/*
 * Code for class GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb335.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.ev_type */
EIF_REFERENCE F848_6438 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_9_);
}


/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.attribute_editor */
EIF_REFERENCE F848_6440 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc7);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,tr4);
	RTLR(11,tr5);
	RTLR(12,loc5);
	RTLR(13,loc8);
	RTLR(14,loc6);
	RTLIU(15);
	
	RTGC;
	Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_7_3_0_1_0_0_0_0_);
	F1209_11188(RTCW(Result), *(EIF_REFERENCE *)(Current));
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.initialize_attribute_editor) */
		/* END INLINED CODE */
	}
	;
	tr1 = RTLNSMART(eif_new_type(1145, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O13222[Dtype(Current)-1562]);
	loc1 = F664_5455(RTCW(tr1));
	loc2 = RTLNS(eif_new_type(1213, 0x00).id, 1213, _OBJSIZ_6_3_0_1_0_0_0_0_);
	tr1 = RTOSCF(5836,F689_5836, (Current));
	F1113_10182(RTCW(loc2), tr1);
	F1120_10306(RTCW(Result), loc2);
	loc3 = RTLNS(eif_new_type(1203, 0x00).id, 1203, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc3));
	loc4 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc4));
	F1195_10961(RTCW(loc2), loc4);
	F1120_10306(RTCW(loc4), loc3);
	loc7 = RTLNS(eif_new_type(1213, 0x00).id, 1213, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc7));
	tr1 = RTLNSMART(eif_new_type(1277, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,997,0,1277,1027,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 4, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+3)->it_b = (EIF_BOOLEAN) 0;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1072,0xFFF9,0,997,3,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A335_512, (EIF_POINTER) _A335_512, (EIF_POINTER)(F848_6446),tr2, 1, 0);
	}
	F1166_10748(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr1 = F1165_10736(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,3,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A335_509_2, (EIF_POINTER) _A335_509_2, (EIF_POINTER)(F848_6443),tr2, 1, 1);
	}
	F681_5535(RTCW(tr1), tr5);
	F1194_10944(RTCW(loc7), ((EIF_INTEGER_32) 40L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr2 = RTOSCF(5837,F689_5837, (Current));
	F1112_10176(RTCW(tr1), tr2);
	loc5 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = RTOSCF(5870,F689_5870, (Current));
	F1113_10182(RTCW(loc5), tr1);
	tr1 = RTMS_EX_H("Select background color",23,1870810226);
	F1112_10176(RTCW(loc5), tr1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8299[Dtype(RTCW(loc1))-1116])(loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	F1195_10961(RTCW(loc7), *(EIF_REFERENCE *)(Current + _REFACS_6_));
	F1203_11117(RTCW(loc3), ((EIF_INTEGER_32) 2L));
	loc8 = RTLNS(eif_new_type(1209, 0x00).id, 1209, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc8));
	F1120_10306(RTCW(loc3), loc8);
	F1203_11119(RTCW(loc3), loc8);
	F1120_10306(RTCW(loc3), loc7);
	F1120_10306(RTCW(loc3), loc5);
	F1203_11119(RTCW(loc3), loc5);
	F1203_11119(RTCW(loc3), loc7);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr1 = F1277_12286(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,4,997,1033,1033,1033,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A335_546_2_3_4_5, (EIF_POINTER) _A335_546_2_3_4_5, (EIF_POINTER)(0),tr2, 1, 4);
	}
	F681_5535(RTCW(tr1), tr5);
	tr1 = F1162_10712(RTCW(loc5));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A335_515, (EIF_POINTER) _A335_515, (EIF_POINTER)(F848_6449),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	loc3 = RTLNS(eif_new_type(1203, 0x00).id, 1203, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc3));
	F1203_11115(RTCW(loc3), ((EIF_INTEGER_32) 2L));
	loc6 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = RTOSCF(5838,F689_5838, (Current));
	F1113_10182(RTCW(loc6), tr1);
	tr1 = RTOSCF(5839,F689_5839, (Current));
	F1112_10176(RTCW(loc6), tr1);
	tr1 = F1162_10712(RTCW(loc6));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A335_513, (EIF_POINTER) _A335_513, (EIF_POINTER)(F848_6447),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F1120_10306(RTCW(loc3), loc6);
	F1120_10306(RTCW(loc4), loc3);
	F1203_11119(RTCW(loc3), loc6);
	ti4_1 = F1106_10144(RTCW(loc5));
	ti4_2 = F1106_10144(RTCW(loc7));
	F1194_10944(RTCW(loc6), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + ((EIF_INTEGER_32) 2L)));
	loc2 = RTLNS(eif_new_type(1213, 0x00).id, 1213, _OBJSIZ_6_3_0_1_0_0_0_0_);
	tr1 = RTOSCF(5834,F689_5834, (Current));
	F1113_10182(RTCW(loc2), tr1);
	F1120_10306(RTCW(Result), loc2);
	loc3 = RTLNS(eif_new_type(1203, 0x00).id, 1203, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc3));
	loc4 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc4));
	F1195_10961(RTCW(loc2), loc4);
	F1120_10306(RTCW(loc4), loc3);
	loc7 = RTLNS(eif_new_type(1213, 0x00).id, 1213, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc7));
	tr1 = RTLNSMART(eif_new_type(1277, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,997,0,1277,1027,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 4, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+3)->it_b = (EIF_BOOLEAN) 1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1072,0xFFF9,0,997,3,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A335_512, (EIF_POINTER) _A335_512, (EIF_POINTER)(F848_6446),tr2, 1, 0);
	}
	F1166_10748(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1165_10736(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,3,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A335_508_2, (EIF_POINTER) _A335_508_2, (EIF_POINTER)(F848_6442),tr2, 1, 1);
	}
	F681_5535(RTCW(tr1), tr5);
	F1194_10944(RTCW(loc7), ((EIF_INTEGER_32) 40L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(5835,F689_5835, (Current));
	F1112_10176(RTCW(tr1), tr2);
	loc5 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = RTOSCF(5870,F689_5870, (Current));
	F1113_10182(RTCW(loc5), tr1);
	tr1 = RTMS_EX_H("Select foreground color",23,660382066);
	F1112_10176(RTCW(loc5), tr1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8298[Dtype(RTCW(loc1))-1116])(loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	F1195_10961(RTCW(loc7), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	F1203_11117(RTCW(loc3), ((EIF_INTEGER_32) 2L));
	loc8 = RTLNS(eif_new_type(1209, 0x00).id, 1209, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc8));
	F1120_10306(RTCW(loc3), loc8);
	F1203_11119(RTCW(loc3), loc8);
	F1120_10306(RTCW(loc3), loc7);
	F1120_10306(RTCW(loc3), loc5);
	F1203_11119(RTCW(loc3), loc5);
	F1203_11119(RTCW(loc3), loc7);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1277_12286(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,4,997,1033,1033,1033,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A335_547_2_3_4_5, (EIF_POINTER) _A335_547_2_3_4_5, (EIF_POINTER)(0),tr2, 1, 4);
	}
	F681_5535(RTCW(tr1), tr5);
	tr1 = F1162_10712(RTCW(loc5));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A335_519, (EIF_POINTER) _A335_519, (EIF_POINTER)(F848_6453),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	loc3 = RTLNS(eif_new_type(1203, 0x00).id, 1203, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc3));
	F1203_11115(RTCW(loc3), ((EIF_INTEGER_32) 2L));
	loc6 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = RTOSCF(5838,F689_5838, (Current));
	F1113_10182(RTCW(loc6), tr1);
	tr1 = RTOSCF(5840,F689_5840, (Current));
	F1112_10176(RTCW(loc6), tr1);
	tr1 = F1162_10712(RTCW(loc6));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A335_514, (EIF_POINTER) _A335_514, (EIF_POINTER)(F848_6448),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F1120_10306(RTCW(loc3), loc6);
	F1120_10306(RTCW(loc4), loc3);
	F1203_11119(RTCW(loc3), loc6);
	ti4_1 = F1106_10144(RTCW(loc5));
	ti4_2 = F1106_10144(RTCW(loc7));
	F1194_10944(RTCW(loc6), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + ((EIF_INTEGER_32) 2L)));
	F848_6441(Current);
	F1563_17197(Current, Result);
	F1563_17196(Current, Result);
	RTLE;
	return Result;
}

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.update_attribute_editor */
void F848_6441 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F848_6451(Current);
	F848_6452(Current);
	RTLE;
}

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.accept_foreground_color_stone */
void F848_6442 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	F848_6454(Current, tr1);
	RTLE;
}

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.accept_background_color_stone */
void F848_6443 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	F848_6450(Current, tr1);
	RTLE;
}

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.retrieve_color */
EIF_REFERENCE F848_6446 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if (arg2) {
		Result = RTLNS(eif_new_type(3, 0x00).id, 3, _OBJSIZ_1_1_0_0_0_0_0_0_);
		tr1 = F1104_10124(RTCW(arg1));
		F4_79(RTCW(Result), tr1, (EIF_BOOLEAN) 1);
	} else {
		Result = RTLNS(eif_new_type(3, 0x00).id, 3, _OBJSIZ_1_1_0_0_0_0_0_0_);
		tr1 = F1104_10124(RTCW(arg1));
		F4_79(RTCW(Result), tr1, (EIF_BOOLEAN) 0);
	}
	RTLE;
	return Result;
}

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.restore_background_color */
void F848_6447 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	tr1 = F1563_17188(Current);
	tr1 = F272_4282(Current, tr1);
	loc1 = F1561_17170(Current, tr1);
	loc1 = RTRV(eif_new_type(1103, 0x00), loc1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1096,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8299[Dtype(RTCW(loc1))-1116])(loc1);
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
	RTAR(tr1,tr2);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1103,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A464_47_1, (EIF_POINTER) _A464_47_1, 0, tr1, 0, 1);
	}
	loc2 = (EIF_REFERENCE) tr4;
	F1563_17199(Current, loc2);
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	F848_6451(Current);
	RTLE;
}

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.restore_foreground_color */
void F848_6448 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	tr1 = F1563_17188(Current);
	tr1 = F272_4282(Current, tr1);
	loc1 = F1561_17170(Current, tr1);
	loc1 = RTRV(eif_new_type(1103, 0x00), loc1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1096,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8298[Dtype(RTCW(loc1))-1116])(loc1);
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
	RTAR(tr1,tr2);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1103,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A464_46_1, (EIF_POINTER) _A464_46_1, 0, tr1, 0, 1);
	}
	loc2 = (EIF_REFERENCE) tr4;
	F1563_17199(Current, loc2);
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	F848_6452(Current);
	RTLE;
}

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.update_background_color */
void F848_6449 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	F1146_10635(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = F1144_10622(RTCW(tr1));
	F681_5547(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = F1144_10622(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A335_545, (EIF_POINTER) _A335_545, (EIF_POINTER)(0),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = F1563_17189(Current, *(EIF_REFERENCE *)(Current + O13220[Dtype(Current)-1562]));
	F1145_10630(RTCW(tr1), tr2);
	RTLE;
}

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.actually_set_background_color */
void F848_6450 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1096,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
	RTAR(tr1,arg1);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1103,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A464_47_1, (EIF_POINTER) _A464_47_1, 0, tr1, 0, 1);
	}
	loc1 = (EIF_REFERENCE) tr4;
	F1563_17199(Current, loc1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	F848_6451(Current);
	RTLE;
}

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.update_background_display */
void F848_6451 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr2 = F1563_17188(Current);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8299[Dtype(RTCW(tr2))-1116])(tr2);
	F1104_10126(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1116_10219(RTCW(tr1));
	RTLE;
}

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.update_foreground_display */
void F848_6452 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = F1563_17188(Current);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8298[Dtype(RTCW(tr2))-1116])(tr2);
	F1104_10126(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1116_10219(RTCW(tr1));
	RTLE;
}

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.update_foreground_color */
void F848_6453 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	F1146_10635(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = F1144_10622(RTCW(tr1));
	F681_5547(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = F1144_10622(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A335_544, (EIF_POINTER) _A335_544, (EIF_POINTER)(0),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = F1563_17189(Current, *(EIF_REFERENCE *)(Current + O13220[Dtype(Current)-1562]));
	F1145_10630(RTCW(tr1), tr2);
	RTLE;
}

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.actually_set_foreground_color */
void F848_6454 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1096,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
	RTAR(tr1,arg1);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1103,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A464_46_1, (EIF_POINTER) _A464_46_1, 0, tr1, 0, 1);
	}
	loc1 = (EIF_REFERENCE) tr4;
	F1563_17199(Current, loc1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	F848_6452(Current);
	RTLE;
}

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.inline-agent#1 of update_foreground_color */
void F848_18058 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = F1146_10634(RTCW(tr1));
	F848_6454(Current, tr1);
	RTLE;
}

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.inline-agent#1 of update_background_color */
void F848_18059 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = F1146_10634(RTCW(tr1));
	F848_6450(Current, tr1);
	RTLE;
}

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.inline-agent#1 of attribute_editor */
void F848_18060 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1116_10219(RTCW(tr1));
	RTLE;
}

/* {GB_EV_COLORIZABLE_EDITOR_CONSTRUCTOR}.inline-agent#2 of attribute_editor */
void F848_18061 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1116_10219(RTCW(tr1));
	RTLE;
}

void EIF_Minit335 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
