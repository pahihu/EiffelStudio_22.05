/*
 * Code for class EV_STOCK_PIXMAPS_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev300.h"
#include "ev_c_util.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STOCK_PIXMAPS_IMP}.information_pixmap */
EIF_REFERENCE F811_6128 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1278, 0x00).id, 1278, _OBJSIZ_6_3_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("dialog-information",18,1358691950);
	tr1 = F811_6137(Current, tr1);
	F1279_12300(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.error_pixmap */
EIF_REFERENCE F811_6129 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1278, 0x00).id, 1278, _OBJSIZ_6_3_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("dialog-error",12,1766531442);
	tr1 = F811_6137(Current, tr1);
	F1279_12300(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.warning_pixmap */
EIF_REFERENCE F811_6130 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1278, 0x00).id, 1278, _OBJSIZ_6_3_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("dialog-warning",14,1187148903);
	tr1 = F811_6137(Current, tr1);
	F1279_12300(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.question_pixmap */
EIF_REFERENCE F811_6131 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1278, 0x00).id, 1278, _OBJSIZ_6_3_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("dialog-question",15,601717614);
	tr1 = F811_6137(Current, tr1);
	F1279_12300(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.default_window_icon */
EIF_REFERENCE F811_6136 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1278, 0x00).id, 1278, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(Result));
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_3_);
	F1514_16427(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.pixmap_from_stock_id */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_REFERENCE F811_6137 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	RTXD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLR(4,loc3);
	RTLR(5,saved_except);
	RTLIU(6);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc2) {
		tr1 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
		F928_6962(RTCW(tr1), arg1);
		loc1 = (EIF_REFERENCE) tr1;
		tr1 = RTLNS(eif_new_type(1091, 0x00).id, 1091, _OBJSIZ_3_0_0_0_0_0_0_0_);
		F1088_9856(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
		RTCT0("attached {EV_PIXEL_BUFFER_IMP} Result.implementation as pixbuf_imp", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_1_);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1286, 0x00),loc3);
		if (EIF_TEST(loc3)) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1287_12449(loc3, loc1);
		F928_6968(RTCW(loc1));
	} else {
		tr1 = RTLNS(eif_new_type(1091, 0x00).id, 1091, _OBJSIZ_3_0_0_0_0_0_0_0_);
		F1088_9856(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
	}
	RTE_E
	RTXSC;
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_STOCK_PIXMAPS_IMP}.information_pixmap_xpm */
EIF_POINTER F811_6139 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) information_pixmap_xpm();
	
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.error_pixmap_xpm */
EIF_POINTER F811_6140 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) error_pixmap_xpm();
	
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.warning_pixmap_xpm */
EIF_POINTER F811_6141 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) warning_pixmap_xpm();
	
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.question_pixmap_xpm */
EIF_POINTER F811_6142 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) question_pixmap_xpm();
	
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.no_cursor_xpm */
EIF_POINTER F811_6151 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) no_cursor_xpm();
	
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.sizenesw_cursor_xpm */
EIF_POINTER F811_6153 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) sizenesw_cursor_xpm();
	
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.sizenwse_cursor_xpm */
EIF_POINTER F811_6155 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) sizenwse_cursor_xpm();
	
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.sizewe_cursor_xpm */
EIF_POINTER F811_6156 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) sizewe_cursor_xpm();
	
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.uparrow_cursor_xpm */
EIF_POINTER F811_6158 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) uparrow_cursor_xpm();
	
	return Result;
}

void EIF_Minit300 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
