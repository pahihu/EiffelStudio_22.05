/*
 * Code for class GB_EV_TOOLTIPABLE_EDITOR_CONSTRUCTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb338.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_EV_TOOLTIPABLE_EDITOR_CONSTRUCTOR}.ev_type */
EIF_REFERENCE F851_6495 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_5_);
}


/* {GB_EV_TOOLTIPABLE_EDITOR_CONSTRUCTOR}.attribute_editor */
EIF_REFERENCE F851_6497 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_REFERENCE tr7 = NULL;
	EIF_REFERENCE tr8 = NULL;
	EIF_REFERENCE tr9 = NULL;
	EIF_REFERENCE tr10 = NULL;
	EIF_REFERENCE tr11 = NULL;
	EIF_REFERENCE tr12 = NULL;
	EIF_REFERENCE tr13 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLR(7,tr6);
	RTLR(8,tr7);
	RTLR(9,tr8);
	RTLR(10,tr9);
	RTLR(11,tr10);
	RTLR(12,tr11);
	RTLR(13,tr12);
	RTLR(14,tr13);
	RTLIU(15);
	
	RTGC;
	Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_7_3_0_1_0_0_0_0_);
	F1209_11188(RTCW(Result), *(EIF_REFERENCE *)(Current));
	F1203_11116(RTCW(Result), ((EIF_INTEGER_32) 2L));
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.initialize_attribute_editor) */
		/* END INLINED CODE */
	}
	;
	tr1 = RTLNSMART(eif_new_type(1206, 0).id);
	tr2 = RTOSCF(6502,F851_6502, (Current));
	tr3 = RTOSCF(5851,F689_5851, (Current));
	tr4 = RTOSCF(5852,F689_5852, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1085,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A338_509_2, (EIF_POINTER) _A338_509_2, (EIF_POINTER)(F851_6501),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1085,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A338_499_2, (EIF_POINTER) _A338_499_2, (EIF_POINTER)(F838_6263),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1207_11155(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, EIF_TRUE, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	F851_6498(Current);
	F1563_17197(Current, Result);
	F1563_17196(Current, Result);
	RTLE;
	return Result;
}

/* {GB_EV_TOOLTIPABLE_EDITOR_CONSTRUCTOR}.update_attribute_editor */
void F851_6498 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = F1112_10175(RTCV(F1563_17188(Current)));
	tr2 = F1078_9449(RTCW(tr2));
	F1207_11160(RTCW(tr1), tr2);
	RTLE;
}

/* {GB_EV_TOOLTIPABLE_EDITOR_CONSTRUCTOR}.set_tooltip */
void F851_6501 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTGC;
	tb1 = F485_4817(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1077,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
		RTAR(tr1,arg1);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1111,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A472_44_1, (EIF_POINTER) _A472_44_1, 0, tr1, 0, 1);
		}
		F1563_17199(Current, tr4);
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,997,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1111,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A472_45_1, (EIF_POINTER) _A472_45_1, 0, tr1, 0, 1);
		}
		F1563_17199(Current, tr4);
	}
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_TOOLTIPABLE_EDITOR_CONSTRUCTOR}.tooltip_string */

EIF_REFERENCE F851_6502 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6502,RTMS_EX_H("Tooltip",7,1367644016));
}

void EIF_Minit338 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
