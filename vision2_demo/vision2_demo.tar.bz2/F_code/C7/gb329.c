/*
 * Code for class GB_EV_PIXMAP_EDITOR_CONSTRUCTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb329.h"
#include "eif_built_in.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_EV_PIXMAP_EDITOR_CONSTRUCTOR}.ev_type */
EIF_REFERENCE F842_6330 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_8_);
}


/* {GB_EV_PIXMAP_EDITOR_CONSTRUCTOR}.attribute_editor */
EIF_REFERENCE F842_6332 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,loc2);
	RTLIU(8);
	
	RTGC;
	Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_7_3_0_1_0_0_0_0_);
	F1209_11188(RTCW(Result), *(EIF_REFERENCE *)(Current));
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.initialize_attribute_editor) */
		/* END INLINED CODE */
	}
	;
	loc1 = RTLNS(eif_new_type(1203, 0x00).id, 1203, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc1));
	loc3 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc3));
	tr1 = RTLNSMART(eif_new_type(1256, 0).id);
	tr2 = RTMS_EX_H("Set with named file",19,523293285);
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A329_511, (EIF_POINTER) _A329_511, (EIF_POINTER)(F842_6335),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A329_528, (EIF_POINTER) _A329_528, (EIF_POINTER)(F1563_17201),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F1120_10306(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	tr1 = RTLNSMART(eif_new_type(1241, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	F1120_10306(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	F1203_11119(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	F1120_10306(RTCW(loc3), loc1);
	tr1 = RTLNSMART(eif_new_type(1209, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	F1120_10306(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	loc2 = RTLNS(eif_new_type(1213, 0x00).id, 1213, _OBJSIZ_6_3_0_1_0_0_0_0_);
	tr1 = RTOSCF(5855,F689_5855, (Current));
	F1113_10182(RTCW(loc2), tr1);
	F1195_10961(RTCW(loc2), loc3);
	F1120_10306(RTCW(Result), loc2);
	F842_6333(Current);
	RTLE;
	return Result;
}

/* {GB_EV_PIXMAP_EDITOR_CONSTRUCTOR}.update_attribute_editor */
void F842_6333 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	tb1 = *(EIF_BOOLEAN *)(RTCV(F1563_17188(Current))+ _CHROFF_6_2_);
	if (tb1) {
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (F1563_17188(Current));
		F842_6336(Current, tr1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,997,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1278,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A637_261_1, (EIF_POINTER) _A637_261_1, 0, tr1, 0, 1);
		}
		F1563_17199(Current, tr4);
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCV(F1563_17188(Current)) + _REFACS_5_);
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
		} else {
			tr1 = RTLNSMART(eif_new_type(1241, 0).id);
			tr2 = RTMS_EX_H("Error - named pixmap missing.",29,386038318);
			F1113_10182(RTCW(tr1), tr2);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tr2 = *(EIF_REFERENCE *)(RTCV(F1563_17188(Current)) + _REFACS_5_);
			tr2 = F964_8109(RTCW(tr2));
			F1112_10176(RTCW(tr1), tr2);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			F1195_10961(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_6_));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,997,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNTS(typres0.id, 1, 1);
			}
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1278,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A637_262_1, (EIF_POINTER) _A637_262_1, 0, tr1, 0, 1);
			}
			F1563_17199(Current, tr4);
		}
	}
	RTLE;
}

/* {GB_EV_PIXMAP_EDITOR_CONSTRUCTOR}.modify_pixmap */
void F842_6335 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc6);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,tr4);
	RTLR(8,loc5);
	RTLIU(9);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1149, 0x00).id, 1149, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1088_9856(RTCW(loc1));
	for (;;) {
		tb1 = '\01';
		tb2 = '\0';
		tr1 = F1149_10651(RTCW(loc1));
		tb3 = F964_8078(RTCW(tr1));
		if (tb3) {
			tb2 = loc3;
		}
		if (!tb2) {
			tb1 = loc4;
		}
		if (tb1) break;
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tr1 = F1563_17189(Current, *(EIF_REFERENCE *)(Current + O13220[dtype-1562]));
		F1145_10630(RTCW(loc1), tr1);
		tr1 = F1149_10651(RTCW(loc1));
		tb2 = F964_8078(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = F1149_10651(RTCW(loc1));
			tr1 = F964_8109(RTCW(tr1));
			loc6 = F1078_9452(RTCW(tr1));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
			tr1 = F1083_9685(RTCW(loc6), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L)), ti4_2);
			loc6 = (EIF_REFERENCE) tr1;
			tr1 = F1078_9449(RTCW(loc6));
			if (F190_3371(Current, tr1)) {
				loc2 = RTLNS(eif_new_type(1278, 0x00).id, 1278, _OBJSIZ_6_3_0_1_0_0_0_0_);
				F1088_9856(RTCW(loc2));
				tr1 = F1149_10651(RTCW(loc1));
				F1279_12310(RTCW(loc2), tr1);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,963,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr1 = RTLNTS(typres0.id, 2, 0);
				}
				tr2 = F1149_10651(RTCW(loc1));
				((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
				RTAR(tr1,tr2);
				
				{
					static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1278,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4= RTLNRF(typres0.id, (EIF_POINTER) __A637_264_1, (EIF_POINTER) _A637_264_1, 0, tr1, 0, 1);
				}
				F1563_17199(Current, tr4);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,963,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr1 = RTLNTS(typres0.id, 2, 0);
				}
				tr2 = F1149_10651(RTCW(loc1));
				((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
				RTAR(tr1,tr2);
				
				{
					static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1278,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4= RTLNRF(typres0.id, (EIF_POINTER) __A637_263_1, (EIF_POINTER) _A637_263_1, 0, tr1, 0, 1);
				}
				F1563_17199(Current, tr4);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,997,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr1 = RTLNTS(typres0.id, 1, 1);
				}
				
				{
					static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1278,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4= RTLNRF(typres0.id, (EIF_POINTER) __A637_261_1, (EIF_POINTER) _A637_261_1, 0, tr1, 0, 1);
				}
				F1563_17199(Current, tr4);
				tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc2);
				F842_6336(Current, tr1);
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				loc5 = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_14_3_0_3_0_0_0_0_);
				F1088_9856(RTCW(loc5));
				tr1 = F190_3372(Current);
				F1235_11936(RTCW(loc5), tr1);
				tr1 = F1563_17189(Current, *(EIF_REFERENCE *)(Current + O13220[dtype-1562]));
				F1226_11642(RTCW(loc5), tr1);
			}
		}
	}
	tr1 = F1563_17188(Current);
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.rebuild_associated_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_PIXMAP_EDITOR_CONSTRUCTOR}.add_pixmap_to_pixmap_container */
void F842_6336 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REAL_64 loc1 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc2 = (EIF_REAL_64) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REAL_64 loc5 = (EIF_REAL_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCV(F1563_17188(Current)) + _REFACS_5_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCV(F1563_17188(Current)) + _REFACS_5_);
		tr1 = F964_8109(RTCW(tr1));
		F1112_10176(RTCW(arg1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tr2 = *(EIF_REFERENCE *)(RTCV(F1563_17188(Current)) + _REFACS_5_);
		tr2 = F964_8109(RTCW(tr2));
		F1112_10176(RTCW(tr1), tr2);
	}
	ti4_1 = F1106_10142(RTCW(arg1));
	loc1 = (EIF_REAL_64) (EIF_REAL_64) ((EIF_REAL_64) (ti4_1) /  (EIF_REAL_64) (((EIF_INTEGER_32) 165L)));
	ti4_1 = F1106_10143(RTCW(arg1));
	loc2 = (EIF_REAL_64) (EIF_REAL_64) ((EIF_REAL_64) (ti4_1) /  (EIF_REAL_64) (((EIF_INTEGER_32) 165L)));
	tb1 = '\0';
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) eif_is_greater_real_64 (loc1, tr8_1)) {
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 1L));
		tb1 = (EIF_BOOLEAN) eif_is_less_real_64 (loc2, tr8_1);
	}
	if (tb1) {
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 165L);
		ti4_1 = F1106_10143(RTCW(arg1));
		tr8_1 = (EIF_REAL_64) (ti4_1);
		loc4 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) (tr8_1) /  (EIF_REAL_64) (loc1));
	}
	tb1 = '\0';
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) eif_is_greater_real_64 (loc2, tr8_1)) {
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 1L));
		tb1 = (EIF_BOOLEAN) eif_is_less_real_64 (loc1, tr8_1);
	}
	if (tb1) {
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 165L);
		ti4_1 = F1106_10142(RTCW(arg1));
		tr8_1 = (EIF_REAL_64) (ti4_1);
		loc3 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) (tr8_1) /  (EIF_REAL_64) (loc2));
	}
	tb1 = '\0';
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) eif_is_greater_real_64 (loc2, tr8_1)) {
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 1L));
		tb1 = (EIF_BOOLEAN) eif_is_greater_real_64 (loc1, tr8_1);
	}
	if (tb1) {
		loc5 = eif_max_real64 (loc1,loc2);
		ti4_1 = F1106_10142(RTCW(arg1));
		tr8_1 = (EIF_REAL_64) (ti4_1);
		loc3 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) (tr8_1) /  (EIF_REAL_64) (loc5));
		ti4_1 = F1106_10143(RTCW(arg1));
		tr8_1 = (EIF_REAL_64) (ti4_1);
		loc4 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) (tr8_1) /  (EIF_REAL_64) (loc5));
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 != ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L)))) {
		F1279_12314(RTCW(arg1), loc3, loc4);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1210_11198(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1195_10961(RTCW(tr1), arg1);
	ti4_1 = F1106_10142(RTCW(arg1));
	ti4_2 = F1106_10143(RTCW(arg1));
	F1194_10946(RTCW(arg1), ti4_1, ti4_2);
	RTLE;
}

void EIF_Minit329 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
