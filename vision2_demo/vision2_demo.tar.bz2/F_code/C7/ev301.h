
#ifndef _C7_ev301_
#define _C7_ev301_

#ifdef __cplusplus
extern "C" {
#endif

extern void F812_6160(EIF_REFERENCE, EIF_REFERENCE);
extern void F812_6161(EIF_REFERENCE);
extern void F812_6162(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F812_6163(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit301(void);
extern EIF_BOOLEAN F1280_12326(EIF_REFERENCE);
extern void F1304_12781(EIF_REFERENCE, EIF_BOOLEAN);

#ifdef __cplusplus
}
#endif

#endif
