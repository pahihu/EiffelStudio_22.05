/*
 * Code for class GB_EV_FRAME_EDITOR_CONSTRUCTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb333.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_EV_FRAME_EDITOR_CONSTRUCTOR}.ev_type */
EIF_REFERENCE F846_6388 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_10_);
}


/* {GB_EV_FRAME_EDITOR_CONSTRUCTOR}.attribute_editor */
EIF_REFERENCE F846_6390 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_7_3_0_1_0_0_0_0_);
	F1209_11188(RTCW(Result), *(EIF_REFERENCE *)(Current));
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.initialize_attribute_editor) */
		/* END INLINED CODE */
	}
	;
	tr1 = RTLNSMART(eif_new_type(1241, 0).id);
	tr2 = RTMS_EX_H("Style",5,1954752101);
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	F1120_10306(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	tr1 = RTLNSMART(eif_new_type(1253, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	F1120_10306(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1248_12039(RTCW(tr1));
	tr1 = RTLNSMART(eif_new_type(1189, 0).id);
	tr2 = RTOSCF(6398,F846_6398, (Current));
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_6_));
	tr1 = RTLNSMART(eif_new_type(1189, 0).id);
	tr2 = RTOSCF(6399,F846_6399, (Current));
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	tr1 = RTLNSMART(eif_new_type(1189, 0).id);
	tr2 = RTOSCF(6400,F846_6400, (Current));
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_8_));
	tr1 = RTLNSMART(eif_new_type(1189, 0).id);
	tr2 = RTOSCF(6401,F846_6401, (Current));
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F1152_10678(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A333_513, (EIF_POINTER) _A333_513, (EIF_POINTER)(F846_6393),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F1152_10678(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A333_534, (EIF_POINTER) _A333_534, (EIF_POINTER)(F1563_17201),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F846_6391(Current);
	F1563_17197(Current, Result);
	F1563_17196(Current, Result);
	RTLE;
	return Result;
}

/* {GB_EV_FRAME_EDITOR_CONSTRUCTOR}.update_attribute_editor */
void F846_6391 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F1152_10678(RTCW(tr1));
	F688_5577(RTCW(tr1));
	ti4_1 = F1214_11420(RTCV(F1563_17188(Current)));
	switch (ti4_1) {
		case 1L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			F1109_10165(RTCW(tr1));
			break;
		case 2L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			F1109_10165(RTCW(tr1));
			break;
		case 3L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			F1109_10165(RTCW(tr1));
			break;
		case 4L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			F1109_10165(RTCW(tr1));
			break;
		default:
			break;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F1152_10678(RTCW(tr1));
	F688_5579(RTCW(tr1));
	RTLE;
}

/* {GB_EV_FRAME_EDITOR_CONSTRUCTOR}.selection_changed */
void F846_6393 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 1);
	}
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = F1253_12120(RTCW(tr2));
	tr2 = F1113_10183(RTCW(tr2));
	tr2 = F1078_9449(RTCW(tr2));
	ti4_1 = F846_6394(Current, tr2);
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = ti4_1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1213,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A572_266_1, (EIF_POINTER) _A572_266_1, 0, tr1, 0, 1);
	}
	F1563_17199(Current, tr4);
	RTLE;
}

/* {GB_EV_FRAME_EDITOR_CONSTRUCTOR}.style_from_text */
EIF_INTEGER_32 F846_6394 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(6398,F846_6398, (Current));
	tb1 = F1084_9718(RTCW(arg1), tr1);
	if (tb1) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		tr1 = RTOSCF(6399,F846_6399, (Current));
		tb1 = F1084_9718(RTCW(arg1), tr1);
		if (tb1) {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		} else {
			tr1 = RTOSCF(6400,F846_6400, (Current));
			tb1 = F1084_9718(RTCW(arg1), tr1);
			if (tb1) {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			} else {
				tr1 = RTOSCF(6401,F846_6401, (Current));
				tb1 = F1084_9718(RTCW(arg1), tr1);
				if (tb1) {
					RTLE;
					return (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
				} else {
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {GB_EV_FRAME_EDITOR_CONSTRUCTOR}.ev_frame_lowered_string */

EIF_REFERENCE F846_6398 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6398,RTMS_EX_H("Ev_frame_lowered",16,1636919140));
}

/* {GB_EV_FRAME_EDITOR_CONSTRUCTOR}.ev_frame_raised_string */

EIF_REFERENCE F846_6399 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6399,RTMS_EX_H("Ev_frame_raised",15,1646383972));
}

/* {GB_EV_FRAME_EDITOR_CONSTRUCTOR}.ev_frame_etched_in_string */

EIF_REFERENCE F846_6400 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6400,RTMS_EX_H("Ev_frame_etched_in",18,27015534));
}

/* {GB_EV_FRAME_EDITOR_CONSTRUCTOR}.ev_frame_etched_out_string */

EIF_REFERENCE F846_6401 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6401,RTMS_EX_H("Ev_frame_etched_out",19,473932404));
}

void EIF_Minit333 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
