/*
 * Code for class EV_GRID_DRAWER_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev344.h"
#include "eif_built_in.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GRID_DRAWER_I}.make_with_grid */
void F857_6579 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	tr1 = RTLNSMART(eif_new_type(860, 0).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {EV_GRID_DRAWER_I}.items_spanning_horizontal_span */
EIF_REFERENCE F857_6581 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc13);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc3);
	RTLR(4,loc8);
	RTLIU(5);
	
	RTGC;
	loc13 = *(EIF_REFERENCE *)(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {670,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 670, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F671_5447(RTCW(Result), ((EIF_INTEGER_32) 20L));
	loc3 = F1390_14461(RTCW(loc13));
	loc1 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_113_55_10_15_);
	loc12 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_113_55_10_8_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_113_55_10_17_);
	ti4_1 = F1390_14457(RTCW(loc13));
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		loc9 = (EIF_INTEGER_32) arg1;
		loc10 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + arg2);
		tb1 = '\0';
		if ((EIF_BOOLEAN) (loc10 >= ((EIF_INTEGER_32) 0L))) {
			ti4_1 = F1390_14287(RTCW(loc13));
			tb1 = (EIF_BOOLEAN) (loc9 <= ti4_1);
		}
		if (tb1) {
			ti4_1 = eif_max_int32 (loc9,((EIF_INTEGER_32) 0L));
			loc9 = (EIF_INTEGER_32) ti4_1;
			ti4_1 = F1390_14287(RTCW(loc13));
			ti4_1 = eif_min_int32 (loc10,ti4_1);
			loc10 = (EIF_INTEGER_32) ti4_1;
			loc8 = *(EIF_REFERENCE *)(RTCW(loc13) + _REFACS_87_);
			F671_5478(RTCW(loc8));
			for (;;) {
				tb1 = '\01';
				if (!loc7) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O4870[Dtype(loc8)-663]);
					ti4_2 = F1390_14457(RTCW(loc13));
					tb1 = (EIF_BOOLEAN) (ti4_1 > (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
				}
				if (tb1) break;
				loc11 = F671_5452(RTCW(loc8));
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc6 && (EIF_BOOLEAN) (loc11 > loc9))) {
					loc4 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O4870[Dtype(loc8)-663]);
					loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L));
					loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
				tb2 = '\0';
				if (loc6) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O4870[Dtype(loc8)-663]);
					tb3 = F1390_14413(RTCW(loc13), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
					tb2 = tb3;
				}
				if (tb2) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O4870[Dtype(loc8)-663]);
					ti4_2 = (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(Result))-534])(Result, (EIF_REFERENCE) &ti4_2);
				}
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc7 && (EIF_BOOLEAN) (loc10 < loc11))) {
					loc5 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O4870[Dtype(loc8)-663]);
					loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - ((EIF_INTEGER_32) 1L));
					loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
				F671_5480(RTCW(loc8));
			}
			if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 0L))) {
				loc5 = F1390_14457(RTCW(loc13));
			}
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
				loc4 = F1390_14457(RTCW(loc13));
			}
		}
	}
	RTLE;
	return Result;
}

/* {EV_GRID_DRAWER_I}.items_spanning_vertical_span */
EIF_REFERENCE F857_6582 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc14 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc15 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc18 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc19 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc20);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,loc16);
	RTLR(5,loc3);
	RTLR(6,loc17);
	RTLIU(7);
	
	RTGC;
	loc20 = *(EIF_REFERENCE *)(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {670,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 670, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F671_5447(RTCW(Result), ((EIF_INTEGER_32) 20L));
	tr1 = *(EIF_REFERENCE *)(RTCW(loc20) + _REFACS_93_);
	tb1 = F483_4817(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		loc4 = (EIF_INTEGER_32) arg1;
		loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + arg2);
		loc8 = F1390_14458(RTCW(loc20));
		tb1 = '\0';
		if ((EIF_BOOLEAN) (loc5 >= ((EIF_INTEGER_32) 0L))) {
			ti4_1 = F1390_14483(RTCW(loc20));
			tb1 = (EIF_BOOLEAN) (loc4 < ti4_1);
		}
		if (tb1) {
			ti4_1 = eif_max_int32 (loc4,((EIF_INTEGER_32) 0L));
			loc4 = (EIF_INTEGER_32) ti4_1;
			ti4_1 = F1390_14288(RTCW(loc20));
			ti4_1 = eif_min_int32 (loc5,ti4_1);
			loc5 = (EIF_INTEGER_32) ti4_1;
			tb1 = F1390_14647(RTCW(loc20));
			if ((EIF_BOOLEAN) !tb1) {
				loc1 = *(EIF_INTEGER_32 *)(RTCW(loc20)+ _LNGOFF_113_55_10_6_);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 / loc1) + ((EIF_INTEGER_32) 1L));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc20)+ _LNGOFF_113_55_10_6_);
				loc2 = eif_min_int32 ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 / ti4_1) + ((EIF_INTEGER_32) 1L)),loc8);
				if ((EIF_BOOLEAN) (loc1 <= loc8)) {
					loc7 = (EIF_INTEGER_32) loc8;
					loc6 = (EIF_INTEGER_32) loc1;
					for (;;) {
						if ((EIF_BOOLEAN) (loc6 > loc2)) break;
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(Result))-534])(Result, (EIF_REFERENCE) &loc6);
						loc6++;
					}
				}
			} else {
				loc16 = *(EIF_REFERENCE *)(RTCW(loc20) + _REFACS_90_);
				RTCT0("l_visible_indexes_to_row_indexes /= Void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc16 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				loc3 = *(EIF_REFERENCE *)(RTCW(loc20) + _REFACS_88_);
				RTCT0("l_row_offsets /= Void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				loc10 = (EIF_INTEGER_32) loc8;
				loc11 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				for (;;) {
					if ((EIF_BOOLEAN) !(EIF_BOOLEAN) ((EIF_INTEGER_32) (loc10 - loc11) > ((EIF_INTEGER_32) 1L))) break;
					loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc11 + loc10) / ((EIF_INTEGER_32) 2L));
					ti4_1 = F671_5453(RTCW(loc3), loc9);
					if ((EIF_BOOLEAN) (ti4_1 <= loc4)) {
						loc11 = (EIF_INTEGER_32) loc9;
					} else {
						loc10 = (EIF_INTEGER_32) loc9;
					}
				}
				loc15 = F671_5453(RTCW(loc3), loc10);
				if ((EIF_BOOLEAN) (loc15 <= loc4)) {
					loc14 = (EIF_INTEGER_32) loc10;
				} else {
					loc14 = eif_max_int32 (loc11,((EIF_INTEGER_32) 1L));
					loc15 = F671_5453(RTCW(loc3), loc14);
				}
				tb1 = '\0';
				if ((EIF_BOOLEAN) (loc14 > ((EIF_INTEGER_32) 1L))) {
					ti4_1 = F671_5453(RTCW(loc3), (EIF_INTEGER_32) (loc14 - ((EIF_INTEGER_32) 1L)));
					tb1 = (EIF_BOOLEAN)(ti4_1 == loc15);
				}
				if (tb1) {
					loc10 = F1390_14459(RTCW(loc20));
					loc11 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					for (;;) {
						if ((EIF_BOOLEAN) !(EIF_BOOLEAN) ((EIF_INTEGER_32) (loc10 - loc11) > ((EIF_INTEGER_32) 1L))) break;
						loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc11 + loc10) / ((EIF_INTEGER_32) 2L));
						ti4_1 = F671_5453(RTCW(loc16), loc9);
						if ((EIF_BOOLEAN) (ti4_1 < loc14)) {
							loc11 = (EIF_INTEGER_32) loc9;
						} else {
							loc10 = (EIF_INTEGER_32) loc9;
						}
					}
					ti4_1 = F671_5453(RTCW(loc16), loc10);
					if ((EIF_BOOLEAN) (ti4_1 <= loc14)) {
						loc14 = F671_5453(RTCW(loc16), loc10);
					} else {
						ti4_1 = eif_max_int32 (loc11,((EIF_INTEGER_32) 1L));
						loc14 = F671_5453(RTCW(loc16), ti4_1);
					}
				}
				loc17 = *(EIF_REFERENCE *)(RTCW(loc20) + _REFACS_89_);
				RTCT0("l_row_indexes_to_visible_indexes /= Void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc17 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				loc12 = F671_5453(RTCW(loc17), loc14);
				loc12 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc12 + ((EIF_INTEGER_32) 1L));
				loc14 = F671_5453(RTCW(loc16), loc12);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(Result))-534])(Result, (EIF_REFERENCE) &loc14);
				loc18 = *(EIF_BOOLEAN *)(RTCW(loc20)+ _CHROFF_113_19_);
				loc19 = *(EIF_INTEGER_32 *)(RTCW(loc20)+ _LNGOFF_113_55_10_6_);
				loc13 = F671_5453(RTCW(loc3), loc14);
				if (loc18) {
					loc13 += loc19;
				} else {
					tr1 = F1390_14256(RTCW(loc20), loc14);
					ti4_1 = F1127_10375(RTCW(tr1));
					loc13 += ti4_1;
				}
				loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc12 + ((EIF_INTEGER_32) 1L));
				for (;;) {
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (loc13 > loc5)) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc20)+ _LNGOFF_113_55_10_19_);
						tb1 = (EIF_BOOLEAN) (loc6 > ti4_1);
					}
					if (tb1) break;
					loc14 = F671_5453(RTCW(loc16), loc6);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(Result))-534])(Result, (EIF_REFERENCE) &loc14);
					if (loc18) {
						loc13 += loc19;
					} else {
						tr1 = F1390_14256(RTCW(loc20), loc14);
						ti4_1 = F1127_10375(RTCW(tr1));
						loc13 += ti4_1;
					}
					loc6++;
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {EV_GRID_DRAWER_I}.item_coordinates_at_position */
EIF_REFERENCE F857_6586 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = F857_6587(Current, arg1, arg2);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		Result = RTLNS(eif_new_type(861, 0x00).id, 861, _OBJSIZ_0_0_0_0_0_0_0_2_);
		tr1 = F1348_13623(RTCW(loc1));
		ti4_1 = F1135_10560(RTCW(tr1));
		tr1 = F1348_13625(RTCW(loc1));
		ti4_2 = F1127_10386(RTCW(tr1));
		F862_6732(RTCW(Result), ti4_1, ti4_2);
	}
	RTLE;
	return Result;
}

/* {EV_GRID_DRAWER_I}.item_at_position */
EIF_REFERENCE F857_6587 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	loc3 = *(EIF_REFERENCE *)(Current);
	F1390_14473(RTCW(loc3));
	F1390_14472(RTCW(loc3));
	Result = F857_6591(Current, arg1, arg2);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		ti4_1 = F857_6608(Current, arg1);
		loc1 = F857_6581(Current, ti4_1, ((EIF_INTEGER_32) 0L));
		ti4_1 = F857_6609(Current, arg2);
		loc2 = F857_6582(Current, ti4_1, ((EIF_INTEGER_32) 0L));
		tb1 = '\0';
		tb2 = F489_4817(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb2) {
			tb2 = F489_4817(RTCW(loc2));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			ti4_1 = F671_5455(RTCW(loc1));
			ti4_2 = F671_5455(RTCW(loc2));
			Result = F1390_14646(RTCW(loc3), ti4_1, ti4_2);
			if ((EIF_BOOLEAN)(Result != NULL)) {
				tb1 = '\01';
				tr1 = F1348_13623(RTCW(Result));
				tb2 = F1135_10550(RTCW(tr1));
				if (!tb2) {
					tr1 = F1348_13625(RTCW(Result));
					tb2 = F1127_10388(RTCW(tr1));
					tb1 = tb2;
				}
				if (tb1) {
					RTLE;
					return (EIF_REFERENCE) NULL;
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {EV_GRID_DRAWER_I}.item_at_position_strict */
EIF_REFERENCE F857_6590 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = F857_6587(Current, arg1, arg2);
	if ((EIF_BOOLEAN)(Result != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc1 = F1390_14484(RTCW(tr1), Result);
		ti4_1 = F1348_13626(RTCW(Result));
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (F857_6608(Current, arg1) - ti4_1) < ((EIF_INTEGER_32) 0L))) {
			RTLE;
			return (EIF_REFERENCE) NULL;
		}
	}
	RTLE;
	return Result;
}

/* {EV_GRID_DRAWER_I}.locked_item_at_position */
EIF_REFERENCE F857_6591 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(12);
	RTLR(0,loc10);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,loc9);
	RTLR(4,loc2);
	RTLR(5,tr1);
	RTLR(6,loc6);
	RTLR(7,Result);
	RTLR(8,loc11);
	RTLR(9,loc3);
	RTLR(10,loc7);
	RTLR(11,loc12);
	RTLIU(12);
	
	RTGC;
	loc10 = *(EIF_REFERENCE *)(Current);
	loc1 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_71_);
	loc9 = F664_5458(RTCW(loc1));
	F664_5479(RTCW(loc1));
	for (;;) {
		tb1 = '\01';
		tb2 = F591_5028(RTCW(loc1));
		if (!tb2) {
			tb1 = loc8;
		}
		if (tb1) break;
		loc2 = F664_5452(RTCW(loc1));
		loc2 = RTRV(eif_new_type(146, 0x00), loc2);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(loc10)+ _CHROFF_113_19_);
			if (tb2) {
				loc4 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_113_55_10_6_);
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_6_);
				loc4 = F1334_13421(RTCW(tr1));
			}
			tb2 = '\0';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_113_55_10_18_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_7_0_0_0_);
			if ((EIF_BOOLEAN) (arg2 >= (EIF_INTEGER_32) (ti4_1 + ti4_2))) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_113_55_10_18_);
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_7_0_0_0_);
				tb2 = (EIF_BOOLEAN) (arg2 < (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + loc4));
			}
			if (tb2) {
				loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				ti4_1 = F857_6608(Current, arg1);
				loc6 = F857_6581(Current, ti4_1, ((EIF_INTEGER_32) 0L));
				tb2 = F489_4817(RTCW(loc6));
				if ((EIF_BOOLEAN) !tb2) {
					ti4_1 = F671_5455(RTCW(loc6));
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_6_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_11_7_0_3_);
					Result = F1390_14646(RTCW(loc10), ti4_1, ti4_2);
					if ((EIF_BOOLEAN)(Result != NULL)) {
						tb2 = '\0';
						tb3 = '\0';
						tr1 = F1348_13623(RTCW(Result));
						tb4 = F1135_10550(RTCW(tr1));
						if (tb4) {
							tr1 = F1348_13623(RTCW(Result));
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_6_);
							loc11 = tr1;
							tb3 = EIF_TEST(loc11);
						}
						if (tb3) {
							ti4_1 = *(EIF_INTEGER_32 *)(loc11+ _LNGOFF_7_0_0_1_);
							ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_7_0_0_1_);
							tb2 = (EIF_BOOLEAN) (ti4_1 > ti4_2);
						}
						if (tb2) {
							Result = (EIF_REFERENCE) NULL;
						}
					}
				}
			}
		} else {
			loc3 = F664_5452(RTCW(loc1));
			loc3 = RTRV(eif_new_type(145, 0x00), loc3);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_6_);
				loc5 = F1335_13503(RTCW(tr1));
				tb2 = '\0';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_113_55_10_17_);
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_7_0_0_0_);
				if ((EIF_BOOLEAN) (arg1 >= (EIF_INTEGER_32) (ti4_1 + ti4_2))) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_113_55_10_17_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_7_0_0_0_);
					tb2 = (EIF_BOOLEAN) (arg1 < (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + loc5));
				}
				if (tb2) {
					loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					ti4_1 = F857_6609(Current, arg2);
					loc7 = F857_6582(Current, ti4_1, ((EIF_INTEGER_32) 0L));
					tb2 = F489_4817(RTCW(loc7));
					if ((EIF_BOOLEAN) !tb2) {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_6_);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_9_4_0_0_);
						ti4_2 = F671_5455(RTCW(loc7));
						Result = F1390_14646(RTCW(loc10), ti4_1, ti4_2);
						if ((EIF_BOOLEAN)(Result != NULL)) {
							tb2 = '\0';
							tb3 = '\0';
							tr1 = F1348_13625(RTCW(Result));
							tb4 = F1127_10388(RTCW(tr1));
							if (tb4) {
								tr1 = F1348_13625(RTCW(Result));
								tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
								tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
								loc12 = tr1;
								tb3 = EIF_TEST(loc12);
							}
							if (tb3) {
								ti4_1 = *(EIF_INTEGER_32 *)(loc12+ _LNGOFF_7_0_0_1_);
								ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_7_0_0_1_);
								tb2 = (EIF_BOOLEAN) (ti4_1 > ti4_2);
							}
							if (tb2) {
								Result = (EIF_REFERENCE) NULL;
							}
						}
					}
				}
			}
		}
		F664_5481(RTCW(loc1));
	}
	F664_5483(RTCW(loc1), loc9);
	RTLE;
	return Result;
}

/* {EV_GRID_DRAWER_I}.redraw_area_in_drawable_coordinates_wrapper */
void F857_6595 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_91_);
	tr2 = *(EIF_REFERENCE *)(Current);
	tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_92_);
	F857_6596(Current, arg1, arg2, arg3, arg4, tr1, tr2, NULL);
	RTLE;
}

/* {EV_GRID_DRAWER_I}.redraw_area_in_drawable_coordinates */
RTEOMS(6595,1);
void F857_6596 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc14 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc15 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc18 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc19 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc20 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc21 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc22 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc23 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc24 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc25 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc26 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc27 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc28 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc29 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc30 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc31 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc32 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc33 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc34 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc35 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc36 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc37 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc38 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc39 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc40 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc41 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc42 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc43 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc44 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc45 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc46 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc47 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc48 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc49 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc50 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc51 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc52 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc53 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc54 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc55 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc56 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc57 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc58 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc59 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc60 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc61 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc62 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc63 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc64 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc65 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc66 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc67 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc68 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc69 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc70 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc71 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc72 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc73 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc74 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc75 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc76 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc77 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc78 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc79 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc80 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc81 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc82 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	EIF_BOOLEAN tb7;
	RTCFDT;
	RTLD;
	
	RTLI(36);
	RTLR(0,loc78);
	RTLR(1,Current);
	RTLR(2,arg5);
	RTLR(3,loc27);
	RTLR(4,loc5);
	RTLR(5,loc43);
	RTLR(6,loc42);
	RTLR(7,loc64);
	RTLR(8,loc8);
	RTLR(9,arg7);
	RTLR(10,loc74);
	RTLR(11,loc75);
	RTLR(12,tr1);
	RTLR(13,loc16);
	RTLR(14,loc17);
	RTLR(15,loc31);
	RTLR(16,loc32);
	RTLR(17,loc65);
	RTLR(18,loc7);
	RTLR(19,loc6);
	RTLR(20,loc47);
	RTLR(21,loc72);
	RTLR(22,loc66);
	RTLR(23,loc12);
	RTLR(24,loc13);
	RTLR(25,tr2);
	RTLR(26,tr3);
	RTLR(27,loc48);
	RTLR(28,loc58);
	RTLR(29,loc59);
	RTLR(30,loc77);
	RTLR(31,loc60);
	RTLR(32,loc79);
	RTLR(33,loc80);
	RTLR(34,loc81);
	RTLR(35,loc82);
	RTLIU(36);
	
	RTGC;
	loc78 = *(EIF_REFERENCE *)(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc78)+ _CHROFF_113_46_);
	if ((EIF_BOOLEAN) !tb1) {
		F1116_10217(RTCW(arg5));
		F1390_14489(RTCW(loc78));
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg3 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg4 > ((EIF_INTEGER_32) 0L)))) {
			F1116_10241(RTCV(RTOSCF(6606,F857_6606, (Current))));
			loc27 = *(EIF_REFERENCE *)(RTCW(loc78) + _REFACS_70_);
			F1390_14473(RTCW(loc78));
			F1390_14472(RTCW(loc78));
			{
				static EIF_TYPE_INDEX typarr0[] = {670,1033,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc5 = RTLNS(typres0.id, 670, _OBJSIZ_1_1_0_1_0_0_0_0_);
			}
			F671_5447(RTCW(loc5), ((EIF_INTEGER_32) 8L));
			ti4_1 = ((EIF_INTEGER_32) 0L);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(loc5))-534])(loc5, (EIF_REFERENCE) &ti4_1);
			loc43 = *(EIF_REFERENCE *)(RTCW(loc78) + _REFACS_94_);
			loc42 = *(EIF_REFERENCE *)(RTCW(loc78) + _REFACS_95_);
			loc61 = *(EIF_BOOLEAN *)(RTCW(loc78)+ _CHROFF_113_21_);
			loc64 = *(EIF_REFERENCE *)(RTCW(loc78) + _REFACS_79_);
			loc40 = ((EIF_INTEGER_32) 3L);
			loc45 = *(EIF_INTEGER_32 *)(RTCW(loc78)+ _LNGOFF_113_55_10_20_);
			loc46 = F1106_10143(RTCW(loc43));
			loc33 = *(EIF_INTEGER_32 *)(RTCW(loc78)+ _LNGOFF_113_55_10_23_);
			loc41 = *(EIF_INTEGER_32 *)(RTCW(loc78)+ _LNGOFF_113_55_10_21_);
			loc44 = *(EIF_INTEGER_32 *)(RTCW(loc78)+ _LNGOFF_113_55_10_22_);
			loc8 = F1390_14461(RTCW(loc78));
			if ((EIF_BOOLEAN)(arg7 == NULL)) {
				loc1 = *(EIF_INTEGER_32 *)(RTCW(loc78)+ _LNGOFF_113_55_10_15_);
				loc2 = *(EIF_INTEGER_32 *)(RTCW(loc78)+ _LNGOFF_113_55_10_16_);
			} else {
				loc74 = arg7;
				loc74 = RTRV(eif_new_type(145, 0x00), loc74);
				loc75 = arg7;
				loc75 = RTRV(eif_new_type(146, 0x00), loc75);
				if ((EIF_BOOLEAN)(loc74 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc74) + _REFACS_6_);
					loc1 = F1335_13505(RTCW(tr1));
					loc2 = *(EIF_INTEGER_32 *)(RTCW(arg7)+ _LNGOFF_7_0_0_2_);
				} else {
					if ((EIF_BOOLEAN)(loc75 != NULL)) {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc75) + _REFACS_6_);
						loc2 = F1334_13428(RTCW(tr1));
						loc1 = *(EIF_INTEGER_32 *)(RTCW(arg7)+ _LNGOFF_7_0_0_3_);
					} else {
					}
				}
			}
			loc28 = *(EIF_INTEGER_32 *)(RTCW(loc78)+ _LNGOFF_113_55_10_8_);
			loc29 = *(EIF_INTEGER_32 *)(RTCW(loc78)+ _LNGOFF_113_55_10_9_);
			loc3 = *(EIF_INTEGER_32 *)(RTCW(loc78)+ _LNGOFF_113_55_10_18_);
			loc4 = *(EIF_INTEGER_32 *)(RTCW(loc78)+ _LNGOFF_113_55_10_17_);
			loc67 = F1390_14458(RTCW(loc78));
			loc69 = *(EIF_BOOLEAN *)(RTCW(loc78)+ _CHROFF_113_34_);
			loc70 = *(EIF_BOOLEAN *)(RTCW(loc78)+ _CHROFF_113_18_);
			loc68 = *(EIF_INTEGER_32 *)(RTCW(loc78)+ _LNGOFF_113_55_10_6_);
			tb1 = '\0';
			if ((EIF_BOOLEAN) (loc67 > ((EIF_INTEGER_32) 0L))) {
				ti4_1 = F1390_14457(RTCW(loc78));
				tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
			}
			if (tb1) {
				loc16 = *(EIF_REFERENCE *)(RTCW(loc78) + _REFACS_87_);
				loc17 = *(EIF_REFERENCE *)(RTCW(loc78) + _REFACS_88_);
				if ((EIF_BOOLEAN)(loc74 == NULL)) {
					ti4_1 = F857_6608(Current, arg1);
					loc31 = F857_6581(Current, ti4_1, (EIF_INTEGER_32) (arg3 - ((EIF_INTEGER_32) 1L)));
				} else {
					{
						static EIF_TYPE_INDEX typarr0[] = {670,1033,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						loc31 = RTLNS(typres0.id, 670, _OBJSIZ_1_1_0_1_0_0_0_0_);
					}
					F671_5447(RTCW(loc31), ((EIF_INTEGER_32) 1L));
					tr1 = *(EIF_REFERENCE *)(RTCW(loc74) + _REFACS_6_);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_9_4_0_0_);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(loc31))-534])(loc31, (EIF_REFERENCE) &ti4_1);
				}
				if ((EIF_BOOLEAN)(loc75 == NULL)) {
					ti4_1 = F857_6609(Current, arg2);
					loc32 = F857_6582(Current, ti4_1, (EIF_INTEGER_32) (arg4 - ((EIF_INTEGER_32) 1L)));
				} else {
					{
						static EIF_TYPE_INDEX typarr0[] = {670,1033,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						loc32 = RTLNS(typres0.id, 670, _OBJSIZ_1_1_0_1_0_0_0_0_);
					}
					F671_5447(RTCW(loc32), ((EIF_INTEGER_32) 1L));
					tr1 = *(EIF_REFERENCE *)(RTCW(loc75) + _REFACS_6_);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_11_7_0_3_);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(loc32))-534])(loc32, (EIF_REFERENCE) &ti4_1);
				}
				tb1 = '\01';
				tb2 = F489_4817(RTCW(loc31));
				if (!tb2) {
					tb2 = F489_4817(RTCW(loc32));
					tb1 = tb2;
				}
				if ((EIF_BOOLEAN) !tb1) {
					loc9 = F671_5455(RTCW(loc31));
					loc11 = F671_5456(RTCW(loc31));
					loc10 = F671_5455(RTCW(loc32));
					loc23 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					F671_5478(RTCW(loc32));
					loc65 = *(EIF_REFERENCE *)(RTCW(loc78) + _REFACS_84_);
					for (;;) {
						tb1 = F598_5028(RTCW(loc32));
						if (tb1) break;
						loc15 = F671_5452(RTCW(loc32));
						loc7 = F1390_14616(RTCW(loc78), loc15);
						loc6 = F664_5454(RTCW(loc65), loc15);
						tb2 = F1390_14647(RTCW(loc78));
						if ((EIF_BOOLEAN) !tb2) {
							loc23 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc68 * (EIF_INTEGER_32) (loc15 - ((EIF_INTEGER_32) 1L))) - (EIF_INTEGER_32) (loc2 - loc3));
							loc19 = (EIF_INTEGER_32) loc68;
						} else {
							if ((EIF_BOOLEAN)(loc17 != NULL)) {
								loc23 = F671_5454(RTCW(loc17), loc15);
								loc23 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc23 - (EIF_INTEGER_32) (loc2 - loc3));
								tb2 = *(EIF_BOOLEAN *)(RTCW(loc78)+ _CHROFF_113_19_);
								if (tb2) {
									loc19 = (EIF_INTEGER_32) loc68;
								} else {
									loc19 = F1334_13421(RTCW(loc7));
								}
							} else {
							}
						}
						if (loc69) {
							loc47 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_10_);
							loc34 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc47 != NULL);
							loc35 = F1334_13430(RTCW(loc7));
							if ((EIF_BOOLEAN) (loc34 || loc35)) {
								loc36 = F857_6599(Current, loc7);
								if ((EIF_BOOLEAN)(loc47 != NULL)) {
									loc37 = F857_6599(Current, loc47);
									loc72 = (EIF_REFERENCE) loc47;
									for (;;) {
										if ((EIF_BOOLEAN)(loc72 == NULL)) break;
										ti4_1 = F1334_13438(RTCW(loc72));
										ti4_1 = eif_max_int32 (loc37,ti4_1);
										loc37 = (EIF_INTEGER_32) ti4_1;
										tr1 = *(EIF_REFERENCE *)(RTCW(loc72) + _REFACS_10_);
										loc72 = (EIF_REFERENCE) tr1;
									}
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc47)+ _LNGOFF_11_7_0_3_);
									loc38 = F1390_14485(RTCW(loc78), loc37, ti4_1);
									loc38 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc38 + (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc45 + ((EIF_INTEGER_32) 1L)) / ((EIF_INTEGER_32) 2L)));
									loc39 = (EIF_INTEGER_32) loc38;
									ti4_1 = eif_max_int32 (loc36,loc37);
									loc36 = (EIF_INTEGER_32) ti4_1;
								}
							} else {
								loc36 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							}
							loc49 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc19 / ((EIF_INTEGER_32) 2L));
							loc50 = (EIF_INTEGER_32) loc19;
							loc51 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc19 - loc46) + ((EIF_INTEGER_32) 1L)) / ((EIF_INTEGER_32) 2L));
							loc52 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc51 + loc46);
							loc30 = F857_6598(Current, loc7);
						}
						F671_5478(RTCW(loc31));
						loc24 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						loc71 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						for (;;) {
							tb2 = F598_5028(RTCW(loc31));
							if (tb2) break;
							loc14 = F671_5452(RTCW(loc31));
							tr1 = *(EIF_REFERENCE *)(RTCW(loc78) + _REFACS_86_);
							loc66 = F664_5454(RTCW(tr1), loc14);
							if ((EIF_BOOLEAN)(loc66 == NULL)) {
								RTCT0("current_column /= Void", EX_CHECK);
								if ((EIF_BOOLEAN)(loc66 != NULL)) {
									RTCK0;
								} else {
									RTCF0;
								}
							}
							loc18 = F671_5454(RTCW(loc16), (EIF_INTEGER_32) (loc14 + ((EIF_INTEGER_32) 1L)));
							ti4_1 = F671_5454(RTCW(loc16), loc14);
							loc18 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc18 - ti4_1);
							if ((EIF_BOOLEAN) (loc18 > ((EIF_INTEGER_32) 0L))) {
								ti4_1 = F671_5452(RTCW(loc31));
								/* INLINED CODE (SPECIAL.item) */
								ti4_3 = *((EIF_INTEGER_32 *)RTCW(loc8) + ((EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L))));
								/* END INLINED CODE */
								loc62 = ti4_3;
								loc22 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								tb3 = '\0';
								if ((EIF_BOOLEAN)(loc6 != NULL)) {
									ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc6);
									tb3 = (EIF_BOOLEAN) (loc62 < ti4_1);
								}
								if (tb3) {
									/* INLINED CODE (SPECIAL.item) */
									tr1 = *((EIF_REFERENCE *)RTCW(loc6) + (loc62));
									/* END INLINED CODE */
									loc12 = tr1;
									if ((EIF_BOOLEAN)(loc12 != NULL)) {
										loc22 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									}
								}
								loc24 = F671_5454(RTCW(loc16), loc14);
								loc24 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc24 - (EIF_INTEGER_32) (loc1 - loc4));
								if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc70 && (EIF_BOOLEAN) !loc22) && (EIF_BOOLEAN)(loc27 != NULL))) {
									{
										static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,1033,1033,0xFFFF};
										EIF_TYPE typres0;
										static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
										
										typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
										tr1 = RTLNTS(typres0.id, 3, 1);
									}
									((EIF_TYPED_VALUE *)tr1+1)->it_i4 = loc14;
									((EIF_TYPED_VALUE *)tr1+2)->it_i4 = loc15;
									loc13 = F1073_9384(RTCW(loc27), tr1);
									if ((EIF_BOOLEAN)(loc13 != NULL)) {
										loc12 = *(EIF_REFERENCE *)(RTCW(loc13) + _REFACS_1_);
										ti4_1 = F671_5452(RTCW(loc31));
										ti4_2 = F671_5452(RTCW(loc32));
										tr1 = F1390_14259(RTCW(loc78), ti4_1, ti4_2);
										if ((EIF_BOOLEAN)(tr1 == NULL)) {
											ti4_1 = F671_5452(RTCW(loc31));
											ti4_2 = F671_5452(RTCW(loc32));
											tr1 = *(EIF_REFERENCE *)(RTCW(loc12) + _REFACS_14_);
											F1390_14449(RTCW(loc78), ti4_1, ti4_2, tr1);
										}
										loc22 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									}
									if (loc69) {
										loc47 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_10_);
										loc34 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc47 != NULL);
										loc35 = F1334_13430(RTCW(loc7));
										if ((EIF_BOOLEAN) (loc34 || loc35)) {
											loc36 = F857_6599(Current, loc7);
											if ((EIF_BOOLEAN)(loc47 != NULL)) {
												loc37 = F857_6599(Current, loc47);
												loc72 = (EIF_REFERENCE) loc47;
												for (;;) {
													if ((EIF_BOOLEAN)(loc72 == NULL)) break;
													ti4_1 = F1334_13438(RTCW(loc72));
													ti4_1 = eif_max_int32 (loc37,ti4_1);
													loc37 = (EIF_INTEGER_32) ti4_1;
													tr1 = *(EIF_REFERENCE *)(RTCW(loc72) + _REFACS_10_);
													loc72 = (EIF_REFERENCE) tr1;
												}
												ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc47)+ _LNGOFF_11_7_0_3_);
												loc38 = F1390_14485(RTCW(loc78), loc37, ti4_1);
												loc38 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc38 + (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc45 + ((EIF_INTEGER_32) 1L)) / ((EIF_INTEGER_32) 2L)));
												loc39 = (EIF_INTEGER_32) loc38;
												ti4_1 = eif_max_int32 (loc36,loc37);
												loc36 = (EIF_INTEGER_32) ti4_1;
											}
										} else {
											loc36 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
										}
										loc49 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc19 / ((EIF_INTEGER_32) 2L));
										loc50 = (EIF_INTEGER_32) loc19;
										loc51 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc19 - loc46) + ((EIF_INTEGER_32) 1L)) / ((EIF_INTEGER_32) 2L));
										loc52 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc51 + loc46);
										loc30 = F857_6598(Current, loc7);
									}
									loc6 = F664_5454(RTCW(loc65), loc15);
								}
								tb3 = '\01';
								ti4_1 = F1106_10142(RTCV(RTOSCF(6606,F857_6606, (Current))));
								if (!(EIF_BOOLEAN) (ti4_1 < loc18)) {
									ti4_1 = F1106_10143(RTCV(RTOSCF(6606,F857_6606, (Current))));
									tb3 = (EIF_BOOLEAN) (ti4_1 < loc19);
								}
								if (tb3) {
									tr1 = RTOSCF(6606,F857_6606, (Current));
									F1279_12312(RTCW(tr1), loc18, loc19);
								}
								if (loc35) {
									loc53 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc30 - (EIF_INTEGER_32) (loc40 * ((EIF_INTEGER_32) 2L))) - loc45);
								} else {
									if (loc34) {
										loc53 = (EIF_INTEGER_32) loc30;
									} else {
										loc53 = (EIF_INTEGER_32) loc18;
									}
								}
								loc54 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc30 - (EIF_INTEGER_32) (loc40 * ((EIF_INTEGER_32) 2L))) - (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc45 + ((EIF_INTEGER_32) 1L)) / ((EIF_INTEGER_32) 2L)));
								loc25 = (EIF_INTEGER_32) loc24;
								loc26 = (EIF_INTEGER_32) loc18;
								if ((EIF_BOOLEAN) (loc22 && (EIF_BOOLEAN)(loc12 != NULL))) {
									tr1 = RTOSCF(6606,F857_6606, (Current));
									tr2 = F1348_13666(RTCW(loc12));
									F1104_10125(RTCW(tr1), tr2);
								} else {
									tr1 = RTOSCF(6606,F857_6606, (Current));
									tr2 = F1390_14432(RTCW(loc78), loc14, loc15);
									F1104_10125(RTCW(tr1), tr2);
								}
								tr1 = RTOSCF(6606,F857_6606, (Current));
								F1116_10237(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc18, loc19);
								tr1 = *(EIF_REFERENCE *)(RTCW(loc78) + _REFACS_45_);
								if ((EIF_BOOLEAN)(tr1 != NULL)) {
									if ((EIF_BOOLEAN) (loc22 && (EIF_BOOLEAN)(loc12 != NULL))) {
										tr1 = F858_6629(RTCW(loc78));
										{
											static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,997,1278,1128,1033,1033,0xFFFF};
											EIF_TYPE typres0;
											static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
											
											typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
											tr2 = RTLNTS(typres0.id, 5, 0);
										}
										tr3 = RTOSCF(6606,F857_6606, (Current));
										((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
										RTAR(tr2,tr3);
										tr3 = *(EIF_REFERENCE *)(RTCW(loc12) + _REFACS_14_);
										((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
										RTAR(tr2,tr3);
										((EIF_TYPED_VALUE *)tr2+3)->it_i4 = loc14;
										((EIF_TYPED_VALUE *)tr2+4)->it_i4 = loc15;
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4892[Dtype(RTCW(tr1))-687])(tr1, tr2);
									} else {
										tr1 = F858_6629(RTCW(loc78));
										{
											static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,997,1278,65534,1033,1033,0xFFFF};
											EIF_TYPE typres0;
											static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
											
											typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
											tr2 = RTLNTS(typres0.id, 5, 0);
										}
										tr3 = RTOSCF(6606,F857_6606, (Current));
										((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
										RTAR(tr2,tr3);
										((EIF_TYPED_VALUE *)tr2+3)->it_i4 = loc14;
										((EIF_TYPED_VALUE *)tr2+4)->it_i4 = loc15;
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4892[Dtype(RTCW(tr1))-687])(tr1, tr2);
									}
								}
								if (loc69) {
									if ((EIF_BOOLEAN)(loc14 == loc36)) {
										loc25 += loc30;
										loc26 -= loc30;
										tb3 = F1334_13430(RTCW(loc7));
										if (tb3) {
											tb3 = *(EIF_BOOLEAN *)(RTCW(loc7)+ _CHROFF_11_1_);
											if (tb3) {
												loc48 = (EIF_REFERENCE) loc42;
											} else {
												loc48 = (EIF_REFERENCE) loc43;
											}
											if ((EIF_BOOLEAN) (loc53 < loc18)) {
												if ((EIF_BOOLEAN) (loc46 > loc19)) {
													tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
													F861_6729(RTCW(tr1), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc46 - loc19) / ((EIF_INTEGER_32) 2L)), loc46, loc19);
													tr1 = RTOSCF(6606,F857_6606, (Current));
													F1116_10230(RTCW(tr1), loc53, ((EIF_INTEGER_32) 0L), loc48, *(EIF_REFERENCE *)(Current + _REFACS_1_));
												} else {
													tr1 = RTOSCF(6606,F857_6606, (Current));
													F1116_10229(RTCW(tr1), loc53, loc51, loc48);
												}
											}
										}
										if (loc61) {
											if ((EIF_BOOLEAN) (loc35 || loc34)) {
												loc55 = (EIF_INTEGER_32) loc30;
												tb3 = F1334_13430(RTCW(loc7));
												if (tb3) {
													loc56 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc53 + loc45);
												} else {
													if ((EIF_BOOLEAN)(loc37 == loc36)) {
														loc56 = (EIF_INTEGER_32) loc54;
													} else {
														loc56 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
													}
												}
												tr1 = RTOSCF(6606,F857_6606, (Current));
												F1104_10125(RTCW(tr1), loc64);
												if ((EIF_BOOLEAN) (loc55 < loc18)) {
													tr1 = RTOSCF(6606,F857_6606, (Current));
													F1116_10227(RTCW(tr1), loc55, loc49, loc56, loc49);
													tb3 = '\0';
													if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc37 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(loc37 != loc36))) {
														tb4 = F1334_13430(RTCW(loc7));
														tb3 = tb4;
													}
													if (tb3) {
														tr1 = RTOSCF(6606,F857_6606, (Current));
														F1116_10227(RTCW(tr1), ((EIF_INTEGER_32) 0L), loc49, loc53, loc49);
													}
												} else {
													ti4_1 = eif_min_int32 (loc56,(EIF_INTEGER_32) (loc24 + loc18));
													if ((EIF_BOOLEAN)(ti4_1 != (EIF_INTEGER_32) (loc24 + loc18))) {
														tr1 = RTOSCF(6606,F857_6606, (Current));
														ti4_1 = eif_min_int32 (loc56,loc18);
														F1116_10227(RTCW(tr1), ti4_1, loc49, loc18, loc49);
													}
												}
											}
											if ((EIF_BOOLEAN) (loc34 && (EIF_BOOLEAN)(loc37 == loc14))) {
												loc57 = (EIF_INTEGER_32) loc54;
												if (loc61) {
													tr1 = RTOSCF(6606,F857_6606, (Current));
													F1104_10125(RTCW(tr1), loc64);
													ti4_1 = F671_5454(RTCW(loc16), (EIF_INTEGER_32) (loc36 + ((EIF_INTEGER_32) 1L)));
													if ((EIF_BOOLEAN) (loc57 < ti4_1)) {
														tb3 = '\0';
														if ((EIF_BOOLEAN)(loc47 != NULL)) {
															ti4_1 = F1334_13433(RTCW(loc47));
															tr1 = F1334_13413(RTCW(loc47), ti4_1);
															tr2 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_4_);
															tb3 = (EIF_BOOLEAN)(tr1 == tr2);
														}
														if (tb3) {
															tb3 = F1334_13430(RTCW(loc7));
															if (tb3) {
																tr1 = RTOSCF(6606,F857_6606, (Current));
																F1116_10227(RTCW(tr1), loc54, (EIF_INTEGER_32) (loc51 - ((EIF_INTEGER_32) 1L)), loc54, ((EIF_INTEGER_32) 0L));
															} else {
																tr1 = RTOSCF(6606,F857_6606, (Current));
																F1116_10227(RTCW(tr1), loc54, loc49, loc54, ((EIF_INTEGER_32) 0L));
															}
														} else {
															tb3 = F1334_13430(RTCW(loc7));
															if (tb3) {
																tr1 = RTOSCF(6606,F857_6606, (Current));
																F1116_10227(RTCW(tr1), loc54, (EIF_INTEGER_32) (loc51 - ((EIF_INTEGER_32) 1L)), loc54, ((EIF_INTEGER_32) 0L));
																tr1 = RTOSCF(6606,F857_6606, (Current));
																F1116_10227(RTCW(tr1), loc54, loc52, loc54, loc50);
															} else {
																tr1 = RTOSCF(6606,F857_6606, (Current));
																F1116_10227(RTCW(tr1), loc54, ((EIF_INTEGER_32) 0L), loc54, loc50);
															}
														}
													}
													RTCT0("parent_row_i /= Void", EX_CHECK);
													if ((EIF_BOOLEAN)(loc47 != NULL)) {
														RTCK0;
													} else {
														RTCF0;
													}
													loc58 = (EIF_REFERENCE) loc47;
													loc59 = *(EIF_REFERENCE *)(RTCW(loc47) + _REFACS_10_);
													for (;;) {
														if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc57 < loc24) || (EIF_BOOLEAN)(loc59 == NULL))) break;
														loc57 -= loc33;
														if ((EIF_BOOLEAN) (loc57 < (EIF_INTEGER_32) (loc24 + loc18))) {
															loc77 = F1280_12327(RTCW(loc59));
															loc76 = F1127_10384(RTCW(loc77));
															if ((EIF_BOOLEAN) (loc76 > ((EIF_INTEGER_32) 0L))) {
																loc60 = F1127_10367(RTCW(loc77), loc76);
																tb3 = F1127_10383(RTCW(loc60));
																if ((EIF_BOOLEAN) !tb3) {
																	for (;;) {
																		tb3 = F1127_10383(RTCW(loc60));
																		if (tb3) break;
																		loc76--;
																		loc60 = F1127_10367(RTCW(loc77), loc76);
																	}
																}
																ti4_1 = F1127_10386(RTCW(loc60));
																ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc58)+ _LNGOFF_11_7_0_3_);
																if ((EIF_BOOLEAN) (ti4_1 > ti4_2)) {
																	tr1 = RTOSCF(6606,F857_6606, (Current));
																	F1116_10227(RTCW(tr1), loc57, loc50, loc57, ((EIF_INTEGER_32) 0L));
																}
															}
														}
														loc58 = (EIF_REFERENCE) loc59;
														tr1 = *(EIF_REFERENCE *)(RTCW(loc59) + _REFACS_10_);
														loc59 = (EIF_REFERENCE) tr1;
													}
												}
											}
										}
									} else {
										if ((EIF_BOOLEAN) (loc34 && (EIF_BOOLEAN) (loc14 < loc36))) {
											RTCT0("parent_row_i /= Void", EX_CHECK);
											if ((EIF_BOOLEAN)(loc47 != NULL)) {
												RTCK0;
											} else {
												RTCF0;
											}
											loc59 = *(EIF_REFERENCE *)(RTCW(loc47) + _REFACS_10_);
											tr1 = RTOSCF(6606,F857_6606, (Current));
											F1104_10125(RTCW(tr1), loc64);
											for (;;) {
												if ((EIF_BOOLEAN)(loc59 == NULL)) break;
												loc77 = F1280_12327(RTCW(loc59));
												loc76 = F1127_10384(RTCW(loc77));
												tb4 = '\0';
												if ((EIF_BOOLEAN) (loc76 > ((EIF_INTEGER_32) 0L))) {
													ti4_1 = F1127_10378(RTCW(loc77));
													tb4 = (EIF_BOOLEAN)(ti4_1 == loc14);
												}
												if (tb4) {
													loc60 = F1127_10367(RTCW(loc77), loc76);
													tb4 = F1127_10383(RTCW(loc60));
													if ((EIF_BOOLEAN) !tb4) {
														for (;;) {
															tb4 = F1127_10383(RTCW(loc60));
															if (tb4) break;
															loc76--;
															loc60 = F1127_10367(RTCW(loc77), loc76);
														}
													}
													ti4_1 = F1127_10386(RTCW(loc60));
													ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_11_7_0_3_);
													if ((EIF_BOOLEAN) (ti4_1 > ti4_2)) {
														loc55 = F857_6598(Current, loc59);
														loc55 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc55 + (EIF_INTEGER_32) (loc45 / ((EIF_INTEGER_32) 2L)));
														tr1 = RTOSCF(6606,F857_6606, (Current));
														F1116_10227(RTCW(tr1), loc55, loc50, loc55, ((EIF_INTEGER_32) 0L));
													}
												}
												tr1 = *(EIF_REFERENCE *)(RTCW(loc59) + _REFACS_10_);
												loc59 = (EIF_REFERENCE) tr1;
											}
										}
									}
								}
								if ((EIF_BOOLEAN) (loc22 && (EIF_BOOLEAN)(loc12 != NULL))) {
									if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc25 - loc24) < loc18)) {
										if ((EIF_BOOLEAN)(loc14 == loc36)) {
											tr1 = RTOSCF(6606,F857_6606, (Current));
											(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE)) R11077[Dtype(RTCW(loc12))-1347])(loc12, loc25, loc23, loc26, loc19, loc30, tr1);
										} else {
											tr1 = RTOSCF(6606,F857_6606, (Current));
											(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE)) R11077[Dtype(RTCW(loc12))-1347])(loc12, loc25, loc23, loc26, loc19, ((EIF_INTEGER_32) 0L), tr1);
										}
									}
									loc71 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									loc63 = *(EIF_INTEGER_32 *)(RTCW(loc78)+ _LNGOFF_113_55_10_7_);
									loc63 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc39 + loc63) - ((EIF_INTEGER_32) 1L));
									if ((EIF_BOOLEAN) (loc37 < loc14)) {
										loc63 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
									}
									tr1 = RTOSCF(6606,F857_6606, (Current));
									F1104_10125(RTCW(tr1), loc64);
									tb5 = '\0';
									if (loc34) {
										ti4_1 = F1334_13438(RTCW(loc7));
										tb5 = (EIF_BOOLEAN)(loc14 == ti4_1);
									}
									if (tb5) {
										loc56 = (EIF_INTEGER_32) loc18;
										if ((EIF_BOOLEAN)(loc37 != loc14)) {
											loc55 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
										}
										tr1 = RTOSCF(6606,F857_6606, (Current));
										F1116_10227(RTCW(tr1), loc55, loc49, loc56, loc49);
									}
									if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc61 && (EIF_BOOLEAN) (loc34 || loc35)) && (EIF_BOOLEAN)(loc14 != loc36)) && (EIF_BOOLEAN) (loc14 >= loc37))) {
										if ((EIF_BOOLEAN) (loc14 < loc36)) {
											tr1 = RTOSCF(6606,F857_6606, (Current));
											ti4_1 = eif_min_int32 (loc63,loc18);
											F1116_10227(RTCW(tr1), ti4_1, loc49, loc18, loc49);
										}
										if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc34 && (EIF_BOOLEAN)(loc37 == loc14)) && (EIF_BOOLEAN) (loc63 < loc18))) {
											RTCT0("parent_row_i /= Void", EX_CHECK);
											if ((EIF_BOOLEAN)(loc47 != NULL)) {
												RTCK0;
											} else {
												RTCF0;
											}
											tr1 = *(EIF_REFERENCE *)(RTCW(loc47) + _REFACS_8_);
											ti4_1 = F1334_13433(RTCW(loc47));
											tr1 = F664_5453(RTCW(tr1), ti4_1);
											if ((EIF_BOOLEAN)(loc7 == tr1)) {
												tr1 = RTOSCF(6606,F857_6606, (Current));
												F1116_10227(RTCW(tr1), loc63, loc49, loc63, ((EIF_INTEGER_32) 0L));
											} else {
												tr1 = RTOSCF(6606,F857_6606, (Current));
												F1116_10227(RTCW(tr1), loc63, loc50, loc63, ((EIF_INTEGER_32) 0L));
											}
										}
									}
								}
								F857_6600(Current, loc66, loc7, loc12, loc24, loc23, loc18, loc19);
								tr1 = *(EIF_REFERENCE *)(RTCW(loc78) + _REFACS_46_);
								if ((EIF_BOOLEAN)(tr1 != NULL)) {
									if ((EIF_BOOLEAN) (loc22 && (EIF_BOOLEAN)(loc12 != NULL))) {
										tr1 = F858_6630(RTCW(loc78));
										{
											static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,997,1278,1128,1033,1033,0xFFFF};
											EIF_TYPE typres0;
											static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
											
											typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
											tr2 = RTLNTS(typres0.id, 5, 0);
										}
										tr3 = RTOSCF(6606,F857_6606, (Current));
										((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
										RTAR(tr2,tr3);
										tr3 = *(EIF_REFERENCE *)(RTCW(loc12) + _REFACS_14_);
										((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
										RTAR(tr2,tr3);
										((EIF_TYPED_VALUE *)tr2+3)->it_i4 = loc14;
										((EIF_TYPED_VALUE *)tr2+4)->it_i4 = loc15;
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4892[Dtype(RTCW(tr1))-687])(tr1, tr2);
									} else {
										tr1 = F858_6630(RTCW(loc78));
										{
											static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,997,1278,65534,1033,1033,0xFFFF};
											EIF_TYPE typres0;
											static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
											
											typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
											tr2 = RTLNTS(typres0.id, 5, 0);
										}
										tr3 = RTOSCF(6606,F857_6606, (Current));
										((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
										RTAR(tr2,tr3);
										((EIF_TYPED_VALUE *)tr2+3)->it_i4 = loc14;
										((EIF_TYPED_VALUE *)tr2+4)->it_i4 = loc15;
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4892[Dtype(RTCW(tr1))-687])(tr1, tr2);
									}
								}
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								F861_6729(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc18, loc19);
								if ((EIF_BOOLEAN)(arg7 == NULL)) {
									tb5 = '\01';
									tb6 = *(EIF_BOOLEAN *)(RTCW(loc66)+ _CHROFF_9_1_);
									if (!tb6) {
										tb6 = *(EIF_BOOLEAN *)(RTCW(loc7)+ _CHROFF_11_3_);
										tb5 = tb6;
									}
									if (tb5) {
										tr1 = RTOSCF(6603,F857_6603, (Current));
										F1104_10125(RTCW(arg5), tr1);
										F1116_10237(RTCW(arg5), loc24, loc23, loc18, loc19);
									} else {
										tr1 = RTOSCF(6606,F857_6606, (Current));
										tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F1116_10230(RTCW(arg5), loc24, loc23, tr1, tr2);
									}
								} else {
									if ((EIF_BOOLEAN)(loc74 != NULL)) {
										tb5 = '\0';
										tb6 = '\0';
										tr1 = F1390_14616(RTCW(loc78), loc15);
										tb7 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_11_3_);
										if (tb7) {
											tr1 = F1390_14616(RTCW(loc78), loc15);
											tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
											loc79 = tr1;
											tb6 = EIF_TEST(loc79);
										}
										if (tb6) {
											ti4_1 = *(EIF_INTEGER_32 *)(loc79+ _LNGOFF_7_0_0_1_);
											ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc74)+ _LNGOFF_7_0_0_1_);
											tb5 = (EIF_BOOLEAN) (ti4_1 > ti4_2);
										}
										if (tb5) {
											tr1 = *(EIF_REFERENCE *)(RTCW(loc66) + _REFACS_3_);
											loc80 = tr1;
											if (EIF_TEST(loc80)) {
												F1104_10125(RTCW(arg5), loc80);
											} else {
												tr1 = RTOSCF(6603,F857_6603, (Current));
												F1104_10125(RTCW(arg5), tr1);
											}
											F1116_10237(RTCW(arg5), ((EIF_INTEGER_32) 0L), loc23, loc18, loc19);
										} else {
											tr1 = RTOSCF(6606,F857_6606, (Current));
											tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F1116_10230(RTCW(arg5), ((EIF_INTEGER_32) 0L), loc23, tr1, tr2);
										}
									} else {
										if ((EIF_BOOLEAN)(loc75 != NULL)) {
											tb5 = '\0';
											tb6 = '\0';
											tr1 = F1390_14617(RTCW(loc78), loc14);
											tb7 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_9_1_);
											if (tb7) {
												tr1 = F1390_14617(RTCW(loc78), loc14);
												tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_6_);
												loc81 = tr1;
												tb6 = EIF_TEST(loc81);
											}
											if (tb6) {
												ti4_1 = *(EIF_INTEGER_32 *)(loc81+ _LNGOFF_7_0_0_1_);
												ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc75)+ _LNGOFF_7_0_0_1_);
												tb5 = (EIF_BOOLEAN) (ti4_1 > ti4_2);
											}
											if (tb5) {
												tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_6_);
												loc82 = tr1;
												if (EIF_TEST(loc82)) {
													F1104_10125(RTCW(arg5), loc82);
												} else {
													tr1 = RTOSCF(6603,F857_6603, (Current));
													F1104_10125(RTCW(arg5), tr1);
												}
												F1116_10237(RTCW(arg5), loc24, ((EIF_INTEGER_32) 0L), loc18, loc19);
											} else {
												tr1 = RTOSCF(6606,F857_6606, (Current));
												tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
												F1116_10230(RTCW(arg5), loc24, ((EIF_INTEGER_32) 0L), tr1, tr2);
											}
										} else {
										}
									}
								}
							}
							F671_5480(RTCW(loc31));
						}
						F671_5480(RTCW(loc32));
					}
				}
				ti4_1 = F671_5468(RTCW(loc16));
				loc20 = F671_5454(RTCW(loc16), ti4_1);
				loc20 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc28 - (EIF_INTEGER_32) (loc20 - loc1));
				if ((EIF_BOOLEAN) (loc20 > ((EIF_INTEGER_32) 0L))) {
					tb5 = '\01';
					ti4_1 = F1106_10142(RTCV(RTOSCF(6606,F857_6606, (Current))));
					if (!(EIF_BOOLEAN) (ti4_1 < loc20)) {
						ti4_1 = F1106_10143(RTCV(RTOSCF(6606,F857_6606, (Current))));
						tb5 = (EIF_BOOLEAN) (ti4_1 < loc29);
					}
					if (tb5) {
						tr1 = RTOSCF(6606,F857_6606, (Current));
						F1279_12312(RTCW(tr1), loc20, loc29);
					}
					tb5 = '\0';
					tr1 = *(EIF_REFERENCE *)(RTCW(loc78) + _REFACS_47_);
					if ((EIF_BOOLEAN)(tr1 != NULL)) {
						tr1 = F858_6631(RTCW(loc78));
						tb6 = F483_4817(RTCW(tr1));
						tb5 = (EIF_BOOLEAN) !tb6;
					}
					if (tb5) {
						tr1 = F858_6631(RTCW(loc78));
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFFF9,5,997,1278,1033,1033,1033,1033,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr2 = RTLNTS(typres0.id, 6, 0);
						}
						tr3 = RTOSCF(6606,F857_6606, (Current));
						((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
						RTAR(tr2,tr3);
						ti4_1 = F671_5468(RTCW(loc16));
						ti4_1 = F671_5454(RTCW(loc16), ti4_1);
						((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
						((EIF_TYPED_VALUE *)tr2+3)->it_i4 = loc2;
						((EIF_TYPED_VALUE *)tr2+4)->it_i4 = loc20;
						((EIF_TYPED_VALUE *)tr2+5)->it_i4 = loc29;
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4892[Dtype(RTCW(tr1))-687])(tr1, tr2);
					} else {
						tr1 = RTOSCF(6606,F857_6606, (Current));
						tr2 = F1322_13272(RTCW(loc78));
						F1104_10125(RTCW(tr1), tr2);
						tr1 = RTOSCF(6606,F857_6606, (Current));
						F1116_10237(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc20, loc29);
					}
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F861_6729(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc20, loc29);
					if ((EIF_BOOLEAN)(loc75 == NULL)) {
						tr1 = RTOSCF(6606,F857_6606, (Current));
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F1116_10230(RTCW(arg5), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 + loc28) - loc20), loc3, tr1, tr2);
					} else {
						tr1 = RTOSCF(6606,F857_6606, (Current));
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F1116_10230(RTCW(arg5), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 + loc28) - loc20), ((EIF_INTEGER_32) 0L), tr1, tr2);
					}
				}
				tb5 = '\01';
				if (!(EIF_BOOLEAN)(loc7 == NULL)) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_11_7_0_3_);
					ti4_2 = F1390_14459(RTCW(loc78));
					tb5 = (EIF_BOOLEAN) (ti4_1 >= ti4_2);
				}
				if (tb5) {
					tb5 = F1390_14647(RTCW(loc78));
					if ((EIF_BOOLEAN) !tb5) {
						loc73 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc68 * loc67);
						loc21 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc29 - (EIF_INTEGER_32) (loc73 - loc2));
					} else {
						RTCT0("row_offsets /= Void", EX_CHECK);
						if ((EIF_BOOLEAN)(loc17 != NULL)) {
							RTCK0;
						} else {
							RTCF0;
						}
						loc73 = F671_5454(RTCW(loc17), (EIF_INTEGER_32) (loc67 + ((EIF_INTEGER_32) 1L)));
						loc21 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc29 - (EIF_INTEGER_32) (loc73 - loc2));
					}
					if ((EIF_BOOLEAN) (loc21 > ((EIF_INTEGER_32) 0L))) {
						tb5 = '\01';
						ti4_1 = F1106_10142(RTCV(RTOSCF(6606,F857_6606, (Current))));
						if (!(EIF_BOOLEAN) (ti4_1 < loc28)) {
							ti4_1 = F1106_10143(RTCV(RTOSCF(6606,F857_6606, (Current))));
							tb5 = (EIF_BOOLEAN) (ti4_1 < loc21);
						}
						if (tb5) {
							tr1 = RTOSCF(6606,F857_6606, (Current));
							F1279_12312(RTCW(tr1), loc28, loc21);
						}
						tb5 = '\0';
						tr1 = *(EIF_REFERENCE *)(RTCW(loc78) + _REFACS_47_);
						if ((EIF_BOOLEAN)(tr1 != NULL)) {
							tr1 = F858_6631(RTCW(loc78));
							tb6 = F483_4817(RTCW(tr1));
							tb5 = (EIF_BOOLEAN) !tb6;
						}
						if (tb5) {
							tr1 = F858_6631(RTCW(loc78));
							{
								static EIF_TYPE_INDEX typarr0[] = {0xFFF9,5,997,1278,1033,1033,1033,1033,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								tr2 = RTLNTS(typres0.id, 6, 0);
							}
							tr3 = RTOSCF(6606,F857_6606, (Current));
							((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
							RTAR(tr2,tr3);
							((EIF_TYPED_VALUE *)tr2+2)->it_i4 = loc1;
							((EIF_TYPED_VALUE *)tr2+3)->it_i4 = loc73;
							((EIF_TYPED_VALUE *)tr2+4)->it_i4 = loc28;
							((EIF_TYPED_VALUE *)tr2+5)->it_i4 = loc21;
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4892[Dtype(RTCW(tr1))-687])(tr1, tr2);
						} else {
							tr1 = RTOSCF(6606,F857_6606, (Current));
							tr2 = F1322_13272(RTCW(loc78));
							F1104_10125(RTCW(tr1), tr2);
							tr1 = RTOSCF(6606,F857_6606, (Current));
							F1116_10237(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc28, loc21);
						}
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F861_6729(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc28, loc21);
						if ((EIF_BOOLEAN)(loc74 == NULL)) {
							tr1 = RTOSCF(6606,F857_6606, (Current));
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							F1116_10230(RTCW(arg5), loc4, (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 + loc29) - loc21), tr1, tr2);
						} else {
							tr1 = RTOSCF(6606,F857_6606, (Current));
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							F1116_10230(RTCW(arg5), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 + loc29) - loc21), tr1, tr2);
						}
					}
				}
			} else {
				tb5 = '\0';
				tr1 = *(EIF_REFERENCE *)(RTCW(loc78) + _REFACS_47_);
				if ((EIF_BOOLEAN)(tr1 != NULL)) {
					tr1 = F858_6631(RTCW(loc78));
					tb6 = F483_4817(RTCW(tr1));
					tb5 = (EIF_BOOLEAN) !tb6;
				}
				if (tb5) {
					tb5 = '\01';
					ti4_1 = F1106_10142(RTCV(RTOSCF(6606,F857_6606, (Current))));
					if (!(EIF_BOOLEAN) (ti4_1 < arg3)) {
						ti4_1 = F1106_10143(RTCV(RTOSCF(6606,F857_6606, (Current))));
						tb5 = (EIF_BOOLEAN) (ti4_1 < arg4);
					}
					if (tb5) {
						tr1 = RTOSCF(6606,F857_6606, (Current));
						F1279_12312(RTCW(tr1), arg3, arg4);
					}
					tr1 = F858_6631(RTCW(loc78));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,5,997,1278,1033,1033,1033,1033,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNTS(typres0.id, 6, 0);
					}
					tr3 = RTOSCF(6606,F857_6606, (Current));
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					((EIF_TYPED_VALUE *)tr2+2)->it_i4 = loc1;
					((EIF_TYPED_VALUE *)tr2+3)->it_i4 = loc2;
					((EIF_TYPED_VALUE *)tr2+4)->it_i4 = arg3;
					((EIF_TYPED_VALUE *)tr2+5)->it_i4 = arg4;
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4892[Dtype(RTCW(tr1))-687])(tr1, tr2);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F861_6729(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), arg3, arg4);
					tr1 = RTOSCF(6606,F857_6606, (Current));
					tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F1116_10230(RTCW(arg5), arg1, arg2, tr1, tr2);
				} else {
					tr1 = F1322_13272(RTCW(loc78));
					F1104_10125(RTCW(arg5), tr1);
					F1116_10237(RTCW(arg5), arg1, arg2, arg3, arg4);
				}
			}
			tb5 = '\0';
			tb6 = '\0';
			tb7 = *(EIF_BOOLEAN *)(RTCW(loc78)+ _CHROFF_113_20_);
			if ((EIF_BOOLEAN) !tb7) {
				tb7 = *(EIF_BOOLEAN *)(RTCW(loc78)+ _CHROFF_113_50_);
				tb6 = tb7;
			}
			if (tb6) {
				tb6 = *(EIF_BOOLEAN *)(RTCW(loc78)+ _CHROFF_113_12_);
				tb5 = tb6;
			}
			if (tb5) {
				F1390_14532(RTCW(loc78));
			}
		}
		F1116_10218(RTCW(arg5));
	}
	RTLE;
}

/* {EV_GRID_DRAWER_I}.drawable_item_buffer_pixmap */
static EIF_REFERENCE F857_6597_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6597);
#define Result RTOSR(6597)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1278, 0x00).id, 1278, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6597);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F857_6597 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6597,F857_6597_body,(Current));
}

/* {EV_GRID_DRAWER_I}.subrow_indent */
EIF_INTEGER_32 F857_6598 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = F1334_13438(RTCW(arg1));
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_11_7_0_3_);
	Result = F1390_14485(RTCW(tr1), ti4_1, ti4_2);
	RTLE;
	return Result;
}

/* {EV_GRID_DRAWER_I}.retrieve_node_index */
EIF_INTEGER_32 F857_6599 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	Result = F1334_13438(RTCW(arg1));
	if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
	return Result;
}

/* {EV_GRID_DRAWER_I}.draw_item_border */
void F857_6600 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	loc3 = *(EIF_REFERENCE *)(Current);
	loc1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_91_);
	tr1 = RTOSCF(6606,F857_6606, (Current));
	tr2 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_75_);
	F1104_10125(RTCW(tr1), tr2);
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_113_22_);
	if (tb1) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_9_4_0_0_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
			tr1 = RTOSCF(6606,F857_6606, (Current));
			F1116_10227(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (arg7 - ((EIF_INTEGER_32) 1L)));
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_9_4_0_0_);
		ti4_2 = F1390_14457(RTCW(loc3));
		if ((EIF_BOOLEAN) (ti4_1 < ti4_2)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_87_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_9_4_0_0_);
			ti4_1 = F671_5453(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_87_);
			ti4_2 = F1390_14457(RTCW(loc3));
			ti4_2 = F671_5453(RTCW(tr1), (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
			if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
		tb1 = '\01';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_9_4_0_0_);
		ti4_2 = F1390_14457(RTCW(loc3));
		if (!(EIF_BOOLEAN)(ti4_1 == ti4_2)) {
			tb1 = loc2;
		}
		if (tb1) {
			tr1 = RTOSCF(6606,F857_6606, (Current));
			F1116_10227(RTCW(tr1), (EIF_INTEGER_32) (arg6 - ((EIF_INTEGER_32) 1L)), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (arg6 - ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (arg7 - ((EIF_INTEGER_32) 1L)));
		}
	}
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_113_23_);
	if (tb1) {
		tr1 = RTOSCF(6606,F857_6606, (Current));
		F1116_10227(RTCW(tr1), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (arg7 - ((EIF_INTEGER_32) 1L)), arg6, (EIF_INTEGER_32) (arg7 - ((EIF_INTEGER_32) 1L)));
	}
	RTLE;
}

/* {EV_GRID_DRAWER_I}.gray */
static EIF_REFERENCE F857_6603_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6603);
#define Result RTOSR(6603)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(193, 0x00).id, 193, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = RTOSCF(3390,F194_3390, (RTCW(tr1)));
	RTOSE (6603);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F857_6603 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6603,F857_6603_body,(Current));
}

/* {EV_GRID_DRAWER_I}.item_buffer_pixmap */
static EIF_REFERENCE F857_6606_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6606);
#define Result RTOSR(6606)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1278, 0x00).id, 1278, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F1279_12312(RTCW(Result), ((EIF_INTEGER_32) 100L), ((EIF_INTEGER_32) 16L));
	RTOSE (6606);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F857_6606 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6606,F857_6606_body,(Current));
}

/* {EV_GRID_DRAWER_I}.drawable_x_to_virtual_x */
EIF_INTEGER_32 F857_6608 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_113_55_10_15_);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_113_55_10_17_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result + arg1) - ti4_1);
	RTLE;
	return Result;
}

/* {EV_GRID_DRAWER_I}.drawable_y_to_virtual_y */
EIF_INTEGER_32 F857_6609 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_113_55_10_16_);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_113_55_10_18_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result + arg1) - ti4_1);
	RTLE;
	return Result;
}

void EIF_Minit344 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
