/*
 * Code for class GB_EV_DESELECTABLE_EDITOR_CONSTRUCTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb330.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_EV_DESELECTABLE_EDITOR_CONSTRUCTOR}.ev_type */
EIF_REFERENCE F843_6345 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_6_);
}


/* {GB_EV_DESELECTABLE_EDITOR_CONSTRUCTOR}.attribute_editor */
EIF_REFERENCE F843_6347 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_7_3_0_1_0_0_0_0_);
	F1209_11188(RTCW(Result), *(EIF_REFERENCE *)(Current));
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.initialize_attribute_editor) */
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + O13222[Dtype(Current)-1562]);
	loc1 = F664_5455(RTCW(tr1));
	tr1 = RTLNSMART(eif_new_type(1259, 0).id);
	tr2 = RTOSCF(5841,F689_5841, (Current));
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = RTOSCF(5842,F689_5842, (Current));
	F1112_10176(RTCW(tr1), tr2);
	F1120_10306(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A330_514, (EIF_POINTER) _A330_514, (EIF_POINTER)(F843_6356),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A330_524, (EIF_POINTER) _A330_524, (EIF_POINTER)(F1563_17201),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F843_6348(Current);
	RTLE;
	return Result;
}

/* {GB_EV_DESELECTABLE_EDITOR_CONSTRUCTOR}.update_attribute_editor */
void F843_6348 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = F1162_10712(RTCW(tr1));
	F688_5577(RTCW(tr1));
	tb1 = F1109_10163(RTCV(F1563_17188(Current)));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F1109_10165(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F1110_10167(RTCW(tr1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = F1162_10712(RTCW(tr1));
	F688_5579(RTCW(tr1));
	RTLE;
}

/* {GB_EV_DESELECTABLE_EDITOR_CONSTRUCTOR}.toggle_selected */
void F843_6356 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tb1 = F1109_10163(RTCW(tr1));
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,997,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1109,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A470_45_1, (EIF_POINTER) _A470_45_1, 0, tr1, 0, 1);
		}
		F1563_17199(Current, tr4);
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,997,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1109,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A470_46_1, (EIF_POINTER) _A470_46_1, 0, tr1, 0, 1);
		}
		F1563_17199(Current, tr4);
	}
	RTLE;
}

void EIF_Minit330 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
