/*
 * Code for class GB_EV_BOX_EDITOR_CONSTRUCTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb337.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_EV_BOX_EDITOR_CONSTRUCTOR}.ev_type */
EIF_REFERENCE F850_6475 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_8_);
}


/* {GB_EV_BOX_EDITOR_CONSTRUCTOR}.attribute_editor */
EIF_REFERENCE F850_6477 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_REFERENCE tr7 = NULL;
	EIF_REFERENCE tr8 = NULL;
	EIF_REFERENCE tr9 = NULL;
	EIF_REFERENCE tr10 = NULL;
	EIF_REFERENCE tr11 = NULL;
	EIF_REFERENCE tr12 = NULL;
	EIF_REFERENCE tr13 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(20);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLR(8,tr6);
	RTLR(9,tr7);
	RTLR(10,tr8);
	RTLR(11,tr9);
	RTLR(12,tr10);
	RTLR(13,tr11);
	RTLR(14,tr12);
	RTLR(15,tr13);
	RTLR(16,loc6);
	RTLR(17,loc4);
	RTLR(18,loc5);
	RTLR(19,loc2);
	RTLIU(20);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {663,1259,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F664_5447(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_7_3_0_1_0_0_0_0_);
	F1209_11188(RTCW(Result), *(EIF_REFERENCE *)(Current));
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.initialize_attribute_editor) */
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + O13222[dtype-1562]);
	tb1 = F664_5474(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + O13222[dtype-1562]);
		loc1 = F664_5453(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	}
	tr1 = RTLNSMART(eif_new_type(1259, 0).id);
	tr2 = RTMS_EX_H("Is_homogeneous\?",15,1873129279);
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	F1120_10306(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A337_511, (EIF_POINTER) _A337_511, (EIF_POINTER)(F850_6483),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A337_531, (EIF_POINTER) _A337_531, (EIF_POINTER)(F1563_17201),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6491,F850_6491, (Current));
	tr3 = RTOSCF(5820,F689_5820, (Current));
	tr4 = RTOSCF(5821,F689_5821, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A337_512_2, (EIF_POINTER) _A337_512_2, (EIF_POINTER)(F850_6484),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A337_513_2, (EIF_POINTER) _A337_513_2, (EIF_POINTER)(F850_6485),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6492,F850_6492, (Current));
	tr3 = RTOSCF(5822,F689_5822, (Current));
	tr4 = RTOSCF(5823,F689_5823, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A337_514_2, (EIF_POINTER) _A337_514_2, (EIF_POINTER)(F850_6486),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A337_513_2, (EIF_POINTER) _A337_513_2, (EIF_POINTER)(F850_6485),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tb1 = F483_4817(RTCV(F1563_17188(Current)));
	if ((EIF_BOOLEAN) !tb1) {
		loc6 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_5_2_0_1_0_0_0_0_);
		tr1 = RTMS_EX_H("Is_item_expanded\?",17,1845263679);
		F1113_10182(RTCW(loc6), tr1);
		F1120_10306(RTCW(Result), loc6);
		F1203_11119(RTCW(Result), loc6);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			ti4_1 = F1120_10295(RTCV(F1563_17188(Current)));
			if ((EIF_BOOLEAN) (loc3 > ti4_1)) break;
			tr1 = F1563_17188(Current);
			loc4 = F1120_10291(RTCW(tr1), loc3);
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				loc5 = F1120_10291(RTCW(loc1), loc3);
			}
			loc2 = RTLNS(eif_new_type(1259, 0x00).id, 1259, _OBJSIZ_6_2_0_1_0_0_0_0_);
			tr1 = F272_4282(Current, loc4);
			F1113_10182(RTCW(loc2), tr1);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,1193,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 3, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			((EIF_TYPED_VALUE *)tr1+2)->it_r = loc4;
			RTAR(tr1,loc4);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1072,0xFFF9,0,997,0,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2= RTLNRF(typres0.id, (EIF_POINTER) __A337_496, (EIF_POINTER) _A337_496, (EIF_POINTER)(F838_6260),tr1, 1, 0);
			}
			F1166_10748(RTCW(loc2), tr2);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			F664_5487(RTCW(tr1), loc2);
			tr1 = F1162_10712(RTCW(loc2));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,997,0,1259,1033,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr2 = RTLNTS(typres0.id, 4, 0);
			}
			((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
			RTAR(tr2,Current);
			((EIF_TYPED_VALUE *)tr2+2)->it_r = loc2;
			RTAR(tr2,loc2);
			((EIF_TYPED_VALUE *)tr2+3)->it_i4 = loc3;
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3= RTLNRF(typres0.id, (EIF_POINTER) __A337_508, (EIF_POINTER) _A337_508, (EIF_POINTER)(F850_6480),tr2, 1, 0);
			}
			F681_5535(RTCW(tr1), tr3);
			tr1 = F1162_10712(RTCW(loc2));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
			RTAR(tr2,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3= RTLNRF(typres0.id, (EIF_POINTER) __A337_531, (EIF_POINTER) _A337_531, (EIF_POINTER)(F1563_17201),tr2, 1, 0);
			}
			F681_5535(RTCW(tr1), tr3);
			F1120_10306(RTCW(Result), loc2);
			F1203_11119(RTCW(Result), loc2);
			loc3++;
		}
	}
	F850_6478(Current);
	F1563_17197(Current, Result);
	F1563_17196(Current, Result);
	RTLE;
	return Result;
}

/* {GB_EV_BOX_EDITOR_CONSTRUCTOR}.update_attribute_editor */
void F850_6478 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F1162_10712(RTCW(tr1));
	F688_5577(RTCW(tr1));
	tb1 = F1203_11108(RTCV(F1563_17188(Current)));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1109_10165(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1110_10167(RTCW(tr1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	ti4_1 = F1203_11109(RTCV(F1563_17188(Current)));
	tr2 = eif_out__i4_s1(ti4_1);
	{
		/* INLINED CODE (GB_INTEGER_INPUT_FIELD.update_constant_display) */
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	ti4_1 = F1203_11110(RTCV(F1563_17188(Current)));
	tr2 = eif_out__i4_s1(ti4_1);
	{
		/* INLINED CODE (GB_INTEGER_INPUT_FIELD.update_constant_display) */
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F664_5478(RTCW(tr1));
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tb1 = F591_5028(RTCW(tr1));
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F664_5452(RTCW(tr1));
		tr1 = F1162_10712(RTCW(tr1));
		F688_5577(RTCW(tr1));
		tr1 = F1563_17188(Current);
		tr2 = F1563_17188(Current);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3) + O4870[Dtype(tr3)-663]);
		tr2 = F591_5018(RTCW(tr2), ti4_1);
		tb2 = F1203_11112(RTCW(tr1), tr2);
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F664_5452(RTCW(tr1));
			F1109_10165(RTCW(tr1));
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F664_5452(RTCW(tr1));
			F1110_10167(RTCW(tr1));
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F664_5452(RTCW(tr1));
		tr1 = F1162_10712(RTCW(tr1));
		F688_5579(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		F664_5480(RTCW(tr1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F1162_10712(RTCW(tr1));
	F688_5579(RTCW(tr1));
	RTLE;
}

/* {GB_EV_BOX_EDITOR_CONSTRUCTOR}.update_widget_expanded */
void F850_6480 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb1 = F1109_10163(RTCW(arg1));
	F850_6481(Current, tr1, tb1, arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,997,0,1027,1033,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 4, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	tb1 = F1109_10163(RTCW(arg1));
	((EIF_TYPED_VALUE *)tr2+2)->it_b = tb1;
	((EIF_TYPED_VALUE *)tr2+3)->it_i4 = arg2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,33,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A337_509_2, (EIF_POINTER) _A337_509_2, (EIF_POINTER)(F850_6481),tr2, 1, 1);
	}
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.for_all_instance_referers) */
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.enable_project_modified) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_BOX_EDITOR_CONSTRUCTOR}.actual_update_widget_expanded */
void F850_6481 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	loc1 = RTRV(eif_new_type(1202, 0x00), loc1);
	if (arg2) {
		tr1 = F1120_10291(RTCW(loc1), arg3);
		F1203_11118(RTCW(loc1), tr1);
	} else {
		tr1 = F1120_10291(RTCW(loc1), arg3);
		F1203_11119(RTCW(loc1), tr1);
	}
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc1 = RTRV(eif_new_type(1202, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		if (arg2) {
			tr1 = F1120_10291(RTCW(loc1), arg3);
			F1203_11118(RTCW(loc1), tr1);
		} else {
			tr1 = F1120_10291(RTCW(loc1), arg3);
			F1203_11119(RTCW(loc1), tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
		tr1 = F664_5453(RTCW(tr1), arg3);
		F850_6482(Current, tr1, arg2);
	}
	RTLE;
}

/* {GB_EV_BOX_EDITOR_CONSTRUCTOR}.update_object_expansion */
void F850_6482 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	if (arg2) {
		{
			/* INLINED CODE (GB_OBJECT.enable_expanded_in_box) */
			(void) RTCW(arg1);
			/* END INLINED CODE */
		}
		;
	} else {
		{
			/* INLINED CODE (GB_OBJECT.disable_expanded_in_box) */
			(void) RTCW(arg1);
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {GB_EV_BOX_EDITOR_CONSTRUCTOR}.update_homogeneous */
void F850_6483 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tb1 = F1109_10163(RTCW(tr1));
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,997,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1202,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A561_310_1, (EIF_POINTER) _A561_310_1, 0, tr1, 0, 1);
		}
		F1563_17199(Current, tr4);
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,997,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1202,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A561_311_1, (EIF_POINTER) _A561_311_1, 0, tr1, 0, 1);
		}
		F1563_17199(Current, tr4);
	}
	RTLE;
}

/* {GB_EV_BOX_EDITOR_CONSTRUCTOR}.set_padding */
void F850_6484 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1202,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A561_313_1, (EIF_POINTER) _A561_313_1, 0, tr1, 0, 1);
	}
	F1563_17199(Current, tr4);
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_BOX_EDITOR_CONSTRUCTOR}.valid_input */
EIF_BOOLEAN F850_6485 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 0L));
}

/* {GB_EV_BOX_EDITOR_CONSTRUCTOR}.set_border */
void F850_6486 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1202,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A561_312_1, (EIF_POINTER) _A561_312_1, 0, tr1, 0, 1);
	}
	F1563_17199(Current, tr4);
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_BOX_EDITOR_CONSTRUCTOR}.padding_string */

EIF_REFERENCE F850_6491 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6491,RTMS_EX_H("Padding",7,1339310951));
}

/* {GB_EV_BOX_EDITOR_CONSTRUCTOR}.border_string */

EIF_REFERENCE F850_6492 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6492,RTMS_EX_H("Border",6,2049795954));
}

void EIF_Minit337 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
