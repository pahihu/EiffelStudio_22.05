/*
 * Code for class GB_EV_TABLE_EDITOR_CONSTRUCTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb341.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.ev_type */
EIF_REFERENCE F854_6519 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_12_);
}


/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.attribute_editor */
EIF_REFERENCE F854_6521 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_REFERENCE tr7 = NULL;
	EIF_REFERENCE tr8 = NULL;
	EIF_REFERENCE tr9 = NULL;
	EIF_REFERENCE tr10 = NULL;
	EIF_REFERENCE tr11 = NULL;
	EIF_REFERENCE tr12 = NULL;
	EIF_REFERENCE tr13 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(17);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLR(7,tr6);
	RTLR(8,tr7);
	RTLR(9,tr8);
	RTLR(10,tr9);
	RTLR(11,tr10);
	RTLR(12,tr11);
	RTLR(13,tr12);
	RTLR(14,tr13);
	RTLR(15,loc2);
	RTLR(16,loc1);
	RTLIU(17);
	
	RTGC;
	Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_7_3_0_1_0_0_0_0_);
	F1209_11188(RTCW(Result), *(EIF_REFERENCE *)(Current));
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.initialize_attribute_editor) */
		/* END INLINED CODE */
	}
	;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6549,F854_6549, (Current));
	tr3 = RTOSCF(5824,F689_5824, (Current));
	tr4 = RTOSCF(5825,F689_5825, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A341_513_2, (EIF_POINTER) _A341_513_2, (EIF_POINTER)(F854_6529),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A341_518_2, (EIF_POINTER) _A341_518_2, (EIF_POINTER)(F854_6534),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6550,F854_6550, (Current));
	tr3 = RTOSCF(5826,F689_5826, (Current));
	tr4 = RTOSCF(5827,F689_5827, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A341_514_2, (EIF_POINTER) _A341_514_2, (EIF_POINTER)(F854_6530),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A341_519_2, (EIF_POINTER) _A341_519_2, (EIF_POINTER)(F854_6535),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6551,F854_6551, (Current));
	tr3 = RTOSCF(5828,F689_5828, (Current));
	tr4 = RTOSCF(5829,F689_5829, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A341_516_2, (EIF_POINTER) _A341_516_2, (EIF_POINTER)(F854_6532),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A341_520_2, (EIF_POINTER) _A341_520_2, (EIF_POINTER)(F854_6536),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6552,F854_6552, (Current));
	tr3 = RTOSCF(5830,F689_5830, (Current));
	tr4 = RTOSCF(5831,F689_5831, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A341_517_2, (EIF_POINTER) _A341_517_2, (EIF_POINTER)(F854_6533),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A341_520_2, (EIF_POINTER) _A341_520_2, (EIF_POINTER)(F854_6536),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6553,F854_6553, (Current));
	tr3 = RTOSCF(5832,F689_5832, (Current));
	tr4 = RTOSCF(5833,F689_5833, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A341_515_2, (EIF_POINTER) _A341_515_2, (EIF_POINTER)(F854_6531),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A341_520_2, (EIF_POINTER) _A341_520_2, (EIF_POINTER)(F854_6536),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1259, 0).id);
	tr2 = RTMS_EX_H("Is_homogeneous\?",15,1873129279);
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A341_521, (EIF_POINTER) _A341_521, (EIF_POINTER)(F854_6537),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A341_546, (EIF_POINTER) _A341_546, (EIF_POINTER)(F1563_17201),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F1120_10306(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	tr1 = RTLNSMART(eif_new_type(1172, 0).id);
	tr2 = RTMS_EX_H("Position children...",20,803932718);
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	loc2 = RTLNS(eif_new_type(1239, 0x00).id, 1239, _OBJSIZ_5_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc2));
	F1120_10306(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_11_));
	loc1 = RTLNS(eif_new_type(1203, 0x00).id, 1203, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc1));
	F1120_10306(RTCW(loc1), loc2);
	F1203_11119(RTCW(loc1), loc2);
	ti4_1 = F1196_11023(RTCV(F1563_17188(Current)));
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		tr1 = F1173_10796(RTCW(tr1));
		F1121_10336(RTCW(tr1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr1 = F1161_10709(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A341_512, (EIF_POINTER) _A341_512, (EIF_POINTER)(F854_6528),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F1120_10306(RTCW(Result), loc1);
	F854_6522(Current);
	RTLE;
	return Result;
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.update_attribute_editor */
void F854_6522 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tr1 = F1162_10712(RTCW(tr1));
	F688_5577(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	ti4_1 = F1196_10986(RTCV(F1563_17188(Current)));
	tr2 = eif_out__i4_s1(ti4_1);
	{
		/* INLINED CODE (GB_INTEGER_INPUT_FIELD.update_constant_display) */
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	ti4_1 = F1196_10987(RTCV(F1563_17188(Current)));
	tr2 = eif_out__i4_s1(ti4_1);
	{
		/* INLINED CODE (GB_INTEGER_INPUT_FIELD.update_constant_display) */
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	ti4_1 = F1196_11002(RTCV(F1563_17188(Current)));
	tr2 = eif_out__i4_s1(ti4_1);
	{
		/* INLINED CODE (GB_INTEGER_INPUT_FIELD.update_constant_display) */
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	ti4_1 = F1196_11001(RTCV(F1563_17188(Current)));
	tr2 = eif_out__i4_s1(ti4_1);
	{
		/* INLINED CODE (GB_INTEGER_INPUT_FIELD.update_constant_display) */
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	ti4_1 = F1196_11000(RTCV(F1563_17188(Current)));
	tr2 = eif_out__i4_s1(ti4_1);
	{
		/* INLINED CODE (GB_INTEGER_INPUT_FIELD.update_constant_display) */
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	tb1 = F1196_11003(RTCV(F1563_17188(Current)));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		F1109_10165(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		tr2 = RTMS_EX_H("Disable homogeneous",19,53089907);
		F1113_10184(RTCW(tr1), tr2);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		F1110_10167(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		tr2 = RTMS_EX_H("Enable homogeneous",18,1356956787);
		F1113_10184(RTCW(tr1), tr2);
	}
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tb2 = F1194_10928(RTCW(tr1));
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1232_11823(RTCW(tr1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tr1 = F1162_10712(RTCW(tr1));
	F688_5579(RTCW(tr1));
	RTLE;
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.set_item_position_and_span */
void F854_6526 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	tb1 = '\01';
	tb2 = '\01';
	tb3 = '\01';
	tr1 = F1563_17188(Current);
	ti4_1 = F1196_10989(RTCW(tr1), arg1);
	if (!(EIF_BOOLEAN)(ti4_1 != arg2)) {
		tr1 = F1563_17188(Current);
		ti4_1 = F1196_10990(RTCW(tr1), arg1);
		tb3 = (EIF_BOOLEAN)(ti4_1 != arg3);
	}
	if (!tb3) {
		tr1 = F1563_17188(Current);
		ti4_1 = F1196_10991(RTCW(tr1), arg1);
		tb2 = (EIF_BOOLEAN)(ti4_1 != arg4);
	}
	if (!tb2) {
		tr1 = F1563_17188(Current);
		ti4_1 = F1196_10992(RTCW(tr1), arg1);
		tb1 = (EIF_BOOLEAN)(ti4_1 != arg5);
	}
	if (tb1) {
		tr1 = F1563_17188(Current);
		loc1 = F591_5016(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L));
		F854_6527(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_), loc1, arg2, arg3, arg4, arg5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,6,997,0,1033,1033,1033,1033,1033,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 7, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		((EIF_TYPED_VALUE *)tr2+2)->it_i4 = loc1;
		((EIF_TYPED_VALUE *)tr2+3)->it_i4 = arg2;
		((EIF_TYPED_VALUE *)tr2+4)->it_i4 = arg3;
		((EIF_TYPED_VALUE *)tr2+5)->it_i4 = arg4;
		((EIF_TYPED_VALUE *)tr2+6)->it_i4 = arg5;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,33,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr5= RTLNRF(typres0.id, (EIF_POINTER) __A341_511_2, (EIF_POINTER) _A341_511_2, (EIF_POINTER)(F854_6527),tr2, 1, 1);
		}
		{
			/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.for_all_instance_referers) */
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.enable_project_modified) */
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.actual_set_item_position_and_span */
void F854_6527 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	loc1 = RTRV(eif_new_type(1195, 0x00), loc1);
	tr1 = F591_5017(RTCW(loc1), arg2);
	F1196_11017(RTCW(loc1), tr1, arg3, arg4, arg5, arg6);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc1 = RTRV(eif_new_type(1195, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = F591_5017(RTCW(loc1), arg2);
		F1196_11017(RTCW(loc1), tr1, arg3, arg4, arg5, arg6);
	}
	RTLE;
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.show_layout_window */
void F854_6528 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) == NULL)) {
		tr1 = RTLNSMART(eif_new_type(1231, 0).id);
		F1232_11819(RTCW(tr1), Current, *(EIF_REFERENCE *)(Current));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = F1563_17189(Current, *(EIF_REFERENCE *)(Current + O13220[Dtype(Current)-1562]));
	F1226_11642(RTCW(tr1), tr2);
	RTLE;
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.set_rows */
void F854_6529 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,1033,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 1);
	}
	ti4_1 = F1196_10987(RTCV(F1563_17188(Current)));
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = ti4_1;
	((EIF_TYPED_VALUE *)tr1+2)->it_i4 = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1195,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A554_289_1, (EIF_POINTER) _A554_289_1, 0, tr1, 0, 1);
	}
	F1563_17199(Current, tr4);
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.set_columns */
void F854_6530 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,1033,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
	ti4_1 = F1196_10986(RTCV(F1563_17188(Current)));
	((EIF_TYPED_VALUE *)tr1+2)->it_i4 = ti4_1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1195,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A554_289_1, (EIF_POINTER) _A554_289_1, 0, tr1, 0, 1);
	}
	F1563_17199(Current, tr4);
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.set_border_width */
void F854_6531 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1195,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A554_288_1, (EIF_POINTER) _A554_288_1, 0, tr1, 0, 1);
	}
	F1563_17199(Current, tr4);
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.set_row_spacing */
void F854_6532 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1195,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A554_286_1, (EIF_POINTER) _A554_286_1, 0, tr1, 0, 1);
	}
	F1563_17199(Current, tr4);
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.set_column_spacing */
void F854_6533 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1195,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A554_287_1, (EIF_POINTER) _A554_287_1, 0, tr1, 0, 1);
	}
	F1563_17199(Current, tr4);
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.valid_row_value */
EIF_BOOLEAN F854_6534 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1563_17188(Current);
	Result = F1196_10996(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.valid_column_value */
EIF_BOOLEAN F854_6535 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1563_17188(Current);
	Result = F1196_10995(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.valid_spacing */
EIF_BOOLEAN F854_6536 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 0L));
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.toggle_homogeneous */
void F854_6537 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	tb1 = F1196_11003(RTCV(F1563_17188(Current)));
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,997,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1195,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A554_285_1, (EIF_POINTER) _A554_285_1, 0, tr1, 0, 1);
		}
		F1563_17199(Current, tr4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		tr2 = RTMS_EX_H("Enable homogeneous",18,1356956787);
		F1113_10184(RTCW(tr1), tr2);
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,997,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1195,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A554_284_1, (EIF_POINTER) _A554_284_1, 0, tr1, 0, 1);
		}
		F1563_17199(Current, tr4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		tr2 = RTMS_EX_H("Disable homogeneous",19,53089907);
		F1113_10184(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.rows_string */

EIF_REFERENCE F854_6549 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6549,RTMS_EX_H("Rows",4,1383036787));
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.columns_string */

EIF_REFERENCE F854_6550 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6550,RTMS_EX_H("Columns",7,1551697523));
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.row_spacing_string */

EIF_REFERENCE F854_6551 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6551,RTMS_EX_H("Row_spacing",11,1815526759));
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.column_spacing_string */

EIF_REFERENCE F854_6552 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6552,RTMS_EX_H("Column_spacing",14,454495591));
}

/* {GB_EV_TABLE_EDITOR_CONSTRUCTOR}.border_width_string */

EIF_REFERENCE F854_6553 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6553,RTMS_EX_H("Border_width",12,1483107432));
}

void EIF_Minit341 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
