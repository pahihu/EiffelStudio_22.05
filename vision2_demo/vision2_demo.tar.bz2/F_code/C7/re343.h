
#ifndef _C7_re343_
#define _C7_re343_

#ifdef __cplusplus
extern "C" {
#endif

extern void F856_6576(EIF_REFERENCE, EIF_REFERENCE);
extern void F856_6577(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit343(void);

#ifdef __cplusplus
}
#endif

#endif
