/*
 * Code for class GB_EV_EDITOR_CONSTRUCTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb325.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_EV_EDITOR_CONSTRUCTOR}.retrieve_pebble */
EIF_REFERENCE F838_6260 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {GB_EV_EDITOR_CONSTRUCTOR}.named_list_item_from_widget */
EIF_REFERENCE F838_6261 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_6_0_0_1_0_0_0_0_);
	tr1 = F272_4283(Current, arg1);
	F1113_10182(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {GB_EV_EDITOR_CONSTRUCTOR}.rebuild_associated_editors */
void F838_6262 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {GB_EV_EDITOR_CONSTRUCTOR}.validate_true */
EIF_BOOLEAN F838_6263 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {GB_EV_EDITOR_CONSTRUCTOR}.set_object */
void F838_6265 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {GB_EV_EDITOR_CONSTRUCTOR}.for_all_instance_referers */
void F838_6266 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

void EIF_Minit325 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
