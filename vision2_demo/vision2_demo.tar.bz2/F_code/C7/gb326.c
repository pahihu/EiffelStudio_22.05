/*
 * Code for class GB_EV_FIXED_EDITOR_CONSTRUCTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb326.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_EV_FIXED_EDITOR_CONSTRUCTOR}.ev_type */
EIF_REFERENCE F839_6267 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_5_);
}


/* {GB_EV_FIXED_EDITOR_CONSTRUCTOR}.attribute_editor */
EIF_REFERENCE F839_6269 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,Result);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLIU(8);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1172, 0x00).id, 1172, _OBJSIZ_6_0_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Position children...",20,803932718);
	F1113_10182(RTCW(loc1), tr1);
	loc2 = RTLNS(eif_new_type(1239, 0x00).id, 1239, _OBJSIZ_5_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc2));
	F1120_10306(RTCW(loc2), loc1);
	tb1 = F483_4817(RTCV(F1563_17188(Current)));
	if (tb1) {
		tr1 = F1173_10796(RTCW(loc1));
		F1121_10336(RTCW(tr1));
	}
	Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_7_3_0_1_0_0_0_0_);
	F1209_11188(RTCW(Result), *(EIF_REFERENCE *)(Current));
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.initialize_attribute_editor) */
		/* END INLINED CODE */
	}
	;
	loc3 = RTLNS(eif_new_type(1203, 0x00).id, 1203, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc3));
	F1120_10306(RTCW(loc3), loc2);
	F1203_11119(RTCW(loc3), loc2);
	F1120_10306(RTCW(Result), loc3);
	tr1 = F1161_10709(RTCW(loc1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A326_516, (EIF_POINTER) _A326_516, (EIF_POINTER)(F839_6280),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F839_6270(Current);
	RTLE;
	return Result;
}

/* {GB_EV_FIXED_EDITOR_CONSTRUCTOR}.update_attribute_editor */
void F839_6270 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tb2 = F1194_10928(RTCW(tr1));
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1230_11711(RTCW(tr1));
	}
	RTLE;
}

/* {GB_EV_FIXED_EDITOR_CONSTRUCTOR}.set_item_x_position */
void F839_6271 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	ti4_1 = F1106_10138(RTCW(arg1));
	if ((EIF_BOOLEAN)(ti4_1 != arg2)) {
		tr1 = F1563_17188(Current);
		loc1 = F1120_10292(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L));
		F839_6272(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_), loc1, arg2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,997,0,1033,1033,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 4, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		((EIF_TYPED_VALUE *)tr2+2)->it_i4 = loc1;
		((EIF_TYPED_VALUE *)tr2+3)->it_i4 = arg2;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,33,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr5= RTLNRF(typres0.id, (EIF_POINTER) __A326_508_2, (EIF_POINTER) _A326_508_2, (EIF_POINTER)(F839_6272),tr2, 1, 1);
		}
		{
			/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.for_all_instance_referers) */
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.enable_project_modified) */
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {GB_EV_FIXED_EDITOR_CONSTRUCTOR}.actual_set_item_x_position */
void F839_6272 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	loc1 = RTRV(eif_new_type(1200, 0x00), loc1);
	tr1 = F1120_10291(RTCW(loc1), arg2);
	F1201_11078(RTCW(loc1), tr1, arg3);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc1 = RTRV(eif_new_type(1200, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = F1120_10291(RTCW(loc1), arg2);
		F1201_11078(RTCW(loc1), tr1, arg3);
	}
	RTLE;
}

/* {GB_EV_FIXED_EDITOR_CONSTRUCTOR}.set_item_y_position */
void F839_6273 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	ti4_1 = F1106_10139(RTCW(arg1));
	if ((EIF_BOOLEAN)(ti4_1 != arg2)) {
		tr1 = F1563_17188(Current);
		loc1 = F1120_10292(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L));
		F839_6274(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_), loc1, arg2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,997,0,1033,1033,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 4, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		((EIF_TYPED_VALUE *)tr2+2)->it_i4 = loc1;
		((EIF_TYPED_VALUE *)tr2+3)->it_i4 = arg2;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,33,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr5= RTLNRF(typres0.id, (EIF_POINTER) __A326_510_2, (EIF_POINTER) _A326_510_2, (EIF_POINTER)(F839_6274),tr2, 1, 1);
		}
		{
			/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.for_all_instance_referers) */
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.enable_project_modified) */
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {GB_EV_FIXED_EDITOR_CONSTRUCTOR}.actual_set_item_y_position */
void F839_6274 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	loc1 = RTRV(eif_new_type(1200, 0x00), loc1);
	tr1 = F1120_10291(RTCW(loc1), arg2);
	F1201_11079(RTCW(loc1), tr1, arg3);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc1 = RTRV(eif_new_type(1200, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = F1120_10291(RTCW(loc1), arg2);
		F1201_11079(RTCW(loc1), tr1, arg3);
	}
	RTLE;
}

/* {GB_EV_FIXED_EDITOR_CONSTRUCTOR}.set_item_width */
void F839_6275 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	ti4_1 = F1106_10142(RTCW(arg1));
	if ((EIF_BOOLEAN)(ti4_1 != arg2)) {
		tr1 = F1563_17188(Current);
		loc1 = F1120_10292(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L));
		F839_6276(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_), loc1, arg2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,997,0,1033,1033,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 4, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		((EIF_TYPED_VALUE *)tr2+2)->it_i4 = loc1;
		((EIF_TYPED_VALUE *)tr2+3)->it_i4 = arg2;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,33,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr5= RTLNRF(typres0.id, (EIF_POINTER) __A326_512_2, (EIF_POINTER) _A326_512_2, (EIF_POINTER)(F839_6276),tr2, 1, 1);
		}
		{
			/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.for_all_instance_referers) */
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.enable_project_modified) */
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {GB_EV_FIXED_EDITOR_CONSTRUCTOR}.actual_set_item_width */
void F839_6276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	loc1 = RTRV(eif_new_type(1200, 0x00), loc1);
	tr1 = F1120_10291(RTCW(loc1), arg2);
	F1201_11081(RTCW(loc1), tr1, arg3);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc1 = RTRV(eif_new_type(1200, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = F1120_10291(RTCW(loc1), arg2);
		ti4_1 = F1106_10144(RTCW(tr1));
		if ((EIF_BOOLEAN) (ti4_1 < arg3)) {
			tr1 = F1120_10291(RTCW(loc1), arg2);
			F1201_11081(RTCW(loc1), tr1, arg3);
		}
	}
	RTLE;
}

/* {GB_EV_FIXED_EDITOR_CONSTRUCTOR}.set_item_height */
void F839_6277 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLIU(8);
	
	RTGC;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1253, 0x00), loc1);
	tb1 = '\0';
	ti4_1 = F1106_10143(RTCW(arg1));
	if ((EIF_BOOLEAN)(ti4_1 != arg2)) {
		tb1 = (EIF_BOOLEAN)(loc1 == NULL);
	}
	if (tb1) {
		tr1 = F1563_17188(Current);
		loc2 = F1120_10292(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L));
		F839_6278(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_), loc2, arg2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,997,0,1033,1033,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 4, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		((EIF_TYPED_VALUE *)tr2+2)->it_i4 = loc2;
		((EIF_TYPED_VALUE *)tr2+3)->it_i4 = arg2;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,33,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr5= RTLNRF(typres0.id, (EIF_POINTER) __A326_514_2, (EIF_POINTER) _A326_514_2, (EIF_POINTER)(F839_6278),tr2, 1, 1);
		}
		{
			/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.for_all_instance_referers) */
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.enable_project_modified) */
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {GB_EV_FIXED_EDITOR_CONSTRUCTOR}.actual_set_item_height */
void F839_6278 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	loc1 = RTRV(eif_new_type(1200, 0x00), loc1);
	tr1 = F1120_10291(RTCW(loc1), arg2);
	F1201_11082(RTCW(loc1), tr1, arg3);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc1 = RTRV(eif_new_type(1200, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = F1120_10291(RTCW(loc1), arg2);
		ti4_1 = F1106_10145(RTCW(tr1));
		if ((EIF_BOOLEAN) (ti4_1 < arg3)) {
			tr1 = F1120_10291(RTCW(loc1), arg2);
			F1201_11082(RTCW(loc1), tr1, arg3);
		}
	}
	RTLE;
}

/* {GB_EV_FIXED_EDITOR_CONSTRUCTOR}.show_layout_window */
void F839_6280 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) == NULL)) {
		tr1 = RTLNSMART(eif_new_type(1229, 0).id);
		F1230_11709(RTCW(tr1), Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = F1563_17189(Current, *(EIF_REFERENCE *)(Current + _REFACS_6_));
	F1226_11642(RTCW(tr1), tr2);
	RTLE;
}

void EIF_Minit326 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
