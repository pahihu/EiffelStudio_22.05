
#ifndef _C7_ev349_
#define _C7_ev349_

#ifdef __cplusplus
extern "C" {
#endif

extern void F862_6732(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F862_6733(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F862_6738(EIF_REFERENCE);
extern EIF_INTEGER_32 F862_6740(EIF_REFERENCE);
extern void EIF_Minit349(void);

#ifdef __cplusplus
}
#endif

#endif
