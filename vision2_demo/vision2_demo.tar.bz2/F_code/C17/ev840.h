
#ifndef _C17_ev840_
#define _C17_ev840_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1486_15923(EIF_REFERENCE);
extern EIF_BOOLEAN F1486_15924(EIF_REFERENCE);
extern void F1486_15926(EIF_REFERENCE);
extern void EIF_Minit840(void);
extern void F1314_13098(EIF_REFERENCE, EIF_POINTER);
extern void F1315_13125(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
