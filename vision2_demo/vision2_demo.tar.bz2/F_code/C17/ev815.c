/*
 * Code for class EV_RADIO_BUTTON_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev815.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_RADIO_BUTTON_IMP}.new_gtk_button */
EIF_POINTER F1461_15657 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	Result = (EIF_POINTER) gtk_radio_button_new((GSList*) tp2);
	RTLE;
	return Result;
}

/* {EV_RADIO_BUTTON_IMP}.make */
void F1461_15658 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1460_15638(Current);
	F1460_15645(Current);
	F1461_15660(Current);
	RTLE;
}

/* {EV_RADIO_BUTTON_IMP}.is_selected */
EIF_BOOLEAN F1461_15659 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1314_13122(Current);
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_toggle_button_get_active((GtkToggleButton*) tp1));
	RTLE;
	return Result;
}

/* {EV_RADIO_BUTTON_IMP}.enable_select */
void F1461_15660 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1461_15659(Current)) {
		tp1 = F1314_13122(Current);
		gtk_toggle_button_set_active((GtkToggleButton*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	}
	RTLE;
}

/* {EV_RADIO_BUTTON_IMP}.widget_object */
EIF_POINTER F1461_15661 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	RTGC;
	Result = (EIF_POINTER) (((GSList *)arg1)->data);
	return (EIF_POINTER) (EIF_POINTER) gtk_widget_get_parent((GtkWidget*) Result);
}

/* {EV_RADIO_BUTTON_IMP}.radio_group */
EIF_POINTER F1461_15662 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1314_13122(Current);
	Result = (EIF_POINTER) gtk_radio_button_get_group((GtkRadioButton*) tp1);
	RTLE;
	return Result;
}

void EIF_Minit815 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
