
#ifndef _C17_ev804_
#define _C17_ev804_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1450_15374(EIF_REFERENCE);
extern void EIF_Minit804(void);
extern void F1441_15182(EIF_REFERENCE);
extern void F1314_13098(EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif

#endif
