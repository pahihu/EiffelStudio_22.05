/*
 * Code for class EV_LIST_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev812.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F101_1871
static void inline_F101_1871 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_tree_view_set_headers_visible ((GtkTreeView*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F101_1871
#endif
#ifndef INLINE_F101_1923
static EIF_POINTER inline_F101_1923 (void)
{
	return (EIF_POINTER) (gtk_tree_view_column_new())
	;
}
#define INLINE_F101_1923
#endif
#ifndef INLINE_F101_1904
static void inline_F101_1904 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_tree_view_column_set_resizable ((GtkTreeViewColumn*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F101_1904
#endif
#ifndef INLINE_F101_1914
static EIF_POINTER inline_F101_1914 (void)
{
	return (EIF_POINTER) (gtk_cell_renderer_text_new())
	;
}
#define INLINE_F101_1914
#endif
#ifndef INLINE_F101_1926
static void inline_F101_1926 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	gtk_tree_view_column_pack_end ((GtkTreeViewColumn*) arg1, (GtkCellRenderer*) arg2, (gboolean) arg3)
	;
}
#define INLINE_F101_1926
#endif
#ifndef INLINE_F101_1913
static void inline_F101_1913 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4)
{
	gtk_tree_view_column_add_attribute ((GtkTreeViewColumn*) arg1, (GtkCellRenderer*) arg2, (gchar*) arg3, (gint) arg4)
	;
}
#define INLINE_F101_1913
#endif
#ifndef INLINE_F101_1915
static EIF_POINTER inline_F101_1915 (void)
{
	return (EIF_POINTER) (gtk_cell_renderer_pixbuf_new())
	;
}
#define INLINE_F101_1915
#endif
#ifndef INLINE_F101_1920
static void inline_F101_1920 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	gtk_tree_view_insert_column ((GtkTreeView*) arg1, (GtkTreeViewColumn*) arg2, (gint) arg3)
	;
}
#define INLINE_F101_1920
#endif
#ifndef INLINE_F101_1897
static EIF_POINTER inline_F101_1897 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_tree_view_get_selection ((GtkTreeView*) arg1))
	;
}
#define INLINE_F101_1897
#endif
#ifndef INLINE_F101_1880
static EIF_POINTER inline_F101_1880 (EIF_POINTER arg1, EIF_POINTER* arg2)
{
	return (EIF_POINTER) (gtk_tree_selection_get_selected_rows ((GtkTreeSelection*) arg1, (GtkTreeModel**) arg2))
	;
}
#define INLINE_F101_1880
#endif
#ifndef INLINE_F101_1805
static void inline_F101_1805 (EIF_POINTER arg1)
{
	g_list_foreach ((GList*) arg1, (GFunc) gtk_tree_path_free, NULL)
	;
}
#define INLINE_F101_1805
#endif
#ifndef INLINE_F101_1888
static EIF_POINTER inline_F101_1888 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	return (EIF_POINTER) (gtk_tree_model_get_path ((GtkTreeModel*) arg1, (GtkTreeIter*) arg2))
	;
}
#define INLINE_F101_1888
#endif
#ifndef INLINE_F101_1864
static void inline_F101_1864 (EIF_POINTER arg1)
{
	gtk_tree_path_free ((GtkTreePath*) arg1)
	;
}
#define INLINE_F101_1864
#endif
#ifndef INLINE_F101_1898
static void inline_F101_1898 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_tree_selection_set_mode ((GtkTreeSelection*) arg1, (GtkSelectionMode) arg2)
	;
}
#define INLINE_F101_1898
#endif
#ifndef INLINE_F101_1882
static void inline_F101_1882 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_tree_selection_select_iter ((GtkTreeSelection*) arg1, (GtkTreeIter*) arg2)
	;
}
#define INLINE_F101_1882
#endif
#ifndef INLINE_F101_1883
static void inline_F101_1883 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_tree_selection_unselect_iter ((GtkTreeSelection*) arg1, (GtkTreeIter*) arg2)
	;
}
#define INLINE_F101_1883
#endif
#ifndef INLINE_F101_1885
static void inline_F101_1885 (EIF_POINTER arg1)
{
	gtk_tree_selection_unselect_all ((GtkTreeSelection*) arg1)
	;
}
#define INLINE_F101_1885
#endif
#ifndef INLINE_F101_1865
static int inline_F101_1865 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4, EIF_POINTER arg5, EIF_POINTER arg6, EIF_POINTER arg7)
{
	return (int) (gtk_tree_view_get_path_at_pos ((GtkTreeView*) arg1, (gint) arg2, (gint) arg3, (GtkTreePath**) arg4, (GtkTreeViewColumn**) arg5, (gint*) arg6, (gint*) arg7))
	;
}
#define INLINE_F101_1865
#endif
#ifndef INLINE_F101_1894
static EIF_POINTER inline_F101_1894 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_tree_view_get_column ((GtkTreeView*) arg1, (gint) arg2))
	;
}
#define INLINE_F101_1894
#endif
#ifndef INLINE_F101_1826
static void inline_F101_1826 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	gtk_widget_style_get ((GtkWidget*) arg1, (gchar*) arg2, (gint*) arg3, NULL);
	;
}
#define INLINE_F101_1826
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_LIST_IMP}.make */
void F1458_15605 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp3 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp4 = tp3;
	tp1 = (EIF_POINTER) gtk_scrolled_window_new((GtkAdjustment*) tp2, (GtkAdjustment*) tp4);
	*(EIF_POINTER *)(Current + O12307[dtype-1457]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O12307[dtype-1457]);
	ti4_1 = (EIF_INTEGER_32) GTK_SHADOW_IN;
	gtk_scrolled_window_set_shadow_type((GtkScrolledWindow*) tp1, (GtkShadowType) ti4_1);
	F1314_13098(Current, *(EIF_POINTER *)(Current + O12307[dtype-1457]));
	tp1 = (EIF_POINTER) gtk_tree_view_new();
	*(EIF_POINTER *)(Current + O12310[dtype-1457]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O12307[dtype-1457]);
	tp2 = *(EIF_POINTER *)(Current + O12310[dtype-1457]);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) tp2);
	F1456_15549(Current);
	tp1 = *(EIF_POINTER *)(Current + O12310[dtype-1457]);
	tp2 = *(EIF_POINTER *)(Current + O12295[dtype-1455]);
	gtk_tree_view_set_model((GtkTreeView*) tp1, (GtkTreeModel*) tp2);
	tp1 = *(EIF_POINTER *)(Current + O12307[dtype-1457]);
	ti4_1 = (EIF_INTEGER_32) GTK_POLICY_AUTOMATIC;
	ti4_2 = (EIF_INTEGER_32) GTK_POLICY_AUTOMATIC;
	gtk_scrolled_window_set_policy((GtkScrolledWindow*) tp1, (GtkPolicyType) ti4_1, (GtkPolicyType) ti4_2);
	tp1 = *(EIF_POINTER *)(Current + O12310[dtype-1457]);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current + O12310[dtype-1457]);
	inline_F101_1871(tp1, (EIF_BOOLEAN) 0);
	loc1 = inline_F101_1923();
	inline_F101_1904(loc1, (EIF_BOOLEAN) 1);
	loc2 = inline_F101_1914();
	inline_F101_1926(loc1, loc2, (EIF_BOOLEAN) 1);
	loc3 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr1 = RTMS_EX_H("text",4,1952807028);
	F928_6962(RTCW(loc3), tr1);
	tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	inline_F101_1913(loc1, loc2, tp1, ((EIF_INTEGER_32) 1L));
	loc2 = inline_F101_1915();
	inline_F101_1926(loc1, loc2, (EIF_BOOLEAN) 0);
	loc3 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr1 = RTMS_EX_H("pixbuf",6,93246054);
	F928_6962(RTCW(loc3), tr1);
	tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	inline_F101_1913(loc1, loc2, tp1, ((EIF_INTEGER_32) 0L));
	tp1 = *(EIF_POINTER *)(Current + O12310[dtype-1457]);
	inline_F101_1920(tp1, loc1, ((EIF_INTEGER_32) 1L));
	tr1 = F1458_15608(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O12309[dtype-1457]) = (EIF_REFERENCE) tr1;
	tp1 = *(EIF_POINTER *)(Current + O12310[dtype-1457]);
	loc4 = inline_F101_1897(tp1);
	tr1 = RTOSCF(371,F16_371, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,960,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(13123,F1314_13123, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O6580[dtype-937]);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A391_320, (EIF_POINTER) _A391_320, (EIF_POINTER)(F941_7731),tr2, 1, 0);
	}
	F1314_13102(Current, loc4, tr1, tr3);
	F1336_13553(Current);
	RTLE;
}

/* {EV_LIST_IMP}.needs_event_box */
EIF_BOOLEAN F1458_15606 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {EV_LIST_IMP}.selected_item */
EIF_REFERENCE F1458_15607 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc6);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12310[dtype-1457]);
	loc1 = inline_F101_1897(tp1);
	loc2 = inline_F101_1880(loc1, (EIF_POINTER *) &(loc3));
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc2 != tp1)) {
		loc4 = (EIF_POINTER) (((GList *)loc2)->data);
		loc5 = (EIF_POINTER) gtk_tree_path_get_indices((GtkTreePath*) loc4);
		loc6 = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_1_0_1_0_1_1_0_);
		F932_7057(RTCW(loc6), loc5, ((EIF_INTEGER_32) 4L));
		tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
		ti4_1 = F932_7071(RTCW(loc6), ((EIF_INTEGER_32) 0L));
		Result = F664_5454(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		inline_F101_1805(loc2);
		g_list_free((GList*) loc2);
	}
	RTLE;
	return Result;
}

/* {EV_LIST_IMP}.selected_items */
EIF_REFERENCE F1458_15608 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc6);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {663,1189,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 663, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F664_5447(RTCW(Result), ((EIF_INTEGER_32) 0L));
	tp1 = *(EIF_POINTER *)(Current + O12310[dtype-1457]);
	loc1 = inline_F101_1897(tp1);
	loc2 = inline_F101_1880(loc1, (EIF_POINTER *) &(loc3));
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc2 != tp1)) {
		for (;;) {
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			if ((EIF_BOOLEAN)(loc2 == tp1)) break;
			loc4 = (EIF_POINTER) (((GList *)loc2)->data);
			loc5 = (EIF_POINTER) gtk_tree_path_get_indices((GtkTreePath*) loc4);
			loc6 = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_1_0_1_0_1_1_0_);
			F932_7057(RTCW(loc6), loc5, ((EIF_INTEGER_32) 4L));
			tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
			ti4_1 = F932_7071(RTCW(loc6), ((EIF_INTEGER_32) 0L));
			tr1 = F664_5454(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(Result))-534])(Result, tr1);
			tp2 = (EIF_POINTER) (((GList *)loc2)->next);
			loc2 = (EIF_POINTER) tp2;
		}
		inline_F101_1805(loc2);
		g_list_free((GList*) loc2);
	}
	RTLE;
	return Result;
}

/* {EV_LIST_IMP}.ensure_item_visible */
void F1458_15610 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1479, 0x00), loc1);
	RTCT0("list_item_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_20_);
	RTCT0("l_list_iter /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = *(EIF_POINTER *)(Current + O12295[dtype-1455]);
	tp2 = F260_4057(RTCW(loc2));
	loc3 = inline_F101_1888(tp1, tp2);
	tp1 = *(EIF_POINTER *)(Current + O12310[dtype-1457]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	tr4_2 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	gtk_tree_view_scroll_to_cell((GtkTreeView*) tp1, (GtkTreePath*) loc3, (GtkTreeViewColumn*) tp3, (gboolean) (EIF_BOOLEAN) 0, (gfloat) tr4_1, (gfloat) tr4_2);
	inline_F101_1864(loc3);
	RTLE;
}

/* {EV_LIST_IMP}.enable_multiple_selection */
void F1458_15611 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12310[Dtype(Current)-1457]);
	loc1 = inline_F101_1897(tp1);
	ti4_1 = (EIF_INTEGER_32) GTK_SELECTION_MULTIPLE;
	inline_F101_1898(loc1, ti4_1);
	RTLE;
}

/* {EV_LIST_IMP}.disable_multiple_selection */
void F1458_15612 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12310[Dtype(Current)-1457]);
	loc1 = inline_F101_1897(tp1);
	ti4_1 = (EIF_INTEGER_32) GTK_SELECTION_SINGLE;
	inline_F101_1898(loc1, ti4_1);
	RTLE;
}

/* {EV_LIST_IMP}.select_item */
void F1458_15613 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12310[dtype-1457]);
	loc1 = inline_F101_1897(tp1);
	tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
	tr1 = F664_5454(RTCW(tr1), arg1);
	loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc2 = RTRV(eif_new_type(1479, 0x00), loc2);
	RTCT0("a_item_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc3 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_20_);
	RTCT0("l_list_iter /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = F260_4057(RTCW(loc3));
	inline_F101_1882(loc1, tp1);
	RTLE;
}

/* {EV_LIST_IMP}.deselect_item */
void F1458_15614 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12310[dtype-1457]);
	loc1 = inline_F101_1897(tp1);
	tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
	tr1 = F664_5454(RTCW(tr1), arg1);
	loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc2 = RTRV(eif_new_type(1479, 0x00), loc2);
	RTCT0("a_item_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc3 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_20_);
	RTCT0("l_list_iter /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = F260_4057(RTCW(loc3));
	inline_F101_1883(loc1, tp1);
	RTLE;
}

/* {EV_LIST_IMP}.clear_selection */
void F1458_15615 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12310[Dtype(Current)-1457]);
	loc1 = inline_F101_1897(tp1);
	inline_F101_1885(loc1);
	RTLE;
}

/* {EV_LIST_IMP}.row_index_from_coords */
EIF_INTEGER_32 F1458_15616 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_POINTER tp5;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12310[Dtype(Current)-1457]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp4 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp5 = tp4;
	loc3 = EIF_TEST (inline_F101_1865(tp1, ((EIF_INTEGER_32) 1L), arg2, (EIF_POINTER *) &(loc1), (EIF_POINTER *) &(loc2), tp3, tp5));
	if (loc3) {
		loc4 = (EIF_POINTER) gtk_tree_path_get_indices((GtkTreePath*) loc1);
		loc5 = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_1_0_1_0_1_1_0_);
		F932_7057(RTCW(loc5), loc4, ((EIF_INTEGER_32) 4L));
		Result = F932_7071(RTCW(loc5), ((EIF_INTEGER_32) 0L));
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
		inline_F101_1864(loc1);
	}
	RTLE;
	return Result;
}

/* {EV_LIST_IMP}.item_from_coords */
EIF_REFERENCE F1458_15617 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = F1458_15616(Current, arg1, arg2);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = F1308_13069(Current, loc1);
		Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		RTLE;
		return RTRV(eif_new_type(1336, 0x00), Result);
	}
	RTLE;
	return Result;
}

/* {EV_LIST_IMP}.on_mouse_button_event */
void F1458_15618 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	loc1 = F1458_15616(Current, arg2, arg3);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		tr2 = F1308_13069(Current, loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_3_);
		*(EIF_REFERENCE *)(Current + O12286[dtype-1455]) = RTRV(eif_new_type(1479, 0), tr1);
		RTAR(Current, tr1);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + O12286[dtype-1455]);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tb2 = '\01';
			tb3 = F1480_15805(loc2, arg4);
			if (!tb3) {
				tb3 = F1363_13813(loc2);
				tb2 = tb3;
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			*(EIF_REFERENCE *)(Current + O12286[dtype-1455]) = (EIF_REFERENCE) NULL;
		}
	} else {
		*(EIF_REFERENCE *)(Current + O12286[dtype-1455]) = (EIF_REFERENCE) NULL;
	}
	F1364_13858(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
	RTLE;
}

/* {EV_LIST_IMP}.row_height */
RTEOMS(15618,1);
EIF_INTEGER_32 F1458_15619 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12310[dtype-1457]);
	loc1 = inline_F101_1894(tp1, ((EIF_INTEGER_32) 0L));
	loc2 = (EIF_POINTER) gtk_cell_layout_get_cells((GtkCellLayout*) loc1);
	loc3 = (EIF_POINTER) g_list_nth_data((GList*) loc2, (guint) ((EIF_INTEGER_32) 0L));
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	gtk_cell_renderer_get_fixed_size((GtkCellRenderer*) loc3, (gint*) tp2, (gint*) (EIF_INTEGER_32 *) &(Result));
	loc4 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F928_6962(RTCW(loc4), RTOMS(15618,0));
	tp1 = *(EIF_POINTER *)(Current + O12310[dtype-1457]);
	tp2 = *(EIF_POINTER *)(RTCW(loc4)+ _PTROFF_0_1_0_1_0_0_);
	inline_F101_1826(tp1, tp2, (EIF_INTEGER_32 *) &(loc5));
	RTLE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + loc5);
}

/* {EV_LIST_IMP}.visual_widget */
EIF_POINTER F1458_15620 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) *(EIF_POINTER *)(Current + O12310[Dtype(Current)-1457]);
}

/* {EV_LIST_IMP}.call_selection_action_sequences */
void F1458_15623 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	loc1 = F1458_15608(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {663,1479,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc2 = RTLNS(typres0.id, 663, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F664_5447(RTCW(loc2), ((EIF_INTEGER_32) 0L));
	F664_5478(RTCW(loc1));
	for (;;) {
		tb1 = F591_5028(RTCW(loc1));
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + O12309[dtype-1457]);
		tr2 = F664_5452(RTCW(loc1));
		tb2 = F664_5459(RTCW(tr1), tr2);
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = F664_5452(RTCW(loc1));
			loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
			loc3 = RTRV(eif_new_type(1479, 0x00), loc3);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(loc2))-534])(loc2, loc3);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + O12309[dtype-1457]);
		tr2 = F664_5452(RTCW(loc1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4439[Dtype(RTCW(tr1))-534])(tr1, tr2);
		F664_5480(RTCW(loc1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + O12309[dtype-1457]);
	F664_5478(RTCW(tr1));
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + O12309[dtype-1457]);
		tb2 = F591_5028(RTCW(tr1));
		if (tb2) break;
		tr1 = *(EIF_REFERENCE *)(Current + O12309[dtype-1457]);
		tr1 = F664_5452(RTCW(tr1));
		loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		loc3 = RTRV(eif_new_type(1479, 0x00), loc3);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_4_);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				tr1 = F106_2481(RTCW(loc3));
				F813_6165(RTCW(tr1), NULL);
			}
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1189,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr2 = RTLNTS(typres0.id, 2, 0);
				}
				tr3 = F1280_12327(RTCW(loc3));
				((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
				RTAR(tr2,tr3);
				F813_6165(RTCW(tr1), tr2);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + O12309[dtype-1457]);
		F664_5480(RTCW(tr1));
	}
	F664_5478(RTCW(loc2));
	for (;;) {
		tb3 = F591_5028(RTCW(loc2));
		if (tb3) break;
		tr1 = F664_5452(RTCW(loc2));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F664_5452(RTCW(loc2));
			tr1 = F106_2479(RTCW(tr1));
			F813_6165(RTCW(tr1), NULL);
		}
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1189,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F664_5452(RTCW(loc2));
			tr3 = F1280_12327(RTCW(tr3));
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			F813_6165(RTCW(tr1), tr2);
		}
		F664_5480(RTCW(loc2));
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + O12309[dtype-1457]) = (EIF_REFERENCE) loc1;
	RTLE;
}

/* {EV_LIST_IMP}.pixmaps_size_changed */
void F1458_15626 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

void EIF_Minit812 (void)
{
	GTCX
	RTPOMS(15618,0,"vertical-separator",18,1613565554);
}


#ifdef __cplusplus
}
#endif
