
#ifndef _C17_ev824_
#define _C17_ev824_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1470_15726(EIF_REFERENCE);
extern EIF_BOOLEAN F1470_15727(EIF_REFERENCE);
extern void EIF_Minit824(void);
extern void F1469_15709(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
