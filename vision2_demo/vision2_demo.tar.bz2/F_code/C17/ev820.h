
#ifndef _C17_ev820_
#define _C17_ev820_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1466_15703(EIF_REFERENCE);
extern void EIF_Minit820(void);
extern void F1464_15676(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
