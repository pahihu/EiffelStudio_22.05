
#ifndef _C17_ev822_
#define _C17_ev822_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1468_15707(EIF_REFERENCE);
extern void EIF_Minit822(void);
extern EIF_POINTER F1464_15692(EIF_REFERENCE);
extern void F1466_15703(EIF_REFERENCE);
extern void F1314_13098(EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif

#endif
