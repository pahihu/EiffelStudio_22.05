/*
 * Code for class EV_VERTICAL_SEPARATOR_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev803.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F17_402
static EIF_NATURAL_8 inline_F17_402 (void)
{
	return GTK_ORIENTATION_VERTICAL
	;
}
#define INLINE_F17_402
#endif
#ifndef INLINE_F101_1823
static void inline_F101_1823 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	gtk_widget_set_size_request ((GtkWidget*) arg1, (gint) arg2, (gint) arg3)
	;
}
#define INLINE_F101_1823
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_VERTICAL_SEPARATOR_IMP}.make */
void F1449_15371 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (EIF_POINTER) gtk_event_box_new();
	F1314_13098(Current, tp1);
	tu1_1 = inline_F17_402();
	loc1 = (EIF_POINTER) gtk_separator_new((GtkOrientation) tu1_1);
	gtk_widget_show((GtkWidget*) loc1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_42_13_10_6_0_0_);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) loc1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_42_13_10_6_0_0_);
	inline_F101_1823(tp1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) -1L));
	F1441_15182(Current);
	RTLE;
}

void EIF_Minit803 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
