/*
 * Code for class EV_RADIO_MENU_ITEM_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev848.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_RADIO_MENU_ITEM_IMP}.make */
void F1494_15958 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1492_15937(Current);
	tp1 = F1492_15943(Current);
	gtk_check_menu_item_set_draw_as_radio((GtkCheckMenuItem*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	F1494_15961(Current);
	RTLE;
}

/* {EV_RADIO_MENU_ITEM_IMP}.initialize_menu_item */
void F1494_15959 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	tp1 = (EIF_POINTER) gtk_radio_menu_item_new((GSList*) tp2);
	F1314_13098(Current, tp1);
	RTLE;
}

/* {EV_RADIO_MENU_ITEM_IMP}.is_selected */
EIF_BOOLEAN F1494_15960 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1492_15943(Current);
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_check_menu_item_get_active((GtkCheckMenuItem*) tp1));
	RTLE;
	return Result;
}

/* {EV_RADIO_MENU_ITEM_IMP}.enable_select */
void F1494_15961 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1494_15960(Current)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_23_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tp1 = F1492_15943(Current);
		gtk_check_menu_item_set_active((GtkCheckMenuItem*) tp1, (gboolean) (EIF_BOOLEAN) 1);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_23_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

/* {EV_RADIO_MENU_ITEM_IMP}.disable_select */
void F1494_15962 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (F1494_15960(Current)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_23_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tp1 = F1492_15943(Current);
		gtk_check_menu_item_set_active((GtkCheckMenuItem*) tp1, (gboolean) (EIF_BOOLEAN) 0);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_23_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

/* {EV_RADIO_MENU_ITEM_IMP}.allow_on_activate */
EIF_BOOLEAN F1494_15964 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_23_6_)) {
		tb1 = F1494_15960(Current);
	}
	if (tb1) {
		Result = (EIF_BOOLEAN)(F1485_15917(Current) != NULL);
	}
	RTLE;
	return Result;
}

/* {EV_RADIO_MENU_ITEM_IMP}.set_radio_group */
void F1494_15965 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1492_15943(Current);
	gtk_radio_menu_item_set_group((GtkRadioMenuItem*) tp1, (GSList*) arg1);
	RTLE;
}

/* {EV_RADIO_MENU_ITEM_IMP}.radio_group */
EIF_POINTER F1494_15966 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1492_15943(Current);
	Result = (EIF_POINTER) gtk_radio_menu_item_get_group((GtkRadioMenuItem*) tp1);
	RTLE;
	return Result;
}

void EIF_Minit848 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
