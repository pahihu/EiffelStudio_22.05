
#ifndef _C17_ev828_
#define _C17_ev828_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1474_15737(EIF_REFERENCE);
extern void EIF_Minit828(void);
extern void F1464_15676(EIF_REFERENCE);
extern void F1314_13098(EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif

#endif
