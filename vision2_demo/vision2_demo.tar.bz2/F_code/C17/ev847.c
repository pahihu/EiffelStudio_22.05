/*
 * Code for class EV_CHECK_MENU_ITEM_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev847.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CHECK_MENU_ITEM_IMP}.initialize_menu_item */
void F1493_15950 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (EIF_POINTER) gtk_check_menu_item_new();
	F1314_13098(Current, tp1);
	RTLE;
}

/* {EV_CHECK_MENU_ITEM_IMP}.make */
void F1493_15951 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1492_15937(Current);
	tp1 = F1492_15943(Current);
	gtk_check_menu_item_set_draw_as_radio((GtkCheckMenuItem*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	F1493_15954(Current);
	RTLE;
}

/* {EV_CHECK_MENU_ITEM_IMP}.is_selected */
EIF_BOOLEAN F1493_15952 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1492_15943(Current);
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_check_menu_item_get_active((GtkCheckMenuItem*) tp1));
	RTLE;
	return Result;
}

/* {EV_CHECK_MENU_ITEM_IMP}.enable_select */
void F1493_15953 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1493_15952(Current)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_23_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tp1 = F1492_15943(Current);
		gtk_check_menu_item_set_active((GtkCheckMenuItem*) tp1, (gboolean) (EIF_BOOLEAN) 1);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_23_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

/* {EV_CHECK_MENU_ITEM_IMP}.disable_select */
void F1493_15954 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (F1493_15952(Current)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_23_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tp1 = F1492_15943(Current);
		gtk_check_menu_item_set_active((GtkCheckMenuItem*) tp1, (gboolean) (EIF_BOOLEAN) 0);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_23_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

/* {EV_CHECK_MENU_ITEM_IMP}.allow_on_activate */
EIF_BOOLEAN F1493_15955 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN)(F1485_15917(Current) != NULL)) {
		Result = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_23_6_);
	}
	RTLE;
	return Result;
}

void EIF_Minit847 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
