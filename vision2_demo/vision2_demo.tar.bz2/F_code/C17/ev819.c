/*
 * Code for class EV_SPIN_BUTTON_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev819.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SPIN_BUTTON_IMP}.make */
void F1465_15698 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1454_15507(Current);
	F1464_15676(Current);
	RTLE;
}

/* {EV_SPIN_BUTTON_IMP}.set_text */
void F1465_15699 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1454_15510(Current, arg1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_14_10_8_0_1_);
	gtk_spin_button_update((GtkSpinButton*) tp1);
	RTLE;
}

/* {EV_SPIN_BUTTON_IMP}.new_entry_widget */
EIF_POINTER F1465_15700 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REAL_32 tr4_1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1464_15692(Current);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	Result = (EIF_POINTER) gtk_spin_button_new((GtkAdjustment*) tp1, (gfloat) tr4_1, (guint) ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {EV_SPIN_BUTTON_IMP}.style_element_name */
EIF_REFERENCE F1465_15701 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTMS_EX_H("spinbutton",10,996172654);
	RTLE;
	return Result;
}

void EIF_Minit819 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
