
#ifndef _C17_ev826_
#define _C17_ev826_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1472_15732(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1472_15733(EIF_REFERENCE);
extern void EIF_Minit826(void);
extern EIF_POINTER F1464_15692(EIF_REFERENCE);
extern EIF_INTEGER_32 F1464_15680(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
