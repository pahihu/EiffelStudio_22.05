
#ifndef _C17_ev819_
#define _C17_ev819_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1465_15698(EIF_REFERENCE);
extern void F1465_15699(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_POINTER F1465_15700(EIF_REFERENCE);
extern EIF_REFERENCE F1465_15701(EIF_REFERENCE);
extern void EIF_Minit819(void);
extern EIF_POINTER F1464_15692(EIF_REFERENCE);
extern void F1464_15676(EIF_REFERENCE);
extern void F1454_15510(EIF_REFERENCE, EIF_REFERENCE);
extern void F1454_15507(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
