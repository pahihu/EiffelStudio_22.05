/*
 * Code for class EV_CHECKABLE_LIST_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev813.h"
#include <string.h>
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F101_1894
static EIF_POINTER inline_F101_1894 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_tree_view_get_column ((GtkTreeView*) arg1, (gint) arg2))
	;
}
#define INLINE_F101_1894
#endif
#ifndef INLINE_F101_1919
static EIF_POINTER inline_F101_1919 (void)
{
	return (EIF_POINTER) (gtk_cell_renderer_toggle_new())
	;
}
#define INLINE_F101_1919
#endif
#ifndef INLINE_F101_1925
static void inline_F101_1925 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	gtk_tree_view_column_pack_start ((GtkTreeViewColumn*) arg1, (GtkCellRenderer*) arg2, (gboolean) arg3)
	;
}
#define INLINE_F101_1925
#endif
#ifndef INLINE_F101_1913
static void inline_F101_1913 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4)
{
	gtk_tree_view_column_add_attribute ((GtkTreeViewColumn*) arg1, (GtkCellRenderer*) arg2, (gchar*) arg3, (gint) arg4)
	;
}
#define INLINE_F101_1913
#endif
#ifndef INLINE_F101_1887
static int inline_F101_1887 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	return (int) (gtk_tree_model_get_iter ((GtkTreeModel*) arg1, (GtkTreeIter*) arg2, (GtkTreePath*) arg3))
	;
}
#define INLINE_F101_1887
#endif
#ifndef INLINE_F101_1889
static void inline_F101_1889 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	gtk_tree_model_get_value ((GtkTreeModel*) arg1, (GtkTreeIter*) arg2, (gint) arg3, (GValue*) arg4)
	;
}
#define INLINE_F101_1889
#endif
#ifndef INLINE_F101_1938
static int inline_F101_1938 (EIF_POINTER arg1)
{
	return (int) (g_value_get_boolean ((GValue*) arg1))
	;
}
#define INLINE_F101_1938
#endif
#ifndef INLINE_F101_1937
static void inline_F101_1937 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	g_value_set_boolean ((GValue*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F101_1937
#endif
#ifndef INLINE_F101_1955
static void inline_F101_1955 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	gtk_list_store_set_value ((GtkListStore*) arg1, (GtkTreeIter*) arg2, (gint) arg3, (GValue*) arg4)
	;
}
#define INLINE_F101_1955
#endif
#ifndef INLINE_F101_1864
static void inline_F101_1864 (EIF_POINTER arg1)
{
	gtk_tree_path_free ((GtkTreePath*) arg1)
	;
}
#define INLINE_F101_1864
#endif
#ifndef INLINE_F100_1539
static void inline_F100_1539 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	{
	GType type = GDK_TYPE_PIXBUF;
	memcpy ((char *) arg1 + arg2, &type, sizeof(GType));
}
	;
}
#define INLINE_F100_1539
#endif
#ifndef INLINE_F100_1538
static void inline_F100_1538 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	{
	GType type = G_TYPE_STRING;
	memcpy ((char *) arg1 + arg2, &type, sizeof(GType));
}
	;
}
#define INLINE_F100_1538
#endif
#ifndef INLINE_F100_1537
static void inline_F100_1537 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	{
	GType type = G_TYPE_BOOLEAN;
	memcpy ((char *) arg1 + arg2, &type, sizeof(GType));
}
	;
}
#define INLINE_F100_1537
#endif
#ifndef INLINE_F101_1947
static EIF_POINTER inline_F101_1947 (EIF_INTEGER_32 arg1, EIF_POINTER arg2)
{
	return (EIF_POINTER) (gtk_list_store_newv ((gint) arg1, (GType*) arg2))
	;
}
#define INLINE_F101_1947
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CHECKABLE_LIST_IMP}.make */
void F1459_15628 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	F1458_15605(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_3_);
	loc1 = inline_F101_1894(tp1, ((EIF_INTEGER_32) 0L));
	loc2 = inline_F101_1919();
	inline_F101_1925(loc1, loc2, (EIF_BOOLEAN) 0);
	loc3 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr1 = RTMS_EX_H("active",6,2144538725);
	F928_6962(RTCW(loc3), tr1);
	tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	inline_F101_1913(loc1, loc2, tp1, ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("toggled",7,209460068);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,960,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(13123,F1314_13123, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_53_14_10_0_);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,2,997,1033,1069,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A391_318_3_4, (EIF_POINTER) _A391_318_3_4, (EIF_POINTER)(F941_7729),tr2, 1, 2);
	}
	F1314_13102(Current, loc2, tr1, tr5);
	RTLE;
}

/* {EV_CHECKABLE_LIST_IMP}.on_tree_path_toggle */
void F1459_15630 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_POINTER loc8 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,loc6);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	loc3 = RTLNS(eif_new_type(261, 0x00).id, 261, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc3));
	loc1 = (EIF_POINTER) gtk_tree_path_new_from_string((gchar*) arg1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_);
	tp2 = F260_4057(RTCW(loc3));
	loc4 = EIF_TEST (inline_F101_1887(tp1, tp2, loc1));
	if (loc4) {
		loc2 = (EIF_POINTER) gtk_tree_path_get_indices((GtkTreePath*) loc1);
		loc5 = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_1_0_1_0_1_1_0_);
		F932_7057(RTCW(loc5), loc2, ((EIF_INTEGER_32) 4L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
		ti4_1 = F932_7071(RTCW(loc5), ((EIF_INTEGER_32) 0L));
		loc6 = F664_5454(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		loc8 = (EIF_POINTER) calloc (sizeof(GValue), 1);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_);
		tp2 = F260_4057(RTCW(loc3));
		inline_F101_1889(tp1, tp2, ((EIF_INTEGER_32) 2L), loc8);
		loc7 = EIF_TEST (inline_F101_1938(loc8));
		inline_F101_1937(loc8, (EIF_BOOLEAN) !loc7);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_);
		tp2 = F260_4057(RTCW(loc3));
		inline_F101_1955(tp1, tp2, ((EIF_INTEGER_32) 2L), loc8);
		if (loc7) {
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1189,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr2 = RTLNTS(typres0.id, 2, 0);
				}
				((EIF_TYPED_VALUE *)tr2+1)->it_r = loc6;
				RTAR(tr2,loc6);
				F813_6165(RTCW(tr1), tr2);
			}
		} else {
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1189,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr2 = RTLNTS(typres0.id, 2, 0);
				}
				((EIF_TYPED_VALUE *)tr2+1)->it_r = loc6;
				RTAR(tr2,loc6);
				F813_6165(RTCW(tr1), tr2);
			}
		}
		free(loc8);
	}
	inline_F101_1864(loc1);
	RTLE;
}

/* {EV_CHECKABLE_LIST_IMP}.initialize_model */
void F1459_15631 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_1_0_1_0_1_1_0_);
	ti4_1 = (EIF_INTEGER_32) sizeof(GType);
	F932_7054(RTCW(loc1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * ti4_1));
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	inline_F100_1539(tp1, ((EIF_INTEGER_32) 0L));
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	ti4_1 = (EIF_INTEGER_32) sizeof(GType);
	inline_F100_1538(tp1, (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) * ti4_1));
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	ti4_1 = (EIF_INTEGER_32) sizeof(GType);
	inline_F100_1537(tp1, (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1));
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	tp1 = inline_F101_1947(((EIF_INTEGER_32) 3L), tp1);
	*(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_) = (EIF_POINTER) tp1;
	RTLE;
}

/* {EV_CHECKABLE_LIST_IMP}.check_item */
void F1459_15633 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1479, 0x00), loc1);
	RTCT0("item_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_20_);
	RTCT0("l_list_iter /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc3 = (EIF_POINTER) calloc (sizeof(GValue), 1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_);
	tp2 = F260_4057(RTCW(loc2));
	inline_F101_1889(tp1, tp2, ((EIF_INTEGER_32) 2L), loc3);
	inline_F101_1937(loc3, (EIF_BOOLEAN) 1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_);
	tp2 = F260_4057(RTCW(loc2));
	inline_F101_1955(tp1, tp2, ((EIF_INTEGER_32) 2L), loc3);
	free(loc3);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1189,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = arg1;
		RTAR(tr2,arg1);
		F813_6165(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {EV_CHECKABLE_LIST_IMP}.uncheck_item */
void F1459_15634 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1479, 0x00), loc1);
	RTCT0("item_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_20_);
	RTCT0("l_list_iter /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc3 = (EIF_POINTER) calloc (sizeof(GValue), 1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_);
	tp2 = F260_4057(RTCW(loc2));
	inline_F101_1889(tp1, tp2, ((EIF_INTEGER_32) 2L), loc3);
	inline_F101_1937(loc3, (EIF_BOOLEAN) 0);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_);
	tp2 = F260_4057(RTCW(loc2));
	inline_F101_1955(tp1, tp2, ((EIF_INTEGER_32) 2L), loc3);
	free(loc3);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1189,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = arg1;
		RTAR(tr2,arg1);
		F813_6165(RTCW(tr1), tr2);
	}
	RTLE;
}

void EIF_Minit813 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
