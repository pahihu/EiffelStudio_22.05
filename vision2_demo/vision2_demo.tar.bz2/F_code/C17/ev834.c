/*
 * Code for class EV_LIST_ITEM_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev834.h"
#include "eif_built_in.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_LIST_ITEM_IMP}.make */
RTEOMS(15801,1);
void F1480_15802 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1078_9452(RTOMS(15801,0));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) tr1;
	F1280_12341(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_LIST_ITEM_IMP}.enable_transport */
void F1480_15803 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_23_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1456_15554(loc1, (EIF_BOOLEAN) 1);
	}
	RTLE;
}

/* {EV_LIST_ITEM_IMP}.able_to_transport */
EIF_BOOLEAN F1480_15805 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	tb1 = '\0';
	if (F1363_13811(Current)) {
		tb1 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L));
	}
	if (!tb1) {
		tb1 = '\0';
		tb2 = '\0';
		if (F1363_13810(Current)) {
			tb2 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 3L));
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN) !F1363_13813(Current);
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.ready_for_pnd_menu */
EIF_BOOLEAN F1480_15806 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\01';
	if (!F1363_13812(Current)) {
		tb2 = F1363_13813(Current);
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 3L));
	}
	if (tb1) {
		Result = (EIF_BOOLEAN) !arg2;
	}
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.draw_rubber_band */
void F1480_15808 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_LIST_ITEM_IMP}.erase_rubber_band */
void F1480_15809 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_LIST_ITEM_IMP}.internal_set_pointer_style */
void F1480_15815 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {EV_LIST_ITEM_IMP}.real_pointed_target */
EIF_REFERENCE F1480_15816 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {EV_LIST_ITEM_IMP}.is_selected */
EIF_BOOLEAN F1480_15817 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12282[Dtype(loc1)-1456])(loc1);
		tr2 = F1280_12327(Current);
		Result = F664_5459(RTCW(tr1), tr2);
	}
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.enable_select */
void F1480_15818 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTCT0("attached {EV_LIST_ITEM_LIST_IMP} parent_imp as l_parent_imp", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = F1280_12327(Current);
	ti4_1 = F1307_13039(loc1, tr1, ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R12124[Dtype(loc1)-1456])(loc1, ti4_1);
	RTLE;
}

/* {EV_LIST_ITEM_IMP}.disable_select */
void F1480_15819 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTCT0("attached {EV_LIST_ITEM_LIST_IMP} parent_imp as l_parent_imp", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = F1280_12327(Current);
	ti4_1 = F1307_13039(loc1, tr1, ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R12125[Dtype(loc1)-1456])(loc1, ti4_1);
	RTLE;
}

/* {EV_LIST_ITEM_IMP}.text */
EIF_REFERENCE F1480_15820 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.set_tooltip */
void F1480_15821 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1078_9452(RTCW(arg1));
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {EV_LIST_ITEM_IMP}.tooltip */
EIF_REFERENCE F1480_15822 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		Result = F1078_9452(RTMS_EX_H("",0,0));
	}
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.set_text */
void F1480_15823 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = F1078_9452(RTCW(arg1));
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1280_12327(Current);
		ti4_1 = F1307_13039(loc1, tr1, ((EIF_INTEGER_32) 1L));
		F1456_15570(loc1, ti4_1, arg1);
	}
	RTLE;
}

/* {EV_LIST_ITEM_IMP}.set_pixmap */
void F1480_15824 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) loc1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = F1280_12327(Current);
		ti4_1 = F1307_13039(loc2, tr1, ((EIF_INTEGER_32) 1L));
		F1456_15572(loc2, ti4_1, loc1);
	}
	RTLE;
}

/* {EV_LIST_ITEM_IMP}.remove_pixmap */
void F1480_15825 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) NULL;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1280_12327(Current);
		ti4_1 = F1307_13039(loc1, tr1, ((EIF_INTEGER_32) 1L));
		F1456_15573(loc1, ti4_1);
	}
	RTLE;
}

/* {EV_LIST_ITEM_IMP}.pixmap */
EIF_REFERENCE F1480_15826 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_22_);
}


/* {EV_LIST_ITEM_IMP}.x_position */
EIF_INTEGER_32 F1480_15827 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1457, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		tp1 = *(EIF_POINTER *)(loc2 + O12307[Dtype(loc2)-1457]);
		loc1 = (EIF_POINTER) gtk_scrolled_window_get_hadjustment((GtkScrolledWindow*) tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc1 != tp1)) {
			tr4_1 = (EIF_REAL_32) gtk_adjustment_get_value((GtkAdjustment*) loc1);
			tr1 = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
			*(EIF_REAL_32 *)tr1 = tr4_1;
			Result = F1014_8797(RTCW(tr1));
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -Result;
		}
	}
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.y_position */
EIF_INTEGER_32 F1480_15828 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		Result = F1307_13039(loc2, *(EIF_REFERENCE *)(Current + _REFACS_12_), ((EIF_INTEGER_32) 1L));
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R12285[Dtype(loc2)-1456])(loc2);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result - ((EIF_INTEGER_32) 1L)) * ti4_1);
		loc3 = loc2;
		loc3 = RTRV(eif_new_type(1457, 0x00),loc3);
		if (EIF_TEST(loc3)) {
			tp1 = *(EIF_POINTER *)(loc3 + O12307[Dtype(loc3)-1457]);
			loc1 = (EIF_POINTER) gtk_scrolled_window_get_hadjustment((GtkScrolledWindow*) tp1);
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			if ((EIF_BOOLEAN)(loc1 != tp1)) {
				tr4_1 = (EIF_REAL_32) gtk_adjustment_get_value((GtkAdjustment*) loc1);
				tr1 = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
				*(EIF_REAL_32 *)tr1 = tr4_1;
				ti4_1 = F1014_8797(RTCW(tr1));
				Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result - ti4_1);
			}
		}
	}
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.screen_x */
EIF_INTEGER_32 F1480_15829 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = F1315_13126(loc1);
		ti4_1 = F1480_15827(Current);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	}
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.screen_y */
EIF_INTEGER_32 F1480_15830 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = F1315_13127(loc1);
		ti4_1 = F1480_15828(Current);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	}
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.width */
EIF_INTEGER_32 F1480_15831 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = F1366_13919(loc1);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_LIST_ITEM_IMP}.height */
EIF_INTEGER_32 F1480_15832 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = F1366_13920(loc1);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_LIST_ITEM_IMP}.minimum_width */
EIF_INTEGER_32 F1480_15833 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = F1315_13131(loc1);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_LIST_ITEM_IMP}.minimum_height */
EIF_INTEGER_32 F1480_15834 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R12285[Dtype(loc1)-1456])(loc1);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_LIST_ITEM_IMP}.destroy */
void F1480_15836 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1280_12327(loc1);
		tr2 = F1280_12327(Current);
		F1120_10315(RTCW(tr1), tr2);
	}
	F1280_12342(Current, (EIF_BOOLEAN) 1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {EV_LIST_ITEM_IMP}.update_for_pick_and_drop */
void F1480_15837 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	RTGC;
}

/* {EV_LIST_ITEM_IMP}.set_list_iter */
void F1480_15839 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) arg1;
}

/* {EV_LIST_ITEM_IMP}.parent_imp */
EIF_REFERENCE F1480_15841 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_21_);
}


/* {EV_LIST_ITEM_IMP}.set_parent_imp */
void F1480_15842 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit834 (void)
{
	GTCX
	RTPOMS(15801,0,"",0,0);
}


#ifdef __cplusplus
}
#endif
