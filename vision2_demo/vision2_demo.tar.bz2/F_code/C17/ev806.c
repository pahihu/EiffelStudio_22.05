/*
 * Code for class EV_TEXT_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev806.h"
#include <ev_gtk.h>
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F100_1398
static EIF_POINTER inline_F100_1398 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref_sink((gpointer) arg1))
	;
}
#define INLINE_F100_1398
#endif
#ifndef INLINE_F101_1823
static void inline_F101_1823 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	gtk_widget_set_size_request ((GtkWidget*) arg1, (gint) arg2, (gint) arg3)
	;
}
#define INLINE_F101_1823
#endif
#ifndef INLINE_F100_1400
static void inline_F100_1400 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F100_1400
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TEXT_IMP}.make */
void F1452_15386 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tp1 = (EIF_POINTER) gtk_event_box_new();
	F1314_13098(Current, tp1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp3 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp4 = tp3;
	tp1 = (EIF_POINTER) gtk_scrolled_window_new((GtkAdjustment*) tp2, (GtkAdjustment*) tp4);
	*(EIF_POINTER *)(Current + O12235[dtype-1451]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O12235[dtype-1451]);
	ti4_1 = (EIF_INTEGER_32) GTK_SHADOW_IN;
	gtk_scrolled_window_set_shadow_type((GtkScrolledWindow*) tp1, (GtkShadowType) ti4_1);
	tp1 = *(EIF_POINTER *)(Current + O12235[dtype-1451]);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current + O10619[dtype-1313]);
	tp2 = *(EIF_POINTER *)(Current + O12235[dtype-1451]);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) tp2);
	tp1 = (EIF_POINTER) gtk_text_view_new();
	*(EIF_POINTER *)(Current + O12234[dtype-1451]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O12234[dtype-1451]);
	tp1 = (EIF_POINTER) gtk_text_view_get_buffer((GtkTextView*) tp1);
	*(EIF_POINTER *)(Current + O12236[dtype-1451]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tp1 = inline_F100_1398(tp1);
	*(EIF_POINTER *)(Current + O12236[dtype-1451]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O12234[dtype-1451]);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current + O12235[dtype-1451]);
	tp2 = *(EIF_POINTER *)(Current + O12234[dtype-1451]);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) tp2);
	tp1 = *(EIF_POINTER *)(Current + O12234[dtype-1451]);
	inline_F101_1823(tp1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	F1452_15421(Current);
	F1452_15396(Current, (EIF_BOOLEAN) 1);
	tr1 = RTLNS(eif_new_type(193, 0x00).id, 193, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(3387,F194_3387, (RTCW(tr1)));
	F1323_13281(Current, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R12230[dtype-1451])(Current);
	F1451_15376(Current);
	RTLE;
}

/* {EV_TEXT_IMP}.initialize_buffer_events */
void F1452_15387 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tr1 = RTOSCF(371,F16_371, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,960,1069,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(13123,F1314_13123, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	tp2 = *(EIF_POINTER *)(Current + O10619[dtype-1313]);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = tp2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A391_335, (EIF_POINTER) _A391_335, (EIF_POINTER)(F942_7747),tr2, 1, 0);
	}
	F1314_13102(Current, tp1, tr1, tr3);
	RTLE;
}

/* {EV_TEXT_IMP}.is_editable */
EIF_BOOLEAN F1452_15391 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O12238[Dtype(Current)-1451]);
}


/* {EV_TEXT_IMP}.has_selection */
EIF_BOOLEAN F1452_15392 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_POINTER tp5;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12236[Dtype(Current)-1451]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp4 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp5 = tp4;
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_text_buffer_get_selection_bounds((GtkTextBuffer*) tp1, (GtkTextIter*) tp3, (GtkTextIter*) tp5));
	RTLE;
	return Result;
}

/* {EV_TEXT_IMP}.start_selection */
EIF_INTEGER_32 F1452_15393 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc1));
	loc2 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc2));
	tp1 = *(EIF_POINTER *)(Current + O12236[Dtype(Current)-1451]);
	tp2 = F260_4057(RTCW(loc1));
	tp3 = F260_4057(RTCW(loc2));
	loc3 = (EIF_BOOLEAN) EIF_TEST(gtk_text_buffer_get_selection_bounds((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (GtkTextIter*) tp3));
	if (loc3) {
		tp1 = F260_4057(RTCW(loc1));
		loc4 = (EIF_INTEGER_32) gtk_text_iter_get_offset((GtkTextIter*) tp1);
		tp1 = F260_4057(RTCW(loc2));
		loc5 = (EIF_INTEGER_32) gtk_text_iter_get_offset((GtkTextIter*) tp1);
		Result = eif_min_int32 (loc4,loc5);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	} else {
		tp1 = F260_4057(RTCW(loc1));
		Result = (EIF_INTEGER_32) gtk_text_iter_get_offset((GtkTextIter*) tp1);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	}
	RTLE;
	return Result;
}

/* {EV_TEXT_IMP}.end_selection */
EIF_INTEGER_32 F1452_15394 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc1));
	loc2 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc2));
	tp1 = *(EIF_POINTER *)(Current + O12236[Dtype(Current)-1451]);
	tp2 = F260_4057(RTCW(loc1));
	tp3 = F260_4057(RTCW(loc2));
	loc3 = (EIF_BOOLEAN) EIF_TEST(gtk_text_buffer_get_selection_bounds((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (GtkTextIter*) tp3));
	if (loc3) {
		tp1 = F260_4057(RTCW(loc1));
		loc4 = (EIF_INTEGER_32) gtk_text_iter_get_offset((GtkTextIter*) tp1);
		tp1 = F260_4057(RTCW(loc2));
		loc5 = (EIF_INTEGER_32) gtk_text_iter_get_offset((GtkTextIter*) tp1);
		Result = eif_max_int32 (loc4,loc5);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	} else {
		tp1 = F260_4057(RTCW(loc1));
		Result = (EIF_INTEGER_32) gtk_text_iter_get_offset((GtkTextIter*) tp1);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	}
	RTLE;
	return Result;
}

/* {EV_TEXT_IMP}.set_editable */
void F1452_15396 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O12238[dtype-1451]) = (EIF_BOOLEAN) arg1;
	tp1 = *(EIF_POINTER *)(Current + O12234[dtype-1451]);
	gtk_text_view_set_editable((GtkTextView*) tp1, (gboolean) arg1);
	RTLE;
}

/* {EV_TEXT_IMP}.set_caret_position */
void F1452_15397 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	F1452_15427(Current, arg1);
}

/* {EV_TEXT_IMP}.select_region */
void F1452_15398 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc1));
	loc2 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc2));
	tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tp2 = F260_4057(RTCW(loc1));
	gtk_text_buffer_get_iter_at_offset((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (gint) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)));
	tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tp2 = F260_4057(RTCW(loc2));
	gtk_text_buffer_get_iter_at_offset((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (gint) arg2);
	tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tp2 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tp2 = (EIF_POINTER) gtk_text_buffer_get_selection_bound((GtkTextBuffer*) tp2);
	tp3 = F260_4057(RTCW(loc1));
	gtk_text_buffer_move_mark((GtkTextBuffer*) tp1, (GtkTextMark*) tp2, (GtkTextIter*) tp3);
	tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tp2 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tp2 = (EIF_POINTER) gtk_text_buffer_get_insert((GtkTextBuffer*) tp2);
	tp3 = F260_4057(RTCW(loc2));
	gtk_text_buffer_move_mark((GtkTextBuffer*) tp1, (GtkTextMark*) tp2, (GtkTextIter*) tp3);
	RTLE;
}

/* {EV_TEXT_IMP}.text */
RTEOMS(15404,1);
EIF_REFERENCE F1452_15405 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLR(3,loc4);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc1));
	loc2 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc2));
	tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tp2 = F260_4057(RTCW(loc1));
	tp3 = F260_4057(RTCW(loc2));
	gtk_text_buffer_get_bounds((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (GtkTextIter*) tp3);
	tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tp2 = F260_4057(RTCW(loc1));
	tp3 = F260_4057(RTCW(loc2));
	loc3 = (EIF_POINTER) gtk_text_buffer_get_text((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (GtkTextIter*) tp3, (gboolean) (EIF_BOOLEAN) 0);
	loc4 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F928_6956(RTCW(loc4), loc3);
	Result = F928_6960(RTCW(loc4));
	F928_6962(RTCW(loc4), RTOMS(15404,0));
	RTLE;
	return Result;
}

/* {EV_TEXT_IMP}.text_length */
EIF_INTEGER_32 F1452_15409 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O12236[Dtype(Current)-1451]);
	return (EIF_INTEGER_32) (EIF_INTEGER_32) gtk_text_buffer_get_char_count((GtkTextBuffer*) tp1);
}

/* {EV_TEXT_IMP}.current_line_number */
EIF_INTEGER_32 F1452_15411 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc1));
	tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tp2 = F260_4057(RTCW(loc1));
	tp3 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tp3 = (EIF_POINTER) gtk_text_buffer_get_insert((GtkTextBuffer*) tp3);
	gtk_text_buffer_get_iter_at_mark((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (GtkTextMark*) tp3);
	for (;;) {
		tp1 = *(EIF_POINTER *)(Current + O12234[dtype-1451]);
		tp2 = F260_4057(RTCW(loc1));
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_text_view_backward_display_line((GtkTextView*) tp1, (GtkTextIter*) tp2))) break;
		Result++;
	}
	ti4_1 = eif_max_int32 (Result,((EIF_INTEGER_32) 1L));
	RTLE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {EV_TEXT_IMP}.caret_position */
EIF_INTEGER_32 F1452_15412 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc1));
	tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tp2 = F260_4057(RTCW(loc1));
	tp3 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tp3 = (EIF_POINTER) gtk_text_buffer_get_insert((GtkTextBuffer*) tp3);
	gtk_text_buffer_get_iter_at_mark((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (GtkTextMark*) tp3);
	tp1 = F260_4057(RTCW(loc1));
	Result = (EIF_INTEGER_32) gtk_text_iter_get_offset((GtkTextIter*) tp1);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	RTLE;
	return Result;
}

/* {EV_TEXT_IMP}.has_word_wrapping */
EIF_BOOLEAN F1452_15413 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O12237[Dtype(Current)-1451]);
}


/* {EV_TEXT_IMP}.set_text */
void F1452_15415 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F928_6962(RTCW(loc1), arg1);
	tp1 = *(EIF_POINTER *)(Current + O12236[Dtype(Current)-1451]);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	gtk_text_buffer_set_text((GtkTextBuffer*) tp1, (gchar*) tp2, (gint) ((EIF_INTEGER_32) -1L));
	RTLE;
}

/* {EV_TEXT_IMP}.append_text */
void F1452_15416 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1452_15426(Current, *(EIF_POINTER *)(Current + O12236[Dtype(Current)-1451]), arg1);
}

/* {EV_TEXT_IMP}.scroll_to_line */
void F1452_15419 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc1));
	if (*(EIF_BOOLEAN *)(Current + O12237[dtype-1451])) {
		tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
		tp2 = F260_4057(RTCW(loc1));
		gtk_text_buffer_get_start_iter((GtkTextBuffer*) tp1, (GtkTextIter*) tp2);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN)(loc2 == arg1)) break;
			tp1 = *(EIF_POINTER *)(Current + O12234[dtype-1451]);
			tp2 = F260_4057(RTCW(loc1));
			loc3 = (EIF_BOOLEAN) EIF_TEST(gtk_text_view_forward_display_line((GtkTextView*) tp1, (GtkTextIter*) tp2));
			loc2++;
		}
	} else {
		tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
		tp2 = F260_4057(RTCW(loc1));
		gtk_text_buffer_get_iter_at_line((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (gint) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)));
	}
	loc4 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr1 = RTMS_EX_H("scroll_to_line",14,1576456805);
	F928_6962(RTCW(loc4), tr1);
	tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tp2 = *(EIF_POINTER *)(RTCW(loc4)+ _PTROFF_0_1_0_1_0_0_);
	tp3 = F260_4057(RTCW(loc1));
	loc5 = (EIF_POINTER) gtk_text_buffer_create_mark((GtkTextBuffer*) tp1, (gchar*) tp2, (GtkTextIter*) tp3, (gboolean) (EIF_BOOLEAN) 1);
	tp1 = *(EIF_POINTER *)(Current + O12234[dtype-1451]);
	gtk_text_view_scroll_to_mark((GtkTextView*) tp1, (GtkTextMark*) loc5, (gdouble) (EIF_REAL_64) 0.0, (gboolean) (EIF_BOOLEAN) 1, (gdouble) (EIF_REAL_64) 0.0, (gdouble) (EIF_REAL_64) 0.0);
	tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	gtk_text_buffer_delete_mark((GtkTextBuffer*) tp1, (GtkTextMark*) loc5);
	RTLE;
}

/* {EV_TEXT_IMP}.enable_word_wrapping */
void F1452_15421 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12235[dtype-1451]);
	ti4_1 = (EIF_INTEGER_32) GTK_POLICY_AUTOMATIC;
	ti4_2 = (EIF_INTEGER_32) GTK_POLICY_ALWAYS;
	gtk_scrolled_window_set_policy((GtkScrolledWindow*) tp1, (GtkPolicyType) ti4_1, (GtkPolicyType) ti4_2);
	tp1 = *(EIF_POINTER *)(Current + O12234[dtype-1451]);
	gtk_text_view_set_wrap_mode((GtkTextView*) tp1, (GtkWrapMode) ((EIF_INTEGER_32) 2L));
	*(EIF_BOOLEAN *)(Current + O12237[dtype-1451]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {EV_TEXT_IMP}.disable_word_wrapping */
void F1452_15422 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12235[dtype-1451]);
	ti4_1 = (EIF_INTEGER_32) GTK_POLICY_ALWAYS;
	ti4_2 = (EIF_INTEGER_32) GTK_POLICY_ALWAYS;
	gtk_scrolled_window_set_policy((GtkScrolledWindow*) tp1, (GtkPolicyType) ti4_1, (GtkPolicyType) ti4_2);
	tp1 = *(EIF_POINTER *)(Current + O12234[dtype-1451]);
	gtk_text_view_set_wrap_mode((GtkTextView*) tp1, (GtkWrapMode) ((EIF_INTEGER_32) 0L));
	*(EIF_BOOLEAN *)(Current + O12237[dtype-1451]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {EV_TEXT_IMP}.visual_widget */
EIF_POINTER F1452_15423 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) *(EIF_POINTER *)(Current + O12234[Dtype(Current)-1451]);
}

/* {EV_TEXT_IMP}.c_object_dispose */
void F1452_15424 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
		inline_F100_1400(tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current + O12236[dtype-1451]) = (EIF_POINTER) tp2;
	}
	F1314_13113(Current);
	RTLE;
}

/* {EV_TEXT_IMP}.on_change_actions */
void F1452_15425 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		F813_6165(RTCW(tr1), NULL);
	}
	RTLE;
}

/* {EV_TEXT_IMP}.append_text_internal */
void F1452_15426 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg2);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	loc3 = F1452_15412(Current);
	loc1 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F928_6962(RTCW(loc1), arg2);
	loc2 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc2));
	tp1 = F260_4057(RTCW(loc2));
	gtk_text_buffer_get_end_iter((GtkTextBuffer*) arg1, (GtkTextIter*) tp1);
	tp1 = F260_4057(RTCW(loc2));
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	gtk_text_buffer_insert((GtkTextBuffer*) arg1, (GtkTextIter*) tp1, (gchar*) tp2, (gint) ((EIF_INTEGER_32) -1L));
	F1452_15427(Current, loc3);
	RTLE;
}

/* {EV_TEXT_IMP}.internal_set_caret_position */
void F1452_15427 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc1));
	tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tp2 = F260_4057(RTCW(loc1));
	gtk_text_buffer_get_iter_at_offset((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (gint) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)));
	tp1 = *(EIF_POINTER *)(Current + O12236[dtype-1451]);
	tp2 = F260_4057(RTCW(loc1));
	gtk_text_buffer_place_cursor((GtkTextBuffer*) tp1, (GtkTextIter*) tp2);
	RTLE;
}

void EIF_Minit806 (void)
{
	GTCX
	RTPOMS(15404,0,"",0,0);
}


#ifdef __cplusplus
}
#endif
