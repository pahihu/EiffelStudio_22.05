
#ifndef _C17_ev809_
#define _C17_ev809_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1455_15547(EIF_REFERENCE);
extern void EIF_Minit809(void);
extern void F1454_15507(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
