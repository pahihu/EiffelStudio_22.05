
#ifndef _C17_ev839_
#define _C17_ev839_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1485_15916(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F1485_15917(EIF_REFERENCE);
extern void F1485_15918(EIF_REFERENCE);
extern void F1485_15920(EIF_REFERENCE, EIF_REFERENCE);
extern void F1485_15921(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit839(void);
extern void F1307_13060(EIF_REFERENCE, EIF_REFERENCE);
extern void F1314_13101(EIF_REFERENCE);
extern void F813_6165(EIF_REFERENCE, EIF_REFERENCE);
extern long O10034[];
extern long O1239[];
extern long O12388[];
extern long O1241[];

#ifdef __cplusplus
}
#endif

#endif
