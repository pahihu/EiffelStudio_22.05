
#ifndef _C17_ev844_
#define _C17_ev844_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1490_15931(EIF_REFERENCE);
extern void EIF_Minit844(void);
extern EIF_REFERENCE F1485_15917(EIF_REFERENCE);
extern long O10034[];

#ifdef __cplusplus
}
#endif

#endif
