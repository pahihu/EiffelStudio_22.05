/*
 * Code for class EV_TREE_NODE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev836.h"
#include "eif_built_in.h"
#include <ev_gtk.h>
#include "eif_memory.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F101_1888
static EIF_POINTER inline_F101_1888 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	return (EIF_POINTER) (gtk_tree_model_get_path ((GtkTreeModel*) arg1, (GtkTreeIter*) arg2))
	;
}
#define INLINE_F101_1888
#endif
#ifndef INLINE_F101_1890
static int inline_F101_1890 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	return (int) (gtk_tree_view_row_expanded ((GtkTreeView*) arg1, (GtkTreePath*) arg2))
	;
}
#define INLINE_F101_1890
#endif
#ifndef INLINE_F101_1864
static void inline_F101_1864 (EIF_POINTER arg1)
{
	gtk_tree_path_free ((GtkTreePath*) arg1)
	;
}
#define INLINE_F101_1864
#endif
#ifndef INLINE_F101_1897
static EIF_POINTER inline_F101_1897 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_tree_view_get_selection ((GtkTreeView*) arg1))
	;
}
#define INLINE_F101_1897
#endif
#ifndef INLINE_F101_1882
static void inline_F101_1882 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_tree_selection_select_iter ((GtkTreeSelection*) arg1, (GtkTreeIter*) arg2)
	;
}
#define INLINE_F101_1882
#endif
#ifndef INLINE_F101_1883
static void inline_F101_1883 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_tree_selection_unselect_iter ((GtkTreeSelection*) arg1, (GtkTreeIter*) arg2)
	;
}
#define INLINE_F101_1883
#endif
#ifndef INLINE_F101_1892
static void inline_F101_1892 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_tree_view_expand_to_path ((GtkTreeView*) arg1, (GtkTreePath*) arg2)
	;
}
#define INLINE_F101_1892
#endif
#ifndef INLINE_F101_1893
static int inline_F101_1893 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	return (int) (gtk_tree_view_collapse_row ((GtkTreeView*) arg1, (GtkTreePath*) arg2))
	;
}
#define INLINE_F101_1893
#endif
#ifndef INLINE_F101_1950
static void inline_F101_1950 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4)
{
	gtk_tree_store_insert ((GtkTreeStore*) arg1, (GtkTreeIter*) arg2, (GtkTreeIter*) arg3, (gint) arg4)
	;
}
#define INLINE_F101_1950
#endif
#ifndef INLINE_F100_1400
static void inline_F100_1400 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F100_1400
#endif
#ifndef INLINE_F101_1952
static void inline_F101_1952 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_tree_store_remove ((GtkTreeStore*) arg1, (GtkTreeIter*) arg2)
	;
}
#define INLINE_F101_1952
#endif
#ifndef INLINE_F924_6930
static int inline_F924_6930 (void)
{
	return eif_is_in_final_collect;
	;
}
#define INLINE_F924_6930
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TREE_NODE_IMP}.destroy */
void F1482_15854 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1280_12327(Current);
		F1307_13060(loc1, tr1);
	}
	F1280_12342(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_TREE_NODE_IMP}.make */
void F1482_15856 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1482_15896(Current);
	F1308_13068(Current);
	RTLE;
}

/* {EV_TREE_NODE_IMP}.is_selected */
EIF_BOOLEAN F1482_15857 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = F1482_15889(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = F1446_15323(RTCW(loc1));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == tr2);
	}
	RTLE;
	return Result;
}

/* {EV_TREE_NODE_IMP}.is_expanded */
EIF_BOOLEAN F1482_15858 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLIU(3);
	
	RTGC;
	loc2 = F1482_15889(Current);
	RTCT0("par_tree /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	RTCT0("l_list_iter /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = *(EIF_POINTER *)(RTCW(loc2) + O12220[Dtype(loc2)-1445]);
	tp2 = F260_4057(RTCW(loc3));
	loc1 = inline_F101_1888(tp1, tp2);
	tp1 = *(EIF_POINTER *)(RTCW(loc2) + O12223[Dtype(loc2)-1445]);
	Result = EIF_TEST (inline_F101_1890(tp1, loc1));
	inline_F101_1864(loc1);
	RTLE;
	return Result;
}

/* {EV_TREE_NODE_IMP}.x_position */
EIF_INTEGER_32 F1482_15859 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc2 = F1482_15889(Current);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tp1 = *(EIF_POINTER *)(RTCW(loc2) + O12225[Dtype(loc2)-1445]);
		loc1 = (EIF_POINTER) gtk_scrolled_window_get_hadjustment((GtkScrolledWindow*) tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc1 != tp1)) {
			tr4_1 = (EIF_REAL_32) gtk_adjustment_get_value((GtkAdjustment*) loc1);
			tr1 = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
			*(EIF_REAL_32 *)tr1 = tr4_1;
			Result = F1014_8797(RTCW(tr1));
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -Result;
		}
	}
	RTLE;
	return Result;
}

/* {EV_TREE_NODE_IMP}.y_position */
EIF_INTEGER_32 F1482_15860 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc2 = F1482_15889(Current);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_25_6_6_0_);
		ti4_1 = F1446_15355(RTCW(loc2));
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result - ((EIF_INTEGER_32) 1L)) * ti4_1);
		tp1 = *(EIF_POINTER *)(RTCW(loc2) + O12225[Dtype(loc2)-1445]);
		loc1 = (EIF_POINTER) gtk_scrolled_window_get_vadjustment((GtkScrolledWindow*) tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc1 != tp1)) {
			tr4_1 = (EIF_REAL_32) gtk_adjustment_get_value((GtkAdjustment*) loc1);
			tr1 = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
			*(EIF_REAL_32 *)tr1 = tr4_1;
			ti4_1 = F1014_8797(RTCW(tr1));
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result - ti4_1);
		}
	}
	RTLE;
	return Result;
}

/* {EV_TREE_NODE_IMP}.screen_x */
EIF_INTEGER_32 F1482_15861 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1482_15889(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		Result = F1315_13126(RTCW(loc1));
		ti4_1 = F1482_15859(Current);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	}
	RTLE;
	return Result;
}

/* {EV_TREE_NODE_IMP}.screen_y */
EIF_INTEGER_32 F1482_15862 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1482_15889(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		Result = F1315_13127(RTCW(loc1));
		ti4_1 = F1482_15860(Current);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	}
	RTLE;
	return Result;
}

/* {EV_TREE_NODE_IMP}.width */
EIF_INTEGER_32 F1482_15863 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1482_15889(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		ti4_1 = F1366_13919(RTCW(loc1));
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_TREE_NODE_IMP}.height */
EIF_INTEGER_32 F1482_15864 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1482_15889(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		ti4_1 = F1446_15355(RTCW(loc1));
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_TREE_NODE_IMP}.minimum_width */
EIF_INTEGER_32 F1482_15865 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1482_15889(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		ti4_1 = F1315_13131(RTCW(loc1));
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_TREE_NODE_IMP}.minimum_height */
EIF_INTEGER_32 F1482_15866 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1482_15889(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		ti4_1 = F1446_15355(RTCW(loc1));
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_TREE_NODE_IMP}.enable_select */
void F1482_15867 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc2 = F1482_15889(Current);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		loc3 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		RTCT0("l_list_iter /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tp1 = *(EIF_POINTER *)(RTCW(loc2) + O12223[Dtype(loc2)-1445]);
		loc1 = inline_F101_1897(tp1);
		tp1 = F260_4057(RTCW(loc3));
		inline_F101_1882(loc1, tp1);
		tr1 = F1280_12327(Current);
		F1446_15327(RTCW(loc2), tr1);
	}
	RTLE;
}

/* {EV_TREE_NODE_IMP}.disable_select */
void F1482_15868 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLIU(3);
	
	RTGC;
	loc2 = F1482_15889(Current);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		loc3 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		RTCT0("l_list_iter /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tp1 = *(EIF_POINTER *)(RTCW(loc2) + O12223[Dtype(loc2)-1445]);
		loc1 = inline_F101_1897(tp1);
		tp1 = F260_4057(RTCW(loc3));
		inline_F101_1883(loc1, tp1);
	}
	RTLE;
}

/* {EV_TREE_NODE_IMP}.set_expand */
void F1482_15869 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLIU(3);
	
	RTGC;
	loc2 = F1482_15889(Current);
	RTCT0("par_tree /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	RTCT0("l_list_iter /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = *(EIF_POINTER *)(RTCW(loc2) + O12220[Dtype(loc2)-1445]);
	tp2 = F260_4057(RTCW(loc4));
	loc1 = inline_F101_1888(tp1, tp2);
	if (arg1) {
		tp1 = *(EIF_POINTER *)(RTCW(loc2) + O12223[Dtype(loc2)-1445]);
		inline_F101_1892(tp1, loc1);
	} else {
		tp1 = *(EIF_POINTER *)(RTCW(loc2) + O12223[Dtype(loc2)-1445]);
		loc3 = EIF_TEST (inline_F101_1893(tp1, loc1));
	}
	inline_F101_1864(loc1);
	RTLE;
}

/* {EV_TREE_NODE_IMP}.set_text */
void F1482_15870 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = F1078_9452(RTCW(arg1));
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
	loc1 = F1482_15889(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1446_15350(RTCW(loc1), Current, *(EIF_REFERENCE *)(Current + _REFACS_22_));
	}
	RTLE;
}

/* {EV_TREE_NODE_IMP}.enable_transport */
void F1482_15871 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_25_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = F1482_15889(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1446_15332(loc1);
	}
	RTLE;
}

/* {EV_TREE_NODE_IMP}.draw_rubber_band */
void F1482_15873 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_TREE_NODE_IMP}.erase_rubber_band */
void F1482_15874 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_TREE_NODE_IMP}.internal_set_pointer_style */
void F1482_15880 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {EV_TREE_NODE_IMP}.is_transport_enabled_iterator */
EIF_BOOLEAN F1482_15881 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLIU(5);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_25_1_)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		if ((EIF_BOOLEAN) (F1308_13070(Current) > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
			loc1 = F664_5458(RTCW(tr1));
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				tb1 = '\01';
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
				ti4_1 = F664_5468(RTCW(tr1));
				if (!(EIF_BOOLEAN) (loc2 > ti4_1)) {
					tb1 = Result;
				}
				if (tb1) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
				tr1 = F664_5453(RTCW(tr1), loc2);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					RTCT0("attached {EV_TREE_NODE_IMP} ch.implementation as a_tree_node_imp", EX_CHECK);
					tr1 = *(EIF_REFERENCE *)(loc3 + _REFACS_3_);
					loc4 = tr1;
					loc4 = RTRV(eif_new_type(1481, 0x00),loc4);
					if (EIF_TEST(loc4)) {
						RTCK0;
					} else {
						RTCF0;
					}
					Result = F1482_15881(loc4);
				}
				loc2++;
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
			F664_5483(RTCW(tr1), loc1);
		}
	}
	RTLE;
	return Result;
}

/* {EV_TREE_NODE_IMP}.able_to_transport */
EIF_BOOLEAN F1482_15883 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	tb1 = '\0';
	if (F1363_13811(Current)) {
		tb1 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L));
	}
	if (!tb1) {
		tb1 = '\0';
		tb2 = '\0';
		if (F1363_13810(Current)) {
			tb2 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 3L));
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN) !F1363_13813(Current);
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {EV_TREE_NODE_IMP}.ready_for_pnd_menu */
EIF_BOOLEAN F1482_15884 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\01';
	if (!F1363_13812(Current)) {
		tb2 = F1363_13813(Current);
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 3L));
	}
	if (tb1) {
		Result = (EIF_BOOLEAN) !arg2;
	}
	RTLE;
	return Result;
}

/* {EV_TREE_NODE_IMP}.set_list_iter */
void F1482_15885 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) arg1;
}

/* {EV_TREE_NODE_IMP}.set_parent_imp */
void F1482_15887 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) arg1;
}

/* {EV_TREE_NODE_IMP}.parent_imp */
EIF_REFERENCE F1482_15888 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_24_);
}


/* {EV_TREE_NODE_IMP}.parent_tree_imp */
EIF_REFERENCE F1482_15889 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1481_15846(Current);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1445, 0),loc1);
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {EV_TREE_NODE_IMP}.add_item_and_children_to_parent_tree */
void F1482_15890 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg2);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,Current);
	RTLR(5,arg1);
	RTLR(6,loc5);
	RTLIU(7);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_21_);
		loc4 = tr1;
		tb1 = EIF_TEST(loc4);
	}
	if (tb1) {
		loc3 = F260_4057(loc4);
	}
	loc1 = RTLNS(eif_new_type(261, 0x00).id, 261, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc1));
	F1482_15885(Current, loc1);
	tp1 = *(EIF_POINTER *)(RTCW(arg1) + O12220[Dtype(arg1)-1445]);
	tp2 = F260_4057(RTCW(loc1));
	inline_F101_1950(tp1, tp2, loc3, (EIF_INTEGER_32) (arg3 - ((EIF_INTEGER_32) 1L)));
	tr1 = F1482_15894(Current);
	F1446_15350(RTCW(arg1), Current, tr1);
	F1446_15352(RTCW(arg1), Current);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		ti4_1 = F664_5468(RTCW(tr1));
		if ((EIF_BOOLEAN) (loc2 > ti4_1)) break;
		RTCT0("attached {EV_TREE_NODE_IMP} (child_array [i]).implementation as item_imp", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		tr1 = F664_5453(RTCW(tr1), loc2);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		loc5 = tr1;
		loc5 = RTRV(eif_new_type(1481, 0x00),loc5);
		if (EIF_TEST(loc5)) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1482_15890(loc5, arg1, Current, loc2);
		loc2++;
	}
	RTLE;
}

/* {EV_TREE_NODE_IMP}.update_for_pick_and_drop */
void F1482_15891 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	RTGC;
}

/* {EV_TREE_NODE_IMP}.ensure_expandable */
void F1482_15892 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(tr1));
	F1482_15908(Current, tr1, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4440[Dtype(RTCW(tr1))-534])(tr1);
	RTLE;
}

/* {EV_TREE_NODE_IMP}.remove_expandable */
void F1482_15893 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1445, 0x00),loc1);
	if (EIF_TEST(loc1)) {
	}
	RTLE;
}

/* {EV_TREE_NODE_IMP}.text */
EIF_REFERENCE F1482_15894 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	RTLE;
	return Result;
}

/* {EV_TREE_NODE_IMP}.tooltip */
EIF_REFERENCE F1482_15895 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		Result = F1078_9452(RTMS_EX_H("",0,0));
	}
	RTLE;
	return Result;
}

/* {EV_TREE_NODE_IMP}.remove_internal_text */
RTEOMS(15895,1);
void F1482_15896 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1078_9452(RTOMS(15895,0));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {EV_TREE_NODE_IMP}.set_tooltip */
void F1482_15900 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1078_9452(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {EV_TREE_NODE_IMP}.set_pixmap */
void F1482_15902 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_25_6_6_3_0_0_) != tp1)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_25_6_6_3_0_0_);
		inline_F100_1400(tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_25_6_6_3_0_0_) = (EIF_POINTER) tp2;
	}
	RTCT0("attached {EV_PIXMAP_IMP} a_pixmap.implementation as a_pix_imp", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1513, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = F1510_16265(loc2);
	*(EIF_POINTER *)(Current+ _PTROFF_25_6_6_3_0_0_) = (EIF_POINTER) tp1;
	loc1 = F1482_15889(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1446_15352(RTCW(loc1), Current);
	}
	RTLE;
}

/* {EV_TREE_NODE_IMP}.remove_pixmap */
void F1482_15905 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_25_6_6_3_0_0_) != tp1)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_25_6_6_3_0_0_);
		inline_F100_1400(tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_25_6_6_3_0_0_) = (EIF_POINTER) tp2;
	}
	loc1 = F1482_15889(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1446_15352(RTCW(loc1), Current);
	}
	RTLE;
}

/* {EV_TREE_NODE_IMP}.pixmap */
EIF_REFERENCE F1482_15906 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_25_6_6_3_0_0_) != tp1)) {
		Result = RTLNS(eif_new_type(1278, 0x00).id, 1278, _OBJSIZ_6_3_0_1_0_0_0_0_);
		F1088_9856(RTCW(Result));
		RTCT0("attached {EV_PIXMAP_IMP} Result.implementation as pix_imp", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_3_);
		loc1 = tr1;
		loc1 = RTRV(eif_new_type(1513, 0x00),loc1);
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1514_16437(loc1, *(EIF_POINTER *)(Current+ _PTROFF_25_6_6_3_0_0_));
	}
	RTLE;
	return Result;
}

/* {EV_TREE_NODE_IMP}.insert_i_th */
void F1482_15908 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	RTCT0("attached {EV_TREE_NODE_IMP} v.implementation as item_imp", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1481, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F1482_15887(loc2, Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F664_5482(RTCW(tr1), arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4583[Dtype(RTCW(tr1))-663])(tr1, arg1);
	loc1 = F1482_15889(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1482_15890(loc2, loc1, Current, arg2);
		tb1 = F1482_15881(loc2);
		if (tb1) {
			F1446_15333(RTCW(loc1), (EIF_BOOLEAN) 1);
		}
	}
	tb1 = '\0';
	if ((EIF_BOOLEAN)(F1308_13070(Current) == ((EIF_INTEGER_32) 1L))) {
		tb1 = (EIF_BOOLEAN)(loc1 != NULL);
	}
	if (tb1) {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			F688_5577(RTCW(tr1));
		}
		F1482_15869(Current, *(EIF_BOOLEAN *)(Current+ _CHROFF_25_3_));
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			F688_5579(RTCW(tr1));
		}
	}
	RTLE;
}

/* {EV_TREE_NODE_IMP}.remove_i_th */
void F1482_15909 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(F1308_13070(Current) == ((EIF_INTEGER_32) 1L))) {
		if ((EIF_BOOLEAN)(F1481_15846(Current) != NULL)) {
			tb1 = F1482_15858(Current);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_25_3_) = (EIF_BOOLEAN) tb1;
		} else {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_25_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
	}
	RTCT0("attached {EV_TREE_NODE_IMP} (child_array [a_position]).implementation as item_imp", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	tr1 = F664_5453(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc3 = tr1;
	loc3 = RTRV(eif_new_type(1481, 0x00),loc3);
	if (EIF_TEST(loc3)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc1 = F1482_15889(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		loc2 = *(EIF_REFERENCE *)(loc3 + _REFACS_21_);
		RTCT0("l_list_iter /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tp1 = *(EIF_POINTER *)(RTCW(loc1) + O12220[Dtype(loc1)-1445]);
		tp2 = F260_4057(RTCW(loc2));
		inline_F101_1952(tp1, tp2);
	}
	F1482_15887(loc3, NULL);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F664_5482(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4455[Dtype(RTCW(tr1))-534])(tr1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1446_15332(RTCW(loc1));
	}
	RTLE;
}

/* {EV_TREE_NODE_IMP}.real_pointed_target */
EIF_REFERENCE F1482_15911 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {EV_TREE_NODE_IMP}.dispose */
void F1482_15912 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN) !EIF_TEST (inline_F924_6930())) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_25_6_6_3_0_0_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_25_6_6_3_0_0_);
		inline_F100_1400(tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_25_6_6_3_0_0_) = (EIF_POINTER) tp2;
	}
	RTLE;
}

void EIF_Minit836 (void)
{
	GTCX
	RTPOMS(15895,0,"",0,0);
}


#ifdef __cplusplus
}
#endif
