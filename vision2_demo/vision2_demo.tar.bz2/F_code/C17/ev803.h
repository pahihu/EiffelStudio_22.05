
#ifndef _C17_ev803_
#define _C17_ev803_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1449_15371(EIF_REFERENCE);
extern void EIF_Minit803(void);
extern void F1441_15182(EIF_REFERENCE);
extern void F1314_13098(EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif

#endif
