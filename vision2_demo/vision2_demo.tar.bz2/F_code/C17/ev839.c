/*
 * Code for class EV_ITEM_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev839.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ITEM_IMP}.call_button_event_actions */
void F1485_15916 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,8,997,1033,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNTS(typres0.id, 9, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg2;
	((EIF_TYPED_VALUE *)tr1+2)->it_i4 = arg3;
	((EIF_TYPED_VALUE *)tr1+3)->it_i4 = arg4;
	((EIF_TYPED_VALUE *)tr1+4)->it_r8 = arg5;
	((EIF_TYPED_VALUE *)tr1+5)->it_r8 = arg6;
	((EIF_TYPED_VALUE *)tr1+6)->it_r8 = arg7;
	((EIF_TYPED_VALUE *)tr1+7)->it_i4 = arg8;
	((EIF_TYPED_VALUE *)tr1+8)->it_i4 = arg9;
	loc1 = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_PRESS)) {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O1239[dtype-80]) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O1239[dtype-80]);
			F813_6165(RTCW(tr1), loc1);
		}
	} else {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O1241[dtype-80]) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O1241[dtype-80]);
			F813_6165(RTCW(tr1), loc1);
		}
	}
	RTLE;
}

/* {EV_ITEM_IMP}.parent_imp */
EIF_REFERENCE F1485_15917 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + O12388[Dtype(Current)-1484]);
}

/* {EV_ITEM_IMP}.destroy */
void F1485_15918 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\0';
	tr1 = F1485_15917(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O10034[dtype-1279]) != NULL);
	}
	if (tb1) {
		F1307_13060(loc1, *(EIF_REFERENCE *)(Current + O10034[dtype-1279]));
	}
	F1314_13101(Current);
	RTLE;
}

/* {EV_ITEM_IMP}.set_item_parent_imp */
void F1485_15920 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O12388[Dtype(Current)-1484]) = (EIF_REFERENCE) arg1;
}

/* {EV_ITEM_IMP}.update_for_pick_and_drop */
void F1485_15921 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	RTGC;
}

void EIF_Minit839 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
