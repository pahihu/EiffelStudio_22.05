
#ifndef _C17_ev835_
#define _C17_ev835_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1481_15844(EIF_REFERENCE);
extern EIF_REFERENCE F1481_15846(EIF_REFERENCE);
extern EIF_BOOLEAN F1481_15847(EIF_REFERENCE);
extern void EIF_Minit835(void);
extern long O10034[];

#ifdef __cplusplus
}
#endif

#endif
