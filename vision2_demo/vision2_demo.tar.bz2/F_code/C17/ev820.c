/*
 * Code for class EV_RANGE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev820.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_RANGE_IMP}.make */
void F1466_15703 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1464_15676(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_13_10_7_0_0_);
	gtk_scale_set_digits((GtkScale*) tp1, (gint) ((EIF_INTEGER_32) 0L));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_13_10_7_0_0_);
	gtk_scale_set_draw_value((GtkScale*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	RTLE;
}

void EIF_Minit820 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
