
#ifndef _C17_ev833_
#define _C17_ev833_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1479_15797(EIF_REFERENCE);
extern EIF_REFERENCE F1479_15798(EIF_REFERENCE);
extern void EIF_Minit833(void);
extern EIF_BOOLEAN F1121_10333(EIF_REFERENCE);
extern EIF_REFERENCE F1475_15739(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
