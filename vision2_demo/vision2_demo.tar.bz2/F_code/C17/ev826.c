/*
 * Code for class EV_SCROLL_BAR_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev826.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SCROLL_BAR_IMP}.set_leap */
void F1472_15732 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(F1464_15680(Current) != arg1)) {
		tp1 = F1464_15692(Current);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
		tr4_1 = (EIF_REAL_32) ((EIF_INTEGER_32) (ti4_1 + arg1));
		gtk_adjustment_set_upper((GtkAdjustment*) tp1, (gdouble) tr4_1);
		tp1 = F1464_15692(Current);
		tr4_1 = (EIF_REAL_32) (arg1);
		gtk_adjustment_set_page_increment((GtkAdjustment*) tp1, (gdouble) tr4_1);
		tp1 = F1464_15692(Current);
		tr4_1 = (EIF_REAL_32) (arg1);
		gtk_adjustment_set_page_size((GtkAdjustment*) tp1, (gdouble) tr4_1);
	}
	RTLE;
}

/* {EV_SCROLL_BAR_IMP}.internal_set_upper */
void F1472_15733 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tp1 = F1464_15692(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
	tr4_1 = (EIF_REAL_32) ((EIF_INTEGER_32) (ti4_1 + F1464_15680(Current)));
	gtk_adjustment_set_upper((GtkAdjustment*) tp1, (gdouble) tr4_1);
	RTLE;
}

void EIF_Minit826 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
