/*
 * Code for class EV_PASSWORD_FIELD_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev809.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PASSWORD_FIELD_IMP}.make */
void F1455_15547 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1454_15507(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	gtk_entry_set_visibility((GtkEntry*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	RTLE;
}

void EIF_Minit809 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
