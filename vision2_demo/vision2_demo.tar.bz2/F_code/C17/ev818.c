/*
 * Code for class EV_GAUGE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev818.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GAUGE_IMP}.make */
void F1464_15676 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1441_15182(Current);
	F1464_15677(Current);
	tp1 = *(EIF_POINTER *)(Current + O10619[Dtype(Current)-1313]);
	gtk_widget_set_redraw_on_allocate((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_GAUGE_IMP}.ev_gauge_imp_initialize */
void F1464_15677 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(576, 0).id);
	F576_4884(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O12147[dtype-1429]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O12147[dtype-1429]);
	tr1 = F577_4929(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A818_424, (EIF_POINTER) _A818_424, (EIF_POINTER)(F1464_15689),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tp1 = F1464_15692(Current);
	tr1 = RTOSCF(373,F16_373, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,960,1069,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(13123,F1314_13123, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	tp2 = *(EIF_POINTER *)(Current + O10619[dtype-1313]);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = tp2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A391_332, (EIF_POINTER) _A391_332, (EIF_POINTER)(F942_7744),tr2, 1, 0);
	}
	F1314_13102(Current, tp1, tr1, tr3);
	F1464_15689(Current);
	RTLE;
}

/* {EV_GAUGE_IMP}.value */
EIF_INTEGER_32 F1464_15678 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tp1 = F1464_15692(Current);
	tr4_1 = (EIF_REAL_32) gtk_adjustment_get_value((GtkAdjustment*) tp1);
	tr1 = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = tr4_1;
	Result = F1014_8797(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_GAUGE_IMP}.step */
EIF_INTEGER_32 F1464_15679 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tp1 = F1464_15692(Current);
	tr4_1 = (EIF_REAL_32) gtk_adjustment_get_step_increment((GtkAdjustment*) tp1);
	tr1 = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = tr4_1;
	Result = F1014_8797(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_GAUGE_IMP}.leap */
EIF_INTEGER_32 F1464_15680 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tp1 = F1464_15692(Current);
	tr4_1 = (EIF_REAL_32) gtk_adjustment_get_page_increment((GtkAdjustment*) tp1);
	tr1 = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = tr4_1;
	Result = F1014_8797(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_GAUGE_IMP}.set_value */
void F1464_15686 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	F1464_15695(Current, arg1);
}

/* {EV_GAUGE_IMP}.set_step */
void F1464_15687 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REAL_32 tr4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(F1464_15679(Current) != arg1)) {
		tp1 = F1464_15692(Current);
		tr4_1 = (EIF_REAL_32) (arg1);
		gtk_adjustment_set_step_increment((GtkAdjustment*) tp1, (gdouble) tr4_1);
	}
	RTLE;
}

/* {EV_GAUGE_IMP}.set_leap */
void F1464_15688 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(F1464_15680(Current) != arg1)) {
		tp1 = F1464_15692(Current);
		tr1 = *(EIF_REFERENCE *)(Current + O12147[Dtype(Current)-1429]);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
		tr4_1 = (EIF_REAL_32) (ti4_1);
		gtk_adjustment_set_upper((GtkAdjustment*) tp1, (gdouble) tr4_1);
		tp1 = F1464_15692(Current);
		tr4_1 = (EIF_REAL_32) (arg1);
		gtk_adjustment_set_page_increment((GtkAdjustment*) tp1, (gdouble) tr4_1);
	}
	RTLE;
}

/* {EV_GAUGE_IMP}.set_range */
void F1464_15689 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = F1464_15678(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O12147[dtype-1429]);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
	if ((EIF_BOOLEAN) (loc1 > ti4_1)) {
		tr1 = *(EIF_REFERENCE *)(Current + O12147[dtype-1429]);
		loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O12147[dtype-1429]);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_1_);
		if ((EIF_BOOLEAN) (loc1 < ti4_1)) {
			tr1 = *(EIF_REFERENCE *)(Current + O12147[dtype-1429]);
			loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_1_);
		}
	}
	tp1 = F1464_15692(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O12147[dtype-1429]);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_1_);
	tr4_1 = (EIF_REAL_32) (ti4_1);
	gtk_adjustment_set_lower((GtkAdjustment*) tp1, (gdouble) tr4_1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R12320[dtype-1464])(Current);
	F1464_15695(Current, loc1);
	RTLE;
}

/* {EV_GAUGE_IMP}.internal_set_upper */
void F1464_15691 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tp1 = F1464_15692(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O12147[Dtype(Current)-1429]);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
	tr4_1 = (EIF_REAL_32) (ti4_1);
	gtk_adjustment_set_upper((GtkAdjustment*) tp1, (gdouble) tr4_1);
	RTLE;
}

/* {EV_GAUGE_IMP}.adjustment */
EIF_POINTER F1464_15692 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O12322[dtype-1463]) == tp1)) {
		tp1 = (EIF_POINTER) gtk_adjustment_new((gfloat) (EIF_REAL_32) 0.0, (gfloat) (EIF_REAL_32) 0.0, (gfloat) (EIF_REAL_32) 100.0, (gfloat) (EIF_REAL_32) 1.0, (gfloat) (EIF_REAL_32) 10.0, (gfloat) (EIF_REAL_32) 0.0);
		*(EIF_POINTER *)(Current + O12322[dtype-1463]) = (EIF_POINTER) tp1;
	}
	RTLE;
	return (EIF_POINTER) *(EIF_POINTER *)(Current + O12322[dtype-1463]);
}

/* {EV_GAUGE_IMP}.internal_set_value */
void F1464_15695 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REAL_32 tr4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(F1464_15678(Current) != arg1)) {
		tp1 = F1464_15692(Current);
		tr4_1 = (EIF_REAL_32) (arg1);
		gtk_adjustment_set_value((GtkAdjustment*) tp1, (gfloat) tr4_1);
		if (F1315_13155(Current)) {
			F1366_13933(Current);
		}
	}
	RTLE;
}

/* {EV_GAUGE_IMP}.value_changed_handler */
void F1464_15696 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1033,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 1);
		}
		ti4_1 = F1464_15678(Current);
		((EIF_TYPED_VALUE *)tr2+1)->it_i4 = ti4_1;
		F813_6165(RTCW(tr1), tr2);
	}
	RTLE;
}

void EIF_Minit818 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
