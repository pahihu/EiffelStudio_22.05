/*
 * Code for class EV_VERTICAL_RANGE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev821.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_VERTICAL_RANGE_IMP}.make */
void F1467_15705 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1464_15692(Current);
	tp1 = (EIF_POINTER) gtk_scale_new((GtkOrientation) (EIF_NATURAL_8) ((EIF_INTEGER_32) 1L), (GtkAdjustment*) tp1);
	F1314_13098(Current, tp1);
	F1466_15703(Current);
	RTLE;
}

void EIF_Minit821 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
