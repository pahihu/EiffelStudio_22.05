/*
 * Code for class EV_MENU_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev849.h"
#include <ev_gtk.h>
#include "ev_c_util.h"
#include "ev_any_imp.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1495_15972
static void inline_F1495_15972 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	g_object_set_data (
    G_OBJECT (arg1),
    "eif_oid",
    (gpointer) (rt_int_ptr) arg2
);
	;
}
#define INLINE_F1495_15972
#endif
#ifndef INLINE_F1495_15973
static void inline_F1495_15973 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_NATURAL_32 arg5)
{
	{
     /* From: https://git.eclipse.org/c/platform/eclipse.platform.swt.git/commit/?id=7714fdbf1ce0110744da9c164486c12254d5bd6f
	 *  GTK Feature: gtk_menu_popup is deprecated as of GTK3.22 and the new method gtk_menu_popup_at_pointer
	 *  requires an event to hook on to. This requires the popup & events related to the menu be handled
	 *  immediately and not as a post event in display, requiring the current event.
	 */
	GdkEvent *event_ptr = gtk_get_current_event();
	if (event_ptr == NULL) {
		GdkEvent *event = gdk_event_new (GDK_BUTTON_PRESS);
		((GdkEventButton*)event)->time = (guint32) arg5;
		((GdkEventButton*)event)->x = (gdouble) arg2;
		((GdkEventButton*)event)->y = (gdouble) arg3;
		((GdkEventButton*)event)->type = GDK_BUTTON_PRESS;
		((GdkEventButton*)event)->button = (guint) arg4;
		gtk_widget_realize (arg1);
		((GdkEventButton*)event)->window = g_object_ref((GdkWindow*) gtk_widget_get_window ((GtkWidget*) arg1));
		((GdkEventButton*)event)->device = (GdkDevice*) gdk_seat_get_pointer ((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default ()));
		gtk_menu_popup_at_pointer ((GtkMenu*) arg1, event);
		gdk_event_free (event);
	} else {
		gtk_menu_popup_at_pointer ((GtkMenu*) arg1, event_ptr);
		gdk_event_free (event_ptr);
	}	
}
	;
}
#define INLINE_F1495_15973
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MENU_IMP}.make */
void F1495_15969 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1492_15937(Current);
	tp1 = (EIF_POINTER) gtk_menu_new();
	*(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = F1492_15943(Current);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = F1492_15943(Current);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
	gtk_menu_item_set_submenu((GtkMenuItem*) tp1, (GtkWidget*) tp2);
	F1308_13068(Current);
	F1341_13572(Current);
	F1492_15944(Current);
	RTLE;
}

/* {EV_MENU_IMP}.show_at */
void F1495_15971 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN) (F1308_13070(Current) > ((EIF_INTEGER_32) 0L))) {
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			loc1 = F1106_10140(RTCW(arg1));
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + arg2);
			loc2 = F1106_10141(RTCW(arg1));
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + arg3);
		} else {
			loc1 = (EIF_INTEGER_32) arg2;
			loc2 = (EIF_INTEGER_32) arg3;
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(13123,F1314_13123, (Current)))+ _LNGOFF_49_16_0_11_);
		loc1 -= ti4_1;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(13123,F1314_13123, (Current)))+ _LNGOFF_49_16_0_12_);
		loc2 -= ti4_1;
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
		ti4_1 = F938_7628(Current);
		inline_F1495_15972(tp1, ti4_1);
		tr1 = RTOSCF(13123,F1314_13123, (Current));
		F1305_12902(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_12_));
		tr1 = RTOSCF(13123,F1314_13123, (Current));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,6,997,0,1069,1033,1033,1033,1006,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 7, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
		((EIF_TYPED_VALUE *)tr2+2)->it_p = tp1;
		((EIF_TYPED_VALUE *)tr2+3)->it_i4 = loc1;
		((EIF_TYPED_VALUE *)tr2+4)->it_i4 = loc2;
		((EIF_TYPED_VALUE *)tr2+5)->it_i4 = ((EIF_INTEGER_32) 0L);
		tu4_1 = (EIF_NATURAL_32) gtk_get_current_event_time();
		((EIF_TYPED_VALUE *)tr2+6)->it_n4 = tu4_1;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3= RTLNRF(typres0.id, (EIF_POINTER) __A849_326, (EIF_POINTER) _A849_326, (EIF_POINTER)(F1495_15973),tr2, 1, 0);
		}
		F1304_12827(RTCW(tr1), tr3);
	}
	RTLE;
}

/* {EV_MENU_IMP}.couple_object_id_with_gtk_object */
void F1495_15972 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	inline_F1495_15972 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
}

/* {EV_MENU_IMP}.c_gtk_menu_popup_at_pointer */
void F1495_15973 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_NATURAL_32 arg5)
{
	GTCX
	
	
	inline_F1495_15973 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4, (EIF_NATURAL_32) arg5);
}

/* {EV_MENU_IMP}.on_activate */
void F1495_15974 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	loc1 = F1485_15917(Current);
	loc1 = RTRV(eif_new_type(1312, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F72_1157(RTCW(loc1));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y10034,Y10034_gen_type,Dftype(Current),1279);
					typarr0[3] = l_type.annotations | 0xFF00;
					typarr0[4] = l_type.id;
				}
				
				typres0 = eif_compound_id(Dftype(Current), typarr0);
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F1280_12327(Current);
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			F813_6165(RTCW(tr1), tr2);
		}
	}
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F813_6165(RTCW(tr1), NULL);
	}
	RTLE;
}

/* {EV_MENU_IMP}.list_widget */
EIF_POINTER F1495_15976 (EIF_REFERENCE Current)
{
	return *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
}


/* {EV_MENU_IMP}.destroy */
void F1495_15977 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1307_13064(Current);
	F1485_15918(Current);
	RTLE;
}

void EIF_Minit849 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
