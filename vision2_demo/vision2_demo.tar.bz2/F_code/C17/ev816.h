
#ifndef _C17_ev816_
#define _C17_ev816_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F1462_15665(EIF_REFERENCE);
extern void F1462_15666(EIF_REFERENCE);
extern void F1462_15667(EIF_REFERENCE);
extern EIF_BOOLEAN F1462_15668(EIF_REFERENCE);
extern void EIF_Minit816(void);
extern EIF_POINTER F1314_13122(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
