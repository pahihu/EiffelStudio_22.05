/*
 * Code for class EV_MENU_ITEM_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev846.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F17_401
static EIF_NATURAL_8 inline_F17_401 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F17_401
#endif
#ifndef INLINE_F102_2119
static EIF_POINTER inline_F102_2119 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F102_2119
#endif
#ifndef INLINE_F103_2335
static void inline_F103_2335 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_xalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F103_2335
#endif
#ifndef INLINE_F103_2336
static void inline_F103_2336 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_yalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F103_2336
#endif
#ifndef INLINE_F103_2143
static EIF_POINTER inline_F103_2143 (void)
{
	return gtk_settings_get_default();
	;
}
#define INLINE_F103_2143
#endif
#ifndef INLINE_F23_518
static EIF_POINTER inline_F23_518 (void)
{
	static char *v = "gtk-menu-images";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_518
#endif
#ifndef INLINE_F101_1996
static void inline_F101_1996 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	g_object_set((gpointer) arg1, (gchar*) arg2, arg3 ? TRUE : FALSE, NULL)
	;
}
#define INLINE_F101_1996
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MENU_ITEM_IMP}.make */
RTEOMS(15936,1);
void F1492_15937 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R12393[dtype-1491])(Current);
	F1315_13125(Current);
	tp1 = F1492_15943(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,960,1069,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	tr2 = *(EIF_REFERENCE *)(RTCV(RTOSCF(13123,F1314_13123, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
	RTAR(tr1,tr2);
	tp2 = *(EIF_POINTER *)(Current + O10619[dtype-1313]);
	((EIF_TYPED_VALUE *)tr1+2)->it_p = tp2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2= RTLNRF(typres0.id, (EIF_POINTER) __A391_338, (EIF_POINTER) _A391_338, (EIF_POINTER)(F942_7750),tr1, 1, 0);
	}
	F1314_13103(Current, tp1, RTOMS(15936,0), tr2);
	F1343_13585(Current);
	tu1_1 = inline_F17_401();
	loc1 = inline_F102_2119(tu1_1, ((EIF_INTEGER_32) 0L));
	tp1 = F1492_15943(Current);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) loc1);
	gtk_widget_show((GtkWidget*) loc1);
	tp1 = *(EIF_POINTER *)(Current + O11017[dtype-1340]);
	tb1 = !tp1;
	if (tb1) {
		F1341_13572(Current);
		tp1 = *(EIF_POINTER *)(Current + O11017[dtype-1340]);
		gtk_box_pack_start((GtkBox*) loc1, (GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	}
	tp1 = *(EIF_POINTER *)(Current + O11026[dtype-1342]);
	gtk_box_pack_start((GtkBox*) loc1, (GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	tp1 = (EIF_POINTER) gtk_label_new((gchar*) tp2);
	*(EIF_POINTER *)(Current + O12394[dtype-1491]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O12394[dtype-1491]);
	inline_F103_2335(tp1, (EIF_REAL_32) 1.0);
	tp1 = *(EIF_POINTER *)(Current + O12394[dtype-1491]);
	inline_F103_2336(tp1, (EIF_REAL_32) 0.5);
	tp1 = *(EIF_POINTER *)(Current + O12394[dtype-1491]);
	gtk_box_pack_start((GtkBox*) loc1, (GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 1, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 2L));
	tp1 = *(EIF_POINTER *)(Current + O12394[dtype-1491]);
	ti4_1 = (EIF_INTEGER_32) GTK_JUSTIFY_RIGHT;
	gtk_label_set_justify((GtkLabel*) tp1, (GtkJustification) ti4_1);
	tp1 = inline_F103_2143();
	tp2 = inline_F23_518();
	inline_F101_1996(tp1, tp2, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_MENU_ITEM_IMP}.initialize_menu_item */
void F1492_15938 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (EIF_POINTER) gtk_menu_item_new();
	F1314_13098(Current, tp1);
	F1341_13572(Current);
	F1492_15944(Current);
	RTLE;
}

/* {EV_MENU_ITEM_IMP}.needs_event_box */
EIF_BOOLEAN F1492_15939 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

/* {EV_MENU_ITEM_IMP}.is_dockable */
EIF_BOOLEAN F1492_15940 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

/* {EV_MENU_ITEM_IMP}.set_text */
void F1492_15942 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\011';
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_CHARACTER_32)) R7828[Dtype(RTCW(arg1))-1081])(arg1, tw1);
	if (tb1) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\011';
		loc1 = F1078_9471(RTCW(arg1), tw1);
	}
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4462[Dtype(RTCW(loc1))-534])(loc1);
		tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L));
	}
	if (tb1) {
		ti4_1 = ((EIF_INTEGER_32) 1L);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4444[Dtype(RTCW(loc1))-577])(loc1, (EIF_REFERENCE) &ti4_1);
		F1343_13591(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(Current + O11028[dtype-1342]);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\011';
			F1083_9651(loc3, tw1);
			ti4_1 = ((EIF_INTEGER_32) 2L);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4444[Dtype(RTCW(loc1))-577])(loc1, (EIF_REFERENCE) &ti4_1);
			F1083_9637(loc3, tr1);
		} else {
		}
		loc2 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
		tr1 = RTMS32_EX_H(" \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000",12,286432288);
		ti4_1 = ((EIF_INTEGER_32) 2L);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4444[Dtype(RTCW(loc1))-577])(loc1, (EIF_REFERENCE) &ti4_1);
		tr2 = F1078_9452(RTCW(tr2));
		tr1 = F1083_9657(tr1, tr2);
		F928_6962(RTCW(loc2), tr1);
		tp1 = *(EIF_POINTER *)(Current + O12394[dtype-1491]);
		tp2 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_0_1_0_1_0_0_);
		gtk_label_set_text((GtkLabel*) tp1, (gchar*) tp2);
		tp1 = *(EIF_POINTER *)(Current + O12394[dtype-1491]);
		gtk_widget_show((GtkWidget*) tp1);
	} else {
		F1343_13591(Current, arg1);
		tp1 = *(EIF_POINTER *)(Current + O12394[dtype-1491]);
		gtk_widget_hide((GtkWidget*) tp1);
	}
	RTLE;
}

/* {EV_MENU_ITEM_IMP}.menu_item */
EIF_POINTER F1492_15943 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) *(EIF_POINTER *)(Current + O10619[Dtype(Current)-1313]);
}

/* {EV_MENU_ITEM_IMP}.image_menu_item_new */
void F1492_15944 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1492_15943(Current);
	gtk_widget_show((GtkWidget*) tp1);
	RTLE;
}

/* {EV_MENU_ITEM_IMP}.allow_on_activate */
EIF_BOOLEAN F1492_15945 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1485_15917(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != NULL);
	RTLE;
	return Result;
}

/* {EV_MENU_ITEM_IMP}.accelerators_enabled */
EIF_BOOLEAN F1492_15946 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {EV_MENU_ITEM_IMP}.on_activate */
void F1492_15947 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	tr1 = F1485_15917(Current);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1312, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F72_1157(loc1);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y10034,Y10034_gen_type,Dftype(Current),1279);
					typarr0[3] = l_type.annotations | 0xFF00;
					typarr0[4] = l_type.id;
				}
				
				typres0 = eif_compound_id(Dftype(Current), typarr0);
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F1280_12327(Current);
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			F813_6165(RTCW(tr1), tr2);
		}
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R10609[Dtype(loc1)-1319])(loc1);
		gtk_menu_shell_deactivate((GtkMenuShell*) tp1);
	}
	tp1 = F1492_15943(Current);
	gtk_menu_item_deselect((GtkMenuItem*) tp1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O1248[dtype-82]) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + O1248[dtype-82]);
		F813_6165(RTCW(tr1), NULL);
	}
	RTLE;
}

void EIF_Minit846 (void)
{
	GTCX
	RTPOMS(15936,0,"activate",8,526134885);
}


#ifdef __cplusplus
}
#endif
