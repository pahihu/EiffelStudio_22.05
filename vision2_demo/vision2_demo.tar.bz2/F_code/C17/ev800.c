/*
 * Code for class EV_TREE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev800.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1446_15358
static EIF_POINTER inline_F1446_15358 (void)
{
	return (EIF_POINTER) (gtk_tree_store_new (2, GDK_TYPE_PIXBUF, G_TYPE_STRING))
	;
}
#define INLINE_F1446_15358
#endif
#ifndef INLINE_F101_1871
static void inline_F101_1871 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_tree_view_set_headers_visible ((GtkTreeView*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F101_1871
#endif
#ifndef INLINE_F101_1923
static EIF_POINTER inline_F101_1923 (void)
{
	return (EIF_POINTER) (gtk_tree_view_column_new())
	;
}
#define INLINE_F101_1923
#endif
#ifndef INLINE_F101_1904
static void inline_F101_1904 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_tree_view_column_set_resizable ((GtkTreeViewColumn*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F101_1904
#endif
#ifndef INLINE_F101_1914
static EIF_POINTER inline_F101_1914 (void)
{
	return (EIF_POINTER) (gtk_cell_renderer_text_new())
	;
}
#define INLINE_F101_1914
#endif
#ifndef INLINE_F101_1926
static void inline_F101_1926 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	gtk_tree_view_column_pack_end ((GtkTreeViewColumn*) arg1, (GtkCellRenderer*) arg2, (gboolean) arg3)
	;
}
#define INLINE_F101_1926
#endif
#ifndef INLINE_F101_1913
static void inline_F101_1913 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4)
{
	gtk_tree_view_column_add_attribute ((GtkTreeViewColumn*) arg1, (GtkCellRenderer*) arg2, (gchar*) arg3, (gint) arg4)
	;
}
#define INLINE_F101_1913
#endif
#ifndef INLINE_F101_1915
static EIF_POINTER inline_F101_1915 (void)
{
	return (EIF_POINTER) (gtk_cell_renderer_pixbuf_new())
	;
}
#define INLINE_F101_1915
#endif
#ifndef INLINE_F101_1920
static void inline_F101_1920 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	gtk_tree_view_insert_column ((GtkTreeView*) arg1, (GtkTreeViewColumn*) arg2, (gint) arg3)
	;
}
#define INLINE_F101_1920
#endif
#ifndef INLINE_F101_1897
static EIF_POINTER inline_F101_1897 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_tree_view_get_selection ((GtkTreeView*) arg1))
	;
}
#define INLINE_F101_1897
#endif
#ifndef INLINE_F101_1898
static void inline_F101_1898 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_tree_selection_set_mode ((GtkTreeSelection*) arg1, (GtkSelectionMode) arg2)
	;
}
#define INLINE_F101_1898
#endif
#ifndef INLINE_F101_1872
static void inline_F101_1872 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_tree_view_set_enable_search ((GtkTreeView*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F101_1872
#endif
#ifndef INLINE_F15_340
static EIF_POINTER inline_F15_340 (EIF_INTEGER_32* arg1, EIF_INTEGER_32* arg2)
{
	return (GdkWindow*) gdk_device_get_window_at_position((GdkDevice*) gdk_seat_get_pointer((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default())), (gint*) arg1, (gint*) arg2);
	;
}
#define INLINE_F15_340
#endif
#ifndef INLINE_F101_1826
static void inline_F101_1826 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	gtk_widget_style_get ((GtkWidget*) arg1, (gchar*) arg2, (gint*) arg3, NULL);
	;
}
#define INLINE_F101_1826
#endif
#ifndef INLINE_F101_1865
static int inline_F101_1865 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4, EIF_POINTER arg5, EIF_POINTER arg6, EIF_POINTER arg7)
{
	return (int) (gtk_tree_view_get_path_at_pos ((GtkTreeView*) arg1, (gint) arg2, (gint) arg3, (GtkTreePath**) arg4, (GtkTreeViewColumn**) arg5, (gint*) arg6, (gint*) arg7))
	;
}
#define INLINE_F101_1865
#endif
#ifndef INLINE_F101_1873
static EIF_INTEGER_32 inline_F101_1873 (EIF_POINTER arg1)
{
	return (EIF_INTEGER_32) (gtk_tree_path_get_depth ((GtkTreePath*) arg1))
	;
}
#define INLINE_F101_1873
#endif
#ifndef INLINE_F101_1864
static void inline_F101_1864 (EIF_POINTER arg1)
{
	gtk_tree_path_free ((GtkTreePath*) arg1)
	;
}
#define INLINE_F101_1864
#endif
#ifndef INLINE_F101_1880
static EIF_POINTER inline_F101_1880 (EIF_POINTER arg1, EIF_POINTER* arg2)
{
	return (EIF_POINTER) (gtk_tree_selection_get_selected_rows ((GtkTreeSelection*) arg1, (GtkTreeModel**) arg2))
	;
}
#define INLINE_F101_1880
#endif
#ifndef INLINE_F101_1805
static void inline_F101_1805 (EIF_POINTER arg1)
{
	g_list_foreach ((GList*) arg1, (GFunc) gtk_tree_path_free, NULL)
	;
}
#define INLINE_F101_1805
#endif
#ifndef INLINE_F101_1888
static EIF_POINTER inline_F101_1888 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	return (EIF_POINTER) (gtk_tree_model_get_path ((GtkTreeModel*) arg1, (GtkTreeIter*) arg2))
	;
}
#define INLINE_F101_1888
#endif
#ifndef INLINE_F101_1952
static void inline_F101_1952 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_tree_store_remove ((GtkTreeStore*) arg1, (GtkTreeIter*) arg2)
	;
}
#define INLINE_F101_1952
#endif
#ifndef INLINE_F101_1943
static void inline_F101_1943 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	g_value_take_string ((GValue*) arg1, (gchar*) arg2)
	;
}
#define INLINE_F101_1943
#endif
#ifndef INLINE_F101_1954
static void inline_F101_1954 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	gtk_tree_store_set_value ((GtkTreeStore*) arg1, (GtkTreeIter*) arg2, (gint) arg3, (GValue*) arg4)
	;
}
#define INLINE_F101_1954
#endif
#ifndef INLINE_F101_1933
static void inline_F101_1933 (EIF_POINTER arg1)
{
	g_value_init ((GValue*) arg1, G_TYPE_STRING)
	;
}
#define INLINE_F101_1933
#endif
#ifndef INLINE_F101_1956
static void inline_F101_1956 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	gtk_tree_store_set ((GtkTreeStore*) arg1, (GtkTreeIter*) arg2, (gint) arg3, (GdkPixbuf*) arg4, -1)
	;
}
#define INLINE_F101_1956
#endif
#ifndef INLINE_F101_1894
static EIF_POINTER inline_F101_1894 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_tree_view_get_column ((GtkTreeView*) arg1, (gint) arg2))
	;
}
#define INLINE_F101_1894
#endif
#ifndef INLINE_F101_1866
static void inline_F101_1866 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3, EIF_INTEGER_32* arg4, EIF_INTEGER_32* arg5, EIF_INTEGER_32* arg6)
{
	gtk_tree_view_column_cell_get_size ((GtkTreeViewColumn*) arg1, (GdkRectangle*) arg2, (gint*) arg3, (gint*) arg4, (gint*) arg5, (gint*) arg6)
	;
}
#define INLINE_F101_1866
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TREE_IMP}.needs_event_box */
EIF_BOOLEAN F1446_15315 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_TREE_IMP}.call_selection_action_sequences */
void F1446_15317 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	loc1 = F1446_15323(Current);
	if ((EIF_BOOLEAN)(loc1 != *(EIF_REFERENCE *)(Current + O12215[dtype-1445]))) {
		tr1 = *(EIF_REFERENCE *)(Current + O12215[dtype-1445]);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			loc3 = *(EIF_REFERENCE *)(loc4 + _REFACS_3_);
			loc3 = RTRV(eif_new_type(1481, 0x00), loc3);
			RTCT0("previous_selected_item_imp /= Void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_4_);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				tr1 = F98_1313(RTCW(loc3));
				F813_6165(RTCW(tr1), NULL);
			}
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O2984[dtype-152]) != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + O2984[dtype-152]);
				F813_6165(RTCW(tr1), NULL);
			}
		}
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
			loc2 = RTRV(eif_new_type(1481, 0x00), loc2);
			RTCT0("a_selected_item_imp /= Void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_3_);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				tr1 = F98_1311(RTCW(loc2));
				F813_6165(RTCW(tr1), NULL);
			}
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O2982[dtype-152]) != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + O2982[dtype-152]);
				F813_6165(RTCW(tr1), NULL);
			}
		}
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + O12215[dtype-1445]) = (EIF_REFERENCE) loc1;
	RTLE;
}

/* {EV_TREE_IMP}.visual_widget */
EIF_POINTER F1446_15318 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) *(EIF_POINTER *)(Current + O12223[Dtype(Current)-1445]);
}

/* {EV_TREE_IMP}.initialize_model */
void F1446_15319 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = inline_F1446_15358();
	*(EIF_POINTER *)(Current + O12220[Dtype(Current)-1445]) = (EIF_POINTER) tp1;
	RTLE;
}

/* {EV_TREE_IMP}.make */
void F1446_15320 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp3 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp4 = tp3;
	tp1 = (EIF_POINTER) gtk_scrolled_window_new((GtkAdjustment*) tp2, (GtkAdjustment*) tp4);
	*(EIF_POINTER *)(Current + O12225[dtype-1445]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O12225[dtype-1445]);
	ti4_1 = (EIF_INTEGER_32) GTK_SHADOW_IN;
	gtk_scrolled_window_set_shadow_type((GtkScrolledWindow*) tp1, (GtkShadowType) ti4_1);
	F1314_13098(Current, *(EIF_POINTER *)(Current + O12225[dtype-1445]));
	tp1 = (EIF_POINTER) gtk_tree_view_new();
	*(EIF_POINTER *)(Current + O12223[dtype-1445]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O12225[dtype-1445]);
	tp2 = *(EIF_POINTER *)(Current + O12223[dtype-1445]);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) tp2);
	F1308_13068(Current);
	F1441_15182(Current);
	F1412_15024(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R12206[dtype-1445])(Current);
	tp1 = *(EIF_POINTER *)(Current + O12223[dtype-1445]);
	tp2 = *(EIF_POINTER *)(Current + O12220[dtype-1445]);
	gtk_tree_view_set_model((GtkTreeView*) tp1, (GtkTreeModel*) tp2);
	tp1 = *(EIF_POINTER *)(Current + O12225[dtype-1445]);
	ti4_1 = (EIF_INTEGER_32) GTK_POLICY_AUTOMATIC;
	ti4_2 = (EIF_INTEGER_32) GTK_POLICY_AUTOMATIC;
	gtk_scrolled_window_set_policy((GtkScrolledWindow*) tp1, (GtkPolicyType) ti4_1, (GtkPolicyType) ti4_2);
	tp1 = *(EIF_POINTER *)(Current + O12223[dtype-1445]);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current + O12223[dtype-1445]);
	inline_F101_1871(tp1, (EIF_BOOLEAN) 0);
	loc1 = inline_F101_1923();
	inline_F101_1904(loc1, (EIF_BOOLEAN) 1);
	loc2 = inline_F101_1914();
	inline_F101_1926(loc1, loc2, (EIF_BOOLEAN) 1);
	loc3 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr1 = RTMS_EX_H("text",4,1952807028);
	F928_6962(RTCW(loc3), tr1);
	tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	inline_F101_1913(loc1, loc2, tp1, ((EIF_INTEGER_32) 1L));
	loc2 = inline_F101_1915();
	inline_F101_1926(loc1, loc2, (EIF_BOOLEAN) 0);
	loc3 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr1 = RTMS_EX_H("pixbuf",6,93246054);
	F928_6962(RTCW(loc3), tr1);
	tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	inline_F101_1913(loc1, loc2, tp1, ((EIF_INTEGER_32) 0L));
	tp1 = *(EIF_POINTER *)(Current + O12223[dtype-1445]);
	inline_F101_1920(tp1, loc1, ((EIF_INTEGER_32) 1L));
	tp1 = *(EIF_POINTER *)(Current + O12223[dtype-1445]);
	tr1 = RTOSCF(376,F16_376, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,997,960,1033,1027,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 4, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(13123,F1314_13123, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O6580[dtype-937]);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
	((EIF_TYPED_VALUE *)tr2+3)->it_b = (EIF_BOOLEAN) 0;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,2,997,1033,1069,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A391_317_4_5, (EIF_POINTER) _A391_317_4_5, (EIF_POINTER)(F941_7728),tr2, 1, 2);
	}
	F1314_13102(Current, tp1, tr1, tr5);
	tp1 = *(EIF_POINTER *)(Current + O12223[dtype-1445]);
	tr1 = RTOSCF(377,F16_377, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,997,960,1033,1027,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 4, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(13123,F1314_13123, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O6580[dtype-937]);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
	((EIF_TYPED_VALUE *)tr2+3)->it_b = (EIF_BOOLEAN) 1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,2,997,1033,1069,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A391_317_4_5, (EIF_POINTER) _A391_317_4_5, (EIF_POINTER)(F941_7728),tr2, 1, 2);
	}
	F1314_13102(Current, tp1, tr1, tr5);
	tp1 = *(EIF_POINTER *)(Current + O12223[dtype-1445]);
	loc4 = inline_F101_1897(tp1);
	tr1 = RTOSCF(371,F16_371, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,960,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(13123,F1314_13123, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O6580[dtype-937]);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A391_320, (EIF_POINTER) _A391_320, (EIF_POINTER)(F941_7731),tr2, 1, 0);
	}
	F1314_13102(Current, loc4, tr1, tr3);
	ti4_1 = (EIF_INTEGER_32) GTK_SELECTION_BROWSE;
	inline_F101_1898(loc4, ti4_1);
	tp1 = *(EIF_POINTER *)(Current + O12223[dtype-1445]);
	inline_F101_1872(tp1, (EIF_BOOLEAN) 0);
	F1336_13553(Current);
	RTLE;
}

/* {EV_TREE_IMP}.call_button_event_actions */
RTEOMS(15320,2);
void F1446_15321 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_POINTER loc7 = (EIF_POINTER) 0;
	EIF_POINTER loc8 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_POINTER loc11 = (EIF_POINTER) 0;
	EIF_POINTER loc12 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc14 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_POINTER tp5;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	F1366_13912(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
	loc11 = inline_F15_340((EIF_INTEGER_32 *) &(loc13), (EIF_INTEGER_32 *) &(loc14));
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc11 != tp1)) {
		gdk_window_get_user_data((GdkWindow*) loc11, (gpointer*) (EIF_POINTER *) &(loc12));
		if ((EIF_BOOLEAN)(loc12 != *(EIF_POINTER *)(Current + O12223[dtype-1445]))) {
			loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			loc3 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
			F928_6962(RTCW(loc3), RTOMS(15320,0));
			tp1 = *(EIF_POINTER *)(Current + O12223[dtype-1445]);
			tp2 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
			inline_F101_1826(tp1, tp2, (EIF_INTEGER_32 *) &(loc4));
			loc3 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
			F928_6962(RTCW(loc3), RTOMS(15320,1));
			tp1 = *(EIF_POINTER *)(Current + O12223[dtype-1445]);
			tp2 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
			inline_F101_1826(tp1, tp2, (EIF_INTEGER_32 *) &(loc5));
			tp1 = *(EIF_POINTER *)(Current + O12223[dtype-1445]);
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp2 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			tp3 = tp2;
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp4 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			tp5 = tp4;
			loc6 = EIF_TEST (inline_F101_1865(tp1, arg2, arg3, (EIF_POINTER *) &(loc7), (EIF_POINTER *) &(loc8), tp3, tp5));
			if (loc6) {
				loc9 = inline_F101_1873(loc7);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg2 <= (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + loc4) + loc5) * loc9)) && (EIF_BOOLEAN) (arg2 >= (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + loc4) + loc5) * (EIF_INTEGER_32) (loc9 - ((EIF_INTEGER_32) 1L)))))) {
					loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
				inline_F101_1864(loc7);
			}
		}
	}
	if ((EIF_BOOLEAN) !loc10) {
		loc2 = F1446_15344(Current, arg2, arg3);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,8,997,1033,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				tr1 = RTLNTS(typres0.id, 9, 1);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg2;
			((EIF_TYPED_VALUE *)tr1+2)->it_i4 = arg3;
			((EIF_TYPED_VALUE *)tr1+3)->it_i4 = arg4;
			((EIF_TYPED_VALUE *)tr1+4)->it_r8 = arg5;
			((EIF_TYPED_VALUE *)tr1+5)->it_r8 = arg6;
			((EIF_TYPED_VALUE *)tr1+6)->it_r8 = arg7;
			((EIF_TYPED_VALUE *)tr1+7)->it_i4 = arg8;
			((EIF_TYPED_VALUE *)tr1+8)->it_i4 = arg9;
			loc1 = (EIF_REFERENCE) tr1;
			tb1 = '\0';
			if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_PRESS)) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_1_);
				tb1 = (EIF_BOOLEAN)(tr1 != NULL);
			}
			if (tb1) {
				tr1 = F81_1247(RTCW(loc2));
				F813_6165(RTCW(tr1), loc1);
			} else {
				tb1 = '\0';
				if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_2BUTTON_PRESS)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_2_);
					tb1 = (EIF_BOOLEAN)(tr1 != NULL);
				}
				if (tb1) {
					tr1 = F81_1249(RTCW(loc2));
					F813_6165(RTCW(tr1), loc1);
				}
			}
		}
	}
	RTLE;
}

/* {EV_TREE_IMP}.on_pointer_motion */
void F1446_15322 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	F1364_13840(Current, arg1);
	tb1 = '\0';
	tb2 = '\0';
	tb3 = F1305_12988(RTCV(RTOSCF(13123,F1314_13123, (Current))));
	if ((EIF_BOOLEAN) !tb3) {
		ti4_1 = F998_8177(RTCW(arg1), ((EIF_INTEGER_32) 2L));
		tb2 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb2) {
		ti4_1 = F998_8177(RTCW(arg1), ((EIF_INTEGER_32) 1L));
		tb1 = (EIF_BOOLEAN) (ti4_1 <= F1366_13919(Current));
	}
	if (tb1) {
		ti4_1 = F998_8177(RTCW(arg1), ((EIF_INTEGER_32) 1L));
		ti4_2 = F998_8177(RTCW(arg1), ((EIF_INTEGER_32) 2L));
		loc1 = F1446_15344(Current, ti4_1, ti4_2);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				tr1 = F81_1245(RTCW(loc1));
				F813_6165(RTCW(tr1), arg1);
			}
		}
	}
	RTLE;
}

/* {EV_TREE_IMP}.selected_item */
EIF_REFERENCE F1446_15323 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12223[Dtype(Current)-1445]);
	loc1 = inline_F101_1897(tp1);
	loc2 = inline_F101_1880(loc1, (EIF_POINTER *) &(loc3));
	tb1 = !loc2;
	if ((EIF_BOOLEAN) !tb1) {
		loc4 = (EIF_POINTER) (((GList *)loc2)->data);
		loc5 = F1446_15324(Current, loc4);
		inline_F101_1805(loc2);
		g_list_free((GList*) loc2);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_14_);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {EV_TREE_IMP}.node_from_tree_path */
EIF_REFERENCE F1446_15324 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,loc5);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc6);
	RTLIU(5);
	
	RTGC;
	loc4 = inline_F101_1873(arg1);
	loc1 = (EIF_POINTER) gtk_tree_path_get_indices((GtkTreePath*) arg1);
	loc2 = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_1_0_1_0_1_1_0_);
	F932_7057(RTCW(loc2), loc1, (EIF_INTEGER_32) (((EIF_INTEGER_32) 4L) * loc4));
	ti4_1 = F932_7071(RTCW(loc2), ((EIF_INTEGER_32) 0L));
	loc5 = F1308_13069(Current, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	RTCT0("a_tree_node /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc3 == loc4)) break;
		ti4_1 = F932_7071(RTCW(loc2), (EIF_INTEGER_32) (loc3 * ((EIF_INTEGER_32) 4L)));
		tr1 = F1120_10291(RTCW(loc5), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		loc5 = (EIF_REFERENCE) tr1;
		RTCT0("a_tree_node /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc3++;
	}
	loc6 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_3_);
	loc6 = RTRV(eif_new_type(1481, 0x00), loc6);
	RTCT0("l_result /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc6 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTLE;
	return (EIF_REFERENCE) loc6;
}

/* {EV_TREE_IMP}.pebble_source */
EIF_REFERENCE F1446_15326 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O12210[Dtype(Current)-1445]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1280_12327(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTLE;
		return (EIF_REFERENCE) F1364_13860(Current);
	}/* NOTREACHED */
	
}

/* {EV_TREE_IMP}.ensure_item_visible */
void F1446_15327 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1481, 0x00), loc1);
	RTCT0("tree_item_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_21_);
	RTCT0("l_list_iter /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = *(EIF_POINTER *)(Current + O12220[dtype-1445]);
	tp2 = F260_4057(RTCW(loc3));
	loc2 = inline_F101_1888(tp1, tp2);
	tp1 = *(EIF_POINTER *)(Current + O12223[dtype-1445]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	tr4_2 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	gtk_tree_view_scroll_to_cell((GtkTreeView*) tp1, (GtkTreePath*) loc2, (GtkTreeViewColumn*) tp3, (gboolean) (EIF_BOOLEAN) 0, (gfloat) tr4_1, (gfloat) tr4_2);
	inline_F101_1864(loc2);
	RTLE;
}

/* {EV_TREE_IMP}.able_to_transport */
EIF_BOOLEAN F1446_15329 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O12210[Dtype(Current)-1445]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = F1482_15883(loc1, arg1);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTLE;
		return (EIF_BOOLEAN) F1364_13857(Current, arg1);
	}/* NOTREACHED */
	
}

/* {EV_TREE_IMP}.ready_for_pnd_menu */
EIF_BOOLEAN F1446_15330 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O12210[Dtype(Current)-1445]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = F1482_15884(loc1, arg1, arg2);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTLE;
		return (EIF_BOOLEAN) F1364_13861(Current, arg1, arg2);
	}/* NOTREACHED */
	
}

/* {EV_TREE_IMP}.update_pnd_status */
void F1446_15332 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,loc4);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
	loc3 = F664_5458(RTCW(tr1));
	loc5 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
	F664_5478(RTCW(loc5));
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tb1 = '\01';
		ti4_1 = F664_5468(RTCW(loc5));
		if (!(EIF_BOOLEAN) (loc2 > ti4_1)) {
			tb1 = loc1;
		}
		if (tb1) break;
		F664_5482(RTCW(loc5), loc2);
		tr1 = F664_5452(RTCW(loc5));
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F664_5452(RTCW(loc5));
			loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
			loc4 = RTRV(eif_new_type(1481, 0x00), loc4);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				loc1 = F1482_15881(RTCW(loc4));
			}
		}
		loc2++;
	}
	F664_5483(RTCW(loc5), loc3);
	F1446_15333(Current, loc1);
	RTLE;
}

/* {EV_TREE_IMP}.update_pnd_connection */
void F1446_15333 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11167[dtype-1362])) {
		if ((EIF_BOOLEAN) (arg1 || (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O11142[dtype-1362]) != NULL))) {
			*(EIF_BOOLEAN *)(Current + O11167[dtype-1362]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !arg1 && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O11142[dtype-1362]) == NULL))) {
			*(EIF_BOOLEAN *)(Current + O11167[dtype-1362]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
	}
	RTLE;
}

/* {EV_TREE_IMP}.on_mouse_button_event */
void F1446_15334 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1446_15344(Current, arg2, arg3);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + O12210[dtype-1445]) = (EIF_REFERENCE) loc1;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tb2 = '\01';
		tb3 = F1482_15883(RTCW(loc1), arg4);
		if (!tb3) {
			tb3 = F1363_13813(RTCW(loc1));
			tb2 = tb3;
		}
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		*(EIF_REFERENCE *)(Current + O12210[dtype-1445]) = (EIF_REFERENCE) NULL;
	}
	F1364_13858(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
	RTLE;
}

/* {EV_TREE_IMP}.call_pebble_function */
void F1446_15340 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O11142[dtype-1362]);
	tr1 = RTCCL(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O12211[dtype-1445]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O11143[dtype-1362]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O12212[dtype-1445]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O12210[dtype-1445]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_16_);
		tr1 = RTCCL(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O11142[dtype-1362]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_17_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O11143[dtype-1362]) = (EIF_REFERENCE) tr1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O11143[dtype-1362]);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,1033,1033,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 1);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
		((EIF_TYPED_VALUE *)tr1+2)->it_i4 = arg2;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7802[Dtype(loc2)-1072])(loc2, tr1);
		tr1 = RTCCL(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O11142[dtype-1362]) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {EV_TREE_IMP}.pre_pick_steps */
void F1446_15341 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_16 ti2_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O11146[dtype-1362]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O12213[dtype-1445]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O11147[dtype-1362]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O12214[dtype-1445]) = (EIF_REFERENCE) tr1;
	loc1 = *(EIF_REFERENCE *)(Current + O11142[dtype-1362]);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = RTOSCF(13123,F1314_13123, (Current));
		tr2 = RTCCL(loc1);
		F1305_12982(RTCW(tr1), Current, tr2);
	}
	loc2 = *(EIF_REFERENCE *)(Current + O12210[dtype-1445]);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_7_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F111_2517(RTCW(loc2));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,1033,1033,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNTS(typres0.id, 3, 1);
			}
			((EIF_TYPED_VALUE *)tr2+1)->it_i4 = arg1;
			((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg2;
			F813_6165(RTCW(tr1), tr2);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_19_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O11146[dtype-1362]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_20_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O11147[dtype-1362]) = (EIF_REFERENCE) tr1;
	} else {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O2508[dtype-110]) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O2508[dtype-110]);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,1033,1033,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNTS(typres0.id, 3, 1);
			}
			((EIF_TYPED_VALUE *)tr2+1)->it_i4 = arg1;
			((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg2;
			F813_6165(RTCW(tr1), tr2);
		}
	}
	ti2_1 = (EIF_INTEGER_16) arg3;
	*(EIF_INTEGER_16 *)(Current + O3008[dtype-155]) = (EIF_INTEGER_16) ti2_1;
	ti2_1 = (EIF_INTEGER_16) arg4;
	*(EIF_INTEGER_16 *)(Current + O3009[dtype-155]) = (EIF_INTEGER_16) ti2_1;
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_16 *)(Current + O11172[dtype-1362]) == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(*(EIF_INTEGER_16 *)(Current + O11173[dtype-1362]) == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L)))) {
			tr1 = RTOSCF(13123,F1314_13123, (Current));
			F1304_12840(RTCW(tr1), arg3, arg4);
		} else {
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O11172[dtype-1362]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			if ((EIF_BOOLEAN) (ti4_1 > F1366_13919(Current))) {
				ti2_1 = (EIF_INTEGER_16) F1366_13919(Current);
				*(EIF_INTEGER_16 *)(Current + O11172[dtype-1362]) = (EIF_INTEGER_16) ti2_1;
			}
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O11173[dtype-1362]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			if ((EIF_BOOLEAN) (ti4_1 > F1366_13920(Current))) {
				ti2_1 = (EIF_INTEGER_16) F1366_13920(Current);
				*(EIF_INTEGER_16 *)(Current + O11173[dtype-1362]) = (EIF_INTEGER_16) ti2_1;
			}
			tr1 = RTOSCF(13123,F1314_13123, (Current));
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O11172[dtype-1362]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O11173[dtype-1362]);
			ti4_2 = (EIF_INTEGER_32) ti2_1;
			F1304_12840(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + (EIF_INTEGER_32) (arg3 - arg1)), (EIF_INTEGER_32) (ti4_2 + (EIF_INTEGER_32) (arg4 - arg2)));
		}
	} else {
		tb1 = '\0';
		ti2_1 = *(EIF_INTEGER_16 *)(RTCW(loc2)+ _I16OFF_25_6_4_);
		if ((EIF_BOOLEAN)(ti2_1 == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L))) {
			ti2_1 = *(EIF_INTEGER_16 *)(RTCW(loc2)+ _I16OFF_25_6_5_);
			tb1 = (EIF_BOOLEAN)(ti2_1 == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L));
		}
		if (tb1) {
			tr1 = RTOSCF(13123,F1314_13123, (Current));
			F1304_12840(RTCW(tr1), arg3, arg4);
		} else {
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O11172[dtype-1362]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			if ((EIF_BOOLEAN) (ti4_1 > F1366_13919(Current))) {
				ti2_1 = (EIF_INTEGER_16) F1366_13919(Current);
				*(EIF_INTEGER_16 *)(Current + O11172[dtype-1362]) = (EIF_INTEGER_16) ti2_1;
			}
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O11173[dtype-1362]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			if ((EIF_BOOLEAN) (ti4_1 > F1446_15355(Current))) {
				ti2_1 = (EIF_INTEGER_16) F1446_15355(Current);
				*(EIF_INTEGER_16 *)(Current + O11173[dtype-1362]) = (EIF_INTEGER_16) ti2_1;
			}
			tr1 = RTOSCF(13123,F1314_13123, (Current));
			ti2_1 = *(EIF_INTEGER_16 *)(RTCW(loc2)+ _I16OFF_25_6_4_);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			ti2_1 = *(EIF_INTEGER_16 *)(RTCW(loc2)+ _I16OFF_25_6_5_);
			ti4_2 = (EIF_INTEGER_32) ti2_1;
			tr2 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
			tr3 = F1280_12327(RTCW(loc2));
			ti4_3 = F591_5016(RTCW(tr2), tr3, ((EIF_INTEGER_32) 1L));
			ti4_4 = F1446_15355(Current);
			F1304_12840(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + (EIF_INTEGER_32) (arg3 - arg1)), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 + (EIF_INTEGER_32) (arg4 - arg2)) + (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_3 - ((EIF_INTEGER_32) 1L)) * ti4_4)));
		}
	}
	F1363_13831(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_TREE_IMP}.reset_pebble_function */
void F1446_15342 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O12211[dtype-1445]);
	tr1 = RTCCL(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11142[dtype-1362]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O12212[dtype-1445]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11143[dtype-1362]) = (EIF_REFERENCE) tr1;
	*(EIF_REFERENCE *)(Current + O12211[dtype-1445]) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + O12212[dtype-1445]) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {EV_TREE_IMP}.post_drop_steps */
void F1446_15343 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1364_13863(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O12213[dtype-1445]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11146[dtype-1362]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O12214[dtype-1445]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11147[dtype-1362]) = (EIF_REFERENCE) tr1;
	*(EIF_REFERENCE *)(Current + O12213[dtype-1445]) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + O12214[dtype-1445]) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + O12210[dtype-1445]) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {EV_TREE_IMP}.item_from_coords */
EIF_REFERENCE F1446_15344 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_POINTER tp5;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,loc7);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12223[dtype-1445]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp4 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp5 = tp4;
	loc3 = EIF_TEST (inline_F101_1865(tp1, ((EIF_INTEGER_32) 1L), arg2, (EIF_POINTER *) &(loc1), (EIF_POINTER *) &(loc2), tp3, tp5));
	if (loc3) {
		loc4 = (EIF_POINTER) gtk_tree_path_get_indices((GtkTreePath*) loc1);
		loc6 = inline_F101_1873(loc1);
		loc5 = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_1_0_1_0_1_1_0_);
		F932_7057(RTCW(loc5), loc4, (EIF_INTEGER_32) (((EIF_INTEGER_32) 4L) * loc6));
		loc9 = F932_7071(RTCW(loc5), ((EIF_INTEGER_32) 0L));
		loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 + ((EIF_INTEGER_32) 1L));
		tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
		tr1 = F664_5453(RTCW(tr1), loc9);
		loc7 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		loc7 = RTRV(eif_new_type(1481, 0x00), loc7);
		RTCT0("a_tree_node_imp /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc7 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN)(loc8 == loc6)) break;
			loc9 = F932_7071(RTCW(loc5), (EIF_INTEGER_32) (loc8 * ((EIF_INTEGER_32) 4L)));
			loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 + ((EIF_INTEGER_32) 1L));
			tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_15_);
			tr1 = F664_5453(RTCW(tr1), loc9);
			loc7 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
			loc7 = RTRV(eif_new_type(1481, 0x00), loc7);
			RTCT0("a_tree_node_imp /= Void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc7 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			loc8++;
		}
		Result = (EIF_REFERENCE) loc7;
		inline_F101_1864(loc1);
	}
	RTLE;
	return Result;
}

/* {EV_TREE_IMP}.insert_i_th */
void F1446_15347 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1481, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1482_15887(RTCW(loc1), Current);
		tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
		F664_5482(RTCW(tr1), arg2);
		tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4583[Dtype(RTCW(tr1))-663])(tr1, arg1);
		F1482_15890(RTCW(loc1), Current, NULL, arg2);
		F1446_15352(Current, loc1);
		tb1 = F1482_15881(RTCW(loc1));
		if (tb1) {
			F1446_15333(Current, (EIF_BOOLEAN) 1);
		}
	}
	RTLE;
}

/* {EV_TREE_IMP}.remove_i_th */
void F1446_15348 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
	tr1 = F664_5454(RTCW(tr1), arg1);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1481, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_21_);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tp1 = *(EIF_POINTER *)(Current + O12220[dtype-1445]);
			tp2 = F260_4057(RTCW(loc2));
			inline_F101_1952(tp1, tp2);
			F1482_15887(RTCW(loc1), NULL);
			tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
			F664_5482(RTCW(tr1), arg1);
			tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R4455[Dtype(RTCW(tr1))-534])(tr1);
			F1446_15332(Current);
		}
	}
	RTLE;
}

/* {EV_TREE_IMP}.set_text_on_position */
void F1446_15350 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	loc1 = RTOSCF(13015,F1305_13015, (RTCV(RTOSCF(13123,F1314_13123, (Current)))));
	F928_6963(RTCW(loc1), arg2);
	loc2 = RTOSCF(15351,F1446_15351, (Current));
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	inline_F101_1943(loc2, tp1);
	loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_21_);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		tp1 = *(EIF_POINTER *)(Current + O12220[Dtype(Current)-1445]);
		tp2 = F260_4057(RTCW(loc3));
		inline_F101_1954(tp1, tp2, ((EIF_INTEGER_32) 1L), loc2);
	}
	RTLE;
}

/* {EV_TREE_IMP}.g_value_string_struct */
static EIF_POINTER F1446_15351_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (15351);
#define Result RTOSR(15351)
	Result = (EIF_POINTER) calloc (sizeof(GValue), 1);
	inline_F101_1933(Result);
	RTOSE (15351);
	RTEE;
	return Result;
#undef Result
}

EIF_POINTER F1446_15351 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15351,F1446_15351_body,(Current));
}

/* {EV_TREE_IMP}.update_row_pixmap */
void F1446_15352 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_25_6_6_3_0_0_);
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_21_);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tp1 = *(EIF_POINTER *)(Current + O12220[Dtype(Current)-1445]);
		tp2 = F260_4057(RTCW(loc2));
		inline_F101_1956(tp1, tp2, ((EIF_INTEGER_32) 0L), loc1);
	}
	RTLE;
}

/* {EV_TREE_IMP}.row_height */
EIF_INTEGER_32 F1446_15355 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12223[Dtype(Current)-1445]);
	loc1 = inline_F101_1894(tp1, ((EIF_INTEGER_32) 0L));
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	inline_F101_1866(loc1, tp2, (EIF_INTEGER_32 *) &(loc2), (EIF_INTEGER_32 *) &(loc3), (EIF_INTEGER_32 *) &(loc4), (EIF_INTEGER_32 *) &(loc5));
	RTLE;
	return (EIF_INTEGER_32) loc5;
}

/* {EV_TREE_IMP}.pixmaps_size_changed */
void F1446_15357 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_TREE_IMP}.new_tree_store */
EIF_POINTER F1446_15358 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F1446_15358 ();
	return Result;
}

void EIF_Minit800 (void)
{
	GTCX
	RTPOMS(15320,1,"horizontal-separator",20,1855499634);
	RTPOMS(15320,0,"expander-size",13,1515618149);
}


#ifdef __cplusplus
}
#endif
