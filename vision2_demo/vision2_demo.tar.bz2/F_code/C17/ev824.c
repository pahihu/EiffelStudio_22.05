/*
 * Code for class EV_VERTICAL_PROGRESS_BAR_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev824.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F17_402
static EIF_NATURAL_8 inline_F17_402 (void)
{
	return GTK_ORIENTATION_VERTICAL
	;
}
#define INLINE_F17_402
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_VERTICAL_PROGRESS_BAR_IMP}.make */
void F1470_15726 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1469_15709(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_14_10_7_0_2_);
	tu1_1 = inline_F17_402();
	gtk_orientable_set_orientation((GtkOrientable*) tp1, (GtkOrientation) tu1_1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_14_10_7_0_2_);
	gtk_progress_bar_set_inverted((GtkProgressBar*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_VERTICAL_PROGRESS_BAR_IMP}.is_vertical */
EIF_BOOLEAN F1470_15727 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

void EIF_Minit824 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
