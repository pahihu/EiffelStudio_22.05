/*
 * Code for class EV_HEADER_ITEM_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev831.h"
#include <string.h>
#include <ev_gtk.h>
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F101_1923
static EIF_POINTER inline_F101_1923 (void)
{
	return (EIF_POINTER) (gtk_tree_view_column_new())
	;
}
#define INLINE_F101_1923
#endif
#ifndef INLINE_F101_1904
static void inline_F101_1904 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_tree_view_column_set_resizable ((GtkTreeViewColumn*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F101_1904
#endif
#ifndef INLINE_F101_1903
static void inline_F101_1903 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_tree_view_column_set_sizing ((GtkTreeViewColumn*) arg1, (GtkTreeViewColumnSizing) arg2)
	;
}
#define INLINE_F101_1903
#endif
#ifndef INLINE_F101_1905
static void inline_F101_1905 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_tree_view_column_set_clickable ((GtkTreeViewColumn*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F101_1905
#endif
#ifndef INLINE_F1477_15756
static void inline_F1477_15756 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	(FUNCTION_CAST(void, (GtkLabel*, gint)) arg1)((GtkLabel*) arg2, (gint) arg3);
	;
}
#define INLINE_F1477_15756
#endif
#ifndef INLINE_F101_1794
static void inline_F101_1794 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_label_set_ellipsize ((GtkLabel*) arg1, (PangoEllipsizeMode) arg2);
	;
}
#define INLINE_F101_1794
#endif
#ifndef INLINE_F17_401
static EIF_NATURAL_8 inline_F17_401 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F17_401
#endif
#ifndef INLINE_F102_2119
static EIF_POINTER inline_F102_2119 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F102_2119
#endif
#ifndef INLINE_F100_1398
static EIF_POINTER inline_F100_1398 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref_sink((gpointer) arg1))
	;
}
#define INLINE_F100_1398
#endif
#ifndef INLINE_F101_1906
static void inline_F101_1906 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_tree_view_column_set_widget ((GtkTreeViewColumn*) arg1, (GtkWidget*) arg2)
	;
}
#define INLINE_F101_1906
#endif
#ifndef INLINE_F102_2103
static void inline_F102_2103 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	gtk_widget_get_preferred_width
                               ((GtkWidget *)arg1,
                                (gint *)arg2,
                                (gint *)arg3);
	;
}
#define INLINE_F102_2103
#endif
#ifndef INLINE_F101_1910
static EIF_INTEGER_32 inline_F101_1910 (EIF_POINTER arg1)
{
	return (EIF_INTEGER_32) (gtk_tree_view_column_get_min_width ((GtkTreeViewColumn*) arg1))
	;
}
#define INLINE_F101_1910
#endif
#ifndef INLINE_F101_1911
static void inline_F101_1911 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_tree_view_column_set_min_width ((GtkTreeViewColumn*) arg1, (gint) arg2)
	;
}
#define INLINE_F101_1911
#endif
#ifndef INLINE_F101_1901
static void inline_F101_1901 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_tree_view_column_set_fixed_width ((GtkTreeViewColumn*) arg1, (gint) arg2)
	;
}
#define INLINE_F101_1901
#endif
#ifndef INLINE_F101_1908
static EIF_INTEGER_32 inline_F101_1908 (EIF_POINTER arg1)
{
	return (EIF_INTEGER_32) (gtk_tree_view_column_get_width ((GtkTreeViewColumn*) arg1))
	;
}
#define INLINE_F101_1908
#endif
#ifndef INLINE_F100_1400
static void inline_F100_1400 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F100_1400
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_HEADER_ITEM_IMP}.needs_event_box */
EIF_BOOLEAN F1477_15752 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_HEADER_ITEM_IMP}.make */
void F1477_15754 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = inline_F101_1923();
	F1314_13098(Current, tp1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
	inline_F101_1904(tp1, (EIF_BOOLEAN) 1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
	ti4_1 = (EIF_INTEGER_32) GTK_TREE_VIEW_COLUMN_FIXED;
	inline_F101_1903(tp1, ti4_1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
	inline_F101_1905(tp1, (EIF_BOOLEAN) 1);
	F1341_13572(Current);
	F1343_13585(Current);
	loc1 = RTOSCF(15755,F1477_15755, (Current));
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_2_);
		inline_F1477_15756(loc1, tp1, ((EIF_INTEGER_32) 3L));
	} else {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_2_);
		inline_F101_1794(tp1, ((EIF_INTEGER_32) 3L));
	}
	tu1_1 = inline_F17_401();
	tp1 = inline_F102_2119(tu1_1, ((EIF_INTEGER_32) 0L));
	*(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_);
	tp1 = inline_F100_1398(tp1);
	*(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_1_);
	gtk_box_pack_start((GtkBox*) tp1, (GtkWidget*) tp2, (gboolean) (EIF_BOOLEAN) 0, (gboolean) (EIF_BOOLEAN) 0, (guint) ((EIF_INTEGER_32) 0L));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_2_);
	gtk_box_pack_end((GtkBox*) tp1, (GtkWidget*) tp2, (gboolean) (EIF_BOOLEAN) 1, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_);
	inline_F101_1906(tp1, tp2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	inline_F102_2103(tp1, (EIF_INTEGER_32 *) &(loc2), tp3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
	ti4_1 = inline_F101_1910(tp1);
	ti4_1 = eif_max_int32 (ti4_1,loc2);
	ti4_1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 1L));
	F1477_15766(Current, ti4_1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_22_8_6_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 32000L);
	F1343_13589(Current);
	F1477_15764(Current);
	ti4_1 = F1477_15759(Current);
	ti4_1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 80L));
	F1477_15767(Current, ti4_1);
	F1280_12341(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_HEADER_ITEM_IMP}.gtk_label_set_ellipsize_symbol */
static EIF_POINTER F1477_15755_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (15755);
#define Result RTOSR(15755)
	tr1 = RTOSCF(13123,F1314_13123, (Current));
	tr2 = RTMS_EX_H("gtk_label_set_ellipsize",23,909237861);
	Result = F1305_12911(RTCW(tr1), tr2);
	RTOSE (15755);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_POINTER F1477_15755 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15755,F1477_15755_body,(Current));
}

/* {EV_HEADER_ITEM_IMP}.gtk_label_set_ellipsize_call */
void F1477_15756 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	inline_F1477_15756 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3);
}

/* {EV_HEADER_ITEM_IMP}.handle_resize */
void F1477_15757 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = F1477_15792(Current);
	loc2 = (EIF_INTEGER_32) loc1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
	loc3 = (EIF_POINTER) gtk_tree_view_column_get_button((GtkTreeViewColumn*) tp1);
	tb1 = !loc3;
	if ((EIF_BOOLEAN) !tb1) {
		loc4 = (EIF_POINTER) gtk_bin_get_child((GtkBin*) loc3);
		tb1 = !loc4;
		if ((EIF_BOOLEAN) !tb1) {
			loc2 = (EIF_INTEGER_32) gtk_widget_get_allocated_width((GtkWidget*) loc4);
		}
	}
	if ((EIF_BOOLEAN)(loc1 != *(EIF_INTEGER_32 *)(Current+ _LNGOFF_22_8_6_3_))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_22_8_6_3_) = (EIF_INTEGER_32) loc1;
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			tb2 = '\01';
			tb3 = *(EIF_BOOLEAN *)(loc5+ _CHROFF_51_11_);
			if (!tb3) {
				tr1 = *(EIF_REFERENCE *)(loc5 + _REFACS_50_);
				tb2 = (EIF_BOOLEAN)(tr1 != NULL);
			}
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = RTLNS(eif_new_type(100, 0x00).id, 100, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F101_1819(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_), loc2, ((EIF_INTEGER_32) -1L));
			tr1 = F1280_12327(Current);
			F1442_15203(loc5, tr1);
		}
	}
	RTLE;
}

/* {EV_HEADER_ITEM_IMP}.width */
EIF_INTEGER_32 F1477_15758 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_22_8_6_3_);
}


/* {EV_HEADER_ITEM_IMP}.minimum_width */
EIF_INTEGER_32 F1477_15759 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		inline_F102_2103(tp1, (EIF_INTEGER_32 *) &(Result), tp3);
	}
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
	loc1 = (EIF_POINTER) gtk_tree_view_column_get_button((GtkTreeViewColumn*) tp1);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		loc2 = (EIF_POINTER) gtk_bin_get_child((GtkBin*) loc1);
		tb1 = !loc2;
		if ((EIF_BOOLEAN) !tb1) {
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			tp2 = tp1;
			inline_F102_2103(loc2, (EIF_INTEGER_32 *) &(loc4), tp2);
			ti4_1 = eif_max_int32 (Result,loc4);
			Result = (EIF_INTEGER_32) ti4_1;
			loc3 = (EIF_INTEGER_32) gtk_widget_get_allocated_width((GtkWidget*) loc2);
			ti4_1 = eif_max_int32 (Result,loc3);
			Result = (EIF_INTEGER_32) ti4_1;
		}
	}
	tp1 = F1314_13122(Current);
	ti4_1 = inline_F101_1910(tp1);
	ti4_1 = eif_max_int32 (Result,ti4_1);
	Result = (EIF_INTEGER_32) ti4_1;
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_22_8_6_1_);
	ti4_1 = eif_max_int32 (ti4_1,Result);
	Result = (EIF_INTEGER_32) ti4_1;
	RTLE;
	return Result;
}

/* {EV_HEADER_ITEM_IMP}.maximum_width */
EIF_INTEGER_32 F1477_15761 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_22_8_6_2_);
}


/* {EV_HEADER_ITEM_IMP}.user_can_resize */
EIF_BOOLEAN F1477_15762 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_22_5_);
}


/* {EV_HEADER_ITEM_IMP}.enable_user_resize */
void F1477_15764 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_22_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
	inline_F101_1904(tp1, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_HEADER_ITEM_IMP}.set_minimum_width */
void F1477_15766 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 0L))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_22_8_6_1_) = (EIF_INTEGER_32) arg1;
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
		inline_F101_1911(tp1, arg1);
	} else {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_22_8_6_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
		inline_F101_1911(tp1, ((EIF_INTEGER_32) -1L));
	}
	RTLE;
}

/* {EV_HEADER_ITEM_IMP}.set_width */
void F1477_15767 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_22_8_6_3_) = (EIF_INTEGER_32) arg1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
	ti4_1 = eif_max_int32 (arg1,((EIF_INTEGER_32) 1L));
	inline_F101_1901(tp1, ti4_1);
	tr1 = RTLNS(eif_new_type(100, 0x00).id, 100, _OBJSIZ_0_0_0_0_0_0_0_0_);
	F101_1819(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_), arg1, ((EIF_INTEGER_32) -1L));
	RTLE;
}

/* {EV_HEADER_ITEM_IMP}.resize_to_content */
void F1477_15768 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) sizeof(GtkRequisition);
	tp1 = malloc((size_t)ti4_1);
	loc1 = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	gtk_widget_get_preferred_size((GtkWidget*) tp1, (GtkRequisition*) loc1, (GtkRequisition*) tp3);
	loc3 = (EIF_INTEGER_32) (((GtkRequisition *)loc1)->height);
	loc2 = (EIF_INTEGER_32) (((GtkRequisition *)loc1)->width);
	ti4_1 = F1477_15759(Current);
	ti4_1 = eif_max_int32 (loc2,ti4_1);
	F1477_15767(Current, ti4_1);
	free(loc1);
	RTLE;
}

/* {EV_HEADER_ITEM_IMP}.update_for_pick_and_drop */
void F1477_15769 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	RTGC;
}

/* {EV_HEADER_ITEM_IMP}.enable_transport */
void F1477_15770 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_22_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_HEADER_ITEM_IMP}.draw_rubber_band */
void F1477_15772 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_HEADER_ITEM_IMP}.erase_rubber_band */
void F1477_15773 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_HEADER_ITEM_IMP}.internal_set_pointer_style */
void F1477_15779 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {EV_HEADER_ITEM_IMP}.x_position */
EIF_INTEGER_32 F1477_15780 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_INTEGER_32) 0;
}

/* {EV_HEADER_ITEM_IMP}.y_position */
EIF_INTEGER_32 F1477_15781 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_INTEGER_32) 0;
}

/* {EV_HEADER_ITEM_IMP}.screen_x */
EIF_INTEGER_32 F1477_15782 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_INTEGER_32) 0;
}

/* {EV_HEADER_ITEM_IMP}.screen_y */
EIF_INTEGER_32 F1477_15783 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_INTEGER_32) 0;
}

/* {EV_HEADER_ITEM_IMP}.height */
EIF_INTEGER_32 F1477_15784 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_INTEGER_32) 0;
}

/* {EV_HEADER_ITEM_IMP}.minimum_height */
EIF_INTEGER_32 F1477_15785 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_INTEGER_32) 0;
}

/* {EV_HEADER_ITEM_IMP}.process_draw_event */
EIF_BOOLEAN F1477_15786 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1477_15757(Current);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_HEADER_ITEM_IMP}.process_gdk_event */
void F1477_15787 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc8);
	RTLR(2,loc7);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
	loc3 = (EIF_POINTER) gtk_tree_view_column_get_button((GtkTreeViewColumn*) tp1);
	loc8 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	gtk_widget_set_can_focus((GtkWidget*) loc3, (gboolean) (EIF_BOOLEAN) 0);
	if ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 0L))) {
		loc5 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(13123,F1314_13123, (Current)))+ _LNGOFF_49_16_0_11_);
		loc6 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(13123,F1314_13123, (Current)))+ _LNGOFF_49_16_0_12_);
		loc1 = (EIF_POINTER) g_value_peek_pointer((GValue*) arg2);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc1 != tp1)) {
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_8) (((GdkEventAny *)loc1)->type);
			if ((EIF_BOOLEAN)(loc2 == (EIF_INTEGER_32) GDK_MOTION_NOTIFY)) {
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
					loc7 = RTOSCF(12922,F1305_12922, (RTCV(RTOSCF(13123,F1314_13123, (Current)))));
					tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->x);
					ti4_1 = (EIF_INTEGER_32) tr8_1;
					F998_8210(RTCW(loc7), ti4_1, ((EIF_INTEGER_32) 1L));
					tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->y);
					ti4_1 = (EIF_INTEGER_32) tr8_1;
					F998_8210(RTCW(loc7), ti4_1, ((EIF_INTEGER_32) 2L));
					F998_8201(RTCW(loc7), (EIF_REAL_64) 0.5, ((EIF_INTEGER_32) 3L));
					F998_8201(RTCW(loc7), (EIF_REAL_64) 0.5, ((EIF_INTEGER_32) 4L));
					F998_8201(RTCW(loc7), (EIF_REAL_64) 0.5, ((EIF_INTEGER_32) 5L));
					tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->x_root);
					ti4_1 = (EIF_INTEGER_32) tr8_1;
					F998_8210(RTCW(loc7), (EIF_INTEGER_32) (ti4_1 + loc5), ((EIF_INTEGER_32) 6L));
					tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->y_root);
					ti4_1 = (EIF_INTEGER_32) tr8_1;
					F998_8210(RTCW(loc7), (EIF_INTEGER_32) (ti4_1 + loc6), ((EIF_INTEGER_32) 7L));
					tr1 = *(EIF_REFERENCE *)(Current);
					F813_6165(RTCW(tr1), loc7);
				}
			} else {
				if ((EIF_BOOLEAN)(loc2 == (EIF_INTEGER_32) GDK_BUTTON_PRESS)) {
					if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFFF9,8,997,1033,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr2 = RTLNTS(typres0.id, 9, 1);
						}
						tr8_1 = (EIF_REAL_64) (((GdkEventButton *)loc1)->x);
						ti4_1 = (EIF_INTEGER_32) tr8_1;
						((EIF_TYPED_VALUE *)tr2+1)->it_i4 = ti4_1;
						tr8_1 = (EIF_REAL_64) (((GdkEventButton *)loc1)->y);
						ti4_1 = (EIF_INTEGER_32) tr8_1;
						((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
						ti4_1 = (EIF_INTEGER_32) (((GdkEventButton *)loc1)->button);
						((EIF_TYPED_VALUE *)tr2+3)->it_i4 = ti4_1;
						((EIF_TYPED_VALUE *)tr2+4)->it_r8 = (EIF_REAL_64) 0.5;
						((EIF_TYPED_VALUE *)tr2+5)->it_r8 = (EIF_REAL_64) 0.5;
						((EIF_TYPED_VALUE *)tr2+6)->it_r8 = (EIF_REAL_64) 0.5;
						tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->x_root);
						ti4_1 = (EIF_INTEGER_32) tr8_1;
						((EIF_TYPED_VALUE *)tr2+7)->it_i4 = (EIF_INTEGER_32) (ti4_1 + loc5);
						tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->y_root);
						ti4_1 = (EIF_INTEGER_32) tr8_1;
						((EIF_TYPED_VALUE *)tr2+8)->it_i4 = (EIF_INTEGER_32) (ti4_1 + loc6);
						F813_6165(RTCW(tr1), tr2);
					}
					if ((EIF_BOOLEAN)(loc8 != NULL)) {
						tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->x_root);
						loc4 = (EIF_INTEGER_32) tr8_1;
						ti4_1 = F1315_13126(RTCW(loc8));
						tr1 = F1280_12327(Current);
						ti4_2 = F1408_14965(RTCW(loc8), tr1);
						loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 + loc5) - ti4_1) - ti4_2);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_16_);
						if ((EIF_BOOLEAN)(tr1 != NULL)) {
							tr1 = F160_3078(RTCW(loc8));
							{
								static EIF_TYPE_INDEX typarr0[] = {0xFFF9,8,997,1033,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								tr2 = RTLNTS(typres0.id, 9, 1);
							}
							((EIF_TYPED_VALUE *)tr2+1)->it_i4 = loc4;
							tr8_1 = (EIF_REAL_64) (((GdkEventButton *)loc1)->y);
							ti4_1 = (EIF_INTEGER_32) tr8_1;
							((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
							ti4_1 = (EIF_INTEGER_32) (((GdkEventButton *)loc1)->button);
							((EIF_TYPED_VALUE *)tr2+3)->it_i4 = ti4_1;
							((EIF_TYPED_VALUE *)tr2+4)->it_r8 = (EIF_REAL_64) 0.5;
							((EIF_TYPED_VALUE *)tr2+5)->it_r8 = (EIF_REAL_64) 0.5;
							((EIF_TYPED_VALUE *)tr2+6)->it_r8 = (EIF_REAL_64) 0.5;
							tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->x_root);
							ti4_1 = (EIF_INTEGER_32) tr8_1;
							((EIF_TYPED_VALUE *)tr2+7)->it_i4 = (EIF_INTEGER_32) (ti4_1 + loc5);
							tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->y_root);
							ti4_1 = (EIF_INTEGER_32) tr8_1;
							((EIF_TYPED_VALUE *)tr2+8)->it_i4 = (EIF_INTEGER_32) (ti4_1 + loc6);
							F813_6165(RTCW(tr1), tr2);
						}
						tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_3_);
						if ((EIF_BOOLEAN)(tr1 != NULL)) {
							tr1 = F75_1222(RTCW(loc8));
							{
								static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,997,1168,1033,1033,1033,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								tr2 = RTLNTS(typres0.id, 5, 0);
							}
							tr3 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
							((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
							RTAR(tr2,tr3);
							((EIF_TYPED_VALUE *)tr2+2)->it_i4 = loc4;
							tr8_1 = (EIF_REAL_64) (((GdkEventButton *)loc1)->y);
							ti4_1 = (EIF_INTEGER_32) tr8_1;
							((EIF_TYPED_VALUE *)tr2+3)->it_i4 = ti4_1;
							ti4_1 = (EIF_INTEGER_32) (((GdkEventButton *)loc1)->button);
							((EIF_TYPED_VALUE *)tr2+4)->it_i4 = ti4_1;
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4892[Dtype(RTCW(tr1))-687])(tr1, tr2);
						}
					}
				} else {
					if ((EIF_BOOLEAN)(loc2 == (EIF_INTEGER_32) GDK_BUTTON_RELEASE)) {
						tb1 = '\0';
						if ((EIF_BOOLEAN)(loc8 != NULL)) {
							tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_18_);
							tb1 = (EIF_BOOLEAN)(tr1 != NULL);
						}
						if (tb1) {
							tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->x_root);
							loc4 = (EIF_INTEGER_32) tr8_1;
							ti4_1 = F1315_13126(RTCW(loc8));
							tr1 = F1280_12327(Current);
							ti4_2 = F1408_14965(RTCW(loc8), tr1);
							loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 + loc5) - ti4_1) - ti4_2);
							tr1 = F160_3082(RTCW(loc8));
							{
								static EIF_TYPE_INDEX typarr0[] = {0xFFF9,8,997,1033,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								tr2 = RTLNTS(typres0.id, 9, 1);
							}
							((EIF_TYPED_VALUE *)tr2+1)->it_i4 = loc4;
							tr8_1 = (EIF_REAL_64) (((GdkEventButton *)loc1)->y);
							ti4_1 = (EIF_INTEGER_32) tr8_1;
							((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
							ti4_1 = (EIF_INTEGER_32) (((GdkEventButton *)loc1)->button);
							((EIF_TYPED_VALUE *)tr2+3)->it_i4 = ti4_1;
							((EIF_TYPED_VALUE *)tr2+4)->it_r8 = (EIF_REAL_64) 0.5;
							((EIF_TYPED_VALUE *)tr2+5)->it_r8 = (EIF_REAL_64) 0.5;
							((EIF_TYPED_VALUE *)tr2+6)->it_r8 = (EIF_REAL_64) 0.5;
							tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->x_root);
							ti4_1 = (EIF_INTEGER_32) tr8_1;
							((EIF_TYPED_VALUE *)tr2+7)->it_i4 = (EIF_INTEGER_32) (ti4_1 + loc5);
							tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->y_root);
							ti4_1 = (EIF_INTEGER_32) tr8_1;
							((EIF_TYPED_VALUE *)tr2+8)->it_i4 = (EIF_INTEGER_32) (ti4_1 + loc6);
							F813_6165(RTCW(tr1), tr2);
						}
					} else {
						if ((EIF_BOOLEAN)(loc2 == (EIF_INTEGER_32) GDK_2BUTTON_PRESS)) {
							if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) != NULL)) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								{
									static EIF_TYPE_INDEX typarr0[] = {0xFFF9,8,997,1033,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
									EIF_TYPE typres0;
									static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
									
									typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
									tr2 = RTLNTS(typres0.id, 9, 1);
								}
								tr8_1 = (EIF_REAL_64) (((GdkEventButton *)loc1)->x);
								ti4_1 = (EIF_INTEGER_32) tr8_1;
								((EIF_TYPED_VALUE *)tr2+1)->it_i4 = ti4_1;
								tr8_1 = (EIF_REAL_64) (((GdkEventButton *)loc1)->y);
								ti4_1 = (EIF_INTEGER_32) tr8_1;
								((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
								ti4_1 = (EIF_INTEGER_32) (((GdkEventButton *)loc1)->button);
								((EIF_TYPED_VALUE *)tr2+3)->it_i4 = ti4_1;
								((EIF_TYPED_VALUE *)tr2+4)->it_r8 = (EIF_REAL_64) 0.5;
								((EIF_TYPED_VALUE *)tr2+5)->it_r8 = (EIF_REAL_64) 0.5;
								((EIF_TYPED_VALUE *)tr2+6)->it_r8 = (EIF_REAL_64) 0.5;
								tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->x_root);
								ti4_1 = (EIF_INTEGER_32) tr8_1;
								((EIF_TYPED_VALUE *)tr2+7)->it_i4 = (EIF_INTEGER_32) (ti4_1 + loc5);
								tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->y_root);
								ti4_1 = (EIF_INTEGER_32) tr8_1;
								((EIF_TYPED_VALUE *)tr2+8)->it_i4 = (EIF_INTEGER_32) (ti4_1 + loc6);
								F813_6165(RTCW(tr1), tr2);
							}
							if ((EIF_BOOLEAN)(loc8 != NULL)) {
								tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->x_root);
								loc4 = (EIF_INTEGER_32) tr8_1;
								ti4_1 = F1315_13126(RTCW(loc8));
								tr1 = F1280_12327(Current);
								ti4_2 = F1408_14965(RTCW(loc8), tr1);
								loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 + loc5) - ti4_1) - ti4_2);
								tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_17_);
								if ((EIF_BOOLEAN)(tr1 != NULL)) {
									tr1 = F160_3080(RTCW(loc8));
									{
										static EIF_TYPE_INDEX typarr0[] = {0xFFF9,8,997,1033,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
										EIF_TYPE typres0;
										static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
										
										typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
										tr2 = RTLNTS(typres0.id, 9, 1);
									}
									((EIF_TYPED_VALUE *)tr2+1)->it_i4 = loc4;
									tr8_1 = (EIF_REAL_64) (((GdkEventButton *)loc1)->y);
									ti4_1 = (EIF_INTEGER_32) tr8_1;
									((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
									ti4_1 = (EIF_INTEGER_32) (((GdkEventButton *)loc1)->button);
									((EIF_TYPED_VALUE *)tr2+3)->it_i4 = ti4_1;
									((EIF_TYPED_VALUE *)tr2+4)->it_r8 = (EIF_REAL_64) 0.5;
									((EIF_TYPED_VALUE *)tr2+5)->it_r8 = (EIF_REAL_64) 0.5;
									((EIF_TYPED_VALUE *)tr2+6)->it_r8 = (EIF_REAL_64) 0.5;
									tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->x_root);
									ti4_1 = (EIF_INTEGER_32) tr8_1;
									((EIF_TYPED_VALUE *)tr2+7)->it_i4 = (EIF_INTEGER_32) (ti4_1 + loc5);
									tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->y_root);
									ti4_1 = (EIF_INTEGER_32) tr8_1;
									((EIF_TYPED_VALUE *)tr2+8)->it_i4 = (EIF_INTEGER_32) (ti4_1 + loc6);
									F813_6165(RTCW(tr1), tr2);
								}
								tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_4_);
								if ((EIF_BOOLEAN)(tr1 != NULL)) {
									tr1 = F75_1221(RTCW(loc8));
									{
										static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,997,0,0,1033,1033,1033,0xFFFF};
										EIF_TYPE typres0;
										{
											EIF_TYPE l_type;
											l_type = eif_final_id(Y10034,Y10034_gen_type,dftype,1279);
											typarr0[3] = l_type.annotations | 0xFF00;
											typarr0[4] = l_type.id;
										}
										
										typres0 = eif_compound_id(dftype, typarr0);
										tr2 = RTLNTS(typres0.id, 5, 0);
									}
									tr3 = F1280_12327(Current);
									((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
									RTAR(tr2,tr3);
									((EIF_TYPED_VALUE *)tr2+2)->it_i4 = loc4;
									tr8_1 = (EIF_REAL_64) (((GdkEventButton *)loc1)->y);
									ti4_1 = (EIF_INTEGER_32) tr8_1;
									((EIF_TYPED_VALUE *)tr2+3)->it_i4 = ti4_1;
									ti4_1 = (EIF_INTEGER_32) (((GdkEventButton *)loc1)->button);
									((EIF_TYPED_VALUE *)tr2+4)->it_i4 = ti4_1;
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4892[Dtype(RTCW(tr1))-687])(tr1, tr2);
								}
							}
						} else {
							if ((EIF_BOOLEAN)(loc2 == (EIF_INTEGER_32) GDK_EXPOSE)) {
								F1477_15757(Current);
							}
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {EV_HEADER_ITEM_IMP}.set_parent_imp */
RTEOMS(15787,1);
void F1477_15788 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLR(8,loc3);
	RTLR(9,loc4);
	RTLIU(10);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) arg1;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)((EIF_POINTER) gtk_widget_get_parent((GtkWidget*) tp1) == tp2)) {
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
			tp2 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_);
			inline_F101_1906(tp1, tp2);
		}
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
		loc1 = (EIF_POINTER) gtk_tree_view_column_get_button((GtkTreeViewColumn*) tp1);
		gtk_widget_set_can_focus((GtkWidget*) loc1, (gboolean) (EIF_BOOLEAN) 0);
		loc2 = RTOSCF(13123,F1314_13123, (Current));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,960,1033,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_42_);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_22_8_6_0_);
		((EIF_TYPED_VALUE *)tr1+2)->it_i4 = ti4_1;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,2,997,1033,1069,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A391_323_3_4, (EIF_POINTER) _A391_323_3_4, (EIF_POINTER)(F941_7734),tr1, 1, 2);
		}
		F1314_13102(Current, loc1, RTOMS(15787,0), tr4);
		tr1 = F1314_13106(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
		tr1 = RTOSCF(369,F16_369, (Current));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,960,1069,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 0);
		}
		tr3 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_42_);
		((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
		RTAR(tr2,tr3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
		((EIF_TYPED_VALUE *)tr2+2)->it_p = tp1;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1069,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr5= RTLNRF(typres0.id, (EIF_POINTER) __A391_329_3, (EIF_POINTER) _A391_329_3, (EIF_POINTER)(F942_7741),tr2, 1, 1);
		}
		F1314_13102(Current, loc1, tr1, tr5);
		tr1 = F1314_13106(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
			loc1 = (EIF_POINTER) gtk_tree_view_column_get_button((GtkTreeViewColumn*) tp1);
			F926_6943(loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) NULL;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			F926_6943(loc4);
			*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) NULL;
		}
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		tp2 = (EIF_POINTER) gtk_label_new((gchar*) tp3);
		inline_F101_1906(tp1, tp2);
	}
	RTLE;
}

/* {EV_HEADER_ITEM_IMP}.parent_imp */
EIF_REFERENCE F1477_15791 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_21_);
}


/* {EV_HEADER_ITEM_IMP}.tree_view_column_width */
EIF_INTEGER_32 F1477_15792 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_0_);
	return (EIF_INTEGER_32) inline_F101_1908(tp1);
}

/* {EV_HEADER_ITEM_IMP}.real_pointed_target */
EIF_REFERENCE F1477_15794 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {EV_HEADER_ITEM_IMP}.c_object_dispose */
void F1477_15795 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_);
		inline_F100_1400(tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_22_8_6_4_0_3_) = (EIF_POINTER) tp2;
	}
	F1314_13113(Current);
	RTLE;
}

void EIF_Minit831 (void)
{
	GTCX
	RTPOMS(15787,0,"event",5,1987134580);
}


#ifdef __cplusplus
}
#endif
