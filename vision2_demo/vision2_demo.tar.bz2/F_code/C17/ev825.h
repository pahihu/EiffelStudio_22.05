
#ifndef _C17_ev825_
#define _C17_ev825_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1471_15729(EIF_REFERENCE);
extern EIF_BOOLEAN F1471_15730(EIF_REFERENCE);
extern void EIF_Minit825(void);
extern void F1469_15709(EIF_REFERENCE);
extern void F1469_15721(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
