/*
 * Code for class EV_VERTICAL_SCROLL_BAR_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev828.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_VERTICAL_SCROLL_BAR_IMP}.make */
void F1474_15737 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	EIF_REAL_32 tr4_4;
	EIF_REAL_32 tr4_5;
	EIF_REAL_32 tr4_6;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	tr4_2 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	tr4_3 = (EIF_REAL_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) + ((EIF_INTEGER_32) 10L)));
	tr4_4 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	tr4_5 = (EIF_REAL_32) (((EIF_INTEGER_32) 10L));
	tr4_6 = (EIF_REAL_32) (((EIF_INTEGER_32) 10L));
	tp1 = (EIF_POINTER) gtk_adjustment_new((gfloat) tr4_1, (gfloat) tr4_2, (gfloat) tr4_3, (gfloat) tr4_4, (gfloat) tr4_5, (gfloat) tr4_6);
	*(EIF_POINTER *)(Current+ _PTROFF_44_13_10_7_0_1_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_13_10_7_0_1_);
	tp1 = (EIF_POINTER) gtk_scrollbar_new((GtkOrientation) (EIF_NATURAL_8) ((EIF_INTEGER_32) 1L), (GtkAdjustment*) tp1);
	F1314_13098(Current, tp1);
	F1464_15676(Current);
	RTLE;
}

void EIF_Minit828 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
