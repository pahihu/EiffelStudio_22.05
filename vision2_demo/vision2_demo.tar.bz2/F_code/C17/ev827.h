
#ifndef _C17_ev827_
#define _C17_ev827_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1473_15735(EIF_REFERENCE);
extern void EIF_Minit827(void);
extern EIF_POINTER F1464_15692(EIF_REFERENCE);
extern void F1314_13098(EIF_REFERENCE, EIF_POINTER);
extern void F1464_15676(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
