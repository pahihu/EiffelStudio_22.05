/*
 * Code for class EV_CHECK_BUTTON_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev817.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F103_2335
static void inline_F103_2335 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_xalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F103_2335
#endif
#ifndef INLINE_F103_2336
static void inline_F103_2336 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_yalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F103_2336
#endif
#ifndef INLINE_F10_111
static EIF_INTEGER_32 inline_F10_111 (void)
{
	return GTK_ALIGN_END
	;
}
#define INLINE_F10_111
#endif
#ifndef INLINE_F102_2106
static void inline_F102_2106 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return gtk_widget_set_halign ((GtkWidget *)arg1, (GtkAlign)arg2)
	;
}
#define INLINE_F102_2106
#endif
#ifndef INLINE_F10_112
static EIF_INTEGER_32 inline_F10_112 (void)
{
	return GTK_ALIGN_CENTER
	;
}
#define INLINE_F10_112
#endif
#ifndef INLINE_F102_2109
static void inline_F102_2109 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return gtk_widget_set_valign ((GtkWidget *)arg1, (GtkAlign)arg2)
	;
}
#define INLINE_F102_2109
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CHECK_BUTTON_IMP}.new_gtk_button */
EIF_POINTER F1463_15671 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) (EIF_POINTER) gtk_check_button_new();
}

/* {EV_CHECK_BUTTON_IMP}.make */
void F1463_15672 (EIF_REFERENCE Current)
{
	GTCX
	struct eif_ex_1534 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(194, 0x00).id);
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1460_15638(Current);
	F1460_15645(Current);
	tr1 = F195_3411(RTCW(loc1));
	F1323_13281(Current, tr1);
	tr1 = F195_3412(RTCW(loc1));
	F1460_15650(Current, tr1);
	RTLE;
}

/* {EV_CHECK_BUTTON_IMP}.set_text */
void F1463_15673 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1343_13591(Current, arg1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
	inline_F103_2335(tp1, (EIF_REAL_32) 0.0);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
	inline_F103_2336(tp1, (EIF_REAL_32) 0.5);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(F1341_13579(Current) != tp1)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_1_);
		ti4_1 = inline_F10_111();
		inline_F102_2106(tp1, ti4_1);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_1_);
		ti4_1 = inline_F10_112();
		inline_F102_2109(tp1, ti4_1);
	}
	RTLE;
}

void EIF_Minit817 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
