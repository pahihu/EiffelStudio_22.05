/*
 * Code for class EV_COMBO_BOX_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev811.h"
#include <ev_gtk.h>
#include "ev_c_util.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F17_402
static EIF_NATURAL_8 inline_F17_402 (void)
{
	return GTK_ORIENTATION_VERTICAL
	;
}
#define INLINE_F17_402
#endif
#ifndef INLINE_F102_2119
static EIF_POINTER inline_F102_2119 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F102_2119
#endif
#ifndef INLINE_F101_1858
static void inline_F101_1858 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_combo_box_set_model ((GtkComboBox*) arg1, (GtkTreeModel*) arg2)
	;
}
#define INLINE_F101_1858
#endif
#ifndef INLINE_F101_1859
static void inline_F101_1859 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_combo_box_set_entry_text_column ((GtkComboBox*) arg1, (gint) arg2)
	;
}
#define INLINE_F101_1859
#endif
#ifndef INLINE_F101_1863
static void inline_F101_1863 (EIF_POINTER arg1)
{
	gtk_cell_layout_clear ((GtkCellLayout*) arg1)
	;
}
#define INLINE_F101_1863
#endif
#ifndef INLINE_F101_1914
static EIF_POINTER inline_F101_1914 (void)
{
	return (EIF_POINTER) (gtk_cell_renderer_text_new())
	;
}
#define INLINE_F101_1914
#endif
#ifndef INLINE_F101_1860
static void inline_F101_1860 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	gtk_cell_layout_pack_start ((GtkCellLayout*) arg1, (GtkCellRenderer*) arg2, (gboolean) arg3)
	;
}
#define INLINE_F101_1860
#endif
#ifndef INLINE_F101_1862
static void inline_F101_1862 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	gtk_cell_layout_reorder ((GtkCellLayout*) arg1, (GtkCellRenderer*) arg2, (gint) arg3)
	;
}
#define INLINE_F101_1862
#endif
#ifndef INLINE_F101_1861
static void inline_F101_1861 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4)
{
	gtk_cell_layout_set_attributes ((GtkCellLayout*) arg1, (GtkCellRenderer*) arg2, (gchar*) arg3, (gint) arg4, NULL)
	;
}
#define INLINE_F101_1861
#endif
#ifndef INLINE_F101_1915
static EIF_POINTER inline_F101_1915 (void)
{
	return (EIF_POINTER) (gtk_cell_renderer_pixbuf_new())
	;
}
#define INLINE_F101_1915
#endif
#ifndef INLINE_F101_1853
static EIF_INTEGER_32 inline_F101_1853 (EIF_POINTER arg1)
{
	return (EIF_INTEGER_32) (gtk_combo_box_get_active ((GtkComboBox*) arg1))
	;
}
#define INLINE_F101_1853
#endif
#ifndef INLINE_F101_1854
static void inline_F101_1854 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_combo_box_set_active ((GtkComboBox*) arg1, (gint) arg2)
	;
}
#define INLINE_F101_1854
#endif
#ifndef INLINE_F1457_15598
static void inline_F1457_15598 (EIF_POINTER arg1, EIF_POINTER* arg2)
{
	{
gtk_container_forall (GTK_CONTAINER (arg1), (GtkCallback) c_gtk_return_combo_toggle, (GtkWidget**) arg2);
}
	;
}
#define INLINE_F1457_15598
#endif
#ifndef INLINE_F101_1823
static void inline_F101_1823 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	gtk_widget_set_size_request ((GtkWidget*) arg1, (gint) arg2, (gint) arg3)
	;
}
#define INLINE_F101_1823
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_COMBO_BOX_IMP}.needs_event_box */
EIF_BOOLEAN F1457_15579 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_COMBO_BOX_IMP}.call_selection_action_sequences */
void F1457_15581 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = F1457_15586(Current);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_56_);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_59_12_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
		gtk_combo_box_popdown((GtkComboBox*) tp1);
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		loc3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
		loc3 = RTRV(eif_new_type(1479, 0x00), loc3);
		RTCT0("l_selected_item_imp /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_3_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F106_2479(RTCW(loc3));
			F813_6165(RTCW(tr1), NULL);
		}
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F813_6165(RTCW(tr1), NULL);
		}
	}
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_4_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F106_2481(RTCW(loc2));
			F813_6165(RTCW(tr1), NULL);
		}
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F813_6165(RTCW(tr1), NULL);
		}
	}
	RTAR(Current, loc3);
	*(EIF_REFERENCE *)(Current + _REFACS_56_) = (EIF_REFERENCE) loc3;
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		F1454_15540(Current);
	}
	RTLE;
}

/* {EV_COMBO_BOX_IMP}.make */
RTEOMS(15582,3);
void F1457_15583 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	tu1_1 = inline_F17_402();
	loc4 = inline_F102_2119(tu1_1, ((EIF_INTEGER_32) 0L));
	F1314_13098(Current, loc4);
	tp1 = (EIF_POINTER) gtk_combo_box_new_with_entry();
	*(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	gtk_box_pack_start((GtkBox*) loc4, (GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0, (gboolean) (EIF_BOOLEAN) 0, (guint) ((EIF_INTEGER_32) 0L));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	tp1 = (EIF_POINTER) gtk_bin_get_child((GtkBin*) tp1);
	*(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_1_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	tr1 = RTOSCF(374,F16_374, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,997,960,1033,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 4, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(13123,F1314_13123, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_59_16_10_0_);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
	((EIF_TYPED_VALUE *)tr2+3)->it_i4 = ((EIF_INTEGER_32) 1L);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A391_321, (EIF_POINTER) _A391_321, (EIF_POINTER)(F941_7732),tr2, 1, 0);
	}
	F1314_13102(Current, tp1, tr1, tr3);
	tr1 = F1314_13106(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_57_) = (EIF_REFERENCE) tr1;
	F1456_15549(Current);
	F1454_15514(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_2_);
	inline_F101_1858(tp1, tp2);
	loc3 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F928_6962(RTCW(loc3), RTOMS(15582,0));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	tp2 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	gtk_widget_set_name((GtkWidget*) tp1, (gchar*) tp2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	inline_F101_1859(tp1, ((EIF_INTEGER_32) 1L));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	inline_F101_1863(tp1);
	loc1 = inline_F101_1914();
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	inline_F101_1860(tp1, loc1, (EIF_BOOLEAN) 1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	inline_F101_1862(tp1, loc1, ((EIF_INTEGER_32) 0L));
	loc2 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F928_6962(RTCW(loc2), RTOMS(15582,1));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	tp2 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_0_1_0_1_0_0_);
	inline_F101_1861(tp1, loc1, tp2, ((EIF_INTEGER_32) 1L));
	loc1 = inline_F101_1915();
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	inline_F101_1860(tp1, loc1, (EIF_BOOLEAN) 0);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	inline_F101_1862(tp1, loc1, ((EIF_INTEGER_32) 0L));
	loc2 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F928_6962(RTCW(loc2), RTOMS(15582,2));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	tp2 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_0_1_0_1_0_0_);
	inline_F101_1861(tp1, loc1, tp2, ((EIF_INTEGER_32) 0L));
	F1454_15509(Current, ((EIF_INTEGER_32) 4L));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	tr1 = RTOSCF(371,F16_371, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,960,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(13123,F1314_13123, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_59_16_10_0_);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A391_320, (EIF_POINTER) _A391_320, (EIF_POINTER)(F941_7731),tr2, 1, 0);
	}
	F1314_13102(Current, tp1, tr1, tr3);
	F1441_15191(Current);
	F1427_15144(Current);
	RTLE;
}

/* {EV_COMBO_BOX_IMP}.insert_i_th */
void F1457_15584 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1456_15574(Current, arg1, arg2);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(F1308_13070(Current) == ((EIF_INTEGER_32) 1L))) {
		tb2 = F1109_10164(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		F1109_10165(RTCW(arg1));
	}
	RTLE;
}

/* {EV_COMBO_BOX_IMP}.has_focus */
EIF_BOOLEAN F1457_15585 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_59_13_);
}


/* {EV_COMBO_BOX_IMP}.selected_item */
EIF_REFERENCE F1457_15586 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	loc1 = inline_F101_1853(tp1);
	if ((EIF_BOOLEAN) (loc1 >= ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		Result = F664_5454(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
	}
	RTLE;
	return Result;
}

/* {EV_COMBO_BOX_IMP}.selected_items */
EIF_REFERENCE F1457_15587 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {663,1189,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 663, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F664_5447(RTCW(Result), ((EIF_INTEGER_32) 0L));
	loc1 = F1457_15586(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(Result))-534])(Result, loc1);
	}
	RTLE;
	return Result;
}

/* {EV_COMBO_BOX_IMP}.select_item */
void F1457_15588 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	inline_F101_1854(tp1, (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)));
}

/* {EV_COMBO_BOX_IMP}.deselect_item */
void F1457_15589 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	inline_F101_1854(tp1, ((EIF_INTEGER_32) -1L));
}

/* {EV_COMBO_BOX_IMP}.clear_selection */
void F1457_15590 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	inline_F101_1854(tp1, ((EIF_INTEGER_32) -1L));
}

/* {EV_COMBO_BOX_IMP}.on_focus_changed */
void F1457_15592 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	if (arg1) {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_59_12_)) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_59_12_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				F813_6165(RTCW(tr1), NULL);
			}
			loc2 = F1315_13157(Current);
			loc2 = RTRV(eif_new_type(1403, 0x00), loc2);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				tb2 = F1315_13154(RTCW(loc2));
				tb1 = tb2;
			}
			if (tb1) {
				F1404_14917(RTCW(loc2));
			}
		} else {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_59_13_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F1366_13910(Current, arg1);
		}
	} else {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
		inline_F1457_15598(tp1, (EIF_POINTER *) &(loc1));
		tb1 = '\0';
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc1 != tp1)) {
			tb1 = (EIF_BOOLEAN) EIF_TEST(gtk_toggle_button_get_active((GtkToggleButton*) loc1));
		}
		if (tb1) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_59_12_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_59_13_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			F1366_13910(Current, arg1);
		}
	}
	RTLE;
}

/* {EV_COMBO_BOX_IMP}.is_list_shown */
EIF_BOOLEAN F1457_15593 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_59_12_);
}


/* {EV_COMBO_BOX_IMP}.retrieve_toggle_button */
void F1457_15596 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	inline_F1457_15598(tp1, (EIF_POINTER *) &(loc1));
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		inline_F101_1823(loc1, ((EIF_INTEGER_32) -1L), ((EIF_INTEGER_32) 1L));
		gtk_widget_set_can_focus((GtkWidget*) loc1, (gboolean) (EIF_BOOLEAN) 0);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_57_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tb2 = *(EIF_BOOLEAN *)(loc2+ _CHROFF_0_0_);
			tb1 = tb2;
		}
		if (tb1) {
			F926_6943(loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_57_) = (EIF_REFERENCE) NULL;
		}
		tb1 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_58_);
		loc3 = tr1;
		if (!((EIF_BOOLEAN) !EIF_TEST(loc3))) {
			tb2 = *(EIF_BOOLEAN *)(loc3+ _CHROFF_0_0_);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			tr1 = RTOSCF(379,F16_379, (Current));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,997,960,1033,1033,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNTS(typres0.id, 4, 0);
			}
			tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(13123,F1314_13123, (Current))) + _REFACS_42_);
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_59_16_10_0_);
			((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
			((EIF_TYPED_VALUE *)tr2+3)->it_i4 = ((EIF_INTEGER_32) 2L);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3= RTLNRF(typres0.id, (EIF_POINTER) __A391_321, (EIF_POINTER) _A391_321, (EIF_POINTER)(F941_7732),tr2, 1, 0);
			}
			F1314_13102(Current, loc1, tr1, tr3);
			tr1 = F1314_13106(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_58_) = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {EV_COMBO_BOX_IMP}.toggle_button_toggled */
void F1457_15597 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
	inline_F1457_15598(tp1, (EIF_POINTER *) &(loc1));
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		if ((EIF_BOOLEAN) EIF_TEST(gtk_toggle_button_get_active((GtkToggleButton*) loc1))) {
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_59_13_)) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_59_12_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				F813_6165(RTCW(tr1), NULL);
			}
		} else {
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_59_16_10_12_0_3_);
			gtk_combo_box_popdown((GtkComboBox*) tp1);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_59_13_)) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_59_12_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
					F813_6165(RTCW(tr1), NULL);
				}
			}
		}
	}
	RTLE;
}

/* {EV_COMBO_BOX_IMP}.return_combo_toggle */
void F1457_15598 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER* arg2)
{
	GTCX
	
	
	inline_F1457_15598 ((EIF_POINTER) arg1, (EIF_POINTER*) arg2);
}

/* {EV_COMBO_BOX_IMP}.style_element_name */
EIF_REFERENCE F1457_15599 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTMS_EX_H("combobox > entry.combo",22,1491381103);
	RTLE;
	return Result;
}

/* {EV_COMBO_BOX_IMP}.pixmaps_size_changed */
void F1457_15601 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

void EIF_Minit811 (void)
{
	GTCX
	RTPOMS(15582,2,"pixbuf",6,93246054);
	RTPOMS(15582,1,"text",4,1952807028);
	RTPOMS(15582,0,"v2combobox",10,126500216);
}


#ifdef __cplusplus
}
#endif
