
#ifndef _C17_ev821_
#define _C17_ev821_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1467_15705(EIF_REFERENCE);
extern void EIF_Minit821(void);
extern EIF_POINTER F1464_15692(EIF_REFERENCE);
extern void F1466_15703(EIF_REFERENCE);
extern void F1314_13098(EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif

#endif
