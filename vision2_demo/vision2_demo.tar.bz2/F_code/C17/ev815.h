
#ifndef _C17_ev815_
#define _C17_ev815_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F1461_15657(EIF_REFERENCE);
extern void F1461_15658(EIF_REFERENCE);
extern EIF_BOOLEAN F1461_15659(EIF_REFERENCE);
extern void F1461_15660(EIF_REFERENCE);
extern EIF_POINTER F1461_15661(EIF_REFERENCE, EIF_POINTER);
extern EIF_POINTER F1461_15662(EIF_REFERENCE);
extern void EIF_Minit815(void);
extern void F1460_15638(EIF_REFERENCE);
extern void F1460_15645(EIF_REFERENCE);
extern EIF_POINTER F1314_13122(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
