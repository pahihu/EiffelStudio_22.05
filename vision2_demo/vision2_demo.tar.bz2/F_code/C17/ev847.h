
#ifndef _C17_ev847_
#define _C17_ev847_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1493_15950(EIF_REFERENCE);
extern void F1493_15951(EIF_REFERENCE);
extern EIF_BOOLEAN F1493_15952(EIF_REFERENCE);
extern void F1493_15953(EIF_REFERENCE);
extern void F1493_15954(EIF_REFERENCE);
extern EIF_BOOLEAN F1493_15955(EIF_REFERENCE);
extern void EIF_Minit847(void);
extern void F1492_15937(EIF_REFERENCE);
extern EIF_POINTER F1492_15943(EIF_REFERENCE);
extern void F1314_13098(EIF_REFERENCE, EIF_POINTER);
extern EIF_REFERENCE F1485_15917(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
