/*
 * Code for class EV_LIST_ITEM_LIST_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev810.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1456_15578
static EIF_POINTER inline_F1456_15578 (void)
{
	return (EIF_POINTER) (gtk_list_store_new (2, GDK_TYPE_PIXBUF, G_TYPE_STRING))
	;
}
#define INLINE_F1456_15578
#endif
#ifndef INLINE_F101_1943
static void inline_F101_1943 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	g_value_take_string ((GValue*) arg1, (gchar*) arg2)
	;
}
#define INLINE_F101_1943
#endif
#ifndef INLINE_F101_1955
static void inline_F101_1955 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	gtk_list_store_set_value ((GtkListStore*) arg1, (GtkTreeIter*) arg2, (gint) arg3, (GValue*) arg4)
	;
}
#define INLINE_F101_1955
#endif
#ifndef INLINE_F101_1933
static void inline_F101_1933 (EIF_POINTER arg1)
{
	g_value_init ((GValue*) arg1, G_TYPE_STRING)
	;
}
#define INLINE_F101_1933
#endif
#ifndef INLINE_F101_1957
static void inline_F101_1957 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	gtk_list_store_set ((GtkListStore*) arg1, (GtkTreeIter*) arg2, (gint) arg3, (GdkPixbuf*) arg4, -1)
	;
}
#define INLINE_F101_1957
#endif
#ifndef INLINE_F100_1400
static void inline_F100_1400 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F100_1400
#endif
#ifndef INLINE_F101_1951
static void inline_F101_1951 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	gtk_list_store_insert ((GtkListStore*) arg1, (GtkTreeIter*) arg2, (gint) arg3)
	;
}
#define INLINE_F101_1951
#endif
#ifndef INLINE_F101_1953
static void inline_F101_1953 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_list_store_remove ((GtkListStore*) arg1, (GtkTreeIter*) arg2)
	;
}
#define INLINE_F101_1953
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_LIST_ITEM_LIST_IMP}.make */
void F1456_15549 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1308_13068(Current);
	F1441_15182(Current);
	F1336_13553(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R12281[Dtype(Current)-1456])(Current);
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.initialize_model */
void F1456_15550 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = inline_F1456_15578();
	*(EIF_POINTER *)(Current + O12295[Dtype(Current)-1455]) = (EIF_POINTER) tp1;
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.item_from_coords */
EIF_REFERENCE F1456_15552 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {EV_LIST_ITEM_LIST_IMP}.update_pnd_connection */
void F1456_15554 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11167[dtype-1362])) {
		if ((EIF_BOOLEAN) (arg1 || (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O11142[dtype-1362]) != NULL))) {
			*(EIF_BOOLEAN *)(Current + O11167[dtype-1362]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !arg1 && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O11142[dtype-1362]) == NULL))) {
			*(EIF_BOOLEAN *)(Current + O11167[dtype-1362]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
	}
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.pre_pick_steps */
void F1456_15555 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_16 ti2_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O11146[dtype-1362]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O12289[dtype-1455]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O11147[dtype-1362]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O12290[dtype-1455]) = (EIF_REFERENCE) tr1;
	loc2 = *(EIF_REFERENCE *)(Current + O11142[dtype-1362]);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tr1 = RTOSCF(13123,F1314_13123, (Current));
		tr2 = RTCCL(loc2);
		F1305_12982(RTCW(tr1), Current, tr2);
	}
	loc1 = *(EIF_REFERENCE *)(Current + O12286[dtype-1455]);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F111_2517(RTCW(loc1));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,1033,1033,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNTS(typres0.id, 3, 1);
			}
			((EIF_TYPED_VALUE *)tr2+1)->it_i4 = arg1;
			((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg2;
			F813_6165(RTCW(tr1), tr2);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_16_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O11146[dtype-1362]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_17_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O11147[dtype-1362]) = (EIF_REFERENCE) tr1;
	} else {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O2508[dtype-110]) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O2508[dtype-110]);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,1033,1033,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNTS(typres0.id, 3, 1);
			}
			((EIF_TYPED_VALUE *)tr2+1)->it_i4 = arg1;
			((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg2;
			F813_6165(RTCW(tr1), tr2);
		}
	}
	ti2_1 = (EIF_INTEGER_16) arg3;
	*(EIF_INTEGER_16 *)(Current + O3008[dtype-155]) = (EIF_INTEGER_16) ti2_1;
	ti2_1 = (EIF_INTEGER_16) arg4;
	*(EIF_INTEGER_16 *)(Current + O3009[dtype-155]) = (EIF_INTEGER_16) ti2_1;
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_16 *)(Current + O11172[dtype-1362]) == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(*(EIF_INTEGER_16 *)(Current + O11173[dtype-1362]) == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L)))) {
			tr1 = RTOSCF(13123,F1314_13123, (Current));
			F1304_12840(RTCW(tr1), arg3, arg4);
		} else {
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O11172[dtype-1362]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			if ((EIF_BOOLEAN) (ti4_1 > F1366_13919(Current))) {
				ti2_1 = (EIF_INTEGER_16) F1366_13919(Current);
				*(EIF_INTEGER_16 *)(Current + O11172[dtype-1362]) = (EIF_INTEGER_16) ti2_1;
			}
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O11173[dtype-1362]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			if ((EIF_BOOLEAN) (ti4_1 > F1366_13920(Current))) {
				ti2_1 = (EIF_INTEGER_16) F1366_13920(Current);
				*(EIF_INTEGER_16 *)(Current + O11173[dtype-1362]) = (EIF_INTEGER_16) ti2_1;
			}
			tr1 = RTOSCF(13123,F1314_13123, (Current));
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O11172[dtype-1362]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O11173[dtype-1362]);
			ti4_2 = (EIF_INTEGER_32) ti2_1;
			F1304_12840(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + (EIF_INTEGER_32) (arg3 - arg1)), (EIF_INTEGER_32) (ti4_2 + (EIF_INTEGER_32) (arg4 - arg2)));
		}
	} else {
		tb1 = '\0';
		ti2_1 = *(EIF_INTEGER_16 *)(RTCW(loc1)+ _I16OFF_23_5_4_);
		if ((EIF_BOOLEAN)(ti2_1 == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L))) {
			ti2_1 = *(EIF_INTEGER_16 *)(RTCW(loc1)+ _I16OFF_23_5_5_);
			tb1 = (EIF_BOOLEAN)(ti2_1 == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L));
		}
		if (tb1) {
			tr1 = RTOSCF(13123,F1314_13123, (Current));
			F1304_12840(RTCW(tr1), arg3, arg4);
		} else {
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O11172[dtype-1362]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			if ((EIF_BOOLEAN) (ti4_1 > F1366_13919(Current))) {
				ti2_1 = (EIF_INTEGER_16) F1366_13919(Current);
				*(EIF_INTEGER_16 *)(Current + O11172[dtype-1362]) = (EIF_INTEGER_16) ti2_1;
			}
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O11173[dtype-1362]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			if ((EIF_BOOLEAN) (ti4_1 > (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R12285[dtype-1456])(Current))) {
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R12285[dtype-1456])(Current);
				ti2_1 = (EIF_INTEGER_16) ti4_1;
				*(EIF_INTEGER_16 *)(Current + O11173[dtype-1362]) = (EIF_INTEGER_16) ti2_1;
			}
			tr1 = RTOSCF(13123,F1314_13123, (Current));
			ti2_1 = *(EIF_INTEGER_16 *)(RTCW(loc1)+ _I16OFF_23_5_4_);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			ti2_1 = *(EIF_INTEGER_16 *)(RTCW(loc1)+ _I16OFF_23_5_5_);
			ti4_2 = (EIF_INTEGER_32) ti2_1;
			tr2 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
			tr3 = F1280_12327(RTCW(loc1));
			ti4_3 = F591_5016(RTCW(tr2), tr3, ((EIF_INTEGER_32) 1L));
			ti4_4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R12285[dtype-1456])(Current);
			F1304_12840(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + (EIF_INTEGER_32) (arg3 - arg1)), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 + (EIF_INTEGER_32) (arg4 - arg2)) + (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_3 - ((EIF_INTEGER_32) 1L)) * ti4_4)));
		}
	}
	F1363_13831(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.post_drop_steps */
void F1456_15556 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1364_13863(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O12289[dtype-1455]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11146[dtype-1362]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O12290[dtype-1455]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11147[dtype-1362]) = (EIF_REFERENCE) tr1;
	*(EIF_REFERENCE *)(Current + O12289[dtype-1455]) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + O12290[dtype-1455]) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + O12286[dtype-1455]) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.row_height */
EIF_INTEGER_32 F1456_15557 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
}

/* {EV_LIST_ITEM_LIST_IMP}.pebble_source */
EIF_REFERENCE F1456_15558 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O12286[Dtype(Current)-1455]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1280_12327(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTLE;
		return (EIF_REFERENCE) F1364_13860(Current);
	}/* NOTREACHED */
	
}

/* {EV_LIST_ITEM_LIST_IMP}.able_to_transport */
EIF_BOOLEAN F1456_15559 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O12286[Dtype(Current)-1455]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = F1480_15805(loc1, arg1);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTLE;
		return (EIF_BOOLEAN) F1364_13857(Current, arg1);
	}/* NOTREACHED */
	
}

/* {EV_LIST_ITEM_LIST_IMP}.ready_for_pnd_menu */
EIF_BOOLEAN F1456_15560 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O12286[Dtype(Current)-1455]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = F1480_15806(loc1, arg1, arg2);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTLE;
		return (EIF_BOOLEAN) F1364_13861(Current, arg1, arg2);
	}/* NOTREACHED */
	
}

/* {EV_LIST_ITEM_LIST_IMP}.call_pebble_function */
void F1456_15566 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O11142[dtype-1362]);
	tr1 = RTCCL(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O12287[dtype-1455]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O11143[dtype-1362]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O12288[dtype-1455]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O12286[dtype-1455]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_13_);
		tr1 = RTCCL(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O11142[dtype-1362]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_14_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O11143[dtype-1362]) = (EIF_REFERENCE) tr1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O11143[dtype-1362]);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,1033,1033,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 1);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
		((EIF_TYPED_VALUE *)tr1+2)->it_i4 = arg2;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7802[Dtype(loc2)-1072])(loc2, tr1);
		tr1 = RTCCL(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O11142[dtype-1362]) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.reset_pebble_function */
void F1456_15567 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O12287[dtype-1455]);
	tr1 = RTCCL(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11142[dtype-1362]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O12288[dtype-1455]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11143[dtype-1362]) = (EIF_REFERENCE) tr1;
	*(EIF_REFERENCE *)(Current + O12287[dtype-1455]) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + O12288[dtype-1455]) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.set_text_on_position */
void F1456_15570 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	loc1 = RTOSCF(13015,F1305_13015, (RTCV(RTOSCF(13123,F1314_13123, (Current)))));
	F928_6963(RTCW(loc1), arg2);
	loc2 = RTOSCF(15571,F1456_15571, (Current));
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	inline_F101_1943(loc2, tp1);
	tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
	tr1 = F664_5453(RTCW(tr1), arg1);
	loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc3 = RTRV(eif_new_type(1479, 0x00), loc3);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		loc4 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_20_);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tp1 = *(EIF_POINTER *)(Current + O12295[dtype-1455]);
			tp2 = F260_4057(RTCW(loc4));
			inline_F101_1955(tp1, tp2, ((EIF_INTEGER_32) 1L), loc2);
		}
	}
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.g_value_string_struct */
static EIF_POINTER F1456_15571_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (15571);
#define Result RTOSR(15571)
	Result = (EIF_POINTER) calloc (sizeof(GValue), 1);
	inline_F101_1933(Result);
	RTOSE (15571);
	RTEE;
	return Result;
#undef Result
}

EIF_POINTER F1456_15571 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15571,F1456_15571_body,(Current));
}

/* {EV_LIST_ITEM_LIST_IMP}.set_row_pixmap */
void F1456_15572 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1513, 0x00), loc1);
	RTCT0("pixmap_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc4 = F1510_16267(RTCW(loc1), *(EIF_INTEGER_32 *)(Current + O10996[dtype-1335]), *(EIF_INTEGER_32 *)(Current + O10997[dtype-1335]));
	tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
	tr1 = F664_5453(RTCW(tr1), arg1);
	loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc2 = RTRV(eif_new_type(1479, 0x00), loc2);
	RTCT0("a_list_item_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc3 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_20_);
	RTCT0("a_list_iter /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = *(EIF_POINTER *)(Current + O12295[dtype-1455]);
	tp2 = F260_4057(RTCW(loc3));
	inline_F101_1957(tp1, tp2, ((EIF_INTEGER_32) 0L), loc4);
	inline_F100_1400(loc4);
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.remove_row_pixmap */
void F1456_15573 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
	tr1 = F664_5453(RTCW(tr1), arg1);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1479, 0x00), loc1);
	RTCT0("a_list_item_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_20_);
	RTCT0("l_list_iter /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = *(EIF_POINTER *)(Current + O12295[dtype-1455]);
	tp2 = F260_4057(RTCW(loc2));
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp3 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp4 = tp3;
	inline_F101_1957(tp1, tp2, ((EIF_INTEGER_32) 0L), tp4);
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.insert_i_th */
void F1456_15574 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1479, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1480_15842(RTCW(loc1), Current);
		tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
		F664_5482(RTCW(tr1), arg2);
		tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4583[Dtype(RTCW(tr1))-663])(tr1, arg1);
		loc2 = RTLNS(eif_new_type(261, 0x00).id, 261, _OBJSIZ_1_1_0_0_0_1_0_0_);
		F260_4054(RTCW(loc2));
		F1480_15839(RTCW(loc1), loc2);
		tp1 = *(EIF_POINTER *)(Current + O12295[dtype-1455]);
		tp2 = F260_4057(RTCW(loc2));
		inline_F101_1951(tp1, tp2, (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
		tr1 = F1113_10183(RTCW(arg1));
		F1456_15570(Current, arg2, tr1);
		tr1 = F1108_10155(RTCW(arg1));
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			F1456_15572(Current, arg2, loc3);
		}
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_23_1_);
		if (tb1) {
			F1456_15554(Current, (EIF_BOOLEAN) 1);
		}
	}
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.remove_i_th */
void F1456_15577 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R12126[dtype-1456])(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
	tr1 = F664_5454(RTCW(tr1), arg1);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1479, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1480_15842(RTCW(loc1), NULL);
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_20_);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tp1 = *(EIF_POINTER *)(Current + O12295[dtype-1455]);
			tp2 = F260_4057(RTCW(loc2));
			inline_F101_1953(tp1, tp2);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
		F664_5482(RTCW(tr1), arg1);
		tr1 = *(EIF_REFERENCE *)(Current + O10602[dtype-1307]);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4455[Dtype(RTCW(tr1))-534])(tr1);
	}
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.new_list_store */
EIF_POINTER F1456_15578 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F1456_15578 ();
	return Result;
}

void EIF_Minit810 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
