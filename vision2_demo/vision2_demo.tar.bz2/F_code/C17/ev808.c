/*
 * Code for class EV_TEXT_FIELD_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev808.h"
#include <ev_gtk.h>
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F17_402
static EIF_NATURAL_8 inline_F17_402 (void)
{
	return GTK_ORIENTATION_VERTICAL
	;
}
#define INLINE_F17_402
#endif
#ifndef INLINE_F102_2119
static EIF_POINTER inline_F102_2119 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F102_2119
#endif
#ifndef INLINE_F103_2310
static void inline_F103_2310 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_entry_set_width_chars ((GtkEntry *)arg1, (gint)arg2)
	;
}
#define INLINE_F103_2310
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TEXT_FIELD_IMP}.needs_event_box */
EIF_BOOLEAN F1454_15505 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_TEXT_FIELD_IMP}.make */
void F1454_15507 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_NATURAL_8 tu1_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = inline_F17_402();
	loc1 = inline_F102_2119(tu1_1, ((EIF_INTEGER_32) 0L));
	F1314_13098(Current, loc1);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R12278[dtype-1453])(Current);
	*(EIF_POINTER *)(Current + O12279[dtype-1453]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O12279[dtype-1453]);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current + O12279[dtype-1453]);
	gtk_box_pack_start((GtkBox*) loc1, (GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 1, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	F1454_15514(Current);
	F1451_15376(Current);
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.text */
EIF_REFERENCE F1454_15508 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tp1 = *(EIF_POINTER *)(Current + O12279[Dtype(Current)-1453]);
	tp1 = (EIF_POINTER) gtk_entry_get_text((GtkEntry*) tp1);
	F928_6964(RTCW(loc1), tp1);
	tr1 = F928_6960(RTCW(loc1));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {EV_TEXT_FIELD_IMP}.set_minimum_width_in_characters */
void F1454_15509 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12279[Dtype(Current)-1453]);
	ti4_1 = F1451_15379(Current);
	tr1 = RTLNS(eif_new_type(100, 0x00).id, 100, _OBJSIZ_0_0_0_0_0_0_0_0_);
	F101_1819(RTCW(tr1), tp1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)) * ti4_1), ((EIF_INTEGER_32) -1L));
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.set_text */
void F1454_15510 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F928_6962(RTCW(loc1), arg1);
	tp1 = *(EIF_POINTER *)(Current + O12279[dtype-1453]);
	inline_F103_2310(tp1, ((EIF_INTEGER_32) 1L));
	tp1 = *(EIF_POINTER *)(Current + O12279[dtype-1453]);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	gtk_entry_set_text((GtkEntry*) tp1, (gchar*) tp2);
	F1454_15540(Current);
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.append_text */
void F1454_15511 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F928_6962(RTCW(loc1), arg1);
	tp1 = *(EIF_POINTER *)(Current + O12279[Dtype(Current)-1453]);
	loc2 = (EIF_POINTER) gtk_entry_get_buffer((GtkEntry*) tp1);
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_0_1_0_0_);
	gtk_entry_buffer_insert_text((GtkEntryBuffer*) loc2, (guint) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L), (gchar*) tp1, (gint) ti4_1);
	F1454_15540(Current);
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.align_text_left */
void F1454_15514 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O12280[dtype-1453]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	tp1 = *(EIF_POINTER *)(Current + O12279[dtype-1453]);
	gtk_entry_set_alignment((GtkEntry*) tp1, (gfloat) (EIF_REAL_32) 0.0);
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.align_text_right */
void F1454_15515 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O12280[dtype-1453]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	tp1 = *(EIF_POINTER *)(Current + O12279[dtype-1453]);
	gtk_entry_set_alignment((GtkEntry*) tp1, (gfloat) (EIF_REAL_32) 1.0);
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.align_text_center */
void F1454_15516 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O12280[dtype-1453]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	tp1 = *(EIF_POINTER *)(Current + O12279[dtype-1453]);
	gtk_entry_set_alignment((GtkEntry*) tp1, (gfloat) (EIF_REAL_32) 0.5);
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.text_alignment */
EIF_INTEGER_32 F1454_15517 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O12280[Dtype(Current)-1453]);
}


/* {EV_TEXT_FIELD_IMP}.caret_position */
EIF_INTEGER_32 F1454_15518 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12279[Dtype(Current)-1453]);
	Result = (EIF_INTEGER_32) gtk_editable_get_position((GtkEditable*) tp1);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	RTLE;
	return Result;
}

/* {EV_TEXT_FIELD_IMP}.on_key_event */
void F1454_15520 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	F1366_13908(Current, arg1, arg2, arg3);
	tb1 = '\0';
	if ((EIF_BOOLEAN) !F1280_12326(Current)) {
		tb1 = arg3;
	}
	if (tb1) {
		F1454_15540(Current);
	}
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.return_actions */
RTEOMS(15520,1);
EIF_REFERENCE F1454_15521 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O1274[dtype-89]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		Result = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_9_2_0_2_0_0_0_0_);
		F688_5569(RTCW(Result));
		tp1 = *(EIF_POINTER *)(Current + O12279[dtype-1453]);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,960,1069,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = *(EIF_REFERENCE *)(RTCV(RTOSCF(13123,F1314_13123, (Current))) + _REFACS_42_);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		tp2 = *(EIF_POINTER *)(Current + O10619[dtype-1313]);
		((EIF_TYPED_VALUE *)tr1+2)->it_p = tp2;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2= RTLNRF(typres0.id, (EIF_POINTER) __A391_336, (EIF_POINTER) _A391_336, (EIF_POINTER)(F942_7748),tr1, 1, 0);
		}
		F1314_13103(Current, tp1, RTOMS(15520,0), tr2);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O1274[dtype-89]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_TEXT_FIELD_IMP}.is_editable */
EIF_BOOLEAN F1454_15522 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O12279[Dtype(Current)-1453]);
	return (EIF_BOOLEAN) (EIF_BOOLEAN) EIF_TEST(gtk_editable_get_editable((GtkEditable*) tp1));
}

/* {EV_TEXT_FIELD_IMP}.has_selection */
EIF_BOOLEAN F1454_15523 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O12279[Dtype(Current)-1453]);
	return (EIF_BOOLEAN) (EIF_BOOLEAN) EIF_TEST(gtk_editable_get_selection_bounds((GtkEditable*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) (EIF_INTEGER_32 *) &(loc2)));
}

/* {EV_TEXT_FIELD_IMP}.start_selection */
EIF_INTEGER_32 F1454_15524 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12279[Dtype(Current)-1453]);
	loc3 = (EIF_BOOLEAN) EIF_TEST(gtk_editable_get_selection_bounds((GtkEditable*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) (EIF_INTEGER_32 *) &(loc2)));
	RTLE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
}

/* {EV_TEXT_FIELD_IMP}.end_selection */
EIF_INTEGER_32 F1454_15525 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12279[Dtype(Current)-1453]);
	loc3 = (EIF_BOOLEAN) EIF_TEST(gtk_editable_get_selection_bounds((GtkEditable*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) (EIF_INTEGER_32 *) &(loc2)));
	RTLE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
}

/* {EV_TEXT_FIELD_IMP}.hide_border */
void F1454_15527 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12279[dtype-1453]);
	loc1 = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) tp1);
	loc2 = (EIF_POINTER) gtk_css_provider_new();
	loc3 = RTLNS(eif_new_type(267, 0x00).id, 267, _OBJSIZ_1_0_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("entry { border:none }",21,338494333);
	F268_4118(RTCW(loc3), tr1);
	tp1 = F268_4140(RTCW(loc3));
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_css_provider_load_from_data((GtkCssProvider*) loc2, (const gchar*) tp1, (gssize) ((EIF_INTEGER_32) -1L), (GError**) (EIF_POINTER *) &(loc4)))) {
	}
	gtk_style_context_add_provider((GtkStyleContext*) loc1, (GtkStyleProvider*) loc2, (guint) (EIF_NATURAL_32) ((EIF_INTEGER_32) 800L));
	tp1 = *(EIF_POINTER *)(Current + O12279[dtype-1453]);
	gtk_entry_set_has_frame((GtkEntry*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.set_editable */
void F1454_15528 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O12279[Dtype(Current)-1453]);
	gtk_editable_set_editable((GtkEditable*) tp1, (gboolean) arg1);
}

/* {EV_TEXT_FIELD_IMP}.set_caret_position */
void F1454_15529 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O12279[Dtype(Current)-1453]);
	gtk_editable_set_position((GtkEditable*) tp1, (gint) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)));
}

/* {EV_TEXT_FIELD_IMP}.select_region */
void F1454_15532 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12279[Dtype(Current)-1453]);
	ti4_1 = eif_min_int32 (arg1,arg2);
	ti4_2 = eif_max_int32 (arg2,arg1);
	gtk_editable_select_region((GtkEditable*) tp1, (gint) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)), (gint) ti4_2);
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.on_change_actions */
void F1454_15540 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tb1 = '\0';
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + O1228[dtype-77]);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tb3 = F483_4817(loc2);
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !F1280_12326(Current);
	}
	if (tb1) {
		loc1 = F1454_15508(Current);
		tb1 = '\01';
		tb2 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + O12276[dtype-1453]);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tb3 = F1081_9547(RTCW(loc1), loc3);
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (!tb2) {
			tb1 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O12276[dtype-1453]) == NULL);
		}
		if (tb1) {
			*(EIF_BOOLEAN *)(Current + O12277[dtype-1453]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F813_6165(loc2, NULL);
			*(EIF_BOOLEAN *)(Current + O12277[dtype-1453]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			tr1 = F1454_15508(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O12276[dtype-1453]) = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.style_element_name */
EIF_REFERENCE F1454_15542 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTMS_EX_H("entry",5,1853900921);
	RTLE;
	return Result;
}

/* {EV_TEXT_FIELD_IMP}.new_entry_widget */
EIF_POINTER F1454_15543 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) (EIF_POINTER) gtk_entry_new();
}

/* {EV_TEXT_FIELD_IMP}.visual_widget */
EIF_POINTER F1454_15545 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) *(EIF_POINTER *)(Current + O12279[Dtype(Current)-1453]);
}

void EIF_Minit808 (void)
{
	GTCX
	RTPOMS(15520,0,"activate",8,526134885);
}


#ifdef __cplusplus
}
#endif
