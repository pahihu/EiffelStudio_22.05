/*
 * Code for class EV_RICH_TEXT_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev807.h"
#include <string.h>
#include <ev_gtk.h>
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1453_15491
static EIF_POINTER inline_F1453_15491 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_text_view_get_default_attributes ((GtkTextView*) arg1))
	;
}
#define INLINE_F1453_15491
#endif
#ifndef INLINE_F1453_15490
static int inline_F1453_15490 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	return (int) (gtk_text_iter_get_attributes ((GtkTextIter*) arg1, (GtkTextAttributes*) arg2 ))
	;
}
#define INLINE_F1453_15490
#endif
#ifndef INLINE_F1453_15494
static EIF_POINTER inline_F1453_15494 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_text_attributes_copy ((GtkTextAttributes*) arg1))
	;
}
#define INLINE_F1453_15494
#endif
#ifndef INLINE_F1453_15492
static void inline_F1453_15492 (EIF_POINTER arg1)
{
	gtk_text_attributes_unref((GtkTextAttributes *) arg1);
	;
}
#define INLINE_F1453_15492
#endif
#ifndef INLINE_F100_1400
static void inline_F100_1400 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F100_1400
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_RICH_TEXT_IMP}.make */
void F1453_15432 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLIU(6);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(260, 0).id);
	F260_4054(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_49_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(260, 0).id);
	F260_4054(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_50_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {685,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F686_5559(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_47_) = (EIF_REFERENCE) tr1;
	F1452_15386(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_47_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A807_539_2, (EIF_POINTER) _A807_539_2, (EIF_POINTER)(F1453_15500),tr2, 1, 1);
	}
	F681_5535(RTCW(tr1), tr5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_47_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A807_539_2, (EIF_POINTER) _A807_539_2, (EIF_POINTER)(F1453_15500),tr2, 1, 1);
	}
	F681_5535(RTCW(tr1), tr5);
	tp1 = (EIF_POINTER) pango_tab_array_new((gint) ((EIF_INTEGER_32) 1L), (gboolean) (EIF_BOOLEAN) 1);
	*(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_4_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_1_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_4_);
	gtk_text_view_set_tabs((GtkTextView*) tp1, (PangoTabArray*) tp2);
	F1453_15468(Current, (EIF_INTEGER_32) (((EIF_INTEGER_32) 96L) / ((EIF_INTEGER_32) 2L)));
	RTLE;
}

/* {EV_RICH_TEXT_IMP}.initialize_buffer_events */
void F1453_15433 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLIU(6);
	
	RTGC;
	F1452_15387(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_3_);
	tr1 = RTOSCF(372,F16_372, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,960,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(13123,F1314_13123, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	ti4_1 = F938_7628(Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,2,997,1033,1069,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A391_316_3_4, (EIF_POINTER) _A391_316_3_4, (EIF_POINTER)(F941_7727),tr2, 1, 2);
	}
	F1314_13102(Current, tp1, tr1, tr5);
	RTLE;
}

/* {EV_RICH_TEXT_IMP}.initialize_for_loading */
void F1453_15437 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_RICH_TEXT_IMP}.complete_loading */
void F1453_15438 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_RICH_TEXT_IMP}.format_paragraph */
void F1453_15440 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_1_);
	loc1 = RTRV(eif_new_type(1282, 0x00), loc1);
	RTCT0("format_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = F1283_12384(RTCW(loc1));
	F1453_15499(Current, arg1, arg2, loc1, tr1);
	RTLE;
}

/* {EV_RICH_TEXT_IMP}.character_format_range_information */
EIF_REFERENCE F1453_15441 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1453_15442(Current, arg1, arg2, (EIF_BOOLEAN) 0, NULL);
}

/* {EV_RICH_TEXT_IMP}.internal_character_format_range_information */
EIF_REFERENCE F1453_15442 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_BOOLEAN arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,loc6);
	RTLR(3,Result);
	RTLR(4,arg4);
	RTLIU(5);
	
	RTGC;
	loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
	ti4_1 = (EIF_INTEGER_32) sizeof(GtkTextIter);
	tp1 = malloc((size_t)ti4_1);
	loc2 = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_3_);
	tp2 = loc2;
	gtk_text_buffer_get_iter_at_offset((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (gint) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_1_);
	loc4 = inline_F1453_15491(tp1);
	tp1 = loc2;
	loc9 = EIF_TEST (inline_F1453_15490(tp1, loc4));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_1_);
	loc3 = inline_F1453_15491(tp1);
	loc5 = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tp1 = (EIF_POINTER) (((GtkTextAttributes *)loc4)->font);
	tp1 = (EIF_POINTER) pango_font_description_get_family((PangoFontDescription*) tp1);
	F1081_9527(RTCW(loc5), tp1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc10 || (EIF_BOOLEAN)(loc1 == arg2))) break;
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_3_);
		tp2 = loc2;
		gtk_text_buffer_get_iter_at_offset((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (gint) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
		loc3 = inline_F1453_15494(loc4);
		tp1 = loc2;
		loc9 = EIF_TEST (inline_F1453_15490(tp1, loc3));
		if (loc8) {
			loc6 = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_1_1_0_3_0_0_0_0_);
			tp1 = (EIF_POINTER) (((GtkTextAttributes *)loc3)->font);
			tp1 = (EIF_POINTER) pango_font_description_get_family((PangoFontDescription*) tp1);
			F1081_9527(RTCW(loc6), tp1);
			ti4_1 = F1078_9402(RTCW(loc6));
			ti4_2 = F1078_9402(RTCW(loc5));
			if ((EIF_BOOLEAN)(ti4_1 != ti4_2)) {
				ti4_1 = eif_bit_or(loc7,((EIF_INTEGER_32) 1L));
				loc7 = (EIF_INTEGER_32) ti4_1;
				loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			loc5 = (EIF_REFERENCE) loc6;
		}
		tp1 = (EIF_POINTER) (((GtkTextAttributes *)loc3)->font);
		tp2 = (EIF_POINTER) (((GtkTextAttributes *)loc4)->font);
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) pango_font_description_get_style((PangoFontDescription*) tp1) != (EIF_INTEGER_32) pango_font_description_get_style((PangoFontDescription*) tp2))) {
			ti4_1 = eif_bit_or(loc7,((EIF_INTEGER_32) 4L));
			loc7 = (EIF_INTEGER_32) ti4_1;
		}
		tp1 = (EIF_POINTER) (((GtkTextAttributes *)loc3)->font);
		tp2 = (EIF_POINTER) (((GtkTextAttributes *)loc4)->font);
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) pango_font_description_get_weight((PangoFontDescription*) tp1) != (EIF_INTEGER_32) pango_font_description_get_weight((PangoFontDescription*) tp2))) {
			ti4_1 = eif_bit_or(loc7,((EIF_INTEGER_32) 2L));
			loc7 = (EIF_INTEGER_32) ti4_1;
		}
		tp1 = (EIF_POINTER) (((GtkTextAttributes *)loc3)->font);
		tp2 = (EIF_POINTER) (((GtkTextAttributes *)loc4)->font);
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) pango_font_description_get_size((PangoFontDescription*) tp1) != (EIF_INTEGER_32) pango_font_description_get_size((PangoFontDescription*) tp2))) {
			ti4_1 = eif_bit_or(loc7,((EIF_INTEGER_32) 8L));
			loc7 = (EIF_INTEGER_32) ti4_1;
		}
		tb1 = '\01';
		tb2 = '\01';
		tp1 = (EIF_POINTER) &(((GtkTextAttributes *)loc3)->appearance);
		tp1 = (EIF_POINTER) &(((GtkTextAppearance *)tp1)->fg_color);
		tp2 = (EIF_POINTER) &(((GtkTextAttributes *)loc4)->appearance);
		tp2 = (EIF_POINTER) &(((GtkTextAppearance *)tp2)->fg_color);
		if (!(EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkColor *)tp1)->red) != (EIF_INTEGER_32) (((GdkColor *)tp2)->red))) {
			tp1 = (EIF_POINTER) &(((GtkTextAttributes *)loc3)->appearance);
			tp1 = (EIF_POINTER) &(((GtkTextAppearance *)tp1)->fg_color);
			tp2 = (EIF_POINTER) &(((GtkTextAttributes *)loc4)->appearance);
			tp2 = (EIF_POINTER) &(((GtkTextAppearance *)tp2)->fg_color);
			tb2 = (EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkColor *)tp1)->green) != (EIF_INTEGER_32) (((GdkColor *)tp2)->green));
		}
		if (!tb2) {
			tp1 = (EIF_POINTER) &(((GtkTextAttributes *)loc3)->appearance);
			tp1 = (EIF_POINTER) &(((GtkTextAppearance *)tp1)->fg_color);
			tp2 = (EIF_POINTER) &(((GtkTextAttributes *)loc4)->appearance);
			tp2 = (EIF_POINTER) &(((GtkTextAppearance *)tp2)->fg_color);
			tb1 = (EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkColor *)tp1)->blue) != (EIF_INTEGER_32) (((GdkColor *)tp2)->blue));
		}
		if (tb1) {
			ti4_1 = eif_bit_or(loc7,((EIF_INTEGER_32) 16L));
			loc7 = (EIF_INTEGER_32) ti4_1;
		}
		tb1 = '\01';
		tb2 = '\01';
		tp1 = (EIF_POINTER) &(((GtkTextAttributes *)loc3)->appearance);
		tp1 = (EIF_POINTER) &(((GtkTextAppearance *)tp1)->bg_color);
		tp2 = (EIF_POINTER) &(((GtkTextAttributes *)loc4)->appearance);
		tp2 = (EIF_POINTER) &(((GtkTextAppearance *)tp2)->bg_color);
		if (!(EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkColor *)tp1)->red) != (EIF_INTEGER_32) (((GdkColor *)tp2)->red))) {
			tp1 = (EIF_POINTER) &(((GtkTextAttributes *)loc3)->appearance);
			tp1 = (EIF_POINTER) &(((GtkTextAppearance *)tp1)->bg_color);
			tp2 = (EIF_POINTER) &(((GtkTextAttributes *)loc4)->appearance);
			tp2 = (EIF_POINTER) &(((GtkTextAppearance *)tp2)->bg_color);
			tb2 = (EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkColor *)tp1)->green) != (EIF_INTEGER_32) (((GdkColor *)tp2)->green));
		}
		if (!tb2) {
			tp1 = (EIF_POINTER) &(((GtkTextAttributes *)loc3)->appearance);
			tp1 = (EIF_POINTER) &(((GtkTextAppearance *)tp1)->bg_color);
			tp2 = (EIF_POINTER) &(((GtkTextAttributes *)loc4)->appearance);
			tp2 = (EIF_POINTER) &(((GtkTextAppearance *)tp2)->bg_color);
			tb1 = (EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkColor *)tp1)->blue) != (EIF_INTEGER_32) (((GdkColor *)tp2)->blue));
		}
		if (tb1) {
			ti4_1 = eif_bit_or(loc7,((EIF_INTEGER_32) 32L));
			loc7 = (EIF_INTEGER_32) ti4_1;
		}
		tp1 = (EIF_POINTER) &(((GtkTextAttributes *)loc3)->appearance);
		tp2 = (EIF_POINTER) &(((GtkTextAttributes *)loc4)->appearance);
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) (((GtkTextAppearance *)tp1)->strikethrough) != (EIF_INTEGER_32) (((GtkTextAppearance *)tp2)->strikethrough))) {
			ti4_1 = eif_bit_or(loc7,((EIF_INTEGER_32) 64L));
			loc7 = (EIF_INTEGER_32) ti4_1;
		}
		tp1 = (EIF_POINTER) &(((GtkTextAttributes *)loc3)->appearance);
		tp2 = (EIF_POINTER) &(((GtkTextAttributes *)loc4)->appearance);
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) (((GtkTextAppearance *)tp1)->underline) != (EIF_INTEGER_32) (((GtkTextAppearance *)tp2)->underline))) {
			ti4_1 = eif_bit_or(loc7,((EIF_INTEGER_32) 128L));
			loc7 = (EIF_INTEGER_32) ti4_1;
		}
		tp1 = (EIF_POINTER) &(((GtkTextAttributes *)loc3)->appearance);
		tp2 = (EIF_POINTER) &(((GtkTextAttributes *)loc3)->appearance);
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) (((GtkTextAppearance *)tp1)->rise) != (EIF_INTEGER_32) (((GtkTextAppearance *)tp2)->rise))) {
			ti4_1 = eif_bit_or(loc7,((EIF_INTEGER_32) 256L));
			loc7 = (EIF_INTEGER_32) ti4_1;
		}
		inline_F1453_15492(loc4);
		loc4 = (EIF_POINTER) loc3;
		loc1++;
		if ((EIF_BOOLEAN) (arg3 && (EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 0L)))) {
			ti4_1 = eif_bit_or(loc7,((EIF_INTEGER_32) 1L));
			loc7 = (EIF_INTEGER_32) ti4_1;
			loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	inline_F1453_15492(loc4);
	free(loc2);
	Result = RTLNS(eif_new_type(1517, 0x00).id, 1517, _OBJSIZ_0_9_0_0_0_0_0_0_);
	ti4_1 = eif_bit_xor(((EIF_INTEGER_32) 511L),loc7);
	F1518_16476(RTCW(Result), ti4_1);
	if ((EIF_BOOLEAN)(arg4 != NULL)) {
		F1032_9120(RTCW(arg4), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
	}
	RTLE;
	return Result;
}

/* {EV_RICH_TEXT_IMP}.modify_region */
void F1453_15449 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg3);
	RTLR(2,Current);
	RTLR(3,arg4);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_1_);
	loc1 = RTRV(eif_new_type(1288, 0x00), loc1);
	RTCT0("a_format_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F1453_15498(Current, *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_3_), arg1, arg2, loc1, arg4);
	RTLE;
}

/* {EV_RICH_TEXT_IMP}.selected_character_format */
EIF_REFERENCE F1453_15453 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	ti4_1 = F1452_15393(Current);
	Result = F1453_15457(Current, ti4_1);
	RTLE;
	return Result;
}

/* {EV_RICH_TEXT_IMP}.character_format */
EIF_REFERENCE F1453_15457 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = F1453_15458(Current, arg1);
	Result = F1280_12327(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_RICH_TEXT_IMP}.internal_character_format */
EIF_REFERENCE F1453_15458 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc11);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,Current);
	RTLR(4,loc9);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1092, 0x00).id, 1092, _OBJSIZ_3_1_0_0_0_0_0_0_);
	F1088_9856(RTCW(tr1));
	loc11 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	loc11 = RTRV(eif_new_type(1288, 0x00), loc11);
	RTCT0("l_result /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc11 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc1 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc1));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_3_);
	tp2 = F260_4057(RTCW(loc1));
	gtk_text_buffer_get_iter_at_offset((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (gint) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 2L)));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_1_);
	loc2 = inline_F1453_15491(tp1);
	tp1 = F260_4057(RTCW(loc1));
	loc10 = EIF_TEST (inline_F1453_15490(tp1, loc2));
	loc3 = (EIF_POINTER) &(((GtkTextAttributes *)loc2)->appearance);
	loc4 = (EIF_POINTER) (((GtkTextAttributes *)loc2)->font);
	loc9 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tp1 = (EIF_POINTER) pango_font_description_get_family((PangoFontDescription*) loc4);
	F928_6964(RTCW(loc9), tp1);
	loc8 = (EIF_INTEGER_32) pango_font_description_get_style((PangoFontDescription*) loc4);
	loc7 = (EIF_INTEGER_32) pango_font_description_get_weight((PangoFontDescription*) loc4);
	if ((EIF_BOOLEAN) (loc7 <= ((EIF_INTEGER_32) 200L))) {
		loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	} else {
		if ((EIF_BOOLEAN) (loc7 <= ((EIF_INTEGER_32) 400L))) {
			loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
		} else {
			if ((EIF_BOOLEAN) (loc7 <= ((EIF_INTEGER_32) 700L))) {
				loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
			} else {
				loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
			}
		}
	}
	loc6 = (EIF_INTEGER_32) pango_font_description_get_size((PangoFontDescription*) loc4);
	ti4_1 = (EIF_INTEGER_32) PANGO_SCALE;
	loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 / ti4_1);
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) pango_font_description_get_style((PangoFontDescription*) loc4) > ((EIF_INTEGER_32) 0L))) {
		loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	} else {
		loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	}
	tr1 = F928_6960(RTCW(loc9));
	F1289_12490(RTCW(loc11), tr1, ((EIF_INTEGER_32) 3L), loc6, loc7, loc8, ((EIF_INTEGER_32) 0L));
	loc5 = (EIF_POINTER) &(((GtkTextAppearance *)loc3)->fg_color);
	ti4_1 = (EIF_INTEGER_32) (((GdkColor *)loc5)->red);
	ti4_2 = (EIF_INTEGER_32) (((GdkColor *)loc5)->green);
	ti4_3 = (EIF_INTEGER_32) (((GdkColor *)loc5)->blue);
	F1289_12492(RTCW(loc11), (EIF_INTEGER_32) (ti4_1 / ((EIF_INTEGER_32) 256L)), (EIF_INTEGER_32) (ti4_2 / ((EIF_INTEGER_32) 256L)), (EIF_INTEGER_32) (ti4_3 / ((EIF_INTEGER_32) 256L)));
	loc5 = (EIF_POINTER) &(((GtkTextAppearance *)loc3)->bg_color);
	ti4_1 = (EIF_INTEGER_32) (((GdkColor *)loc5)->red);
	ti4_2 = (EIF_INTEGER_32) (((GdkColor *)loc5)->green);
	ti4_3 = (EIF_INTEGER_32) (((GdkColor *)loc5)->blue);
	F1289_12493(RTCW(loc11), (EIF_INTEGER_32) (ti4_1 / ((EIF_INTEGER_32) 256L)), (EIF_INTEGER_32) (ti4_2 / ((EIF_INTEGER_32) 256L)), (EIF_INTEGER_32) (ti4_3 / ((EIF_INTEGER_32) 256L)));
	ti4_1 = (EIF_INTEGER_32) (((GtkTextAppearance *)loc3)->underline);
	tr1 = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = ti4_1;
	tb1 = F1032_9140(RTCW(tr1));
	ti4_1 = (EIF_INTEGER_32) (((GtkTextAppearance *)loc3)->strikethrough);
	tr1 = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = ti4_1;
	tb2 = F1032_9140(RTCW(tr1));
	ti4_1 = (EIF_INTEGER_32) (((GtkTextAppearance *)loc3)->rise);
	F1289_12496(RTCW(loc11), tb1, tb2, ti4_1);
	inline_F1453_15492(loc2);
	RTLE;
	return (EIF_REFERENCE) loc11;
}

/* {EV_RICH_TEXT_IMP}.set_current_format */
void F1453_15459 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_48_) = (EIF_REFERENCE) arg1;
}

/* {EV_RICH_TEXT_IMP}.format_region */
void F1453_15461 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1280_12326(Current)) {
		RTCT0("attached {EV_CHARACTER_FORMAT_IMP} format.implementation as a_format_imp", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_1_);
		loc1 = tr1;
		loc1 = RTRV(eif_new_type(1288, 0x00),loc1);
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_3_);
		tr1 = RTOSCF(12497,F1289_12497, (loc1));
		F1453_15498(Current, tp1, arg1, arg2, loc1, tr1);
	}
	RTLE;
}

/* {EV_RICH_TEXT_IMP}.buffered_append */
void F1453_15463 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7847[Dtype(RTCW(arg1))-1081])(arg1);
	if ((EIF_BOOLEAN) (loc3 >= ((EIF_INTEGER_32) 1L))) {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_51_11_)) {
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_);
			tb1 = !tp1;
			if ((EIF_BOOLEAN) !tb1) {
				tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_);
				inline_F100_1400(tp1);
			}
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_3_);
			loc1 = (EIF_POINTER) gtk_text_buffer_get_tag_table((GtkTextBuffer*) tp1);
			tp1 = (EIF_POINTER) gtk_text_buffer_new((GtkTextTagTable*) loc1);
			*(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_) = (EIF_POINTER) tp1;
			*(EIF_BOOLEAN *)(Current+ _CHROFF_51_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		loc4 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7810[Dtype(RTCW(arg1))-1081])(arg1, ((EIF_INTEGER_32) 1L));
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 1L))) {
			tb2 = '\01';
			tu4_1 = (EIF_NATURAL_32) (EIF_CHARACTER_8) '\012';
			if (!(EIF_BOOLEAN)(loc4 == tu4_1)) {
				tu4_1 = (EIF_NATURAL_32) (EIF_CHARACTER_8) '\011';
				tb2 = (EIF_BOOLEAN)(loc4 == tu4_1);
			}
			tb1 = tb2;
		}
		if (tb1) {
			F1452_15426(Current, *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_), arg1);
		} else {
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_);
			loc2 = (EIF_INTEGER_32) gtk_text_buffer_get_char_count((GtkTextBuffer*) tp1);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
			F1452_15426(Current, *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_), arg1);
			RTCT0("attached {EV_CHARACTER_FORMAT_IMP} format.implementation as a_format_imp", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
			loc5 = tr1;
			loc5 = RTRV(eif_new_type(1288, 0x00),loc5);
			if (EIF_TEST(loc5)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_49_);
			tp2 = F260_4057(RTCW(tr1));
			gtk_text_buffer_get_iter_at_offset((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (gint) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_50_);
			tp2 = F260_4057(RTCW(tr1));
			tp3 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_);
			ti4_1 = (EIF_INTEGER_32) gtk_text_buffer_get_char_count((GtkTextBuffer*) tp3);
			gtk_text_buffer_get_iter_at_offset((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (gint) ti4_1);
			tr1 = RTOSCF(12497,F1289_12497, (loc5));
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_49_);
			tp2 = F260_4057(RTCW(tr2));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_50_);
			tp3 = F260_4057(RTCW(tr2));
			F1289_12498(loc5, tr1, tp1, tp2, tp3);
		}
	}
	RTLE;
}

/* {EV_RICH_TEXT_IMP}.flush_buffer */
void F1453_15466 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_51_10_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_1_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_);
		gtk_text_view_set_buffer((GtkTextView*) tp1, (GtkTextBuffer*) tp2);
		*(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_3_) = (EIF_POINTER) *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_);
		F1453_15433(Current);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_);
		inline_F100_1400(tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_) = (EIF_POINTER) tp2;
		*(EIF_BOOLEAN *)(Current+ _CHROFF_51_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_51_11_)) {
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_1_);
			tp2 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_);
			gtk_text_view_set_buffer((GtkTextView*) tp1, (GtkTextBuffer*) tp2);
			*(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_3_) = (EIF_POINTER) *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_);
			F1453_15433(Current);
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_);
			inline_F100_1400(tp1);
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			tp2 = tp1;
			*(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_) = (EIF_POINTER) tp2;
			*(EIF_BOOLEAN *)(Current+ _CHROFF_51_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
	}
	RTLE;
}

/* {EV_RICH_TEXT_IMP}.set_tab_width */
void F1453_15468 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_51_18_10_9_) = (EIF_INTEGER_32) arg1;
	F1453_15500(Current, ((EIF_INTEGER_32) 1L));
	RTLE;
}

/* {EV_RICH_TEXT_IMP}.tab_width */
EIF_INTEGER_32 F1453_15470 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_51_18_10_9_);
}


/* {EV_RICH_TEXT_IMP}.on_key_event */
void F1453_15471 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	F1366_13908(Current, arg1, arg2, arg3);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && arg3) && (EIF_BOOLEAN)(arg1 != NULL))) {
		tb1 = '\01';
		tb2 = '\01';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
		if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 67L))) {
			tb3 = F1519_16494(RTCW(arg1));
			tb2 = tb3;
		}
		if (!tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
			tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 40L));
		}
		if (tb1) {
			*(EIF_REFERENCE *)(Current + _REFACS_48_) = (EIF_REFERENCE) NULL;
		} else {
			tr1 = RTOSCF(13123,F1314_13123, (Current));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,997,0,1033,1033,1092,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr2 = RTLNTS(typres0.id, 5, 0);
			}
			((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
			RTAR(tr2,Current);
			ti4_1 = F1452_15412(Current);
			((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
			ti4_1 = F1452_15412(Current);
			((EIF_TYPED_VALUE *)tr2+3)->it_i4 = (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L));
			((EIF_TYPED_VALUE *)tr2+4)->it_r = loc1;
			RTAR(tr2,loc1);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3= RTLNRF(typres0.id, (EIF_POINTER) __A807_500, (EIF_POINTER) _A807_500, (EIF_POINTER)(F1453_15461),tr2, 1, 0);
			}
			F1304_12827(RTCW(tr1), tr3);
		}
	}
	RTLE;
}

/* {EV_RICH_TEXT_IMP}.on_text_mark_changed */
void F1453_15472 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	if (F1315_13155(Current)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_3_);
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(arg2 == (EIF_POINTER) gtk_text_buffer_get_insert((GtkTextBuffer*) tp1))) {
			loc2 = F1452_15393(Current);
			loc3 = F1452_15394(Current);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) != NULL) && (EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_51_18_10_7_) != loc2) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_51_18_10_8_) != loc3)))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F813_6165(RTCW(tr1), NULL);
			}
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_51_18_10_7_) = (EIF_INTEGER_32) loc2;
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_51_18_10_8_) = (EIF_INTEGER_32) loc3;
		} else {
			loc1 = F1452_15412(Current);
			if ((EIF_BOOLEAN)(loc1 != *(EIF_INTEGER_32 *)(Current+ _LNGOFF_51_18_10_6_))) {
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1033,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
						tr2 = RTLNTS(typres0.id, 2, 1);
					}
					((EIF_TYPED_VALUE *)tr2+1)->it_i4 = loc1;
					F813_6165(RTCW(tr1), tr2);
				}
				*(EIF_REFERENCE *)(Current + _REFACS_48_) = (EIF_REFERENCE) NULL;
			}
		}
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_51_18_10_6_) = (EIF_INTEGER_32) loc1;
	}
	RTLE;
}

/* {EV_RICH_TEXT_IMP}.gtk_text_attributes_struct_font_description */
EIF_POINTER F1453_15478 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((GtkTextAttributes *)arg1)->font);
	
	return Result;
}

/* {EV_RICH_TEXT_IMP}.gtk_text_attributes_struct_text_appearance */
EIF_POINTER F1453_15479 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) &(((GtkTextAttributes *)arg1)->appearance);
	
	return Result;
}

/* {EV_RICH_TEXT_IMP}.gtk_text_appearance_struct_rise */
EIF_INTEGER_32 F1453_15485 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GtkTextAppearance *)arg1)->rise);
	
	return Result;
}

/* {EV_RICH_TEXT_IMP}.gtk_text_appearance_struct_bg_color */
EIF_POINTER F1453_15486 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) &(((GtkTextAppearance *)arg1)->bg_color);
	
	return Result;
}

/* {EV_RICH_TEXT_IMP}.gtk_text_appearance_struct_underline */
EIF_INTEGER_32 F1453_15487 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GtkTextAppearance *)arg1)->underline);
	
	return Result;
}

/* {EV_RICH_TEXT_IMP}.gtk_text_appearance_struct_strikethrough */
EIF_INTEGER_32 F1453_15488 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GtkTextAppearance *)arg1)->strikethrough);
	
	return Result;
}

/* {EV_RICH_TEXT_IMP}.gtk_text_appearance_struct_fg_color */
EIF_POINTER F1453_15489 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) &(((GtkTextAppearance *)arg1)->fg_color);
	
	return Result;
}

/* {EV_RICH_TEXT_IMP}.gtk_text_iter_get_attributes */
EIF_BOOLEAN F1453_15490 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F1453_15490 ((EIF_POINTER) arg1, (EIF_POINTER) arg2));
	return Result;
}

/* {EV_RICH_TEXT_IMP}.gtk_text_view_get_default_attributes */
EIF_POINTER F1453_15491 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F1453_15491 ((EIF_POINTER) arg1);
	return Result;
}

/* {EV_RICH_TEXT_IMP}.gtk_text_attributes_unref */
void F1453_15492 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F1453_15492 ((EIF_POINTER) arg1);
}

/* {EV_RICH_TEXT_IMP}.gtk_text_attributes_copy */
EIF_POINTER F1453_15494 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F1453_15494 ((EIF_POINTER) arg1);
	return Result;
}

/* {EV_RICH_TEXT_IMP}.modify_region_internal */
void F1453_15498 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,loc2);
	RTLR(2,arg4);
	RTLR(3,arg5);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc1));
	loc2 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc2));
	tp1 = F260_4057(RTCW(loc1));
	gtk_text_buffer_get_iter_at_offset((GtkTextBuffer*) arg1, (GtkTextIter*) tp1, (gint) (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	tp1 = F260_4057(RTCW(loc2));
	gtk_text_buffer_get_iter_at_offset((GtkTextBuffer*) arg1, (GtkTextIter*) tp1, (gint) (EIF_INTEGER_32) (arg3 - ((EIF_INTEGER_32) 1L)));
	loc4 = F1289_12499(RTCW(arg4), arg5);
	loc3 = (EIF_POINTER) gtk_text_buffer_get_tag_table((GtkTextBuffer*) arg1);
	gtk_text_tag_table_add((GtkTextTagTable*) loc3, (GtkTextTag*) loc4);
	tp1 = F260_4057(RTCW(loc1));
	tp2 = F260_4057(RTCW(loc2));
	gtk_text_buffer_apply_tag((GtkTextBuffer*) arg1, (GtkTextTag*) loc4, (GtkTextIter*) tp1, (GtkTextIter*) tp2);
	RTLE;
}

/* {EV_RICH_TEXT_IMP}.modify_paragraph_internal */
void F1453_15499 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_POINTER loc6 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,loc4);
	RTLR(2,Current);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLIU(5);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) arg1;
	loc2 = (EIF_INTEGER_32) arg2;
	loc3 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc3));
	loc4 = RTLNS(eif_new_type(260, 0x00).id, 260, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F260_4054(RTCW(loc4));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_3_);
	tp2 = F260_4057(RTCW(loc3));
	gtk_text_buffer_get_iter_at_offset((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (gint) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_3_);
	tp2 = F260_4057(RTCW(loc4));
	gtk_text_buffer_get_iter_at_offset((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (gint) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
	tp1 = F260_4057(RTCW(loc3));
	loc7 = (EIF_INTEGER_32) gtk_text_iter_get_line((GtkTextIter*) tp1);
	tp1 = F260_4057(RTCW(loc3));
	gtk_text_iter_set_line((GtkTextIter*) tp1, (gint) loc7);
	tp1 = F260_4057(RTCW(loc4));
	gtk_text_iter_forward_to_line_end((GtkTextIter*) tp1);
	tp1 = F260_4057(RTCW(loc4));
	gtk_text_iter_forward_char((GtkTextIter*) tp1);
	loc6 = F1283_12383(RTCW(arg3), arg4);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_3_);
	loc5 = (EIF_POINTER) gtk_text_buffer_get_tag_table((GtkTextBuffer*) tp1);
	gtk_text_tag_table_add((GtkTextTagTable*) loc5, (GtkTextTag*) loc6);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_3_);
	tp2 = F260_4057(RTCW(loc3));
	tp3 = F260_4057(RTCW(loc4));
	gtk_text_buffer_apply_tag((GtkTextBuffer*) tp1, (GtkTextTag*) loc6, (GtkTextIter*) tp2, (GtkTextIter*) tp3);
	RTLE;
}

/* {EV_RICH_TEXT_IMP}.update_tab_positions */
void F1453_15500 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_4_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_47_);
	ti4_1 = F671_5468(RTCW(tr1));
	pango_tab_array_resize((PangoTabArray*) tp1, (gint) (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_47_);
		ti4_1 = F671_5468(RTCW(tr1));
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_47_);
		ti4_2 = F671_5453(RTCW(tr1), loc1);
		loc2 += ti4_2;
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_4_);
		pango_tab_array_set_tab((PangoTabArray*) tp1, (gint) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)), (PangoTabAlign) ((EIF_INTEGER_32) 0L), (gint) loc2);
		loc1++;
	}
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_4_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_51_18_10_9_);
	pango_tab_array_set_tab((PangoTabArray*) tp1, (gint) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)), (PangoTabAlign) ((EIF_INTEGER_32) 0L), (gint) (EIF_INTEGER_32) (loc2 + ti4_2));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_1_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_4_);
	gtk_text_view_set_tabs((GtkTextView*) tp1, (PangoTabArray*) tp2);
	RTLE;
}

/* {EV_RICH_TEXT_IMP}.c_object_dispose */
void F1453_15503 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_);
		inline_F100_1400(tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_51_18_10_10_0_5_) = (EIF_POINTER) tp2;
	}
	F1452_15424(Current);
	RTLE;
}

void EIF_Minit807 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
