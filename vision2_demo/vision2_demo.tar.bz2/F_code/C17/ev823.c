/*
 * Code for class EV_PROGRESS_BAR_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev823.h"
#include <ev_gtk.h>
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F100_1400
static void inline_F100_1400 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F100_1400
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PROGRESS_BAR_IMP}.make */
void F1469_15709 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (EIF_POINTER) gtk_progress_bar_new();
	F1314_13098(Current, loc1);
	*(EIF_POINTER *)(Current+ _PTROFF_44_14_10_7_0_2_) = (EIF_POINTER) loc1;
	F1469_15715(Current);
	F1464_15676(Current);
	tp1 = F1314_13122(Current);
	F1469_15719(Current, tp1);
	RTLE;
}

/* {EV_PROGRESS_BAR_IMP}.needs_event_box */
EIF_BOOLEAN F1469_15710 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_PROGRESS_BAR_IMP}.event_widget */
EIF_POINTER F1469_15711 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) F1314_13122(Current);
}

/* {EV_PROGRESS_BAR_IMP}.is_segmented */
EIF_BOOLEAN F1469_15712 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_44_11_);
}


/* {EV_PROGRESS_BAR_IMP}.enable_segmentation */
void F1469_15715 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_44_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_PROGRESS_BAR_IMP}.disable_segmentation */
void F1469_15716 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_44_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_PROGRESS_BAR_IMP}.real_set_background_color */
void F1469_15717 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1323_13283(Current, arg1, arg2);
	F1469_15719(Current, arg1);
	RTLE;
}

/* {EV_PROGRESS_BAR_IMP}.real_set_foreground_color */
void F1469_15718 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1323_13285(Current, arg1, arg2);
	F1469_15719(Current, arg1);
	RTLE;
}

/* {EV_PROGRESS_BAR_IMP}.apply_css */
void F1469_15719 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc6);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc7);
	RTLR(6,loc8);
	RTLR(7,loc9);
	RTLR(8,loc10);
	RTLR(9,loc4);
	RTLIU(10);
	
	RTGC;
	loc3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1084_9690(RTCW(loc3), ((EIF_INTEGER_32) 2048L));
	loc1 = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) arg1);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R12326[Dtype(Current)-1469])(Current)) {
		loc6 = RTMS_EX_H("",0,0);
		tr1 = RTMS_EX_H("progressbar",11,1497446258);
		tr1 = F1086_9822(tr1, loc6);
		tr2 = RTMS_EX_H(" > trough { min-width: ",23,1521880608);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		tr2 = eif_out__i4_s1(F1315_13131(Current));
		tr1 = F1086_9822(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H("px; }\012",6,1213107466);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		F1086_9803(RTCW(loc3), tr1);
		tr1 = RTMS_EX_H("progressbar",11,1497446258);
		tr1 = F1086_9822(tr1, loc6);
		tr2 = RTMS_EX_H(" > trough > progress { min-width: ",34,649486368);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		tr2 = eif_out__i4_s1(F1315_13131(Current));
		tr1 = F1086_9822(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H("px; }\012",6,1213107466);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		F1086_9803(RTCW(loc3), tr1);
	} else {
		loc6 = RTMS_EX_H(".horizontal",11,96093036);
		tr1 = RTMS_EX_H("progressbar",11,1497446258);
		tr1 = F1086_9822(tr1, loc6);
		tr2 = RTMS_EX_H(" > trough { min-height: ",24,1051886624);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		tr2 = eif_out__i4_s1(F1315_13132(Current));
		tr1 = F1086_9822(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H("px; }\012",6,1213107466);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		F1086_9803(RTCW(loc3), tr1);
		tr1 = RTMS_EX_H("progressbar",11,1497446258);
		tr1 = F1086_9822(tr1, loc6);
		tr2 = RTMS_EX_H(" > trough > progress { min-height: ",35,1056861216);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		tr2 = eif_out__i4_s1(F1315_13132(Current));
		tr1 = F1086_9822(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H("px; }\012",6,1213107466);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		F1086_9803(RTCW(loc3), tr1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		tr1 = RTMS_EX_H("progressbar",11,1497446258);
		tr1 = F1086_9822(tr1, loc6);
		tr2 = RTMS_EX_H(" > trough { background-color: rgb(",34,437152296);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		ti4_1 = F1298_12694(loc7);
		tr2 = eif_out__i4_s1(ti4_1);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(",",1,44);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		ti4_1 = F1298_12695(loc7);
		tr2 = eif_out__i4_s1(ti4_1);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(",",1,44);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		ti4_1 = F1298_12696(loc7);
		tr2 = eif_out__i4_s1(ti4_1);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H("); }\012",5,992299786);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		F1086_9803(RTCW(loc3), tr1);
	} else {
		tr2 = RTMS_EX_H("theme_selected_fg_color",23,689486706);
		tr1 = RTLNS(eif_new_type(102, 0x00).id, 102, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr2 = F103_2407(RTCW(tr1), loc1, tr2);
		loc8 = tr2;
		if (EIF_TEST(loc8)) {
			tr1 = RTMS_EX_H("progressbar",11,1497446258);
			tr1 = F1086_9822(tr1, loc6);
			tr2 = RTMS_EX_H(" > trough { background-color: ",30,874457632);
			tr1 = F1086_9822(RTCW(tr1), tr2);
			tr1 = F1086_9822(RTCW(tr1), loc8);
			tr2 = RTMS_EX_H("; }\012",4,991984906);
			tr1 = F1086_9822(RTCW(tr1), tr2);
			F1086_9803(RTCW(loc3), tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		tr1 = RTMS_EX_H("progressbar",11,1497446258);
		tr1 = F1086_9822(tr1, loc6);
		tr2 = RTMS_EX_H(" > trough > progress { background-color: rgb(",45,1517850408);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		ti4_1 = F1298_12694(loc9);
		tr2 = eif_out__i4_s1(ti4_1);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(",",1,44);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		ti4_1 = F1298_12695(loc9);
		tr2 = eif_out__i4_s1(ti4_1);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(",",1,44);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		ti4_1 = F1298_12696(loc9);
		tr2 = eif_out__i4_s1(ti4_1);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H("); }\012",5,992299786);
		tr1 = F1086_9822(RTCW(tr1), tr2);
		F1086_9803(RTCW(loc3), tr1);
	} else {
		tr2 = RTMS_EX_H("theme_selected_bg_color",23,688565106);
		tr1 = RTLNS(eif_new_type(102, 0x00).id, 102, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr2 = F103_2407(RTCW(tr1), loc1, tr2);
		loc10 = tr2;
		if (EIF_TEST(loc10)) {
			tr1 = RTMS_EX_H("progressbar",11,1497446258);
			tr1 = F1086_9822(tr1, loc6);
			tr2 = RTMS_EX_H(" > trough > progress { background-color: ",41,1056630816);
			tr1 = F1086_9822(RTCW(tr1), tr2);
			tr1 = F1086_9822(RTCW(tr1), loc10);
			tr2 = RTMS_EX_H("; }\012",4,991984906);
			tr1 = F1086_9822(RTCW(tr1), tr2);
			F1086_9803(RTCW(loc3), tr1);
		}
	}
	loc4 = RTLNS(eif_new_type(267, 0x00).id, 267, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F268_4118(RTCW(loc4), loc3);
	loc2 = (EIF_POINTER) gtk_css_provider_new();
	tu4_1 = (EIF_NATURAL_32) GTK_STYLE_PROVIDER_PRIORITY_APPLICATION;
	gtk_style_context_add_provider((GtkStyleContext*) loc1, (GtkStyleProvider*) loc2, (guint) tu4_1);
	tp1 = F268_4140(RTCW(loc4));
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_css_provider_load_from_data((GtkCssProvider*) loc2, (const gchar*) tp1, (gssize) ((EIF_INTEGER_32) -1L), (GError**) (EIF_POINTER *) &(loc5)))) {
	}
	tb1 = !loc2;
	if ((EIF_BOOLEAN) !tb1) {
		inline_F100_1400(loc2);
	}
	RTLE;
}

/* {EV_PROGRESS_BAR_IMP}.set_minimum_width */
void F1469_15720 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1366_13923(Current, arg1);
	tp1 = F1314_13122(Current);
	F1469_15719(Current, tp1);
	RTLE;
}

/* {EV_PROGRESS_BAR_IMP}.set_minimum_height */
void F1469_15721 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1366_13924(Current, arg1);
	tp1 = F1314_13122(Current);
	F1469_15719(Current, tp1);
	RTLE;
}

/* {EV_PROGRESS_BAR_IMP}.set_minimum_size */
void F1469_15722 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1366_13925(Current, arg1, arg2);
	tp1 = F1314_13122(Current);
	F1469_15719(Current, tp1);
	RTLE;
}

/* {EV_PROGRESS_BAR_IMP}.value_changed_handler */
void F1469_15723 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REAL_64 tr8_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_14_10_7_0_2_);
	tr8_1 = (EIF_REAL_64) (F1430_15162(Current));
	gtk_progress_bar_set_fraction((GtkProgressBar*) tp1, (gdouble) tr8_1);
	F1464_15696(Current);
	RTLE;
}

void EIF_Minit823 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
