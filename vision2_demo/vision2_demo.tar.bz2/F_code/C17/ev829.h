
#ifndef _C17_ev829_
#define _C17_ev829_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1475_15739(EIF_REFERENCE);
extern void EIF_Minit829(void);
extern char *(*R12332[])();
extern long O10034[];

#ifdef __cplusplus
}
#endif

#endif
