#ifndef _estructure_h_
#define _estructure_h_

#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

struct eif_ex_30 {union overhead overhead; char data [1];};
struct eif_ex_42 {union overhead overhead; char data [1];};
struct eif_ex_1534 {union overhead overhead; char data [1];};
struct eif_ex_396 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_399 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,0,1,0)];};
struct eif_ex_402 {union overhead overhead; char data [@OBJSIZ(0,0,0,1,0,0,0,0)];};
struct eif_ex_405 {union overhead overhead; char data [@OBJSIZ(0,0,1,0,0,0,0,0)];};
struct eif_ex_408 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_411 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,1,0,0,0)];};
struct eif_ex_414 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,0,0,1)];};
struct eif_ex_417 {union overhead overhead; char data [@OBJSIZ(0,0,0,1,0,0,0,0)];};
struct eif_ex_420 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_423 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_426 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,0,1,0)];};
struct eif_ex_429 {union overhead overhead; char data [@OBJSIZ(0,0,0,1,0,0,0,0)];};
struct eif_ex_432 {union overhead overhead; char data [@OBJSIZ(0,0,1,0,0,0,0,0)];};
struct eif_ex_1070 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1164 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1200 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1276 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1330 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1334 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1338 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1342 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1482 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1526 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1530 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1543 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1547 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1551 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1566 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_435 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};

#ifdef __cplusplus
}
#endif
#endif
