#include "epoly15.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

EIF_TYPE_INDEX *Y4486_gen_type [1161];
EIF_TYPE_INDEX Y4486 [1161];
void Y4486_init (void)
{
	egc_routines_types [4486] = Y4486;
	egc_routines_gen_types [4486] = Y4486_gen_type;
	egc_routines_offset [4486] = 551;
	{long i; for (i = 0; i < 94; i++) Y4486[i] = 1033;};
	{long i; for (i = 103; i < 137; i++) Y4486[i] = 1033;};
	{long i; for (i = 261; i < 286; i++) Y4486[i] = 1033;};
	{long i; for (i = 313; i < 325; i++) Y4486[i] = 1033;};
	{long i; for (i = 393; i < 396; i++) Y4486[i] = 1033;};
	Y4486[446] = 1033;
	{long i; for (i = 529; i < 536; i++) Y4486[i] = 1033;};
	Y4486[568] = 1033;
	{long i; for (i = 570; i < 572; i++) Y4486[i] = 1033;};
	{long i; for (i = 586; i < 588; i++) Y4486[i] = 1033;};
	Y4486[616] = 1033;
	Y4486[627] = 1033;
	{long i; for (i = 633; i < 636; i++) Y4486[i] = 1033;};
	Y4486[644] = 1033;
	{long i; for (i = 648; i < 658; i++) Y4486[i] = 1033;};
	{long i; for (i = 688; i < 690; i++) Y4486[i] = 1033;};
	{long i; for (i = 691; i < 693; i++) Y4486[i] = 1033;};
	{long i; for (i = 701; i < 705; i++) Y4486[i] = 1033;};
	{long i; for (i = 709; i < 711; i++) Y4486[i] = 1033;};
	Y4486[1157] = 1033;
	{long i; for (i = 1159; i < 1161; i++) Y4486[i] = 1033;};
}

char *(*R4487[1137])();
void R4487_init () {
	{long i; for (i = 0; i < 2; i++) R4487[i] = (char *(*)()) F576_4889;}
	R4487[2] = (char *(*)()) F578_4944;
	R4487[3] = (char *(*)()) F579_4944;
	R4487[4] = (char *(*)()) F580_4944;
	R4487[5] = (char *(*)()) F581_4944;
	R4487[6] = (char *(*)()) F582_4944;
	R4487[7] = (char *(*)()) F583_4944;
	R4487[8] = (char *(*)()) F584_4944;
	R4487[9] = (char *(*)()) F585_4944;
	R4487[10] = (char *(*)()) F586_4944;
	R4487[11] = (char *(*)()) F587_4944;
	R4487[12] = (char *(*)()) F588_4944;
	R4487[13] = (char *(*)()) F589_4944;
	R4487[14] = (char *(*)()) F581_4944;
	R4487[63] = (char *(*)()) F639_5072;
	R4487[64] = (char *(*)()) F640_5072;
	R4487[65] = (char *(*)()) F641_5072;
	R4487[66] = (char *(*)()) F639_5072;
	R4487[67] = (char *(*)()) F640_5072;
	R4487[68] = (char *(*)()) F641_5072;
	R4487[69] = (char *(*)()) F639_5072;
	R4487[79] = (char *(*)()) F655_5338;
	R4487[80] = (char *(*)()) F656_5338;
	R4487[81] = (char *(*)()) F657_5338;
	R4487[82] = (char *(*)()) F658_5338;
	R4487[83] = (char *(*)()) F659_5338;
	R4487[84] = (char *(*)()) F660_5338;
	R4487[85] = (char *(*)()) F655_5338;
	R4487[86] = (char *(*)()) F657_5338;
	R4487[87] = (char *(*)()) F655_5338;
	R4487[88] = (char *(*)()) F664_5468;
	R4487[89] = (char *(*)()) F665_5468;
	R4487[90] = (char *(*)()) F666_5468;
	R4487[91] = (char *(*)()) F667_5468;
	R4487[92] = (char *(*)()) F668_5468;
	R4487[93] = (char *(*)()) F669_5468;
	R4487[94] = (char *(*)()) F670_5468;
	R4487[95] = (char *(*)()) F671_5468;
	R4487[96] = (char *(*)()) F672_5468;
	R4487[97] = (char *(*)()) F673_5468;
	R4487[98] = (char *(*)()) F674_5468;
	R4487[99] = (char *(*)()) F675_5468;
	R4487[100] = (char *(*)()) F664_5468;
	R4487[101] = (char *(*)()) F671_5468;
	R4487[102] = (char *(*)()) F669_5468;
	R4487[103] = (char *(*)()) F664_5468;
	R4487[104] = (char *(*)()) F671_5468;
	R4487[107] = (char *(*)()) F664_5468;
	R4487[108] = (char *(*)()) F671_5468;
	R4487[109] = (char *(*)()) F664_5468;
	R4487[110] = (char *(*)()) F671_5468;
	{long i; for (i = 111; i < 113; i++) R4487[i] = (char *(*)()) F664_5468;}
	{long i; for (i = 237; i < 239; i++) R4487[i] = (char *(*)()) F664_5468;}
	{long i; for (i = 240; i < 262; i++) R4487[i] = (char *(*)()) F664_5468;}
	R4487[289] = (char *(*)()) F865_6821;
	R4487[290] = (char *(*)()) F866_6821;
	R4487[291] = (char *(*)()) F867_6821;
	R4487[292] = (char *(*)()) F868_6821;
	R4487[293] = (char *(*)()) F869_6821;
	R4487[294] = (char *(*)()) F870_6821;
	R4487[295] = (char *(*)()) F871_6821;
	R4487[296] = (char *(*)()) F872_6821;
	R4487[297] = (char *(*)()) F873_6821;
	R4487[298] = (char *(*)()) F874_6821;
	R4487[299] = (char *(*)()) F875_6821;
	R4487[300] = (char *(*)()) F876_6821;
	{long i; for (i = 369; i < 372; i++) R4487[i] = (char *(*)()) F664_5468;}
	R4487[422] = (char *(*)()) F998_8189;
	{long i; for (i = 506; i < 508; i++) R4487[i] = (char *(*)()) F1081_9544;}
	{long i; for (i = 509; i < 512; i++) R4487[i] = (char *(*)()) F1084_9712;}
	R4487[563] = (char *(*)()) F1120_10295;
	R4487[592] = (char *(*)()) F664_5468;
	R4487[603] = (char *(*)()) F1120_10295;
	{long i; for (i = 610; i < 612; i++) R4487[i] = (char *(*)()) F1120_10295;}
	R4487[620] = (char *(*)()) F1196_11023;
	{long i; for (i = 625; i < 627; i++) R4487[i] = (char *(*)()) F1120_10295;}
	{long i; for (i = 628; i < 634; i++) R4487[i] = (char *(*)()) F1120_10295;}
	{long i; for (i = 664; i < 666; i++) R4487[i] = (char *(*)()) F1120_10295;}
	{long i; for (i = 667; i < 669; i++) R4487[i] = (char *(*)()) F1120_10295;}
	{long i; for (i = 678; i < 681; i++) R4487[i] = (char *(*)()) F1120_10295;}
	{long i; for (i = 685; i < 687; i++) R4487[i] = (char *(*)()) F1120_10295;}
	R4487[1133] = (char *(*)()) F1120_10295;
	{long i; for (i = 1135; i < 1137; i++) R4487[i] = (char *(*)()) F1120_10295;}
}

char *(*R4489[1137])();
void R4489_init () {
	{long i; for (i = 0; i < 2; i++) R4489[i] = (char *(*)()) F576_4893;}
	R4489[2] = (char *(*)()) F578_4953;
	R4489[3] = (char *(*)()) F579_4953;
	R4489[4] = (char *(*)()) F580_4953;
	R4489[5] = (char *(*)()) F581_4953;
	R4489[6] = (char *(*)()) F582_4953;
	R4489[7] = (char *(*)()) F583_4953;
	R4489[8] = (char *(*)()) F584_4953;
	R4489[9] = (char *(*)()) F585_4953;
	R4489[10] = (char *(*)()) F586_4953;
	R4489[11] = (char *(*)()) F587_4953;
	R4489[12] = (char *(*)()) F588_4953;
	R4489[13] = (char *(*)()) F589_4953;
	R4489[14] = (char *(*)()) F581_4953;
	R4489[63] = (char *(*)()) F591_5025;
	R4489[64] = (char *(*)()) F598_5025;
	R4489[65] = (char *(*)()) F596_5025;
	R4489[66] = (char *(*)()) F591_5025;
	R4489[67] = (char *(*)()) F598_5025;
	R4489[68] = (char *(*)()) F596_5025;
	R4489[69] = (char *(*)()) F591_5025;
	R4489[79] = (char *(*)()) F655_5354;
	R4489[80] = (char *(*)()) F656_5354;
	R4489[81] = (char *(*)()) F657_5354;
	R4489[82] = (char *(*)()) F658_5354;
	R4489[83] = (char *(*)()) F659_5354;
	R4489[84] = (char *(*)()) F660_5354;
	R4489[85] = (char *(*)()) F655_5354;
	R4489[86] = (char *(*)()) F657_5354;
	R4489[87] = (char *(*)()) F655_5354;
	R4489[88] = (char *(*)()) F664_5474;
	R4489[89] = (char *(*)()) F665_5474;
	R4489[90] = (char *(*)()) F666_5474;
	R4489[91] = (char *(*)()) F667_5474;
	R4489[92] = (char *(*)()) F668_5474;
	R4489[93] = (char *(*)()) F669_5474;
	R4489[94] = (char *(*)()) F670_5474;
	R4489[95] = (char *(*)()) F671_5474;
	R4489[96] = (char *(*)()) F672_5474;
	R4489[97] = (char *(*)()) F673_5474;
	R4489[98] = (char *(*)()) F674_5474;
	R4489[99] = (char *(*)()) F675_5474;
	R4489[100] = (char *(*)()) F664_5474;
	R4489[101] = (char *(*)()) F671_5474;
	R4489[102] = (char *(*)()) F669_5474;
	R4489[103] = (char *(*)()) F664_5474;
	R4489[104] = (char *(*)()) F671_5474;
	R4489[107] = (char *(*)()) F664_5474;
	R4489[108] = (char *(*)()) F671_5474;
	R4489[109] = (char *(*)()) F664_5474;
	R4489[110] = (char *(*)()) F671_5474;
	{long i; for (i = 111; i < 113; i++) R4489[i] = (char *(*)()) F664_5474;}
	{long i; for (i = 237; i < 239; i++) R4489[i] = (char *(*)()) F664_5474;}
	{long i; for (i = 240; i < 262; i++) R4489[i] = (char *(*)()) F664_5474;}
	R4489[289] = (char *(*)()) F865_6826;
	R4489[290] = (char *(*)()) F866_6826;
	R4489[291] = (char *(*)()) F867_6826;
	R4489[292] = (char *(*)()) F868_6826;
	R4489[293] = (char *(*)()) F869_6826;
	R4489[294] = (char *(*)()) F870_6826;
	R4489[295] = (char *(*)()) F871_6826;
	R4489[296] = (char *(*)()) F872_6826;
	R4489[297] = (char *(*)()) F873_6826;
	R4489[298] = (char *(*)()) F874_6826;
	R4489[299] = (char *(*)()) F875_6826;
	R4489[300] = (char *(*)()) F876_6826;
	{long i; for (i = 369; i < 372; i++) R4489[i] = (char *(*)()) F664_5474;}
	R4489[422] = (char *(*)()) F998_8187;
	{long i; for (i = 506; i < 508; i++) R4489[i] = (char *(*)()) F1078_9405;}
	{long i; for (i = 509; i < 512; i++) R4489[i] = (char *(*)()) F1078_9405;}
	R4489[563] = (char *(*)()) F591_5025;
	R4489[592] = (char *(*)()) F664_5474;
	R4489[603] = (char *(*)()) F591_5025;
	{long i; for (i = 610; i < 612; i++) R4489[i] = (char *(*)()) F591_5025;}
	R4489[620] = (char *(*)()) F591_5025;
	{long i; for (i = 625; i < 627; i++) R4489[i] = (char *(*)()) F591_5025;}
	{long i; for (i = 628; i < 634; i++) R4489[i] = (char *(*)()) F591_5025;}
	{long i; for (i = 664; i < 666; i++) R4489[i] = (char *(*)()) F591_5025;}
	{long i; for (i = 667; i < 669; i++) R4489[i] = (char *(*)()) F591_5025;}
	{long i; for (i = 678; i < 681; i++) R4489[i] = (char *(*)()) F591_5025;}
	{long i; for (i = 685; i < 687; i++) R4489[i] = (char *(*)()) F591_5025;}
	R4489[1133] = (char *(*)()) F591_5025;
	{long i; for (i = 1135; i < 1137; i++) R4489[i] = (char *(*)()) F591_5025;}
}

char *(*R4492[2])();
void R4492_init () {
	R4492[0] = (char *(*)()) F576_4885;
	R4492[1] = (char *(*)()) F577_4923;
}

char *(*R4497[2])();
void R4497_init () {
	R4497[0] = (char *(*)()) F576_4905;
	R4497[1] = (char *(*)()) F577_4927;
}

char *(*R4516[13])();
void R4516_init () {
	R4516[0] = (char *(*)()) F578_4936;
	R4516[1] = (char *(*)()) F579_4936;
	R4516[2] = (char *(*)()) F580_4936;
	R4516[3] = (char *(*)()) F581_4936;
	R4516[4] = (char *(*)()) F582_4936;
	R4516[5] = (char *(*)()) F583_4936;
	R4516[6] = (char *(*)()) F584_4936;
	R4516[7] = (char *(*)()) F585_4936;
	R4516[8] = (char *(*)()) F586_4936;
	R4516[9] = (char *(*)()) F587_4936;
	R4516[10] = (char *(*)()) F588_4936;
	R4516[11] = (char *(*)()) F589_4936;
	R4516[12] = (char *(*)()) F581_4936;
}

char *(*R4540[13])();
void R4540_init () {
	R4540[0] = (char *(*)()) F578_4978;
	R4540[1] = (char *(*)()) F579_4978_4540_276;
	R4540[2] = (char *(*)()) F580_4978_4540_276;
	R4540[3] = (char *(*)()) F581_4978_4540_276;
	R4540[4] = (char *(*)()) F582_4978_4540_276;
	R4540[5] = (char *(*)()) F583_4978_4540_276;
	R4540[6] = (char *(*)()) F584_4978_4540_276;
	R4540[7] = (char *(*)()) F585_4978_4540_276;
	R4540[8] = (char *(*)()) F586_4978_4540_276;
	R4540[9] = (char *(*)()) F587_4978_4540_276;
	R4540[10] = (char *(*)()) F588_4978_4540_276;
	R4540[11] = (char *(*)()) F589_4978_4540_276;
	R4540[12] = (char *(*)()) F581_4978_4540_276;
}
static void F579_4978_4540_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F579_4978(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F580_4978_4540_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F580_4978(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F581_4978_4540_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F581_4978(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F582_4978_4540_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F582_4978(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F583_4978_4540_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F583_4978(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F584_4978_4540_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F584_4978(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}
static void F585_4978_4540_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F585_4978(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F586_4978_4540_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F586_4978(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F587_4978_4540_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F587_4978(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F588_4978_4540_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F588_4978(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F589_4978_4540_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F589_4978(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}

char *(*R4547[13])();
void R4547_init () {
	R4547[0] = (char *(*)()) F578_4990;
	R4547[1] = (char *(*)()) F579_4990;
	R4547[2] = (char *(*)()) F580_4990;
	R4547[3] = (char *(*)()) F581_4990;
	R4547[4] = (char *(*)()) F582_4990;
	R4547[5] = (char *(*)()) F583_4990;
	R4547[6] = (char *(*)()) F584_4990;
	R4547[7] = (char *(*)()) F585_4990;
	R4547[8] = (char *(*)()) F586_4990;
	R4547[9] = (char *(*)()) F587_4990;
	R4547[10] = (char *(*)()) F588_4990;
	R4547[11] = (char *(*)()) F589_4990;
	R4547[12] = (char *(*)()) F581_4990;
}

char *(*R4573[1074])();
void R4573_init () {
	R4573[0] = (char *(*)()) F639_5067;
	R4573[1] = (char *(*)()) F640_5067_4573_1;
	R4573[2] = (char *(*)()) F641_5067_4573_1;
	R4573[3] = (char *(*)()) F639_5067;
	R4573[4] = (char *(*)()) F640_5067_4573_1;
	R4573[5] = (char *(*)()) F641_5067_4573_1;
	R4573[6] = (char *(*)()) F639_5067;
	R4573[25] = (char *(*)()) F664_5456;
	R4573[26] = (char *(*)()) F665_5456_4573_1;
	R4573[27] = (char *(*)()) F666_5456_4573_1;
	R4573[28] = (char *(*)()) F667_5456_4573_1;
	R4573[29] = (char *(*)()) F668_5456_4573_1;
	R4573[30] = (char *(*)()) F669_5456_4573_1;
	R4573[31] = (char *(*)()) F670_5456_4573_1;
	R4573[32] = (char *(*)()) F671_5456_4573_1;
	R4573[33] = (char *(*)()) F672_5456_4573_1;
	R4573[34] = (char *(*)()) F673_5456_4573_1;
	R4573[35] = (char *(*)()) F674_5456_4573_1;
	R4573[36] = (char *(*)()) F675_5456_4573_1;
	R4573[37] = (char *(*)()) F664_5456;
	R4573[38] = (char *(*)()) F671_5456_4573_1;
	R4573[39] = (char *(*)()) F669_5456_4573_1;
	R4573[40] = (char *(*)()) F664_5456;
	R4573[41] = (char *(*)()) F671_5456_4573_1;
	R4573[44] = (char *(*)()) F664_5456;
	R4573[45] = (char *(*)()) F671_5456_4573_1;
	R4573[46] = (char *(*)()) F664_5456;
	R4573[47] = (char *(*)()) F671_5456_4573_1;
	{long i; for (i = 48; i < 50; i++) R4573[i] = (char *(*)()) F664_5456;}
	{long i; for (i = 174; i < 176; i++) R4573[i] = (char *(*)()) F664_5456;}
	{long i; for (i = 177; i < 199; i++) R4573[i] = (char *(*)()) F664_5456;}
	{long i; for (i = 306; i < 309; i++) R4573[i] = (char *(*)()) F664_5456;}
	R4573[500] = (char *(*)()) F591_5014;
	R4573[529] = (char *(*)()) F664_5456;
	R4573[540] = (char *(*)()) F591_5014;
	{long i; for (i = 547; i < 549; i++) R4573[i] = (char *(*)()) F591_5014;}
	R4573[557] = (char *(*)()) F591_5014;
	{long i; for (i = 562; i < 564; i++) R4573[i] = (char *(*)()) F591_5014;}
	{long i; for (i = 565; i < 571; i++) R4573[i] = (char *(*)()) F591_5014;}
	{long i; for (i = 601; i < 603; i++) R4573[i] = (char *(*)()) F591_5014;}
	{long i; for (i = 604; i < 606; i++) R4573[i] = (char *(*)()) F591_5014;}
	{long i; for (i = 615; i < 618; i++) R4573[i] = (char *(*)()) F591_5014;}
	{long i; for (i = 622; i < 624; i++) R4573[i] = (char *(*)()) F591_5014;}
	R4573[1070] = (char *(*)()) F591_5014;
	{long i; for (i = 1072; i < 1074; i++) R4573[i] = (char *(*)()) F591_5014;}
}
static EIF_REFERENCE F640_5067_4573_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F640_5067(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_5067_4573_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F641_5067(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5456_4573_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F665_5456(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5456_4573_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F666_5456(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1009, 0x00).id, 1009, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5456_4573_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F667_5456(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1012, 0x00).id, 1012, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5456_4573_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F668_5456(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1003, 0x00).id, 1003, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_5456_4573_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F669_5456(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_5456_4573_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F670_5456(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1018, 0x00).id, 1018, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F671_5456_4573_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F671_5456(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F672_5456_4573_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F672_5456(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F673_5456_4573_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F673_5456(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F674_5456_4573_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F674_5456(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F675_5456_4573_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F675_5456(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}

char *(*R4574[1074])();
void R4574_init () {
	R4574[0] = (char *(*)()) F639_5086;
	R4574[1] = (char *(*)()) F640_5086;
	R4574[2] = (char *(*)()) F641_5086;
	R4574[3] = (char *(*)()) F639_5086;
	R4574[4] = (char *(*)()) F640_5086;
	R4574[5] = (char *(*)()) F641_5086;
	R4574[6] = (char *(*)()) F639_5086;
	R4574[25] = (char *(*)()) F664_5477;
	R4574[26] = (char *(*)()) F665_5477;
	R4574[27] = (char *(*)()) F666_5477;
	R4574[28] = (char *(*)()) F667_5477;
	R4574[29] = (char *(*)()) F668_5477;
	R4574[30] = (char *(*)()) F669_5477;
	R4574[31] = (char *(*)()) F670_5477;
	R4574[32] = (char *(*)()) F671_5477;
	R4574[33] = (char *(*)()) F672_5477;
	R4574[34] = (char *(*)()) F673_5477;
	R4574[35] = (char *(*)()) F674_5477;
	R4574[36] = (char *(*)()) F675_5477;
	R4574[37] = (char *(*)()) F664_5477;
	R4574[38] = (char *(*)()) F671_5477;
	R4574[39] = (char *(*)()) F669_5477;
	R4574[40] = (char *(*)()) F664_5477;
	R4574[41] = (char *(*)()) F671_5477;
	R4574[44] = (char *(*)()) F664_5477;
	R4574[45] = (char *(*)()) F671_5477;
	R4574[46] = (char *(*)()) F664_5477;
	R4574[47] = (char *(*)()) F671_5477;
	{long i; for (i = 48; i < 50; i++) R4574[i] = (char *(*)()) F664_5477;}
	{long i; for (i = 174; i < 176; i++) R4574[i] = (char *(*)()) F664_5477;}
	{long i; for (i = 177; i < 199; i++) R4574[i] = (char *(*)()) F664_5477;}
	{long i; for (i = 306; i < 309; i++) R4574[i] = (char *(*)()) F664_5477;}
	R4574[500] = (char *(*)()) F1120_10303;
	R4574[529] = (char *(*)()) F664_5477;
	R4574[540] = (char *(*)()) F1120_10303;
	{long i; for (i = 547; i < 549; i++) R4574[i] = (char *(*)()) F1120_10303;}
	R4574[557] = (char *(*)()) F1196_11034;
	{long i; for (i = 562; i < 564; i++) R4574[i] = (char *(*)()) F1120_10303;}
	{long i; for (i = 565; i < 571; i++) R4574[i] = (char *(*)()) F1120_10303;}
	{long i; for (i = 601; i < 603; i++) R4574[i] = (char *(*)()) F1120_10303;}
	{long i; for (i = 604; i < 606; i++) R4574[i] = (char *(*)()) F1120_10303;}
	{long i; for (i = 615; i < 618; i++) R4574[i] = (char *(*)()) F1120_10303;}
	{long i; for (i = 622; i < 624; i++) R4574[i] = (char *(*)()) F1120_10303;}
	R4574[1070] = (char *(*)()) F1120_10303;
	{long i; for (i = 1072; i < 1074; i++) R4574[i] = (char *(*)()) F1120_10303;}
}

char *(*R4575[1074])();
void R4575_init () {
	R4575[0] = (char *(*)()) F639_5087;
	R4575[1] = (char *(*)()) F640_5087;
	R4575[2] = (char *(*)()) F641_5087;
	R4575[3] = (char *(*)()) F639_5087;
	R4575[4] = (char *(*)()) F640_5087;
	R4575[5] = (char *(*)()) F641_5087;
	R4575[6] = (char *(*)()) F639_5087;
	R4575[25] = (char *(*)()) F664_5482;
	R4575[26] = (char *(*)()) F665_5482;
	R4575[27] = (char *(*)()) F666_5482;
	R4575[28] = (char *(*)()) F667_5482;
	R4575[29] = (char *(*)()) F668_5482;
	R4575[30] = (char *(*)()) F669_5482;
	R4575[31] = (char *(*)()) F670_5482;
	R4575[32] = (char *(*)()) F671_5482;
	R4575[33] = (char *(*)()) F672_5482;
	R4575[34] = (char *(*)()) F673_5482;
	R4575[35] = (char *(*)()) F674_5482;
	R4575[36] = (char *(*)()) F675_5482;
	R4575[37] = (char *(*)()) F664_5482;
	R4575[38] = (char *(*)()) F671_5482;
	R4575[39] = (char *(*)()) F669_5482;
	R4575[40] = (char *(*)()) F664_5482;
	R4575[41] = (char *(*)()) F671_5482;
	R4575[44] = (char *(*)()) F664_5482;
	R4575[45] = (char *(*)()) F671_5482;
	R4575[46] = (char *(*)()) F664_5482;
	R4575[47] = (char *(*)()) F671_5482;
	{long i; for (i = 48; i < 50; i++) R4575[i] = (char *(*)()) F664_5482;}
	{long i; for (i = 174; i < 176; i++) R4575[i] = (char *(*)()) F664_5482;}
	{long i; for (i = 177; i < 199; i++) R4575[i] = (char *(*)()) F664_5482;}
	{long i; for (i = 306; i < 309; i++) R4575[i] = (char *(*)()) F664_5482;}
	R4575[500] = (char *(*)()) F1120_10301;
	R4575[529] = (char *(*)()) F664_5482;
	R4575[540] = (char *(*)()) F1120_10301;
	{long i; for (i = 547; i < 549; i++) R4575[i] = (char *(*)()) F1120_10301;}
	R4575[557] = (char *(*)()) F591_5024;
	{long i; for (i = 562; i < 564; i++) R4575[i] = (char *(*)()) F1120_10301;}
	{long i; for (i = 565; i < 571; i++) R4575[i] = (char *(*)()) F1120_10301;}
	{long i; for (i = 601; i < 603; i++) R4575[i] = (char *(*)()) F1120_10301;}
	{long i; for (i = 604; i < 606; i++) R4575[i] = (char *(*)()) F1120_10301;}
	{long i; for (i = 615; i < 618; i++) R4575[i] = (char *(*)()) F1120_10301;}
	{long i; for (i = 622; i < 624; i++) R4575[i] = (char *(*)()) F1120_10301;}
	R4575[1070] = (char *(*)()) F1120_10301;
	{long i; for (i = 1072; i < 1074; i++) R4575[i] = (char *(*)()) F1120_10301;}
}

char *(*R4576[1074])();
void R4576_init () {
	R4576[0] = (char *(*)()) F639_5077;
	R4576[1] = (char *(*)()) F640_5077;
	R4576[2] = (char *(*)()) F641_5077;
	R4576[3] = (char *(*)()) F639_5077;
	R4576[4] = (char *(*)()) F640_5077;
	R4576[5] = (char *(*)()) F641_5077;
	R4576[6] = (char *(*)()) F639_5077;
	R4576[25] = (char *(*)()) F591_5026;
	R4576[26] = (char *(*)()) F592_5026;
	R4576[27] = (char *(*)()) F593_5026;
	R4576[28] = (char *(*)()) F594_5026;
	R4576[29] = (char *(*)()) F595_5026;
	R4576[30] = (char *(*)()) F596_5026;
	R4576[31] = (char *(*)()) F597_5026;
	R4576[32] = (char *(*)()) F598_5026;
	R4576[33] = (char *(*)()) F599_5026;
	R4576[34] = (char *(*)()) F600_5026;
	R4576[35] = (char *(*)()) F601_5026;
	R4576[36] = (char *(*)()) F602_5026;
	R4576[37] = (char *(*)()) F591_5026;
	R4576[38] = (char *(*)()) F598_5026;
	R4576[39] = (char *(*)()) F596_5026;
	R4576[40] = (char *(*)()) F591_5026;
	R4576[41] = (char *(*)()) F598_5026;
	R4576[44] = (char *(*)()) F591_5026;
	R4576[45] = (char *(*)()) F598_5026;
	R4576[46] = (char *(*)()) F591_5026;
	R4576[47] = (char *(*)()) F598_5026;
	{long i; for (i = 48; i < 50; i++) R4576[i] = (char *(*)()) F591_5026;}
	{long i; for (i = 174; i < 176; i++) R4576[i] = (char *(*)()) F591_5026;}
	{long i; for (i = 177; i < 199; i++) R4576[i] = (char *(*)()) F591_5026;}
	{long i; for (i = 306; i < 309; i++) R4576[i] = (char *(*)()) F591_5026;}
	R4576[500] = (char *(*)()) F591_5026;
	R4576[529] = (char *(*)()) F591_5026;
	R4576[540] = (char *(*)()) F591_5026;
	{long i; for (i = 547; i < 549; i++) R4576[i] = (char *(*)()) F591_5026;}
	R4576[557] = (char *(*)()) F591_5026;
	{long i; for (i = 562; i < 564; i++) R4576[i] = (char *(*)()) F591_5026;}
	{long i; for (i = 565; i < 571; i++) R4576[i] = (char *(*)()) F591_5026;}
	{long i; for (i = 601; i < 603; i++) R4576[i] = (char *(*)()) F591_5026;}
	{long i; for (i = 604; i < 606; i++) R4576[i] = (char *(*)()) F591_5026;}
	{long i; for (i = 615; i < 618; i++) R4576[i] = (char *(*)()) F591_5026;}
	{long i; for (i = 622; i < 624; i++) R4576[i] = (char *(*)()) F591_5026;}
	R4576[1070] = (char *(*)()) F591_5026;
	{long i; for (i = 1072; i < 1074; i++) R4576[i] = (char *(*)()) F591_5026;}
}

char *(*R4577[7])();
void R4577_init () {
	R4577[0] = (char *(*)()) F639_5078;
	R4577[1] = (char *(*)()) F640_5078;
	R4577[2] = (char *(*)()) F641_5078;
	R4577[3] = (char *(*)()) F639_5078;
	R4577[4] = (char *(*)()) F640_5078;
	R4577[5] = (char *(*)()) F641_5078;
	R4577[6] = (char *(*)()) F639_5078;
}

char *(*R4578[1074])();
void R4578_init () {
	R4578[0] = (char *(*)()) F591_5029;
	R4578[1] = (char *(*)()) F598_5029;
	R4578[2] = (char *(*)()) F596_5029;
	R4578[3] = (char *(*)()) F591_5029;
	R4578[4] = (char *(*)()) F598_5029;
	R4578[5] = (char *(*)()) F596_5029;
	R4578[6] = (char *(*)()) F591_5029;
	R4578[25] = (char *(*)()) F591_5029;
	R4578[26] = (char *(*)()) F592_5029;
	R4578[27] = (char *(*)()) F593_5029;
	R4578[28] = (char *(*)()) F594_5029;
	R4578[29] = (char *(*)()) F595_5029;
	R4578[30] = (char *(*)()) F596_5029;
	R4578[31] = (char *(*)()) F597_5029;
	R4578[32] = (char *(*)()) F598_5029;
	R4578[33] = (char *(*)()) F599_5029;
	R4578[34] = (char *(*)()) F600_5029;
	R4578[35] = (char *(*)()) F601_5029;
	R4578[36] = (char *(*)()) F602_5029;
	R4578[37] = (char *(*)()) F591_5029;
	R4578[38] = (char *(*)()) F598_5029;
	R4578[39] = (char *(*)()) F596_5029;
	R4578[40] = (char *(*)()) F591_5029;
	R4578[41] = (char *(*)()) F598_5029;
	R4578[44] = (char *(*)()) F591_5029;
	R4578[45] = (char *(*)()) F598_5029;
	R4578[46] = (char *(*)()) F591_5029;
	R4578[47] = (char *(*)()) F598_5029;
	{long i; for (i = 48; i < 50; i++) R4578[i] = (char *(*)()) F591_5029;}
	{long i; for (i = 174; i < 176; i++) R4578[i] = (char *(*)()) F591_5029;}
	{long i; for (i = 177; i < 199; i++) R4578[i] = (char *(*)()) F591_5029;}
	{long i; for (i = 306; i < 309; i++) R4578[i] = (char *(*)()) F591_5029;}
	R4578[500] = (char *(*)()) F591_5029;
	R4578[529] = (char *(*)()) F591_5029;
	R4578[540] = (char *(*)()) F591_5029;
	{long i; for (i = 547; i < 549; i++) R4578[i] = (char *(*)()) F591_5029;}
	R4578[557] = (char *(*)()) F591_5029;
	{long i; for (i = 562; i < 564; i++) R4578[i] = (char *(*)()) F591_5029;}
	{long i; for (i = 565; i < 571; i++) R4578[i] = (char *(*)()) F591_5029;}
	{long i; for (i = 601; i < 603; i++) R4578[i] = (char *(*)()) F591_5029;}
	{long i; for (i = 604; i < 606; i++) R4578[i] = (char *(*)()) F591_5029;}
	{long i; for (i = 615; i < 618; i++) R4578[i] = (char *(*)()) F591_5029;}
	{long i; for (i = 622; i < 624; i++) R4578[i] = (char *(*)()) F591_5029;}
	R4578[1070] = (char *(*)()) F591_5029;
	{long i; for (i = 1072; i < 1074; i++) R4578[i] = (char *(*)()) F591_5029;}
}

char *(*R4582[7])();
void R4582_init () {
	R4582[0] = (char *(*)()) F639_5089;
	R4582[1] = (char *(*)()) F640_5089_4582_4;
	R4582[2] = (char *(*)()) F641_5089_4582_4;
	R4582[3] = (char *(*)()) F639_5089;
	R4582[4] = (char *(*)()) F640_5089_4582_4;
	R4582[5] = (char *(*)()) F641_5089_4582_4;
	R4582[6] = (char *(*)()) F639_5089;
}
static void F640_5089_4582_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F640_5089(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F641_5089_4582_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F641_5089(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R4583[505])();
void R4583_init () {
	R4583[0] = (char *(*)()) F664_5489;
	R4583[1] = (char *(*)()) F665_5489_4583_4;
	R4583[2] = (char *(*)()) F666_5489_4583_4;
	R4583[3] = (char *(*)()) F667_5489_4583_4;
	R4583[4] = (char *(*)()) F668_5489_4583_4;
	R4583[5] = (char *(*)()) F669_5489_4583_4;
	R4583[6] = (char *(*)()) F670_5489_4583_4;
	R4583[7] = (char *(*)()) F671_5489_4583_4;
	R4583[8] = (char *(*)()) F672_5489_4583_4;
	R4583[9] = (char *(*)()) F673_5489_4583_4;
	R4583[10] = (char *(*)()) F674_5489_4583_4;
	R4583[11] = (char *(*)()) F675_5489_4583_4;
	R4583[12] = (char *(*)()) F664_5489;
	R4583[13] = (char *(*)()) F671_5489_4583_4;
	R4583[14] = (char *(*)()) F669_5489_4583_4;
	R4583[15] = (char *(*)()) F664_5489;
	R4583[16] = (char *(*)()) F671_5489_4583_4;
	R4583[19] = (char *(*)()) F681_5537;
	R4583[20] = (char *(*)()) F682_5537_4583_4;
	R4583[21] = (char *(*)()) F681_5537;
	R4583[22] = (char *(*)()) F682_5537_4583_4;
	{long i; for (i = 23; i < 25; i++) R4583[i] = (char *(*)()) F681_5537;}
	{long i; for (i = 149; i < 151; i++) R4583[i] = (char *(*)()) F681_5537;}
	{long i; for (i = 152; i < 174; i++) R4583[i] = (char *(*)()) F681_5537;}
	{long i; for (i = 281; i < 284; i++) R4583[i] = (char *(*)()) F664_5489;}
	R4583[504] = (char *(*)()) F681_5537;
}
static void F665_5489_4583_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5489(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F666_5489_4583_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5489(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F667_5489_4583_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5489(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F668_5489_4583_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5489(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F669_5489_4583_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F669_5489(Current, *(EIF_BOOLEAN *)arg1);
}
static void F670_5489_4583_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F670_5489(Current, *(EIF_REAL_64 *)arg1);
}
static void F671_5489_4583_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F671_5489(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F672_5489_4583_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F672_5489(Current, *(EIF_POINTER *)arg1);
}
static void F673_5489_4583_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F673_5489(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F674_5489_4583_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F674_5489(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F675_5489_4583_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F675_5489(Current, *(EIF_REAL_32 *)arg1);
}
static void F682_5537_4583_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F682_5537(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4588[7])();
void R4588_init () {
	R4588[0] = (char *(*)()) F639_5098;
	R4588[1] = (char *(*)()) F640_5098;
	R4588[2] = (char *(*)()) F641_5098;
	R4588[3] = (char *(*)()) F639_5098;
	R4588[4] = (char *(*)()) F640_5098;
	R4588[5] = (char *(*)()) F641_5098;
	R4588[6] = (char *(*)()) F639_5098;
}

char *(*R4593[7])();
void R4593_init () {
	R4593[0] = (char *(*)()) F639_5102;
	R4593[1] = (char *(*)()) F640_5102_4593_5;
	R4593[2] = (char *(*)()) F641_5102_4593_5;
	R4593[3] = (char *(*)()) F639_5102;
	R4593[4] = (char *(*)()) F640_5102_4593_5;
	R4593[5] = (char *(*)()) F641_5102_4593_5;
	R4593[6] = (char *(*)()) F639_5102;
}
static EIF_REFERENCE F640_5102_4593_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F640_5102(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F641_5102_4593_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F641_5102(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R4594[7])();
void R4594_init () {
	R4594[0] = (char *(*)()) F639_5103;
	R4594[1] = (char *(*)()) F640_5103;
	R4594[2] = (char *(*)()) F641_5103;
	R4594[3] = (char *(*)()) F639_5103;
	R4594[4] = (char *(*)()) F640_5103;
	R4594[5] = (char *(*)()) F641_5103;
	R4594[6] = (char *(*)()) F639_5103;
}

char *(*R4597[7])();
void R4597_init () {
	R4597[0] = (char *(*)()) F639_5106;
	R4597[1] = (char *(*)()) F640_5106;
	R4597[2] = (char *(*)()) F641_5106;
	R4597[3] = (char *(*)()) F639_5106;
	R4597[4] = (char *(*)()) F640_5106;
	R4597[5] = (char *(*)()) F641_5106;
	R4597[6] = (char *(*)()) F639_5106;
}

char *(*R4598[7])();
void R4598_init () {
	R4598[0] = (char *(*)()) F639_5107;
	R4598[1] = (char *(*)()) F640_5107;
	R4598[2] = (char *(*)()) F641_5107;
	R4598[3] = (char *(*)()) F639_5107;
	R4598[4] = (char *(*)()) F640_5107;
	R4598[5] = (char *(*)()) F641_5107;
	R4598[6] = (char *(*)()) F639_5107;
}

char *(*R4599[7])();
void R4599_init () {
	R4599[0] = (char *(*)()) F639_5108;
	R4599[1] = (char *(*)()) F640_5108;
	R4599[2] = (char *(*)()) F641_5108;
	R4599[3] = (char *(*)()) F639_5108;
	R4599[4] = (char *(*)()) F640_5108;
	R4599[5] = (char *(*)()) F641_5108;
	R4599[6] = (char *(*)()) F639_5108;
}

char *(*R4604[3])();
void R4604_init () {
	R4604[0] = (char *(*)()) F639_5065;
	R4604[1] = (char *(*)()) F640_5065_4604_1;
	R4604[2] = (char *(*)()) F641_5065_4604_1;
}
static EIF_REFERENCE F640_5065_4604_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F640_5065(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_5065_4604_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F641_5065(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R4605[3])();
void R4605_init () {
	R4605[0] = (char *(*)()) F639_5096;
	R4605[1] = (char *(*)()) F640_5096;
	R4605[2] = (char *(*)()) F641_5096;
}

char *(*R4730[909])();
void R4730_init () {
	R4730[0] = (char *(*)()) F652_5264;
	R4730[1] = (char *(*)()) F653_5290;
	R4730[2] = (char *(*)()) F654_5307;
	R4730[3] = (char *(*)()) F655_5375;
	R4730[4] = (char *(*)()) F656_5375;
	R4730[5] = (char *(*)()) F657_5375;
	R4730[6] = (char *(*)()) F658_5375;
	R4730[7] = (char *(*)()) F659_5375;
	R4730[8] = (char *(*)()) F660_5375;
	R4730[9] = (char *(*)()) F655_5375;
	R4730[10] = (char *(*)()) F657_5375;
	R4730[11] = (char *(*)()) F655_5375;
	R4730[12] = (char *(*)()) F664_5508;
	R4730[13] = (char *(*)()) F665_5508;
	R4730[14] = (char *(*)()) F666_5508;
	R4730[15] = (char *(*)()) F667_5508;
	R4730[16] = (char *(*)()) F668_5508;
	R4730[17] = (char *(*)()) F669_5508;
	R4730[18] = (char *(*)()) F670_5508;
	R4730[19] = (char *(*)()) F671_5508;
	R4730[20] = (char *(*)()) F672_5508;
	R4730[21] = (char *(*)()) F673_5508;
	R4730[22] = (char *(*)()) F674_5508;
	R4730[23] = (char *(*)()) F675_5508;
	R4730[24] = (char *(*)()) F664_5508;
	R4730[25] = (char *(*)()) F671_5508;
	R4730[26] = (char *(*)()) F669_5508;
	R4730[27] = (char *(*)()) F664_5508;
	R4730[28] = (char *(*)()) F671_5508;
	R4730[31] = (char *(*)()) F664_5508;
	R4730[32] = (char *(*)()) F671_5508;
	R4730[33] = (char *(*)()) F664_5508;
	R4730[34] = (char *(*)()) F671_5508;
	{long i; for (i = 35; i < 37; i++) R4730[i] = (char *(*)()) F664_5508;}
	{long i; for (i = 161; i < 163; i++) R4730[i] = (char *(*)()) F664_5508;}
	{long i; for (i = 164; i < 186; i++) R4730[i] = (char *(*)()) F664_5508;}
	{long i; for (i = 293; i < 296; i++) R4730[i] = (char *(*)()) F664_5508;}
	R4730[346] = (char *(*)()) F998_8268;
	{long i; for (i = 420; i < 426; i++) R4730[i] = (char *(*)()) F1071_9359;}
	R4730[430] = (char *(*)()) F1082_9598;
	R4730[431] = (char *(*)()) F1083_9689;
	{long i; for (i = 434; i < 436; i++) R4730[i] = (char *(*)()) F1086_9853;}
	R4730[516] = (char *(*)()) F664_5508;
	{long i; for (i = 904; i < 909; i++) R4730[i] = (char *(*)()) F654_5307;}
}


#ifdef __cplusplus
}
#endif
