#include "epoly9.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4237[867])();
void R4237_init () {
	R4237[0] = (char *(*)()) F302_4516;
	R4237[1] = (char *(*)()) F303_4516;
	R4237[2] = (char *(*)()) F304_4516;
	R4237[3] = (char *(*)()) F305_4516;
	R4237[4] = (char *(*)()) F306_4516;
	R4237[5] = (char *(*)()) F307_4516;
	R4237[6] = (char *(*)()) F308_4516;
	R4237[7] = (char *(*)()) F309_4516;
	R4237[8] = (char *(*)()) F310_4516;
	R4237[9] = (char *(*)()) F311_4516;
	R4237[10] = (char *(*)()) F312_4516;
	R4237[11] = (char *(*)()) F313_4516;
	R4237[276] = (char *(*)()) F302_4516;
	R4237[277] = (char *(*)()) F303_4516;
	R4237[278] = (char *(*)()) F304_4516;
	R4237[279] = (char *(*)()) F305_4516;
	R4237[280] = (char *(*)()) F306_4516;
	R4237[281] = (char *(*)()) F307_4516;
	R4237[282] = (char *(*)()) F308_4516;
	R4237[283] = (char *(*)()) F309_4516;
	R4237[284] = (char *(*)()) F310_4516;
	R4237[285] = (char *(*)()) F311_4516;
	R4237[286] = (char *(*)()) F312_4516;
	R4237[287] = (char *(*)()) F313_4516;
	R4237[288] = (char *(*)()) F305_4516;
	{long i; for (i = 346; i < 348; i++) R4237[i] = (char *(*)()) F305_4516;}
	R4237[362] = (char *(*)()) F302_4516;
	R4237[363] = (char *(*)()) F303_4516;
	R4237[364] = (char *(*)()) F304_4516;
	R4237[365] = (char *(*)()) F305_4516;
	R4237[366] = (char *(*)()) F306_4516;
	R4237[367] = (char *(*)()) F307_4516;
	R4237[368] = (char *(*)()) F308_4516;
	R4237[369] = (char *(*)()) F309_4516;
	R4237[370] = (char *(*)()) F310_4516;
	R4237[371] = (char *(*)()) F311_4516;
	R4237[372] = (char *(*)()) F312_4516;
	R4237[373] = (char *(*)()) F313_4516;
	R4237[374] = (char *(*)()) F302_4516;
	R4237[375] = (char *(*)()) F309_4516;
	R4237[376] = (char *(*)()) F307_4516;
	R4237[377] = (char *(*)()) F302_4516;
	R4237[378] = (char *(*)()) F309_4516;
	R4237[381] = (char *(*)()) F302_4516;
	R4237[382] = (char *(*)()) F309_4516;
	R4237[383] = (char *(*)()) F302_4516;
	R4237[384] = (char *(*)()) F309_4516;
	{long i; for (i = 385; i < 387; i++) R4237[i] = (char *(*)()) F302_4516;}
	{long i; for (i = 511; i < 513; i++) R4237[i] = (char *(*)()) F302_4516;}
	{long i; for (i = 514; i < 536; i++) R4237[i] = (char *(*)()) F302_4516;}
	{long i; for (i = 643; i < 646; i++) R4237[i] = (char *(*)()) F302_4516;}
	R4237[781] = (char *(*)()) F311_4516;
	{long i; for (i = 784; i < 786; i++) R4237[i] = (char *(*)()) F312_4516;}
	R4237[866] = (char *(*)()) F302_4516;
}

char *(*R4238[867])();
void R4238_init () {
	R4238[0] = (char *(*)()) F302_4517;
	R4238[1] = (char *(*)()) F303_4517_4238_243;
	R4238[2] = (char *(*)()) F304_4517_4238_243;
	R4238[3] = (char *(*)()) F305_4517_4238_243;
	R4238[4] = (char *(*)()) F306_4517_4238_243;
	R4238[5] = (char *(*)()) F307_4517_4238_243;
	R4238[6] = (char *(*)()) F308_4517_4238_243;
	R4238[7] = (char *(*)()) F309_4517_4238_243;
	R4238[8] = (char *(*)()) F310_4517_4238_243;
	R4238[9] = (char *(*)()) F311_4517_4238_243;
	R4238[10] = (char *(*)()) F312_4517_4238_243;
	R4238[11] = (char *(*)()) F313_4517_4238_243;
	R4238[276] = (char *(*)()) F302_4517;
	R4238[277] = (char *(*)()) F303_4517_4238_243;
	R4238[278] = (char *(*)()) F304_4517_4238_243;
	R4238[279] = (char *(*)()) F305_4517_4238_243;
	R4238[280] = (char *(*)()) F306_4517_4238_243;
	R4238[281] = (char *(*)()) F307_4517_4238_243;
	R4238[282] = (char *(*)()) F308_4517_4238_243;
	R4238[283] = (char *(*)()) F309_4517_4238_243;
	R4238[284] = (char *(*)()) F310_4517_4238_243;
	R4238[285] = (char *(*)()) F311_4517_4238_243;
	R4238[286] = (char *(*)()) F312_4517_4238_243;
	R4238[287] = (char *(*)()) F313_4517_4238_243;
	R4238[288] = (char *(*)()) F305_4517_4238_243;
	{long i; for (i = 346; i < 348; i++) R4238[i] = (char *(*)()) F305_4517_4238_243;}
	R4238[362] = (char *(*)()) F302_4517;
	R4238[363] = (char *(*)()) F303_4517_4238_243;
	R4238[364] = (char *(*)()) F304_4517_4238_243;
	R4238[365] = (char *(*)()) F305_4517_4238_243;
	R4238[366] = (char *(*)()) F306_4517_4238_243;
	R4238[367] = (char *(*)()) F307_4517_4238_243;
	R4238[368] = (char *(*)()) F308_4517_4238_243;
	R4238[369] = (char *(*)()) F309_4517_4238_243;
	R4238[370] = (char *(*)()) F310_4517_4238_243;
	R4238[371] = (char *(*)()) F311_4517_4238_243;
	R4238[372] = (char *(*)()) F312_4517_4238_243;
	R4238[373] = (char *(*)()) F313_4517_4238_243;
	R4238[374] = (char *(*)()) F302_4517;
	R4238[375] = (char *(*)()) F309_4517_4238_243;
	R4238[376] = (char *(*)()) F307_4517_4238_243;
	R4238[377] = (char *(*)()) F302_4517;
	R4238[378] = (char *(*)()) F309_4517_4238_243;
	R4238[381] = (char *(*)()) F302_4517;
	R4238[382] = (char *(*)()) F309_4517_4238_243;
	R4238[383] = (char *(*)()) F302_4517;
	R4238[384] = (char *(*)()) F309_4517_4238_243;
	{long i; for (i = 385; i < 387; i++) R4238[i] = (char *(*)()) F302_4517;}
	{long i; for (i = 511; i < 513; i++) R4238[i] = (char *(*)()) F302_4517;}
	{long i; for (i = 514; i < 536; i++) R4238[i] = (char *(*)()) F302_4517;}
	{long i; for (i = 643; i < 646; i++) R4238[i] = (char *(*)()) F302_4517;}
	R4238[781] = (char *(*)()) F311_4517_4238_243;
	{long i; for (i = 784; i < 786; i++) R4238[i] = (char *(*)()) F312_4517_4238_243;}
	R4238[866] = (char *(*)()) F302_4517;
}
static void F303_4517_4238_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F303_4517(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F304_4517_4238_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F304_4517(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F305_4517_4238_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F305_4517(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F306_4517_4238_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F306_4517(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F307_4517_4238_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F307_4517(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F308_4517_4238_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F308_4517(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F309_4517_4238_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F309_4517(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F310_4517_4238_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F310_4517(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F311_4517_4238_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F311_4517(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F312_4517_4238_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F312_4517(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F313_4517_4238_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F313_4517(Current, *(EIF_REAL_32 *)arg1, arg2);
}

char *(*R4244[867])();
void R4244_init () {
	R4244[0] = (char *(*)()) F302_4523;
	R4244[1] = (char *(*)()) F303_4523;
	R4244[2] = (char *(*)()) F304_4523;
	R4244[3] = (char *(*)()) F305_4523;
	R4244[4] = (char *(*)()) F306_4523;
	R4244[5] = (char *(*)()) F307_4523;
	R4244[6] = (char *(*)()) F308_4523;
	R4244[7] = (char *(*)()) F309_4523;
	R4244[8] = (char *(*)()) F310_4523;
	R4244[9] = (char *(*)()) F311_4523;
	R4244[10] = (char *(*)()) F312_4523;
	R4244[11] = (char *(*)()) F313_4523;
	R4244[276] = (char *(*)()) F302_4523;
	R4244[277] = (char *(*)()) F303_4523;
	R4244[278] = (char *(*)()) F304_4523;
	R4244[279] = (char *(*)()) F305_4523;
	R4244[280] = (char *(*)()) F306_4523;
	R4244[281] = (char *(*)()) F307_4523;
	R4244[282] = (char *(*)()) F308_4523;
	R4244[283] = (char *(*)()) F309_4523;
	R4244[284] = (char *(*)()) F310_4523;
	R4244[285] = (char *(*)()) F311_4523;
	R4244[286] = (char *(*)()) F312_4523;
	R4244[287] = (char *(*)()) F313_4523;
	R4244[288] = (char *(*)()) F305_4523;
	{long i; for (i = 346; i < 348; i++) R4244[i] = (char *(*)()) F305_4523;}
	R4244[362] = (char *(*)()) F302_4523;
	R4244[363] = (char *(*)()) F303_4523;
	R4244[364] = (char *(*)()) F304_4523;
	R4244[365] = (char *(*)()) F305_4523;
	R4244[366] = (char *(*)()) F306_4523;
	R4244[367] = (char *(*)()) F307_4523;
	R4244[368] = (char *(*)()) F308_4523;
	R4244[369] = (char *(*)()) F309_4523;
	R4244[370] = (char *(*)()) F310_4523;
	R4244[371] = (char *(*)()) F311_4523;
	R4244[372] = (char *(*)()) F312_4523;
	R4244[373] = (char *(*)()) F313_4523;
	R4244[374] = (char *(*)()) F302_4523;
	R4244[375] = (char *(*)()) F309_4523;
	R4244[376] = (char *(*)()) F307_4523;
	R4244[377] = (char *(*)()) F302_4523;
	R4244[378] = (char *(*)()) F309_4523;
	R4244[381] = (char *(*)()) F302_4523;
	R4244[382] = (char *(*)()) F309_4523;
	R4244[383] = (char *(*)()) F302_4523;
	R4244[384] = (char *(*)()) F309_4523;
	{long i; for (i = 385; i < 387; i++) R4244[i] = (char *(*)()) F302_4523;}
	{long i; for (i = 511; i < 513; i++) R4244[i] = (char *(*)()) F302_4523;}
	{long i; for (i = 514; i < 536; i++) R4244[i] = (char *(*)()) F302_4523;}
	{long i; for (i = 643; i < 646; i++) R4244[i] = (char *(*)()) F302_4523;}
	R4244[781] = (char *(*)()) F311_4523;
	{long i; for (i = 784; i < 786; i++) R4244[i] = (char *(*)()) F312_4523;}
	R4244[866] = (char *(*)()) F302_4523;
}

static EIF_TYPE_INDEX Y4245_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype24[] = {1012,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype25[] = {1012,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype26[] = {1012,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype50[] = {1098,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype51[] = {1071,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype52[] = {1071,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype53[] = {1071,0xFFF9,1,997,0,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype54[] = {1071,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype55[] = {1071,0xFFF9,1,997,1033,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype56[] = {1071,0xFFF9,1,997,1175,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype57[] = {1071,0xFFF9,1,997,1184,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype58[] = {1071,0xFFF9,1,997,1168,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype59[] = {1071,0xFFF9,1,997,1126,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype60[] = {1071,0xFFF9,1,997,1128,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype61[] = {1071,0xFFF9,1,997,1193,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype62[] = {1071,0xFFF9,1,997,1033,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype63[] = {1071,0xFFF9,1,997,1167,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype64[] = {1071,0xFFF9,1,997,942,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype65[] = {1071,0xFFF9,1,997,1163,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype66[] = {1071,0xFFF9,1,997,1189,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype67[] = {1071,0xFFF9,5,997,1006,1033,1033,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype68[] = {1071,0xFFF9,4,997,1033,1033,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype69[] = {1071,0xFFF9,1,997,1082,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype70[] = {1071,0xFFF9,1,997,1033,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype71[] = {1071,0xFFF9,1,997,1518,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype72[] = {1071,0xFFF9,7,997,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype73[] = {1071,0xFFF9,2,997,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype74[] = {1071,0xFFF9,3,997,1033,1033,942,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype75[] = {1071,0xFFF9,0,997,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype76[] = {1071,0xFFF9,8,997,1033,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype77[] = {943,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype78[] = {943,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype79[] = {943,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype80[] = {1021,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype81[] = {1024,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype82[] = {1024,0xFFFF};
static EIF_TYPE_INDEX Y4245_pgtype83[] = {1082,0xFFFF};
EIF_TYPE_INDEX *Y4245_gen_type [867];
EIF_TYPE_INDEX Y4245 [867];
void Y4245_init (void)
{
	egc_routines_types [4245] = Y4245;
	egc_routines_gen_types [4245] = Y4245_gen_type;
	egc_routines_offset [4245] = 301;
	Y4245_gen_type [0] = Y4245_pgtype0;
	Y4245_gen_type [1] = Y4245_pgtype1;
	Y4245_gen_type [2] = Y4245_pgtype2;
	Y4245_gen_type [3] = Y4245_pgtype3;
	Y4245_gen_type [4] = Y4245_pgtype4;
	Y4245_gen_type [5] = Y4245_pgtype5;
	Y4245_gen_type [6] = Y4245_pgtype6;
	Y4245_gen_type [7] = Y4245_pgtype7;
	Y4245_gen_type [8] = Y4245_pgtype8;
	Y4245_gen_type [9] = Y4245_pgtype9;
	Y4245_gen_type [10] = Y4245_pgtype10;
	Y4245_gen_type [11] = Y4245_pgtype11;
	Y4245_gen_type [276] = Y4245_pgtype12;
	Y4245_gen_type [277] = Y4245_pgtype13;
	Y4245_gen_type [278] = Y4245_pgtype14;
	Y4245_gen_type [279] = Y4245_pgtype15;
	Y4245_gen_type [280] = Y4245_pgtype16;
	Y4245_gen_type [281] = Y4245_pgtype17;
	Y4245_gen_type [282] = Y4245_pgtype18;
	Y4245_gen_type [283] = Y4245_pgtype19;
	Y4245_gen_type [284] = Y4245_pgtype20;
	Y4245_gen_type [285] = Y4245_pgtype21;
	Y4245_gen_type [286] = Y4245_pgtype22;
	Y4245_gen_type [287] = Y4245_pgtype23;
	Y4245_gen_type [288] = Y4245_pgtype24;
	Y4245_gen_type [346] = Y4245_pgtype25;
	Y4245_gen_type [347] = Y4245_pgtype26;
	Y4245_gen_type [362] = Y4245_pgtype27;
	Y4245_gen_type [363] = Y4245_pgtype28;
	Y4245_gen_type [364] = Y4245_pgtype29;
	Y4245_gen_type [365] = Y4245_pgtype30;
	Y4245_gen_type [366] = Y4245_pgtype31;
	Y4245_gen_type [367] = Y4245_pgtype32;
	Y4245_gen_type [368] = Y4245_pgtype33;
	Y4245_gen_type [369] = Y4245_pgtype34;
	Y4245_gen_type [370] = Y4245_pgtype35;
	Y4245_gen_type [371] = Y4245_pgtype36;
	Y4245_gen_type [372] = Y4245_pgtype37;
	Y4245_gen_type [373] = Y4245_pgtype38;
	Y4245_gen_type [374] = Y4245_pgtype39;
	Y4245_gen_type [375] = Y4245_pgtype40;
	Y4245_gen_type [376] = Y4245_pgtype41;
	Y4245_gen_type [377] = Y4245_pgtype42;
	Y4245_gen_type [378] = Y4245_pgtype43;
	Y4245_gen_type [379] = Y4245_pgtype44;
	Y4245_gen_type [380] = Y4245_pgtype45;
	Y4245_gen_type [381] = Y4245_pgtype46;
	Y4245_gen_type [382] = Y4245_pgtype47;
	Y4245_gen_type [383] = Y4245_pgtype48;
	Y4245_gen_type [384] = Y4245_pgtype49;
	Y4245_gen_type [385] = Y4245_pgtype50;
	Y4245_gen_type [386] = Y4245_pgtype51;
	Y4245_gen_type [511] = Y4245_pgtype52;
	Y4245_gen_type [512] = Y4245_pgtype53;
	Y4245_gen_type [513] = Y4245_pgtype54;
	Y4245_gen_type [514] = Y4245_pgtype55;
	Y4245_gen_type [515] = Y4245_pgtype56;
	Y4245_gen_type [516] = Y4245_pgtype57;
	Y4245_gen_type [517] = Y4245_pgtype58;
	Y4245_gen_type [518] = Y4245_pgtype59;
	Y4245_gen_type [519] = Y4245_pgtype60;
	Y4245_gen_type [520] = Y4245_pgtype61;
	Y4245_gen_type [521] = Y4245_pgtype62;
	Y4245_gen_type [522] = Y4245_pgtype63;
	Y4245_gen_type [523] = Y4245_pgtype64;
	Y4245_gen_type [524] = Y4245_pgtype65;
	Y4245_gen_type [525] = Y4245_pgtype66;
	Y4245_gen_type [526] = Y4245_pgtype67;
	Y4245_gen_type [527] = Y4245_pgtype68;
	Y4245_gen_type [528] = Y4245_pgtype69;
	Y4245_gen_type [529] = Y4245_pgtype70;
	Y4245_gen_type [530] = Y4245_pgtype71;
	Y4245_gen_type [531] = Y4245_pgtype72;
	Y4245_gen_type [532] = Y4245_pgtype73;
	Y4245_gen_type [533] = Y4245_pgtype74;
	Y4245_gen_type [534] = Y4245_pgtype75;
	Y4245_gen_type [535] = Y4245_pgtype76;
	Y4245_gen_type [643] = Y4245_pgtype77;
	Y4245_gen_type [644] = Y4245_pgtype78;
	Y4245_gen_type [645] = Y4245_pgtype79;
	Y4245_gen_type [781] = Y4245_pgtype80;
	Y4245_gen_type [784] = Y4245_pgtype81;
	Y4245_gen_type [785] = Y4245_pgtype82;
	Y4245_gen_type [866] = Y4245_pgtype83;
	Y4245[288] = 1012;
	{long i; for (i = 346; i < 348; i++) Y4245[i] = 1012;};
	Y4245[385] = 1098;
	Y4245[386] = 1071;
	{long i; for (i = 511; i < 536; i++) Y4245[i] = 1071;};
	{long i; for (i = 643; i < 646; i++) Y4245[i] = 943;};
	Y4245[781] = 1021;
	{long i; for (i = 784; i < 786; i++) Y4245[i] = 1024;};
	Y4245[866] = 1082;
}

char *(*R4258[1137])();
void R4258_init () {
	{long i; for (i = 0; i < 2; i++) R4258[i] = (char *(*)()) F558_4879;}
	R4258[2] = (char *(*)()) F578_4942;
	R4258[3] = (char *(*)()) F579_4942;
	R4258[4] = (char *(*)()) F580_4942;
	R4258[5] = (char *(*)()) F581_4942;
	R4258[6] = (char *(*)()) F582_4942;
	R4258[7] = (char *(*)()) F583_4942;
	R4258[8] = (char *(*)()) F584_4942;
	R4258[9] = (char *(*)()) F585_4942;
	R4258[10] = (char *(*)()) F586_4942;
	R4258[11] = (char *(*)()) F587_4942;
	R4258[12] = (char *(*)()) F588_4942;
	R4258[13] = (char *(*)()) F589_4942;
	R4258[14] = (char *(*)()) F581_4942;
	R4258[63] = (char *(*)()) F639_5070;
	R4258[64] = (char *(*)()) F640_5070;
	R4258[65] = (char *(*)()) F641_5070;
	R4258[66] = (char *(*)()) F639_5070;
	R4258[67] = (char *(*)()) F640_5070;
	R4258[68] = (char *(*)()) F641_5070;
	R4258[69] = (char *(*)()) F639_5070;
	R4258[79] = (char *(*)()) F655_5331;
	R4258[80] = (char *(*)()) F656_5331;
	R4258[81] = (char *(*)()) F657_5331;
	R4258[82] = (char *(*)()) F658_5331;
	R4258[83] = (char *(*)()) F659_5331;
	R4258[84] = (char *(*)()) F660_5331;
	R4258[85] = (char *(*)()) F655_5331;
	R4258[86] = (char *(*)()) F657_5331;
	R4258[87] = (char *(*)()) F655_5331;
	R4258[88] = (char *(*)()) F664_5461;
	R4258[89] = (char *(*)()) F665_5461;
	R4258[90] = (char *(*)()) F666_5461;
	R4258[91] = (char *(*)()) F667_5461;
	R4258[92] = (char *(*)()) F668_5461;
	R4258[93] = (char *(*)()) F669_5461;
	R4258[94] = (char *(*)()) F670_5461;
	R4258[95] = (char *(*)()) F671_5461;
	R4258[96] = (char *(*)()) F672_5461;
	R4258[97] = (char *(*)()) F673_5461;
	R4258[98] = (char *(*)()) F674_5461;
	R4258[99] = (char *(*)()) F675_5461;
	R4258[100] = (char *(*)()) F664_5461;
	R4258[101] = (char *(*)()) F671_5461;
	R4258[102] = (char *(*)()) F669_5461;
	R4258[103] = (char *(*)()) F664_5461;
	R4258[104] = (char *(*)()) F671_5461;
	R4258[107] = (char *(*)()) F664_5461;
	R4258[108] = (char *(*)()) F671_5461;
	R4258[109] = (char *(*)()) F664_5461;
	R4258[110] = (char *(*)()) F671_5461;
	{long i; for (i = 111; i < 113; i++) R4258[i] = (char *(*)()) F664_5461;}
	R4258[129] = (char *(*)()) F705_5966;
	R4258[131] = (char *(*)()) F707_5993;
	R4258[132] = (char *(*)()) F708_6011;
	{long i; for (i = 237; i < 239; i++) R4258[i] = (char *(*)()) F664_5461;}
	{long i; for (i = 240; i < 262; i++) R4258[i] = (char *(*)()) F664_5461;}
	{long i; for (i = 359; i < 361; i++) R4258[i] = (char *(*)()) F934_7340;}
	{long i; for (i = 369; i < 372; i++) R4258[i] = (char *(*)()) F664_5461;}
	R4258[422] = (char *(*)()) F552_4879;
	{long i; for (i = 506; i < 508; i++) R4258[i] = (char *(*)()) F1081_9542;}
	{long i; for (i = 509; i < 512; i++) R4258[i] = (char *(*)()) F1084_9710;}
	R4258[563] = (char *(*)()) F552_4879;
	R4258[592] = (char *(*)()) F664_5461;
	R4258[603] = (char *(*)()) F552_4879;
	{long i; for (i = 610; i < 612; i++) R4258[i] = (char *(*)()) F552_4879;}
	R4258[620] = (char *(*)()) F552_4879;
	{long i; for (i = 625; i < 627; i++) R4258[i] = (char *(*)()) F552_4879;}
	{long i; for (i = 628; i < 634; i++) R4258[i] = (char *(*)()) F552_4879;}
	{long i; for (i = 664; i < 666; i++) R4258[i] = (char *(*)()) F552_4879;}
	{long i; for (i = 667; i < 669; i++) R4258[i] = (char *(*)()) F552_4879;}
	{long i; for (i = 678; i < 681; i++) R4258[i] = (char *(*)()) F552_4879;}
	{long i; for (i = 685; i < 687; i++) R4258[i] = (char *(*)()) F552_4879;}
	R4258[944] = (char *(*)()) F1520_16508;
	R4258[1051] = (char *(*)()) F708_6011;
	R4258[1133] = (char *(*)()) F552_4879;
	{long i; for (i = 1135; i < 1137; i++) R4258[i] = (char *(*)()) F552_4879;}
}

static EIF_TYPE_INDEX Y4259_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype12[] = {1081,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype13[] = {1085,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype256[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype260[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype261[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype264[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype274[] = {1012,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype319[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype320[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype321[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype339[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype358[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype362[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype363[] = {1098,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype364[] = {1071,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype365[] = {24,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype366[] = {1021,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype367[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype368[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype369[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype370[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype371[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype372[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype373[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype374[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype375[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype376[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype377[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype378[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype379[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype380[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype381[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype382[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype383[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype384[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype385[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype387[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype438[] = {1021,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype439[] = {1024,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype447[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype448[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype449[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype450[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype451[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype452[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype453[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype454[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype455[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype456[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype457[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype458[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype459[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype460[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype461[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype462[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype463[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype464[] = {1071,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype465[] = {1071,0xFFF9,1,997,0,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype466[] = {1071,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype467[] = {1071,0xFFF9,1,997,1033,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype468[] = {1071,0xFFF9,1,997,1175,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype469[] = {1071,0xFFF9,1,997,1184,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype470[] = {1071,0xFFF9,1,997,1168,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype471[] = {1071,0xFFF9,1,997,1126,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype472[] = {1071,0xFFF9,1,997,1128,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype473[] = {1071,0xFFF9,1,997,1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype474[] = {1071,0xFFF9,1,997,1033,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype475[] = {1071,0xFFF9,1,997,1167,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype476[] = {1071,0xFFF9,1,997,942,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype477[] = {1071,0xFFF9,1,997,1163,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype478[] = {1071,0xFFF9,1,997,1189,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype479[] = {1071,0xFFF9,5,997,1006,1033,1033,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype480[] = {1071,0xFFF9,4,997,1033,1033,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype481[] = {1071,0xFFF9,1,997,1082,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype482[] = {1071,0xFFF9,1,997,1033,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype483[] = {1071,0xFFF9,1,997,1518,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype484[] = {1071,0xFFF9,7,997,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype485[] = {1071,0xFFF9,2,997,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype486[] = {1071,0xFFF9,3,997,1033,1033,942,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype487[] = {1071,0xFFF9,0,997,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype488[] = {1071,0xFFF9,8,997,1033,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype489[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype490[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype491[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype492[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype493[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype494[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype495[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype496[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype497[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype498[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype499[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype500[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype501[] = {1024,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype502[] = {1024,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype503[] = {1024,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype504[] = {943,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype505[] = {943,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype506[] = {943,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype507[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype508[] = {1021,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype509[] = {1021,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype510[] = {1021,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype511[] = {1024,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype512[] = {1024,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype513[] = {1024,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype514[] = {1024,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype515[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype516[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype517[] = {1184,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype518[] = {1175,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype519[] = {1175,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype520[] = {1082,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype521[] = {1175,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype522[] = {1184,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype523[] = {1184,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype524[] = {1184,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype525[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype526[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype527[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype528[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype529[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype530[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype531[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype532[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype533[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype534[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype535[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype536[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype537[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype538[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype539[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype540[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype541[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype542[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype543[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype544[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype545[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype546[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype547[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype548[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype549[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype550[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype551[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype552[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype553[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype554[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype555[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype556[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype557[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype558[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype559[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype560[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype561[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype562[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype563[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype564[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype565[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype566[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype567[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype568[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype569[] = {1170,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype570[] = {1167,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype571[] = {1168,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype572[] = {1168,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype573[] = {1189,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype574[] = {1189,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype575[] = {1189,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype576[] = {1189,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype577[] = {1184,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype578[] = {1184,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype579[] = {1024,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype580[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype581[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype582[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype583[] = {1193,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype584[] = {1184,0xFFFF};
static EIF_TYPE_INDEX Y4259_pgtype585[] = {1193,0xFFFF};
EIF_TYPE_INDEX *Y4259_gen_type [1398];
EIF_TYPE_INDEX Y4259 [1398];
void Y4259_init (void)
{
	egc_routines_types [4259] = Y4259;
	egc_routines_gen_types [4259] = Y4259_gen_type;
	egc_routines_offset [4259] = 315;
	Y4259_gen_type [0] = Y4259_pgtype0;
	Y4259_gen_type [1] = Y4259_pgtype1;
	Y4259_gen_type [2] = Y4259_pgtype2;
	Y4259_gen_type [3] = Y4259_pgtype3;
	Y4259_gen_type [4] = Y4259_pgtype4;
	Y4259_gen_type [5] = Y4259_pgtype5;
	Y4259_gen_type [6] = Y4259_pgtype6;
	Y4259_gen_type [7] = Y4259_pgtype7;
	Y4259_gen_type [8] = Y4259_pgtype8;
	Y4259_gen_type [9] = Y4259_pgtype9;
	Y4259_gen_type [10] = Y4259_pgtype10;
	Y4259_gen_type [11] = Y4259_pgtype11;
	Y4259_gen_type [12] = Y4259_pgtype12;
	Y4259_gen_type [13] = Y4259_pgtype13;
	Y4259_gen_type [14] = Y4259_pgtype14;
	Y4259_gen_type [15] = Y4259_pgtype15;
	Y4259_gen_type [16] = Y4259_pgtype16;
	Y4259_gen_type [17] = Y4259_pgtype17;
	Y4259_gen_type [18] = Y4259_pgtype18;
	Y4259_gen_type [19] = Y4259_pgtype19;
	Y4259_gen_type [20] = Y4259_pgtype20;
	Y4259_gen_type [21] = Y4259_pgtype21;
	Y4259_gen_type [22] = Y4259_pgtype22;
	Y4259_gen_type [23] = Y4259_pgtype23;
	Y4259_gen_type [24] = Y4259_pgtype24;
	Y4259_gen_type [25] = Y4259_pgtype25;
	Y4259_gen_type [26] = Y4259_pgtype26;
	Y4259_gen_type [27] = Y4259_pgtype27;
	Y4259_gen_type [28] = Y4259_pgtype28;
	Y4259_gen_type [29] = Y4259_pgtype29;
	Y4259_gen_type [30] = Y4259_pgtype30;
	Y4259_gen_type [31] = Y4259_pgtype31;
	Y4259_gen_type [32] = Y4259_pgtype32;
	Y4259_gen_type [33] = Y4259_pgtype33;
	Y4259_gen_type [34] = Y4259_pgtype34;
	Y4259_gen_type [35] = Y4259_pgtype35;
	Y4259_gen_type [36] = Y4259_pgtype36;
	Y4259_gen_type [37] = Y4259_pgtype37;
	Y4259_gen_type [38] = Y4259_pgtype38;
	Y4259_gen_type [39] = Y4259_pgtype39;
	Y4259_gen_type [40] = Y4259_pgtype40;
	Y4259_gen_type [41] = Y4259_pgtype41;
	Y4259_gen_type [42] = Y4259_pgtype42;
	Y4259_gen_type [43] = Y4259_pgtype43;
	Y4259_gen_type [44] = Y4259_pgtype44;
	Y4259_gen_type [45] = Y4259_pgtype45;
	Y4259_gen_type [46] = Y4259_pgtype46;
	Y4259_gen_type [47] = Y4259_pgtype47;
	Y4259_gen_type [48] = Y4259_pgtype48;
	Y4259_gen_type [49] = Y4259_pgtype49;
	Y4259_gen_type [50] = Y4259_pgtype50;
	Y4259_gen_type [51] = Y4259_pgtype51;
	Y4259_gen_type [52] = Y4259_pgtype52;
	Y4259_gen_type [53] = Y4259_pgtype53;
	Y4259_gen_type [54] = Y4259_pgtype54;
	Y4259_gen_type [55] = Y4259_pgtype55;
	Y4259_gen_type [56] = Y4259_pgtype56;
	Y4259_gen_type [57] = Y4259_pgtype57;
	Y4259_gen_type [58] = Y4259_pgtype58;
	Y4259_gen_type [59] = Y4259_pgtype59;
	Y4259_gen_type [60] = Y4259_pgtype60;
	Y4259_gen_type [61] = Y4259_pgtype61;
	Y4259_gen_type [62] = Y4259_pgtype62;
	Y4259_gen_type [63] = Y4259_pgtype63;
	Y4259_gen_type [64] = Y4259_pgtype64;
	Y4259_gen_type [65] = Y4259_pgtype65;
	Y4259_gen_type [66] = Y4259_pgtype66;
	Y4259_gen_type [67] = Y4259_pgtype67;
	Y4259_gen_type [68] = Y4259_pgtype68;
	Y4259_gen_type [69] = Y4259_pgtype69;
	Y4259_gen_type [70] = Y4259_pgtype70;
	Y4259_gen_type [71] = Y4259_pgtype71;
	Y4259_gen_type [72] = Y4259_pgtype72;
	Y4259_gen_type [73] = Y4259_pgtype73;
	Y4259_gen_type [74] = Y4259_pgtype74;
	Y4259_gen_type [75] = Y4259_pgtype75;
	Y4259_gen_type [76] = Y4259_pgtype76;
	Y4259_gen_type [77] = Y4259_pgtype77;
	Y4259_gen_type [78] = Y4259_pgtype78;
	Y4259_gen_type [79] = Y4259_pgtype79;
	Y4259_gen_type [80] = Y4259_pgtype80;
	Y4259_gen_type [81] = Y4259_pgtype81;
	Y4259_gen_type [82] = Y4259_pgtype82;
	Y4259_gen_type [83] = Y4259_pgtype83;
	Y4259_gen_type [84] = Y4259_pgtype84;
	Y4259_gen_type [85] = Y4259_pgtype85;
	Y4259_gen_type [86] = Y4259_pgtype86;
	Y4259_gen_type [87] = Y4259_pgtype87;
	Y4259_gen_type [88] = Y4259_pgtype88;
	Y4259_gen_type [89] = Y4259_pgtype89;
	Y4259_gen_type [90] = Y4259_pgtype90;
	Y4259_gen_type [91] = Y4259_pgtype91;
	Y4259_gen_type [92] = Y4259_pgtype92;
	Y4259_gen_type [93] = Y4259_pgtype93;
	Y4259_gen_type [94] = Y4259_pgtype94;
	Y4259_gen_type [95] = Y4259_pgtype95;
	Y4259_gen_type [96] = Y4259_pgtype96;
	Y4259_gen_type [97] = Y4259_pgtype97;
	Y4259_gen_type [98] = Y4259_pgtype98;
	Y4259_gen_type [99] = Y4259_pgtype99;
	Y4259_gen_type [100] = Y4259_pgtype100;
	Y4259_gen_type [101] = Y4259_pgtype101;
	Y4259_gen_type [102] = Y4259_pgtype102;
	Y4259_gen_type [103] = Y4259_pgtype103;
	Y4259_gen_type [104] = Y4259_pgtype104;
	Y4259_gen_type [105] = Y4259_pgtype105;
	Y4259_gen_type [106] = Y4259_pgtype106;
	Y4259_gen_type [107] = Y4259_pgtype107;
	Y4259_gen_type [108] = Y4259_pgtype108;
	Y4259_gen_type [109] = Y4259_pgtype109;
	Y4259_gen_type [110] = Y4259_pgtype110;
	Y4259_gen_type [111] = Y4259_pgtype111;
	Y4259_gen_type [112] = Y4259_pgtype112;
	Y4259_gen_type [113] = Y4259_pgtype113;
	Y4259_gen_type [114] = Y4259_pgtype114;
	Y4259_gen_type [115] = Y4259_pgtype115;
	Y4259_gen_type [116] = Y4259_pgtype116;
	Y4259_gen_type [117] = Y4259_pgtype117;
	Y4259_gen_type [118] = Y4259_pgtype118;
	Y4259_gen_type [119] = Y4259_pgtype119;
	Y4259_gen_type [120] = Y4259_pgtype120;
	Y4259_gen_type [121] = Y4259_pgtype121;
	Y4259_gen_type [122] = Y4259_pgtype122;
	Y4259_gen_type [123] = Y4259_pgtype123;
	Y4259_gen_type [124] = Y4259_pgtype124;
	Y4259_gen_type [125] = Y4259_pgtype125;
	Y4259_gen_type [126] = Y4259_pgtype126;
	Y4259_gen_type [127] = Y4259_pgtype127;
	Y4259_gen_type [128] = Y4259_pgtype128;
	Y4259_gen_type [129] = Y4259_pgtype129;
	Y4259_gen_type [130] = Y4259_pgtype130;
	Y4259_gen_type [131] = Y4259_pgtype131;
	Y4259_gen_type [132] = Y4259_pgtype132;
	Y4259_gen_type [133] = Y4259_pgtype133;
	Y4259_gen_type [134] = Y4259_pgtype134;
	Y4259_gen_type [135] = Y4259_pgtype135;
	Y4259_gen_type [136] = Y4259_pgtype136;
	Y4259_gen_type [137] = Y4259_pgtype137;
	Y4259_gen_type [138] = Y4259_pgtype138;
	Y4259_gen_type [139] = Y4259_pgtype139;
	Y4259_gen_type [140] = Y4259_pgtype140;
	Y4259_gen_type [141] = Y4259_pgtype141;
	Y4259_gen_type [142] = Y4259_pgtype142;
	Y4259_gen_type [143] = Y4259_pgtype143;
	Y4259_gen_type [144] = Y4259_pgtype144;
	Y4259_gen_type [145] = Y4259_pgtype145;
	Y4259_gen_type [146] = Y4259_pgtype146;
	Y4259_gen_type [147] = Y4259_pgtype147;
	Y4259_gen_type [148] = Y4259_pgtype148;
	Y4259_gen_type [149] = Y4259_pgtype149;
	Y4259_gen_type [150] = Y4259_pgtype150;
	Y4259_gen_type [151] = Y4259_pgtype151;
	Y4259_gen_type [152] = Y4259_pgtype152;
	Y4259_gen_type [153] = Y4259_pgtype153;
	Y4259_gen_type [154] = Y4259_pgtype154;
	Y4259_gen_type [155] = Y4259_pgtype155;
	Y4259_gen_type [156] = Y4259_pgtype156;
	Y4259_gen_type [157] = Y4259_pgtype157;
	Y4259_gen_type [158] = Y4259_pgtype158;
	Y4259_gen_type [159] = Y4259_pgtype159;
	Y4259_gen_type [160] = Y4259_pgtype160;
	Y4259_gen_type [161] = Y4259_pgtype161;
	Y4259_gen_type [162] = Y4259_pgtype162;
	Y4259_gen_type [163] = Y4259_pgtype163;
	Y4259_gen_type [164] = Y4259_pgtype164;
	Y4259_gen_type [165] = Y4259_pgtype165;
	Y4259_gen_type [166] = Y4259_pgtype166;
	Y4259_gen_type [167] = Y4259_pgtype167;
	Y4259_gen_type [168] = Y4259_pgtype168;
	Y4259_gen_type [169] = Y4259_pgtype169;
	Y4259_gen_type [170] = Y4259_pgtype170;
	Y4259_gen_type [171] = Y4259_pgtype171;
	Y4259_gen_type [172] = Y4259_pgtype172;
	Y4259_gen_type [173] = Y4259_pgtype173;
	Y4259_gen_type [174] = Y4259_pgtype174;
	Y4259_gen_type [175] = Y4259_pgtype175;
	Y4259_gen_type [176] = Y4259_pgtype176;
	Y4259_gen_type [177] = Y4259_pgtype177;
	Y4259_gen_type [178] = Y4259_pgtype178;
	Y4259_gen_type [179] = Y4259_pgtype179;
	Y4259_gen_type [180] = Y4259_pgtype180;
	Y4259_gen_type [181] = Y4259_pgtype181;
	Y4259_gen_type [182] = Y4259_pgtype182;
	Y4259_gen_type [183] = Y4259_pgtype183;
	Y4259_gen_type [184] = Y4259_pgtype184;
	Y4259_gen_type [185] = Y4259_pgtype185;
	Y4259_gen_type [186] = Y4259_pgtype186;
	Y4259_gen_type [187] = Y4259_pgtype187;
	Y4259_gen_type [188] = Y4259_pgtype188;
	Y4259_gen_type [189] = Y4259_pgtype189;
	Y4259_gen_type [190] = Y4259_pgtype190;
	Y4259_gen_type [191] = Y4259_pgtype191;
	Y4259_gen_type [192] = Y4259_pgtype192;
	Y4259_gen_type [193] = Y4259_pgtype193;
	Y4259_gen_type [194] = Y4259_pgtype194;
	Y4259_gen_type [195] = Y4259_pgtype195;
	Y4259_gen_type [196] = Y4259_pgtype196;
	Y4259_gen_type [197] = Y4259_pgtype197;
	Y4259_gen_type [198] = Y4259_pgtype198;
	Y4259_gen_type [199] = Y4259_pgtype199;
	Y4259_gen_type [200] = Y4259_pgtype200;
	Y4259_gen_type [201] = Y4259_pgtype201;
	Y4259_gen_type [202] = Y4259_pgtype202;
	Y4259_gen_type [203] = Y4259_pgtype203;
	Y4259_gen_type [204] = Y4259_pgtype204;
	Y4259_gen_type [205] = Y4259_pgtype205;
	Y4259_gen_type [206] = Y4259_pgtype206;
	Y4259_gen_type [207] = Y4259_pgtype207;
	Y4259_gen_type [208] = Y4259_pgtype208;
	Y4259_gen_type [209] = Y4259_pgtype209;
	Y4259_gen_type [210] = Y4259_pgtype210;
	Y4259_gen_type [211] = Y4259_pgtype211;
	Y4259_gen_type [212] = Y4259_pgtype212;
	Y4259_gen_type [213] = Y4259_pgtype213;
	Y4259_gen_type [214] = Y4259_pgtype214;
	Y4259_gen_type [215] = Y4259_pgtype215;
	Y4259_gen_type [216] = Y4259_pgtype216;
	Y4259_gen_type [217] = Y4259_pgtype217;
	Y4259_gen_type [218] = Y4259_pgtype218;
	Y4259_gen_type [219] = Y4259_pgtype219;
	Y4259_gen_type [220] = Y4259_pgtype220;
	Y4259_gen_type [221] = Y4259_pgtype221;
	Y4259_gen_type [222] = Y4259_pgtype222;
	Y4259_gen_type [223] = Y4259_pgtype223;
	Y4259_gen_type [224] = Y4259_pgtype224;
	Y4259_gen_type [225] = Y4259_pgtype225;
	Y4259_gen_type [226] = Y4259_pgtype226;
	Y4259_gen_type [227] = Y4259_pgtype227;
	Y4259_gen_type [228] = Y4259_pgtype228;
	Y4259_gen_type [229] = Y4259_pgtype229;
	Y4259_gen_type [230] = Y4259_pgtype230;
	Y4259_gen_type [231] = Y4259_pgtype231;
	Y4259_gen_type [232] = Y4259_pgtype232;
	Y4259_gen_type [233] = Y4259_pgtype233;
	Y4259_gen_type [234] = Y4259_pgtype234;
	Y4259_gen_type [235] = Y4259_pgtype235;
	Y4259_gen_type [236] = Y4259_pgtype236;
	Y4259_gen_type [237] = Y4259_pgtype237;
	Y4259_gen_type [238] = Y4259_pgtype238;
	Y4259_gen_type [239] = Y4259_pgtype239;
	Y4259_gen_type [240] = Y4259_pgtype240;
	Y4259_gen_type [241] = Y4259_pgtype241;
	Y4259_gen_type [242] = Y4259_pgtype242;
	Y4259_gen_type [243] = Y4259_pgtype243;
	Y4259_gen_type [244] = Y4259_pgtype244;
	Y4259_gen_type [245] = Y4259_pgtype245;
	Y4259_gen_type [246] = Y4259_pgtype246;
	Y4259_gen_type [247] = Y4259_pgtype247;
	Y4259_gen_type [248] = Y4259_pgtype248;
	Y4259_gen_type [249] = Y4259_pgtype249;
	Y4259_gen_type [250] = Y4259_pgtype250;
	Y4259_gen_type [251] = Y4259_pgtype251;
	Y4259_gen_type [252] = Y4259_pgtype252;
	Y4259_gen_type [253] = Y4259_pgtype253;
	Y4259_gen_type [254] = Y4259_pgtype254;
	Y4259_gen_type [255] = Y4259_pgtype255;
	Y4259_gen_type [256] = Y4259_pgtype256;
	Y4259_gen_type [257] = Y4259_pgtype257;
	Y4259_gen_type [258] = Y4259_pgtype258;
	Y4259_gen_type [259] = Y4259_pgtype259;
	Y4259_gen_type [260] = Y4259_pgtype260;
	Y4259_gen_type [261] = Y4259_pgtype261;
	Y4259_gen_type [262] = Y4259_pgtype262;
	Y4259_gen_type [263] = Y4259_pgtype263;
	Y4259_gen_type [264] = Y4259_pgtype264;
	Y4259_gen_type [265] = Y4259_pgtype265;
	Y4259_gen_type [266] = Y4259_pgtype266;
	Y4259_gen_type [267] = Y4259_pgtype267;
	Y4259_gen_type [268] = Y4259_pgtype268;
	Y4259_gen_type [269] = Y4259_pgtype269;
	Y4259_gen_type [270] = Y4259_pgtype270;
	Y4259_gen_type [271] = Y4259_pgtype271;
	Y4259_gen_type [272] = Y4259_pgtype272;
	Y4259_gen_type [273] = Y4259_pgtype273;
	Y4259_gen_type [274] = Y4259_pgtype274;
	Y4259_gen_type [275] = Y4259_pgtype275;
	Y4259_gen_type [276] = Y4259_pgtype276;
	Y4259_gen_type [277] = Y4259_pgtype277;
	Y4259_gen_type [278] = Y4259_pgtype278;
	Y4259_gen_type [279] = Y4259_pgtype279;
	Y4259_gen_type [280] = Y4259_pgtype280;
	Y4259_gen_type [281] = Y4259_pgtype281;
	Y4259_gen_type [282] = Y4259_pgtype282;
	Y4259_gen_type [283] = Y4259_pgtype283;
	Y4259_gen_type [284] = Y4259_pgtype284;
	Y4259_gen_type [285] = Y4259_pgtype285;
	Y4259_gen_type [286] = Y4259_pgtype286;
	Y4259_gen_type [287] = Y4259_pgtype287;
	Y4259_gen_type [288] = Y4259_pgtype288;
	Y4259_gen_type [289] = Y4259_pgtype289;
	Y4259_gen_type [290] = Y4259_pgtype290;
	Y4259_gen_type [291] = Y4259_pgtype291;
	Y4259_gen_type [292] = Y4259_pgtype292;
	Y4259_gen_type [293] = Y4259_pgtype293;
	Y4259_gen_type [294] = Y4259_pgtype294;
	Y4259_gen_type [295] = Y4259_pgtype295;
	Y4259_gen_type [296] = Y4259_pgtype296;
	Y4259_gen_type [297] = Y4259_pgtype297;
	Y4259_gen_type [298] = Y4259_pgtype298;
	Y4259_gen_type [299] = Y4259_pgtype299;
	Y4259_gen_type [300] = Y4259_pgtype300;
	Y4259_gen_type [301] = Y4259_pgtype301;
	Y4259_gen_type [302] = Y4259_pgtype302;
	Y4259_gen_type [303] = Y4259_pgtype303;
	Y4259_gen_type [304] = Y4259_pgtype304;
	Y4259_gen_type [305] = Y4259_pgtype305;
	Y4259_gen_type [306] = Y4259_pgtype306;
	Y4259_gen_type [307] = Y4259_pgtype307;
	Y4259_gen_type [308] = Y4259_pgtype308;
	Y4259_gen_type [309] = Y4259_pgtype309;
	Y4259_gen_type [310] = Y4259_pgtype310;
	Y4259_gen_type [311] = Y4259_pgtype311;
	Y4259_gen_type [312] = Y4259_pgtype312;
	Y4259_gen_type [313] = Y4259_pgtype313;
	Y4259_gen_type [314] = Y4259_pgtype314;
	Y4259_gen_type [315] = Y4259_pgtype315;
	Y4259_gen_type [316] = Y4259_pgtype316;
	Y4259_gen_type [317] = Y4259_pgtype317;
	Y4259_gen_type [318] = Y4259_pgtype318;
	Y4259_gen_type [319] = Y4259_pgtype319;
	Y4259_gen_type [320] = Y4259_pgtype320;
	Y4259_gen_type [321] = Y4259_pgtype321;
	Y4259_gen_type [322] = Y4259_pgtype322;
	Y4259_gen_type [323] = Y4259_pgtype323;
	Y4259_gen_type [324] = Y4259_pgtype324;
	Y4259_gen_type [325] = Y4259_pgtype325;
	Y4259_gen_type [326] = Y4259_pgtype326;
	Y4259_gen_type [327] = Y4259_pgtype327;
	Y4259_gen_type [328] = Y4259_pgtype328;
	Y4259_gen_type [329] = Y4259_pgtype329;
	Y4259_gen_type [337] = Y4259_pgtype330;
	Y4259_gen_type [339] = Y4259_pgtype331;
	Y4259_gen_type [340] = Y4259_pgtype332;
	Y4259_gen_type [341] = Y4259_pgtype333;
	Y4259_gen_type [342] = Y4259_pgtype334;
	Y4259_gen_type [343] = Y4259_pgtype335;
	Y4259_gen_type [344] = Y4259_pgtype336;
	Y4259_gen_type [345] = Y4259_pgtype337;
	Y4259_gen_type [346] = Y4259_pgtype338;
	Y4259_gen_type [347] = Y4259_pgtype339;
	Y4259_gen_type [348] = Y4259_pgtype340;
	Y4259_gen_type [349] = Y4259_pgtype341;
	Y4259_gen_type [350] = Y4259_pgtype342;
	Y4259_gen_type [351] = Y4259_pgtype343;
	Y4259_gen_type [352] = Y4259_pgtype344;
	Y4259_gen_type [353] = Y4259_pgtype345;
	Y4259_gen_type [354] = Y4259_pgtype346;
	Y4259_gen_type [355] = Y4259_pgtype347;
	Y4259_gen_type [356] = Y4259_pgtype348;
	Y4259_gen_type [357] = Y4259_pgtype349;
	Y4259_gen_type [358] = Y4259_pgtype350;
	Y4259_gen_type [359] = Y4259_pgtype351;
	Y4259_gen_type [360] = Y4259_pgtype352;
	Y4259_gen_type [361] = Y4259_pgtype353;
	Y4259_gen_type [362] = Y4259_pgtype354;
	Y4259_gen_type [363] = Y4259_pgtype355;
	Y4259_gen_type [364] = Y4259_pgtype356;
	Y4259_gen_type [365] = Y4259_pgtype357;
	Y4259_gen_type [366] = Y4259_pgtype358;
	Y4259_gen_type [367] = Y4259_pgtype359;
	Y4259_gen_type [368] = Y4259_pgtype360;
	Y4259_gen_type [369] = Y4259_pgtype361;
	Y4259_gen_type [370] = Y4259_pgtype362;
	Y4259_gen_type [371] = Y4259_pgtype363;
	Y4259_gen_type [372] = Y4259_pgtype364;
	Y4259_gen_type [389] = Y4259_pgtype365;
	Y4259_gen_type [390] = Y4259_pgtype366;
	Y4259_gen_type [391] = Y4259_pgtype367;
	Y4259_gen_type [392] = Y4259_pgtype368;
	Y4259_gen_type [399] = Y4259_pgtype369;
	Y4259_gen_type [400] = Y4259_pgtype370;
	Y4259_gen_type [401] = Y4259_pgtype371;
	Y4259_gen_type [402] = Y4259_pgtype372;
	Y4259_gen_type [403] = Y4259_pgtype373;
	Y4259_gen_type [404] = Y4259_pgtype374;
	Y4259_gen_type [405] = Y4259_pgtype375;
	Y4259_gen_type [406] = Y4259_pgtype376;
	Y4259_gen_type [407] = Y4259_pgtype377;
	Y4259_gen_type [408] = Y4259_pgtype378;
	Y4259_gen_type [409] = Y4259_pgtype379;
	Y4259_gen_type [410] = Y4259_pgtype380;
	Y4259_gen_type [411] = Y4259_pgtype381;
	Y4259_gen_type [412] = Y4259_pgtype382;
	Y4259_gen_type [413] = Y4259_pgtype383;
	Y4259_gen_type [414] = Y4259_pgtype384;
	Y4259_gen_type [415] = Y4259_pgtype385;
	Y4259_gen_type [416] = Y4259_pgtype386;
	Y4259_gen_type [417] = Y4259_pgtype387;
	Y4259_gen_type [418] = Y4259_pgtype388;
	Y4259_gen_type [419] = Y4259_pgtype389;
	Y4259_gen_type [420] = Y4259_pgtype390;
	Y4259_gen_type [421] = Y4259_pgtype391;
	Y4259_gen_type [422] = Y4259_pgtype392;
	Y4259_gen_type [423] = Y4259_pgtype393;
	Y4259_gen_type [424] = Y4259_pgtype394;
	Y4259_gen_type [425] = Y4259_pgtype395;
	Y4259_gen_type [426] = Y4259_pgtype396;
	Y4259_gen_type [427] = Y4259_pgtype397;
	Y4259_gen_type [428] = Y4259_pgtype398;
	Y4259_gen_type [429] = Y4259_pgtype399;
	Y4259_gen_type [430] = Y4259_pgtype400;
	Y4259_gen_type [431] = Y4259_pgtype401;
	Y4259_gen_type [432] = Y4259_pgtype402;
	Y4259_gen_type [433] = Y4259_pgtype403;
	Y4259_gen_type [434] = Y4259_pgtype404;
	Y4259_gen_type [435] = Y4259_pgtype405;
	Y4259_gen_type [436] = Y4259_pgtype406;
	Y4259_gen_type [437] = Y4259_pgtype407;
	Y4259_gen_type [438] = Y4259_pgtype408;
	Y4259_gen_type [439] = Y4259_pgtype409;
	Y4259_gen_type [440] = Y4259_pgtype410;
	Y4259_gen_type [441] = Y4259_pgtype411;
	Y4259_gen_type [442] = Y4259_pgtype412;
	Y4259_gen_type [443] = Y4259_pgtype413;
	Y4259_gen_type [444] = Y4259_pgtype414;
	Y4259_gen_type [445] = Y4259_pgtype415;
	Y4259_gen_type [446] = Y4259_pgtype416;
	Y4259_gen_type [447] = Y4259_pgtype417;
	Y4259_gen_type [448] = Y4259_pgtype418;
	Y4259_gen_type [449] = Y4259_pgtype419;
	Y4259_gen_type [450] = Y4259_pgtype420;
	Y4259_gen_type [451] = Y4259_pgtype421;
	Y4259_gen_type [452] = Y4259_pgtype422;
	Y4259_gen_type [453] = Y4259_pgtype423;
	Y4259_gen_type [454] = Y4259_pgtype424;
	Y4259_gen_type [455] = Y4259_pgtype425;
	Y4259_gen_type [456] = Y4259_pgtype426;
	Y4259_gen_type [457] = Y4259_pgtype427;
	Y4259_gen_type [458] = Y4259_pgtype428;
	Y4259_gen_type [459] = Y4259_pgtype429;
	Y4259_gen_type [460] = Y4259_pgtype430;
	Y4259_gen_type [461] = Y4259_pgtype431;
	Y4259_gen_type [462] = Y4259_pgtype432;
	Y4259_gen_type [463] = Y4259_pgtype433;
	Y4259_gen_type [464] = Y4259_pgtype434;
	Y4259_gen_type [465] = Y4259_pgtype435;
	Y4259_gen_type [466] = Y4259_pgtype436;
	Y4259_gen_type [467] = Y4259_pgtype437;
	Y4259_gen_type [468] = Y4259_pgtype438;
	Y4259_gen_type [469] = Y4259_pgtype439;
	Y4259_gen_type [470] = Y4259_pgtype440;
	Y4259_gen_type [471] = Y4259_pgtype441;
	Y4259_gen_type [472] = Y4259_pgtype442;
	Y4259_gen_type [473] = Y4259_pgtype443;
	Y4259_gen_type [474] = Y4259_pgtype444;
	Y4259_gen_type [475] = Y4259_pgtype445;
	Y4259_gen_type [476] = Y4259_pgtype446;
	Y4259_gen_type [477] = Y4259_pgtype447;
	Y4259_gen_type [478] = Y4259_pgtype448;
	Y4259_gen_type [479] = Y4259_pgtype449;
	Y4259_gen_type [480] = Y4259_pgtype450;
	Y4259_gen_type [481] = Y4259_pgtype451;
	Y4259_gen_type [482] = Y4259_pgtype452;
	Y4259_gen_type [483] = Y4259_pgtype453;
	Y4259_gen_type [484] = Y4259_pgtype454;
	Y4259_gen_type [485] = Y4259_pgtype455;
	Y4259_gen_type [486] = Y4259_pgtype456;
	Y4259_gen_type [487] = Y4259_pgtype457;
	Y4259_gen_type [488] = Y4259_pgtype458;
	Y4259_gen_type [489] = Y4259_pgtype459;
	Y4259_gen_type [490] = Y4259_pgtype460;
	Y4259_gen_type [491] = Y4259_pgtype461;
	Y4259_gen_type [492] = Y4259_pgtype462;
	Y4259_gen_type [493] = Y4259_pgtype463;
	Y4259_gen_type [497] = Y4259_pgtype464;
	Y4259_gen_type [498] = Y4259_pgtype465;
	Y4259_gen_type [499] = Y4259_pgtype466;
	Y4259_gen_type [500] = Y4259_pgtype467;
	Y4259_gen_type [501] = Y4259_pgtype468;
	Y4259_gen_type [502] = Y4259_pgtype469;
	Y4259_gen_type [503] = Y4259_pgtype470;
	Y4259_gen_type [504] = Y4259_pgtype471;
	Y4259_gen_type [505] = Y4259_pgtype472;
	Y4259_gen_type [506] = Y4259_pgtype473;
	Y4259_gen_type [507] = Y4259_pgtype474;
	Y4259_gen_type [508] = Y4259_pgtype475;
	Y4259_gen_type [509] = Y4259_pgtype476;
	Y4259_gen_type [510] = Y4259_pgtype477;
	Y4259_gen_type [511] = Y4259_pgtype478;
	Y4259_gen_type [512] = Y4259_pgtype479;
	Y4259_gen_type [513] = Y4259_pgtype480;
	Y4259_gen_type [514] = Y4259_pgtype481;
	Y4259_gen_type [515] = Y4259_pgtype482;
	Y4259_gen_type [516] = Y4259_pgtype483;
	Y4259_gen_type [517] = Y4259_pgtype484;
	Y4259_gen_type [518] = Y4259_pgtype485;
	Y4259_gen_type [519] = Y4259_pgtype486;
	Y4259_gen_type [520] = Y4259_pgtype487;
	Y4259_gen_type [521] = Y4259_pgtype488;
	Y4259_gen_type [549] = Y4259_pgtype489;
	Y4259_gen_type [550] = Y4259_pgtype490;
	Y4259_gen_type [551] = Y4259_pgtype491;
	Y4259_gen_type [552] = Y4259_pgtype492;
	Y4259_gen_type [553] = Y4259_pgtype493;
	Y4259_gen_type [554] = Y4259_pgtype494;
	Y4259_gen_type [555] = Y4259_pgtype495;
	Y4259_gen_type [556] = Y4259_pgtype496;
	Y4259_gen_type [557] = Y4259_pgtype497;
	Y4259_gen_type [558] = Y4259_pgtype498;
	Y4259_gen_type [559] = Y4259_pgtype499;
	Y4259_gen_type [560] = Y4259_pgtype500;
	Y4259_gen_type [618] = Y4259_pgtype501;
	Y4259_gen_type [619] = Y4259_pgtype502;
	Y4259_gen_type [620] = Y4259_pgtype503;
	Y4259_gen_type [629] = Y4259_pgtype504;
	Y4259_gen_type [630] = Y4259_pgtype505;
	Y4259_gen_type [631] = Y4259_pgtype506;
	Y4259_gen_type [682] = Y4259_pgtype507;
	Y4259_gen_type [765] = Y4259_pgtype508;
	Y4259_gen_type [766] = Y4259_pgtype509;
	Y4259_gen_type [767] = Y4259_pgtype510;
	Y4259_gen_type [768] = Y4259_pgtype511;
	Y4259_gen_type [769] = Y4259_pgtype512;
	Y4259_gen_type [770] = Y4259_pgtype513;
	Y4259_gen_type [771] = Y4259_pgtype514;
	Y4259_gen_type [804] = Y4259_pgtype515;
	Y4259_gen_type [806] = Y4259_pgtype516;
	Y4259_gen_type [807] = Y4259_pgtype517;
	Y4259_gen_type [822] = Y4259_pgtype518;
	Y4259_gen_type [823] = Y4259_pgtype519;
	Y4259_gen_type [852] = Y4259_pgtype520;
	Y4259_gen_type [863] = Y4259_pgtype521;
	Y4259_gen_type [869] = Y4259_pgtype522;
	Y4259_gen_type [870] = Y4259_pgtype523;
	Y4259_gen_type [871] = Y4259_pgtype524;
	Y4259_gen_type [879] = Y4259_pgtype525;
	Y4259_gen_type [880] = Y4259_pgtype526;
	Y4259_gen_type [881] = Y4259_pgtype527;
	Y4259_gen_type [882] = Y4259_pgtype528;
	Y4259_gen_type [883] = Y4259_pgtype529;
	Y4259_gen_type [884] = Y4259_pgtype530;
	Y4259_gen_type [885] = Y4259_pgtype531;
	Y4259_gen_type [886] = Y4259_pgtype532;
	Y4259_gen_type [887] = Y4259_pgtype533;
	Y4259_gen_type [888] = Y4259_pgtype534;
	Y4259_gen_type [889] = Y4259_pgtype535;
	Y4259_gen_type [890] = Y4259_pgtype536;
	Y4259_gen_type [891] = Y4259_pgtype537;
	Y4259_gen_type [892] = Y4259_pgtype538;
	Y4259_gen_type [893] = Y4259_pgtype539;
	Y4259_gen_type [894] = Y4259_pgtype540;
	Y4259_gen_type [895] = Y4259_pgtype541;
	Y4259_gen_type [896] = Y4259_pgtype542;
	Y4259_gen_type [897] = Y4259_pgtype543;
	Y4259_gen_type [898] = Y4259_pgtype544;
	Y4259_gen_type [899] = Y4259_pgtype545;
	Y4259_gen_type [900] = Y4259_pgtype546;
	Y4259_gen_type [901] = Y4259_pgtype547;
	Y4259_gen_type [902] = Y4259_pgtype548;
	Y4259_gen_type [903] = Y4259_pgtype549;
	Y4259_gen_type [904] = Y4259_pgtype550;
	Y4259_gen_type [905] = Y4259_pgtype551;
	Y4259_gen_type [906] = Y4259_pgtype552;
	Y4259_gen_type [907] = Y4259_pgtype553;
	Y4259_gen_type [908] = Y4259_pgtype554;
	Y4259_gen_type [909] = Y4259_pgtype555;
	Y4259_gen_type [910] = Y4259_pgtype556;
	Y4259_gen_type [911] = Y4259_pgtype557;
	Y4259_gen_type [912] = Y4259_pgtype558;
	Y4259_gen_type [913] = Y4259_pgtype559;
	Y4259_gen_type [914] = Y4259_pgtype560;
	Y4259_gen_type [915] = Y4259_pgtype561;
	Y4259_gen_type [916] = Y4259_pgtype562;
	Y4259_gen_type [917] = Y4259_pgtype563;
	Y4259_gen_type [918] = Y4259_pgtype564;
	Y4259_gen_type [919] = Y4259_pgtype565;
	Y4259_gen_type [920] = Y4259_pgtype566;
	Y4259_gen_type [921] = Y4259_pgtype567;
	Y4259_gen_type [922] = Y4259_pgtype568;
	Y4259_gen_type [924] = Y4259_pgtype569;
	Y4259_gen_type [925] = Y4259_pgtype570;
	Y4259_gen_type [927] = Y4259_pgtype571;
	Y4259_gen_type [928] = Y4259_pgtype572;
	Y4259_gen_type [937] = Y4259_pgtype573;
	Y4259_gen_type [938] = Y4259_pgtype574;
	Y4259_gen_type [939] = Y4259_pgtype575;
	Y4259_gen_type [940] = Y4259_pgtype576;
	Y4259_gen_type [945] = Y4259_pgtype577;
	Y4259_gen_type [946] = Y4259_pgtype578;
	Y4259_gen_type [1204] = Y4259_pgtype579;
	Y4259_gen_type [1311] = Y4259_pgtype580;
	Y4259_gen_type [1388] = Y4259_pgtype581;
	Y4259_gen_type [1393] = Y4259_pgtype582;
	Y4259_gen_type [1395] = Y4259_pgtype583;
	Y4259_gen_type [1396] = Y4259_pgtype584;
	Y4259_gen_type [1397] = Y4259_pgtype585;
	Y4259[12] = 1081;
	Y4259[13] = 1085;
	{long i; for (i = 260; i < 262; i++) Y4259[i] = 1033;};
	Y4259[274] = 1012;
	Y4259[347] = 0;
	Y4259[371] = 1098;
	Y4259[372] = 1071;
	Y4259[389] = 24;
	Y4259[390] = 1021;
	{long i; for (i = 391; i < 393; i++) Y4259[i] = 1033;};
	Y4259[468] = 1021;
	Y4259[469] = 1024;
	{long i; for (i = 497; i < 522; i++) Y4259[i] = 1071;};
	{long i; for (i = 618; i < 621; i++) Y4259[i] = 1024;};
	{long i; for (i = 629; i < 632; i++) Y4259[i] = 943;};
	Y4259[682] = 0;
	{long i; for (i = 765; i < 768; i++) Y4259[i] = 1021;};
	{long i; for (i = 768; i < 772; i++) Y4259[i] = 1024;};
	Y4259[807] = 1184;
	{long i; for (i = 822; i < 824; i++) Y4259[i] = 1175;};
	Y4259[852] = 1082;
	Y4259[863] = 1175;
	{long i; for (i = 869; i < 872; i++) Y4259[i] = 1184;};
	{long i; for (i = 879; i < 923; i++) Y4259[i] = 1193;};
	Y4259[924] = 1170;
	Y4259[925] = 1167;
	{long i; for (i = 927; i < 929; i++) Y4259[i] = 1168;};
	{long i; for (i = 937; i < 941; i++) Y4259[i] = 1189;};
	{long i; for (i = 945; i < 947; i++) Y4259[i] = 1184;};
	Y4259[1204] = 1024;
	Y4259[1311] = 1033;
	Y4259[1388] = 1193;
	Y4259[1393] = 1193;
	Y4259[1395] = 1193;
	Y4259[1396] = 1184;
	Y4259[1397] = 1193;
}

char *(*R4304[1179])();
void R4304_init () {
	R4304[0] = (char *(*)()) F535_4844;
	{long i; for (i = 41; i < 43; i++) R4304[i] = (char *(*)()) F576_4892_4304_2;}
	R4304[43] = (char *(*)()) F578_4941;
	R4304[44] = (char *(*)()) F579_4941_4304_2;
	R4304[45] = (char *(*)()) F580_4941_4304_2;
	R4304[46] = (char *(*)()) F581_4941_4304_2;
	R4304[47] = (char *(*)()) F582_4941_4304_2;
	R4304[48] = (char *(*)()) F583_4941_4304_2;
	R4304[49] = (char *(*)()) F584_4941_4304_2;
	R4304[50] = (char *(*)()) F585_4941_4304_2;
	R4304[51] = (char *(*)()) F586_4941_4304_2;
	R4304[52] = (char *(*)()) F587_4941_4304_2;
	R4304[53] = (char *(*)()) F588_4941_4304_2;
	R4304[54] = (char *(*)()) F589_4941_4304_2;
	R4304[55] = (char *(*)()) F581_4941_4304_2;
	R4304[104] = (char *(*)()) F591_5015;
	R4304[105] = (char *(*)()) F598_5015_4304_2;
	R4304[106] = (char *(*)()) F596_5015_4304_2;
	R4304[107] = (char *(*)()) F591_5015;
	R4304[108] = (char *(*)()) F598_5015_4304_2;
	R4304[109] = (char *(*)()) F596_5015_4304_2;
	R4304[110] = (char *(*)()) F591_5015;
	R4304[118] = (char *(*)()) F653_5268;
	R4304[120] = (char *(*)()) F655_5326;
	R4304[121] = (char *(*)()) F656_5326;
	R4304[122] = (char *(*)()) F657_5326_4304_2;
	R4304[123] = (char *(*)()) F658_5326_4304_2;
	R4304[124] = (char *(*)()) F659_5326_4304_2;
	R4304[125] = (char *(*)()) F660_5326_4304_2;
	R4304[126] = (char *(*)()) F655_5326;
	R4304[127] = (char *(*)()) F657_5326_4304_2;
	R4304[128] = (char *(*)()) F655_5326;
	R4304[129] = (char *(*)()) F664_5459;
	R4304[130] = (char *(*)()) F665_5459_4304_2;
	R4304[131] = (char *(*)()) F666_5459_4304_2;
	R4304[132] = (char *(*)()) F667_5459_4304_2;
	R4304[133] = (char *(*)()) F668_5459_4304_2;
	R4304[134] = (char *(*)()) F669_5459_4304_2;
	R4304[135] = (char *(*)()) F670_5459_4304_2;
	R4304[136] = (char *(*)()) F671_5459_4304_2;
	R4304[137] = (char *(*)()) F672_5459_4304_2;
	R4304[138] = (char *(*)()) F673_5459_4304_2;
	R4304[139] = (char *(*)()) F674_5459_4304_2;
	R4304[140] = (char *(*)()) F675_5459_4304_2;
	R4304[141] = (char *(*)()) F664_5459;
	R4304[142] = (char *(*)()) F671_5459_4304_2;
	R4304[143] = (char *(*)()) F669_5459_4304_2;
	R4304[144] = (char *(*)()) F664_5459;
	R4304[145] = (char *(*)()) F671_5459_4304_2;
	R4304[148] = (char *(*)()) F664_5459;
	R4304[149] = (char *(*)()) F671_5459_4304_2;
	R4304[150] = (char *(*)()) F664_5459;
	R4304[151] = (char *(*)()) F671_5459_4304_2;
	{long i; for (i = 152; i < 154; i++) R4304[i] = (char *(*)()) F664_5459;}
	R4304[170] = (char *(*)()) F363_4741;
	R4304[172] = (char *(*)()) F707_5991_4304_2;
	R4304[173] = (char *(*)()) F708_6005_4304_2;
	{long i; for (i = 278; i < 280; i++) R4304[i] = (char *(*)()) F664_5459;}
	{long i; for (i = 281; i < 303; i++) R4304[i] = (char *(*)()) F664_5459;}
	{long i; for (i = 400; i < 402; i++) R4304[i] = (char *(*)()) F365_4741_4304_2;}
	{long i; for (i = 410; i < 413; i++) R4304[i] = (char *(*)()) F664_5459;}
	R4304[548] = (char *(*)()) F1081_9557_4304_2;
	{long i; for (i = 551; i < 553; i++) R4304[i] = (char *(*)()) F1084_9725_4304_2;}
	R4304[604] = (char *(*)()) F591_5015;
	R4304[633] = (char *(*)()) F664_5459;
	R4304[644] = (char *(*)()) F591_5015;
	{long i; for (i = 651; i < 653; i++) R4304[i] = (char *(*)()) F591_5015;}
	R4304[661] = (char *(*)()) F1196_11022;
	{long i; for (i = 663; i < 665; i++) R4304[i] = (char *(*)()) F1197_11040;}
	{long i; for (i = 666; i < 668; i++) R4304[i] = (char *(*)()) F591_5015;}
	{long i; for (i = 669; i < 675; i++) R4304[i] = (char *(*)()) F591_5015;}
	{long i; for (i = 675; i < 680; i++) R4304[i] = (char *(*)()) F1210_11189;}
	{long i; for (i = 681; i < 687; i++) R4304[i] = (char *(*)()) F1210_11189;}
	{long i; for (i = 687; i < 690; i++) R4304[i] = (char *(*)()) F1222_11487;}
	{long i; for (i = 691; i < 694; i++) R4304[i] = (char *(*)()) F1222_11487;}
	R4304[695] = (char *(*)()) F1222_11487;
	R4304[697] = (char *(*)()) F1222_11487;
	{long i; for (i = 699; i < 704; i++) R4304[i] = (char *(*)()) F1222_11487;}
	{long i; for (i = 705; i < 707; i++) R4304[i] = (char *(*)()) F591_5015;}
	{long i; for (i = 708; i < 710; i++) R4304[i] = (char *(*)()) F591_5015;}
	{long i; for (i = 719; i < 722; i++) R4304[i] = (char *(*)()) F591_5015;}
	{long i; for (i = 726; i < 728; i++) R4304[i] = (char *(*)()) F591_5015;}
	R4304[985] = (char *(*)()) F365_4741_4304_2;
	R4304[1092] = (char *(*)()) F708_6005_4304_2;
	R4304[1169] = (char *(*)()) F1210_11189;
	R4304[1174] = (char *(*)()) F591_5015;
	{long i; for (i = 1176; i < 1178; i++) R4304[i] = (char *(*)()) F591_5015;}
	R4304[1178] = (char *(*)()) F1222_11487;
}
static EIF_BOOLEAN F576_4892_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F576_4892(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F579_4941_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F579_4941(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F580_4941_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F580_4941(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F581_4941_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F581_4941(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F582_4941_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F582_4941(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F583_4941_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F583_4941(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F584_4941_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F584_4941(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F585_4941_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F585_4941(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F586_4941_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F586_4941(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F587_4941_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F587_4941(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F588_4941_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F588_4941(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F589_4941_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F589_4941(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F598_5015_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F598_5015(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F596_5015_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F596_5015(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F657_5326_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F657_5326(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F658_5326_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F658_5326(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F659_5326_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F659_5326(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F660_5326_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F660_5326(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F665_5459_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F665_5459(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F666_5459_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F666_5459(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F667_5459_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F667_5459(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F668_5459_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F668_5459(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F669_5459_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F669_5459(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F670_5459_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F670_5459(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F671_5459_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F671_5459(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F672_5459_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F672_5459(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F673_5459_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F673_5459(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F674_5459_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F674_5459(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F675_5459_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F675_5459(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F707_5991_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F707_5991(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F708_6005_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F708_6005(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F365_4741_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F365_4741(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1081_9557_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1081_9557(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F1084_9725_4304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1084_9725(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4305[1365])();
void R4305_init () {
	{long i; for (i = 0; i < 2; i++) R4305[i] = (char *(*)()) F348_4616;}
	R4305[186] = (char *(*)()) F483_4817;
	{long i; for (i = 227; i < 229; i++) R4305[i] = (char *(*)()) F489_4817;}
	R4305[229] = (char *(*)()) F483_4817;
	R4305[230] = (char *(*)()) F484_4817;
	R4305[231] = (char *(*)()) F486_4817;
	R4305[232] = (char *(*)()) F487_4817;
	R4305[233] = (char *(*)()) F488_4817;
	R4305[234] = (char *(*)()) F490_4817;
	R4305[235] = (char *(*)()) F491_4817;
	R4305[236] = (char *(*)()) F489_4817;
	R4305[237] = (char *(*)()) F492_4817;
	R4305[238] = (char *(*)()) F493_4817;
	R4305[239] = (char *(*)()) F485_4817;
	R4305[240] = (char *(*)()) F494_4817;
	R4305[241] = (char *(*)()) F487_4817;
	R4305[290] = (char *(*)()) F483_4817;
	R4305[291] = (char *(*)()) F489_4817;
	R4305[292] = (char *(*)()) F490_4817;
	R4305[293] = (char *(*)()) F483_4817;
	R4305[294] = (char *(*)()) F489_4817;
	R4305[295] = (char *(*)()) F490_4817;
	R4305[296] = (char *(*)()) F483_4817;
	{long i; for (i = 306; i < 308; i++) R4305[i] = (char *(*)()) F483_4817;}
	{long i; for (i = 308; i < 311; i++) R4305[i] = (char *(*)()) F489_4817;}
	R4305[311] = (char *(*)()) F492_4817;
	R4305[312] = (char *(*)()) F483_4817;
	R4305[313] = (char *(*)()) F489_4817;
	{long i; for (i = 314; i < 316; i++) R4305[i] = (char *(*)()) F483_4817;}
	R4305[316] = (char *(*)()) F484_4817;
	R4305[317] = (char *(*)()) F486_4817;
	R4305[318] = (char *(*)()) F487_4817;
	R4305[319] = (char *(*)()) F488_4817;
	R4305[320] = (char *(*)()) F490_4817;
	R4305[321] = (char *(*)()) F491_4817;
	R4305[322] = (char *(*)()) F489_4817;
	R4305[323] = (char *(*)()) F492_4817;
	R4305[324] = (char *(*)()) F493_4817;
	R4305[325] = (char *(*)()) F485_4817;
	R4305[326] = (char *(*)()) F494_4817;
	R4305[327] = (char *(*)()) F483_4817;
	R4305[328] = (char *(*)()) F489_4817;
	R4305[329] = (char *(*)()) F490_4817;
	R4305[330] = (char *(*)()) F483_4817;
	R4305[331] = (char *(*)()) F489_4817;
	R4305[334] = (char *(*)()) F483_4817;
	R4305[335] = (char *(*)()) F489_4817;
	R4305[336] = (char *(*)()) F483_4817;
	R4305[337] = (char *(*)()) F489_4817;
	{long i; for (i = 338; i < 340; i++) R4305[i] = (char *(*)()) F483_4817;}
	R4305[356] = (char *(*)()) F705_5969;
	{long i; for (i = 358; i < 360; i++) R4305[i] = (char *(*)()) F480_4795;}
	{long i; for (i = 464; i < 466; i++) R4305[i] = (char *(*)()) F483_4817;}
	{long i; for (i = 467; i < 489; i++) R4305[i] = (char *(*)()) F483_4817;}
	{long i; for (i = 586; i < 588; i++) R4305[i] = (char *(*)()) F485_4817;}
	{long i; for (i = 596; i < 599; i++) R4305[i] = (char *(*)()) F483_4817;}
	R4305[734] = (char *(*)()) F493_4817;
	{long i; for (i = 737; i < 739; i++) R4305[i] = (char *(*)()) F485_4817;}
	R4305[790] = (char *(*)()) F483_4817;
	R4305[819] = (char *(*)()) F483_4817;
	R4305[830] = (char *(*)()) F483_4817;
	{long i; for (i = 837; i < 839; i++) R4305[i] = (char *(*)()) F483_4817;}
	R4305[847] = (char *(*)()) F483_4817;
	{long i; for (i = 852; i < 854; i++) R4305[i] = (char *(*)()) F483_4817;}
	{long i; for (i = 855; i < 861; i++) R4305[i] = (char *(*)()) F483_4817;}
	{long i; for (i = 861; i < 866; i++) R4305[i] = (char *(*)()) F1210_11190;}
	{long i; for (i = 867; i < 876; i++) R4305[i] = (char *(*)()) F1210_11190;}
	{long i; for (i = 877; i < 880; i++) R4305[i] = (char *(*)()) F1210_11190;}
	R4305[881] = (char *(*)()) F1210_11190;
	R4305[883] = (char *(*)()) F1210_11190;
	{long i; for (i = 885; i < 890; i++) R4305[i] = (char *(*)()) F1210_11190;}
	{long i; for (i = 891; i < 893; i++) R4305[i] = (char *(*)()) F483_4817;}
	{long i; for (i = 894; i < 896; i++) R4305[i] = (char *(*)()) F483_4817;}
	{long i; for (i = 905; i < 908; i++) R4305[i] = (char *(*)()) F483_4817;}
	{long i; for (i = 912; i < 914; i++) R4305[i] = (char *(*)()) F483_4817;}
	R4305[1171] = (char *(*)()) F1520_16537;
	R4305[1278] = (char *(*)()) F480_4795;
	R4305[1355] = (char *(*)()) F1210_11190;
	R4305[1360] = (char *(*)()) F483_4817;
	{long i; for (i = 1362; i < 1364; i++) R4305[i] = (char *(*)()) F483_4817;}
	R4305[1364] = (char *(*)()) F1210_11190;
}

char *(*R4309[1365])();
void R4309_init () {
	{long i; for (i = 0; i < 2; i++) R4309[i] = (char *(*)()) F336_4588;}
	R4309[186] = (char *(*)()) F336_4588;
	{long i; for (i = 227; i < 229; i++) R4309[i] = (char *(*)()) F342_4588;}
	R4309[229] = (char *(*)()) F336_4588;
	R4309[230] = (char *(*)()) F337_4588;
	R4309[231] = (char *(*)()) F339_4588;
	R4309[232] = (char *(*)()) F340_4588;
	R4309[233] = (char *(*)()) F341_4588;
	R4309[234] = (char *(*)()) F343_4588;
	R4309[235] = (char *(*)()) F344_4588;
	R4309[236] = (char *(*)()) F342_4588;
	R4309[237] = (char *(*)()) F345_4588;
	R4309[238] = (char *(*)()) F346_4588;
	R4309[239] = (char *(*)()) F338_4588;
	R4309[240] = (char *(*)()) F347_4588;
	R4309[241] = (char *(*)()) F340_4588;
	R4309[290] = (char *(*)()) F336_4588;
	R4309[291] = (char *(*)()) F342_4588;
	R4309[292] = (char *(*)()) F343_4588;
	R4309[293] = (char *(*)()) F336_4588;
	R4309[294] = (char *(*)()) F342_4588;
	R4309[295] = (char *(*)()) F343_4588;
	R4309[296] = (char *(*)()) F336_4588;
	R4309[304] = (char *(*)()) F336_4588;
	{long i; for (i = 306; i < 308; i++) R4309[i] = (char *(*)()) F336_4588;}
	{long i; for (i = 308; i < 311; i++) R4309[i] = (char *(*)()) F342_4588;}
	R4309[311] = (char *(*)()) F345_4588;
	R4309[312] = (char *(*)()) F336_4588;
	R4309[313] = (char *(*)()) F342_4588;
	{long i; for (i = 314; i < 316; i++) R4309[i] = (char *(*)()) F336_4588;}
	R4309[316] = (char *(*)()) F337_4588;
	R4309[317] = (char *(*)()) F339_4588;
	R4309[318] = (char *(*)()) F340_4588;
	R4309[319] = (char *(*)()) F341_4588;
	R4309[320] = (char *(*)()) F343_4588;
	R4309[321] = (char *(*)()) F344_4588;
	R4309[322] = (char *(*)()) F342_4588;
	R4309[323] = (char *(*)()) F345_4588;
	R4309[324] = (char *(*)()) F346_4588;
	R4309[325] = (char *(*)()) F338_4588;
	R4309[326] = (char *(*)()) F347_4588;
	R4309[327] = (char *(*)()) F336_4588;
	R4309[328] = (char *(*)()) F342_4588;
	R4309[329] = (char *(*)()) F343_4588;
	R4309[330] = (char *(*)()) F336_4588;
	R4309[331] = (char *(*)()) F342_4588;
	R4309[334] = (char *(*)()) F336_4588;
	R4309[335] = (char *(*)()) F342_4588;
	R4309[336] = (char *(*)()) F336_4588;
	R4309[337] = (char *(*)()) F342_4588;
	{long i; for (i = 338; i < 340; i++) R4309[i] = (char *(*)()) F336_4588;}
	R4309[356] = (char *(*)()) F336_4588;
	{long i; for (i = 358; i < 360; i++) R4309[i] = (char *(*)()) F342_4588;}
	{long i; for (i = 464; i < 466; i++) R4309[i] = (char *(*)()) F336_4588;}
	{long i; for (i = 467; i < 489; i++) R4309[i] = (char *(*)()) F336_4588;}
	{long i; for (i = 586; i < 588; i++) R4309[i] = (char *(*)()) F338_4588;}
	{long i; for (i = 596; i < 599; i++) R4309[i] = (char *(*)()) F336_4588;}
	R4309[734] = (char *(*)()) F346_4588;
	{long i; for (i = 737; i < 739; i++) R4309[i] = (char *(*)()) F338_4588;}
	R4309[790] = (char *(*)()) F336_4588;
	R4309[819] = (char *(*)()) F336_4588;
	R4309[830] = (char *(*)()) F336_4588;
	{long i; for (i = 837; i < 839; i++) R4309[i] = (char *(*)()) F336_4588;}
	R4309[847] = (char *(*)()) F336_4588;
	{long i; for (i = 849; i < 851; i++) R4309[i] = (char *(*)()) F336_4588;}
	{long i; for (i = 852; i < 854; i++) R4309[i] = (char *(*)()) F336_4588;}
	{long i; for (i = 855; i < 866; i++) R4309[i] = (char *(*)()) F336_4588;}
	{long i; for (i = 867; i < 876; i++) R4309[i] = (char *(*)()) F336_4588;}
	{long i; for (i = 877; i < 880; i++) R4309[i] = (char *(*)()) F336_4588;}
	R4309[881] = (char *(*)()) F336_4588;
	R4309[883] = (char *(*)()) F336_4588;
	{long i; for (i = 885; i < 890; i++) R4309[i] = (char *(*)()) F336_4588;}
	{long i; for (i = 891; i < 893; i++) R4309[i] = (char *(*)()) F336_4588;}
	{long i; for (i = 894; i < 896; i++) R4309[i] = (char *(*)()) F336_4588;}
	{long i; for (i = 905; i < 908; i++) R4309[i] = (char *(*)()) F336_4588;}
	{long i; for (i = 912; i < 914; i++) R4309[i] = (char *(*)()) F336_4588;}
	R4309[1171] = (char *(*)()) F338_4588;
	R4309[1278] = (char *(*)()) F342_4588;
	R4309[1355] = (char *(*)()) F336_4588;
	R4309[1360] = (char *(*)()) F336_4588;
	{long i; for (i = 1362; i < 1365; i++) R4309[i] = (char *(*)()) F336_4588;}
}

char *(*R4311[1365])();
void R4311_init () {
	{long i; for (i = 0; i < 2; i++) R4311[i] = (char *(*)()) F348_4643;}
	R4311[186] = (char *(*)()) F535_4864;
	{long i; for (i = 227; i < 229; i++) R4311[i] = (char *(*)()) F576_4911;}
	R4311[229] = (char *(*)()) F578_4985;
	R4311[230] = (char *(*)()) F579_4985;
	R4311[231] = (char *(*)()) F580_4985;
	R4311[232] = (char *(*)()) F581_4985;
	R4311[233] = (char *(*)()) F582_4985;
	R4311[234] = (char *(*)()) F583_4985;
	R4311[235] = (char *(*)()) F584_4985;
	R4311[236] = (char *(*)()) F585_4985;
	R4311[237] = (char *(*)()) F586_4985;
	R4311[238] = (char *(*)()) F587_4985;
	R4311[239] = (char *(*)()) F588_4985;
	R4311[240] = (char *(*)()) F589_4985;
	R4311[241] = (char *(*)()) F581_4985;
	R4311[290] = (char *(*)()) F363_4756;
	R4311[291] = (char *(*)()) F369_4756;
	R4311[292] = (char *(*)()) F370_4756;
	R4311[293] = (char *(*)()) F642_5115;
	R4311[294] = (char *(*)()) F643_5115;
	R4311[295] = (char *(*)()) F644_5115;
	R4311[296] = (char *(*)()) F645_5129;
	R4311[304] = (char *(*)()) F653_5289;
	R4311[306] = (char *(*)()) F655_5372;
	R4311[307] = (char *(*)()) F656_5372;
	R4311[308] = (char *(*)()) F657_5372;
	R4311[309] = (char *(*)()) F658_5372;
	R4311[310] = (char *(*)()) F659_5372;
	R4311[311] = (char *(*)()) F660_5372;
	R4311[312] = (char *(*)()) F655_5372;
	R4311[313] = (char *(*)()) F657_5372;
	R4311[314] = (char *(*)()) F655_5372;
	R4311[315] = (char *(*)()) F363_4756;
	R4311[316] = (char *(*)()) F364_4756;
	R4311[317] = (char *(*)()) F366_4756;
	R4311[318] = (char *(*)()) F367_4756;
	R4311[319] = (char *(*)()) F368_4756;
	R4311[320] = (char *(*)()) F370_4756;
	R4311[321] = (char *(*)()) F371_4756;
	R4311[322] = (char *(*)()) F369_4756;
	R4311[323] = (char *(*)()) F372_4756;
	R4311[324] = (char *(*)()) F373_4756;
	R4311[325] = (char *(*)()) F365_4756;
	R4311[326] = (char *(*)()) F374_4756;
	R4311[327] = (char *(*)()) F676_5518;
	R4311[328] = (char *(*)()) F677_5518;
	R4311[329] = (char *(*)()) F678_5518;
	R4311[330] = (char *(*)()) F363_4756;
	R4311[331] = (char *(*)()) F369_4756;
	R4311[334] = (char *(*)()) F363_4756;
	R4311[335] = (char *(*)()) F369_4756;
	R4311[336] = (char *(*)()) F363_4756;
	R4311[337] = (char *(*)()) F369_4756;
	{long i; for (i = 338; i < 340; i++) R4311[i] = (char *(*)()) F363_4756;}
	R4311[356] = (char *(*)()) F363_4756;
	{long i; for (i = 358; i < 360; i++) R4311[i] = (char *(*)()) F482_4810;}
	{long i; for (i = 464; i < 466; i++) R4311[i] = (char *(*)()) F363_4756;}
	{long i; for (i = 467; i < 489; i++) R4311[i] = (char *(*)()) F363_4756;}
	{long i; for (i = 586; i < 588; i++) R4311[i] = (char *(*)()) F365_4756;}
	{long i; for (i = 596; i < 599; i++) R4311[i] = (char *(*)()) F363_4756;}
	R4311[734] = (char *(*)()) F1083_9681;
	{long i; for (i = 737; i < 739; i++) R4311[i] = (char *(*)()) F1086_9846;}
	R4311[790] = (char *(*)()) F363_4756;
	R4311[819] = (char *(*)()) F363_4756;
	R4311[830] = (char *(*)()) F363_4756;
	{long i; for (i = 837; i < 839; i++) R4311[i] = (char *(*)()) F363_4756;}
	R4311[847] = (char *(*)()) F363_4756;
	{long i; for (i = 849; i < 851; i++) R4311[i] = (char *(*)()) F1197_11068;}
	{long i; for (i = 852; i < 854; i++) R4311[i] = (char *(*)()) F363_4756;}
	{long i; for (i = 855; i < 861; i++) R4311[i] = (char *(*)()) F363_4756;}
	{long i; for (i = 861; i < 866; i++) R4311[i] = (char *(*)()) F1210_11199;}
	{long i; for (i = 867; i < 876; i++) R4311[i] = (char *(*)()) F1210_11199;}
	{long i; for (i = 877; i < 880; i++) R4311[i] = (char *(*)()) F1210_11199;}
	R4311[881] = (char *(*)()) F1210_11199;
	R4311[883] = (char *(*)()) F1210_11199;
	{long i; for (i = 885; i < 890; i++) R4311[i] = (char *(*)()) F1210_11199;}
	{long i; for (i = 891; i < 893; i++) R4311[i] = (char *(*)()) F363_4756;}
	{long i; for (i = 894; i < 896; i++) R4311[i] = (char *(*)()) F363_4756;}
	{long i; for (i = 905; i < 908; i++) R4311[i] = (char *(*)()) F363_4756;}
	{long i; for (i = 912; i < 914; i++) R4311[i] = (char *(*)()) F363_4756;}
	R4311[1171] = (char *(*)()) F365_4756;
	R4311[1278] = (char *(*)()) F482_4810;
	R4311[1355] = (char *(*)()) F1210_11199;
	R4311[1360] = (char *(*)()) F363_4756;
	{long i; for (i = 1362; i < 1364; i++) R4311[i] = (char *(*)()) F363_4756;}
	R4311[1364] = (char *(*)()) F1210_11199;
}


#ifdef __cplusplus
}
#endif
