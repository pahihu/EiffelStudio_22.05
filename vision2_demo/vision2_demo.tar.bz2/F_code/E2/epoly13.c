#include "epoly13.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4458[1074])();
void R4458_init () {
	R4458[0] = (char *(*)()) F639_5088;
	R4458[1] = (char *(*)()) F640_5088;
	R4458[2] = (char *(*)()) F641_5088;
	R4458[3] = (char *(*)()) F639_5088;
	R4458[4] = (char *(*)()) F640_5088;
	R4458[5] = (char *(*)()) F641_5088;
	R4458[6] = (char *(*)()) F639_5088;
	R4458[25] = (char *(*)()) F664_5483;
	R4458[26] = (char *(*)()) F665_5483;
	R4458[27] = (char *(*)()) F666_5483;
	R4458[28] = (char *(*)()) F667_5483;
	R4458[29] = (char *(*)()) F668_5483;
	R4458[30] = (char *(*)()) F669_5483;
	R4458[31] = (char *(*)()) F670_5483;
	R4458[32] = (char *(*)()) F671_5483;
	R4458[33] = (char *(*)()) F672_5483;
	R4458[34] = (char *(*)()) F673_5483;
	R4458[35] = (char *(*)()) F674_5483;
	R4458[36] = (char *(*)()) F675_5483;
	R4458[37] = (char *(*)()) F664_5483;
	R4458[38] = (char *(*)()) F671_5483;
	R4458[39] = (char *(*)()) F669_5483;
	R4458[40] = (char *(*)()) F664_5483;
	R4458[41] = (char *(*)()) F671_5483;
	R4458[44] = (char *(*)()) F664_5483;
	R4458[45] = (char *(*)()) F671_5483;
	R4458[46] = (char *(*)()) F664_5483;
	R4458[47] = (char *(*)()) F671_5483;
	{long i; for (i = 48; i < 50; i++) R4458[i] = (char *(*)()) F664_5483;}
	{long i; for (i = 174; i < 176; i++) R4458[i] = (char *(*)()) F664_5483;}
	{long i; for (i = 177; i < 199; i++) R4458[i] = (char *(*)()) F664_5483;}
	{long i; for (i = 306; i < 309; i++) R4458[i] = (char *(*)()) F664_5483;}
	R4458[500] = (char *(*)()) F1120_10302;
	R4458[529] = (char *(*)()) F664_5483;
	R4458[540] = (char *(*)()) F1120_10302;
	{long i; for (i = 547; i < 549; i++) R4458[i] = (char *(*)()) F1120_10302;}
	R4458[557] = (char *(*)()) F1196_11033;
	{long i; for (i = 562; i < 564; i++) R4458[i] = (char *(*)()) F1120_10302;}
	{long i; for (i = 565; i < 571; i++) R4458[i] = (char *(*)()) F1120_10302;}
	{long i; for (i = 601; i < 603; i++) R4458[i] = (char *(*)()) F1120_10302;}
	{long i; for (i = 604; i < 606; i++) R4458[i] = (char *(*)()) F1120_10302;}
	{long i; for (i = 615; i < 618; i++) R4458[i] = (char *(*)()) F1120_10302;}
	{long i; for (i = 622; i < 624; i++) R4458[i] = (char *(*)()) F1120_10302;}
	R4458[1070] = (char *(*)()) F1120_10302;
	{long i; for (i = 1072; i < 1074; i++) R4458[i] = (char *(*)()) F1120_10302;}
}

char *(*R4459[1179])();
void R4459_init () {
	R4459[0] = (char *(*)()) F495_4819;
	{long i; for (i = 41; i < 43; i++) R4459[i] = (char *(*)()) F502_4819;}
	R4459[118] = (char *(*)()) F495_4819;
	R4459[129] = (char *(*)()) F495_4819;
	R4459[130] = (char *(*)()) F496_4819;
	R4459[131] = (char *(*)()) F497_4819;
	R4459[132] = (char *(*)()) F498_4819;
	R4459[133] = (char *(*)()) F499_4819;
	R4459[134] = (char *(*)()) F500_4819;
	R4459[135] = (char *(*)()) F501_4819;
	R4459[136] = (char *(*)()) F502_4819;
	R4459[137] = (char *(*)()) F503_4819;
	R4459[138] = (char *(*)()) F505_4819;
	R4459[139] = (char *(*)()) F504_4819;
	R4459[140] = (char *(*)()) F506_4819;
	R4459[141] = (char *(*)()) F495_4819;
	R4459[142] = (char *(*)()) F502_4819;
	R4459[143] = (char *(*)()) F500_4819;
	R4459[144] = (char *(*)()) F495_4819;
	R4459[145] = (char *(*)()) F502_4819;
	R4459[148] = (char *(*)()) F495_4819;
	R4459[149] = (char *(*)()) F502_4819;
	R4459[150] = (char *(*)()) F495_4819;
	R4459[151] = (char *(*)()) F502_4819;
	{long i; for (i = 152; i < 154; i++) R4459[i] = (char *(*)()) F495_4819;}
	{long i; for (i = 278; i < 280; i++) R4459[i] = (char *(*)()) F495_4819;}
	{long i; for (i = 281; i < 303; i++) R4459[i] = (char *(*)()) F495_4819;}
	{long i; for (i = 410; i < 413; i++) R4459[i] = (char *(*)()) F495_4819;}
	R4459[548] = (char *(*)()) F505_4819;
	{long i; for (i = 551; i < 553; i++) R4459[i] = (char *(*)()) F504_4819;}
	R4459[604] = (char *(*)()) F1120_10297;
	R4459[633] = (char *(*)()) F495_4819;
	R4459[644] = (char *(*)()) F1120_10297;
	{long i; for (i = 651; i < 653; i++) R4459[i] = (char *(*)()) F1120_10297;}
	R4459[661] = (char *(*)()) F1196_11024;
	{long i; for (i = 663; i < 665; i++) R4459[i] = (char *(*)()) F1197_11044;}
	{long i; for (i = 666; i < 668; i++) R4459[i] = (char *(*)()) F1120_10297;}
	{long i; for (i = 669; i < 675; i++) R4459[i] = (char *(*)()) F1120_10297;}
	{long i; for (i = 675; i < 680; i++) R4459[i] = (char *(*)()) F1210_11192;}
	{long i; for (i = 681; i < 690; i++) R4459[i] = (char *(*)()) F1210_11192;}
	{long i; for (i = 691; i < 694; i++) R4459[i] = (char *(*)()) F1210_11192;}
	R4459[695] = (char *(*)()) F1210_11192;
	R4459[697] = (char *(*)()) F1210_11192;
	{long i; for (i = 699; i < 704; i++) R4459[i] = (char *(*)()) F1210_11192;}
	{long i; for (i = 705; i < 707; i++) R4459[i] = (char *(*)()) F1120_10297;}
	{long i; for (i = 708; i < 710; i++) R4459[i] = (char *(*)()) F1120_10297;}
	{long i; for (i = 719; i < 722; i++) R4459[i] = (char *(*)()) F1120_10297;}
	{long i; for (i = 726; i < 728; i++) R4459[i] = (char *(*)()) F1120_10297;}
	R4459[1169] = (char *(*)()) F1210_11192;
	R4459[1174] = (char *(*)()) F1120_10297;
	{long i; for (i = 1176; i < 1178; i++) R4459[i] = (char *(*)()) F1120_10297;}
	R4459[1178] = (char *(*)()) F1210_11192;
}

char *(*R4460[921])();
void R4460_init () {
	R4460[0] = (char *(*)()) F707_5992;
	R4460[1] = (char *(*)()) F708_6006;
	R4460[920] = (char *(*)()) F708_6006;
}

char *(*R4462[1178])();
void R4462_init () {
	R4462[0] = (char *(*)()) F535_4846;
	{long i; for (i = 41; i < 43; i++) R4462[i] = (char *(*)()) F576_4896;}
	R4462[43] = (char *(*)()) F578_4945;
	R4462[44] = (char *(*)()) F579_4945;
	R4462[45] = (char *(*)()) F580_4945;
	R4462[46] = (char *(*)()) F581_4945;
	R4462[47] = (char *(*)()) F582_4945;
	R4462[48] = (char *(*)()) F583_4945;
	R4462[49] = (char *(*)()) F584_4945;
	R4462[50] = (char *(*)()) F585_4945;
	R4462[51] = (char *(*)()) F586_4945;
	R4462[52] = (char *(*)()) F587_4945;
	R4462[53] = (char *(*)()) F588_4945;
	R4462[54] = (char *(*)()) F589_4945;
	R4462[55] = (char *(*)()) F581_4945;
	R4462[104] = (char *(*)()) F639_5072;
	R4462[105] = (char *(*)()) F640_5072;
	R4462[106] = (char *(*)()) F641_5072;
	R4462[107] = (char *(*)()) F639_5072;
	R4462[108] = (char *(*)()) F640_5072;
	R4462[109] = (char *(*)()) F641_5072;
	R4462[110] = (char *(*)()) F639_5072;
	R4462[118] = (char *(*)()) F653_5271;
	R4462[120] = (char *(*)()) F655_5334;
	R4462[121] = (char *(*)()) F656_5334;
	R4462[122] = (char *(*)()) F657_5334;
	R4462[123] = (char *(*)()) F658_5334;
	R4462[124] = (char *(*)()) F659_5334;
	R4462[125] = (char *(*)()) F660_5334;
	R4462[126] = (char *(*)()) F655_5334;
	R4462[127] = (char *(*)()) F657_5334;
	R4462[128] = (char *(*)()) F655_5334;
	R4462[129] = (char *(*)()) F664_5468;
	R4462[130] = (char *(*)()) F665_5468;
	R4462[131] = (char *(*)()) F666_5468;
	R4462[132] = (char *(*)()) F667_5468;
	R4462[133] = (char *(*)()) F668_5468;
	R4462[134] = (char *(*)()) F669_5468;
	R4462[135] = (char *(*)()) F670_5468;
	R4462[136] = (char *(*)()) F671_5468;
	R4462[137] = (char *(*)()) F672_5468;
	R4462[138] = (char *(*)()) F673_5468;
	R4462[139] = (char *(*)()) F674_5468;
	R4462[140] = (char *(*)()) F675_5468;
	R4462[141] = (char *(*)()) F664_5468;
	R4462[142] = (char *(*)()) F671_5468;
	R4462[143] = (char *(*)()) F669_5468;
	R4462[144] = (char *(*)()) F664_5468;
	R4462[145] = (char *(*)()) F671_5468;
	R4462[148] = (char *(*)()) F664_5468;
	R4462[149] = (char *(*)()) F671_5468;
	R4462[150] = (char *(*)()) F664_5468;
	R4462[151] = (char *(*)()) F671_5468;
	{long i; for (i = 152; i < 154; i++) R4462[i] = (char *(*)()) F664_5468;}
	{long i; for (i = 278; i < 280; i++) R4462[i] = (char *(*)()) F664_5468;}
	{long i; for (i = 281; i < 303; i++) R4462[i] = (char *(*)()) F664_5468;}
	{long i; for (i = 400; i < 402; i++) R4462[i] = (char *(*)()) F934_7274;}
	{long i; for (i = 410; i < 413; i++) R4462[i] = (char *(*)()) F664_5468;}
	R4462[548] = (char *(*)()) F1081_9544;
	{long i; for (i = 551; i < 553; i++) R4462[i] = (char *(*)()) F1084_9712;}
	R4462[604] = (char *(*)()) F1120_10295;
	R4462[633] = (char *(*)()) F664_5468;
	R4462[644] = (char *(*)()) F1120_10295;
	{long i; for (i = 651; i < 653; i++) R4462[i] = (char *(*)()) F1120_10295;}
	R4462[661] = (char *(*)()) F1196_11023;
	{long i; for (i = 666; i < 668; i++) R4462[i] = (char *(*)()) F1120_10295;}
	{long i; for (i = 669; i < 675; i++) R4462[i] = (char *(*)()) F1120_10295;}
	{long i; for (i = 705; i < 707; i++) R4462[i] = (char *(*)()) F1120_10295;}
	{long i; for (i = 708; i < 710; i++) R4462[i] = (char *(*)()) F1120_10295;}
	{long i; for (i = 719; i < 722; i++) R4462[i] = (char *(*)()) F1120_10295;}
	{long i; for (i = 726; i < 728; i++) R4462[i] = (char *(*)()) F1120_10295;}
	R4462[985] = (char *(*)()) F1520_16505;
	R4462[1174] = (char *(*)()) F1120_10295;
	{long i; for (i = 1176; i < 1178; i++) R4462[i] = (char *(*)()) F1120_10295;}
}

char *(*R4463[634])();
void R4463_init () {
	R4463[0] = (char *(*)()) F535_4847;
	{long i; for (i = 41; i < 43; i++) R4463[i] = (char *(*)()) F576_4895;}
	R4463[43] = (char *(*)()) F578_4946;
	R4463[44] = (char *(*)()) F579_4946;
	R4463[45] = (char *(*)()) F580_4946;
	R4463[46] = (char *(*)()) F581_4946;
	R4463[47] = (char *(*)()) F582_4946;
	R4463[48] = (char *(*)()) F583_4946;
	R4463[49] = (char *(*)()) F584_4946;
	R4463[50] = (char *(*)()) F585_4946;
	R4463[51] = (char *(*)()) F586_4946;
	R4463[52] = (char *(*)()) F587_4946;
	R4463[53] = (char *(*)()) F588_4946;
	R4463[54] = (char *(*)()) F589_4946;
	R4463[55] = (char *(*)()) F581_4946;
	R4463[118] = (char *(*)()) F653_5272;
	R4463[129] = (char *(*)()) F664_5469;
	R4463[130] = (char *(*)()) F665_5469;
	R4463[131] = (char *(*)()) F666_5469;
	R4463[132] = (char *(*)()) F667_5469;
	R4463[133] = (char *(*)()) F668_5469;
	R4463[134] = (char *(*)()) F669_5469;
	R4463[135] = (char *(*)()) F670_5469;
	R4463[136] = (char *(*)()) F671_5469;
	R4463[137] = (char *(*)()) F672_5469;
	R4463[138] = (char *(*)()) F673_5469;
	R4463[139] = (char *(*)()) F674_5469;
	R4463[140] = (char *(*)()) F675_5469;
	R4463[141] = (char *(*)()) F664_5469;
	R4463[142] = (char *(*)()) F671_5469;
	R4463[143] = (char *(*)()) F669_5469;
	R4463[144] = (char *(*)()) F664_5469;
	R4463[145] = (char *(*)()) F671_5469;
	R4463[148] = (char *(*)()) F664_5469;
	R4463[149] = (char *(*)()) F671_5469;
	R4463[150] = (char *(*)()) F664_5469;
	R4463[151] = (char *(*)()) F671_5469;
	{long i; for (i = 152; i < 154; i++) R4463[i] = (char *(*)()) F664_5469;}
	{long i; for (i = 278; i < 280; i++) R4463[i] = (char *(*)()) F664_5469;}
	{long i; for (i = 281; i < 303; i++) R4463[i] = (char *(*)()) F664_5469;}
	{long i; for (i = 410; i < 413; i++) R4463[i] = (char *(*)()) F664_5469;}
	R4463[548] = (char *(*)()) F1081_9543;
	{long i; for (i = 551; i < 553; i++) R4463[i] = (char *(*)()) F1084_9711;}
	R4463[633] = (char *(*)()) F664_5469;
}

char *(*R4467[634])();
void R4467_init () {
	R4467[0] = (char *(*)()) F507_4823;
	{long i; for (i = 41; i < 43; i++) R4467[i] = (char *(*)()) F514_4823;}
	R4467[43] = (char *(*)()) F507_4823;
	R4467[44] = (char *(*)()) F508_4823;
	R4467[45] = (char *(*)()) F509_4823;
	R4467[46] = (char *(*)()) F510_4823;
	R4467[47] = (char *(*)()) F511_4823;
	R4467[48] = (char *(*)()) F512_4823;
	R4467[49] = (char *(*)()) F513_4823;
	R4467[50] = (char *(*)()) F514_4823;
	R4467[51] = (char *(*)()) F515_4823;
	R4467[52] = (char *(*)()) F517_4823;
	R4467[53] = (char *(*)()) F516_4823;
	R4467[54] = (char *(*)()) F518_4823;
	R4467[55] = (char *(*)()) F510_4823;
	R4467[118] = (char *(*)()) F507_4823;
	R4467[129] = (char *(*)()) F507_4823;
	R4467[130] = (char *(*)()) F508_4823;
	R4467[131] = (char *(*)()) F509_4823;
	R4467[132] = (char *(*)()) F510_4823;
	R4467[133] = (char *(*)()) F511_4823;
	R4467[134] = (char *(*)()) F512_4823;
	R4467[135] = (char *(*)()) F513_4823;
	R4467[136] = (char *(*)()) F514_4823;
	R4467[137] = (char *(*)()) F515_4823;
	R4467[138] = (char *(*)()) F517_4823;
	R4467[139] = (char *(*)()) F516_4823;
	R4467[140] = (char *(*)()) F518_4823;
	R4467[141] = (char *(*)()) F507_4823;
	R4467[142] = (char *(*)()) F514_4823;
	R4467[143] = (char *(*)()) F512_4823;
	R4467[144] = (char *(*)()) F507_4823;
	R4467[145] = (char *(*)()) F514_4823;
	R4467[148] = (char *(*)()) F507_4823;
	R4467[149] = (char *(*)()) F514_4823;
	R4467[150] = (char *(*)()) F507_4823;
	R4467[151] = (char *(*)()) F514_4823;
	{long i; for (i = 152; i < 154; i++) R4467[i] = (char *(*)()) F507_4823;}
	{long i; for (i = 278; i < 280; i++) R4467[i] = (char *(*)()) F507_4823;}
	{long i; for (i = 281; i < 303; i++) R4467[i] = (char *(*)()) F507_4823;}
	{long i; for (i = 410; i < 413; i++) R4467[i] = (char *(*)()) F507_4823;}
	R4467[548] = (char *(*)()) F517_4823;
	{long i; for (i = 551; i < 553; i++) R4467[i] = (char *(*)()) F516_4823;}
	R4467[633] = (char *(*)()) F507_4823;
}

char *(*R4469[591])();
void R4469_init () {
	R4469[0] = (char *(*)()) F578_4976;
	R4469[1] = (char *(*)()) F579_4976;
	R4469[2] = (char *(*)()) F580_4976;
	R4469[3] = (char *(*)()) F581_4976;
	R4469[4] = (char *(*)()) F582_4976;
	R4469[5] = (char *(*)()) F583_4976;
	R4469[6] = (char *(*)()) F584_4976;
	R4469[7] = (char *(*)()) F585_4976;
	R4469[8] = (char *(*)()) F586_4976;
	R4469[9] = (char *(*)()) F587_4976;
	R4469[10] = (char *(*)()) F588_4976;
	R4469[11] = (char *(*)()) F589_4976;
	R4469[12] = (char *(*)()) F581_4976;
	R4469[75] = (char *(*)()) F653_5294;
	R4469[86] = (char *(*)()) F664_5495;
	R4469[87] = (char *(*)()) F665_5495;
	R4469[88] = (char *(*)()) F666_5495;
	R4469[89] = (char *(*)()) F667_5495;
	R4469[90] = (char *(*)()) F668_5495;
	R4469[91] = (char *(*)()) F669_5495;
	R4469[92] = (char *(*)()) F670_5495;
	R4469[93] = (char *(*)()) F671_5495;
	R4469[94] = (char *(*)()) F672_5495;
	R4469[95] = (char *(*)()) F673_5495;
	R4469[96] = (char *(*)()) F674_5495;
	R4469[97] = (char *(*)()) F675_5495;
	R4469[98] = (char *(*)()) F664_5495;
	R4469[99] = (char *(*)()) F671_5495;
	R4469[100] = (char *(*)()) F669_5495;
	R4469[101] = (char *(*)()) F664_5495;
	R4469[102] = (char *(*)()) F671_5495;
	R4469[105] = (char *(*)()) F664_5495;
	R4469[106] = (char *(*)()) F671_5495;
	R4469[107] = (char *(*)()) F664_5495;
	R4469[108] = (char *(*)()) F671_5495;
	{long i; for (i = 109; i < 111; i++) R4469[i] = (char *(*)()) F664_5495;}
	{long i; for (i = 235; i < 237; i++) R4469[i] = (char *(*)()) F664_5495;}
	{long i; for (i = 238; i < 260; i++) R4469[i] = (char *(*)()) F664_5495;}
	{long i; for (i = 367; i < 370; i++) R4469[i] = (char *(*)()) F664_5495;}
	R4469[505] = (char *(*)()) F1083_9671;
	{long i; for (i = 508; i < 510; i++) R4469[i] = (char *(*)()) F1086_9836;}
	R4469[590] = (char *(*)()) F664_5495;
}

char *(*R4471[1074])();
void R4471_init () {
	R4471[0] = (char *(*)()) F519_4830;
	R4471[1] = (char *(*)()) F527_4830_4471_4;
	R4471[2] = (char *(*)()) F525_4830_4471_4;
	R4471[3] = (char *(*)()) F642_5111;
	R4471[4] = (char *(*)()) F643_5111_4471_4;
	R4471[5] = (char *(*)()) F644_5111_4471_4;
	R4471[6] = (char *(*)()) F645_5128;
	R4471[25] = (char *(*)()) F664_5487;
	R4471[26] = (char *(*)()) F665_5487_4471_4;
	R4471[27] = (char *(*)()) F666_5487_4471_4;
	R4471[28] = (char *(*)()) F667_5487_4471_4;
	R4471[29] = (char *(*)()) F668_5487_4471_4;
	R4471[30] = (char *(*)()) F669_5487_4471_4;
	R4471[31] = (char *(*)()) F670_5487_4471_4;
	R4471[32] = (char *(*)()) F671_5487_4471_4;
	R4471[33] = (char *(*)()) F672_5487_4471_4;
	R4471[34] = (char *(*)()) F673_5487_4471_4;
	R4471[35] = (char *(*)()) F674_5487_4471_4;
	R4471[36] = (char *(*)()) F675_5487_4471_4;
	R4471[37] = (char *(*)()) F664_5487;
	R4471[38] = (char *(*)()) F671_5487_4471_4;
	R4471[39] = (char *(*)()) F669_5487_4471_4;
	R4471[40] = (char *(*)()) F664_5487;
	R4471[41] = (char *(*)()) F671_5487_4471_4;
	R4471[44] = (char *(*)()) F664_5487;
	R4471[45] = (char *(*)()) F671_5487_4471_4;
	R4471[46] = (char *(*)()) F664_5487;
	R4471[47] = (char *(*)()) F671_5487_4471_4;
	{long i; for (i = 48; i < 50; i++) R4471[i] = (char *(*)()) F664_5487;}
	{long i; for (i = 174; i < 176; i++) R4471[i] = (char *(*)()) F664_5487;}
	{long i; for (i = 177; i < 199; i++) R4471[i] = (char *(*)()) F664_5487;}
	{long i; for (i = 296; i < 298; i++) R4471[i] = (char *(*)()) F521_4830_4471_4;}
	{long i; for (i = 306; i < 309; i++) R4471[i] = (char *(*)()) F945_7859;}
	R4471[500] = (char *(*)()) F519_4830;
	R4471[529] = (char *(*)()) F664_5487;
	R4471[540] = (char *(*)()) F519_4830;
	{long i; for (i = 547; i < 549; i++) R4471[i] = (char *(*)()) F519_4830;}
	R4471[557] = (char *(*)()) F519_4830;
	{long i; for (i = 562; i < 564; i++) R4471[i] = (char *(*)()) F519_4830;}
	{long i; for (i = 565; i < 571; i++) R4471[i] = (char *(*)()) F519_4830;}
	{long i; for (i = 601; i < 603; i++) R4471[i] = (char *(*)()) F519_4830;}
	{long i; for (i = 604; i < 606; i++) R4471[i] = (char *(*)()) F519_4830;}
	{long i; for (i = 615; i < 618; i++) R4471[i] = (char *(*)()) F519_4830;}
	{long i; for (i = 622; i < 624; i++) R4471[i] = (char *(*)()) F519_4830;}
	R4471[881] = (char *(*)()) F521_4830_4471_4;
	R4471[1070] = (char *(*)()) F519_4830;
	{long i; for (i = 1072; i < 1074; i++) R4471[i] = (char *(*)()) F519_4830;}
}
static void F527_4830_4471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F527_4830(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F525_4830_4471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F525_4830(Current, *(EIF_BOOLEAN *)arg1);
}
static void F643_5111_4471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F643_5111(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F644_5111_4471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F644_5111(Current, *(EIF_BOOLEAN *)arg1);
}
static void F665_5487_4471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5487(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F666_5487_4471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5487(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F667_5487_4471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5487(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F668_5487_4471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5487(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F669_5487_4471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F669_5487(Current, *(EIF_BOOLEAN *)arg1);
}
static void F670_5487_4471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F670_5487(Current, *(EIF_REAL_64 *)arg1);
}
static void F671_5487_4471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F671_5487(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F672_5487_4471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F672_5487(Current, *(EIF_POINTER *)arg1);
}
static void F673_5487_4471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F673_5487(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F674_5487_4471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F674_5487(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F675_5487_4471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F675_5487(Current, *(EIF_REAL_32 *)arg1);
}
static void F521_4830_4471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F521_4830(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4472[558])();
void R4472_init () {
	R4472[0] = (char *(*)()) F591_5032;
	R4472[1] = (char *(*)()) F598_5032;
	R4472[2] = (char *(*)()) F596_5032;
	R4472[3] = (char *(*)()) F531_4837;
	R4472[4] = (char *(*)()) F532_4837;
	R4472[5] = (char *(*)()) F533_4837;
	R4472[6] = (char *(*)()) F531_4837;
	R4472[25] = (char *(*)()) F664_5494;
	R4472[26] = (char *(*)()) F665_5494;
	R4472[27] = (char *(*)()) F666_5494;
	R4472[28] = (char *(*)()) F667_5494;
	R4472[29] = (char *(*)()) F668_5494;
	R4472[30] = (char *(*)()) F669_5494;
	R4472[31] = (char *(*)()) F670_5494;
	R4472[32] = (char *(*)()) F671_5494;
	R4472[33] = (char *(*)()) F672_5494;
	R4472[34] = (char *(*)()) F673_5494;
	R4472[35] = (char *(*)()) F674_5494;
	R4472[36] = (char *(*)()) F675_5494;
	R4472[37] = (char *(*)()) F531_4837;
	R4472[38] = (char *(*)()) F532_4837;
	R4472[39] = (char *(*)()) F533_4837;
	R4472[40] = (char *(*)()) F664_5494;
	R4472[41] = (char *(*)()) F671_5494;
	R4472[44] = (char *(*)()) F681_5536;
	R4472[45] = (char *(*)()) F682_5536;
	R4472[46] = (char *(*)()) F681_5536;
	R4472[47] = (char *(*)()) F682_5536;
	{long i; for (i = 48; i < 50; i++) R4472[i] = (char *(*)()) F681_5536;}
	{long i; for (i = 174; i < 176; i++) R4472[i] = (char *(*)()) F681_5536;}
	{long i; for (i = 177; i < 199; i++) R4472[i] = (char *(*)()) F681_5536;}
	{long i; for (i = 306; i < 309; i++) R4472[i] = (char *(*)()) F945_7866;}
	R4472[529] = (char *(*)()) F681_5536;
	R4472[557] = (char *(*)()) F591_5032;
}

char *(*R4485[1137])();
void R4485_init () {
	{long i; for (i = 0; i < 2; i++) R4485[i] = (char *(*)()) F576_4890_4485_88;}
	R4485[2] = (char *(*)()) F578_4938;
	R4485[3] = (char *(*)()) F579_4938_4485_88;
	R4485[4] = (char *(*)()) F580_4938_4485_88;
	R4485[5] = (char *(*)()) F581_4938_4485_88;
	R4485[6] = (char *(*)()) F582_4938_4485_88;
	R4485[7] = (char *(*)()) F583_4938_4485_88;
	R4485[8] = (char *(*)()) F584_4938_4485_88;
	R4485[9] = (char *(*)()) F585_4938_4485_88;
	R4485[10] = (char *(*)()) F586_4938_4485_88;
	R4485[11] = (char *(*)()) F587_4938_4485_88;
	R4485[12] = (char *(*)()) F588_4938_4485_88;
	R4485[13] = (char *(*)()) F589_4938_4485_88;
	R4485[14] = (char *(*)()) F581_4938_4485_88;
	R4485[63] = (char *(*)()) F591_5017;
	R4485[64] = (char *(*)()) F598_5017_4485_88;
	R4485[65] = (char *(*)()) F596_5017_4485_88;
	R4485[66] = (char *(*)()) F591_5017;
	R4485[67] = (char *(*)()) F598_5017_4485_88;
	R4485[68] = (char *(*)()) F596_5017_4485_88;
	R4485[69] = (char *(*)()) F591_5017;
	R4485[79] = (char *(*)()) F655_5332;
	R4485[80] = (char *(*)()) F656_5332;
	R4485[81] = (char *(*)()) F657_5332_4485_88;
	R4485[82] = (char *(*)()) F658_5332_4485_88;
	R4485[83] = (char *(*)()) F659_5332_4485_88;
	R4485[84] = (char *(*)()) F660_5332_4485_88;
	R4485[85] = (char *(*)()) F655_5332;
	R4485[86] = (char *(*)()) F657_5332_4485_88;
	R4485[87] = (char *(*)()) F655_5332;
	R4485[88] = (char *(*)()) F664_5453;
	R4485[89] = (char *(*)()) F665_5453_4485_88;
	R4485[90] = (char *(*)()) F666_5453_4485_88;
	R4485[91] = (char *(*)()) F667_5453_4485_88;
	R4485[92] = (char *(*)()) F668_5453_4485_88;
	R4485[93] = (char *(*)()) F669_5453_4485_88;
	R4485[94] = (char *(*)()) F670_5453_4485_88;
	R4485[95] = (char *(*)()) F671_5453_4485_88;
	R4485[96] = (char *(*)()) F672_5453_4485_88;
	R4485[97] = (char *(*)()) F673_5453_4485_88;
	R4485[98] = (char *(*)()) F674_5453_4485_88;
	R4485[99] = (char *(*)()) F675_5453_4485_88;
	R4485[100] = (char *(*)()) F664_5453;
	R4485[101] = (char *(*)()) F671_5453_4485_88;
	R4485[102] = (char *(*)()) F669_5453_4485_88;
	R4485[103] = (char *(*)()) F664_5453;
	R4485[104] = (char *(*)()) F671_5453_4485_88;
	R4485[107] = (char *(*)()) F664_5453;
	R4485[108] = (char *(*)()) F671_5453_4485_88;
	R4485[109] = (char *(*)()) F664_5453;
	R4485[110] = (char *(*)()) F671_5453_4485_88;
	{long i; for (i = 111; i < 113; i++) R4485[i] = (char *(*)()) F664_5453;}
	{long i; for (i = 237; i < 239; i++) R4485[i] = (char *(*)()) F664_5453;}
	{long i; for (i = 240; i < 262; i++) R4485[i] = (char *(*)()) F664_5453;}
	R4485[289] = (char *(*)()) F865_6812;
	R4485[290] = (char *(*)()) F866_6812_4485_88;
	R4485[291] = (char *(*)()) F867_6812_4485_88;
	R4485[292] = (char *(*)()) F868_6812_4485_88;
	R4485[293] = (char *(*)()) F869_6812_4485_88;
	R4485[294] = (char *(*)()) F870_6812_4485_88;
	R4485[295] = (char *(*)()) F871_6812_4485_88;
	R4485[296] = (char *(*)()) F872_6812_4485_88;
	R4485[297] = (char *(*)()) F873_6812_4485_88;
	R4485[298] = (char *(*)()) F874_6812_4485_88;
	R4485[299] = (char *(*)()) F875_6812_4485_88;
	R4485[300] = (char *(*)()) F876_6812_4485_88;
	{long i; for (i = 369; i < 372; i++) R4485[i] = (char *(*)()) F664_5453;}
	R4485[422] = (char *(*)()) F998_8160;
	R4485[506] = (char *(*)()) F1082_9582_4485_88;
	R4485[507] = (char *(*)()) F1083_9605_4485_88;
	R4485[509] = (char *(*)()) F1085_9747_4485_88;
	{long i; for (i = 510; i < 512; i++) R4485[i] = (char *(*)()) F1086_9769_4485_88;}
	R4485[563] = (char *(*)()) F1120_10291;
	R4485[592] = (char *(*)()) F664_5453;
	R4485[603] = (char *(*)()) F1120_10291;
	{long i; for (i = 610; i < 612; i++) R4485[i] = (char *(*)()) F1120_10291;}
	R4485[620] = (char *(*)()) F591_5017;
	{long i; for (i = 625; i < 627; i++) R4485[i] = (char *(*)()) F1120_10291;}
	{long i; for (i = 628; i < 634; i++) R4485[i] = (char *(*)()) F1120_10291;}
	{long i; for (i = 664; i < 666; i++) R4485[i] = (char *(*)()) F1120_10291;}
	{long i; for (i = 667; i < 669; i++) R4485[i] = (char *(*)()) F1120_10291;}
	{long i; for (i = 678; i < 681; i++) R4485[i] = (char *(*)()) F1120_10291;}
	{long i; for (i = 685; i < 687; i++) R4485[i] = (char *(*)()) F1120_10291;}
	R4485[1133] = (char *(*)()) F1120_10291;
	{long i; for (i = 1135; i < 1137; i++) R4485[i] = (char *(*)()) F1120_10291;}
}
static EIF_REFERENCE F576_4890_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F576_4890(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F579_4938_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F579_4938(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_4938_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F580_4938(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1009, 0x00).id, 1009, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F581_4938_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F581_4938(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1012, 0x00).id, 1012, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F582_4938_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F582_4938(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1003, 0x00).id, 1003, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F583_4938_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F583_4938(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F584_4938_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F584_4938(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1018, 0x00).id, 1018, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F585_4938_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F585_4938(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F586_4938_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F586_4938(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_4938_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F587_4938(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_4938_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F588_4938(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_4938_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F589_4938(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F598_5017_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F598_5017(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F596_5017_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F596_5017(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F657_5332_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F657_5332(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_5332_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5332(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5332_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F659_5332(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5332_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F660_5332(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5453_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F665_5453(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5453_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F666_5453(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1009, 0x00).id, 1009, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5453_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F667_5453(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1012, 0x00).id, 1012, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5453_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F668_5453(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1003, 0x00).id, 1003, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_5453_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F669_5453(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_5453_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F670_5453(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1018, 0x00).id, 1018, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F671_5453_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F671_5453(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F672_5453_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F672_5453(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F673_5453_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F673_5453(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F674_5453_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F674_5453(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F675_5453_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F675_5453(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F866_6812_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F866_6812(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F867_6812_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F867_6812(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1009, 0x00).id, 1009, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F868_6812_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F868_6812(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1012, 0x00).id, 1012, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F869_6812_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F869_6812(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1003, 0x00).id, 1003, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F870_6812_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F870_6812(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F871_6812_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F871_6812(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1018, 0x00).id, 1018, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F872_6812_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F872_6812(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F873_6812_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F873_6812(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F874_6812_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F874_6812(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F875_6812_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F875_6812(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F876_6812_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F876_6812(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1082_9582_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1082_9582(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1083_9605_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1083_9605(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1085_9747_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1085_9747(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1086_9769_4485_88 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1086_9769(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4486[1137])();
void R4486_init () {
	{long i; for (i = 0; i < 2; i++) R4486[i] = (char *(*)()) F576_4887;}
	R4486[2] = (char *(*)()) F578_4943;
	R4486[3] = (char *(*)()) F579_4943;
	R4486[4] = (char *(*)()) F580_4943;
	R4486[5] = (char *(*)()) F581_4943;
	R4486[6] = (char *(*)()) F582_4943;
	R4486[7] = (char *(*)()) F583_4943;
	R4486[8] = (char *(*)()) F584_4943;
	R4486[9] = (char *(*)()) F585_4943;
	R4486[10] = (char *(*)()) F586_4943;
	R4486[11] = (char *(*)()) F587_4943;
	R4486[12] = (char *(*)()) F588_4943;
	R4486[13] = (char *(*)()) F589_4943;
	R4486[14] = (char *(*)()) F581_4943;
	R4486[63] = (char *(*)()) F591_5020;
	R4486[64] = (char *(*)()) F598_5020;
	R4486[65] = (char *(*)()) F596_5020;
	R4486[66] = (char *(*)()) F591_5020;
	R4486[67] = (char *(*)()) F598_5020;
	R4486[68] = (char *(*)()) F596_5020;
	R4486[69] = (char *(*)()) F591_5020;
	R4486[79] = (char *(*)()) F655_5337;
	R4486[80] = (char *(*)()) F656_5337;
	R4486[81] = (char *(*)()) F657_5337;
	R4486[82] = (char *(*)()) F658_5337;
	R4486[83] = (char *(*)()) F659_5337;
	R4486[84] = (char *(*)()) F660_5337;
	R4486[85] = (char *(*)()) F655_5337;
	R4486[86] = (char *(*)()) F657_5337;
	R4486[87] = (char *(*)()) F655_5337;
	R4486[88] = (char *(*)()) F591_5020;
	R4486[89] = (char *(*)()) F592_5020;
	R4486[90] = (char *(*)()) F593_5020;
	R4486[91] = (char *(*)()) F594_5020;
	R4486[92] = (char *(*)()) F595_5020;
	R4486[93] = (char *(*)()) F596_5020;
	R4486[94] = (char *(*)()) F597_5020;
	R4486[95] = (char *(*)()) F598_5020;
	R4486[96] = (char *(*)()) F599_5020;
	R4486[97] = (char *(*)()) F600_5020;
	R4486[98] = (char *(*)()) F601_5020;
	R4486[99] = (char *(*)()) F602_5020;
	R4486[100] = (char *(*)()) F591_5020;
	R4486[101] = (char *(*)()) F598_5020;
	R4486[102] = (char *(*)()) F596_5020;
	R4486[103] = (char *(*)()) F591_5020;
	R4486[104] = (char *(*)()) F598_5020;
	R4486[107] = (char *(*)()) F591_5020;
	R4486[108] = (char *(*)()) F598_5020;
	R4486[109] = (char *(*)()) F591_5020;
	R4486[110] = (char *(*)()) F598_5020;
	{long i; for (i = 111; i < 113; i++) R4486[i] = (char *(*)()) F591_5020;}
	{long i; for (i = 237; i < 239; i++) R4486[i] = (char *(*)()) F591_5020;}
	{long i; for (i = 240; i < 262; i++) R4486[i] = (char *(*)()) F591_5020;}
	R4486[289] = (char *(*)()) F865_6820;
	R4486[290] = (char *(*)()) F866_6820;
	R4486[291] = (char *(*)()) F867_6820;
	R4486[292] = (char *(*)()) F868_6820;
	R4486[293] = (char *(*)()) F869_6820;
	R4486[294] = (char *(*)()) F870_6820;
	R4486[295] = (char *(*)()) F871_6820;
	R4486[296] = (char *(*)()) F872_6820;
	R4486[297] = (char *(*)()) F873_6820;
	R4486[298] = (char *(*)()) F874_6820;
	R4486[299] = (char *(*)()) F875_6820;
	R4486[300] = (char *(*)()) F876_6820;
	{long i; for (i = 369; i < 372; i++) R4486[i] = (char *(*)()) F591_5020;}
	R4486[422] = (char *(*)()) F998_8190;
	{long i; for (i = 506; i < 508; i++) R4486[i] = (char *(*)()) F1081_9546;}
	{long i; for (i = 509; i < 512; i++) R4486[i] = (char *(*)()) F1084_9714;}
	R4486[563] = (char *(*)()) F591_5020;
	R4486[592] = (char *(*)()) F591_5020;
	R4486[603] = (char *(*)()) F591_5020;
	{long i; for (i = 610; i < 612; i++) R4486[i] = (char *(*)()) F591_5020;}
	R4486[620] = (char *(*)()) F591_5020;
	{long i; for (i = 625; i < 627; i++) R4486[i] = (char *(*)()) F591_5020;}
	{long i; for (i = 628; i < 634; i++) R4486[i] = (char *(*)()) F591_5020;}
	{long i; for (i = 664; i < 666; i++) R4486[i] = (char *(*)()) F591_5020;}
	{long i; for (i = 667; i < 669; i++) R4486[i] = (char *(*)()) F591_5020;}
	{long i; for (i = 678; i < 681; i++) R4486[i] = (char *(*)()) F591_5020;}
	{long i; for (i = 685; i < 687; i++) R4486[i] = (char *(*)()) F591_5020;}
	R4486[1133] = (char *(*)()) F591_5020;
	{long i; for (i = 1135; i < 1137; i++) R4486[i] = (char *(*)()) F591_5020;}
}


#ifdef __cplusplus
}
#endif
