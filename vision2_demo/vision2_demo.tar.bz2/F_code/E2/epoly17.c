#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

EIF_TYPE_INDEX *Y4741_gen_type [1];
EIF_TYPE_INDEX Y4741 [1];
void Y4741_init (void)
{
	egc_routines_types [4741] = Y4741;
	egc_routines_gen_types [4741] = Y4741_gen_type;
	egc_routines_offset [4741] = 652;
	Y4741[0] = 1033;
}

long O4742[907];
void O4742_init () {
	O4742[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 902; i < 904; i++) O4742[i] = + _LNGOFF_0_0_0_0_;}
	O4742[904] = + _LNGOFF_0_0_0_1_;
	O4742[905] = + _LNGOFF_5_1_0_1_;
	O4742[906] = + _LNGOFF_2_0_0_1_;
}

long O4756[9];
void O4756_init () {
	{long i; for (i = 0; i < 2; i++) O4756[i] = 0;}
	O4756[2] = + _LNGOFF_5_3_0_0_;
	O4756[3] = + _LNGOFF_4_3_0_1_;
	O4756[4] = + _LNGOFF_4_3_0_0_;
	O4756[5] = + _PTROFF_5_3_0_7_0_0_;
	O4756[6] = 0;
	O4756[7] = + _LNGOFF_5_4_0_0_;
	O4756[8] = 0;
}

long O4765[9];
void O4765_init () {
	O4765[0] = + _LNGOFF_7_3_0_0_;
	O4765[1] = + _LNGOFF_6_3_0_0_;
	O4765[2] = + _LNGOFF_5_3_0_1_;
	O4765[3] = + _LNGOFF_4_3_0_2_;
	O4765[4] = + _LNGOFF_4_3_0_1_;
	O4765[5] = + _LNGOFF_5_3_0_0_;
	O4765[6] = + _LNGOFF_7_4_0_0_;
	O4765[7] = + _LNGOFF_5_4_0_1_;
	O4765[8] = + _LNGOFF_9_3_0_0_;
}

long O4792[9];
void O4792_init () {
	{long i; for (i = 0; i < 2; i++) O4792[i] =  + _REFACS_1_;}
	{long i; for (i = 2; i < 6; i++) O4792[i] = 0;}
	O4792[6] =  + _REFACS_1_;
	O4792[7] = 0;
	O4792[8] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y4792_pgtype0[] = {864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4792_pgtype1[] = {864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4792_pgtype2[] = {871,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4792_pgtype3[] = {871,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4792_pgtype4[] = {871,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4792_pgtype5[] = {872,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4792_pgtype6[] = {864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4792_pgtype7[] = {871,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4792_pgtype8[] = {864,0,0xFFFF};
EIF_TYPE_INDEX *Y4792_gen_type [9];
EIF_TYPE_INDEX Y4792 [9];
void Y4792_init (void)
{
	egc_routines_types [4792] = Y4792;
	egc_routines_gen_types [4792] = Y4792_gen_type;
	egc_routines_offset [4792] = 654;
	Y4792_gen_type [0] = Y4792_pgtype0;
	Y4792_gen_type [1] = Y4792_pgtype1;
	Y4792_gen_type [2] = Y4792_pgtype2;
	Y4792_gen_type [3] = Y4792_pgtype3;
	Y4792_gen_type [4] = Y4792_pgtype4;
	Y4792_gen_type [5] = Y4792_pgtype5;
	Y4792_gen_type [6] = Y4792_pgtype6;
	Y4792_gen_type [7] = Y4792_pgtype7;
	Y4792_gen_type [8] = Y4792_pgtype8;
	{long i; for (i = 0; i < 2; i++) Y4792[i] = 864;};
	{long i; for (i = 2; i < 5; i++) Y4792[i] = 871;};
	Y4792[5] = 872;
	Y4792[6] = 864;
	Y4792[7] = 871;
	Y4792[8] = 864;
}

long O4793[9];
void O4793_init () {
	{long i; for (i = 0; i < 2; i++) O4793[i] =  + _REFACS_2_;}
	{long i; for (i = 2; i < 6; i++) O4793[i] =  + _REFACS_1_;}
	O4793[6] =  + _REFACS_2_;
	O4793[7] =  + _REFACS_1_;
	O4793[8] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y4793_pgtype0[] = {864,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4793_pgtype1[] = {871,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4793_pgtype2[] = {864,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4793_pgtype3[] = {865,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4793_pgtype4[] = {871,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4793_pgtype5[] = {864,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4793_pgtype6[] = {864,1077,0xFFFF};
static EIF_TYPE_INDEX Y4793_pgtype7[] = {864,1077,0xFFFF};
static EIF_TYPE_INDEX Y4793_pgtype8[] = {864,1085,0xFFFF};
EIF_TYPE_INDEX *Y4793_gen_type [9];
EIF_TYPE_INDEX Y4793 [9];
void Y4793_init (void)
{
	egc_routines_types [4793] = Y4793;
	egc_routines_gen_types [4793] = Y4793_gen_type;
	egc_routines_offset [4793] = 654;
	Y4793_gen_type [0] = Y4793_pgtype0;
	Y4793_gen_type [1] = Y4793_pgtype1;
	Y4793_gen_type [2] = Y4793_pgtype2;
	Y4793_gen_type [3] = Y4793_pgtype3;
	Y4793_gen_type [4] = Y4793_pgtype4;
	Y4793_gen_type [5] = Y4793_pgtype5;
	Y4793_gen_type [6] = Y4793_pgtype6;
	Y4793_gen_type [7] = Y4793_pgtype7;
	Y4793_gen_type [8] = Y4793_pgtype8;
	Y4793[0] = 864;
	Y4793[1] = 871;
	Y4793[2] = 864;
	Y4793[3] = 865;
	Y4793[4] = 871;
	{long i; for (i = 5; i < 9; i++) Y4793[i] = 864;};
}

long O4794[9];
void O4794_init () {
	{long i; for (i = 0; i < 2; i++) O4794[i] =  + _REFACS_3_;}
	{long i; for (i = 2; i < 6; i++) O4794[i] =  + _REFACS_2_;}
	O4794[6] =  + _REFACS_3_;
	O4794[7] =  + _REFACS_2_;
	O4794[8] =  + _REFACS_3_;
}

long O4795[9];
void O4795_init () {
	{long i; for (i = 0; i < 2; i++) O4795[i] =  + _REFACS_4_;}
	{long i; for (i = 2; i < 6; i++) O4795[i] =  + _REFACS_3_;}
	O4795[6] =  + _REFACS_4_;
	O4795[7] =  + _REFACS_3_;
	O4795[8] =  + _REFACS_4_;
}

long O4796[9];
void O4796_init () {
	O4796[0] = + _LNGOFF_7_3_0_1_;
	O4796[1] = + _LNGOFF_6_3_0_1_;
	O4796[2] = + _LNGOFF_5_3_0_2_;
	O4796[3] = + _LNGOFF_4_3_0_3_;
	O4796[4] = + _LNGOFF_4_3_0_2_;
	O4796[5] = + _LNGOFF_5_3_0_1_;
	O4796[6] = + _LNGOFF_7_4_0_1_;
	O4796[7] = + _LNGOFF_5_4_0_2_;
	O4796[8] = + _LNGOFF_9_3_0_1_;
}

long O4797[9];
void O4797_init () {
	O4797[0] = + _CHROFF_7_2_;
	O4797[1] = + _CHROFF_6_2_;
	O4797[2] = + _CHROFF_5_2_;
	{long i; for (i = 3; i < 5; i++) O4797[i] = + _CHROFF_4_2_;}
	O4797[5] = + _CHROFF_5_2_;
	O4797[6] = + _CHROFF_7_2_;
	O4797[7] = + _CHROFF_5_2_;
	O4797[8] = + _CHROFF_9_2_;
}

long O4798[9];
void O4798_init () {
	O4798[0] = + _LNGOFF_7_3_0_2_;
	O4798[1] = + _LNGOFF_6_3_0_2_;
	O4798[2] = + _LNGOFF_5_3_0_3_;
	O4798[3] = + _LNGOFF_4_3_0_4_;
	O4798[4] = + _LNGOFF_4_3_0_3_;
	O4798[5] = + _LNGOFF_5_3_0_2_;
	O4798[6] = + _LNGOFF_7_4_0_2_;
	O4798[7] = + _LNGOFF_5_4_0_3_;
	O4798[8] = + _LNGOFF_9_3_0_2_;
}

long O4801[9];
void O4801_init () {
	O4801[0] = + _LNGOFF_7_3_0_3_;
	O4801[1] = + _LNGOFF_6_3_0_3_;
	O4801[2] = + _LNGOFF_5_3_0_4_;
	O4801[3] = + _LNGOFF_4_3_0_5_;
	O4801[4] = + _LNGOFF_4_3_0_4_;
	O4801[5] = + _LNGOFF_5_3_0_3_;
	O4801[6] = + _LNGOFF_7_4_0_3_;
	O4801[7] = + _LNGOFF_5_4_0_4_;
	O4801[8] = + _LNGOFF_9_3_0_3_;
}

long O4802[9];
void O4802_init () {
	O4802[0] = + _LNGOFF_7_3_0_4_;
	O4802[1] = + _LNGOFF_6_3_0_4_;
	O4802[2] = + _LNGOFF_5_3_0_5_;
	O4802[3] = + _LNGOFF_4_3_0_6_;
	O4802[4] = + _LNGOFF_4_3_0_5_;
	O4802[5] = + _LNGOFF_5_3_0_4_;
	O4802[6] = + _LNGOFF_7_4_0_4_;
	O4802[7] = + _LNGOFF_5_4_0_5_;
	O4802[8] = + _LNGOFF_9_3_0_4_;
}

long O4806[9];
void O4806_init () {
	O4806[0] = + _LNGOFF_7_3_0_5_;
	O4806[1] = + _LNGOFF_6_3_0_5_;
	O4806[2] = + _LNGOFF_5_3_0_6_;
	O4806[3] = + _LNGOFF_4_3_0_7_;
	O4806[4] = + _LNGOFF_4_3_0_6_;
	O4806[5] = + _LNGOFF_5_3_0_5_;
	O4806[6] = + _LNGOFF_7_4_0_5_;
	O4806[7] = + _LNGOFF_5_4_0_6_;
	O4806[8] = + _LNGOFF_9_3_0_5_;
}

long O4807[9];
void O4807_init () {
	{long i; for (i = 0; i < 2; i++) O4807[i] =  + _REFACS_5_;}
	O4807[2] = + _LNGOFF_5_3_0_7_;
	O4807[3] = + _LNGOFF_4_3_0_8_;
	O4807[4] = + _LNGOFF_4_3_0_7_;
	O4807[5] = + _PTROFF_5_3_0_7_0_1_;
	O4807[6] =  + _REFACS_5_;
	O4807[7] = + _LNGOFF_5_4_0_7_;
	O4807[8] =  + _REFACS_5_;
}

long O4808[9];
void O4808_init () {
	O4808[0] =  + _REFACS_6_;
	O4808[1] = + _LNGOFF_6_3_0_6_;
	O4808[2] =  + _REFACS_4_;
	O4808[3] = + _LNGOFF_4_3_0_0_;
	O4808[4] = + _LNGOFF_4_3_0_8_;
	O4808[5] =  + _REFACS_4_;
	O4808[6] =  + _REFACS_6_;
	O4808[7] =  + _REFACS_4_;
	O4808[8] =  + _REFACS_6_;
}

long O4842[9];
void O4842_init () {
	O4842[0] = + _LNGOFF_7_3_0_6_;
	O4842[1] = + _LNGOFF_6_3_0_7_;
	O4842[2] = + _LNGOFF_5_3_0_8_;
	{long i; for (i = 3; i < 5; i++) O4842[i] = + _LNGOFF_4_3_0_9_;}
	O4842[5] = + _LNGOFF_5_3_0_6_;
	O4842[6] = + _LNGOFF_7_4_0_6_;
	O4842[7] = + _LNGOFF_5_4_0_8_;
	O4842[8] = + _LNGOFF_9_3_0_6_;
}

long O4845[2];
void O4845_init () {
	O4845[0] = + _CHROFF_7_3_;
	O4845[1] = + _CHROFF_5_3_;
}

long O4870[505];
void O4870_init () {
	{long i; for (i = 0; i < 17; i++) O4870[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 17; i < 19; i++) O4870[i] = + _LNGOFF_1_2_0_0_;}
	{long i; for (i = 19; i < 21; i++) O4870[i] = + _LNGOFF_3_2_0_0_;}
	{long i; for (i = 21; i < 24; i++) O4870[i] = + _LNGOFF_5_2_0_0_;}
	O4870[24] = + _LNGOFF_9_2_0_0_;
	O4870[149] = + _LNGOFF_9_2_0_0_;
	O4870[150] = + _LNGOFF_10_2_0_0_;
	{long i; for (i = 151; i < 174; i++) O4870[i] = + _LNGOFF_9_2_0_0_;}
	O4870[281] = + _LNGOFF_22_4_0_0_;
	O4870[282] = + _LNGOFF_28_6_0_0_;
	O4870[283] = + _LNGOFF_24_8_0_0_;
	O4870[504] = + _LNGOFF_7_2_0_0_;
}

long O4882[488];
void O4882_init () {
	{long i; for (i = 0; i < 2; i++) O4882[i] = + _CHROFF_1_1_;}
	{long i; for (i = 2; i < 4; i++) O4882[i] = + _CHROFF_3_1_;}
	{long i; for (i = 4; i < 7; i++) O4882[i] = + _CHROFF_5_1_;}
	O4882[7] = + _CHROFF_9_1_;
	O4882[132] = + _CHROFF_9_1_;
	O4882[133] = + _CHROFF_10_1_;
	{long i; for (i = 134; i < 157; i++) O4882[i] = + _CHROFF_9_1_;}
	O4882[487] = + _CHROFF_7_1_;
}

static EIF_TYPE_INDEX Y4885_pgtype0[] = {687,0xFFF9,1,997,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4885_pgtype1[] = {687,0xFFF9,1,997,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4885_pgtype2[] = {687,0xFFF9,1,997,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4885_pgtype3[] = {687,0xFFF9,1,997,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4885_pgtype4[] = {687,0xFFF9,1,997,1098,0xFFFF};
EIF_TYPE_INDEX *Y4885_gen_type [5];
EIF_TYPE_INDEX Y4885 [5];
void Y4885_init (void)
{
	egc_routines_types [4885] = Y4885;
	egc_routines_gen_types [4885] = Y4885_gen_type;
	egc_routines_offset [4885] = 682;
	Y4885_gen_type [0] = Y4885_pgtype0;
	Y4885_gen_type [1] = Y4885_pgtype1;
	Y4885_gen_type [2] = Y4885_pgtype2;
	Y4885_gen_type [3] = Y4885_pgtype3;
	Y4885_gen_type [4] = Y4885_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y4885[i] = 687;};
}

static EIF_TYPE_INDEX Y4886_pgtype0[] = {687,0xFFF9,1,997,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4886_pgtype1[] = {687,0xFFF9,1,997,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4886_pgtype2[] = {687,0xFFF9,1,997,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4886_pgtype3[] = {687,0xFFF9,1,997,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4886_pgtype4[] = {687,0xFFF9,1,997,1098,0xFFFF};
EIF_TYPE_INDEX *Y4886_gen_type [5];
EIF_TYPE_INDEX Y4886 [5];
void Y4886_init (void)
{
	egc_routines_types [4886] = Y4886;
	egc_routines_gen_types [4886] = Y4886_gen_type;
	egc_routines_offset [4886] = 682;
	Y4886_gen_type [0] = Y4886_pgtype0;
	Y4886_gen_type [1] = Y4886_pgtype1;
	Y4886_gen_type [2] = Y4886_pgtype2;
	Y4886_gen_type [3] = Y4886_pgtype3;
	Y4886_gen_type [4] = Y4886_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y4886[i] = 687;};
}

static EIF_TYPE_INDEX Y4887_pgtype0[] = {812,0xFFF9,1,997,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4887_pgtype1[] = {812,0xFFF9,1,997,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4887_pgtype2[] = {812,0xFFF9,1,997,1098,0xFFFF};
EIF_TYPE_INDEX *Y4887_gen_type [3];
EIF_TYPE_INDEX Y4887 [3];
void Y4887_init (void)
{
	egc_routines_types [4887] = Y4887;
	egc_routines_gen_types [4887] = Y4887_gen_type;
	egc_routines_offset [4887] = 684;
	Y4887_gen_type [0] = Y4887_pgtype0;
	Y4887_gen_type [1] = Y4887_pgtype1;
	Y4887_gen_type [2] = Y4887_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y4887[i] = 812;};
}

static EIF_TYPE_INDEX Y4888_pgtype0[] = {812,0xFFF9,1,997,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4888_pgtype1[] = {812,0xFFF9,1,997,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4888_pgtype2[] = {812,0xFFF9,1,997,1098,0xFFFF};
EIF_TYPE_INDEX *Y4888_gen_type [3];
EIF_TYPE_INDEX Y4888 [3];
void Y4888_init (void)
{
	egc_routines_types [4888] = Y4888;
	egc_routines_gen_types [4888] = Y4888_gen_type;
	egc_routines_offset [4888] = 684;
	Y4888_gen_type [0] = Y4888_pgtype0;
	Y4888_gen_type [1] = Y4888_pgtype1;
	Y4888_gen_type [2] = Y4888_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y4888[i] = 812;};
}

long O4901[150];
void O4901_init () {
	O4901[0] = + _LNGOFF_9_2_0_1_;
	O4901[125] = + _LNGOFF_9_2_0_1_;
	O4901[126] = + _LNGOFF_10_2_0_1_;
	{long i; for (i = 127; i < 150; i++) O4901[i] = + _LNGOFF_9_2_0_1_;}
}

long O5297[920];
void O5297_init () {
	O5297[0] = + _LNGOFF_0_1_0_1_;
	O5297[919] = + _LNGOFF_6_1_0_1_;
}

long O5305[920];
void O5305_init () {
	O5305[0] = + _LNGOFF_0_1_0_2_;
	O5305[919] = + _LNGOFF_6_1_0_2_;
}

long O5306[920];
void O5306_init () {
	O5306[0] = + _LNGOFF_0_1_0_3_;
	O5306[919] = + _LNGOFF_6_1_0_3_;
}

long O5329[21];
void O5329_init () {
	{long i; for (i = 0; i < 12; i++) O5329[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 12; i < 15; i++) O5329[i] = + _LNGOFF_2_1_0_0_;}
	{long i; for (i = 15; i < 21; i++) O5329[i] = + _LNGOFF_1_1_0_0_;}
}

long O5333[21];
void O5333_init () {
	{long i; for (i = 0; i < 12; i++) O5333[i] = + _CHROFF_1_0_;}
	{long i; for (i = 12; i < 15; i++) O5333[i] = + _CHROFF_2_0_;}
	{long i; for (i = 15; i < 21; i++) O5333[i] = + _CHROFF_1_0_;}
}

long O5334[21];
void O5334_init () {
	{long i; for (i = 0; i < 12; i++) O5334[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 12; i < 15; i++) O5334[i] = + _LNGOFF_2_1_0_1_;}
	{long i; for (i = 15; i < 21; i++) O5334[i] = + _LNGOFF_1_1_0_1_;}
}

long O5335[21];
void O5335_init () {
	{long i; for (i = 0; i < 12; i++) O5335[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 12; i < 15; i++) O5335[i] = + _LNGOFF_2_1_0_2_;}
	{long i; for (i = 15; i < 21; i++) O5335[i] = + _LNGOFF_1_1_0_2_;}
}

long O5336[21];
void O5336_init () {
	{long i; for (i = 0; i < 12; i++) O5336[i] = + _LNGOFF_1_1_0_3_;}
	{long i; for (i = 12; i < 15; i++) O5336[i] = + _LNGOFF_2_1_0_3_;}
	{long i; for (i = 15; i < 21; i++) O5336[i] = + _LNGOFF_1_1_0_3_;}
}

long O5337[21];
void O5337_init () {
	{long i; for (i = 0; i < 12; i++) O5337[i] = + _LNGOFF_1_1_0_4_;}
	{long i; for (i = 12; i < 15; i++) O5337[i] = + _LNGOFF_2_1_0_4_;}
	{long i; for (i = 15; i < 21; i++) O5337[i] = + _LNGOFF_1_1_0_4_;}
}

long O5340[50];
void O5340_init () {
	{long i; for (i = 0; i < 12; i++) O5340[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 12; i < 38; i++) O5340[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 38; i < 50; i++) O5340[i] = + _LNGOFF_1_0_0_0_;}
}

long O5342[50];
void O5342_init () {
	{long i; for (i = 0; i < 12; i++) O5342[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 12; i < 38; i++) O5342[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 38; i < 50; i++) O5342[i] = + _LNGOFF_1_0_0_1_;}
}

long O6256[588];
void O6256_init () {
	O6256[0] = + _CHROFF_1_0_;
	O6256[1] = + _CHROFF_3_0_;
	O6256[2] = + _CHROFF_4_0_;
	O6256[3] = + _CHROFF_5_0_;
	O6256[587] = + _CHROFF_5_0_;
}

long O6355[587];
void O6355_init () {
	O6355[0] = + _PTROFF_3_6_2_4_1_0_;
	O6355[1] = + _PTROFF_4_6_2_4_1_0_;
	O6355[2] = + _PTROFF_5_7_2_4_1_0_;
	O6355[586] = + _PTROFF_5_7_2_4_1_0_;
}

long O6494[587];
void O6494_init () {
	O6494[0] = + _LNGOFF_3_6_2_3_;
	O6494[1] = + _LNGOFF_4_6_2_3_;
	O6494[2] = + _LNGOFF_5_7_2_3_;
	O6494[586] = + _LNGOFF_5_7_2_3_;
}

long O6503[587];
void O6503_init () {
	O6503[0] = + _CHROFF_3_3_;
	O6503[1] = + _CHROFF_4_3_;
	O6503[2] = + _CHROFF_5_3_;
	O6503[586] = + _CHROFF_5_3_;
}

long O6580[776];
void O6580_init () {
	O6580[0] = + _LNGOFF_0_0_0_0_;
	O6580[1] = + _LNGOFF_3_3_0_0_;
	O6580[2] = + _LNGOFF_1_0_0_1_;
	{long i; for (i = 3; i < 5; i++) O6580[i] = + _LNGOFF_0_0_0_0_;}
	O6580[5] = + _LNGOFF_2_0_0_0_;
	O6580[6] = + _LNGOFF_21_3_0_0_;
	O6580[7] = + _LNGOFF_22_4_0_1_;
	O6580[8] = + _LNGOFF_28_6_0_1_;
	O6580[9] = + _LNGOFF_24_8_0_1_;
	{long i; for (i = 10; i < 14; i++) O6580[i] = + _LNGOFF_22_4_0_0_;}
	O6580[14] = + _LNGOFF_23_5_0_0_;
	O6580[15] = + _LNGOFF_24_5_0_0_;
	{long i; for (i = 16; i < 23; i++) O6580[i] = + _LNGOFF_23_4_0_0_;}
	O6580[23] = + _LNGOFF_0_1_0_0_;
	O6580[228] = + _LNGOFF_4_0_0_0_;
	O6580[229] = + _LNGOFF_6_0_0_0_;
	O6580[230] = + _LNGOFF_7_2_0_1_;
	O6580[231] = + _LNGOFF_6_0_0_0_;
	O6580[232] = + _LNGOFF_7_0_0_0_;
	{long i; for (i = 233; i < 241; i++) O6580[i] = + _LNGOFF_6_0_0_0_;}
	O6580[241] = + _LNGOFF_6_1_0_0_;
	O6580[242] = + _LNGOFF_6_0_0_0_;
	O6580[244] = + _LNGOFF_2_0_0_0_;
	O6580[247] = + _LNGOFF_6_1_0_0_;
	O6580[248] = + _LNGOFF_8_1_0_0_;
	O6580[249] = + _LNGOFF_6_1_0_0_;
	O6580[252] = + _LNGOFF_6_0_0_0_;
	O6580[253] = + _LNGOFF_8_0_0_0_;
	O6580[256] = + _LNGOFF_5_2_0_0_;
	{long i; for (i = 257; i < 268; i++) O6580[i] = + _LNGOFF_6_3_0_0_;}
	O6580[268] = + _LNGOFF_15_3_0_0_;
	O6580[269] = + _LNGOFF_12_4_0_0_;
	O6580[270] = + _LNGOFF_10_3_0_0_;
	O6580[271] = + _LNGOFF_7_3_0_0_;
	{long i; for (i = 272; i < 277; i++) O6580[i] = + _LNGOFF_6_3_0_0_;}
	{long i; for (i = 277; i < 284; i++) O6580[i] = + _LNGOFF_15_3_0_0_;}
	O6580[284] = + _LNGOFF_6_3_0_0_;
	O6580[285] = + _LNGOFF_6_4_0_0_;
	O6580[286] = + _LNGOFF_6_3_0_0_;
	O6580[287] = + _LNGOFF_83_3_0_0_;
	O6580[288] = + _LNGOFF_6_3_0_0_;
	O6580[289] = + _LNGOFF_7_4_0_0_;
	O6580[290] = + _LNGOFF_6_3_0_0_;
	O6580[291] = + _LNGOFF_39_3_0_0_;
	O6580[292] = + _LNGOFF_46_9_0_0_;
	O6580[293] = + _LNGOFF_39_3_0_0_;
	O6580[294] = + _LNGOFF_49_6_0_0_;
	{long i; for (i = 295; i < 297; i++) O6580[i] = + _LNGOFF_28_3_0_0_;}
	{long i; for (i = 297; i < 301; i++) O6580[i] = + _LNGOFF_14_3_0_0_;}
	O6580[301] = + _LNGOFF_5_2_0_0_;
	{long i; for (i = 302; i < 304; i++) O6580[i] = + _LNGOFF_5_3_0_0_;}
	O6580[304] = + _LNGOFF_5_2_0_0_;
	O6580[305] = + _LNGOFF_5_3_0_0_;
	O6580[306] = + _LNGOFF_6_3_0_0_;
	{long i; for (i = 307; i < 315; i++) O6580[i] = + _LNGOFF_5_2_0_0_;}
	{long i; for (i = 315; i < 319; i++) O6580[i] = + _LNGOFF_5_3_0_0_;}
	{long i; for (i = 319; i < 323; i++) O6580[i] = + _LNGOFF_6_2_0_0_;}
	{long i; for (i = 323; i < 325; i++) O6580[i] = + _LNGOFF_5_3_0_0_;}
	{long i; for (i = 325; i < 336; i++) O6580[i] = + _LNGOFF_5_2_0_0_;}
	O6580[340] = + _LNGOFF_5_2_0_0_;
	O6580[341] = + _LNGOFF_6_3_0_0_;
	O6580[351] = + _LNGOFF_2_4_0_0_;
	O6580[355] = + _LNGOFF_2_2_0_1_;
	O6580[367] = + _LNGOFF_49_16_0_3_;
	O6580[376] = + _LNGOFF_2_3_0_0_;
	O6580[377] = + _LNGOFF_4_3_0_0_;
	O6580[378] = + _LNGOFF_5_5_0_0_;
	O6580[379] = + _LNGOFF_10_10_0_0_;
	O6580[382] = + _LNGOFF_6_3_0_0_;
	O6580[419] = + _LNGOFF_8_5_0_0_;
	O6580[420] = + _LNGOFF_9_5_0_0_;
	O6580[421] = + _LNGOFF_8_5_0_0_;
	O6580[422] = + _LNGOFF_9_5_0_0_;
	O6580[423] = + _LNGOFF_11_5_0_0_;
	O6580[424] = + _LNGOFF_11_6_0_0_;
	O6580[426] = + _LNGOFF_16_7_6_0_;
	O6580[428] = + _LNGOFF_42_12_10_0_;
	O6580[440] = + _LNGOFF_46_12_10_0_;
	O6580[441] = + _LNGOFF_48_13_10_0_;
	{long i; for (i = 442; i < 445; i++) O6580[i] = + _LNGOFF_48_15_10_0_;}
	{long i; for (i = 445; i < 447; i++) O6580[i] = + _LNGOFF_47_12_10_0_;}
	O6580[447] = + _LNGOFF_49_12_10_0_;
	{long i; for (i = 448; i < 451; i++) O6580[i] = + _LNGOFF_49_13_10_0_;}
	O6580[460] = + _LNGOFF_49_13_10_0_;
	O6580[461] = + _LNGOFF_113_55_10_0_;
	O6580[462] = + _LNGOFF_51_13_10_0_;
	{long i; for (i = 463; i < 465; i++) O6580[i] = + _LNGOFF_49_14_10_0_;}
	O6580[465] = + _LNGOFF_59_21_10_0_;
	O6580[466] = + _LNGOFF_59_23_10_0_;
	O6580[467] = + _LNGOFF_65_25_10_0_;
	O6580[468] = + _LNGOFF_68_26_10_0_;
	O6580[503] = + _LNGOFF_42_13_10_0_;
	O6580[504] = + _LNGOFF_51_15_10_0_;
	O6580[505] = + _LNGOFF_45_16_10_0_;
	O6580[506] = + _LNGOFF_58_14_10_0_;
	O6580[507] = + _LNGOFF_44_13_10_0_;
	O6580[508] = + _LNGOFF_51_13_10_0_;
	O6580[509] = + _LNGOFF_53_13_10_0_;
	{long i; for (i = 510; i < 513; i++) O6580[i] = + _LNGOFF_42_13_10_0_;}
	O6580[513] = + _LNGOFF_43_13_10_0_;
	O6580[514] = + _LNGOFF_44_15_10_0_;
	O6580[515] = + _LNGOFF_51_18_10_0_;
	{long i; for (i = 516; i < 518; i++) O6580[i] = + _LNGOFF_46_14_10_0_;}
	O6580[518] = + _LNGOFF_50_13_10_0_;
	O6580[519] = + _LNGOFF_59_16_10_0_;
	O6580[520] = + _LNGOFF_51_14_10_0_;
	O6580[521] = + _LNGOFF_53_14_10_0_;
	{long i; for (i = 522; i < 526; i++) O6580[i] = + _LNGOFF_46_14_10_0_;}
	O6580[526] = + _LNGOFF_44_13_10_0_;
	O6580[527] = + _LNGOFF_48_14_10_0_;
	{long i; for (i = 528; i < 531; i++) O6580[i] = + _LNGOFF_44_13_10_0_;}
	{long i; for (i = 531; i < 534; i++) O6580[i] = + _LNGOFF_44_14_10_0_;}
	{long i; for (i = 534; i < 537; i++) O6580[i] = + _LNGOFF_44_13_10_0_;}
	O6580[539] = + _LNGOFF_22_8_6_0_;
	{long i; for (i = 547; i < 549; i++) O6580[i] = + _LNGOFF_21_7_6_0_;}
	O6580[554] = + _LNGOFF_23_8_6_0_;
	{long i; for (i = 555; i < 557; i++) O6580[i] = + _LNGOFF_23_9_6_0_;}
	O6580[557] = + _LNGOFF_26_8_6_0_;
	O6580[558] = + _LNGOFF_24_9_6_0_;
	{long i; for (i = 564; i < 567; i++) O6580[i] = + _LNGOFF_29_14_8_0_;}
	O6580[573] = + _LNGOFF_48_19_10_0_;
	O6580[576] = + _LNGOFF_48_18_10_0_;
	O6580[593] = + _LNGOFF_24_5_0_0_;
	O6580[594] = + _LNGOFF_24_4_0_0_;
	O6580[766] = + _LNGOFF_25_3_0_0_;
	O6580[771] = + _LNGOFF_13_3_0_0_;
	O6580[773] = + _LNGOFF_14_3_0_0_;
	O6580[774] = + _LNGOFF_5_3_0_0_;
	O6580[775] = + _LNGOFF_84_3_0_1_;
}

long O6698[771];
void O6698_init () {
	{long i; for (i = 0; i < 2; i++) O6698[i] =  + _REFACS_1_;}
	{long i; for (i = 2; i < 5; i++) O6698[i] =  + _REFACS_2_;}
	{long i; for (i = 5; i < 18; i++) O6698[i] =  + _REFACS_1_;}
	{long i; for (i = 223; i < 225; i++) O6698[i] =  + _REFACS_1_;}
	O6698[225] =  + _REFACS_2_;
	{long i; for (i = 226; i < 238; i++) O6698[i] =  + _REFACS_1_;}
	{long i; for (i = 242; i < 245; i++) O6698[i] =  + _REFACS_1_;}
	{long i; for (i = 247; i < 249; i++) O6698[i] =  + _REFACS_1_;}
	{long i; for (i = 251; i < 331; i++) O6698[i] =  + _REFACS_1_;}
	{long i; for (i = 335; i < 337; i++) O6698[i] =  + _REFACS_1_;}
	{long i; for (i = 588; i < 590; i++) O6698[i] =  + _REFACS_1_;}
	O6698[761] =  + _REFACS_1_;
	O6698[766] =  + _REFACS_1_;
	{long i; for (i = 768; i < 771; i++) O6698[i] =  + _REFACS_1_;}
}

long O6717[589];
void O6717_init () {
	O6717[0] =  + _REFACS_2_;
	{long i; for (i = 1; i < 4; i++) O6717[i] =  + _REFACS_3_;}
	{long i; for (i = 4; i < 17; i++) O6717[i] =  + _REFACS_2_;}
	{long i; for (i = 587; i < 589; i++) O6717[i] =  + _REFACS_2_;}
}

long O6731[589];
void O6731_init () {
	O6731[0] = + _CHROFF_21_0_;
	O6731[1] = + _CHROFF_22_1_;
	O6731[2] = + _CHROFF_28_1_;
	O6731[3] = + _CHROFF_24_1_;
	{long i; for (i = 4; i < 8; i++) O6731[i] = + _CHROFF_22_0_;}
	O6731[8] = + _CHROFF_23_0_;
	O6731[9] = + _CHROFF_24_0_;
	{long i; for (i = 10; i < 17; i++) O6731[i] = + _CHROFF_23_0_;}
	{long i; for (i = 587; i < 589; i++) O6731[i] = + _CHROFF_24_0_;}
}


#ifdef __cplusplus
}
#endif
