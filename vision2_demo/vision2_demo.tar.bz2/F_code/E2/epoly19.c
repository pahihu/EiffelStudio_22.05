#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O6745[589];
void O6745_init () {
	O6745[0] = + _CHROFF_21_1_;
	O6745[1] = + _CHROFF_22_2_;
	O6745[2] = + _CHROFF_28_2_;
	O6745[3] = + _CHROFF_24_2_;
	{long i; for (i = 4; i < 8; i++) O6745[i] = + _CHROFF_22_1_;}
	O6745[8] = + _CHROFF_23_1_;
	O6745[9] = + _CHROFF_24_1_;
	{long i; for (i = 10; i < 17; i++) O6745[i] = + _CHROFF_23_1_;}
	{long i; for (i = 587; i < 589; i++) O6745[i] = + _CHROFF_24_1_;}
}

long O6748[589];
void O6748_init () {
	O6748[0] =  + _REFACS_3_;
	{long i; for (i = 1; i < 4; i++) O6748[i] =  + _REFACS_4_;}
	{long i; for (i = 4; i < 17; i++) O6748[i] =  + _REFACS_3_;}
	{long i; for (i = 587; i < 589; i++) O6748[i] =  + _REFACS_3_;}
}

long O6752[589];
void O6752_init () {
	O6752[0] =  + _REFACS_4_;
	{long i; for (i = 1; i < 4; i++) O6752[i] =  + _REFACS_5_;}
	{long i; for (i = 4; i < 17; i++) O6752[i] =  + _REFACS_4_;}
	{long i; for (i = 587; i < 589; i++) O6752[i] =  + _REFACS_4_;}
}

long O6755[589];
void O6755_init () {
	O6755[0] = + _LNGOFF_21_3_0_1_;
	O6755[1] = + _LNGOFF_22_4_0_2_;
	O6755[2] = + _LNGOFF_28_6_0_2_;
	O6755[3] = + _LNGOFF_24_8_0_2_;
	{long i; for (i = 4; i < 8; i++) O6755[i] = + _LNGOFF_22_4_0_1_;}
	O6755[8] = + _LNGOFF_23_5_0_1_;
	O6755[9] = + _LNGOFF_24_5_0_1_;
	{long i; for (i = 10; i < 17; i++) O6755[i] = + _LNGOFF_23_4_0_1_;}
	O6755[587] = + _LNGOFF_24_5_0_1_;
	O6755[588] = + _LNGOFF_24_4_0_1_;
}

long O6757[589];
void O6757_init () {
	O6757[0] =  + _REFACS_5_;
	{long i; for (i = 1; i < 4; i++) O6757[i] =  + _REFACS_6_;}
	{long i; for (i = 4; i < 17; i++) O6757[i] =  + _REFACS_5_;}
	{long i; for (i = 587; i < 589; i++) O6757[i] =  + _REFACS_5_;}
}

long O6758[589];
void O6758_init () {
	O6758[0] = + _CHROFF_21_2_;
	O6758[1] = + _CHROFF_22_3_;
	O6758[2] = + _CHROFF_28_3_;
	O6758[3] = + _CHROFF_24_3_;
	{long i; for (i = 4; i < 8; i++) O6758[i] = + _CHROFF_22_2_;}
	O6758[8] = + _CHROFF_23_2_;
	O6758[9] = + _CHROFF_24_2_;
	{long i; for (i = 10; i < 17; i++) O6758[i] = + _CHROFF_23_2_;}
	{long i; for (i = 587; i < 589; i++) O6758[i] = + _CHROFF_24_2_;}
}

long O6765[589];
void O6765_init () {
	O6765[0] =  + _REFACS_6_;
	{long i; for (i = 1; i < 4; i++) O6765[i] =  + _REFACS_7_;}
	{long i; for (i = 4; i < 17; i++) O6765[i] =  + _REFACS_6_;}
	{long i; for (i = 587; i < 589; i++) O6765[i] =  + _REFACS_6_;}
}

long O6766[589];
void O6766_init () {
	O6766[0] =  + _REFACS_7_;
	{long i; for (i = 1; i < 4; i++) O6766[i] =  + _REFACS_8_;}
	{long i; for (i = 4; i < 17; i++) O6766[i] =  + _REFACS_7_;}
	{long i; for (i = 587; i < 589; i++) O6766[i] =  + _REFACS_7_;}
}

long O6767[589];
void O6767_init () {
	O6767[0] =  + _REFACS_8_;
	{long i; for (i = 1; i < 4; i++) O6767[i] =  + _REFACS_9_;}
	{long i; for (i = 4; i < 17; i++) O6767[i] =  + _REFACS_8_;}
	{long i; for (i = 587; i < 589; i++) O6767[i] =  + _REFACS_8_;}
}

long O6768[589];
void O6768_init () {
	O6768[0] =  + _REFACS_9_;
	{long i; for (i = 1; i < 4; i++) O6768[i] =  + _REFACS_10_;}
	{long i; for (i = 4; i < 17; i++) O6768[i] =  + _REFACS_9_;}
	{long i; for (i = 587; i < 589; i++) O6768[i] =  + _REFACS_9_;}
}

long O6769[589];
void O6769_init () {
	O6769[0] =  + _REFACS_10_;
	{long i; for (i = 1; i < 4; i++) O6769[i] =  + _REFACS_11_;}
	{long i; for (i = 4; i < 17; i++) O6769[i] =  + _REFACS_10_;}
	{long i; for (i = 587; i < 589; i++) O6769[i] =  + _REFACS_10_;}
}

long O6770[589];
void O6770_init () {
	O6770[0] =  + _REFACS_11_;
	{long i; for (i = 1; i < 4; i++) O6770[i] =  + _REFACS_12_;}
	{long i; for (i = 4; i < 17; i++) O6770[i] =  + _REFACS_11_;}
	{long i; for (i = 587; i < 589; i++) O6770[i] =  + _REFACS_11_;}
}

long O6775[589];
void O6775_init () {
	O6775[0] =  + _REFACS_16_;
	{long i; for (i = 1; i < 4; i++) O6775[i] =  + _REFACS_17_;}
	{long i; for (i = 4; i < 17; i++) O6775[i] =  + _REFACS_16_;}
	{long i; for (i = 587; i < 589; i++) O6775[i] =  + _REFACS_16_;}
}

long O6776[589];
void O6776_init () {
	O6776[0] =  + _REFACS_17_;
	{long i; for (i = 1; i < 4; i++) O6776[i] =  + _REFACS_18_;}
	{long i; for (i = 4; i < 17; i++) O6776[i] =  + _REFACS_17_;}
	{long i; for (i = 587; i < 589; i++) O6776[i] =  + _REFACS_17_;}
}

long O6777[589];
void O6777_init () {
	O6777[0] =  + _REFACS_18_;
	{long i; for (i = 1; i < 4; i++) O6777[i] =  + _REFACS_19_;}
	{long i; for (i = 4; i < 17; i++) O6777[i] =  + _REFACS_18_;}
	{long i; for (i = 587; i < 589; i++) O6777[i] =  + _REFACS_18_;}
}

long O6778[589];
void O6778_init () {
	O6778[0] =  + _REFACS_19_;
	{long i; for (i = 1; i < 4; i++) O6778[i] =  + _REFACS_20_;}
	{long i; for (i = 4; i < 17; i++) O6778[i] =  + _REFACS_19_;}
	{long i; for (i = 587; i < 589; i++) O6778[i] =  + _REFACS_19_;}
}

long O6779[589];
void O6779_init () {
	O6779[0] =  + _REFACS_20_;
	{long i; for (i = 1; i < 4; i++) O6779[i] =  + _REFACS_21_;}
	{long i; for (i = 4; i < 17; i++) O6779[i] =  + _REFACS_20_;}
	{long i; for (i = 587; i < 589; i++) O6779[i] =  + _REFACS_20_;}
}


#ifdef __cplusplus
}
#endif
