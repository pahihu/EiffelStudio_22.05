#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O1228[1388];
void O1228_init () {
	O1228[0] = 0;
	{long i; for (i = 1339; i < 1344; i++) O1228[i] = 0;}
	O1228[1349] = 0;
	O1228[1353] =  + _REFACS_1_;
	{long i; for (i = 1373; i < 1378; i++) O1228[i] = 0;}
	O1228[1379] = 0;
	O1228[1387] =  + _REFACS_1_;
}

long O1234[1380];
void O1234_init () {
	O1234[0] = 0;
	O1234[1346] = 0;
	O1234[1347] =  + _REFACS_1_;
	{long i; for (i = 1348; i < 1350; i++) O1234[i] = 0;}
	O1234[1376] = 0;
	O1234[1377] =  + _REFACS_1_;
	{long i; for (i = 1378; i < 1380; i++) O1234[i] = 0;}
}

long O1237[1424];
void O1237_init () {
	O1237[0] = 0;
	{long i; for (i = 1394; i < 1409; i++) O1237[i] = 0;}
	O1237[1409] =  + _REFACS_1_;
	{long i; for (i = 1410; i < 1414; i++) O1237[i] = 0;}
	O1237[1414] =  + _REFACS_1_;
	O1237[1415] = 0;
	{long i; for (i = 1416; i < 1418; i++) O1237[i] =  + _REFACS_2_;}
	{long i; for (i = 1418; i < 1424; i++) O1237[i] = 0;}
}

long O1239[1424];
void O1239_init () {
	O1239[0] =  + _REFACS_1_;
	{long i; for (i = 1394; i < 1409; i++) O1239[i] =  + _REFACS_1_;}
	O1239[1409] =  + _REFACS_2_;
	{long i; for (i = 1410; i < 1414; i++) O1239[i] =  + _REFACS_1_;}
	O1239[1414] =  + _REFACS_2_;
	O1239[1415] =  + _REFACS_1_;
	{long i; for (i = 1416; i < 1418; i++) O1239[i] =  + _REFACS_3_;}
	{long i; for (i = 1418; i < 1424; i++) O1239[i] =  + _REFACS_1_;}
}

long O1241[1424];
void O1241_init () {
	O1241[0] =  + _REFACS_2_;
	{long i; for (i = 1394; i < 1409; i++) O1241[i] =  + _REFACS_2_;}
	O1241[1409] =  + _REFACS_3_;
	{long i; for (i = 1410; i < 1414; i++) O1241[i] =  + _REFACS_2_;}
	O1241[1414] =  + _REFACS_3_;
	O1241[1415] =  + _REFACS_2_;
	{long i; for (i = 1416; i < 1418; i++) O1241[i] =  + _REFACS_4_;}
	{long i; for (i = 1418; i < 1424; i++) O1241[i] =  + _REFACS_2_;}
}

long O1248[1414];
void O1248_init () {
	O1248[0] = 0;
	{long i; for (i = 1404; i < 1407; i++) O1248[i] =  + _REFACS_3_;}
	O1248[1407] =  + _REFACS_4_;
	{long i; for (i = 1408; i < 1412; i++) O1248[i] =  + _REFACS_3_;}
	O1248[1412] =  + _REFACS_4_;
	O1248[1413] =  + _REFACS_3_;
}

long O1274[1376];
void O1274_init () {
	O1274[0] = 0;
	{long i; for (i = 1330; i < 1332; i++) O1274[i] =  + _REFACS_1_;}
	O1274[1337] =  + _REFACS_5_;
	O1274[1341] =  + _REFACS_2_;
	{long i; for (i = 1364; i < 1366; i++) O1274[i] =  + _REFACS_1_;}
	O1274[1367] =  + _REFACS_5_;
	O1274[1375] =  + _REFACS_2_;
}

long O1292[1420];
void O1292_init () {
	O1292[0] = 0;
	{long i; for (i = 1229; i < 1231; i++) O1292[i] = 0;}
	{long i; for (i = 1270; i < 1272; i++) O1292[i] = 0;}
	{long i; for (i = 1272; i < 1279; i++) O1292[i] =  + _REFACS_1_;}
	O1292[1279] =  + _REFACS_2_;
	{long i; for (i = 1280; i < 1290; i++) O1292[i] =  + _REFACS_1_;}
	O1292[1290] =  + _REFACS_2_;
	{long i; for (i = 1291; i < 1312; i++) O1292[i] =  + _REFACS_1_;}
	O1292[1312] = 0;
	O1292[1313] =  + _REFACS_5_;
	O1292[1314] = 0;
	O1292[1315] =  + _REFACS_4_;
	{long i; for (i = 1316; i < 1318; i++) O1292[i] = 0;}
	O1292[1318] =  + _REFACS_2_;
	{long i; for (i = 1319; i < 1322; i++) O1292[i] = 0;}
	{long i; for (i = 1322; i < 1324; i++) O1292[i] =  + _REFACS_1_;}
	O1292[1324] =  + _REFACS_4_;
	{long i; for (i = 1325; i < 1327; i++) O1292[i] =  + _REFACS_2_;}
	{long i; for (i = 1327; i < 1331; i++) O1292[i] =  + _REFACS_1_;}
	O1292[1331] =  + _REFACS_2_;
	O1292[1332] =  + _REFACS_6_;
	{long i; for (i = 1333; i < 1335; i++) O1292[i] =  + _REFACS_2_;}
	O1292[1335] =  + _REFACS_1_;
	O1292[1336] =  + _REFACS_3_;
	{long i; for (i = 1337; i < 1346; i++) O1292[i] =  + _REFACS_1_;}
	O1292[1346] = 0;
	O1292[1347] =  + _REFACS_5_;
	O1292[1348] = 0;
	O1292[1349] =  + _REFACS_4_;
	{long i; for (i = 1350; i < 1352; i++) O1292[i] = 0;}
	O1292[1352] =  + _REFACS_2_;
	{long i; for (i = 1353; i < 1356; i++) O1292[i] = 0;}
	{long i; for (i = 1356; i < 1358; i++) O1292[i] =  + _REFACS_1_;}
	O1292[1358] =  + _REFACS_4_;
	{long i; for (i = 1359; i < 1362; i++) O1292[i] =  + _REFACS_2_;}
	O1292[1362] =  + _REFACS_6_;
	{long i; for (i = 1363; i < 1365; i++) O1292[i] =  + _REFACS_2_;}
	{long i; for (i = 1365; i < 1370; i++) O1292[i] =  + _REFACS_1_;}
	O1292[1370] =  + _REFACS_3_;
	{long i; for (i = 1371; i < 1380; i++) O1292[i] =  + _REFACS_1_;}
	{long i; for (i = 1404; i < 1410; i++) O1292[i] =  + _REFACS_5_;}
	O1292[1411] = 0;
	O1292[1414] = 0;
	O1292[1416] = 0;
	O1292[1419] = 0;
}


#ifdef __cplusplus
}
#endif
