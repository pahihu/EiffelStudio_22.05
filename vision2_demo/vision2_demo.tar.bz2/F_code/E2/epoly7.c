#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O3044[1355];
void O3044_init () {
	O3044[0] =  + _REFACS_4_;
	{long i; for (i = 1205; i < 1207; i++) O3044[i] =  + _REFACS_13_;}
	{long i; for (i = 1207; i < 1214; i++) O3044[i] =  + _REFACS_14_;}
	{long i; for (i = 1214; i < 1218; i++) O3044[i] =  + _REFACS_15_;}
	{long i; for (i = 1218; i < 1225; i++) O3044[i] =  + _REFACS_14_;}
	{long i; for (i = 1225; i < 1234; i++) O3044[i] =  + _REFACS_15_;}
	{long i; for (i = 1234; i < 1236; i++) O3044[i] =  + _REFACS_19_;}
	{long i; for (i = 1236; i < 1238; i++) O3044[i] =  + _REFACS_22_;}
	{long i; for (i = 1238; i < 1243; i++) O3044[i] =  + _REFACS_15_;}
	{long i; for (i = 1243; i < 1245; i++) O3044[i] =  + _REFACS_19_;}
	{long i; for (i = 1245; i < 1247; i++) O3044[i] =  + _REFACS_22_;}
	O3044[1247] =  + _REFACS_13_;
	O3044[1248] =  + _REFACS_18_;
	O3044[1249] =  + _REFACS_14_;
	O3044[1250] =  + _REFACS_17_;
	O3044[1251] =  + _REFACS_13_;
	O3044[1252] =  + _REFACS_15_;
	O3044[1253] =  + _REFACS_17_;
	{long i; for (i = 1254; i < 1257; i++) O3044[i] =  + _REFACS_13_;}
	{long i; for (i = 1257; i < 1259; i++) O3044[i] =  + _REFACS_14_;}
	O3044[1259] =  + _REFACS_17_;
	{long i; for (i = 1260; i < 1262; i++) O3044[i] =  + _REFACS_15_;}
	{long i; for (i = 1262; i < 1266; i++) O3044[i] =  + _REFACS_14_;}
	O3044[1266] =  + _REFACS_15_;
	O3044[1267] =  + _REFACS_19_;
	O3044[1268] =  + _REFACS_15_;
	O3044[1269] =  + _REFACS_17_;
	O3044[1270] =  + _REFACS_14_;
	O3044[1271] =  + _REFACS_16_;
	{long i; for (i = 1272; i < 1281; i++) O3044[i] =  + _REFACS_14_;}
	O3044[1281] =  + _REFACS_13_;
	O3044[1282] =  + _REFACS_18_;
	O3044[1283] =  + _REFACS_14_;
	O3044[1284] =  + _REFACS_17_;
	O3044[1285] =  + _REFACS_13_;
	O3044[1286] =  + _REFACS_15_;
	O3044[1287] =  + _REFACS_17_;
	{long i; for (i = 1288; i < 1291; i++) O3044[i] =  + _REFACS_13_;}
	{long i; for (i = 1291; i < 1293; i++) O3044[i] =  + _REFACS_14_;}
	O3044[1293] =  + _REFACS_17_;
	{long i; for (i = 1294; i < 1297; i++) O3044[i] =  + _REFACS_15_;}
	O3044[1297] =  + _REFACS_19_;
	O3044[1298] =  + _REFACS_15_;
	O3044[1299] =  + _REFACS_17_;
	{long i; for (i = 1300; i < 1305; i++) O3044[i] =  + _REFACS_14_;}
	O3044[1305] =  + _REFACS_16_;
	{long i; for (i = 1306; i < 1315; i++) O3044[i] =  + _REFACS_14_;}
	O3044[1346] =  + _REFACS_14_;
	O3044[1349] =  + _REFACS_14_;
	O3044[1351] =  + _REFACS_14_;
	O3044[1354] =  + _REFACS_14_;
}

long O3046[1355];
void O3046_init () {
	O3046[0] =  + _REFACS_5_;
	{long i; for (i = 1205; i < 1207; i++) O3046[i] =  + _REFACS_14_;}
	{long i; for (i = 1207; i < 1214; i++) O3046[i] =  + _REFACS_15_;}
	{long i; for (i = 1214; i < 1218; i++) O3046[i] =  + _REFACS_16_;}
	{long i; for (i = 1218; i < 1225; i++) O3046[i] =  + _REFACS_15_;}
	{long i; for (i = 1225; i < 1234; i++) O3046[i] =  + _REFACS_16_;}
	{long i; for (i = 1234; i < 1236; i++) O3046[i] =  + _REFACS_20_;}
	{long i; for (i = 1236; i < 1238; i++) O3046[i] =  + _REFACS_23_;}
	{long i; for (i = 1238; i < 1243; i++) O3046[i] =  + _REFACS_16_;}
	{long i; for (i = 1243; i < 1245; i++) O3046[i] =  + _REFACS_20_;}
	{long i; for (i = 1245; i < 1247; i++) O3046[i] =  + _REFACS_23_;}
	O3046[1247] =  + _REFACS_14_;
	O3046[1248] =  + _REFACS_19_;
	O3046[1249] =  + _REFACS_15_;
	O3046[1250] =  + _REFACS_18_;
	O3046[1251] =  + _REFACS_14_;
	O3046[1252] =  + _REFACS_16_;
	O3046[1253] =  + _REFACS_18_;
	{long i; for (i = 1254; i < 1257; i++) O3046[i] =  + _REFACS_14_;}
	{long i; for (i = 1257; i < 1259; i++) O3046[i] =  + _REFACS_15_;}
	O3046[1259] =  + _REFACS_18_;
	{long i; for (i = 1260; i < 1262; i++) O3046[i] =  + _REFACS_16_;}
	{long i; for (i = 1262; i < 1266; i++) O3046[i] =  + _REFACS_15_;}
	O3046[1266] =  + _REFACS_16_;
	O3046[1267] =  + _REFACS_20_;
	O3046[1268] =  + _REFACS_16_;
	O3046[1269] =  + _REFACS_18_;
	O3046[1270] =  + _REFACS_15_;
	O3046[1271] =  + _REFACS_17_;
	{long i; for (i = 1272; i < 1281; i++) O3046[i] =  + _REFACS_15_;}
	O3046[1281] =  + _REFACS_14_;
	O3046[1282] =  + _REFACS_19_;
	O3046[1283] =  + _REFACS_15_;
	O3046[1284] =  + _REFACS_18_;
	O3046[1285] =  + _REFACS_14_;
	O3046[1286] =  + _REFACS_16_;
	O3046[1287] =  + _REFACS_18_;
	{long i; for (i = 1288; i < 1291; i++) O3046[i] =  + _REFACS_14_;}
	{long i; for (i = 1291; i < 1293; i++) O3046[i] =  + _REFACS_15_;}
	O3046[1293] =  + _REFACS_18_;
	{long i; for (i = 1294; i < 1297; i++) O3046[i] =  + _REFACS_16_;}
	O3046[1297] =  + _REFACS_20_;
	O3046[1298] =  + _REFACS_16_;
	O3046[1299] =  + _REFACS_18_;
	{long i; for (i = 1300; i < 1305; i++) O3046[i] =  + _REFACS_15_;}
	O3046[1305] =  + _REFACS_17_;
	{long i; for (i = 1306; i < 1315; i++) O3046[i] =  + _REFACS_15_;}
	O3046[1346] =  + _REFACS_15_;
	O3046[1349] =  + _REFACS_15_;
	O3046[1351] =  + _REFACS_15_;
	O3046[1354] =  + _REFACS_15_;
}

long O3048[1355];
void O3048_init () {
	O3048[0] =  + _REFACS_6_;
	{long i; for (i = 1205; i < 1207; i++) O3048[i] =  + _REFACS_15_;}
	{long i; for (i = 1207; i < 1214; i++) O3048[i] =  + _REFACS_16_;}
	{long i; for (i = 1214; i < 1218; i++) O3048[i] =  + _REFACS_17_;}
	{long i; for (i = 1218; i < 1225; i++) O3048[i] =  + _REFACS_16_;}
	{long i; for (i = 1225; i < 1234; i++) O3048[i] =  + _REFACS_17_;}
	{long i; for (i = 1234; i < 1236; i++) O3048[i] =  + _REFACS_21_;}
	{long i; for (i = 1236; i < 1238; i++) O3048[i] =  + _REFACS_24_;}
	{long i; for (i = 1238; i < 1243; i++) O3048[i] =  + _REFACS_17_;}
	{long i; for (i = 1243; i < 1245; i++) O3048[i] =  + _REFACS_21_;}
	{long i; for (i = 1245; i < 1247; i++) O3048[i] =  + _REFACS_24_;}
	O3048[1247] =  + _REFACS_15_;
	O3048[1248] =  + _REFACS_20_;
	O3048[1249] =  + _REFACS_16_;
	O3048[1250] =  + _REFACS_19_;
	O3048[1251] =  + _REFACS_15_;
	O3048[1252] =  + _REFACS_17_;
	O3048[1253] =  + _REFACS_19_;
	{long i; for (i = 1254; i < 1257; i++) O3048[i] =  + _REFACS_15_;}
	{long i; for (i = 1257; i < 1259; i++) O3048[i] =  + _REFACS_16_;}
	O3048[1259] =  + _REFACS_19_;
	{long i; for (i = 1260; i < 1262; i++) O3048[i] =  + _REFACS_17_;}
	{long i; for (i = 1262; i < 1266; i++) O3048[i] =  + _REFACS_16_;}
	O3048[1266] =  + _REFACS_17_;
	O3048[1267] =  + _REFACS_21_;
	O3048[1268] =  + _REFACS_17_;
	O3048[1269] =  + _REFACS_19_;
	O3048[1270] =  + _REFACS_16_;
	O3048[1271] =  + _REFACS_18_;
	{long i; for (i = 1272; i < 1281; i++) O3048[i] =  + _REFACS_16_;}
	O3048[1281] =  + _REFACS_15_;
	O3048[1282] =  + _REFACS_20_;
	O3048[1283] =  + _REFACS_16_;
	O3048[1284] =  + _REFACS_19_;
	O3048[1285] =  + _REFACS_15_;
	O3048[1286] =  + _REFACS_17_;
	O3048[1287] =  + _REFACS_19_;
	{long i; for (i = 1288; i < 1291; i++) O3048[i] =  + _REFACS_15_;}
	{long i; for (i = 1291; i < 1293; i++) O3048[i] =  + _REFACS_16_;}
	O3048[1293] =  + _REFACS_19_;
	{long i; for (i = 1294; i < 1297; i++) O3048[i] =  + _REFACS_17_;}
	O3048[1297] =  + _REFACS_21_;
	O3048[1298] =  + _REFACS_17_;
	O3048[1299] =  + _REFACS_19_;
	{long i; for (i = 1300; i < 1305; i++) O3048[i] =  + _REFACS_16_;}
	O3048[1305] =  + _REFACS_18_;
	{long i; for (i = 1306; i < 1315; i++) O3048[i] =  + _REFACS_16_;}
	O3048[1346] =  + _REFACS_16_;
	O3048[1349] =  + _REFACS_16_;
	O3048[1351] =  + _REFACS_16_;
	O3048[1354] =  + _REFACS_16_;
}

long O3050[1355];
void O3050_init () {
	O3050[0] =  + _REFACS_7_;
	{long i; for (i = 1205; i < 1207; i++) O3050[i] =  + _REFACS_16_;}
	{long i; for (i = 1207; i < 1214; i++) O3050[i] =  + _REFACS_17_;}
	{long i; for (i = 1214; i < 1218; i++) O3050[i] =  + _REFACS_18_;}
	{long i; for (i = 1218; i < 1225; i++) O3050[i] =  + _REFACS_17_;}
	{long i; for (i = 1225; i < 1234; i++) O3050[i] =  + _REFACS_18_;}
	{long i; for (i = 1234; i < 1236; i++) O3050[i] =  + _REFACS_22_;}
	{long i; for (i = 1236; i < 1238; i++) O3050[i] =  + _REFACS_25_;}
	{long i; for (i = 1238; i < 1243; i++) O3050[i] =  + _REFACS_18_;}
	{long i; for (i = 1243; i < 1245; i++) O3050[i] =  + _REFACS_22_;}
	{long i; for (i = 1245; i < 1247; i++) O3050[i] =  + _REFACS_25_;}
	O3050[1247] =  + _REFACS_16_;
	O3050[1248] =  + _REFACS_21_;
	O3050[1249] =  + _REFACS_17_;
	O3050[1250] =  + _REFACS_20_;
	O3050[1251] =  + _REFACS_16_;
	O3050[1252] =  + _REFACS_18_;
	O3050[1253] =  + _REFACS_20_;
	{long i; for (i = 1254; i < 1257; i++) O3050[i] =  + _REFACS_16_;}
	{long i; for (i = 1257; i < 1259; i++) O3050[i] =  + _REFACS_17_;}
	O3050[1259] =  + _REFACS_20_;
	{long i; for (i = 1260; i < 1262; i++) O3050[i] =  + _REFACS_18_;}
	{long i; for (i = 1262; i < 1266; i++) O3050[i] =  + _REFACS_17_;}
	O3050[1266] =  + _REFACS_18_;
	O3050[1267] =  + _REFACS_22_;
	O3050[1268] =  + _REFACS_18_;
	O3050[1269] =  + _REFACS_20_;
	O3050[1270] =  + _REFACS_17_;
	O3050[1271] =  + _REFACS_19_;
	{long i; for (i = 1272; i < 1281; i++) O3050[i] =  + _REFACS_17_;}
	O3050[1281] =  + _REFACS_16_;
	O3050[1282] =  + _REFACS_21_;
	O3050[1283] =  + _REFACS_17_;
	O3050[1284] =  + _REFACS_20_;
	O3050[1285] =  + _REFACS_16_;
	O3050[1286] =  + _REFACS_18_;
	O3050[1287] =  + _REFACS_20_;
	{long i; for (i = 1288; i < 1291; i++) O3050[i] =  + _REFACS_16_;}
	{long i; for (i = 1291; i < 1293; i++) O3050[i] =  + _REFACS_17_;}
	O3050[1293] =  + _REFACS_20_;
	{long i; for (i = 1294; i < 1297; i++) O3050[i] =  + _REFACS_18_;}
	O3050[1297] =  + _REFACS_22_;
	O3050[1298] =  + _REFACS_18_;
	O3050[1299] =  + _REFACS_20_;
	{long i; for (i = 1300; i < 1305; i++) O3050[i] =  + _REFACS_17_;}
	O3050[1305] =  + _REFACS_19_;
	{long i; for (i = 1306; i < 1315; i++) O3050[i] =  + _REFACS_17_;}
	O3050[1346] =  + _REFACS_17_;
	O3050[1349] =  + _REFACS_17_;
	O3050[1351] =  + _REFACS_17_;
	O3050[1354] =  + _REFACS_17_;
}

long O3052[1355];
void O3052_init () {
	O3052[0] =  + _REFACS_8_;
	{long i; for (i = 1205; i < 1207; i++) O3052[i] =  + _REFACS_17_;}
	{long i; for (i = 1207; i < 1214; i++) O3052[i] =  + _REFACS_18_;}
	{long i; for (i = 1214; i < 1218; i++) O3052[i] =  + _REFACS_19_;}
	{long i; for (i = 1218; i < 1225; i++) O3052[i] =  + _REFACS_18_;}
	{long i; for (i = 1225; i < 1234; i++) O3052[i] =  + _REFACS_19_;}
	{long i; for (i = 1234; i < 1236; i++) O3052[i] =  + _REFACS_23_;}
	{long i; for (i = 1236; i < 1238; i++) O3052[i] =  + _REFACS_26_;}
	{long i; for (i = 1238; i < 1243; i++) O3052[i] =  + _REFACS_19_;}
	{long i; for (i = 1243; i < 1245; i++) O3052[i] =  + _REFACS_23_;}
	{long i; for (i = 1245; i < 1247; i++) O3052[i] =  + _REFACS_26_;}
	O3052[1247] =  + _REFACS_17_;
	O3052[1248] =  + _REFACS_22_;
	O3052[1249] =  + _REFACS_18_;
	O3052[1250] =  + _REFACS_21_;
	O3052[1251] =  + _REFACS_17_;
	O3052[1252] =  + _REFACS_19_;
	O3052[1253] =  + _REFACS_21_;
	{long i; for (i = 1254; i < 1257; i++) O3052[i] =  + _REFACS_17_;}
	{long i; for (i = 1257; i < 1259; i++) O3052[i] =  + _REFACS_18_;}
	O3052[1259] =  + _REFACS_21_;
	{long i; for (i = 1260; i < 1262; i++) O3052[i] =  + _REFACS_19_;}
	{long i; for (i = 1262; i < 1266; i++) O3052[i] =  + _REFACS_18_;}
	O3052[1266] =  + _REFACS_19_;
	O3052[1267] =  + _REFACS_23_;
	O3052[1268] =  + _REFACS_19_;
	O3052[1269] =  + _REFACS_21_;
	O3052[1270] =  + _REFACS_18_;
	O3052[1271] =  + _REFACS_20_;
	{long i; for (i = 1272; i < 1281; i++) O3052[i] =  + _REFACS_18_;}
	O3052[1281] =  + _REFACS_17_;
	O3052[1282] =  + _REFACS_22_;
	O3052[1283] =  + _REFACS_18_;
	O3052[1284] =  + _REFACS_21_;
	O3052[1285] =  + _REFACS_17_;
	O3052[1286] =  + _REFACS_19_;
	O3052[1287] =  + _REFACS_21_;
	{long i; for (i = 1288; i < 1291; i++) O3052[i] =  + _REFACS_17_;}
	{long i; for (i = 1291; i < 1293; i++) O3052[i] =  + _REFACS_18_;}
	O3052[1293] =  + _REFACS_21_;
	{long i; for (i = 1294; i < 1297; i++) O3052[i] =  + _REFACS_19_;}
	O3052[1297] =  + _REFACS_23_;
	O3052[1298] =  + _REFACS_19_;
	O3052[1299] =  + _REFACS_21_;
	{long i; for (i = 1300; i < 1305; i++) O3052[i] =  + _REFACS_18_;}
	O3052[1305] =  + _REFACS_20_;
	{long i; for (i = 1306; i < 1315; i++) O3052[i] =  + _REFACS_18_;}
	O3052[1346] =  + _REFACS_18_;
	O3052[1349] =  + _REFACS_18_;
	O3052[1351] =  + _REFACS_18_;
	O3052[1354] =  + _REFACS_18_;
}

long O3054[1355];
void O3054_init () {
	O3054[0] =  + _REFACS_9_;
	{long i; for (i = 1205; i < 1207; i++) O3054[i] =  + _REFACS_18_;}
	{long i; for (i = 1207; i < 1214; i++) O3054[i] =  + _REFACS_19_;}
	{long i; for (i = 1214; i < 1218; i++) O3054[i] =  + _REFACS_20_;}
	{long i; for (i = 1218; i < 1225; i++) O3054[i] =  + _REFACS_19_;}
	{long i; for (i = 1225; i < 1234; i++) O3054[i] =  + _REFACS_20_;}
	{long i; for (i = 1234; i < 1236; i++) O3054[i] =  + _REFACS_24_;}
	{long i; for (i = 1236; i < 1238; i++) O3054[i] =  + _REFACS_27_;}
	{long i; for (i = 1238; i < 1243; i++) O3054[i] =  + _REFACS_20_;}
	{long i; for (i = 1243; i < 1245; i++) O3054[i] =  + _REFACS_24_;}
	{long i; for (i = 1245; i < 1247; i++) O3054[i] =  + _REFACS_27_;}
	O3054[1247] =  + _REFACS_18_;
	O3054[1248] =  + _REFACS_23_;
	O3054[1249] =  + _REFACS_19_;
	O3054[1250] =  + _REFACS_22_;
	O3054[1251] =  + _REFACS_18_;
	O3054[1252] =  + _REFACS_20_;
	O3054[1253] =  + _REFACS_22_;
	{long i; for (i = 1254; i < 1257; i++) O3054[i] =  + _REFACS_18_;}
	{long i; for (i = 1257; i < 1259; i++) O3054[i] =  + _REFACS_19_;}
	O3054[1259] =  + _REFACS_22_;
	{long i; for (i = 1260; i < 1262; i++) O3054[i] =  + _REFACS_20_;}
	{long i; for (i = 1262; i < 1266; i++) O3054[i] =  + _REFACS_19_;}
	O3054[1266] =  + _REFACS_20_;
	O3054[1267] =  + _REFACS_24_;
	O3054[1268] =  + _REFACS_20_;
	O3054[1269] =  + _REFACS_22_;
	O3054[1270] =  + _REFACS_19_;
	O3054[1271] =  + _REFACS_21_;
	{long i; for (i = 1272; i < 1281; i++) O3054[i] =  + _REFACS_19_;}
	O3054[1281] =  + _REFACS_18_;
	O3054[1282] =  + _REFACS_23_;
	O3054[1283] =  + _REFACS_19_;
	O3054[1284] =  + _REFACS_22_;
	O3054[1285] =  + _REFACS_18_;
	O3054[1286] =  + _REFACS_20_;
	O3054[1287] =  + _REFACS_22_;
	{long i; for (i = 1288; i < 1291; i++) O3054[i] =  + _REFACS_18_;}
	{long i; for (i = 1291; i < 1293; i++) O3054[i] =  + _REFACS_19_;}
	O3054[1293] =  + _REFACS_22_;
	{long i; for (i = 1294; i < 1297; i++) O3054[i] =  + _REFACS_20_;}
	O3054[1297] =  + _REFACS_24_;
	O3054[1298] =  + _REFACS_20_;
	O3054[1299] =  + _REFACS_22_;
	{long i; for (i = 1300; i < 1305; i++) O3054[i] =  + _REFACS_19_;}
	O3054[1305] =  + _REFACS_21_;
	{long i; for (i = 1306; i < 1315; i++) O3054[i] =  + _REFACS_19_;}
	O3054[1346] =  + _REFACS_19_;
	O3054[1349] =  + _REFACS_19_;
	O3054[1351] =  + _REFACS_19_;
	O3054[1354] =  + _REFACS_19_;
}

long O3056[1355];
void O3056_init () {
	O3056[0] =  + _REFACS_10_;
	{long i; for (i = 1205; i < 1207; i++) O3056[i] =  + _REFACS_19_;}
	{long i; for (i = 1207; i < 1214; i++) O3056[i] =  + _REFACS_20_;}
	{long i; for (i = 1214; i < 1218; i++) O3056[i] =  + _REFACS_21_;}
	{long i; for (i = 1218; i < 1225; i++) O3056[i] =  + _REFACS_20_;}
	{long i; for (i = 1225; i < 1234; i++) O3056[i] =  + _REFACS_21_;}
	{long i; for (i = 1234; i < 1236; i++) O3056[i] =  + _REFACS_25_;}
	{long i; for (i = 1236; i < 1238; i++) O3056[i] =  + _REFACS_28_;}
	{long i; for (i = 1238; i < 1243; i++) O3056[i] =  + _REFACS_21_;}
	{long i; for (i = 1243; i < 1245; i++) O3056[i] =  + _REFACS_25_;}
	{long i; for (i = 1245; i < 1247; i++) O3056[i] =  + _REFACS_28_;}
	O3056[1247] =  + _REFACS_19_;
	O3056[1248] =  + _REFACS_24_;
	O3056[1249] =  + _REFACS_20_;
	O3056[1250] =  + _REFACS_23_;
	O3056[1251] =  + _REFACS_19_;
	O3056[1252] =  + _REFACS_21_;
	O3056[1253] =  + _REFACS_23_;
	{long i; for (i = 1254; i < 1257; i++) O3056[i] =  + _REFACS_19_;}
	{long i; for (i = 1257; i < 1259; i++) O3056[i] =  + _REFACS_20_;}
	O3056[1259] =  + _REFACS_23_;
	{long i; for (i = 1260; i < 1262; i++) O3056[i] =  + _REFACS_21_;}
	{long i; for (i = 1262; i < 1266; i++) O3056[i] =  + _REFACS_20_;}
	O3056[1266] =  + _REFACS_21_;
	O3056[1267] =  + _REFACS_25_;
	O3056[1268] =  + _REFACS_21_;
	O3056[1269] =  + _REFACS_23_;
	O3056[1270] =  + _REFACS_20_;
	O3056[1271] =  + _REFACS_22_;
	{long i; for (i = 1272; i < 1281; i++) O3056[i] =  + _REFACS_20_;}
	O3056[1281] =  + _REFACS_19_;
	O3056[1282] =  + _REFACS_24_;
	O3056[1283] =  + _REFACS_20_;
	O3056[1284] =  + _REFACS_23_;
	O3056[1285] =  + _REFACS_19_;
	O3056[1286] =  + _REFACS_21_;
	O3056[1287] =  + _REFACS_23_;
	{long i; for (i = 1288; i < 1291; i++) O3056[i] =  + _REFACS_19_;}
	{long i; for (i = 1291; i < 1293; i++) O3056[i] =  + _REFACS_20_;}
	O3056[1293] =  + _REFACS_23_;
	{long i; for (i = 1294; i < 1297; i++) O3056[i] =  + _REFACS_21_;}
	O3056[1297] =  + _REFACS_25_;
	O3056[1298] =  + _REFACS_21_;
	O3056[1299] =  + _REFACS_23_;
	{long i; for (i = 1300; i < 1305; i++) O3056[i] =  + _REFACS_20_;}
	O3056[1305] =  + _REFACS_22_;
	{long i; for (i = 1306; i < 1315; i++) O3056[i] =  + _REFACS_20_;}
	O3056[1346] =  + _REFACS_20_;
	O3056[1349] =  + _REFACS_20_;
	O3056[1351] =  + _REFACS_20_;
	O3056[1354] =  + _REFACS_20_;
}

long O3058[1355];
void O3058_init () {
	O3058[0] =  + _REFACS_11_;
	{long i; for (i = 1205; i < 1207; i++) O3058[i] =  + _REFACS_20_;}
	{long i; for (i = 1207; i < 1214; i++) O3058[i] =  + _REFACS_21_;}
	{long i; for (i = 1214; i < 1218; i++) O3058[i] =  + _REFACS_22_;}
	{long i; for (i = 1218; i < 1225; i++) O3058[i] =  + _REFACS_21_;}
	{long i; for (i = 1225; i < 1234; i++) O3058[i] =  + _REFACS_22_;}
	{long i; for (i = 1234; i < 1236; i++) O3058[i] =  + _REFACS_26_;}
	{long i; for (i = 1236; i < 1238; i++) O3058[i] =  + _REFACS_29_;}
	{long i; for (i = 1238; i < 1243; i++) O3058[i] =  + _REFACS_22_;}
	{long i; for (i = 1243; i < 1245; i++) O3058[i] =  + _REFACS_26_;}
	{long i; for (i = 1245; i < 1247; i++) O3058[i] =  + _REFACS_29_;}
	O3058[1247] =  + _REFACS_20_;
	O3058[1248] =  + _REFACS_25_;
	O3058[1249] =  + _REFACS_21_;
	O3058[1250] =  + _REFACS_24_;
	O3058[1251] =  + _REFACS_20_;
	O3058[1252] =  + _REFACS_22_;
	O3058[1253] =  + _REFACS_24_;
	{long i; for (i = 1254; i < 1257; i++) O3058[i] =  + _REFACS_20_;}
	{long i; for (i = 1257; i < 1259; i++) O3058[i] =  + _REFACS_21_;}
	O3058[1259] =  + _REFACS_24_;
	{long i; for (i = 1260; i < 1262; i++) O3058[i] =  + _REFACS_22_;}
	{long i; for (i = 1262; i < 1266; i++) O3058[i] =  + _REFACS_21_;}
	O3058[1266] =  + _REFACS_22_;
	O3058[1267] =  + _REFACS_26_;
	O3058[1268] =  + _REFACS_22_;
	O3058[1269] =  + _REFACS_24_;
	O3058[1270] =  + _REFACS_21_;
	O3058[1271] =  + _REFACS_23_;
	{long i; for (i = 1272; i < 1281; i++) O3058[i] =  + _REFACS_21_;}
	O3058[1281] =  + _REFACS_20_;
	O3058[1282] =  + _REFACS_25_;
	O3058[1283] =  + _REFACS_21_;
	O3058[1284] =  + _REFACS_24_;
	O3058[1285] =  + _REFACS_20_;
	O3058[1286] =  + _REFACS_22_;
	O3058[1287] =  + _REFACS_24_;
	{long i; for (i = 1288; i < 1291; i++) O3058[i] =  + _REFACS_20_;}
	{long i; for (i = 1291; i < 1293; i++) O3058[i] =  + _REFACS_21_;}
	O3058[1293] =  + _REFACS_24_;
	{long i; for (i = 1294; i < 1297; i++) O3058[i] =  + _REFACS_22_;}
	O3058[1297] =  + _REFACS_26_;
	O3058[1298] =  + _REFACS_22_;
	O3058[1299] =  + _REFACS_24_;
	{long i; for (i = 1300; i < 1305; i++) O3058[i] =  + _REFACS_21_;}
	O3058[1305] =  + _REFACS_23_;
	{long i; for (i = 1306; i < 1315; i++) O3058[i] =  + _REFACS_21_;}
	O3058[1346] =  + _REFACS_21_;
	O3058[1349] =  + _REFACS_21_;
	O3058[1351] =  + _REFACS_21_;
	O3058[1354] =  + _REFACS_21_;
}


#ifdef __cplusplus
}
#endif
