#include "epoly8.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2845[1308])();
void R2845_init () {
	R2845[0] = (char *(*)()) F253_3981;
	R2845[1307] = (char *(*)()) F1560_17145;
}

char *(*R2846[1308])();
void R2846_init () {
	R2846[0] = (char *(*)()) F253_3982;
	R2846[1307] = (char *(*)()) F1560_17146;
}

char *(*R2857[1307])();
void R2857_init () {
	R2857[0] = (char *(*)()) F254_4004;
	R2857[400] = (char *(*)()) F654_5298;
	{long i; for (i = 1302; i < 1306; i++) R2857[i] = (char *(*)()) F654_5298;}
	R2857[1306] = (char *(*)()) F141_2882;
}

char *(*R2858[1307])();
void R2858_init () {
	R2858[0] = (char *(*)()) F254_4005;
	R2858[400] = (char *(*)()) F654_5299;
	{long i; for (i = 1302; i < 1306; i++) R2858[i] = (char *(*)()) F654_5299;}
	R2858[1306] = (char *(*)()) F141_2881;
}

char *(*R2859[1307])();
void R2859_init () {
	R2859[0] = (char *(*)()) F254_4006;
	R2859[400] = (char *(*)()) F654_5300;
	{long i; for (i = 1302; i < 1306; i++) R2859[i] = (char *(*)()) F654_5300;}
	R2859[1306] = (char *(*)()) F141_2880;
}

char *(*R2988[13])();
void R2988_init () {
	R2988[0] = (char *(*)()) F1447_15363;
	R2988[12] = (char *(*)()) F1459_15630;
}

char *(*R3275[2])();
void R3275_init () {
	R3275[0] = (char *(*)()) F178_3349;
	R3275[1] = (char *(*)()) F179_3353;
}

char *(*R3277[2])();
void R3277_init () {
	R3277[0] = (char *(*)()) F178_3350;
	R3277[1] = (char *(*)()) F179_3354;
}

char *(*R3285[170])();
void R3285_init () {
	R3285[0] = (char *(*)()) F181_3357;
	R3285[1] = (char *(*)()) F182_3357_3285_1;
	R3285[2] = (char *(*)()) F183_3357_3285_1;
	R3285[3] = (char *(*)()) F184_3357_3285_1;
	R3285[4] = (char *(*)()) F185_3357_3285_1;
	R3285[5] = (char *(*)()) F181_3357;
	R3285[6] = (char *(*)()) F182_3357_3285_1;
	R3285[7] = (char *(*)()) F185_3357_3285_1;
	{long i; for (i = 168; i < 170; i++) R3285[i] = (char *(*)()) F181_3357;}
}
static EIF_REFERENCE F182_3357_3285_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F182_3357(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F183_3357_3285_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F183_3357(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1003, 0x00).id, 1003, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F184_3357_3285_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F184_3357(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F185_3357_3285_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F185_3357(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R3286[170])();
void R3286_init () {
	R3286[0] = (char *(*)()) F181_3358;
	R3286[1] = (char *(*)()) F182_3358_3286_4;
	R3286[2] = (char *(*)()) F183_3358_3286_4;
	R3286[3] = (char *(*)()) F184_3358_3286_4;
	R3286[4] = (char *(*)()) F185_3358_3286_4;
	R3286[5] = (char *(*)()) F181_3358;
	R3286[6] = (char *(*)()) F182_3358_3286_4;
	R3286[7] = (char *(*)()) F185_3358_3286_4;
	{long i; for (i = 168; i < 170; i++) R3286[i] = (char *(*)()) F181_3358;}
}
static void F182_3358_3286_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F182_3358(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F183_3358_3286_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F183_3358(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F184_3358_3286_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F184_3358(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F185_3358_3286_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F185_3358(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R3290[3])();
void R3290_init () {
	R3290[0] = (char *(*)()) F186_3361;
	R3290[1] = (char *(*)()) F187_3361;
	R3290[2] = (char *(*)()) F188_3361;
}

char *(*R3291[3])();
void R3291_init () {
	R3291[0] = (char *(*)()) F186_3362;
	R3291[1] = (char *(*)()) F187_3362;
	R3291[2] = (char *(*)()) F188_3362;
}

char *(*R3302[362])();
void R3302_init () {
	R3302[0] = (char *(*)()) F1206_11146;
	R3302[359] = (char *(*)()) F689_5744;
	R3302[361] = (char *(*)()) F689_5744;
}

char *(*R3378[40])();
void R3378_init () {
	R3378[0] = (char *(*)()) F198_3449;
	{long i; for (i = 1; i < 3; i++) R3378[i] = (char *(*)()) F199_3473;}
	R3378[5] = (char *(*)()) F203_3476;
	R3378[7] = (char *(*)()) F205_3478;
	R3378[8] = (char *(*)()) F206_3482;
	R3378[9] = (char *(*)()) F207_3488;
	R3378[11] = (char *(*)()) F209_3505;
	R3378[12] = (char *(*)()) F210_3507;
	R3378[13] = (char *(*)()) F211_3509;
	R3378[15] = (char *(*)()) F213_3511;
	R3378[16] = (char *(*)()) F214_3515;
	R3378[19] = (char *(*)()) F217_3517;
	R3378[20] = (char *(*)()) F218_3519;
	R3378[22] = (char *(*)()) F220_3523;
	R3378[23] = (char *(*)()) F221_3525;
	R3378[24] = (char *(*)()) F222_3531;
	R3378[26] = (char *(*)()) F224_3533;
	R3378[27] = (char *(*)()) F225_3535;
	R3378[28] = (char *(*)()) F226_3539;
	R3378[29] = (char *(*)()) F227_3543;
	R3378[31] = (char *(*)()) F229_3545;
	R3378[32] = (char *(*)()) F230_3547;
	R3378[34] = (char *(*)()) F232_3549;
	R3378[35] = (char *(*)()) F233_3551;
	R3378[36] = (char *(*)()) F234_3553;
	R3378[37] = (char *(*)()) F235_3555;
	R3378[38] = (char *(*)()) F236_3559;
	R3378[39] = (char *(*)()) F237_3561;
}

char *(*R3488[17])();
void R3488_init () {
	R3488[0] = (char *(*)()) F1443_15225;
	R3488[1] = (char *(*)()) F1444_15290;
	{long i; for (i = 3; i < 5; i++) R3488[i] = (char *(*)()) F1446_15344;}
	R3488[14] = (char *(*)()) F1456_15552;
	{long i; for (i = 15; i < 17; i++) R3488[i] = (char *(*)()) F1458_15617;}
}

char *(*R3490[17])();
void R3490_init () {
	R3490[0] = (char *(*)()) F239_3616;
	R3490[1] = (char *(*)()) F1444_15238;
	{long i; for (i = 3; i < 5; i++) R3490[i] = (char *(*)()) F1446_15317;}
	R3490[14] = (char *(*)()) F1457_15581;
	{long i; for (i = 15; i < 17; i++) R3490[i] = (char *(*)()) F1458_15623;}
}

char *(*R3765[3])();
void R3765_init () {
	R3765[0] = (char *(*)()) F244_3890;
	R3765[1] = (char *(*)()) F245_3890;
	R3765[2] = (char *(*)()) F246_3890;
}

char *(*R3774[1305])();
void R3774_init () {
	R3774[0] = (char *(*)()) F256_4039;
	R3774[707] = (char *(*)()) F963_8058;
	R3774[708] = (char *(*)()) F964_8102;
	R3774[743] = (char *(*)()) F999_8300;
	R3774[744] = (char *(*)()) F1000_8363_3774_2;
	R3774[745] = (char *(*)()) F1001_8363_3774_2;
	R3774[746] = (char *(*)()) F1002_8399;
	R3774[747] = (char *(*)()) F1003_8458_3774_2;
	R3774[748] = (char *(*)()) F1004_8458_3774_2;
	R3774[749] = (char *(*)()) F1005_8493;
	R3774[750] = (char *(*)()) F1006_8552_3774_2;
	R3774[751] = (char *(*)()) F1007_8552_3774_2;
	R3774[752] = (char *(*)()) F1008_8587;
	R3774[753] = (char *(*)()) F1009_8647_3774_2;
	R3774[754] = (char *(*)()) F1010_8647_3774_2;
	R3774[755] = (char *(*)()) F1011_8682;
	R3774[756] = (char *(*)()) F1012_8742_3774_2;
	R3774[757] = (char *(*)()) F1013_8742_3774_2;
	R3774[758] = (char *(*)()) F1014_8781;
	R3774[759] = (char *(*)()) F1015_8811_3774_2;
	R3774[760] = (char *(*)()) F1016_8811_3774_2;
	R3774[761] = (char *(*)()) F1017_8847;
	R3774[762] = (char *(*)()) F1018_8877_3774_2;
	R3774[763] = (char *(*)()) F1019_8877_3774_2;
	{long i; for (i = 764; i < 767; i++) R3774[i] = (char *(*)()) F1020_8908;}
	{long i; for (i = 767; i < 770; i++) R3774[i] = (char *(*)()) F1023_8948;}
	R3774[773] = (char *(*)()) F1029_9020;
	R3774[774] = (char *(*)()) F1030_9082_3774_2;
	R3774[775] = (char *(*)()) F1031_9082_3774_2;
	R3774[776] = (char *(*)()) F1032_9118;
	R3774[777] = (char *(*)()) F1033_9181_3774_2;
	R3774[778] = (char *(*)()) F1034_9181_3774_2;
	R3774[779] = (char *(*)()) F1035_9217;
	R3774[780] = (char *(*)()) F1036_9280_3774_2;
	R3774[781] = (char *(*)()) F1037_9280_3774_2;
	{long i; for (i = 826; i < 828; i++) R3774[i] = (char *(*)()) F1081_9552;}
	{long i; for (i = 829; i < 832; i++) R3774[i] = (char *(*)()) F1084_9720;}
	R3774[1299] = (char *(*)()) F1555_17033;
	R3774[1301] = (char *(*)()) F1557_17071;
	R3774[1304] = (char *(*)()) F1560_17152;
}
static EIF_BOOLEAN F1000_8363_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1000_8363(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1001_8363_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1001_8363(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1003_8458_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1003_8458(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1004_8458_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1004_8458(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1006_8552_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1006_8552(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1007_8552_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1007_8552(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1009_8647_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1009_8647(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1010_8647_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1010_8647(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1012_8742_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1012_8742(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1013_8742_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1013_8742(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1015_8811_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1015_8811(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1016_8811_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1016_8811(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1018_8877_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1018_8877(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1019_8877_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1019_8877(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1030_9082_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1030_9082(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1031_9082_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1031_9082(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1033_9181_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1033_9181(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1034_9181_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1034_9181(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1036_9280_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1036_9280(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1037_9280_3774_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1037_9280(Current, *(EIF_INTEGER_16 *)arg1);
}

char *(*R3885[1291])();
void R3885_init () {
	R3885[0] = (char *(*)()) F261_4062;
	R3885[1] = (char *(*)()) F262_4063;
	R3885[666] = (char *(*)()) F927_6946;
	R3885[1289] = (char *(*)()) F1550_16903;
	R3885[1290] = (char *(*)()) F1551_16931;
}

char *(*R4174[23])();
void R4174_init () {
	{long i; for (i = 0; i < 9; i++) R4174[i] = (char *(*)()) F275_4350;}
	R4174[9] = (char *(*)()) F285_4394;
	{long i; for (i = 10; i < 23; i++) R4174[i] = (char *(*)()) F275_4350;}
}

char *(*R4177[23])();
void R4177_init () {
	R4177[0] = (char *(*)()) F276_4359;
	R4177[1] = (char *(*)()) F277_4363;
	R4177[2] = (char *(*)()) F278_4367;
	R4177[3] = (char *(*)()) F279_4371;
	R4177[4] = (char *(*)()) F280_4375;
	R4177[5] = (char *(*)()) F281_4379;
	R4177[6] = (char *(*)()) F282_4383;
	R4177[7] = (char *(*)()) F283_4387;
	R4177[8] = (char *(*)()) F284_4391;
	R4177[9] = (char *(*)()) F285_4397;
	R4177[10] = (char *(*)()) F286_4404;
	R4177[11] = (char *(*)()) F287_4408;
	R4177[12] = (char *(*)()) F288_4412;
	R4177[13] = (char *(*)()) F289_4416;
	R4177[14] = (char *(*)()) F290_4420;
	R4177[15] = (char *(*)()) F291_4424;
	R4177[16] = (char *(*)()) F292_4428;
	R4177[17] = (char *(*)()) F293_4432;
	R4177[18] = (char *(*)()) F294_4436;
	R4177[19] = (char *(*)()) F295_4440;
	R4177[20] = (char *(*)()) F296_4444;
	R4177[21] = (char *(*)()) F297_4448;
	R4177[22] = (char *(*)()) F298_4452;
}

char *(*R4179[23])();
void R4179_init () {
	R4179[0] = (char *(*)()) F276_4356;
	R4179[1] = (char *(*)()) F277_4360;
	R4179[2] = (char *(*)()) F278_4364;
	R4179[3] = (char *(*)()) F279_4368;
	R4179[4] = (char *(*)()) F280_4372;
	R4179[5] = (char *(*)()) F281_4376;
	R4179[6] = (char *(*)()) F282_4380;
	R4179[7] = (char *(*)()) F283_4384;
	R4179[8] = (char *(*)()) F284_4388;
	R4179[9] = (char *(*)()) F285_4398;
	R4179[10] = (char *(*)()) F286_4401;
	R4179[11] = (char *(*)()) F287_4405;
	R4179[12] = (char *(*)()) F288_4409;
	R4179[13] = (char *(*)()) F289_4413;
	R4179[14] = (char *(*)()) F290_4417;
	R4179[15] = (char *(*)()) F291_4421;
	R4179[16] = (char *(*)()) F292_4425;
	R4179[17] = (char *(*)()) F293_4429;
	R4179[18] = (char *(*)()) F294_4433;
	R4179[19] = (char *(*)()) F295_4437;
	R4179[20] = (char *(*)()) F296_4441;
	R4179[21] = (char *(*)()) F297_4445;
	R4179[22] = (char *(*)()) F298_4449;
}


#ifdef __cplusplus
}
#endif
