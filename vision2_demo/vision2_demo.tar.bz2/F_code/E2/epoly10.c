#include "epoly10.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

EIF_TYPE_INDEX *Y4318_gen_type [3];
EIF_TYPE_INDEX Y4318 [3];
void Y4318_init (void)
{
	egc_routines_types [4318] = Y4318;
	egc_routines_gen_types [4318] = Y4318_gen_type;
	egc_routines_offset [4318] = 347;
	{long i; for (i = 0; i < 3; i++) Y4318[i] = 1033;};
}

char *(*R4414[1074])();
void R4414_init () {
	R4414[0] = (char *(*)()) F639_5065;
	R4414[1] = (char *(*)()) F640_5065_4414_1;
	R4414[2] = (char *(*)()) F641_5065_4414_1;
	R4414[3] = (char *(*)()) F639_5065;
	R4414[4] = (char *(*)()) F640_5065_4414_1;
	R4414[5] = (char *(*)()) F641_5065_4414_1;
	R4414[6] = (char *(*)()) F639_5065;
	R4414[25] = (char *(*)()) F664_5452;
	R4414[26] = (char *(*)()) F665_5452_4414_1;
	R4414[27] = (char *(*)()) F666_5452_4414_1;
	R4414[28] = (char *(*)()) F667_5452_4414_1;
	R4414[29] = (char *(*)()) F668_5452_4414_1;
	R4414[30] = (char *(*)()) F669_5452_4414_1;
	R4414[31] = (char *(*)()) F670_5452_4414_1;
	R4414[32] = (char *(*)()) F671_5452_4414_1;
	R4414[33] = (char *(*)()) F672_5452_4414_1;
	R4414[34] = (char *(*)()) F673_5452_4414_1;
	R4414[35] = (char *(*)()) F674_5452_4414_1;
	R4414[36] = (char *(*)()) F675_5452_4414_1;
	R4414[37] = (char *(*)()) F664_5452;
	R4414[38] = (char *(*)()) F671_5452_4414_1;
	R4414[39] = (char *(*)()) F669_5452_4414_1;
	R4414[40] = (char *(*)()) F664_5452;
	R4414[41] = (char *(*)()) F671_5452_4414_1;
	R4414[44] = (char *(*)()) F664_5452;
	R4414[45] = (char *(*)()) F671_5452_4414_1;
	R4414[46] = (char *(*)()) F664_5452;
	R4414[47] = (char *(*)()) F671_5452_4414_1;
	{long i; for (i = 48; i < 50; i++) R4414[i] = (char *(*)()) F664_5452;}
	R4414[66] = (char *(*)()) F705_5962;
	{long i; for (i = 68; i < 70; i++) R4414[i] = (char *(*)()) F482_4799_4414_1;}
	{long i; for (i = 174; i < 176; i++) R4414[i] = (char *(*)()) F664_5452;}
	{long i; for (i = 177; i < 199; i++) R4414[i] = (char *(*)()) F664_5452;}
	{long i; for (i = 296; i < 298; i++) R4414[i] = (char *(*)()) F934_7256_4414_1;}
	{long i; for (i = 306; i < 309; i++) R4414[i] = (char *(*)()) F664_5452;}
	R4414[500] = (char *(*)()) F1120_10288;
	R4414[529] = (char *(*)()) F664_5452;
	R4414[540] = (char *(*)()) F1120_10288;
	{long i; for (i = 547; i < 549; i++) R4414[i] = (char *(*)()) F1120_10288;}
	R4414[557] = (char *(*)()) F1195_10952;
	{long i; for (i = 562; i < 564; i++) R4414[i] = (char *(*)()) F1120_10288;}
	{long i; for (i = 565; i < 571; i++) R4414[i] = (char *(*)()) F1120_10288;}
	{long i; for (i = 601; i < 603; i++) R4414[i] = (char *(*)()) F1120_10288;}
	{long i; for (i = 604; i < 606; i++) R4414[i] = (char *(*)()) F1120_10288;}
	{long i; for (i = 615; i < 618; i++) R4414[i] = (char *(*)()) F1120_10288;}
	{long i; for (i = 622; i < 624; i++) R4414[i] = (char *(*)()) F1120_10288;}
	R4414[881] = (char *(*)()) F934_7256_4414_1;
	R4414[988] = (char *(*)()) F482_4799_4414_1;
	R4414[1070] = (char *(*)()) F1120_10288;
	{long i; for (i = 1072; i < 1074; i++) R4414[i] = (char *(*)()) F1120_10288;}
}
static EIF_REFERENCE F640_5065_4414_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F640_5065(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_5065_4414_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F641_5065(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5452_4414_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F665_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5452_4414_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F666_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1009, 0x00).id, 1009, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5452_4414_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F667_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1012, 0x00).id, 1012, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5452_4414_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F668_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1003, 0x00).id, 1003, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_5452_4414_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F669_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_5452_4414_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F670_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1018, 0x00).id, 1018, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F671_5452_4414_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F671_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F672_5452_4414_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F672_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F673_5452_4414_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F673_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F674_5452_4414_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F674_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F675_5452_4414_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F675_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F482_4799_4414_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F482_4799(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F934_7256_4414_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F934_7256(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4415[1074])();
void R4415_init () {
	R4415[0] = (char *(*)()) F639_5076;
	R4415[1] = (char *(*)()) F640_5076;
	R4415[2] = (char *(*)()) F641_5076;
	R4415[3] = (char *(*)()) F639_5076;
	R4415[4] = (char *(*)()) F640_5076;
	R4415[5] = (char *(*)()) F641_5076;
	R4415[6] = (char *(*)()) F639_5076;
	R4415[25] = (char *(*)()) F591_5028;
	R4415[26] = (char *(*)()) F592_5028;
	R4415[27] = (char *(*)()) F593_5028;
	R4415[28] = (char *(*)()) F594_5028;
	R4415[29] = (char *(*)()) F595_5028;
	R4415[30] = (char *(*)()) F596_5028;
	R4415[31] = (char *(*)()) F597_5028;
	R4415[32] = (char *(*)()) F598_5028;
	R4415[33] = (char *(*)()) F599_5028;
	R4415[34] = (char *(*)()) F600_5028;
	R4415[35] = (char *(*)()) F601_5028;
	R4415[36] = (char *(*)()) F602_5028;
	R4415[37] = (char *(*)()) F591_5028;
	R4415[38] = (char *(*)()) F598_5028;
	R4415[39] = (char *(*)()) F596_5028;
	R4415[40] = (char *(*)()) F591_5028;
	R4415[41] = (char *(*)()) F598_5028;
	R4415[44] = (char *(*)()) F591_5028;
	R4415[45] = (char *(*)()) F598_5028;
	R4415[46] = (char *(*)()) F591_5028;
	R4415[47] = (char *(*)()) F598_5028;
	{long i; for (i = 48; i < 50; i++) R4415[i] = (char *(*)()) F591_5028;}
	R4415[66] = (char *(*)()) F375_4757;
	{long i; for (i = 68; i < 70; i++) R4415[i] = (char *(*)()) F369_4749;}
	{long i; for (i = 174; i < 176; i++) R4415[i] = (char *(*)()) F591_5028;}
	{long i; for (i = 177; i < 199; i++) R4415[i] = (char *(*)()) F591_5028;}
	{long i; for (i = 296; i < 298; i++) R4415[i] = (char *(*)()) F934_7277;}
	{long i; for (i = 306; i < 309; i++) R4415[i] = (char *(*)()) F591_5028;}
	R4415[500] = (char *(*)()) F591_5028;
	R4415[529] = (char *(*)()) F591_5028;
	R4415[540] = (char *(*)()) F591_5028;
	{long i; for (i = 547; i < 549; i++) R4415[i] = (char *(*)()) F591_5028;}
	R4415[557] = (char *(*)()) F591_5028;
	{long i; for (i = 562; i < 564; i++) R4415[i] = (char *(*)()) F591_5028;}
	{long i; for (i = 565; i < 571; i++) R4415[i] = (char *(*)()) F591_5028;}
	{long i; for (i = 601; i < 603; i++) R4415[i] = (char *(*)()) F591_5028;}
	{long i; for (i = 604; i < 606; i++) R4415[i] = (char *(*)()) F591_5028;}
	{long i; for (i = 615; i < 618; i++) R4415[i] = (char *(*)()) F591_5028;}
	{long i; for (i = 622; i < 624; i++) R4415[i] = (char *(*)()) F591_5028;}
	R4415[881] = (char *(*)()) F934_7277;
	R4415[988] = (char *(*)()) F369_4749;
	R4415[1070] = (char *(*)()) F591_5028;
	{long i; for (i = 1072; i < 1074; i++) R4415[i] = (char *(*)()) F591_5028;}
}

char *(*R4416[1074])();
void R4416_init () {
	R4416[0] = (char *(*)()) F639_5082;
	R4416[1] = (char *(*)()) F640_5082;
	R4416[2] = (char *(*)()) F641_5082;
	R4416[3] = (char *(*)()) F639_5082;
	R4416[4] = (char *(*)()) F640_5082;
	R4416[5] = (char *(*)()) F641_5082;
	R4416[6] = (char *(*)()) F639_5082;
	R4416[25] = (char *(*)()) F664_5478;
	R4416[26] = (char *(*)()) F665_5478;
	R4416[27] = (char *(*)()) F666_5478;
	R4416[28] = (char *(*)()) F667_5478;
	R4416[29] = (char *(*)()) F668_5478;
	R4416[30] = (char *(*)()) F669_5478;
	R4416[31] = (char *(*)()) F670_5478;
	R4416[32] = (char *(*)()) F671_5478;
	R4416[33] = (char *(*)()) F672_5478;
	R4416[34] = (char *(*)()) F673_5478;
	R4416[35] = (char *(*)()) F674_5478;
	R4416[36] = (char *(*)()) F675_5478;
	R4416[37] = (char *(*)()) F664_5478;
	R4416[38] = (char *(*)()) F671_5478;
	R4416[39] = (char *(*)()) F669_5478;
	R4416[40] = (char *(*)()) F664_5478;
	R4416[41] = (char *(*)()) F671_5478;
	R4416[44] = (char *(*)()) F664_5478;
	R4416[45] = (char *(*)()) F671_5478;
	R4416[46] = (char *(*)()) F664_5478;
	R4416[47] = (char *(*)()) F671_5478;
	{long i; for (i = 48; i < 50; i++) R4416[i] = (char *(*)()) F664_5478;}
	R4416[66] = (char *(*)()) F705_5956;
	{long i; for (i = 68; i < 70; i++) R4416[i] = (char *(*)()) F482_4807;}
	{long i; for (i = 174; i < 176; i++) R4416[i] = (char *(*)()) F664_5478;}
	{long i; for (i = 177; i < 199; i++) R4416[i] = (char *(*)()) F664_5478;}
	{long i; for (i = 296; i < 298; i++) R4416[i] = (char *(*)()) F934_7332;}
	{long i; for (i = 306; i < 309; i++) R4416[i] = (char *(*)()) F664_5478;}
	R4416[500] = (char *(*)()) F1120_10298;
	R4416[529] = (char *(*)()) F664_5478;
	R4416[540] = (char *(*)()) F1120_10298;
	{long i; for (i = 547; i < 549; i++) R4416[i] = (char *(*)()) F1120_10298;}
	R4416[557] = (char *(*)()) F591_5021;
	{long i; for (i = 562; i < 564; i++) R4416[i] = (char *(*)()) F1120_10298;}
	{long i; for (i = 565; i < 571; i++) R4416[i] = (char *(*)()) F1120_10298;}
	{long i; for (i = 601; i < 603; i++) R4416[i] = (char *(*)()) F1120_10298;}
	{long i; for (i = 604; i < 606; i++) R4416[i] = (char *(*)()) F1120_10298;}
	{long i; for (i = 615; i < 618; i++) R4416[i] = (char *(*)()) F1120_10298;}
	{long i; for (i = 622; i < 624; i++) R4416[i] = (char *(*)()) F1120_10298;}
	R4416[881] = (char *(*)()) F934_7332;
	R4416[988] = (char *(*)()) F482_4807;
	R4416[1070] = (char *(*)()) F1120_10298;
	{long i; for (i = 1072; i < 1074; i++) R4416[i] = (char *(*)()) F1120_10298;}
}

char *(*R4422[1074])();
void R4422_init () {
	R4422[0] = (char *(*)()) F375_4760;
	R4422[1] = (char *(*)()) F383_4760_4422_4;
	R4422[2] = (char *(*)()) F381_4760_4422_4;
	R4422[3] = (char *(*)()) F375_4760;
	R4422[4] = (char *(*)()) F383_4760_4422_4;
	R4422[5] = (char *(*)()) F381_4760_4422_4;
	R4422[6] = (char *(*)()) F375_4760;
	R4422[25] = (char *(*)()) F664_5484;
	R4422[26] = (char *(*)()) F665_5484_4422_4;
	R4422[27] = (char *(*)()) F666_5484_4422_4;
	R4422[28] = (char *(*)()) F667_5484_4422_4;
	R4422[29] = (char *(*)()) F668_5484_4422_4;
	R4422[30] = (char *(*)()) F669_5484_4422_4;
	R4422[31] = (char *(*)()) F670_5484_4422_4;
	R4422[32] = (char *(*)()) F671_5484_4422_4;
	R4422[33] = (char *(*)()) F672_5484_4422_4;
	R4422[34] = (char *(*)()) F673_5484_4422_4;
	R4422[35] = (char *(*)()) F674_5484_4422_4;
	R4422[36] = (char *(*)()) F675_5484_4422_4;
	R4422[37] = (char *(*)()) F664_5484;
	R4422[38] = (char *(*)()) F671_5484_4422_4;
	R4422[39] = (char *(*)()) F669_5484_4422_4;
	R4422[40] = (char *(*)()) F664_5484;
	R4422[41] = (char *(*)()) F671_5484_4422_4;
	R4422[44] = (char *(*)()) F664_5484;
	R4422[45] = (char *(*)()) F671_5484_4422_4;
	R4422[46] = (char *(*)()) F664_5484;
	R4422[47] = (char *(*)()) F671_5484_4422_4;
	{long i; for (i = 48; i < 50; i++) R4422[i] = (char *(*)()) F664_5484;}
	R4422[66] = (char *(*)()) F375_4760;
	{long i; for (i = 68; i < 70; i++) R4422[i] = (char *(*)()) F369_4743_4422_4;}
	{long i; for (i = 174; i < 176; i++) R4422[i] = (char *(*)()) F664_5484;}
	{long i; for (i = 177; i < 199; i++) R4422[i] = (char *(*)()) F664_5484;}
	{long i; for (i = 296; i < 298; i++) R4422[i] = (char *(*)()) F377_4760_4422_4;}
	{long i; for (i = 306; i < 309; i++) R4422[i] = (char *(*)()) F664_5484;}
	R4422[500] = (char *(*)()) F375_4760;
	R4422[529] = (char *(*)()) F664_5484;
	R4422[540] = (char *(*)()) F375_4760;
	{long i; for (i = 547; i < 549; i++) R4422[i] = (char *(*)()) F375_4760;}
	R4422[557] = (char *(*)()) F375_4760;
	{long i; for (i = 562; i < 564; i++) R4422[i] = (char *(*)()) F375_4760;}
	{long i; for (i = 565; i < 571; i++) R4422[i] = (char *(*)()) F375_4760;}
	{long i; for (i = 601; i < 603; i++) R4422[i] = (char *(*)()) F375_4760;}
	{long i; for (i = 604; i < 606; i++) R4422[i] = (char *(*)()) F375_4760;}
	{long i; for (i = 615; i < 618; i++) R4422[i] = (char *(*)()) F375_4760;}
	{long i; for (i = 622; i < 624; i++) R4422[i] = (char *(*)()) F375_4760;}
	R4422[881] = (char *(*)()) F377_4760_4422_4;
	R4422[988] = (char *(*)()) F369_4743_4422_4;
	R4422[1070] = (char *(*)()) F375_4760;
	{long i; for (i = 1072; i < 1074; i++) R4422[i] = (char *(*)()) F375_4760;}
}
static void F383_4760_4422_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F383_4760(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F381_4760_4422_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F381_4760(Current, *(EIF_BOOLEAN *)arg1);
}
static void F665_5484_4422_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5484(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F666_5484_4422_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5484(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F667_5484_4422_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5484(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F668_5484_4422_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5484(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F669_5484_4422_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F669_5484(Current, *(EIF_BOOLEAN *)arg1);
}
static void F670_5484_4422_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F670_5484(Current, *(EIF_REAL_64 *)arg1);
}
static void F671_5484_4422_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F671_5484(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F672_5484_4422_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F672_5484(Current, *(EIF_POINTER *)arg1);
}
static void F673_5484_4422_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F673_5484(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F674_5484_4422_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F674_5484(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F675_5484_4422_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F675_5484(Current, *(EIF_REAL_32 *)arg1);
}
static void F369_4743_4422_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F369_4743(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F377_4760_4422_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F377_4760(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4423[1074])();
void R4423_init () {
	R4423[0] = (char *(*)()) F639_5068;
	R4423[1] = (char *(*)()) F640_5068;
	R4423[2] = (char *(*)()) F641_5068;
	R4423[3] = (char *(*)()) F639_5068;
	R4423[4] = (char *(*)()) F640_5068;
	R4423[5] = (char *(*)()) F641_5068;
	R4423[6] = (char *(*)()) F639_5068;
	R4423[25] = (char *(*)()) F664_5457;
	R4423[26] = (char *(*)()) F665_5457;
	R4423[27] = (char *(*)()) F666_5457;
	R4423[28] = (char *(*)()) F667_5457;
	R4423[29] = (char *(*)()) F668_5457;
	R4423[30] = (char *(*)()) F669_5457;
	R4423[31] = (char *(*)()) F670_5457;
	R4423[32] = (char *(*)()) F671_5457;
	R4423[33] = (char *(*)()) F672_5457;
	R4423[34] = (char *(*)()) F673_5457;
	R4423[35] = (char *(*)()) F674_5457;
	R4423[36] = (char *(*)()) F675_5457;
	R4423[37] = (char *(*)()) F664_5457;
	R4423[38] = (char *(*)()) F671_5457;
	R4423[39] = (char *(*)()) F669_5457;
	R4423[40] = (char *(*)()) F664_5457;
	R4423[41] = (char *(*)()) F671_5457;
	R4423[44] = (char *(*)()) F664_5457;
	R4423[45] = (char *(*)()) F671_5457;
	R4423[46] = (char *(*)()) F664_5457;
	R4423[47] = (char *(*)()) F671_5457;
	{long i; for (i = 48; i < 50; i++) R4423[i] = (char *(*)()) F664_5457;}
	{long i; for (i = 68; i < 70; i++) R4423[i] = (char *(*)()) F482_4798;}
	{long i; for (i = 174; i < 176; i++) R4423[i] = (char *(*)()) F664_5457;}
	{long i; for (i = 177; i < 199; i++) R4423[i] = (char *(*)()) F664_5457;}
	{long i; for (i = 296; i < 298; i++) R4423[i] = (char *(*)()) F934_7257;}
	{long i; for (i = 306; i < 309; i++) R4423[i] = (char *(*)()) F664_5457;}
	R4423[500] = (char *(*)()) F1120_10289;
	R4423[529] = (char *(*)()) F664_5457;
	R4423[540] = (char *(*)()) F1120_10289;
	{long i; for (i = 547; i < 549; i++) R4423[i] = (char *(*)()) F1120_10289;}
	R4423[557] = (char *(*)()) F1196_11027;
	{long i; for (i = 562; i < 564; i++) R4423[i] = (char *(*)()) F1120_10289;}
	{long i; for (i = 565; i < 571; i++) R4423[i] = (char *(*)()) F1120_10289;}
	{long i; for (i = 601; i < 603; i++) R4423[i] = (char *(*)()) F1120_10289;}
	{long i; for (i = 604; i < 606; i++) R4423[i] = (char *(*)()) F1120_10289;}
	{long i; for (i = 615; i < 618; i++) R4423[i] = (char *(*)()) F1120_10289;}
	{long i; for (i = 622; i < 624; i++) R4423[i] = (char *(*)()) F1120_10289;}
	R4423[881] = (char *(*)()) F934_7257;
	R4423[988] = (char *(*)()) F482_4798;
	R4423[1070] = (char *(*)()) F1120_10289;
	{long i; for (i = 1072; i < 1074; i++) R4423[i] = (char *(*)()) F1120_10289;}
}

char *(*R4426[1074])();
void R4426_init () {
	R4426[0] = (char *(*)()) F363_4747;
	R4426[1] = (char *(*)()) F369_4747;
	R4426[2] = (char *(*)()) F370_4747;
	R4426[3] = (char *(*)()) F363_4747;
	R4426[4] = (char *(*)()) F369_4747;
	R4426[5] = (char *(*)()) F370_4747;
	R4426[6] = (char *(*)()) F363_4747;
	R4426[25] = (char *(*)()) F363_4747;
	R4426[26] = (char *(*)()) F364_4747;
	R4426[27] = (char *(*)()) F366_4747;
	R4426[28] = (char *(*)()) F367_4747;
	R4426[29] = (char *(*)()) F368_4747;
	R4426[30] = (char *(*)()) F370_4747;
	R4426[31] = (char *(*)()) F371_4747;
	R4426[32] = (char *(*)()) F369_4747;
	R4426[33] = (char *(*)()) F372_4747;
	R4426[34] = (char *(*)()) F373_4747;
	R4426[35] = (char *(*)()) F365_4747;
	R4426[36] = (char *(*)()) F374_4747;
	R4426[37] = (char *(*)()) F363_4747;
	R4426[38] = (char *(*)()) F369_4747;
	R4426[39] = (char *(*)()) F370_4747;
	R4426[40] = (char *(*)()) F363_4747;
	R4426[41] = (char *(*)()) F369_4747;
	R4426[44] = (char *(*)()) F363_4747;
	R4426[45] = (char *(*)()) F369_4747;
	R4426[46] = (char *(*)()) F363_4747;
	R4426[47] = (char *(*)()) F369_4747;
	{long i; for (i = 48; i < 50; i++) R4426[i] = (char *(*)()) F363_4747;}
	R4426[66] = (char *(*)()) F363_4747;
	{long i; for (i = 68; i < 70; i++) R4426[i] = (char *(*)()) F369_4747;}
	{long i; for (i = 174; i < 176; i++) R4426[i] = (char *(*)()) F363_4747;}
	{long i; for (i = 177; i < 199; i++) R4426[i] = (char *(*)()) F363_4747;}
	{long i; for (i = 296; i < 298; i++) R4426[i] = (char *(*)()) F365_4747;}
	{long i; for (i = 306; i < 309; i++) R4426[i] = (char *(*)()) F363_4747;}
	R4426[500] = (char *(*)()) F363_4747;
	R4426[529] = (char *(*)()) F363_4747;
	R4426[540] = (char *(*)()) F363_4747;
	{long i; for (i = 547; i < 549; i++) R4426[i] = (char *(*)()) F363_4747;}
	R4426[557] = (char *(*)()) F363_4747;
	{long i; for (i = 562; i < 564; i++) R4426[i] = (char *(*)()) F363_4747;}
	{long i; for (i = 565; i < 571; i++) R4426[i] = (char *(*)()) F363_4747;}
	{long i; for (i = 601; i < 603; i++) R4426[i] = (char *(*)()) F363_4747;}
	{long i; for (i = 604; i < 606; i++) R4426[i] = (char *(*)()) F363_4747;}
	{long i; for (i = 615; i < 618; i++) R4426[i] = (char *(*)()) F363_4747;}
	{long i; for (i = 622; i < 624; i++) R4426[i] = (char *(*)()) F363_4747;}
	R4426[881] = (char *(*)()) F365_4747;
	R4426[988] = (char *(*)()) F369_4747;
	R4426[1070] = (char *(*)()) F363_4747;
	{long i; for (i = 1072; i < 1074; i++) R4426[i] = (char *(*)()) F363_4747;}
}

char *(*R4427[1074])();
void R4427_init () {
	R4427[0] = (char *(*)()) F639_5074;
	R4427[1] = (char *(*)()) F640_5074;
	R4427[2] = (char *(*)()) F641_5074;
	R4427[3] = (char *(*)()) F639_5074;
	R4427[4] = (char *(*)()) F640_5074;
	R4427[5] = (char *(*)()) F641_5074;
	R4427[6] = (char *(*)()) F639_5074;
	R4427[25] = (char *(*)()) F615_5052;
	R4427[26] = (char *(*)()) F616_5052;
	R4427[27] = (char *(*)()) F617_5052;
	R4427[28] = (char *(*)()) F618_5052;
	R4427[29] = (char *(*)()) F619_5052;
	R4427[30] = (char *(*)()) F620_5052;
	R4427[31] = (char *(*)()) F621_5052;
	R4427[32] = (char *(*)()) F622_5052;
	R4427[33] = (char *(*)()) F623_5052;
	R4427[34] = (char *(*)()) F624_5052;
	R4427[35] = (char *(*)()) F625_5052;
	R4427[36] = (char *(*)()) F626_5052;
	R4427[37] = (char *(*)()) F615_5052;
	R4427[38] = (char *(*)()) F622_5052;
	R4427[39] = (char *(*)()) F620_5052;
	R4427[40] = (char *(*)()) F615_5052;
	R4427[41] = (char *(*)()) F622_5052;
	R4427[44] = (char *(*)()) F615_5052;
	R4427[45] = (char *(*)()) F622_5052;
	R4427[46] = (char *(*)()) F615_5052;
	R4427[47] = (char *(*)()) F622_5052;
	{long i; for (i = 48; i < 50; i++) R4427[i] = (char *(*)()) F615_5052;}
	R4427[66] = (char *(*)()) F705_5957;
	{long i; for (i = 68; i < 70; i++) R4427[i] = (char *(*)()) F482_4800;}
	{long i; for (i = 174; i < 176; i++) R4427[i] = (char *(*)()) F615_5052;}
	{long i; for (i = 177; i < 199; i++) R4427[i] = (char *(*)()) F615_5052;}
	{long i; for (i = 296; i < 298; i++) R4427[i] = (char *(*)()) F934_7275;}
	{long i; for (i = 306; i < 309; i++) R4427[i] = (char *(*)()) F615_5052;}
	R4427[500] = (char *(*)()) F615_5052;
	R4427[529] = (char *(*)()) F615_5052;
	R4427[540] = (char *(*)()) F615_5052;
	{long i; for (i = 547; i < 549; i++) R4427[i] = (char *(*)()) F615_5052;}
	R4427[557] = (char *(*)()) F1196_11028;
	{long i; for (i = 562; i < 564; i++) R4427[i] = (char *(*)()) F615_5052;}
	{long i; for (i = 565; i < 571; i++) R4427[i] = (char *(*)()) F615_5052;}
	{long i; for (i = 601; i < 603; i++) R4427[i] = (char *(*)()) F615_5052;}
	{long i; for (i = 604; i < 606; i++) R4427[i] = (char *(*)()) F615_5052;}
	{long i; for (i = 615; i < 618; i++) R4427[i] = (char *(*)()) F615_5052;}
	{long i; for (i = 622; i < 624; i++) R4427[i] = (char *(*)()) F615_5052;}
	R4427[881] = (char *(*)()) F934_7275;
	R4427[988] = (char *(*)()) F482_4800;
	R4427[1070] = (char *(*)()) F615_5052;
	{long i; for (i = 1072; i < 1074; i++) R4427[i] = (char *(*)()) F615_5052;}
}

char *(*R4428[1074])();
void R4428_init () {
	R4428[0] = (char *(*)()) F639_5083;
	R4428[1] = (char *(*)()) F640_5083;
	R4428[2] = (char *(*)()) F641_5083;
	R4428[3] = (char *(*)()) F639_5083;
	R4428[4] = (char *(*)()) F640_5083;
	R4428[5] = (char *(*)()) F641_5083;
	R4428[6] = (char *(*)()) F639_5083;
	R4428[25] = (char *(*)()) F664_5479;
	R4428[26] = (char *(*)()) F665_5479;
	R4428[27] = (char *(*)()) F666_5479;
	R4428[28] = (char *(*)()) F667_5479;
	R4428[29] = (char *(*)()) F668_5479;
	R4428[30] = (char *(*)()) F669_5479;
	R4428[31] = (char *(*)()) F670_5479;
	R4428[32] = (char *(*)()) F671_5479;
	R4428[33] = (char *(*)()) F672_5479;
	R4428[34] = (char *(*)()) F673_5479;
	R4428[35] = (char *(*)()) F674_5479;
	R4428[36] = (char *(*)()) F675_5479;
	R4428[37] = (char *(*)()) F664_5479;
	R4428[38] = (char *(*)()) F671_5479;
	R4428[39] = (char *(*)()) F669_5479;
	R4428[40] = (char *(*)()) F664_5479;
	R4428[41] = (char *(*)()) F671_5479;
	R4428[44] = (char *(*)()) F664_5479;
	R4428[45] = (char *(*)()) F671_5479;
	R4428[46] = (char *(*)()) F664_5479;
	R4428[47] = (char *(*)()) F671_5479;
	{long i; for (i = 48; i < 50; i++) R4428[i] = (char *(*)()) F664_5479;}
	{long i; for (i = 174; i < 176; i++) R4428[i] = (char *(*)()) F664_5479;}
	{long i; for (i = 177; i < 199; i++) R4428[i] = (char *(*)()) F664_5479;}
	{long i; for (i = 306; i < 309; i++) R4428[i] = (char *(*)()) F664_5479;}
	R4428[500] = (char *(*)()) F591_5022;
	R4428[529] = (char *(*)()) F664_5479;
	R4428[540] = (char *(*)()) F591_5022;
	{long i; for (i = 547; i < 549; i++) R4428[i] = (char *(*)()) F591_5022;}
	R4428[557] = (char *(*)()) F591_5022;
	{long i; for (i = 562; i < 564; i++) R4428[i] = (char *(*)()) F591_5022;}
	{long i; for (i = 565; i < 571; i++) R4428[i] = (char *(*)()) F591_5022;}
	{long i; for (i = 601; i < 603; i++) R4428[i] = (char *(*)()) F591_5022;}
	{long i; for (i = 604; i < 606; i++) R4428[i] = (char *(*)()) F591_5022;}
	{long i; for (i = 615; i < 618; i++) R4428[i] = (char *(*)()) F591_5022;}
	{long i; for (i = 622; i < 624; i++) R4428[i] = (char *(*)()) F591_5022;}
	R4428[1070] = (char *(*)()) F591_5022;
	{long i; for (i = 1072; i < 1074; i++) R4428[i] = (char *(*)()) F591_5022;}
}

char *(*R4429[1074])();
void R4429_init () {
	R4429[0] = (char *(*)()) F639_5084;
	R4429[1] = (char *(*)()) F640_5084;
	R4429[2] = (char *(*)()) F641_5084;
	R4429[3] = (char *(*)()) F639_5084;
	R4429[4] = (char *(*)()) F640_5084;
	R4429[5] = (char *(*)()) F641_5084;
	R4429[6] = (char *(*)()) F639_5084;
	R4429[25] = (char *(*)()) F664_5480;
	R4429[26] = (char *(*)()) F665_5480;
	R4429[27] = (char *(*)()) F666_5480;
	R4429[28] = (char *(*)()) F667_5480;
	R4429[29] = (char *(*)()) F668_5480;
	R4429[30] = (char *(*)()) F669_5480;
	R4429[31] = (char *(*)()) F670_5480;
	R4429[32] = (char *(*)()) F671_5480;
	R4429[33] = (char *(*)()) F672_5480;
	R4429[34] = (char *(*)()) F673_5480;
	R4429[35] = (char *(*)()) F674_5480;
	R4429[36] = (char *(*)()) F675_5480;
	R4429[37] = (char *(*)()) F664_5480;
	R4429[38] = (char *(*)()) F671_5480;
	R4429[39] = (char *(*)()) F669_5480;
	R4429[40] = (char *(*)()) F664_5480;
	R4429[41] = (char *(*)()) F671_5480;
	R4429[44] = (char *(*)()) F664_5480;
	R4429[45] = (char *(*)()) F671_5480;
	R4429[46] = (char *(*)()) F664_5480;
	R4429[47] = (char *(*)()) F671_5480;
	{long i; for (i = 48; i < 50; i++) R4429[i] = (char *(*)()) F664_5480;}
	R4429[66] = (char *(*)()) F705_5959;
	{long i; for (i = 68; i < 70; i++) R4429[i] = (char *(*)()) F482_4806;}
	{long i; for (i = 174; i < 176; i++) R4429[i] = (char *(*)()) F664_5480;}
	{long i; for (i = 177; i < 199; i++) R4429[i] = (char *(*)()) F664_5480;}
	{long i; for (i = 296; i < 298; i++) R4429[i] = (char *(*)()) F934_7334;}
	{long i; for (i = 306; i < 309; i++) R4429[i] = (char *(*)()) F664_5480;}
	R4429[500] = (char *(*)()) F1120_10300;
	R4429[529] = (char *(*)()) F664_5480;
	R4429[540] = (char *(*)()) F1120_10300;
	{long i; for (i = 547; i < 549; i++) R4429[i] = (char *(*)()) F1120_10300;}
	R4429[557] = (char *(*)()) F1196_11029;
	{long i; for (i = 562; i < 564; i++) R4429[i] = (char *(*)()) F1120_10300;}
	{long i; for (i = 565; i < 571; i++) R4429[i] = (char *(*)()) F1120_10300;}
	{long i; for (i = 601; i < 603; i++) R4429[i] = (char *(*)()) F1120_10300;}
	{long i; for (i = 604; i < 606; i++) R4429[i] = (char *(*)()) F1120_10300;}
	{long i; for (i = 615; i < 618; i++) R4429[i] = (char *(*)()) F1120_10300;}
	{long i; for (i = 622; i < 624; i++) R4429[i] = (char *(*)()) F1120_10300;}
	R4429[881] = (char *(*)()) F934_7334;
	R4429[988] = (char *(*)()) F482_4806;
	R4429[1070] = (char *(*)()) F1120_10300;
	{long i; for (i = 1072; i < 1074; i++) R4429[i] = (char *(*)()) F1120_10300;}
}

char *(*R4430[1074])();
void R4430_init () {
	R4430[0] = (char *(*)()) F639_5075;
	R4430[1] = (char *(*)()) F640_5075;
	R4430[2] = (char *(*)()) F641_5075;
	R4430[3] = (char *(*)()) F639_5075;
	R4430[4] = (char *(*)()) F640_5075;
	R4430[5] = (char *(*)()) F641_5075;
	R4430[6] = (char *(*)()) F639_5075;
	R4430[25] = (char *(*)()) F615_5053;
	R4430[26] = (char *(*)()) F616_5053;
	R4430[27] = (char *(*)()) F617_5053;
	R4430[28] = (char *(*)()) F618_5053;
	R4430[29] = (char *(*)()) F619_5053;
	R4430[30] = (char *(*)()) F620_5053;
	R4430[31] = (char *(*)()) F621_5053;
	R4430[32] = (char *(*)()) F622_5053;
	R4430[33] = (char *(*)()) F623_5053;
	R4430[34] = (char *(*)()) F624_5053;
	R4430[35] = (char *(*)()) F625_5053;
	R4430[36] = (char *(*)()) F626_5053;
	R4430[37] = (char *(*)()) F615_5053;
	R4430[38] = (char *(*)()) F622_5053;
	R4430[39] = (char *(*)()) F620_5053;
	R4430[40] = (char *(*)()) F615_5053;
	R4430[41] = (char *(*)()) F622_5053;
	R4430[44] = (char *(*)()) F615_5053;
	R4430[45] = (char *(*)()) F622_5053;
	R4430[46] = (char *(*)()) F615_5053;
	R4430[47] = (char *(*)()) F622_5053;
	{long i; for (i = 48; i < 50; i++) R4430[i] = (char *(*)()) F615_5053;}
	R4430[66] = (char *(*)()) F705_5960;
	{long i; for (i = 174; i < 176; i++) R4430[i] = (char *(*)()) F615_5053;}
	{long i; for (i = 177; i < 199; i++) R4430[i] = (char *(*)()) F615_5053;}
	{long i; for (i = 296; i < 298; i++) R4430[i] = (char *(*)()) F934_7276;}
	{long i; for (i = 306; i < 309; i++) R4430[i] = (char *(*)()) F615_5053;}
	R4430[500] = (char *(*)()) F615_5053;
	R4430[529] = (char *(*)()) F615_5053;
	R4430[540] = (char *(*)()) F615_5053;
	{long i; for (i = 547; i < 549; i++) R4430[i] = (char *(*)()) F615_5053;}
	R4430[557] = (char *(*)()) F1196_11026;
	{long i; for (i = 562; i < 564; i++) R4430[i] = (char *(*)()) F615_5053;}
	{long i; for (i = 565; i < 571; i++) R4430[i] = (char *(*)()) F615_5053;}
	{long i; for (i = 601; i < 603; i++) R4430[i] = (char *(*)()) F615_5053;}
	{long i; for (i = 604; i < 606; i++) R4430[i] = (char *(*)()) F615_5053;}
	{long i; for (i = 615; i < 618; i++) R4430[i] = (char *(*)()) F615_5053;}
	{long i; for (i = 622; i < 624; i++) R4430[i] = (char *(*)()) F615_5053;}
	R4430[881] = (char *(*)()) F934_7276;
	R4430[1070] = (char *(*)()) F615_5053;
	{long i; for (i = 1072; i < 1074; i++) R4430[i] = (char *(*)()) F615_5053;}
}


#ifdef __cplusplus
}
#endif
