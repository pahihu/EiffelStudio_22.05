#include "epoly11.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4431[1049])();
void R4431_init () {
	R4431[0] = (char *(*)()) F664_5481;
	R4431[1] = (char *(*)()) F665_5481;
	R4431[2] = (char *(*)()) F666_5481;
	R4431[3] = (char *(*)()) F667_5481;
	R4431[4] = (char *(*)()) F668_5481;
	R4431[5] = (char *(*)()) F669_5481;
	R4431[6] = (char *(*)()) F670_5481;
	R4431[7] = (char *(*)()) F671_5481;
	R4431[8] = (char *(*)()) F672_5481;
	R4431[9] = (char *(*)()) F673_5481;
	R4431[10] = (char *(*)()) F674_5481;
	R4431[11] = (char *(*)()) F675_5481;
	R4431[12] = (char *(*)()) F664_5481;
	R4431[13] = (char *(*)()) F671_5481;
	R4431[14] = (char *(*)()) F669_5481;
	R4431[15] = (char *(*)()) F664_5481;
	R4431[16] = (char *(*)()) F671_5481;
	R4431[19] = (char *(*)()) F664_5481;
	R4431[20] = (char *(*)()) F671_5481;
	R4431[21] = (char *(*)()) F664_5481;
	R4431[22] = (char *(*)()) F671_5481;
	{long i; for (i = 23; i < 25; i++) R4431[i] = (char *(*)()) F664_5481;}
	{long i; for (i = 149; i < 151; i++) R4431[i] = (char *(*)()) F664_5481;}
	{long i; for (i = 152; i < 174; i++) R4431[i] = (char *(*)()) F664_5481;}
	{long i; for (i = 271; i < 273; i++) R4431[i] = (char *(*)()) F934_7335;}
	{long i; for (i = 281; i < 284; i++) R4431[i] = (char *(*)()) F664_5481;}
	R4431[475] = (char *(*)()) F1120_10299;
	R4431[504] = (char *(*)()) F664_5481;
	R4431[515] = (char *(*)()) F1120_10299;
	{long i; for (i = 522; i < 524; i++) R4431[i] = (char *(*)()) F1120_10299;}
	{long i; for (i = 537; i < 539; i++) R4431[i] = (char *(*)()) F1120_10299;}
	{long i; for (i = 540; i < 546; i++) R4431[i] = (char *(*)()) F1120_10299;}
	{long i; for (i = 576; i < 578; i++) R4431[i] = (char *(*)()) F1120_10299;}
	{long i; for (i = 579; i < 581; i++) R4431[i] = (char *(*)()) F1120_10299;}
	{long i; for (i = 590; i < 593; i++) R4431[i] = (char *(*)()) F1120_10299;}
	{long i; for (i = 597; i < 599; i++) R4431[i] = (char *(*)()) F1120_10299;}
	R4431[856] = (char *(*)()) F1520_16507;
	R4431[1045] = (char *(*)()) F1120_10299;
	{long i; for (i = 1047; i < 1049; i++) R4431[i] = (char *(*)()) F1120_10299;}
}

char *(*R4432[1179])();
void R4432_init () {
	R4432[0] = (char *(*)()) F535_4850;
	{long i; for (i = 41; i < 43; i++) R4432[i] = (char *(*)()) F576_4900;}
	R4432[43] = (char *(*)()) F578_4954;
	R4432[44] = (char *(*)()) F579_4954;
	R4432[45] = (char *(*)()) F580_4954;
	R4432[46] = (char *(*)()) F581_4954;
	R4432[47] = (char *(*)()) F582_4954;
	R4432[48] = (char *(*)()) F583_4954;
	R4432[49] = (char *(*)()) F584_4954;
	R4432[50] = (char *(*)()) F585_4954;
	R4432[51] = (char *(*)()) F586_4954;
	R4432[52] = (char *(*)()) F587_4954;
	R4432[53] = (char *(*)()) F588_4954;
	R4432[54] = (char *(*)()) F589_4954;
	R4432[55] = (char *(*)()) F581_4954;
	R4432[104] = (char *(*)()) F603_5037;
	R4432[105] = (char *(*)()) F610_5037;
	R4432[106] = (char *(*)()) F608_5037;
	R4432[107] = (char *(*)()) F603_5037;
	R4432[108] = (char *(*)()) F610_5037;
	R4432[109] = (char *(*)()) F608_5037;
	R4432[110] = (char *(*)()) F603_5037;
	R4432[118] = (char *(*)()) F653_5277;
	R4432[120] = (char *(*)()) F655_5343;
	R4432[121] = (char *(*)()) F656_5343;
	R4432[122] = (char *(*)()) F657_5343;
	R4432[123] = (char *(*)()) F658_5343;
	R4432[124] = (char *(*)()) F659_5343;
	R4432[125] = (char *(*)()) F660_5343;
	R4432[126] = (char *(*)()) F655_5343;
	R4432[127] = (char *(*)()) F657_5343;
	R4432[128] = (char *(*)()) F655_5343;
	R4432[129] = (char *(*)()) F603_5037;
	R4432[130] = (char *(*)()) F604_5037;
	R4432[131] = (char *(*)()) F605_5037;
	R4432[132] = (char *(*)()) F606_5037;
	R4432[133] = (char *(*)()) F607_5037;
	R4432[134] = (char *(*)()) F608_5037;
	R4432[135] = (char *(*)()) F609_5037;
	R4432[136] = (char *(*)()) F610_5037;
	R4432[137] = (char *(*)()) F611_5037;
	R4432[138] = (char *(*)()) F612_5037;
	R4432[139] = (char *(*)()) F613_5037;
	R4432[140] = (char *(*)()) F614_5037;
	R4432[141] = (char *(*)()) F603_5037;
	R4432[142] = (char *(*)()) F610_5037;
	R4432[143] = (char *(*)()) F608_5037;
	R4432[144] = (char *(*)()) F603_5037;
	R4432[145] = (char *(*)()) F610_5037;
	R4432[148] = (char *(*)()) F603_5037;
	R4432[149] = (char *(*)()) F610_5037;
	R4432[150] = (char *(*)()) F603_5037;
	R4432[151] = (char *(*)()) F610_5037;
	{long i; for (i = 152; i < 154; i++) R4432[i] = (char *(*)()) F603_5037;}
	{long i; for (i = 172; i < 174; i++) R4432[i] = (char *(*)()) F482_4801;}
	{long i; for (i = 278; i < 280; i++) R4432[i] = (char *(*)()) F603_5037;}
	{long i; for (i = 281; i < 303; i++) R4432[i] = (char *(*)()) F603_5037;}
	{long i; for (i = 400; i < 402; i++) R4432[i] = (char *(*)()) F934_7308;}
	{long i; for (i = 410; i < 413; i++) R4432[i] = (char *(*)()) F603_5037;}
	R4432[548] = (char *(*)()) F1083_9610;
	{long i; for (i = 551; i < 553; i++) R4432[i] = (char *(*)()) F1086_9775;}
	R4432[604] = (char *(*)()) F603_5037;
	R4432[633] = (char *(*)()) F603_5037;
	R4432[644] = (char *(*)()) F603_5037;
	{long i; for (i = 651; i < 653; i++) R4432[i] = (char *(*)()) F603_5037;}
	R4432[661] = (char *(*)()) F1196_11007;
	{long i; for (i = 663; i < 665; i++) R4432[i] = (char *(*)()) F1197_11043;}
	{long i; for (i = 666; i < 668; i++) R4432[i] = (char *(*)()) F603_5037;}
	{long i; for (i = 669; i < 675; i++) R4432[i] = (char *(*)()) F603_5037;}
	{long i; for (i = 675; i < 680; i++) R4432[i] = (char *(*)()) F1210_11191;}
	{long i; for (i = 681; i < 690; i++) R4432[i] = (char *(*)()) F1210_11191;}
	{long i; for (i = 691; i < 694; i++) R4432[i] = (char *(*)()) F1210_11191;}
	R4432[695] = (char *(*)()) F1210_11191;
	R4432[697] = (char *(*)()) F1210_11191;
	{long i; for (i = 699; i < 704; i++) R4432[i] = (char *(*)()) F1210_11191;}
	{long i; for (i = 705; i < 707; i++) R4432[i] = (char *(*)()) F603_5037;}
	{long i; for (i = 708; i < 710; i++) R4432[i] = (char *(*)()) F603_5037;}
	{long i; for (i = 719; i < 722; i++) R4432[i] = (char *(*)()) F603_5037;}
	{long i; for (i = 726; i < 728; i++) R4432[i] = (char *(*)()) F603_5037;}
	R4432[985] = (char *(*)()) F934_7308;
	R4432[1092] = (char *(*)()) F482_4801;
	R4432[1169] = (char *(*)()) F1210_11191;
	R4432[1174] = (char *(*)()) F603_5037;
	{long i; for (i = 1176; i < 1178; i++) R4432[i] = (char *(*)()) F603_5037;}
	R4432[1178] = (char *(*)()) F1210_11191;
}

char *(*R4433[1075])();
void R4433_init () {
	R4433[0] = (char *(*)()) F429_4783;
	R4433[1] = (char *(*)()) F437_4783;
	R4433[2] = (char *(*)()) F434_4783;
	R4433[3] = (char *(*)()) F429_4783;
	R4433[4] = (char *(*)()) F437_4783;
	R4433[5] = (char *(*)()) F434_4783;
	R4433[6] = (char *(*)()) F429_4783;
	R4433[16] = (char *(*)()) F428_4783;
	R4433[17] = (char *(*)()) F429_4783;
	R4433[18] = (char *(*)()) F436_4783;
	R4433[19] = (char *(*)()) F443_4783;
	R4433[20] = (char *(*)()) F437_4783;
	R4433[21] = (char *(*)()) F438_4783;
	R4433[22] = (char *(*)()) F428_4783;
	R4433[23] = (char *(*)()) F436_4783;
	R4433[24] = (char *(*)()) F428_4783;
	R4433[444] = (char *(*)()) F440_4783;
	{long i; for (i = 447; i < 449; i++) R4433[i] = (char *(*)()) F441_4783;}
	R4433[500] = (char *(*)()) F429_4783;
	R4433[540] = (char *(*)()) F429_4783;
	{long i; for (i = 547; i < 549; i++) R4433[i] = (char *(*)()) F429_4783;}
	R4433[557] = (char *(*)()) F1196_11006;
	{long i; for (i = 559; i < 561; i++) R4433[i] = (char *(*)()) F1197_11047;}
	{long i; for (i = 562; i < 564; i++) R4433[i] = (char *(*)()) F429_4783;}
	{long i; for (i = 565; i < 571; i++) R4433[i] = (char *(*)()) F429_4783;}
	R4433[571] = (char *(*)()) F1210_11193;
	R4433[572] = (char *(*)()) F1211_11337;
	{long i; for (i = 573; i < 576; i++) R4433[i] = (char *(*)()) F1210_11193;}
	{long i; for (i = 577; i < 586; i++) R4433[i] = (char *(*)()) F1210_11193;}
	{long i; for (i = 587; i < 590; i++) R4433[i] = (char *(*)()) F1210_11193;}
	R4433[591] = (char *(*)()) F1210_11193;
	R4433[593] = (char *(*)()) F1210_11193;
	{long i; for (i = 595; i < 600; i++) R4433[i] = (char *(*)()) F1210_11193;}
	{long i; for (i = 601; i < 603; i++) R4433[i] = (char *(*)()) F429_4783;}
	{long i; for (i = 604; i < 606; i++) R4433[i] = (char *(*)()) F429_4783;}
	{long i; for (i = 615; i < 618; i++) R4433[i] = (char *(*)()) F429_4783;}
	{long i; for (i = 622; i < 624; i++) R4433[i] = (char *(*)()) F429_4783;}
	R4433[1065] = (char *(*)()) F1210_11193;
	R4433[1070] = (char *(*)()) F429_4783;
	{long i; for (i = 1072; i < 1074; i++) R4433[i] = (char *(*)()) F429_4783;}
	R4433[1074] = (char *(*)()) F1210_11193;
}

char *(*R4435[144])();
void R4435_init () {
	R4435[0] = (char *(*)()) F535_4855;
	R4435[107] = (char *(*)()) F642_5113;
	R4435[108] = (char *(*)()) F643_5113_4435_4;
	R4435[109] = (char *(*)()) F644_5113_4435_4;
	R4435[141] = (char *(*)()) F676_5515;
	R4435[142] = (char *(*)()) F677_5515_4435_4;
	R4435[143] = (char *(*)()) F678_5515_4435_4;
}
static void F643_5113_4435_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F643_5113(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F644_5113_4435_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F644_5113(Current, *(EIF_BOOLEAN *)arg1);
}
static void F677_5515_4435_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F677_5515(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F678_5515_4435_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F678_5515(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R4436[1179])();
void R4436_init () {
	R4436[0] = (char *(*)()) F535_4856;
	R4436[41] = (char *(*)()) F576_4902_4436_4;
	R4436[42] = (char *(*)()) F577_4924_4436_4;
	R4436[43] = (char *(*)()) F578_4989;
	R4436[44] = (char *(*)()) F579_4989_4436_4;
	R4436[45] = (char *(*)()) F580_4989_4436_4;
	R4436[46] = (char *(*)()) F581_4989_4436_4;
	R4436[47] = (char *(*)()) F582_4989_4436_4;
	R4436[48] = (char *(*)()) F583_4989_4436_4;
	R4436[49] = (char *(*)()) F584_4989_4436_4;
	R4436[50] = (char *(*)()) F585_4989_4436_4;
	R4436[51] = (char *(*)()) F586_4989_4436_4;
	R4436[52] = (char *(*)()) F587_4989_4436_4;
	R4436[53] = (char *(*)()) F588_4989_4436_4;
	R4436[54] = (char *(*)()) F589_4989_4436_4;
	R4436[55] = (char *(*)()) F581_4989_4436_4;
	R4436[104] = (char *(*)()) F639_5090;
	R4436[105] = (char *(*)()) F640_5090_4436_4;
	R4436[106] = (char *(*)()) F641_5090_4436_4;
	R4436[107] = (char *(*)()) F642_5112;
	R4436[108] = (char *(*)()) F643_5112_4436_4;
	R4436[109] = (char *(*)()) F644_5112_4436_4;
	R4436[110] = (char *(*)()) F645_5127;
	R4436[118] = (char *(*)()) F653_5279;
	R4436[120] = (char *(*)()) F655_5427;
	R4436[121] = (char *(*)()) F656_5427;
	R4436[122] = (char *(*)()) F657_5427_4436_4;
	R4436[123] = (char *(*)()) F658_5427_4436_4;
	R4436[124] = (char *(*)()) F659_5427_4436_4;
	R4436[125] = (char *(*)()) F660_5427_4436_4;
	R4436[126] = (char *(*)()) F655_5427;
	R4436[127] = (char *(*)()) F657_5427_4436_4;
	R4436[128] = (char *(*)()) F655_5427;
	R4436[129] = (char *(*)()) F664_5488;
	R4436[130] = (char *(*)()) F665_5488_4436_4;
	R4436[131] = (char *(*)()) F666_5488_4436_4;
	R4436[132] = (char *(*)()) F667_5488_4436_4;
	R4436[133] = (char *(*)()) F668_5488_4436_4;
	R4436[134] = (char *(*)()) F669_5488_4436_4;
	R4436[135] = (char *(*)()) F670_5488_4436_4;
	R4436[136] = (char *(*)()) F671_5488_4436_4;
	R4436[137] = (char *(*)()) F672_5488_4436_4;
	R4436[138] = (char *(*)()) F673_5488_4436_4;
	R4436[139] = (char *(*)()) F674_5488_4436_4;
	R4436[140] = (char *(*)()) F675_5488_4436_4;
	R4436[141] = (char *(*)()) F676_5514;
	R4436[142] = (char *(*)()) F677_5514_4436_4;
	R4436[143] = (char *(*)()) F678_5514_4436_4;
	R4436[144] = (char *(*)()) F664_5488;
	R4436[145] = (char *(*)()) F671_5488_4436_4;
	R4436[148] = (char *(*)()) F681_5535;
	R4436[149] = (char *(*)()) F682_5535_4436_4;
	R4436[150] = (char *(*)()) F681_5535;
	R4436[151] = (char *(*)()) F682_5535_4436_4;
	{long i; for (i = 152; i < 154; i++) R4436[i] = (char *(*)()) F681_5535;}
	{long i; for (i = 172; i < 174; i++) R4436[i] = (char *(*)()) F482_4808_4436_4;}
	{long i; for (i = 278; i < 280; i++) R4436[i] = (char *(*)()) F681_5535;}
	{long i; for (i = 281; i < 303; i++) R4436[i] = (char *(*)()) F681_5535;}
	{long i; for (i = 400; i < 402; i++) R4436[i] = (char *(*)()) F934_7341_4436_4;}
	{long i; for (i = 410; i < 413; i++) R4436[i] = (char *(*)()) F945_7858;}
	R4436[548] = (char *(*)()) F1083_9652_4436_4;
	{long i; for (i = 551; i < 553; i++) R4436[i] = (char *(*)()) F1086_9817_4436_4;}
	R4436[604] = (char *(*)()) F1120_10324;
	R4436[633] = (char *(*)()) F681_5535;
	R4436[644] = (char *(*)()) F1120_10324;
	{long i; for (i = 651; i < 653; i++) R4436[i] = (char *(*)()) F1120_10324;}
	R4436[661] = (char *(*)()) F1195_10984;
	{long i; for (i = 663; i < 665; i++) R4436[i] = (char *(*)()) F1195_10984;}
	{long i; for (i = 666; i < 668; i++) R4436[i] = (char *(*)()) F1195_10984;}
	{long i; for (i = 669; i < 680; i++) R4436[i] = (char *(*)()) F1195_10984;}
	{long i; for (i = 681; i < 690; i++) R4436[i] = (char *(*)()) F1195_10984;}
	{long i; for (i = 691; i < 694; i++) R4436[i] = (char *(*)()) F1195_10984;}
	R4436[695] = (char *(*)()) F1195_10984;
	R4436[697] = (char *(*)()) F1195_10984;
	{long i; for (i = 699; i < 704; i++) R4436[i] = (char *(*)()) F1195_10984;}
	{long i; for (i = 705; i < 707; i++) R4436[i] = (char *(*)()) F1120_10324;}
	{long i; for (i = 708; i < 710; i++) R4436[i] = (char *(*)()) F1120_10324;}
	{long i; for (i = 719; i < 722; i++) R4436[i] = (char *(*)()) F1120_10324;}
	{long i; for (i = 726; i < 728; i++) R4436[i] = (char *(*)()) F1120_10324;}
	R4436[985] = (char *(*)()) F934_7341_4436_4;
	R4436[1092] = (char *(*)()) F482_4808_4436_4;
	R4436[1169] = (char *(*)()) F1195_10984;
	R4436[1174] = (char *(*)()) F1195_10984;
	R4436[1176] = (char *(*)()) F1195_10984;
	R4436[1177] = (char *(*)()) F1120_10324;
	R4436[1178] = (char *(*)()) F1195_10984;
}
static void F576_4902_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F576_4902(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F577_4924_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F577_4924(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F579_4989_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F579_4989(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F580_4989_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F580_4989(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F581_4989_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F581_4989(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F582_4989_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F582_4989(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F583_4989_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F583_4989(Current, *(EIF_BOOLEAN *)arg1);
}
static void F584_4989_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F584_4989(Current, *(EIF_REAL_64 *)arg1);
}
static void F585_4989_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F585_4989(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F586_4989_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F586_4989(Current, *(EIF_POINTER *)arg1);
}
static void F587_4989_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F587_4989(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F588_4989_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F588_4989(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F589_4989_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F589_4989(Current, *(EIF_REAL_32 *)arg1);
}
static void F640_5090_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F640_5090(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F641_5090_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F641_5090(Current, *(EIF_BOOLEAN *)arg1);
}
static void F643_5112_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F643_5112(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F644_5112_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F644_5112(Current, *(EIF_BOOLEAN *)arg1);
}
static void F657_5427_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F657_5427(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F658_5427_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5427(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F659_5427_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5427(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F660_5427_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F660_5427(Current, *(EIF_POINTER *)arg1);
}
static void F665_5488_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5488(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F666_5488_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5488(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F667_5488_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5488(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F668_5488_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5488(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F669_5488_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F669_5488(Current, *(EIF_BOOLEAN *)arg1);
}
static void F670_5488_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F670_5488(Current, *(EIF_REAL_64 *)arg1);
}
static void F671_5488_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F671_5488(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F672_5488_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F672_5488(Current, *(EIF_POINTER *)arg1);
}
static void F673_5488_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F673_5488(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F674_5488_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F674_5488(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F675_5488_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F675_5488(Current, *(EIF_REAL_32 *)arg1);
}
static void F677_5514_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F677_5514(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F678_5514_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F678_5514(Current, *(EIF_BOOLEAN *)arg1);
}
static void F682_5535_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F682_5535(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F482_4808_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F482_4808(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F934_7341_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F934_7341(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1083_9652_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1083_9652(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1086_9817_4436_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1086_9817(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4437[1179])();
void R4437_init () {
	R4437[0] = (char *(*)()) F387_4766;
	{long i; for (i = 41; i < 43; i++) R4437[i] = (char *(*)()) F393_4766;}
	R4437[43] = (char *(*)()) F387_4766;
	R4437[44] = (char *(*)()) F388_4766;
	R4437[45] = (char *(*)()) F390_4766;
	R4437[46] = (char *(*)()) F391_4766;
	R4437[47] = (char *(*)()) F392_4766;
	R4437[48] = (char *(*)()) F394_4766;
	R4437[49] = (char *(*)()) F395_4766;
	R4437[50] = (char *(*)()) F393_4766;
	R4437[51] = (char *(*)()) F396_4766;
	R4437[52] = (char *(*)()) F397_4766;
	R4437[53] = (char *(*)()) F389_4766;
	R4437[54] = (char *(*)()) F398_4766;
	R4437[55] = (char *(*)()) F391_4766;
	R4437[104] = (char *(*)()) F591_5033;
	R4437[105] = (char *(*)()) F598_5033;
	R4437[106] = (char *(*)()) F596_5033;
	R4437[107] = (char *(*)()) F536_4876;
	R4437[108] = (char *(*)()) F537_4876;
	R4437[109] = (char *(*)()) F538_4876;
	R4437[110] = (char *(*)()) F387_4766;
	R4437[118] = (char *(*)()) F387_4766;
	{long i; for (i = 120; i < 122; i++) R4437[i] = (char *(*)()) F387_4766;}
	{long i; for (i = 122; i < 125; i++) R4437[i] = (char *(*)()) F393_4766;}
	R4437[125] = (char *(*)()) F396_4766;
	R4437[126] = (char *(*)()) F387_4766;
	R4437[127] = (char *(*)()) F393_4766;
	R4437[128] = (char *(*)()) F387_4766;
	R4437[129] = (char *(*)()) F591_5033;
	R4437[130] = (char *(*)()) F592_5033;
	R4437[131] = (char *(*)()) F593_5033;
	R4437[132] = (char *(*)()) F594_5033;
	R4437[133] = (char *(*)()) F595_5033;
	R4437[134] = (char *(*)()) F596_5033;
	R4437[135] = (char *(*)()) F597_5033;
	R4437[136] = (char *(*)()) F598_5033;
	R4437[137] = (char *(*)()) F599_5033;
	R4437[138] = (char *(*)()) F600_5033;
	R4437[139] = (char *(*)()) F601_5033;
	R4437[140] = (char *(*)()) F602_5033;
	R4437[141] = (char *(*)()) F536_4876;
	R4437[142] = (char *(*)()) F537_4876;
	R4437[143] = (char *(*)()) F538_4876;
	R4437[144] = (char *(*)()) F591_5033;
	R4437[145] = (char *(*)()) F598_5033;
	R4437[148] = (char *(*)()) F591_5033;
	R4437[149] = (char *(*)()) F598_5033;
	R4437[150] = (char *(*)()) F591_5033;
	R4437[151] = (char *(*)()) F598_5033;
	{long i; for (i = 152; i < 154; i++) R4437[i] = (char *(*)()) F591_5033;}
	{long i; for (i = 172; i < 174; i++) R4437[i] = (char *(*)()) F393_4766;}
	{long i; for (i = 278; i < 280; i++) R4437[i] = (char *(*)()) F591_5033;}
	{long i; for (i = 281; i < 303; i++) R4437[i] = (char *(*)()) F591_5033;}
	{long i; for (i = 400; i < 402; i++) R4437[i] = (char *(*)()) F389_4766;}
	{long i; for (i = 410; i < 413; i++) R4437[i] = (char *(*)()) F591_5033;}
	R4437[548] = (char *(*)()) F397_4766;
	{long i; for (i = 551; i < 553; i++) R4437[i] = (char *(*)()) F389_4766;}
	R4437[604] = (char *(*)()) F591_5033;
	R4437[633] = (char *(*)()) F591_5033;
	R4437[644] = (char *(*)()) F591_5033;
	{long i; for (i = 651; i < 653; i++) R4437[i] = (char *(*)()) F591_5033;}
	R4437[661] = (char *(*)()) F591_5033;
	{long i; for (i = 663; i < 665; i++) R4437[i] = (char *(*)()) F387_4766;}
	{long i; for (i = 666; i < 668; i++) R4437[i] = (char *(*)()) F591_5033;}
	{long i; for (i = 669; i < 675; i++) R4437[i] = (char *(*)()) F591_5033;}
	{long i; for (i = 675; i < 680; i++) R4437[i] = (char *(*)()) F387_4766;}
	{long i; for (i = 681; i < 690; i++) R4437[i] = (char *(*)()) F387_4766;}
	{long i; for (i = 691; i < 694; i++) R4437[i] = (char *(*)()) F387_4766;}
	R4437[695] = (char *(*)()) F387_4766;
	R4437[697] = (char *(*)()) F387_4766;
	{long i; for (i = 699; i < 704; i++) R4437[i] = (char *(*)()) F387_4766;}
	{long i; for (i = 705; i < 707; i++) R4437[i] = (char *(*)()) F591_5033;}
	{long i; for (i = 708; i < 710; i++) R4437[i] = (char *(*)()) F591_5033;}
	{long i; for (i = 719; i < 722; i++) R4437[i] = (char *(*)()) F591_5033;}
	{long i; for (i = 726; i < 728; i++) R4437[i] = (char *(*)()) F591_5033;}
	R4437[985] = (char *(*)()) F389_4766;
	R4437[1092] = (char *(*)()) F393_4766;
	R4437[1169] = (char *(*)()) F387_4766;
	R4437[1174] = (char *(*)()) F591_5033;
	{long i; for (i = 1176; i < 1178; i++) R4437[i] = (char *(*)()) F591_5033;}
	R4437[1178] = (char *(*)()) F387_4766;
}

char *(*R4438[1179])();
void R4438_init () {
	R4438[0] = (char *(*)()) F535_4860;
	{long i; for (i = 41; i < 43; i++) R4438[i] = (char *(*)()) F576_4919_4438_4;}
	R4438[43] = (char *(*)()) F578_4988;
	R4438[44] = (char *(*)()) F579_4988_4438_4;
	R4438[45] = (char *(*)()) F580_4988_4438_4;
	R4438[46] = (char *(*)()) F581_4988_4438_4;
	R4438[47] = (char *(*)()) F582_4988_4438_4;
	R4438[48] = (char *(*)()) F583_4988_4438_4;
	R4438[49] = (char *(*)()) F584_4988_4438_4;
	R4438[50] = (char *(*)()) F585_4988_4438_4;
	R4438[51] = (char *(*)()) F586_4988_4438_4;
	R4438[52] = (char *(*)()) F587_4988_4438_4;
	R4438[53] = (char *(*)()) F588_4988_4438_4;
	R4438[54] = (char *(*)()) F589_4988_4438_4;
	R4438[55] = (char *(*)()) F581_4988_4438_4;
	R4438[104] = (char *(*)()) F603_5043;
	R4438[105] = (char *(*)()) F610_5043_4438_4;
	R4438[106] = (char *(*)()) F608_5043_4438_4;
	R4438[107] = (char *(*)()) F603_5043;
	R4438[108] = (char *(*)()) F610_5043_4438_4;
	R4438[109] = (char *(*)()) F608_5043_4438_4;
	R4438[110] = (char *(*)()) F645_5132;
	R4438[118] = (char *(*)()) F653_5285;
	R4438[120] = (char *(*)()) F655_5369;
	R4438[121] = (char *(*)()) F656_5369;
	R4438[122] = (char *(*)()) F657_5369_4438_4;
	R4438[123] = (char *(*)()) F658_5369_4438_4;
	R4438[124] = (char *(*)()) F659_5369_4438_4;
	R4438[125] = (char *(*)()) F660_5369_4438_4;
	R4438[126] = (char *(*)()) F655_5369;
	R4438[127] = (char *(*)()) F657_5369_4438_4;
	R4438[128] = (char *(*)()) F655_5369;
	R4438[129] = (char *(*)()) F664_5500;
	R4438[130] = (char *(*)()) F665_5500_4438_4;
	R4438[131] = (char *(*)()) F666_5500_4438_4;
	R4438[132] = (char *(*)()) F667_5500_4438_4;
	R4438[133] = (char *(*)()) F668_5500_4438_4;
	R4438[134] = (char *(*)()) F669_5500_4438_4;
	R4438[135] = (char *(*)()) F670_5500_4438_4;
	R4438[136] = (char *(*)()) F671_5500_4438_4;
	R4438[137] = (char *(*)()) F672_5500_4438_4;
	R4438[138] = (char *(*)()) F673_5500_4438_4;
	R4438[139] = (char *(*)()) F674_5500_4438_4;
	R4438[140] = (char *(*)()) F675_5500_4438_4;
	R4438[141] = (char *(*)()) F664_5500;
	R4438[142] = (char *(*)()) F671_5500_4438_4;
	R4438[143] = (char *(*)()) F669_5500_4438_4;
	R4438[144] = (char *(*)()) F664_5500;
	R4438[145] = (char *(*)()) F671_5500_4438_4;
	R4438[148] = (char *(*)()) F664_5500;
	R4438[149] = (char *(*)()) F671_5500_4438_4;
	R4438[150] = (char *(*)()) F664_5500;
	R4438[151] = (char *(*)()) F671_5500_4438_4;
	R4438[152] = (char *(*)()) F664_5500;
	R4438[153] = (char *(*)()) F688_5586;
	{long i; for (i = 172; i < 174; i++) R4438[i] = (char *(*)()) F482_4811_4438_4;}
	{long i; for (i = 278; i < 280; i++) R4438[i] = (char *(*)()) F688_5586;}
	{long i; for (i = 281; i < 303; i++) R4438[i] = (char *(*)()) F688_5586;}
	{long i; for (i = 400; i < 402; i++) R4438[i] = (char *(*)()) F934_7462_4438_4;}
	{long i; for (i = 410; i < 413; i++) R4438[i] = (char *(*)()) F664_5500;}
	R4438[548] = (char *(*)()) F1083_9663_4438_4;
	{long i; for (i = 551; i < 553; i++) R4438[i] = (char *(*)()) F1086_9828_4438_4;}
	R4438[604] = (char *(*)()) F603_5043;
	R4438[633] = (char *(*)()) F664_5500;
	R4438[644] = (char *(*)()) F603_5043;
	{long i; for (i = 651; i < 653; i++) R4438[i] = (char *(*)()) F603_5043;}
	R4438[661] = (char *(*)()) F1195_10985;
	{long i; for (i = 663; i < 665; i++) R4438[i] = (char *(*)()) F1195_10985;}
	{long i; for (i = 666; i < 668; i++) R4438[i] = (char *(*)()) F1195_10985;}
	{long i; for (i = 669; i < 680; i++) R4438[i] = (char *(*)()) F1195_10985;}
	{long i; for (i = 681; i < 690; i++) R4438[i] = (char *(*)()) F1195_10985;}
	{long i; for (i = 691; i < 694; i++) R4438[i] = (char *(*)()) F1195_10985;}
	R4438[695] = (char *(*)()) F1195_10985;
	R4438[697] = (char *(*)()) F1195_10985;
	{long i; for (i = 699; i < 704; i++) R4438[i] = (char *(*)()) F1195_10985;}
	{long i; for (i = 705; i < 707; i++) R4438[i] = (char *(*)()) F603_5043;}
	{long i; for (i = 708; i < 710; i++) R4438[i] = (char *(*)()) F603_5043;}
	{long i; for (i = 719; i < 722; i++) R4438[i] = (char *(*)()) F603_5043;}
	{long i; for (i = 726; i < 728; i++) R4438[i] = (char *(*)()) F603_5043;}
	R4438[985] = (char *(*)()) F934_7462_4438_4;
	R4438[1092] = (char *(*)()) F482_4811_4438_4;
	R4438[1169] = (char *(*)()) F1195_10985;
	R4438[1174] = (char *(*)()) F1195_10985;
	R4438[1176] = (char *(*)()) F1195_10985;
	R4438[1177] = (char *(*)()) F603_5043;
	R4438[1178] = (char *(*)()) F1195_10985;
}
static void F576_4919_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F576_4919(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F579_4988_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F579_4988(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F580_4988_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F580_4988(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F581_4988_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F581_4988(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F582_4988_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F582_4988(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F583_4988_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F583_4988(Current, *(EIF_BOOLEAN *)arg1);
}
static void F584_4988_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F584_4988(Current, *(EIF_REAL_64 *)arg1);
}
static void F585_4988_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F585_4988(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F586_4988_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F586_4988(Current, *(EIF_POINTER *)arg1);
}
static void F587_4988_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F587_4988(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F588_4988_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F588_4988(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F589_4988_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F589_4988(Current, *(EIF_REAL_32 *)arg1);
}
static void F610_5043_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F610_5043(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F608_5043_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F608_5043(Current, *(EIF_BOOLEAN *)arg1);
}
static void F657_5369_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F657_5369(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F658_5369_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5369(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F659_5369_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5369(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F660_5369_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F660_5369(Current, *(EIF_POINTER *)arg1);
}
static void F665_5500_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5500(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F666_5500_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5500(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F667_5500_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5500(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F668_5500_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5500(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F669_5500_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F669_5500(Current, *(EIF_BOOLEAN *)arg1);
}
static void F670_5500_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F670_5500(Current, *(EIF_REAL_64 *)arg1);
}
static void F671_5500_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F671_5500(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F672_5500_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F672_5500(Current, *(EIF_POINTER *)arg1);
}
static void F673_5500_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F673_5500(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F674_5500_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F674_5500(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F675_5500_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F675_5500(Current, *(EIF_REAL_32 *)arg1);
}
static void F482_4811_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F482_4811(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F934_7462_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F934_7462(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1083_9663_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1083_9663(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1086_9828_4438_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1086_9828(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4439[1179])();
void R4439_init () {
	R4439[0] = (char *(*)()) F387_4768;
	{long i; for (i = 41; i < 43; i++) R4439[i] = (char *(*)()) F393_4768_4439_4;}
	R4439[43] = (char *(*)()) F387_4768;
	R4439[44] = (char *(*)()) F388_4768_4439_4;
	R4439[45] = (char *(*)()) F390_4768_4439_4;
	R4439[46] = (char *(*)()) F391_4768_4439_4;
	R4439[47] = (char *(*)()) F392_4768_4439_4;
	R4439[48] = (char *(*)()) F394_4768_4439_4;
	R4439[49] = (char *(*)()) F395_4768_4439_4;
	R4439[50] = (char *(*)()) F393_4768_4439_4;
	R4439[51] = (char *(*)()) F396_4768_4439_4;
	R4439[52] = (char *(*)()) F397_4768_4439_4;
	R4439[53] = (char *(*)()) F389_4768_4439_4;
	R4439[54] = (char *(*)()) F398_4768_4439_4;
	R4439[55] = (char *(*)()) F391_4768_4439_4;
	R4439[104] = (char *(*)()) F603_5044;
	R4439[105] = (char *(*)()) F610_5044_4439_4;
	R4439[106] = (char *(*)()) F608_5044_4439_4;
	R4439[107] = (char *(*)()) F387_4768;
	R4439[108] = (char *(*)()) F393_4768_4439_4;
	R4439[109] = (char *(*)()) F394_4768_4439_4;
	R4439[110] = (char *(*)()) F645_5133;
	{long i; for (i = 120; i < 122; i++) R4439[i] = (char *(*)()) F387_4768;}
	{long i; for (i = 122; i < 125; i++) R4439[i] = (char *(*)()) F393_4768_4439_4;}
	R4439[125] = (char *(*)()) F396_4768_4439_4;
	R4439[126] = (char *(*)()) F387_4768;
	R4439[127] = (char *(*)()) F393_4768_4439_4;
	R4439[128] = (char *(*)()) F387_4768;
	R4439[129] = (char *(*)()) F664_5503;
	R4439[130] = (char *(*)()) F665_5503_4439_4;
	R4439[131] = (char *(*)()) F666_5503_4439_4;
	R4439[132] = (char *(*)()) F667_5503_4439_4;
	R4439[133] = (char *(*)()) F668_5503_4439_4;
	R4439[134] = (char *(*)()) F669_5503_4439_4;
	R4439[135] = (char *(*)()) F670_5503_4439_4;
	R4439[136] = (char *(*)()) F671_5503_4439_4;
	R4439[137] = (char *(*)()) F672_5503_4439_4;
	R4439[138] = (char *(*)()) F673_5503_4439_4;
	R4439[139] = (char *(*)()) F674_5503_4439_4;
	R4439[140] = (char *(*)()) F675_5503_4439_4;
	R4439[141] = (char *(*)()) F664_5503;
	R4439[142] = (char *(*)()) F671_5503_4439_4;
	R4439[143] = (char *(*)()) F669_5503_4439_4;
	R4439[144] = (char *(*)()) F664_5503;
	R4439[145] = (char *(*)()) F671_5503_4439_4;
	R4439[148] = (char *(*)()) F681_5545;
	R4439[149] = (char *(*)()) F682_5545_4439_4;
	R4439[150] = (char *(*)()) F681_5545;
	R4439[151] = (char *(*)()) F682_5545_4439_4;
	{long i; for (i = 152; i < 154; i++) R4439[i] = (char *(*)()) F681_5545;}
	{long i; for (i = 172; i < 174; i++) R4439[i] = (char *(*)()) F393_4768_4439_4;}
	{long i; for (i = 278; i < 280; i++) R4439[i] = (char *(*)()) F681_5545;}
	{long i; for (i = 281; i < 303; i++) R4439[i] = (char *(*)()) F681_5545;}
	{long i; for (i = 400; i < 402; i++) R4439[i] = (char *(*)()) F521_4834_4439_4;}
	{long i; for (i = 410; i < 413; i++) R4439[i] = (char *(*)()) F945_7862;}
	R4439[548] = (char *(*)()) F1083_9664_4439_4;
	{long i; for (i = 551; i < 553; i++) R4439[i] = (char *(*)()) F1086_9829_4439_4;}
	R4439[604] = (char *(*)()) F603_5044;
	R4439[633] = (char *(*)()) F681_5545;
	R4439[644] = (char *(*)()) F603_5044;
	{long i; for (i = 651; i < 653; i++) R4439[i] = (char *(*)()) F603_5044;}
	R4439[661] = (char *(*)()) F519_4834;
	{long i; for (i = 663; i < 665; i++) R4439[i] = (char *(*)()) F387_4768;}
	{long i; for (i = 666; i < 668; i++) R4439[i] = (char *(*)()) F603_5044;}
	{long i; for (i = 669; i < 675; i++) R4439[i] = (char *(*)()) F603_5044;}
	{long i; for (i = 675; i < 680; i++) R4439[i] = (char *(*)()) F387_4768;}
	{long i; for (i = 681; i < 690; i++) R4439[i] = (char *(*)()) F387_4768;}
	{long i; for (i = 691; i < 694; i++) R4439[i] = (char *(*)()) F387_4768;}
	R4439[695] = (char *(*)()) F387_4768;
	R4439[697] = (char *(*)()) F387_4768;
	{long i; for (i = 699; i < 704; i++) R4439[i] = (char *(*)()) F387_4768;}
	{long i; for (i = 705; i < 707; i++) R4439[i] = (char *(*)()) F603_5044;}
	{long i; for (i = 708; i < 710; i++) R4439[i] = (char *(*)()) F603_5044;}
	{long i; for (i = 719; i < 722; i++) R4439[i] = (char *(*)()) F603_5044;}
	{long i; for (i = 726; i < 728; i++) R4439[i] = (char *(*)()) F603_5044;}
	R4439[985] = (char *(*)()) F521_4834_4439_4;
	R4439[1092] = (char *(*)()) F393_4768_4439_4;
	R4439[1169] = (char *(*)()) F387_4768;
	R4439[1174] = (char *(*)()) F603_5044;
	{long i; for (i = 1176; i < 1178; i++) R4439[i] = (char *(*)()) F603_5044;}
	R4439[1178] = (char *(*)()) F387_4768;
}
static void F393_4768_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F393_4768(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F388_4768_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F388_4768(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F390_4768_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F390_4768(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F391_4768_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F391_4768(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F392_4768_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F392_4768(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F394_4768_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F394_4768(Current, *(EIF_BOOLEAN *)arg1);
}
static void F395_4768_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F395_4768(Current, *(EIF_REAL_64 *)arg1);
}
static void F396_4768_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F396_4768(Current, *(EIF_POINTER *)arg1);
}
static void F397_4768_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F397_4768(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F389_4768_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F389_4768(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F398_4768_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F398_4768(Current, *(EIF_REAL_32 *)arg1);
}
static void F610_5044_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F610_5044(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F608_5044_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F608_5044(Current, *(EIF_BOOLEAN *)arg1);
}
static void F665_5503_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5503(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F666_5503_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5503(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F667_5503_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5503(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F668_5503_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5503(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F669_5503_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F669_5503(Current, *(EIF_BOOLEAN *)arg1);
}
static void F670_5503_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F670_5503(Current, *(EIF_REAL_64 *)arg1);
}
static void F671_5503_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F671_5503(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F672_5503_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F672_5503(Current, *(EIF_POINTER *)arg1);
}
static void F673_5503_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F673_5503(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F674_5503_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F674_5503(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F675_5503_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F675_5503(Current, *(EIF_REAL_32 *)arg1);
}
static void F682_5545_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F682_5545(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F521_4834_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F521_4834(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1083_9664_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1083_9664(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1086_9829_4439_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1086_9829(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4440[1179])();
void R4440_init () {
	R4440[0] = (char *(*)()) F535_4861;
	R4440[120] = (char *(*)()) F655_5370;
	R4440[121] = (char *(*)()) F656_5370;
	R4440[122] = (char *(*)()) F657_5370;
	R4440[123] = (char *(*)()) F658_5370;
	R4440[124] = (char *(*)()) F659_5370;
	R4440[125] = (char *(*)()) F660_5370;
	R4440[126] = (char *(*)()) F655_5370;
	R4440[127] = (char *(*)()) F657_5370;
	R4440[128] = (char *(*)()) F655_5370;
	R4440[129] = (char *(*)()) F664_5506;
	R4440[130] = (char *(*)()) F665_5506;
	R4440[131] = (char *(*)()) F666_5506;
	R4440[132] = (char *(*)()) F667_5506;
	R4440[133] = (char *(*)()) F668_5506;
	R4440[134] = (char *(*)()) F669_5506;
	R4440[135] = (char *(*)()) F670_5506;
	R4440[136] = (char *(*)()) F671_5506;
	R4440[137] = (char *(*)()) F672_5506;
	R4440[138] = (char *(*)()) F673_5506;
	R4440[139] = (char *(*)()) F674_5506;
	R4440[140] = (char *(*)()) F675_5506;
	R4440[141] = (char *(*)()) F664_5506;
	R4440[142] = (char *(*)()) F671_5506;
	R4440[143] = (char *(*)()) F669_5506;
	R4440[144] = (char *(*)()) F664_5506;
	R4440[145] = (char *(*)()) F671_5506;
	R4440[148] = (char *(*)()) F681_5547;
	R4440[149] = (char *(*)()) F682_5547;
	R4440[150] = (char *(*)()) F681_5547;
	R4440[151] = (char *(*)()) F682_5547;
	{long i; for (i = 152; i < 154; i++) R4440[i] = (char *(*)()) F681_5547;}
	{long i; for (i = 278; i < 280; i++) R4440[i] = (char *(*)()) F681_5547;}
	{long i; for (i = 281; i < 303; i++) R4440[i] = (char *(*)()) F681_5547;}
	{long i; for (i = 410; i < 413; i++) R4440[i] = (char *(*)()) F945_7865;}
	R4440[548] = (char *(*)()) F1083_9667;
	R4440[604] = (char *(*)()) F1120_10319;
	R4440[633] = (char *(*)()) F681_5547;
	R4440[644] = (char *(*)()) F1120_10319;
	{long i; for (i = 651; i < 653; i++) R4440[i] = (char *(*)()) F1120_10319;}
	R4440[661] = (char *(*)()) F1196_11025;
	{long i; for (i = 663; i < 665; i++) R4440[i] = (char *(*)()) F1197_11067;}
	{long i; for (i = 666; i < 668; i++) R4440[i] = (char *(*)()) F1120_10319;}
	{long i; for (i = 669; i < 675; i++) R4440[i] = (char *(*)()) F1120_10319;}
	{long i; for (i = 675; i < 680; i++) R4440[i] = (char *(*)()) F1210_11198;}
	{long i; for (i = 681; i < 690; i++) R4440[i] = (char *(*)()) F1210_11198;}
	{long i; for (i = 691; i < 694; i++) R4440[i] = (char *(*)()) F1210_11198;}
	R4440[695] = (char *(*)()) F1210_11198;
	R4440[697] = (char *(*)()) F1210_11198;
	{long i; for (i = 699; i < 704; i++) R4440[i] = (char *(*)()) F1210_11198;}
	{long i; for (i = 705; i < 707; i++) R4440[i] = (char *(*)()) F1120_10319;}
	{long i; for (i = 708; i < 710; i++) R4440[i] = (char *(*)()) F1120_10319;}
	{long i; for (i = 719; i < 722; i++) R4440[i] = (char *(*)()) F1120_10319;}
	{long i; for (i = 726; i < 728; i++) R4440[i] = (char *(*)()) F1120_10319;}
	R4440[1169] = (char *(*)()) F1210_11198;
	R4440[1174] = (char *(*)()) F1120_10319;
	{long i; for (i = 1176; i < 1178; i++) R4440[i] = (char *(*)()) F1120_10319;}
	R4440[1178] = (char *(*)()) F1210_11198;
}

char *(*R4443[1137])();
void R4443_init () {
	{long i; for (i = 0; i < 2; i++) R4443[i] = (char *(*)()) F576_4890_4443_5;}
	R4443[2] = (char *(*)()) F578_4938_4443_5;
	R4443[3] = (char *(*)()) F579_4938_4443_5;
	R4443[4] = (char *(*)()) F580_4938_4443_5;
	R4443[5] = (char *(*)()) F581_4938_4443_5;
	R4443[6] = (char *(*)()) F582_4938_4443_5;
	R4443[7] = (char *(*)()) F583_4938_4443_5;
	R4443[8] = (char *(*)()) F584_4938_4443_5;
	R4443[9] = (char *(*)()) F585_4938_4443_5;
	R4443[10] = (char *(*)()) F586_4938_4443_5;
	R4443[11] = (char *(*)()) F587_4938_4443_5;
	R4443[12] = (char *(*)()) F588_4938_4443_5;
	R4443[13] = (char *(*)()) F589_4938_4443_5;
	R4443[14] = (char *(*)()) F581_4938_4443_5;
	R4443[63] = (char *(*)()) F591_5017_4443_5;
	R4443[64] = (char *(*)()) F598_5017_4443_5;
	R4443[65] = (char *(*)()) F596_5017_4443_5;
	R4443[66] = (char *(*)()) F591_5017_4443_5;
	R4443[67] = (char *(*)()) F598_5017_4443_5;
	R4443[68] = (char *(*)()) F596_5017_4443_5;
	R4443[69] = (char *(*)()) F591_5017_4443_5;
	R4443[88] = (char *(*)()) F664_5453_4443_5;
	R4443[89] = (char *(*)()) F665_5453_4443_5;
	R4443[90] = (char *(*)()) F666_5453_4443_5;
	R4443[91] = (char *(*)()) F667_5453_4443_5;
	R4443[92] = (char *(*)()) F668_5453_4443_5;
	R4443[93] = (char *(*)()) F669_5453_4443_5;
	R4443[94] = (char *(*)()) F670_5453_4443_5;
	R4443[95] = (char *(*)()) F671_5453_4443_5;
	R4443[96] = (char *(*)()) F672_5453_4443_5;
	R4443[97] = (char *(*)()) F673_5453_4443_5;
	R4443[98] = (char *(*)()) F674_5453_4443_5;
	R4443[99] = (char *(*)()) F675_5453_4443_5;
	R4443[100] = (char *(*)()) F664_5453_4443_5;
	R4443[101] = (char *(*)()) F671_5453_4443_5;
	R4443[102] = (char *(*)()) F669_5453_4443_5;
	R4443[103] = (char *(*)()) F664_5453_4443_5;
	R4443[104] = (char *(*)()) F671_5453_4443_5;
	R4443[107] = (char *(*)()) F664_5453_4443_5;
	R4443[108] = (char *(*)()) F671_5453_4443_5;
	R4443[109] = (char *(*)()) F664_5453_4443_5;
	R4443[110] = (char *(*)()) F671_5453_4443_5;
	{long i; for (i = 111; i < 113; i++) R4443[i] = (char *(*)()) F664_5453_4443_5;}
	{long i; for (i = 237; i < 239; i++) R4443[i] = (char *(*)()) F664_5453_4443_5;}
	{long i; for (i = 240; i < 262; i++) R4443[i] = (char *(*)()) F664_5453_4443_5;}
	{long i; for (i = 369; i < 372; i++) R4443[i] = (char *(*)()) F664_5453_4443_5;}
	R4443[507] = (char *(*)()) F1083_9605_4443_5;
	{long i; for (i = 510; i < 512; i++) R4443[i] = (char *(*)()) F1086_9769_4443_5;}
	R4443[563] = (char *(*)()) F1120_10291_4443_5;
	R4443[592] = (char *(*)()) F664_5453_4443_5;
	R4443[603] = (char *(*)()) F1120_10291_4443_5;
	{long i; for (i = 610; i < 612; i++) R4443[i] = (char *(*)()) F1120_10291_4443_5;}
	R4443[620] = (char *(*)()) F591_5017_4443_5;
	{long i; for (i = 625; i < 627; i++) R4443[i] = (char *(*)()) F1120_10291_4443_5;}
	{long i; for (i = 628; i < 634; i++) R4443[i] = (char *(*)()) F1120_10291_4443_5;}
	{long i; for (i = 664; i < 666; i++) R4443[i] = (char *(*)()) F1120_10291_4443_5;}
	{long i; for (i = 667; i < 669; i++) R4443[i] = (char *(*)()) F1120_10291_4443_5;}
	{long i; for (i = 678; i < 681; i++) R4443[i] = (char *(*)()) F1120_10291_4443_5;}
	{long i; for (i = 685; i < 687; i++) R4443[i] = (char *(*)()) F1120_10291_4443_5;}
	R4443[1133] = (char *(*)()) F1120_10291_4443_5;
	{long i; for (i = 1135; i < 1137; i++) R4443[i] = (char *(*)()) F1120_10291_4443_5;}
}
static EIF_REFERENCE F576_4890_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F576_4890(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F578_4938_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F578_4938(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F579_4938_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F579_4938(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_4938_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F580_4938(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1009, 0x00).id, 1009, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F581_4938_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F581_4938(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1012, 0x00).id, 1012, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F582_4938_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F582_4938(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1003, 0x00).id, 1003, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F583_4938_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F583_4938(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F584_4938_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F584_4938(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1018, 0x00).id, 1018, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F585_4938_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F585_4938(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F586_4938_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F586_4938(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_4938_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F587_4938(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_4938_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F588_4938(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_4938_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F589_4938(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F591_5017_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F591_5017(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F598_5017_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F598_5017(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F596_5017_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F596_5017(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5453_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F664_5453(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F665_5453_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F665_5453(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5453_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F666_5453(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1009, 0x00).id, 1009, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5453_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F667_5453(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1012, 0x00).id, 1012, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5453_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F668_5453(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1003, 0x00).id, 1003, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_5453_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F669_5453(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_5453_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F670_5453(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1018, 0x00).id, 1018, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F671_5453_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F671_5453(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F672_5453_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F672_5453(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F673_5453_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F673_5453(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F674_5453_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F674_5453(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F675_5453_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F675_5453(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1083_9605_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1083_9605(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1086_9769_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1086_9769(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1120_10291_4443_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1120_10291(Current, *(EIF_INTEGER_32 *)arg1);
}


#ifdef __cplusplus
}
#endif
