#include "epoly12.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4444[1135])();
void R4444_init () {
	R4444[0] = (char *(*)()) F578_4939_4444_5;
	R4444[1] = (char *(*)()) F579_4939_4444_5;
	R4444[2] = (char *(*)()) F580_4939_4444_5;
	R4444[3] = (char *(*)()) F581_4939_4444_5;
	R4444[4] = (char *(*)()) F582_4939_4444_5;
	R4444[5] = (char *(*)()) F583_4939_4444_5;
	R4444[6] = (char *(*)()) F584_4939_4444_5;
	R4444[7] = (char *(*)()) F585_4939_4444_5;
	R4444[8] = (char *(*)()) F586_4939_4444_5;
	R4444[9] = (char *(*)()) F587_4939_4444_5;
	R4444[10] = (char *(*)()) F588_4939_4444_5;
	R4444[11] = (char *(*)()) F589_4939_4444_5;
	R4444[12] = (char *(*)()) F581_4939_4444_5;
	R4444[61] = (char *(*)()) F591_5018_4444_5;
	R4444[62] = (char *(*)()) F598_5018_4444_5;
	R4444[63] = (char *(*)()) F596_5018_4444_5;
	R4444[64] = (char *(*)()) F591_5018_4444_5;
	R4444[65] = (char *(*)()) F598_5018_4444_5;
	R4444[66] = (char *(*)()) F596_5018_4444_5;
	R4444[67] = (char *(*)()) F591_5018_4444_5;
	R4444[86] = (char *(*)()) F664_5454_4444_5;
	R4444[87] = (char *(*)()) F665_5454_4444_5;
	R4444[88] = (char *(*)()) F666_5454_4444_5;
	R4444[89] = (char *(*)()) F667_5454_4444_5;
	R4444[90] = (char *(*)()) F668_5454_4444_5;
	R4444[91] = (char *(*)()) F669_5454_4444_5;
	R4444[92] = (char *(*)()) F670_5454_4444_5;
	R4444[93] = (char *(*)()) F671_5454_4444_5;
	R4444[94] = (char *(*)()) F672_5454_4444_5;
	R4444[95] = (char *(*)()) F673_5454_4444_5;
	R4444[96] = (char *(*)()) F674_5454_4444_5;
	R4444[97] = (char *(*)()) F675_5454_4444_5;
	R4444[98] = (char *(*)()) F664_5454_4444_5;
	R4444[99] = (char *(*)()) F671_5454_4444_5;
	R4444[100] = (char *(*)()) F669_5454_4444_5;
	R4444[101] = (char *(*)()) F664_5454_4444_5;
	R4444[102] = (char *(*)()) F671_5454_4444_5;
	R4444[105] = (char *(*)()) F664_5454_4444_5;
	R4444[106] = (char *(*)()) F671_5454_4444_5;
	R4444[107] = (char *(*)()) F664_5454_4444_5;
	R4444[108] = (char *(*)()) F671_5454_4444_5;
	{long i; for (i = 109; i < 111; i++) R4444[i] = (char *(*)()) F664_5454_4444_5;}
	{long i; for (i = 235; i < 237; i++) R4444[i] = (char *(*)()) F664_5454_4444_5;}
	{long i; for (i = 238; i < 260; i++) R4444[i] = (char *(*)()) F664_5454_4444_5;}
	{long i; for (i = 367; i < 370; i++) R4444[i] = (char *(*)()) F664_5454_4444_5;}
	R4444[505] = (char *(*)()) F1083_9606_4444_5;
	R4444[561] = (char *(*)()) F591_5018_4444_5;
	R4444[590] = (char *(*)()) F664_5454_4444_5;
	R4444[601] = (char *(*)()) F591_5018_4444_5;
	{long i; for (i = 608; i < 610; i++) R4444[i] = (char *(*)()) F591_5018_4444_5;}
	R4444[618] = (char *(*)()) F591_5018_4444_5;
	{long i; for (i = 623; i < 625; i++) R4444[i] = (char *(*)()) F591_5018_4444_5;}
	{long i; for (i = 626; i < 632; i++) R4444[i] = (char *(*)()) F591_5018_4444_5;}
	{long i; for (i = 662; i < 664; i++) R4444[i] = (char *(*)()) F591_5018_4444_5;}
	{long i; for (i = 665; i < 667; i++) R4444[i] = (char *(*)()) F591_5018_4444_5;}
	{long i; for (i = 676; i < 679; i++) R4444[i] = (char *(*)()) F591_5018_4444_5;}
	{long i; for (i = 683; i < 685; i++) R4444[i] = (char *(*)()) F591_5018_4444_5;}
	R4444[1131] = (char *(*)()) F591_5018_4444_5;
	{long i; for (i = 1133; i < 1135; i++) R4444[i] = (char *(*)()) F591_5018_4444_5;}
}
static EIF_REFERENCE F578_4939_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F578_4939(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F579_4939_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F579_4939(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_4939_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F580_4939(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1009, 0x00).id, 1009, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F581_4939_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F581_4939(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1012, 0x00).id, 1012, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F582_4939_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F582_4939(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1003, 0x00).id, 1003, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F583_4939_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F583_4939(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F584_4939_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F584_4939(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1018, 0x00).id, 1018, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F585_4939_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F585_4939(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F586_4939_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F586_4939(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_4939_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F587_4939(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_4939_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F588_4939(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_4939_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F589_4939(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F591_5018_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F591_5018(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F598_5018_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F598_5018(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F596_5018_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F596_5018(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5454_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F664_5454(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F665_5454_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F665_5454(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5454_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F666_5454(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1009, 0x00).id, 1009, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5454_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F667_5454(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1012, 0x00).id, 1012, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5454_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F668_5454(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1003, 0x00).id, 1003, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_5454_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F669_5454(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_5454_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F670_5454(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1018, 0x00).id, 1018, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F671_5454_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F671_5454(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F672_5454_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F672_5454(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F673_5454_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F673_5454(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F674_5454_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F674_5454(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F675_5454_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F675_5454(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1083_9606_4444_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1083_9606(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R4446[591])();
void R4446_init () {
	R4446[0] = (char *(*)()) F578_4957_4446_18;
	R4446[1] = (char *(*)()) F579_4957_4446_18;
	R4446[2] = (char *(*)()) F580_4957_4446_18;
	R4446[3] = (char *(*)()) F581_4957_4446_18;
	R4446[4] = (char *(*)()) F582_4957_4446_18;
	R4446[5] = (char *(*)()) F583_4957_4446_18;
	R4446[6] = (char *(*)()) F584_4957_4446_18;
	R4446[7] = (char *(*)()) F585_4957_4446_18;
	R4446[8] = (char *(*)()) F586_4957_4446_18;
	R4446[9] = (char *(*)()) F587_4957_4446_18;
	R4446[10] = (char *(*)()) F588_4957_4446_18;
	R4446[11] = (char *(*)()) F589_4957_4446_18;
	R4446[12] = (char *(*)()) F581_4957_4446_18;
	R4446[77] = (char *(*)()) F655_5362;
	R4446[78] = (char *(*)()) F656_5362_4446_18;
	R4446[79] = (char *(*)()) F657_5362_4446_18;
	R4446[80] = (char *(*)()) F658_5362_4446_18;
	R4446[81] = (char *(*)()) F659_5362_4446_18;
	R4446[82] = (char *(*)()) F660_5362_4446_18;
	R4446[83] = (char *(*)()) F655_5362;
	R4446[84] = (char *(*)()) F657_5362_4446_18;
	R4446[85] = (char *(*)()) F655_5362;
	R4446[86] = (char *(*)()) F664_5486_4446_18;
	R4446[87] = (char *(*)()) F665_5486_4446_18;
	R4446[88] = (char *(*)()) F666_5486_4446_18;
	R4446[89] = (char *(*)()) F667_5486_4446_18;
	R4446[90] = (char *(*)()) F668_5486_4446_18;
	R4446[91] = (char *(*)()) F669_5486_4446_18;
	R4446[92] = (char *(*)()) F670_5486_4446_18;
	R4446[93] = (char *(*)()) F671_5486_4446_18;
	R4446[94] = (char *(*)()) F672_5486_4446_18;
	R4446[95] = (char *(*)()) F673_5486_4446_18;
	R4446[96] = (char *(*)()) F674_5486_4446_18;
	R4446[97] = (char *(*)()) F675_5486_4446_18;
	R4446[98] = (char *(*)()) F664_5486_4446_18;
	R4446[99] = (char *(*)()) F671_5486_4446_18;
	R4446[100] = (char *(*)()) F669_5486_4446_18;
	R4446[101] = (char *(*)()) F664_5486_4446_18;
	R4446[102] = (char *(*)()) F671_5486_4446_18;
	R4446[105] = (char *(*)()) F681_5539_4446_18;
	R4446[106] = (char *(*)()) F682_5539_4446_18;
	R4446[107] = (char *(*)()) F681_5539_4446_18;
	R4446[108] = (char *(*)()) F682_5539_4446_18;
	{long i; for (i = 109; i < 111; i++) R4446[i] = (char *(*)()) F681_5539_4446_18;}
	{long i; for (i = 235; i < 237; i++) R4446[i] = (char *(*)()) F681_5539_4446_18;}
	{long i; for (i = 238; i < 260; i++) R4446[i] = (char *(*)()) F681_5539_4446_18;}
	{long i; for (i = 367; i < 370; i++) R4446[i] = (char *(*)()) F664_5486_4446_18;}
	R4446[505] = (char *(*)()) F1083_9625_4446_18;
	{long i; for (i = 508; i < 510; i++) R4446[i] = (char *(*)()) F1086_9790_4446_18;}
	R4446[590] = (char *(*)()) F681_5539_4446_18;
}
static void F578_4957_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F578_4957(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F579_4957_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F579_4957(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F580_4957_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F580_4957(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F581_4957_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F581_4957(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F582_4957_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F582_4957(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F583_4957_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F583_4957(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F584_4957_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F584_4957(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F585_4957_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F585_4957(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F586_4957_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F586_4957(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F587_4957_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F587_4957(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F588_4957_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F588_4957(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F589_4957_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F589_4957(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F656_5362_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F656_5362(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F657_5362_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F657_5362(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F658_5362_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F658_5362(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static void F659_5362_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F659_5362(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F660_5362_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F660_5362(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F664_5486_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F664_5486(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F665_5486_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F665_5486(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F666_5486_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F666_5486(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F667_5486_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F667_5486(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F668_5486_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F668_5486(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F669_5486_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F669_5486(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F670_5486_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F670_5486(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F671_5486_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F671_5486(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F672_5486_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F672_5486(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F673_5486_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F673_5486(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F674_5486_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F674_5486(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F675_5486_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F675_5486(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F681_5539_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F681_5539(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F682_5539_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F682_5539(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1083_9625_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1083_9625(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1086_9790_4446_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1086_9790(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y4448_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype32[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype33[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype34[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype35[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype36[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype37[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype38[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype39[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype40[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype41[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype42[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype43[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype44[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype45[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype46[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype47[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype48[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype49[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype50[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype51[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype52[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype53[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype54[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype55[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype56[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype57[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype58[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype59[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype60[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype61[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype62[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype63[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype64[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype65[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype66[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype67[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype68[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype69[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype70[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype71[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype72[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype73[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype74[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype75[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype76[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype77[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype78[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype79[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype80[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype81[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype82[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype83[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype84[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype85[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype86[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype87[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype88[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype89[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype90[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype91[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype92[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype93[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype94[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype95[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype96[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype97[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype98[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype99[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype100[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype101[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype102[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype103[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype104[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype105[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype106[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype107[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype108[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype109[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype110[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype111[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype112[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype113[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype114[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype115[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype116[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype117[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype118[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype119[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype120[] = {1077,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype121[] = {1077,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype122[] = {1085,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype123[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype124[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype125[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype126[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype127[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype128[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype129[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype130[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype131[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype132[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype133[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype134[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype135[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype136[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype137[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype138[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype139[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype140[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype141[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype142[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype143[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype144[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype145[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype146[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype147[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype148[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype149[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype150[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype151[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype152[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype153[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype154[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype155[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype156[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype157[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype158[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype159[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype160[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype161[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype162[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype163[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype164[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype165[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype166[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype167[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype168[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype169[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype170[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype171[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype172[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype173[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype174[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype175[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype176[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype177[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype178[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype179[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype180[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype181[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype182[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype183[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype184[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype185[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype186[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype187[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype188[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype189[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype190[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype191[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype192[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype193[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype194[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype195[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype196[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype197[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype198[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype199[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype200[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype201[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype202[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype203[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype204[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype205[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype206[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype207[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype208[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype209[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype210[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype211[] = {1033,0xFFFF};
static EIF_TYPE_INDEX Y4448_pgtype212[] = {1033,0xFFFF};
EIF_TYPE_INDEX *Y4448_gen_type [1301];
EIF_TYPE_INDEX Y4448 [1301];
void Y4448_init (void)
{
	egc_routines_types [4448] = Y4448;
	egc_routines_gen_types [4448] = Y4448_gen_type;
	egc_routines_offset [4448] = 411;
	Y4448_gen_type [0] = Y4448_pgtype0;
	Y4448_gen_type [1] = Y4448_pgtype1;
	Y4448_gen_type [2] = Y4448_pgtype2;
	Y4448_gen_type [3] = Y4448_pgtype3;
	Y4448_gen_type [4] = Y4448_pgtype4;
	Y4448_gen_type [5] = Y4448_pgtype5;
	Y4448_gen_type [6] = Y4448_pgtype6;
	Y4448_gen_type [7] = Y4448_pgtype7;
	Y4448_gen_type [8] = Y4448_pgtype8;
	Y4448_gen_type [9] = Y4448_pgtype9;
	Y4448_gen_type [10] = Y4448_pgtype10;
	Y4448_gen_type [11] = Y4448_pgtype11;
	Y4448_gen_type [12] = Y4448_pgtype12;
	Y4448_gen_type [13] = Y4448_pgtype13;
	Y4448_gen_type [14] = Y4448_pgtype14;
	Y4448_gen_type [15] = Y4448_pgtype15;
	Y4448_gen_type [16] = Y4448_pgtype16;
	Y4448_gen_type [17] = Y4448_pgtype17;
	Y4448_gen_type [18] = Y4448_pgtype18;
	Y4448_gen_type [19] = Y4448_pgtype19;
	Y4448_gen_type [20] = Y4448_pgtype20;
	Y4448_gen_type [21] = Y4448_pgtype21;
	Y4448_gen_type [22] = Y4448_pgtype22;
	Y4448_gen_type [23] = Y4448_pgtype23;
	Y4448_gen_type [24] = Y4448_pgtype24;
	Y4448_gen_type [25] = Y4448_pgtype25;
	Y4448_gen_type [26] = Y4448_pgtype26;
	Y4448_gen_type [27] = Y4448_pgtype27;
	Y4448_gen_type [28] = Y4448_pgtype28;
	Y4448_gen_type [29] = Y4448_pgtype29;
	Y4448_gen_type [30] = Y4448_pgtype30;
	Y4448_gen_type [31] = Y4448_pgtype31;
	Y4448_gen_type [152] = Y4448_pgtype32;
	Y4448_gen_type [153] = Y4448_pgtype33;
	Y4448_gen_type [154] = Y4448_pgtype34;
	Y4448_gen_type [155] = Y4448_pgtype35;
	Y4448_gen_type [156] = Y4448_pgtype36;
	Y4448_gen_type [157] = Y4448_pgtype37;
	Y4448_gen_type [158] = Y4448_pgtype38;
	Y4448_gen_type [159] = Y4448_pgtype39;
	Y4448_gen_type [160] = Y4448_pgtype40;
	Y4448_gen_type [161] = Y4448_pgtype41;
	Y4448_gen_type [162] = Y4448_pgtype42;
	Y4448_gen_type [163] = Y4448_pgtype43;
	Y4448_gen_type [164] = Y4448_pgtype44;
	Y4448_gen_type [165] = Y4448_pgtype45;
	Y4448_gen_type [166] = Y4448_pgtype46;
	Y4448_gen_type [167] = Y4448_pgtype47;
	Y4448_gen_type [168] = Y4448_pgtype48;
	Y4448_gen_type [169] = Y4448_pgtype49;
	Y4448_gen_type [170] = Y4448_pgtype50;
	Y4448_gen_type [171] = Y4448_pgtype51;
	Y4448_gen_type [172] = Y4448_pgtype52;
	Y4448_gen_type [173] = Y4448_pgtype53;
	Y4448_gen_type [174] = Y4448_pgtype54;
	Y4448_gen_type [175] = Y4448_pgtype55;
	Y4448_gen_type [176] = Y4448_pgtype56;
	Y4448_gen_type [177] = Y4448_pgtype57;
	Y4448_gen_type [178] = Y4448_pgtype58;
	Y4448_gen_type [179] = Y4448_pgtype59;
	Y4448_gen_type [180] = Y4448_pgtype60;
	Y4448_gen_type [181] = Y4448_pgtype61;
	Y4448_gen_type [182] = Y4448_pgtype62;
	Y4448_gen_type [183] = Y4448_pgtype63;
	Y4448_gen_type [184] = Y4448_pgtype64;
	Y4448_gen_type [185] = Y4448_pgtype65;
	Y4448_gen_type [186] = Y4448_pgtype66;
	Y4448_gen_type [187] = Y4448_pgtype67;
	Y4448_gen_type [188] = Y4448_pgtype68;
	Y4448_gen_type [189] = Y4448_pgtype69;
	Y4448_gen_type [190] = Y4448_pgtype70;
	Y4448_gen_type [191] = Y4448_pgtype71;
	Y4448_gen_type [192] = Y4448_pgtype72;
	Y4448_gen_type [193] = Y4448_pgtype73;
	Y4448_gen_type [194] = Y4448_pgtype74;
	Y4448_gen_type [195] = Y4448_pgtype75;
	Y4448_gen_type [196] = Y4448_pgtype76;
	Y4448_gen_type [197] = Y4448_pgtype77;
	Y4448_gen_type [198] = Y4448_pgtype78;
	Y4448_gen_type [199] = Y4448_pgtype79;
	Y4448_gen_type [200] = Y4448_pgtype80;
	Y4448_gen_type [201] = Y4448_pgtype81;
	Y4448_gen_type [202] = Y4448_pgtype82;
	Y4448_gen_type [203] = Y4448_pgtype83;
	Y4448_gen_type [204] = Y4448_pgtype84;
	Y4448_gen_type [205] = Y4448_pgtype85;
	Y4448_gen_type [206] = Y4448_pgtype86;
	Y4448_gen_type [207] = Y4448_pgtype87;
	Y4448_gen_type [208] = Y4448_pgtype88;
	Y4448_gen_type [209] = Y4448_pgtype89;
	Y4448_gen_type [210] = Y4448_pgtype90;
	Y4448_gen_type [211] = Y4448_pgtype91;
	Y4448_gen_type [212] = Y4448_pgtype92;
	Y4448_gen_type [213] = Y4448_pgtype93;
	Y4448_gen_type [214] = Y4448_pgtype94;
	Y4448_gen_type [215] = Y4448_pgtype95;
	Y4448_gen_type [216] = Y4448_pgtype96;
	Y4448_gen_type [217] = Y4448_pgtype97;
	Y4448_gen_type [218] = Y4448_pgtype98;
	Y4448_gen_type [219] = Y4448_pgtype99;
	Y4448_gen_type [220] = Y4448_pgtype100;
	Y4448_gen_type [221] = Y4448_pgtype101;
	Y4448_gen_type [222] = Y4448_pgtype102;
	Y4448_gen_type [223] = Y4448_pgtype103;
	Y4448_gen_type [224] = Y4448_pgtype104;
	Y4448_gen_type [225] = Y4448_pgtype105;
	Y4448_gen_type [226] = Y4448_pgtype106;
	Y4448_gen_type [227] = Y4448_pgtype107;
	Y4448_gen_type [228] = Y4448_pgtype108;
	Y4448_gen_type [229] = Y4448_pgtype109;
	Y4448_gen_type [230] = Y4448_pgtype110;
	Y4448_gen_type [231] = Y4448_pgtype111;
	Y4448_gen_type [232] = Y4448_pgtype112;
	Y4448_gen_type [233] = Y4448_pgtype113;
	Y4448_gen_type [243] = Y4448_pgtype114;
	Y4448_gen_type [244] = Y4448_pgtype115;
	Y4448_gen_type [245] = Y4448_pgtype116;
	Y4448_gen_type [246] = Y4448_pgtype117;
	Y4448_gen_type [247] = Y4448_pgtype118;
	Y4448_gen_type [248] = Y4448_pgtype119;
	Y4448_gen_type [249] = Y4448_pgtype120;
	Y4448_gen_type [250] = Y4448_pgtype121;
	Y4448_gen_type [251] = Y4448_pgtype122;
	Y4448_gen_type [252] = Y4448_pgtype123;
	Y4448_gen_type [253] = Y4448_pgtype124;
	Y4448_gen_type [254] = Y4448_pgtype125;
	Y4448_gen_type [255] = Y4448_pgtype126;
	Y4448_gen_type [256] = Y4448_pgtype127;
	Y4448_gen_type [257] = Y4448_pgtype128;
	Y4448_gen_type [258] = Y4448_pgtype129;
	Y4448_gen_type [259] = Y4448_pgtype130;
	Y4448_gen_type [260] = Y4448_pgtype131;
	Y4448_gen_type [261] = Y4448_pgtype132;
	Y4448_gen_type [262] = Y4448_pgtype133;
	Y4448_gen_type [263] = Y4448_pgtype134;
	Y4448_gen_type [264] = Y4448_pgtype135;
	Y4448_gen_type [265] = Y4448_pgtype136;
	Y4448_gen_type [266] = Y4448_pgtype137;
	Y4448_gen_type [267] = Y4448_pgtype138;
	Y4448_gen_type [268] = Y4448_pgtype139;
	Y4448_gen_type [269] = Y4448_pgtype140;
	Y4448_gen_type [270] = Y4448_pgtype141;
	Y4448_gen_type [271] = Y4448_pgtype142;
	Y4448_gen_type [272] = Y4448_pgtype143;
	Y4448_gen_type [273] = Y4448_pgtype144;
	Y4448_gen_type [274] = Y4448_pgtype145;
	Y4448_gen_type [275] = Y4448_pgtype146;
	Y4448_gen_type [276] = Y4448_pgtype147;
	Y4448_gen_type [401] = Y4448_pgtype148;
	Y4448_gen_type [402] = Y4448_pgtype149;
	Y4448_gen_type [403] = Y4448_pgtype150;
	Y4448_gen_type [404] = Y4448_pgtype151;
	Y4448_gen_type [405] = Y4448_pgtype152;
	Y4448_gen_type [406] = Y4448_pgtype153;
	Y4448_gen_type [407] = Y4448_pgtype154;
	Y4448_gen_type [408] = Y4448_pgtype155;
	Y4448_gen_type [409] = Y4448_pgtype156;
	Y4448_gen_type [410] = Y4448_pgtype157;
	Y4448_gen_type [411] = Y4448_pgtype158;
	Y4448_gen_type [412] = Y4448_pgtype159;
	Y4448_gen_type [413] = Y4448_pgtype160;
	Y4448_gen_type [414] = Y4448_pgtype161;
	Y4448_gen_type [415] = Y4448_pgtype162;
	Y4448_gen_type [416] = Y4448_pgtype163;
	Y4448_gen_type [417] = Y4448_pgtype164;
	Y4448_gen_type [418] = Y4448_pgtype165;
	Y4448_gen_type [419] = Y4448_pgtype166;
	Y4448_gen_type [420] = Y4448_pgtype167;
	Y4448_gen_type [421] = Y4448_pgtype168;
	Y4448_gen_type [422] = Y4448_pgtype169;
	Y4448_gen_type [423] = Y4448_pgtype170;
	Y4448_gen_type [424] = Y4448_pgtype171;
	Y4448_gen_type [425] = Y4448_pgtype172;
	Y4448_gen_type [533] = Y4448_pgtype173;
	Y4448_gen_type [534] = Y4448_pgtype174;
	Y4448_gen_type [535] = Y4448_pgtype175;
	Y4448_gen_type [671] = Y4448_pgtype176;
	Y4448_gen_type [674] = Y4448_pgtype177;
	Y4448_gen_type [675] = Y4448_pgtype178;
	Y4448_gen_type [708] = Y4448_pgtype179;
	Y4448_gen_type [710] = Y4448_pgtype180;
	Y4448_gen_type [711] = Y4448_pgtype181;
	Y4448_gen_type [726] = Y4448_pgtype182;
	Y4448_gen_type [727] = Y4448_pgtype183;
	Y4448_gen_type [756] = Y4448_pgtype184;
	Y4448_gen_type [767] = Y4448_pgtype185;
	Y4448_gen_type [773] = Y4448_pgtype186;
	Y4448_gen_type [774] = Y4448_pgtype187;
	Y4448_gen_type [775] = Y4448_pgtype188;
	Y4448_gen_type [784] = Y4448_pgtype189;
	Y4448_gen_type [788] = Y4448_pgtype190;
	Y4448_gen_type [789] = Y4448_pgtype191;
	Y4448_gen_type [790] = Y4448_pgtype192;
	Y4448_gen_type [791] = Y4448_pgtype193;
	Y4448_gen_type [792] = Y4448_pgtype194;
	Y4448_gen_type [793] = Y4448_pgtype195;
	Y4448_gen_type [794] = Y4448_pgtype196;
	Y4448_gen_type [795] = Y4448_pgtype197;
	Y4448_gen_type [796] = Y4448_pgtype198;
	Y4448_gen_type [797] = Y4448_pgtype199;
	Y4448_gen_type [828] = Y4448_pgtype200;
	Y4448_gen_type [829] = Y4448_pgtype201;
	Y4448_gen_type [831] = Y4448_pgtype202;
	Y4448_gen_type [832] = Y4448_pgtype203;
	Y4448_gen_type [841] = Y4448_pgtype204;
	Y4448_gen_type [842] = Y4448_pgtype205;
	Y4448_gen_type [843] = Y4448_pgtype206;
	Y4448_gen_type [844] = Y4448_pgtype207;
	Y4448_gen_type [849] = Y4448_pgtype208;
	Y4448_gen_type [850] = Y4448_pgtype209;
	Y4448_gen_type [1297] = Y4448_pgtype210;
	Y4448_gen_type [1299] = Y4448_pgtype211;
	Y4448_gen_type [1300] = Y4448_pgtype212;
	{long i; for (i = 152; i < 234; i++) Y4448[i] = 1033;};
	{long i; for (i = 249; i < 251; i++) Y4448[i] = 1077;};
	Y4448[251] = 1085;
	{long i; for (i = 252; i < 277; i++) Y4448[i] = 1033;};
	{long i; for (i = 401; i < 426; i++) Y4448[i] = 1033;};
	{long i; for (i = 533; i < 536; i++) Y4448[i] = 1033;};
	Y4448[671] = 1033;
	{long i; for (i = 674; i < 676; i++) Y4448[i] = 1033;};
	Y4448[708] = 1033;
	{long i; for (i = 710; i < 712; i++) Y4448[i] = 1033;};
	{long i; for (i = 726; i < 728; i++) Y4448[i] = 1033;};
	Y4448[756] = 1033;
	Y4448[767] = 1033;
	{long i; for (i = 773; i < 776; i++) Y4448[i] = 1033;};
	Y4448[784] = 1033;
	{long i; for (i = 788; i < 798; i++) Y4448[i] = 1033;};
	{long i; for (i = 828; i < 830; i++) Y4448[i] = 1033;};
	{long i; for (i = 831; i < 833; i++) Y4448[i] = 1033;};
	{long i; for (i = 841; i < 845; i++) Y4448[i] = 1033;};
	{long i; for (i = 849; i < 851; i++) Y4448[i] = 1033;};
	Y4448[1297] = 1033;
	{long i; for (i = 1299; i < 1301; i++) Y4448[i] = 1033;};
}

char *(*R4449[514])();
void R4449_init () {
	R4449[0] = (char *(*)()) F655_5368;
	R4449[1] = (char *(*)()) F656_5368_4449_4;
	R4449[2] = (char *(*)()) F657_5368;
	R4449[3] = (char *(*)()) F658_5368_4449_4;
	R4449[4] = (char *(*)()) F659_5368_4449_4;
	R4449[5] = (char *(*)()) F660_5368;
	R4449[6] = (char *(*)()) F655_5368;
	R4449[7] = (char *(*)()) F657_5368;
	R4449[8] = (char *(*)()) F655_5368;
	R4449[9] = (char *(*)()) F664_5502_4449_4;
	R4449[10] = (char *(*)()) F665_5502_4449_4;
	R4449[11] = (char *(*)()) F666_5502_4449_4;
	R4449[12] = (char *(*)()) F667_5502_4449_4;
	R4449[13] = (char *(*)()) F668_5502_4449_4;
	R4449[14] = (char *(*)()) F669_5502_4449_4;
	R4449[15] = (char *(*)()) F670_5502_4449_4;
	R4449[16] = (char *(*)()) F671_5502_4449_4;
	R4449[17] = (char *(*)()) F672_5502_4449_4;
	R4449[18] = (char *(*)()) F673_5502_4449_4;
	R4449[19] = (char *(*)()) F674_5502_4449_4;
	R4449[20] = (char *(*)()) F675_5502_4449_4;
	R4449[21] = (char *(*)()) F664_5502_4449_4;
	R4449[22] = (char *(*)()) F671_5502_4449_4;
	R4449[23] = (char *(*)()) F669_5502_4449_4;
	R4449[24] = (char *(*)()) F664_5502_4449_4;
	R4449[25] = (char *(*)()) F671_5502_4449_4;
	R4449[28] = (char *(*)()) F664_5502_4449_4;
	R4449[29] = (char *(*)()) F671_5502_4449_4;
	R4449[30] = (char *(*)()) F664_5502_4449_4;
	R4449[31] = (char *(*)()) F671_5502_4449_4;
	{long i; for (i = 32; i < 34; i++) R4449[i] = (char *(*)()) F664_5502_4449_4;}
	{long i; for (i = 158; i < 160; i++) R4449[i] = (char *(*)()) F664_5502_4449_4;}
	{long i; for (i = 161; i < 183; i++) R4449[i] = (char *(*)()) F664_5502_4449_4;}
	{long i; for (i = 290; i < 293; i++) R4449[i] = (char *(*)()) F664_5502_4449_4;}
	R4449[428] = (char *(*)()) F1083_9659_4449_4;
	{long i; for (i = 431; i < 433; i++) R4449[i] = (char *(*)()) F1086_9824_4449_4;}
	R4449[513] = (char *(*)()) F664_5502_4449_4;
}
static void F656_5368_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F656_5368(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F658_5368_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5368(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F659_5368_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5368(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F664_5502_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5502(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F665_5502_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5502(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F666_5502_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5502(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F667_5502_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5502(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F668_5502_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5502(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F669_5502_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F669_5502(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F670_5502_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F670_5502(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F671_5502_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F671_5502(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F672_5502_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F672_5502(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F673_5502_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F673_5502(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F674_5502_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F674_5502(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F675_5502_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F675_5502(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1083_9659_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1083_9659(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1086_9824_4449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1086_9824(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4450[1178])();
void R4450_init () {
	R4450[0] = (char *(*)()) F535_4843;
	R4450[104] = (char *(*)()) F639_5065;
	R4450[105] = (char *(*)()) F640_5065_4450_1;
	R4450[106] = (char *(*)()) F641_5065_4450_1;
	R4450[107] = (char *(*)()) F642_5110;
	R4450[108] = (char *(*)()) F643_5110_4450_1;
	R4450[109] = (char *(*)()) F644_5110_4450_1;
	R4450[110] = (char *(*)()) F645_5125;
	R4450[129] = (char *(*)()) F664_5452;
	R4450[130] = (char *(*)()) F665_5452_4450_1;
	R4450[131] = (char *(*)()) F666_5452_4450_1;
	R4450[132] = (char *(*)()) F667_5452_4450_1;
	R4450[133] = (char *(*)()) F668_5452_4450_1;
	R4450[134] = (char *(*)()) F669_5452_4450_1;
	R4450[135] = (char *(*)()) F670_5452_4450_1;
	R4450[136] = (char *(*)()) F671_5452_4450_1;
	R4450[137] = (char *(*)()) F672_5452_4450_1;
	R4450[138] = (char *(*)()) F673_5452_4450_1;
	R4450[139] = (char *(*)()) F674_5452_4450_1;
	R4450[140] = (char *(*)()) F675_5452_4450_1;
	R4450[141] = (char *(*)()) F664_5452;
	R4450[142] = (char *(*)()) F671_5452_4450_1;
	R4450[143] = (char *(*)()) F669_5452_4450_1;
	R4450[144] = (char *(*)()) F664_5452;
	R4450[145] = (char *(*)()) F671_5452_4450_1;
	R4450[148] = (char *(*)()) F664_5452;
	R4450[149] = (char *(*)()) F671_5452_4450_1;
	R4450[150] = (char *(*)()) F664_5452;
	R4450[151] = (char *(*)()) F671_5452_4450_1;
	{long i; for (i = 152; i < 154; i++) R4450[i] = (char *(*)()) F664_5452;}
	{long i; for (i = 172; i < 174; i++) R4450[i] = (char *(*)()) F482_4799_4450_1;}
	{long i; for (i = 278; i < 280; i++) R4450[i] = (char *(*)()) F664_5452;}
	{long i; for (i = 281; i < 303; i++) R4450[i] = (char *(*)()) F664_5452;}
	{long i; for (i = 400; i < 402; i++) R4450[i] = (char *(*)()) F934_7256_4450_1;}
	{long i; for (i = 410; i < 413; i++) R4450[i] = (char *(*)()) F664_5452;}
	R4450[604] = (char *(*)()) F1120_10288;
	R4450[633] = (char *(*)()) F664_5452;
	R4450[644] = (char *(*)()) F1120_10288;
	{long i; for (i = 651; i < 653; i++) R4450[i] = (char *(*)()) F1120_10288;}
	R4450[661] = (char *(*)()) F1195_10952;
	{long i; for (i = 666; i < 668; i++) R4450[i] = (char *(*)()) F1120_10288;}
	{long i; for (i = 669; i < 675; i++) R4450[i] = (char *(*)()) F1120_10288;}
	{long i; for (i = 705; i < 707; i++) R4450[i] = (char *(*)()) F1120_10288;}
	{long i; for (i = 708; i < 710; i++) R4450[i] = (char *(*)()) F1120_10288;}
	{long i; for (i = 719; i < 722; i++) R4450[i] = (char *(*)()) F1120_10288;}
	{long i; for (i = 726; i < 728; i++) R4450[i] = (char *(*)()) F1120_10288;}
	R4450[985] = (char *(*)()) F934_7256_4450_1;
	R4450[1092] = (char *(*)()) F482_4799_4450_1;
	R4450[1174] = (char *(*)()) F1120_10288;
	{long i; for (i = 1176; i < 1178; i++) R4450[i] = (char *(*)()) F1120_10288;}
}
static EIF_REFERENCE F640_5065_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F640_5065(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_5065_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F641_5065(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F643_5110_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F643_5110(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F644_5110_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F644_5110(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5452_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F665_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5452_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F666_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1009, 0x00).id, 1009, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5452_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F667_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1012, 0x00).id, 1012, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5452_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F668_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1003, 0x00).id, 1003, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_5452_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F669_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_5452_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F670_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1018, 0x00).id, 1018, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F671_5452_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F671_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F672_5452_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F672_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F673_5452_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F673_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F674_5452_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F674_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F675_5452_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F675_5452(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F482_4799_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F482_4799(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F934_7256_4450_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F934_7256(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y4450_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype125[] = {1071,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype126[] = {1071,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype127[] = {1071,0xFFF9,1,997,0,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype128[] = {1071,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype129[] = {1071,0xFFF9,1,997,1033,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype130[] = {1071,0xFFF9,1,997,1175,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype131[] = {1071,0xFFF9,1,997,1184,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype132[] = {1071,0xFFF9,1,997,1168,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype133[] = {1071,0xFFF9,1,997,1126,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype134[] = {1071,0xFFF9,1,997,1128,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype135[] = {1071,0xFFF9,1,997,1193,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype136[] = {1071,0xFFF9,1,997,1033,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype137[] = {1071,0xFFF9,1,997,1167,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype138[] = {1071,0xFFF9,1,997,942,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype139[] = {1071,0xFFF9,1,997,1163,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype140[] = {1071,0xFFF9,1,997,1189,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype141[] = {1071,0xFFF9,5,997,1006,1033,1033,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype142[] = {1071,0xFFF9,4,997,1033,1033,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype143[] = {1071,0xFFF9,1,997,1082,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype144[] = {1071,0xFFF9,1,997,1033,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype145[] = {1071,0xFFF9,1,997,1518,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype146[] = {1071,0xFFF9,7,997,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype147[] = {1071,0xFFF9,2,997,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype148[] = {1071,0xFFF9,3,997,1033,1033,942,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype149[] = {1071,0xFFF9,0,997,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype150[] = {1071,0xFFF9,8,997,1033,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4450_pgtype152[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y4450_gen_type [1269];
EIF_TYPE_INDEX Y4450 [1269];
void Y4450_init (void)
{
	egc_routines_types [4450] = Y4450;
	egc_routines_gen_types [4450] = Y4450_gen_type;
	egc_routines_offset [4450] = 443;
	Y4450_gen_type [0] = Y4450_pgtype0;
	Y4450_gen_type [1] = Y4450_pgtype1;
	Y4450_gen_type [2] = Y4450_pgtype2;
	Y4450_gen_type [3] = Y4450_pgtype3;
	Y4450_gen_type [4] = Y4450_pgtype4;
	Y4450_gen_type [5] = Y4450_pgtype5;
	Y4450_gen_type [6] = Y4450_pgtype6;
	Y4450_gen_type [7] = Y4450_pgtype7;
	Y4450_gen_type [8] = Y4450_pgtype8;
	Y4450_gen_type [9] = Y4450_pgtype9;
	Y4450_gen_type [10] = Y4450_pgtype10;
	Y4450_gen_type [11] = Y4450_pgtype11;
	Y4450_gen_type [12] = Y4450_pgtype12;
	Y4450_gen_type [13] = Y4450_pgtype13;
	Y4450_gen_type [14] = Y4450_pgtype14;
	Y4450_gen_type [15] = Y4450_pgtype15;
	Y4450_gen_type [16] = Y4450_pgtype16;
	Y4450_gen_type [17] = Y4450_pgtype17;
	Y4450_gen_type [18] = Y4450_pgtype18;
	Y4450_gen_type [19] = Y4450_pgtype19;
	Y4450_gen_type [20] = Y4450_pgtype20;
	Y4450_gen_type [21] = Y4450_pgtype21;
	Y4450_gen_type [22] = Y4450_pgtype22;
	Y4450_gen_type [23] = Y4450_pgtype23;
	Y4450_gen_type [38] = Y4450_pgtype24;
	Y4450_gen_type [75] = Y4450_pgtype25;
	Y4450_gen_type [76] = Y4450_pgtype26;
	Y4450_gen_type [77] = Y4450_pgtype27;
	Y4450_gen_type [78] = Y4450_pgtype28;
	Y4450_gen_type [79] = Y4450_pgtype29;
	Y4450_gen_type [80] = Y4450_pgtype30;
	Y4450_gen_type [81] = Y4450_pgtype31;
	Y4450_gen_type [82] = Y4450_pgtype32;
	Y4450_gen_type [83] = Y4450_pgtype33;
	Y4450_gen_type [84] = Y4450_pgtype34;
	Y4450_gen_type [85] = Y4450_pgtype35;
	Y4450_gen_type [86] = Y4450_pgtype36;
	Y4450_gen_type [87] = Y4450_pgtype37;
	Y4450_gen_type [88] = Y4450_pgtype38;
	Y4450_gen_type [89] = Y4450_pgtype39;
	Y4450_gen_type [90] = Y4450_pgtype40;
	Y4450_gen_type [91] = Y4450_pgtype41;
	Y4450_gen_type [92] = Y4450_pgtype42;
	Y4450_gen_type [93] = Y4450_pgtype43;
	Y4450_gen_type [94] = Y4450_pgtype44;
	Y4450_gen_type [95] = Y4450_pgtype45;
	Y4450_gen_type [147] = Y4450_pgtype46;
	Y4450_gen_type [148] = Y4450_pgtype47;
	Y4450_gen_type [149] = Y4450_pgtype48;
	Y4450_gen_type [150] = Y4450_pgtype49;
	Y4450_gen_type [151] = Y4450_pgtype50;
	Y4450_gen_type [152] = Y4450_pgtype51;
	Y4450_gen_type [153] = Y4450_pgtype52;
	Y4450_gen_type [154] = Y4450_pgtype53;
	Y4450_gen_type [155] = Y4450_pgtype54;
	Y4450_gen_type [156] = Y4450_pgtype55;
	Y4450_gen_type [157] = Y4450_pgtype56;
	Y4450_gen_type [158] = Y4450_pgtype57;
	Y4450_gen_type [159] = Y4450_pgtype58;
	Y4450_gen_type [160] = Y4450_pgtype59;
	Y4450_gen_type [161] = Y4450_pgtype60;
	Y4450_gen_type [162] = Y4450_pgtype61;
	Y4450_gen_type [163] = Y4450_pgtype62;
	Y4450_gen_type [164] = Y4450_pgtype63;
	Y4450_gen_type [165] = Y4450_pgtype64;
	Y4450_gen_type [166] = Y4450_pgtype65;
	Y4450_gen_type [167] = Y4450_pgtype66;
	Y4450_gen_type [168] = Y4450_pgtype67;
	Y4450_gen_type [169] = Y4450_pgtype68;
	Y4450_gen_type [170] = Y4450_pgtype69;
	Y4450_gen_type [171] = Y4450_pgtype70;
	Y4450_gen_type [172] = Y4450_pgtype71;
	Y4450_gen_type [173] = Y4450_pgtype72;
	Y4450_gen_type [174] = Y4450_pgtype73;
	Y4450_gen_type [175] = Y4450_pgtype74;
	Y4450_gen_type [176] = Y4450_pgtype75;
	Y4450_gen_type [177] = Y4450_pgtype76;
	Y4450_gen_type [178] = Y4450_pgtype77;
	Y4450_gen_type [179] = Y4450_pgtype78;
	Y4450_gen_type [180] = Y4450_pgtype79;
	Y4450_gen_type [181] = Y4450_pgtype80;
	Y4450_gen_type [182] = Y4450_pgtype81;
	Y4450_gen_type [183] = Y4450_pgtype82;
	Y4450_gen_type [184] = Y4450_pgtype83;
	Y4450_gen_type [185] = Y4450_pgtype84;
	Y4450_gen_type [186] = Y4450_pgtype85;
	Y4450_gen_type [187] = Y4450_pgtype86;
	Y4450_gen_type [188] = Y4450_pgtype87;
	Y4450_gen_type [189] = Y4450_pgtype88;
	Y4450_gen_type [190] = Y4450_pgtype89;
	Y4450_gen_type [191] = Y4450_pgtype90;
	Y4450_gen_type [192] = Y4450_pgtype91;
	Y4450_gen_type [193] = Y4450_pgtype92;
	Y4450_gen_type [194] = Y4450_pgtype93;
	Y4450_gen_type [195] = Y4450_pgtype94;
	Y4450_gen_type [196] = Y4450_pgtype95;
	Y4450_gen_type [197] = Y4450_pgtype96;
	Y4450_gen_type [198] = Y4450_pgtype97;
	Y4450_gen_type [199] = Y4450_pgtype98;
	Y4450_gen_type [200] = Y4450_pgtype99;
	Y4450_gen_type [201] = Y4450_pgtype100;
	Y4450_gen_type [209] = Y4450_pgtype101;
	Y4450_gen_type [220] = Y4450_pgtype102;
	Y4450_gen_type [221] = Y4450_pgtype103;
	Y4450_gen_type [222] = Y4450_pgtype104;
	Y4450_gen_type [223] = Y4450_pgtype105;
	Y4450_gen_type [224] = Y4450_pgtype106;
	Y4450_gen_type [225] = Y4450_pgtype107;
	Y4450_gen_type [226] = Y4450_pgtype108;
	Y4450_gen_type [227] = Y4450_pgtype109;
	Y4450_gen_type [228] = Y4450_pgtype110;
	Y4450_gen_type [229] = Y4450_pgtype111;
	Y4450_gen_type [230] = Y4450_pgtype112;
	Y4450_gen_type [231] = Y4450_pgtype113;
	Y4450_gen_type [232] = Y4450_pgtype114;
	Y4450_gen_type [233] = Y4450_pgtype115;
	Y4450_gen_type [234] = Y4450_pgtype116;
	Y4450_gen_type [235] = Y4450_pgtype117;
	Y4450_gen_type [236] = Y4450_pgtype118;
	Y4450_gen_type [237] = Y4450_pgtype119;
	Y4450_gen_type [238] = Y4450_pgtype120;
	Y4450_gen_type [239] = Y4450_pgtype121;
	Y4450_gen_type [240] = Y4450_pgtype122;
	Y4450_gen_type [241] = Y4450_pgtype123;
	Y4450_gen_type [242] = Y4450_pgtype124;
	Y4450_gen_type [244] = Y4450_pgtype125;
	Y4450_gen_type [369] = Y4450_pgtype126;
	Y4450_gen_type [370] = Y4450_pgtype127;
	Y4450_gen_type [371] = Y4450_pgtype128;
	Y4450_gen_type [372] = Y4450_pgtype129;
	Y4450_gen_type [373] = Y4450_pgtype130;
	Y4450_gen_type [374] = Y4450_pgtype131;
	Y4450_gen_type [375] = Y4450_pgtype132;
	Y4450_gen_type [376] = Y4450_pgtype133;
	Y4450_gen_type [377] = Y4450_pgtype134;
	Y4450_gen_type [378] = Y4450_pgtype135;
	Y4450_gen_type [379] = Y4450_pgtype136;
	Y4450_gen_type [380] = Y4450_pgtype137;
	Y4450_gen_type [381] = Y4450_pgtype138;
	Y4450_gen_type [382] = Y4450_pgtype139;
	Y4450_gen_type [383] = Y4450_pgtype140;
	Y4450_gen_type [384] = Y4450_pgtype141;
	Y4450_gen_type [385] = Y4450_pgtype142;
	Y4450_gen_type [386] = Y4450_pgtype143;
	Y4450_gen_type [387] = Y4450_pgtype144;
	Y4450_gen_type [388] = Y4450_pgtype145;
	Y4450_gen_type [389] = Y4450_pgtype146;
	Y4450_gen_type [390] = Y4450_pgtype147;
	Y4450_gen_type [391] = Y4450_pgtype148;
	Y4450_gen_type [392] = Y4450_pgtype149;
	Y4450_gen_type [393] = Y4450_pgtype150;
	Y4450_gen_type [676] = Y4450_pgtype151;
	Y4450_gen_type [678] = Y4450_pgtype152;
	Y4450[243] = 1098;
	Y4450[244] = 1071;
	{long i; for (i = 263; i < 265; i++) Y4450[i] = 1033;};
	{long i; for (i = 369; i < 394; i++) Y4450[i] = 1071;};
	{long i; for (i = 490; i < 493; i++) Y4450[i] = 1024;};
	{long i; for (i = 501; i < 504; i++) Y4450[i] = 943;};
	Y4450[679] = 1184;
	{long i; for (i = 694; i < 696; i++) Y4450[i] = 1175;};
	Y4450[724] = 1082;
	Y4450[735] = 1175;
	{long i; for (i = 741; i < 744; i++) Y4450[i] = 1184;};
	Y4450[752] = 1193;
	{long i; for (i = 756; i < 766; i++) Y4450[i] = 1193;};
	Y4450[796] = 1170;
	Y4450[797] = 1167;
	{long i; for (i = 799; i < 801; i++) Y4450[i] = 1168;};
	{long i; for (i = 809; i < 813; i++) Y4450[i] = 1189;};
	{long i; for (i = 817; i < 819; i++) Y4450[i] = 1184;};
	Y4450[1076] = 1024;
	Y4450[1183] = 1033;
	Y4450[1265] = 1193;
	Y4450[1267] = 1193;
	Y4450[1268] = 1184;
}

char *(*R4454[1074])();
void R4454_init () {
	R4454[0] = (char *(*)()) F639_5093;
	R4454[1] = (char *(*)()) F640_5093_4454_4;
	R4454[2] = (char *(*)()) F641_5093_4454_4;
	R4454[3] = (char *(*)()) F639_5093;
	R4454[4] = (char *(*)()) F640_5093_4454_4;
	R4454[5] = (char *(*)()) F641_5093_4454_4;
	R4454[6] = (char *(*)()) F639_5093;
	R4454[25] = (char *(*)()) F664_5491;
	R4454[26] = (char *(*)()) F665_5491_4454_4;
	R4454[27] = (char *(*)()) F666_5491_4454_4;
	R4454[28] = (char *(*)()) F667_5491_4454_4;
	R4454[29] = (char *(*)()) F668_5491_4454_4;
	R4454[30] = (char *(*)()) F669_5491_4454_4;
	R4454[31] = (char *(*)()) F670_5491_4454_4;
	R4454[32] = (char *(*)()) F671_5491_4454_4;
	R4454[33] = (char *(*)()) F672_5491_4454_4;
	R4454[34] = (char *(*)()) F673_5491_4454_4;
	R4454[35] = (char *(*)()) F674_5491_4454_4;
	R4454[36] = (char *(*)()) F675_5491_4454_4;
	R4454[37] = (char *(*)()) F664_5491;
	R4454[38] = (char *(*)()) F671_5491_4454_4;
	R4454[39] = (char *(*)()) F669_5491_4454_4;
	R4454[40] = (char *(*)()) F664_5491;
	R4454[41] = (char *(*)()) F671_5491_4454_4;
	R4454[44] = (char *(*)()) F681_5540;
	R4454[45] = (char *(*)()) F682_5540_4454_4;
	R4454[46] = (char *(*)()) F681_5540;
	R4454[47] = (char *(*)()) F682_5540_4454_4;
	{long i; for (i = 48; i < 50; i++) R4454[i] = (char *(*)()) F681_5540;}
	{long i; for (i = 174; i < 176; i++) R4454[i] = (char *(*)()) F681_5540;}
	{long i; for (i = 177; i < 199; i++) R4454[i] = (char *(*)()) F681_5540;}
	{long i; for (i = 306; i < 309; i++) R4454[i] = (char *(*)()) F945_7860;}
	R4454[500] = (char *(*)()) F1120_10325;
	R4454[529] = (char *(*)()) F681_5540;
	R4454[540] = (char *(*)()) F1120_10325;
	{long i; for (i = 547; i < 549; i++) R4454[i] = (char *(*)()) F1120_10325;}
	R4454[557] = (char *(*)()) F1195_10963;
	{long i; for (i = 562; i < 564; i++) R4454[i] = (char *(*)()) F1120_10325;}
	{long i; for (i = 565; i < 571; i++) R4454[i] = (char *(*)()) F1120_10325;}
	{long i; for (i = 601; i < 603; i++) R4454[i] = (char *(*)()) F1120_10325;}
	{long i; for (i = 604; i < 606; i++) R4454[i] = (char *(*)()) F1120_10325;}
	{long i; for (i = 615; i < 618; i++) R4454[i] = (char *(*)()) F1120_10325;}
	{long i; for (i = 622; i < 624; i++) R4454[i] = (char *(*)()) F1120_10325;}
	R4454[1070] = (char *(*)()) F1120_10325;
	{long i; for (i = 1072; i < 1074; i++) R4454[i] = (char *(*)()) F1120_10325;}
}
static void F640_5093_4454_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F640_5093(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F641_5093_4454_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F641_5093(Current, *(EIF_BOOLEAN *)arg1);
}
static void F665_5491_4454_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5491(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F666_5491_4454_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5491(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F667_5491_4454_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5491(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F668_5491_4454_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5491(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F669_5491_4454_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F669_5491(Current, *(EIF_BOOLEAN *)arg1);
}
static void F670_5491_4454_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F670_5491(Current, *(EIF_REAL_64 *)arg1);
}
static void F671_5491_4454_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F671_5491(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F672_5491_4454_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F672_5491(Current, *(EIF_POINTER *)arg1);
}
static void F673_5491_4454_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F673_5491(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F674_5491_4454_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F674_5491(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F675_5491_4454_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F675_5491(Current, *(EIF_REAL_32 *)arg1);
}
static void F682_5540_4454_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F682_5540(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4455[1178])();
void R4455_init () {
	R4455[0] = (char *(*)()) F535_4859;
	R4455[104] = (char *(*)()) F639_5096;
	R4455[105] = (char *(*)()) F640_5096;
	R4455[106] = (char *(*)()) F641_5096;
	R4455[107] = (char *(*)()) F642_5114;
	R4455[108] = (char *(*)()) F643_5114;
	R4455[109] = (char *(*)()) F644_5114;
	R4455[110] = (char *(*)()) F639_5097;
	R4455[129] = (char *(*)()) F664_5501;
	R4455[130] = (char *(*)()) F665_5501;
	R4455[131] = (char *(*)()) F666_5501;
	R4455[132] = (char *(*)()) F667_5501;
	R4455[133] = (char *(*)()) F668_5501;
	R4455[134] = (char *(*)()) F669_5501;
	R4455[135] = (char *(*)()) F670_5501;
	R4455[136] = (char *(*)()) F671_5501;
	R4455[137] = (char *(*)()) F672_5501;
	R4455[138] = (char *(*)()) F673_5501;
	R4455[139] = (char *(*)()) F674_5501;
	R4455[140] = (char *(*)()) F675_5501;
	R4455[141] = (char *(*)()) F676_5517;
	R4455[142] = (char *(*)()) F677_5517;
	R4455[143] = (char *(*)()) F678_5517;
	R4455[144] = (char *(*)()) F664_5501;
	R4455[145] = (char *(*)()) F671_5501;
	R4455[148] = (char *(*)()) F681_5541;
	R4455[149] = (char *(*)()) F682_5541;
	R4455[150] = (char *(*)()) F681_5541;
	R4455[151] = (char *(*)()) F682_5541;
	{long i; for (i = 152; i < 154; i++) R4455[i] = (char *(*)()) F681_5541;}
	{long i; for (i = 278; i < 280; i++) R4455[i] = (char *(*)()) F681_5541;}
	{long i; for (i = 281; i < 303; i++) R4455[i] = (char *(*)()) F681_5541;}
	{long i; for (i = 400; i < 402; i++) R4455[i] = (char *(*)()) F934_7461;}
	{long i; for (i = 410; i < 413; i++) R4455[i] = (char *(*)()) F945_7861;}
	R4455[604] = (char *(*)()) F1120_10316;
	R4455[633] = (char *(*)()) F681_5541;
	R4455[644] = (char *(*)()) F1120_10316;
	{long i; for (i = 651; i < 653; i++) R4455[i] = (char *(*)()) F1120_10316;}
	R4455[661] = (char *(*)()) F1196_11020;
	{long i; for (i = 666; i < 668; i++) R4455[i] = (char *(*)()) F1120_10316;}
	{long i; for (i = 669; i < 675; i++) R4455[i] = (char *(*)()) F1120_10316;}
	{long i; for (i = 705; i < 707; i++) R4455[i] = (char *(*)()) F1120_10316;}
	{long i; for (i = 708; i < 710; i++) R4455[i] = (char *(*)()) F1120_10316;}
	{long i; for (i = 719; i < 722; i++) R4455[i] = (char *(*)()) F1120_10316;}
	{long i; for (i = 726; i < 728; i++) R4455[i] = (char *(*)()) F1120_10316;}
	R4455[985] = (char *(*)()) F934_7461;
	R4455[1174] = (char *(*)()) F1120_10316;
	{long i; for (i = 1176; i < 1178; i++) R4455[i] = (char *(*)()) F1120_10316;}
}

char *(*R4456[1074])();
void R4456_init () {
	R4456[0] = (char *(*)()) F639_5069;
	R4456[1] = (char *(*)()) F640_5069;
	R4456[2] = (char *(*)()) F641_5069;
	R4456[3] = (char *(*)()) F639_5069;
	R4456[4] = (char *(*)()) F640_5069;
	R4456[5] = (char *(*)()) F641_5069;
	R4456[6] = (char *(*)()) F639_5069;
	R4456[25] = (char *(*)()) F664_5458;
	R4456[26] = (char *(*)()) F665_5458;
	R4456[27] = (char *(*)()) F666_5458;
	R4456[28] = (char *(*)()) F667_5458;
	R4456[29] = (char *(*)()) F668_5458;
	R4456[30] = (char *(*)()) F669_5458;
	R4456[31] = (char *(*)()) F670_5458;
	R4456[32] = (char *(*)()) F671_5458;
	R4456[33] = (char *(*)()) F672_5458;
	R4456[34] = (char *(*)()) F673_5458;
	R4456[35] = (char *(*)()) F674_5458;
	R4456[36] = (char *(*)()) F675_5458;
	R4456[37] = (char *(*)()) F664_5458;
	R4456[38] = (char *(*)()) F671_5458;
	R4456[39] = (char *(*)()) F669_5458;
	R4456[40] = (char *(*)()) F664_5458;
	R4456[41] = (char *(*)()) F671_5458;
	R4456[44] = (char *(*)()) F664_5458;
	R4456[45] = (char *(*)()) F671_5458;
	R4456[46] = (char *(*)()) F664_5458;
	R4456[47] = (char *(*)()) F671_5458;
	{long i; for (i = 48; i < 50; i++) R4456[i] = (char *(*)()) F664_5458;}
	{long i; for (i = 174; i < 176; i++) R4456[i] = (char *(*)()) F664_5458;}
	{long i; for (i = 177; i < 199; i++) R4456[i] = (char *(*)()) F664_5458;}
	{long i; for (i = 306; i < 309; i++) R4456[i] = (char *(*)()) F664_5458;}
	R4456[500] = (char *(*)()) F1120_10290;
	R4456[529] = (char *(*)()) F664_5458;
	R4456[540] = (char *(*)()) F1120_10290;
	{long i; for (i = 547; i < 549; i++) R4456[i] = (char *(*)()) F1120_10290;}
	R4456[557] = (char *(*)()) F1196_11031;
	{long i; for (i = 562; i < 564; i++) R4456[i] = (char *(*)()) F1120_10290;}
	{long i; for (i = 565; i < 571; i++) R4456[i] = (char *(*)()) F1120_10290;}
	{long i; for (i = 601; i < 603; i++) R4456[i] = (char *(*)()) F1120_10290;}
	{long i; for (i = 604; i < 606; i++) R4456[i] = (char *(*)()) F1120_10290;}
	{long i; for (i = 615; i < 618; i++) R4456[i] = (char *(*)()) F1120_10290;}
	{long i; for (i = 622; i < 624; i++) R4456[i] = (char *(*)()) F1120_10290;}
	R4456[1070] = (char *(*)()) F1120_10290;
	{long i; for (i = 1072; i < 1074; i++) R4456[i] = (char *(*)()) F1120_10290;}
}

static EIF_TYPE_INDEX Y4456_pgtype0[] = {243,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype1[] = {244,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype2[] = {245,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype3[] = {243,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype4[] = {244,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype5[] = {245,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype6[] = {243,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype7[] = {242,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype8[] = {242,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype9[] = {242,1184,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype10[] = {242,1175,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype11[] = {242,1175,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype12[] = {242,1175,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype13[] = {242,1184,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype14[] = {242,1184,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype15[] = {242,1184,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype16[] = {242,1193,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype17[] = {242,1193,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype18[] = {242,1193,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype19[] = {242,1193,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype20[] = {242,1193,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype21[] = {242,1193,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype22[] = {242,1193,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype23[] = {242,1193,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype24[] = {242,1193,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype25[] = {242,1193,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype26[] = {242,1170,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype27[] = {242,1167,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype28[] = {242,1168,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype29[] = {242,1168,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype30[] = {242,1189,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype31[] = {242,1189,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype32[] = {242,1189,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype33[] = {242,1189,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype34[] = {242,1184,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype35[] = {242,1184,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype36[] = {242,1193,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype37[] = {242,1193,0xFFFF};
static EIF_TYPE_INDEX Y4456_pgtype38[] = {242,1184,0xFFFF};
EIF_TYPE_INDEX *Y4456_gen_type [1257];
EIF_TYPE_INDEX Y4456 [1257];
void Y4456_init (void)
{
	egc_routines_types [4456] = Y4456;
	egc_routines_gen_types [4456] = Y4456_gen_type;
	egc_routines_offset [4456] = 455;
	Y4456_gen_type [183] = Y4456_pgtype0;
	Y4456_gen_type [184] = Y4456_pgtype1;
	Y4456_gen_type [185] = Y4456_pgtype2;
	Y4456_gen_type [186] = Y4456_pgtype3;
	Y4456_gen_type [187] = Y4456_pgtype4;
	Y4456_gen_type [188] = Y4456_pgtype5;
	Y4456_gen_type [189] = Y4456_pgtype6;
	Y4456_gen_type [664] = Y4456_pgtype7;
	Y4456_gen_type [666] = Y4456_pgtype8;
	Y4456_gen_type [667] = Y4456_pgtype9;
	Y4456_gen_type [682] = Y4456_pgtype10;
	Y4456_gen_type [683] = Y4456_pgtype11;
	Y4456_gen_type [723] = Y4456_pgtype12;
	Y4456_gen_type [729] = Y4456_pgtype13;
	Y4456_gen_type [730] = Y4456_pgtype14;
	Y4456_gen_type [731] = Y4456_pgtype15;
	Y4456_gen_type [744] = Y4456_pgtype16;
	Y4456_gen_type [745] = Y4456_pgtype17;
	Y4456_gen_type [746] = Y4456_pgtype18;
	Y4456_gen_type [747] = Y4456_pgtype19;
	Y4456_gen_type [748] = Y4456_pgtype20;
	Y4456_gen_type [749] = Y4456_pgtype21;
	Y4456_gen_type [750] = Y4456_pgtype22;
	Y4456_gen_type [751] = Y4456_pgtype23;
	Y4456_gen_type [752] = Y4456_pgtype24;
	Y4456_gen_type [753] = Y4456_pgtype25;
	Y4456_gen_type [784] = Y4456_pgtype26;
	Y4456_gen_type [785] = Y4456_pgtype27;
	Y4456_gen_type [787] = Y4456_pgtype28;
	Y4456_gen_type [788] = Y4456_pgtype29;
	Y4456_gen_type [797] = Y4456_pgtype30;
	Y4456_gen_type [798] = Y4456_pgtype31;
	Y4456_gen_type [799] = Y4456_pgtype32;
	Y4456_gen_type [800] = Y4456_pgtype33;
	Y4456_gen_type [805] = Y4456_pgtype34;
	Y4456_gen_type [806] = Y4456_pgtype35;
	Y4456_gen_type [1253] = Y4456_pgtype36;
	Y4456_gen_type [1255] = Y4456_pgtype37;
	Y4456_gen_type [1256] = Y4456_pgtype38;
	{long i; for (i = 0; i < 12; i++) Y4456[i] = 241;};
	{long i; for (i = 135; i < 183; i++) Y4456[i] = 241;};
	Y4456[183] = 243;
	Y4456[184] = 244;
	Y4456[185] = 245;
	Y4456[186] = 243;
	Y4456[187] = 244;
	Y4456[188] = 245;
	Y4456[189] = 243;
	{long i; for (i = 208; i < 233; i++) Y4456[i] = 247;};
	{long i; for (i = 357; i < 382; i++) Y4456[i] = 247;};
	{long i; for (i = 489; i < 492; i++) Y4456[i] = 247;};
	Y4456[664] = 242;
	{long i; for (i = 666; i < 668; i++) Y4456[i] = 242;};
	{long i; for (i = 682; i < 684; i++) Y4456[i] = 242;};
	Y4456[712] = 247;
	Y4456[723] = 242;
	{long i; for (i = 729; i < 732; i++) Y4456[i] = 242;};
	Y4456[740] = 241;
	{long i; for (i = 744; i < 754; i++) Y4456[i] = 242;};
	{long i; for (i = 784; i < 786; i++) Y4456[i] = 242;};
	{long i; for (i = 787; i < 789; i++) Y4456[i] = 242;};
	{long i; for (i = 797; i < 801; i++) Y4456[i] = 242;};
	{long i; for (i = 805; i < 807; i++) Y4456[i] = 242;};
	Y4456[1253] = 242;
	{long i; for (i = 1255; i < 1257; i++) Y4456[i] = 242;};
}


#ifdef __cplusplus
}
#endif
