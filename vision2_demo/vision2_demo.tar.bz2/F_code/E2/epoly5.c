#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O2823[1422];
void O2823_init () {
	O2823[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 1415; i < 1417; i++) O2823[i] = + _LNGOFF_0_0_0_0_;}
	O2823[1419] = + _LNGOFF_0_0_0_0_;
	O2823[1420] = + _LNGOFF_5_1_0_0_;
	O2823[1421] = + _LNGOFF_2_0_0_0_;
}

EIF_TYPE_INDEX *Y2855_gen_type [1419];
EIF_TYPE_INDEX Y2855 [1419];
void Y2855_init (void)
{
	egc_routines_types [2855] = Y2855;
	egc_routines_gen_types [2855] = Y2855_gen_type;
	egc_routines_offset [2855] = 141;
	Y2855[0] = 138;
	Y2855[1418] = 1554;
}

EIF_TYPE_INDEX *Y2856_gen_type [1419];
EIF_TYPE_INDEX Y2856 [1419];
void Y2856_init (void)
{
	egc_routines_types [2856] = Y2856;
	egc_routines_gen_types [2856] = Y2856_gen_type;
	egc_routines_offset [2856] = 141;
	Y2856[0] = 653;
	Y2856[1418] = 1556;
}

long O2982[1295];
void O2982_init () {
	O2982[0] = 0;
	O2982[1259] =  + _REFACS_6_;
	O2982[1260] =  + _REFACS_8_;
	O2982[1293] =  + _REFACS_6_;
	O2982[1294] =  + _REFACS_8_;
}

long O2984[1295];
void O2984_init () {
	O2984[0] =  + _REFACS_1_;
	O2984[1259] =  + _REFACS_7_;
	O2984[1260] =  + _REFACS_9_;
	O2984[1293] =  + _REFACS_7_;
	O2984[1294] =  + _REFACS_9_;
}

long O2995[1359];
void O2995_init () {
	O2995[0] = 0;
	{long i; for (i = 1168; i < 1170; i++) O2995[i] =  + _REFACS_2_;}
	{long i; for (i = 1207; i < 1209; i++) O2995[i] =  + _REFACS_4_;}
	{long i; for (i = 1209; i < 1211; i++) O2995[i] =  + _REFACS_6_;}
	{long i; for (i = 1211; i < 1218; i++) O2995[i] =  + _REFACS_7_;}
	{long i; for (i = 1218; i < 1222; i++) O2995[i] =  + _REFACS_8_;}
	{long i; for (i = 1222; i < 1229; i++) O2995[i] =  + _REFACS_7_;}
	{long i; for (i = 1229; i < 1238; i++) O2995[i] =  + _REFACS_8_;}
	{long i; for (i = 1238; i < 1240; i++) O2995[i] =  + _REFACS_12_;}
	{long i; for (i = 1240; i < 1242; i++) O2995[i] =  + _REFACS_15_;}
	{long i; for (i = 1242; i < 1247; i++) O2995[i] =  + _REFACS_8_;}
	{long i; for (i = 1247; i < 1249; i++) O2995[i] =  + _REFACS_12_;}
	{long i; for (i = 1249; i < 1251; i++) O2995[i] =  + _REFACS_15_;}
	O2995[1251] =  + _REFACS_6_;
	O2995[1252] =  + _REFACS_11_;
	O2995[1253] =  + _REFACS_7_;
	O2995[1254] =  + _REFACS_10_;
	O2995[1255] =  + _REFACS_6_;
	O2995[1256] =  + _REFACS_8_;
	O2995[1257] =  + _REFACS_10_;
	{long i; for (i = 1258; i < 1261; i++) O2995[i] =  + _REFACS_6_;}
	{long i; for (i = 1261; i < 1263; i++) O2995[i] =  + _REFACS_7_;}
	O2995[1263] =  + _REFACS_10_;
	{long i; for (i = 1264; i < 1266; i++) O2995[i] =  + _REFACS_8_;}
	{long i; for (i = 1266; i < 1270; i++) O2995[i] =  + _REFACS_7_;}
	O2995[1270] =  + _REFACS_8_;
	O2995[1271] =  + _REFACS_12_;
	O2995[1272] =  + _REFACS_8_;
	O2995[1273] =  + _REFACS_10_;
	O2995[1274] =  + _REFACS_7_;
	O2995[1275] =  + _REFACS_9_;
	{long i; for (i = 1276; i < 1285; i++) O2995[i] =  + _REFACS_7_;}
	O2995[1285] =  + _REFACS_6_;
	O2995[1286] =  + _REFACS_11_;
	O2995[1287] =  + _REFACS_7_;
	O2995[1288] =  + _REFACS_10_;
	O2995[1289] =  + _REFACS_6_;
	O2995[1290] =  + _REFACS_8_;
	O2995[1291] =  + _REFACS_10_;
	{long i; for (i = 1292; i < 1295; i++) O2995[i] =  + _REFACS_6_;}
	{long i; for (i = 1295; i < 1297; i++) O2995[i] =  + _REFACS_7_;}
	O2995[1297] =  + _REFACS_10_;
	{long i; for (i = 1298; i < 1301; i++) O2995[i] =  + _REFACS_8_;}
	O2995[1301] =  + _REFACS_12_;
	O2995[1302] =  + _REFACS_8_;
	O2995[1303] =  + _REFACS_10_;
	{long i; for (i = 1304; i < 1309; i++) O2995[i] =  + _REFACS_7_;}
	O2995[1309] =  + _REFACS_9_;
	{long i; for (i = 1310; i < 1323; i++) O2995[i] =  + _REFACS_7_;}
	{long i; for (i = 1323; i < 1325; i++) O2995[i] =  + _REFACS_9_;}
	{long i; for (i = 1325; i < 1329; i++) O2995[i] =  + _REFACS_11_;}
	{long i; for (i = 1329; i < 1331; i++) O2995[i] =  + _REFACS_7_;}
	{long i; for (i = 1331; i < 1334; i++) O2995[i] =  + _REFACS_8_;}
	O2995[1334] =  + _REFACS_9_;
	{long i; for (i = 1335; i < 1339; i++) O2995[i] =  + _REFACS_8_;}
	O2995[1339] =  + _REFACS_9_;
	O2995[1340] =  + _REFACS_8_;
	{long i; for (i = 1341; i < 1343; i++) O2995[i] =  + _REFACS_9_;}
	{long i; for (i = 1343; i < 1349; i++) O2995[i] =  + _REFACS_11_;}
	O2995[1350] =  + _REFACS_7_;
	O2995[1353] =  + _REFACS_7_;
	O2995[1355] =  + _REFACS_7_;
	O2995[1358] =  + _REFACS_7_;
}

long O2996[1359];
void O2996_init () {
	O2996[0] =  + _REFACS_1_;
	{long i; for (i = 1168; i < 1170; i++) O2996[i] =  + _REFACS_3_;}
	{long i; for (i = 1207; i < 1209; i++) O2996[i] =  + _REFACS_5_;}
	{long i; for (i = 1209; i < 1211; i++) O2996[i] =  + _REFACS_7_;}
	{long i; for (i = 1211; i < 1218; i++) O2996[i] =  + _REFACS_8_;}
	{long i; for (i = 1218; i < 1222; i++) O2996[i] =  + _REFACS_9_;}
	{long i; for (i = 1222; i < 1229; i++) O2996[i] =  + _REFACS_8_;}
	{long i; for (i = 1229; i < 1238; i++) O2996[i] =  + _REFACS_9_;}
	{long i; for (i = 1238; i < 1240; i++) O2996[i] =  + _REFACS_13_;}
	{long i; for (i = 1240; i < 1242; i++) O2996[i] =  + _REFACS_16_;}
	{long i; for (i = 1242; i < 1247; i++) O2996[i] =  + _REFACS_9_;}
	{long i; for (i = 1247; i < 1249; i++) O2996[i] =  + _REFACS_13_;}
	{long i; for (i = 1249; i < 1251; i++) O2996[i] =  + _REFACS_16_;}
	O2996[1251] =  + _REFACS_7_;
	O2996[1252] =  + _REFACS_12_;
	O2996[1253] =  + _REFACS_8_;
	O2996[1254] =  + _REFACS_11_;
	O2996[1255] =  + _REFACS_7_;
	O2996[1256] =  + _REFACS_9_;
	O2996[1257] =  + _REFACS_11_;
	{long i; for (i = 1258; i < 1261; i++) O2996[i] =  + _REFACS_7_;}
	{long i; for (i = 1261; i < 1263; i++) O2996[i] =  + _REFACS_8_;}
	O2996[1263] =  + _REFACS_11_;
	{long i; for (i = 1264; i < 1266; i++) O2996[i] =  + _REFACS_9_;}
	{long i; for (i = 1266; i < 1270; i++) O2996[i] =  + _REFACS_8_;}
	O2996[1270] =  + _REFACS_9_;
	O2996[1271] =  + _REFACS_13_;
	O2996[1272] =  + _REFACS_9_;
	O2996[1273] =  + _REFACS_11_;
	O2996[1274] =  + _REFACS_8_;
	O2996[1275] =  + _REFACS_10_;
	{long i; for (i = 1276; i < 1285; i++) O2996[i] =  + _REFACS_8_;}
	O2996[1285] =  + _REFACS_7_;
	O2996[1286] =  + _REFACS_12_;
	O2996[1287] =  + _REFACS_8_;
	O2996[1288] =  + _REFACS_11_;
	O2996[1289] =  + _REFACS_7_;
	O2996[1290] =  + _REFACS_9_;
	O2996[1291] =  + _REFACS_11_;
	{long i; for (i = 1292; i < 1295; i++) O2996[i] =  + _REFACS_7_;}
	{long i; for (i = 1295; i < 1297; i++) O2996[i] =  + _REFACS_8_;}
	O2996[1297] =  + _REFACS_11_;
	{long i; for (i = 1298; i < 1301; i++) O2996[i] =  + _REFACS_9_;}
	O2996[1301] =  + _REFACS_13_;
	O2996[1302] =  + _REFACS_9_;
	O2996[1303] =  + _REFACS_11_;
	{long i; for (i = 1304; i < 1309; i++) O2996[i] =  + _REFACS_8_;}
	O2996[1309] =  + _REFACS_10_;
	{long i; for (i = 1310; i < 1323; i++) O2996[i] =  + _REFACS_8_;}
	{long i; for (i = 1323; i < 1325; i++) O2996[i] =  + _REFACS_10_;}
	{long i; for (i = 1325; i < 1329; i++) O2996[i] =  + _REFACS_12_;}
	{long i; for (i = 1329; i < 1331; i++) O2996[i] =  + _REFACS_8_;}
	{long i; for (i = 1331; i < 1334; i++) O2996[i] =  + _REFACS_9_;}
	O2996[1334] =  + _REFACS_10_;
	{long i; for (i = 1335; i < 1339; i++) O2996[i] =  + _REFACS_9_;}
	O2996[1339] =  + _REFACS_10_;
	O2996[1340] =  + _REFACS_9_;
	{long i; for (i = 1341; i < 1343; i++) O2996[i] =  + _REFACS_10_;}
	{long i; for (i = 1343; i < 1349; i++) O2996[i] =  + _REFACS_12_;}
	O2996[1350] =  + _REFACS_8_;
	O2996[1353] =  + _REFACS_8_;
	O2996[1355] =  + _REFACS_8_;
	O2996[1358] =  + _REFACS_8_;
}

long O2997[1359];
void O2997_init () {
	O2997[0] = + _I16OFF_3_1_0_;
	O2997[1168] = + _I16OFF_7_5_0_;
	O2997[1169] = + _I16OFF_8_6_0_;
	O2997[1207] = + _I16OFF_13_5_0_;
	O2997[1208] = + _I16OFF_16_7_0_;
	O2997[1209] = + _I16OFF_35_9_0_;
	O2997[1210] = + _I16OFF_42_12_0_;
	O2997[1211] = + _I16OFF_37_9_0_;
	O2997[1212] = + _I16OFF_39_9_0_;
	{long i; for (i = 1213; i < 1216; i++) O2997[i] = + _I16OFF_39_12_0_;}
	{long i; for (i = 1216; i < 1218; i++) O2997[i] = + _I16OFF_37_9_0_;}
	O2997[1218] = + _I16OFF_38_9_0_;
	{long i; for (i = 1219; i < 1222; i++) O2997[i] = + _I16OFF_39_10_0_;}
	O2997[1222] = + _I16OFF_46_12_0_;
	O2997[1223] = + _I16OFF_48_13_0_;
	{long i; for (i = 1224; i < 1227; i++) O2997[i] = + _I16OFF_48_15_0_;}
	{long i; for (i = 1227; i < 1229; i++) O2997[i] = + _I16OFF_47_12_0_;}
	O2997[1229] = + _I16OFF_49_12_0_;
	{long i; for (i = 1230; i < 1233; i++) O2997[i] = + _I16OFF_49_13_0_;}
	O2997[1233] = + _I16OFF_39_10_0_;
	O2997[1234] = + _I16OFF_103_52_0_;
	{long i; for (i = 1235; i < 1238; i++) O2997[i] = + _I16OFF_39_10_0_;}
	O2997[1238] = + _I16OFF_47_12_0_;
	O2997[1239] = + _I16OFF_47_14_0_;
	O2997[1240] = + _I16OFF_50_13_0_;
	O2997[1241] = + _I16OFF_53_13_0_;
	O2997[1242] = + _I16OFF_49_13_0_;
	O2997[1243] = + _I16OFF_113_55_0_;
	O2997[1244] = + _I16OFF_51_13_0_;
	{long i; for (i = 1245; i < 1247; i++) O2997[i] = + _I16OFF_49_14_0_;}
	O2997[1247] = + _I16OFF_59_21_0_;
	O2997[1248] = + _I16OFF_59_23_0_;
	O2997[1249] = + _I16OFF_65_25_0_;
	O2997[1250] = + _I16OFF_68_26_0_;
	O2997[1251] = + _I16OFF_35_9_0_;
	O2997[1252] = + _I16OFF_40_9_0_;
	O2997[1253] = + _I16OFF_37_10_0_;
	O2997[1254] = + _I16OFF_43_9_0_;
	O2997[1255] = + _I16OFF_35_9_0_;
	O2997[1256] = + _I16OFF_37_9_0_;
	O2997[1257] = + _I16OFF_39_9_0_;
	{long i; for (i = 1258; i < 1261; i++) O2997[i] = + _I16OFF_35_9_0_;}
	{long i; for (i = 1261; i < 1263; i++) O2997[i] = + _I16OFF_36_9_0_;}
	O2997[1263] = + _I16OFF_40_12_0_;
	{long i; for (i = 1264; i < 1266; i++) O2997[i] = + _I16OFF_37_9_0_;}
	{long i; for (i = 1266; i < 1270; i++) O2997[i] = + _I16OFF_36_9_0_;}
	O2997[1270] = + _I16OFF_37_9_0_;
	O2997[1271] = + _I16OFF_41_9_0_;
	O2997[1272] = + _I16OFF_37_10_0_;
	O2997[1273] = + _I16OFF_39_10_0_;
	O2997[1274] = + _I16OFF_37_9_0_;
	O2997[1275] = + _I16OFF_39_9_0_;
	{long i; for (i = 1276; i < 1285; i++) O2997[i] = + _I16OFF_37_9_0_;}
	O2997[1285] = + _I16OFF_42_13_0_;
	O2997[1286] = + _I16OFF_51_15_0_;
	O2997[1287] = + _I16OFF_45_16_0_;
	O2997[1288] = + _I16OFF_58_14_0_;
	O2997[1289] = + _I16OFF_44_13_0_;
	O2997[1290] = + _I16OFF_51_13_0_;
	O2997[1291] = + _I16OFF_53_13_0_;
	{long i; for (i = 1292; i < 1295; i++) O2997[i] = + _I16OFF_42_13_0_;}
	O2997[1295] = + _I16OFF_43_13_0_;
	O2997[1296] = + _I16OFF_44_15_0_;
	O2997[1297] = + _I16OFF_51_18_0_;
	{long i; for (i = 1298; i < 1300; i++) O2997[i] = + _I16OFF_46_14_0_;}
	O2997[1300] = + _I16OFF_50_13_0_;
	O2997[1301] = + _I16OFF_59_16_0_;
	O2997[1302] = + _I16OFF_51_14_0_;
	O2997[1303] = + _I16OFF_53_14_0_;
	{long i; for (i = 1304; i < 1308; i++) O2997[i] = + _I16OFF_46_14_0_;}
	O2997[1308] = + _I16OFF_44_13_0_;
	O2997[1309] = + _I16OFF_48_14_0_;
	{long i; for (i = 1310; i < 1313; i++) O2997[i] = + _I16OFF_44_13_0_;}
	{long i; for (i = 1313; i < 1316; i++) O2997[i] = + _I16OFF_44_14_0_;}
	{long i; for (i = 1316; i < 1319; i++) O2997[i] = + _I16OFF_44_13_0_;}
	{long i; for (i = 1319; i < 1321; i++) O2997[i] = + _I16OFF_16_5_0_;}
	O2997[1321] = + _I16OFF_22_8_0_;
	O2997[1322] = + _I16OFF_16_5_0_;
	O2997[1323] = + _I16OFF_18_5_0_;
	O2997[1324] = + _I16OFF_23_5_0_;
	O2997[1325] = + _I16OFF_20_5_0_;
	O2997[1326] = + _I16OFF_25_6_0_;
	O2997[1327] = + _I16OFF_20_5_0_;
	O2997[1328] = + _I16OFF_25_6_0_;
	{long i; for (i = 1329; i < 1331; i++) O2997[i] = + _I16OFF_21_7_0_;}
	{long i; for (i = 1331; i < 1334; i++) O2997[i] = + _I16OFF_17_6_0_;}
	O2997[1334] = + _I16OFF_18_6_0_;
	O2997[1335] = + _I16OFF_17_6_0_;
	O2997[1336] = + _I16OFF_23_8_0_;
	{long i; for (i = 1337; i < 1339; i++) O2997[i] = + _I16OFF_23_9_0_;}
	O2997[1339] = + _I16OFF_26_8_0_;
	O2997[1340] = + _I16OFF_24_9_0_;
	O2997[1341] = + _I16OFF_19_5_0_;
	O2997[1342] = + _I16OFF_22_5_0_;
	{long i; for (i = 1343; i < 1346; i++) O2997[i] = + _I16OFF_21_10_0_;}
	{long i; for (i = 1346; i < 1349; i++) O2997[i] = + _I16OFF_29_14_0_;}
	O2997[1350] = + _I16OFF_36_10_0_;
	O2997[1353] = + _I16OFF_36_9_0_;
	O2997[1355] = + _I16OFF_48_19_0_;
	O2997[1358] = + _I16OFF_48_18_0_;
}


#ifdef __cplusplus
}
#endif
