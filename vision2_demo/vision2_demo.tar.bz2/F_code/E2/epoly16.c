#include "epoly16.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4752[9])();
void R4752_init () {
	R4752[0] = (char *(*)()) F655_5316;
	R4752[1] = (char *(*)()) F656_5316;
	R4752[2] = (char *(*)()) F657_5316;
	R4752[3] = (char *(*)()) F658_5316;
	R4752[4] = (char *(*)()) F659_5316;
	R4752[5] = (char *(*)()) F660_5316;
	R4752[6] = (char *(*)()) F655_5316;
	R4752[7] = (char *(*)()) F657_5316;
	R4752[8] = (char *(*)()) F655_5316;
}

char *(*R4755[9])();
void R4755_init () {
	R4755[0] = (char *(*)()) F655_5319;
	R4755[1] = (char *(*)()) F656_5319;
	R4755[2] = (char *(*)()) F657_5319;
	R4755[3] = (char *(*)()) F658_5319;
	R4755[4] = (char *(*)()) F659_5319;
	R4755[5] = (char *(*)()) F660_5319;
	R4755[6] = (char *(*)()) F655_5319;
	R4755[7] = (char *(*)()) F657_5319;
	R4755[8] = (char *(*)()) F655_5319;
}

char *(*R4756[9])();
void R4756_init () {
	R4756[0] = (char *(*)()) F655_5320;
	R4756[1] = (char *(*)()) F656_5320;
	R4756[2] = (char *(*)()) F657_5320_4756_1;
	R4756[3] = (char *(*)()) F658_5320_4756_1;
	R4756[4] = (char *(*)()) F659_5320_4756_1;
	R4756[5] = (char *(*)()) F660_5320_4756_1;
	R4756[6] = (char *(*)()) F655_5320;
	R4756[7] = (char *(*)()) F657_5320_4756_1;
	R4756[8] = (char *(*)()) F655_5320;
}
static EIF_REFERENCE F657_5320_4756_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F657_5320(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_5320_4756_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5320(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5320_4756_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F659_5320(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5320_4756_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F660_5320(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R4761[9])();
void R4761_init () {
	R4761[0] = (char *(*)()) F655_5328;
	R4761[1] = (char *(*)()) F656_5328;
	R4761[2] = (char *(*)()) F657_5328_4761_1;
	R4761[3] = (char *(*)()) F658_5328_4761_1;
	R4761[4] = (char *(*)()) F659_5328_4761_1;
	R4761[5] = (char *(*)()) F660_5328_4761_1;
	R4761[6] = (char *(*)()) F655_5328;
	R4761[7] = (char *(*)()) F657_5328_4761_1;
	R4761[8] = (char *(*)()) F655_5328;
}
static EIF_REFERENCE F657_5328_4761_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F657_5328(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_5328_4761_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5328(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5328_4761_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F659_5328(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5328_4761_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F660_5328(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R4762[9])();
void R4762_init () {
	R4762[0] = (char *(*)()) F655_5329;
	R4762[1] = (char *(*)()) F656_5329_4762_1;
	R4762[2] = (char *(*)()) F657_5329;
	R4762[3] = (char *(*)()) F658_5329_4762_1;
	R4762[4] = (char *(*)()) F659_5329_4762_1;
	R4762[5] = (char *(*)()) F660_5329;
	R4762[6] = (char *(*)()) F655_5329;
	R4762[7] = (char *(*)()) F657_5329;
	R4762[8] = (char *(*)()) F655_5329;
}
static EIF_REFERENCE F656_5329_4762_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F656_5329(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_5329_4762_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F658_5329(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5329_4762_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F659_5329(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4764[9])();
void R4764_init () {
	R4764[0] = (char *(*)()) F655_5333;
	R4764[1] = (char *(*)()) F656_5333_4764_70;
	R4764[2] = (char *(*)()) F657_5333;
	R4764[3] = (char *(*)()) F658_5333_4764_70;
	R4764[4] = (char *(*)()) F659_5333_4764_70;
	R4764[5] = (char *(*)()) F660_5333;
	R4764[6] = (char *(*)()) F661_5430;
	R4764[7] = (char *(*)()) F662_5430;
	R4764[8] = (char *(*)()) F655_5333;
}
static EIF_INTEGER_32 F656_5333_4764_70 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F656_5333(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F658_5333_4764_70 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F658_5333(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_INTEGER_32 F659_5333_4764_70 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F659_5333(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4766[9])();
void R4766_init () {
	R4766[0] = (char *(*)()) F655_5340;
	R4766[1] = (char *(*)()) F656_5340_4766_3;
	R4766[2] = (char *(*)()) F657_5340;
	R4766[3] = (char *(*)()) F658_5340_4766_3;
	R4766[4] = (char *(*)()) F659_5340_4766_3;
	R4766[5] = (char *(*)()) F660_5340;
	R4766[6] = (char *(*)()) F661_5432;
	R4766[7] = (char *(*)()) F662_5432;
	R4766[8] = (char *(*)()) F655_5340;
}
static EIF_BOOLEAN F656_5340_4766_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F656_5340(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F658_5340_4766_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F658_5340(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static EIF_BOOLEAN F659_5340_4766_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F659_5340(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R4772[9])();
void R4772_init () {
	R4772[0] = (char *(*)()) F655_5348;
	R4772[1] = (char *(*)()) F656_5348;
	R4772[2] = (char *(*)()) F657_5348;
	R4772[3] = (char *(*)()) F658_5348;
	R4772[4] = (char *(*)()) F659_5348;
	R4772[5] = (char *(*)()) F660_5348;
	R4772[6] = (char *(*)()) F655_5348;
	R4772[7] = (char *(*)()) F657_5348;
	R4772[8] = (char *(*)()) F655_5348;
}

char *(*R4773[9])();
void R4773_init () {
	R4773[0] = (char *(*)()) F655_5349;
	R4773[1] = (char *(*)()) F656_5349;
	R4773[2] = (char *(*)()) F657_5349;
	R4773[3] = (char *(*)()) F658_5349;
	R4773[4] = (char *(*)()) F659_5349;
	R4773[5] = (char *(*)()) F660_5349;
	R4773[6] = (char *(*)()) F655_5349;
	R4773[7] = (char *(*)()) F657_5349;
	R4773[8] = (char *(*)()) F655_5349;
}

char *(*R4774[9])();
void R4774_init () {
	R4774[0] = (char *(*)()) F655_5350;
	R4774[1] = (char *(*)()) F656_5350;
	R4774[2] = (char *(*)()) F657_5350;
	R4774[3] = (char *(*)()) F658_5350;
	R4774[4] = (char *(*)()) F659_5350;
	R4774[5] = (char *(*)()) F660_5350;
	R4774[6] = (char *(*)()) F655_5350;
	R4774[7] = (char *(*)()) F657_5350;
	R4774[8] = (char *(*)()) F655_5350;
}

char *(*R4775[9])();
void R4775_init () {
	R4775[0] = (char *(*)()) F655_5351;
	R4775[1] = (char *(*)()) F656_5351;
	R4775[2] = (char *(*)()) F657_5351;
	R4775[3] = (char *(*)()) F658_5351;
	R4775[4] = (char *(*)()) F659_5351;
	R4775[5] = (char *(*)()) F660_5351;
	R4775[6] = (char *(*)()) F655_5351;
	R4775[7] = (char *(*)()) F657_5351;
	R4775[8] = (char *(*)()) F655_5351;
}

char *(*R4778[9])();
void R4778_init () {
	R4778[0] = (char *(*)()) F655_5355;
	R4778[1] = (char *(*)()) F656_5355;
	R4778[2] = (char *(*)()) F657_5355;
	R4778[3] = (char *(*)()) F658_5355;
	R4778[4] = (char *(*)()) F659_5355;
	R4778[5] = (char *(*)()) F660_5355;
	R4778[6] = (char *(*)()) F655_5355;
	R4778[7] = (char *(*)()) F657_5355;
	R4778[8] = (char *(*)()) F655_5355;
}

char *(*R4779[9])();
void R4779_init () {
	R4779[0] = (char *(*)()) F655_5356;
	R4779[1] = (char *(*)()) F656_5356;
	R4779[2] = (char *(*)()) F657_5356;
	R4779[3] = (char *(*)()) F658_5356;
	R4779[4] = (char *(*)()) F659_5356;
	R4779[5] = (char *(*)()) F660_5356;
	R4779[6] = (char *(*)()) F655_5356;
	R4779[7] = (char *(*)()) F657_5356;
	R4779[8] = (char *(*)()) F655_5356;
}

char *(*R4781[9])();
void R4781_init () {
	R4781[0] = (char *(*)()) F655_5358;
	R4781[1] = (char *(*)()) F656_5358_4781_4;
	R4781[2] = (char *(*)()) F657_5358;
	R4781[3] = (char *(*)()) F658_5358_4781_4;
	R4781[4] = (char *(*)()) F659_5358_4781_4;
	R4781[5] = (char *(*)()) F660_5358;
	R4781[6] = (char *(*)()) F655_5358;
	R4781[7] = (char *(*)()) F657_5358;
	R4781[8] = (char *(*)()) F655_5358;
}
static void F656_5358_4781_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F656_5358(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F658_5358_4781_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5358(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F659_5358_4781_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5358(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4783[9])();
void R4783_init () {
	R4783[0] = (char *(*)()) F655_5360;
	R4783[1] = (char *(*)()) F656_5360;
	R4783[2] = (char *(*)()) F657_5360;
	R4783[3] = (char *(*)()) F658_5360;
	R4783[4] = (char *(*)()) F659_5360;
	R4783[5] = (char *(*)()) F660_5360;
	R4783[6] = (char *(*)()) F655_5360;
	R4783[7] = (char *(*)()) F657_5360;
	R4783[8] = (char *(*)()) F655_5360;
}

char *(*R4784[9])();
void R4784_init () {
	R4784[0] = (char *(*)()) F655_5361;
	R4784[1] = (char *(*)()) F656_5361;
	R4784[2] = (char *(*)()) F657_5361;
	R4784[3] = (char *(*)()) F658_5361;
	R4784[4] = (char *(*)()) F659_5361;
	R4784[5] = (char *(*)()) F660_5361;
	R4784[6] = (char *(*)()) F655_5361;
	R4784[7] = (char *(*)()) F657_5361;
	R4784[8] = (char *(*)()) F655_5361;
}

char *(*R4790[9])();
void R4790_init () {
	R4790[0] = (char *(*)()) F655_5374;
	R4790[1] = (char *(*)()) F656_5374;
	R4790[2] = (char *(*)()) F657_5374;
	R4790[3] = (char *(*)()) F658_5374;
	R4790[4] = (char *(*)()) F659_5374;
	R4790[5] = (char *(*)()) F660_5374;
	R4790[6] = (char *(*)()) F661_5434;
	R4790[7] = (char *(*)()) F662_5434;
	R4790[8] = (char *(*)()) F655_5374;
}

char *(*R4799[9])();
void R4799_init () {
	R4799[0] = (char *(*)()) F655_5384;
	R4799[1] = (char *(*)()) F656_5384;
	R4799[2] = (char *(*)()) F657_5384;
	R4799[3] = (char *(*)()) F658_5384;
	R4799[4] = (char *(*)()) F659_5384;
	R4799[5] = (char *(*)()) F660_5384;
	R4799[6] = (char *(*)()) F655_5384;
	R4799[7] = (char *(*)()) F657_5384;
	R4799[8] = (char *(*)()) F655_5384;
}

char *(*R4800[9])();
void R4800_init () {
	R4800[0] = (char *(*)()) F655_5385;
	R4800[1] = (char *(*)()) F656_5385;
	R4800[2] = (char *(*)()) F657_5385;
	R4800[3] = (char *(*)()) F658_5385;
	R4800[4] = (char *(*)()) F659_5385;
	R4800[5] = (char *(*)()) F660_5385;
	R4800[6] = (char *(*)()) F655_5385;
	R4800[7] = (char *(*)()) F657_5385;
	R4800[8] = (char *(*)()) F655_5385;
}

char *(*R4807[9])();
void R4807_init () {
	R4807[0] = (char *(*)()) F655_5392;
	R4807[1] = (char *(*)()) F656_5392;
	R4807[2] = (char *(*)()) F657_5392_4807_1;
	R4807[3] = (char *(*)()) F658_5392_4807_1;
	R4807[4] = (char *(*)()) F659_5392_4807_1;
	R4807[5] = (char *(*)()) F660_5392_4807_1;
	R4807[6] = (char *(*)()) F655_5392;
	R4807[7] = (char *(*)()) F657_5392_4807_1;
	R4807[8] = (char *(*)()) F655_5392;
}
static EIF_REFERENCE F657_5392_4807_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F657_5392(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_5392_4807_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5392(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5392_4807_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F659_5392(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5392_4807_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F660_5392(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R4808[9])();
void R4808_init () {
	R4808[0] = (char *(*)()) F655_5393;
	R4808[1] = (char *(*)()) F656_5393_4808_1;
	R4808[2] = (char *(*)()) F657_5393;
	R4808[3] = (char *(*)()) F658_5393_4808_1;
	R4808[4] = (char *(*)()) F659_5393_4808_1;
	R4808[5] = (char *(*)()) F660_5393;
	R4808[6] = (char *(*)()) F655_5393;
	R4808[7] = (char *(*)()) F657_5393;
	R4808[8] = (char *(*)()) F655_5393;
}
static EIF_REFERENCE F656_5393_4808_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F656_5393(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_5393_4808_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F658_5393(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5393_4808_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F659_5393(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4809[9])();
void R4809_init () {
	R4809[0] = (char *(*)()) F655_5394;
	R4809[1] = (char *(*)()) F656_5394;
	R4809[2] = (char *(*)()) F657_5394;
	R4809[3] = (char *(*)()) F658_5394;
	R4809[4] = (char *(*)()) F659_5394;
	R4809[5] = (char *(*)()) F660_5394;
	R4809[6] = (char *(*)()) F655_5394;
	R4809[7] = (char *(*)()) F657_5394;
	R4809[8] = (char *(*)()) F655_5394;
}

char *(*R4810[9])();
void R4810_init () {
	R4810[0] = (char *(*)()) F655_5395;
	R4810[1] = (char *(*)()) F656_5395;
	R4810[2] = (char *(*)()) F657_5395;
	R4810[3] = (char *(*)()) F658_5395;
	R4810[4] = (char *(*)()) F659_5395;
	R4810[5] = (char *(*)()) F660_5395;
	R4810[6] = (char *(*)()) F655_5395;
	R4810[7] = (char *(*)()) F657_5395;
	R4810[8] = (char *(*)()) F655_5395;
}

char *(*R4811[9])();
void R4811_init () {
	R4811[0] = (char *(*)()) F655_5396;
	R4811[1] = (char *(*)()) F656_5396;
	R4811[2] = (char *(*)()) F657_5396;
	R4811[3] = (char *(*)()) F658_5396;
	R4811[4] = (char *(*)()) F659_5396;
	R4811[5] = (char *(*)()) F660_5396;
	R4811[6] = (char *(*)()) F655_5396;
	R4811[7] = (char *(*)()) F657_5396;
	R4811[8] = (char *(*)()) F655_5396;
}

char *(*R4812[9])();
void R4812_init () {
	R4812[0] = (char *(*)()) F655_5397;
	R4812[1] = (char *(*)()) F656_5397;
	R4812[2] = (char *(*)()) F657_5397;
	R4812[3] = (char *(*)()) F658_5397;
	R4812[4] = (char *(*)()) F659_5397;
	R4812[5] = (char *(*)()) F660_5397;
	R4812[6] = (char *(*)()) F655_5397;
	R4812[7] = (char *(*)()) F657_5397;
	R4812[8] = (char *(*)()) F655_5397;
}

char *(*R4813[9])();
void R4813_init () {
	R4813[0] = (char *(*)()) F655_5398;
	R4813[1] = (char *(*)()) F656_5398;
	R4813[2] = (char *(*)()) F657_5398;
	R4813[3] = (char *(*)()) F658_5398;
	R4813[4] = (char *(*)()) F659_5398;
	R4813[5] = (char *(*)()) F660_5398;
	R4813[6] = (char *(*)()) F655_5398;
	R4813[7] = (char *(*)()) F657_5398;
	R4813[8] = (char *(*)()) F655_5398;
}

char *(*R4815[9])();
void R4815_init () {
	R4815[0] = (char *(*)()) F655_5400;
	R4815[1] = (char *(*)()) F656_5400;
	R4815[2] = (char *(*)()) F657_5400;
	R4815[3] = (char *(*)()) F658_5400;
	R4815[4] = (char *(*)()) F659_5400;
	R4815[5] = (char *(*)()) F660_5400;
	R4815[6] = (char *(*)()) F655_5400;
	R4815[7] = (char *(*)()) F657_5400;
	R4815[8] = (char *(*)()) F655_5400;
}

char *(*R4816[9])();
void R4816_init () {
	R4816[0] = (char *(*)()) F655_5401;
	R4816[1] = (char *(*)()) F656_5401;
	R4816[2] = (char *(*)()) F657_5401;
	R4816[3] = (char *(*)()) F658_5401;
	R4816[4] = (char *(*)()) F659_5401;
	R4816[5] = (char *(*)()) F660_5401;
	R4816[6] = (char *(*)()) F655_5401;
	R4816[7] = (char *(*)()) F657_5401;
	R4816[8] = (char *(*)()) F655_5401;
}

char *(*R4817[9])();
void R4817_init () {
	R4817[0] = (char *(*)()) F655_5402;
	R4817[1] = (char *(*)()) F656_5402;
	R4817[2] = (char *(*)()) F657_5402;
	R4817[3] = (char *(*)()) F658_5402;
	R4817[4] = (char *(*)()) F659_5402;
	R4817[5] = (char *(*)()) F660_5402;
	R4817[6] = (char *(*)()) F655_5402;
	R4817[7] = (char *(*)()) F657_5402;
	R4817[8] = (char *(*)()) F655_5402;
}

char *(*R4821[9])();
void R4821_init () {
	R4821[0] = (char *(*)()) F655_5406;
	R4821[1] = (char *(*)()) F656_5406_4821_4;
	R4821[2] = (char *(*)()) F657_5406;
	R4821[3] = (char *(*)()) F658_5406_4821_4;
	R4821[4] = (char *(*)()) F659_5406_4821_4;
	R4821[5] = (char *(*)()) F660_5406;
	R4821[6] = (char *(*)()) F655_5406;
	R4821[7] = (char *(*)()) F657_5406;
	R4821[8] = (char *(*)()) F655_5406;
}
static void F656_5406_4821_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F656_5406(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F658_5406_4821_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5406(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F659_5406_4821_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5406(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4822[9])();
void R4822_init () {
	R4822[0] = (char *(*)()) F655_5407;
	R4822[1] = (char *(*)()) F656_5407_4822_4;
	R4822[2] = (char *(*)()) F657_5407;
	R4822[3] = (char *(*)()) F658_5407_4822_4;
	R4822[4] = (char *(*)()) F659_5407_4822_4;
	R4822[5] = (char *(*)()) F660_5407;
	R4822[6] = (char *(*)()) F655_5407;
	R4822[7] = (char *(*)()) F657_5407;
	R4822[8] = (char *(*)()) F655_5407;
}
static void F656_5407_4822_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F656_5407(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F658_5407_4822_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5407(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F659_5407_4822_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5407(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4827[9])();
void R4827_init () {
	R4827[0] = (char *(*)()) F655_5412;
	R4827[1] = (char *(*)()) F656_5412;
	R4827[2] = (char *(*)()) F657_5412;
	R4827[3] = (char *(*)()) F658_5412;
	R4827[4] = (char *(*)()) F659_5412;
	R4827[5] = (char *(*)()) F660_5412;
	R4827[6] = (char *(*)()) F655_5412;
	R4827[7] = (char *(*)()) F657_5412;
	R4827[8] = (char *(*)()) F655_5412;
}

char *(*R4840[9])();
void R4840_init () {
	R4840[0] = (char *(*)()) F655_5425;
	R4840[1] = (char *(*)()) F656_5425;
	R4840[2] = (char *(*)()) F657_5425;
	R4840[3] = (char *(*)()) F658_5425;
	R4840[4] = (char *(*)()) F659_5425;
	R4840[5] = (char *(*)()) F660_5425;
	R4840[6] = (char *(*)()) F655_5425;
	R4840[7] = (char *(*)()) F657_5425;
	R4840[8] = (char *(*)()) F655_5425;
}

char *(*R4843[2])();
void R4843_init () {
	R4843[0] = (char *(*)()) F661_5428;
	R4843[1] = (char *(*)()) F662_5428;
}

char *(*R4856[505])();
void R4856_init () {
	R4856[0] = (char *(*)()) F664_5447;
	R4856[1] = (char *(*)()) F665_5447;
	R4856[2] = (char *(*)()) F666_5447;
	R4856[3] = (char *(*)()) F667_5447;
	R4856[4] = (char *(*)()) F668_5447;
	R4856[5] = (char *(*)()) F669_5447;
	R4856[6] = (char *(*)()) F670_5447;
	R4856[7] = (char *(*)()) F671_5447;
	R4856[8] = (char *(*)()) F672_5447;
	R4856[9] = (char *(*)()) F673_5447;
	R4856[10] = (char *(*)()) F674_5447;
	R4856[11] = (char *(*)()) F675_5447;
	R4856[12] = (char *(*)()) F664_5447;
	R4856[13] = (char *(*)()) F671_5447;
	R4856[14] = (char *(*)()) F669_5447;
	R4856[15] = (char *(*)()) F664_5447;
	R4856[16] = (char *(*)()) F671_5447;
	R4856[19] = (char *(*)()) F664_5447;
	R4856[20] = (char *(*)()) F671_5447;
	R4856[21] = (char *(*)()) F664_5447;
	R4856[22] = (char *(*)()) F671_5447;
	{long i; for (i = 23; i < 25; i++) R4856[i] = (char *(*)()) F664_5447;}
	{long i; for (i = 149; i < 151; i++) R4856[i] = (char *(*)()) F664_5447;}
	{long i; for (i = 152; i < 174; i++) R4856[i] = (char *(*)()) F664_5447;}
	{long i; for (i = 281; i < 284; i++) R4856[i] = (char *(*)()) F945_7847;}
	R4856[504] = (char *(*)()) F664_5447;
}

char *(*R4860[505])();
void R4860_init () {
	R4860[0] = (char *(*)()) F664_5451;
	R4860[1] = (char *(*)()) F665_5451;
	R4860[2] = (char *(*)()) F666_5451;
	R4860[3] = (char *(*)()) F667_5451;
	R4860[4] = (char *(*)()) F668_5451;
	R4860[5] = (char *(*)()) F669_5451;
	R4860[6] = (char *(*)()) F670_5451;
	R4860[7] = (char *(*)()) F671_5451;
	R4860[8] = (char *(*)()) F672_5451;
	R4860[9] = (char *(*)()) F673_5451;
	R4860[10] = (char *(*)()) F674_5451;
	R4860[11] = (char *(*)()) F675_5451;
	R4860[12] = (char *(*)()) F664_5451;
	R4860[13] = (char *(*)()) F671_5451;
	R4860[14] = (char *(*)()) F669_5451;
	R4860[15] = (char *(*)()) F664_5451;
	R4860[16] = (char *(*)()) F671_5451;
	R4860[19] = (char *(*)()) F664_5451;
	R4860[20] = (char *(*)()) F671_5451;
	R4860[21] = (char *(*)()) F664_5451;
	R4860[22] = (char *(*)()) F671_5451;
	{long i; for (i = 23; i < 25; i++) R4860[i] = (char *(*)()) F664_5451;}
	{long i; for (i = 149; i < 151; i++) R4860[i] = (char *(*)()) F664_5451;}
	{long i; for (i = 152; i < 174; i++) R4860[i] = (char *(*)()) F664_5451;}
	{long i; for (i = 281; i < 284; i++) R4860[i] = (char *(*)()) F664_5451;}
	R4860[504] = (char *(*)()) F664_5451;
}

char *(*R4864[505])();
void R4864_init () {
	R4864[0] = (char *(*)()) F664_5470;
	R4864[1] = (char *(*)()) F665_5470;
	R4864[2] = (char *(*)()) F666_5470;
	R4864[3] = (char *(*)()) F667_5470;
	R4864[4] = (char *(*)()) F668_5470;
	R4864[5] = (char *(*)()) F669_5470;
	R4864[6] = (char *(*)()) F670_5470;
	R4864[7] = (char *(*)()) F671_5470;
	R4864[8] = (char *(*)()) F672_5470;
	R4864[9] = (char *(*)()) F673_5470;
	R4864[10] = (char *(*)()) F674_5470;
	R4864[11] = (char *(*)()) F675_5470;
	R4864[12] = (char *(*)()) F664_5470;
	R4864[13] = (char *(*)()) F671_5470;
	R4864[14] = (char *(*)()) F669_5470;
	R4864[15] = (char *(*)()) F664_5470;
	R4864[16] = (char *(*)()) F671_5470;
	R4864[19] = (char *(*)()) F664_5470;
	R4864[20] = (char *(*)()) F671_5470;
	R4864[21] = (char *(*)()) F664_5470;
	R4864[22] = (char *(*)()) F671_5470;
	{long i; for (i = 23; i < 25; i++) R4864[i] = (char *(*)()) F664_5470;}
	{long i; for (i = 149; i < 151; i++) R4864[i] = (char *(*)()) F664_5470;}
	{long i; for (i = 152; i < 174; i++) R4864[i] = (char *(*)()) F664_5470;}
	{long i; for (i = 281; i < 284; i++) R4864[i] = (char *(*)()) F664_5470;}
	R4864[504] = (char *(*)()) F664_5470;
}

char *(*R4868[505])();
void R4868_init () {
	R4868[0] = (char *(*)()) F664_5511;
	R4868[1] = (char *(*)()) F665_5511_4868_243;
	R4868[2] = (char *(*)()) F666_5511_4868_243;
	R4868[3] = (char *(*)()) F667_5511_4868_243;
	R4868[4] = (char *(*)()) F668_5511_4868_243;
	R4868[5] = (char *(*)()) F669_5511_4868_243;
	R4868[6] = (char *(*)()) F670_5511_4868_243;
	R4868[7] = (char *(*)()) F671_5511_4868_243;
	R4868[8] = (char *(*)()) F672_5511_4868_243;
	R4868[9] = (char *(*)()) F673_5511_4868_243;
	R4868[10] = (char *(*)()) F674_5511_4868_243;
	R4868[11] = (char *(*)()) F675_5511_4868_243;
	R4868[12] = (char *(*)()) F664_5511;
	R4868[13] = (char *(*)()) F671_5511_4868_243;
	R4868[14] = (char *(*)()) F669_5511_4868_243;
	R4868[15] = (char *(*)()) F664_5511;
	R4868[16] = (char *(*)()) F671_5511_4868_243;
	R4868[19] = (char *(*)()) F664_5511;
	R4868[20] = (char *(*)()) F671_5511_4868_243;
	R4868[21] = (char *(*)()) F664_5511;
	R4868[22] = (char *(*)()) F671_5511_4868_243;
	{long i; for (i = 23; i < 25; i++) R4868[i] = (char *(*)()) F664_5511;}
	{long i; for (i = 149; i < 151; i++) R4868[i] = (char *(*)()) F664_5511;}
	{long i; for (i = 152; i < 174; i++) R4868[i] = (char *(*)()) F664_5511;}
	{long i; for (i = 281; i < 284; i++) R4868[i] = (char *(*)()) F945_7857;}
	R4868[504] = (char *(*)()) F664_5511;
}
static void F665_5511_4868_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F665_5511(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F666_5511_4868_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F666_5511(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F667_5511_4868_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F667_5511(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F668_5511_4868_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F668_5511(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F669_5511_4868_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F669_5511(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F670_5511_4868_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F670_5511(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F671_5511_4868_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F671_5511(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F672_5511_4868_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F672_5511(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F673_5511_4868_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F673_5511(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F674_5511_4868_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F674_5511(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F675_5511_4868_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F675_5511(Current, *(EIF_REAL_32 *)arg1, arg2);
}

char *(*R4872[3])();
void R4872_init () {
	R4872[0] = (char *(*)()) F664_5488;
	R4872[1] = (char *(*)()) F671_5488_4872_4;
	R4872[2] = (char *(*)()) F669_5488_4872_4;
}
static void F671_5488_4872_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F671_5488(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F669_5488_4872_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F669_5488(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R4873[3])();
void R4873_init () {
	R4873[0] = (char *(*)()) F664_5501;
	R4873[1] = (char *(*)()) F671_5501;
	R4873[2] = (char *(*)()) F669_5501;
}

char *(*R4877[2])();
void R4877_init () {
	R4877[0] = (char *(*)()) F679_5529;
	R4877[1] = (char *(*)()) F680_5529;
}

char *(*R4878[486])();
void R4878_init () {
	R4878[0] = (char *(*)()) F683_5556;
	R4878[1] = (char *(*)()) F684_5556_4878_243;
	R4878[2] = (char *(*)()) F685_5561;
	R4878[3] = (char *(*)()) F686_5561_4878_243;
	R4878[4] = (char *(*)()) F685_5561;
	R4878[5] = (char *(*)()) F688_5570;
	{long i; for (i = 130; i < 132; i++) R4878[i] = (char *(*)()) F688_5570;}
	{long i; for (i = 133; i < 155; i++) R4878[i] = (char *(*)()) F688_5570;}
	R4878[485] = (char *(*)()) F1168_10774;
}
static void F684_5556_4878_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F684_5556(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F686_5561_4878_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F686_5561(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R4879[486])();
void R4879_init () {
	R4879[0] = (char *(*)()) F683_5557;
	R4879[1] = (char *(*)()) F684_5557_4879_243;
	R4879[2] = (char *(*)()) F685_5562;
	R4879[3] = (char *(*)()) F686_5562_4879_243;
	R4879[4] = (char *(*)()) F685_5562;
	R4879[5] = (char *(*)()) F688_5571;
	{long i; for (i = 130; i < 132; i++) R4879[i] = (char *(*)()) F688_5571;}
	{long i; for (i = 133; i < 155; i++) R4879[i] = (char *(*)()) F688_5571;}
	R4879[485] = (char *(*)()) F1168_10775;
}
static void F684_5557_4879_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F684_5557(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F686_5562_4879_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F686_5562(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R4883[486])();
void R4883_init () {
	R4883[0] = (char *(*)()) F681_5550;
	R4883[1] = (char *(*)()) F682_5550_4883_243;
	R4883[2] = (char *(*)()) F681_5550;
	R4883[3] = (char *(*)()) F682_5550_4883_243;
	{long i; for (i = 4; i < 6; i++) R4883[i] = (char *(*)()) F681_5550;}
	{long i; for (i = 130; i < 132; i++) R4883[i] = (char *(*)()) F681_5550;}
	{long i; for (i = 133; i < 155; i++) R4883[i] = (char *(*)()) F681_5550;}
	R4883[485] = (char *(*)()) F681_5550;
}
static void F682_5550_4883_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F682_5550(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R4884[486])();
void R4884_init () {
	R4884[0] = (char *(*)()) F681_5551;
	R4884[1] = (char *(*)()) F682_5551_4884_243;
	R4884[2] = (char *(*)()) F681_5551;
	R4884[3] = (char *(*)()) F682_5551_4884_243;
	{long i; for (i = 4; i < 6; i++) R4884[i] = (char *(*)()) F681_5551;}
	{long i; for (i = 130; i < 132; i++) R4884[i] = (char *(*)()) F681_5551;}
	{long i; for (i = 133; i < 155; i++) R4884[i] = (char *(*)()) F681_5551;}
	R4884[485] = (char *(*)()) F681_5551;
}
static void F682_5551_4884_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F682_5551(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R4892[150])();
void R4892_init () {
	R4892[0] = (char *(*)()) F688_5572;
	R4892[125] = (char *(*)()) F813_6165;
	R4892[126] = (char *(*)()) F814_6166;
	{long i; for (i = 128; i < 150; i++) R4892[i] = (char *(*)()) F813_6165;}
}

static EIF_TYPE_INDEX Y4924_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype2[] = {0xFFF9,1,997,0,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype4[] = {0xFFF9,1,997,1033,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype5[] = {0xFFF9,1,997,1175,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype6[] = {0xFFF9,1,997,1184,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype7[] = {0xFFF9,1,997,1168,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype8[] = {0xFFF9,1,997,1126,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype9[] = {0xFFF9,1,997,1128,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype10[] = {0xFFF9,1,997,1193,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype11[] = {0xFFF9,1,997,1033,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype12[] = {0xFFF9,1,997,1167,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype13[] = {0xFFF9,1,997,942,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype14[] = {0xFFF9,1,997,1163,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype15[] = {0xFFF9,1,997,1189,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype16[] = {0xFFF9,5,997,1006,1033,1033,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype17[] = {0xFFF9,4,997,1033,1033,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype18[] = {0xFFF9,1,997,1082,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype19[] = {0xFFF9,1,997,1033,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype20[] = {0xFFF9,1,997,1518,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype21[] = {0xFFF9,7,997,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype22[] = {0xFFF9,2,997,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype23[] = {0xFFF9,3,997,1033,1033,942,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype24[] = {0xFFF9,0,997,0xFFFF};
static EIF_TYPE_INDEX Y4924_pgtype25[] = {0xFFF9,8,997,1033,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
EIF_TYPE_INDEX *Y4924_gen_type [150];
EIF_TYPE_INDEX Y4924 [150];
void Y4924_init (void)
{
	egc_routines_types [4924] = Y4924;
	egc_routines_gen_types [4924] = Y4924_gen_type;
	egc_routines_offset [4924] = 687;
	Y4924_gen_type [0] = Y4924_pgtype0;
	Y4924_gen_type [125] = Y4924_pgtype1;
	Y4924_gen_type [126] = Y4924_pgtype2;
	Y4924_gen_type [127] = Y4924_pgtype3;
	Y4924_gen_type [128] = Y4924_pgtype4;
	Y4924_gen_type [129] = Y4924_pgtype5;
	Y4924_gen_type [130] = Y4924_pgtype6;
	Y4924_gen_type [131] = Y4924_pgtype7;
	Y4924_gen_type [132] = Y4924_pgtype8;
	Y4924_gen_type [133] = Y4924_pgtype9;
	Y4924_gen_type [134] = Y4924_pgtype10;
	Y4924_gen_type [135] = Y4924_pgtype11;
	Y4924_gen_type [136] = Y4924_pgtype12;
	Y4924_gen_type [137] = Y4924_pgtype13;
	Y4924_gen_type [138] = Y4924_pgtype14;
	Y4924_gen_type [139] = Y4924_pgtype15;
	Y4924_gen_type [140] = Y4924_pgtype16;
	Y4924_gen_type [141] = Y4924_pgtype17;
	Y4924_gen_type [142] = Y4924_pgtype18;
	Y4924_gen_type [143] = Y4924_pgtype19;
	Y4924_gen_type [144] = Y4924_pgtype20;
	Y4924_gen_type [145] = Y4924_pgtype21;
	Y4924_gen_type [146] = Y4924_pgtype22;
	Y4924_gen_type [147] = Y4924_pgtype23;
	Y4924_gen_type [148] = Y4924_pgtype24;
	Y4924_gen_type [149] = Y4924_pgtype25;
	Y4924[126] = 997;
	{long i; for (i = 128; i < 150; i++) Y4924[i] = 997;};
}

char *(*R5250[926])();
void R5250_init () {
	R5250[0] = (char *(*)()) F702_5935;
	R5250[1] = (char *(*)()) F703_5941;
	R5250[2] = (char *(*)()) F704_5948;
	R5250[3] = (char *(*)()) F705_5962;
	R5250[4] = (char *(*)()) F706_5977_5250_1;
	{long i; for (i = 5; i < 7; i++) R5250[i] = (char *(*)()) F482_4799_5250_1;}
	R5250[37] = (char *(*)()) F727_6036;
	R5250[38] = (char *(*)()) F728_6036_5250_1;
	R5250[39] = (char *(*)()) F729_6036_5250_1;
	R5250[40] = (char *(*)()) F730_6036_5250_1;
	R5250[41] = (char *(*)()) F731_6036_5250_1;
	R5250[42] = (char *(*)()) F732_6036_5250_1;
	R5250[43] = (char *(*)()) F733_6036_5250_1;
	R5250[44] = (char *(*)()) F734_6036_5250_1;
	R5250[45] = (char *(*)()) F735_6036_5250_1;
	R5250[46] = (char *(*)()) F736_6036_5250_1;
	R5250[47] = (char *(*)()) F737_6036_5250_1;
	R5250[48] = (char *(*)()) F738_6036_5250_1;
	R5250[49] = (char *(*)()) F751_6064;
	R5250[50] = (char *(*)()) F752_6064_5250_1;
	R5250[51] = (char *(*)()) F753_6064_5250_1;
	R5250[52] = (char *(*)()) F754_6070;
	R5250[53] = (char *(*)()) F755_6070;
	R5250[54] = (char *(*)()) F756_6070_5250_1;
	R5250[55] = (char *(*)()) F757_6070_5250_1;
	R5250[56] = (char *(*)()) F758_6070_5250_1;
	R5250[57] = (char *(*)()) F759_6070_5250_1;
	R5250[70] = (char *(*)()) F760_6076;
	R5250[71] = (char *(*)()) F761_6076_5250_1;
	R5250[72] = (char *(*)()) F762_6076_5250_1;
	R5250[73] = (char *(*)()) F763_6076_5250_1;
	R5250[74] = (char *(*)()) F764_6076_5250_1;
	R5250[75] = (char *(*)()) F765_6076_5250_1;
	R5250[76] = (char *(*)()) F766_6076_5250_1;
	R5250[77] = (char *(*)()) F767_6076_5250_1;
	R5250[78] = (char *(*)()) F768_6076_5250_1;
	R5250[79] = (char *(*)()) F769_6076_5250_1;
	R5250[80] = (char *(*)()) F770_6076_5250_1;
	R5250[81] = (char *(*)()) F771_6076_5250_1;
	R5250[82] = (char *(*)()) F769_6076_5250_1;
	R5250[83] = (char *(*)()) F770_6076_5250_1;
	R5250[84] = (char *(*)()) F760_6076;
	R5250[85] = (char *(*)()) F761_6076_5250_1;
	R5250[86] = (char *(*)()) F762_6076_5250_1;
	R5250[87] = (char *(*)()) F763_6076_5250_1;
	R5250[88] = (char *(*)()) F764_6076_5250_1;
	R5250[89] = (char *(*)()) F765_6076_5250_1;
	R5250[90] = (char *(*)()) F766_6076_5250_1;
	R5250[91] = (char *(*)()) F767_6076_5250_1;
	R5250[92] = (char *(*)()) F768_6076_5250_1;
	R5250[93] = (char *(*)()) F769_6076_5250_1;
	R5250[94] = (char *(*)()) F770_6076_5250_1;
	R5250[95] = (char *(*)()) F771_6076_5250_1;
	R5250[96] = (char *(*)()) F760_6076;
	R5250[97] = (char *(*)()) F761_6076_5250_1;
	R5250[98] = (char *(*)()) F762_6076_5250_1;
	R5250[99] = (char *(*)()) F763_6076_5250_1;
	R5250[100] = (char *(*)()) F764_6076_5250_1;
	R5250[101] = (char *(*)()) F765_6076_5250_1;
	R5250[102] = (char *(*)()) F766_6076_5250_1;
	R5250[103] = (char *(*)()) F767_6076_5250_1;
	R5250[104] = (char *(*)()) F768_6076_5250_1;
	R5250[105] = (char *(*)()) F769_6076_5250_1;
	R5250[106] = (char *(*)()) F770_6076_5250_1;
	R5250[107] = (char *(*)()) F771_6076_5250_1;
	R5250[227] = (char *(*)()) F929_6973_5250_1;
	R5250[925] = (char *(*)()) F482_4799_5250_1;
}
static EIF_REFERENCE F706_5977_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F706_5977(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F482_4799_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F482_4799(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F728_6036_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F728_6036(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F729_6036_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F729_6036(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F730_6036_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F730_6036(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1009, 0x00).id, 1009, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F731_6036_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F731_6036(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1012, 0x00).id, 1012, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F732_6036_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F732_6036(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1003, 0x00).id, 1003, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F733_6036_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F733_6036(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F734_6036_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F734_6036(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F735_6036_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F735_6036(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1018, 0x00).id, 1018, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F736_6036_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F736_6036(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F737_6036_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F737_6036(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F738_6036_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F738_6036(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F752_6064_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F752_6064(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F753_6064_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F753_6064(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F756_6070_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F756_6070(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F757_6070_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F757_6070(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F758_6070_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F758_6070(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F759_6070_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F759_6070(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F761_6076_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F761_6076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F762_6076_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F762_6076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1009, 0x00).id, 1009, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F763_6076_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F763_6076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1012, 0x00).id, 1012, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F764_6076_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F764_6076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1003, 0x00).id, 1003, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F765_6076_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F765_6076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1027, 0x00).id, 1027, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F766_6076_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F766_6076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1018, 0x00).id, 1018, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F767_6076_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F767_6076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F768_6076_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F768_6076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1069, 0x00).id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F769_6076_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F769_6076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1021, 0x00).id, 1021, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F770_6076_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F770_6076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F771_6076_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F771_6076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F929_6973_5250_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F929_6973(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R5251[926])();
void R5251_init () {
	R5251[0] = (char *(*)()) F702_5936;
	R5251[1] = (char *(*)()) F703_5942;
	R5251[2] = (char *(*)()) F704_5949;
	R5251[3] = (char *(*)()) F705_5957;
	R5251[4] = (char *(*)()) F706_5980;
	{long i; for (i = 5; i < 7; i++) R5251[i] = (char *(*)()) F482_4800;}
	R5251[37] = (char *(*)()) F739_6054;
	R5251[38] = (char *(*)()) F740_6054;
	R5251[39] = (char *(*)()) F741_6054;
	R5251[40] = (char *(*)()) F742_6054;
	R5251[41] = (char *(*)()) F743_6054;
	R5251[42] = (char *(*)()) F744_6054;
	R5251[43] = (char *(*)()) F745_6054;
	R5251[44] = (char *(*)()) F746_6054;
	R5251[45] = (char *(*)()) F747_6054;
	R5251[46] = (char *(*)()) F748_6054;
	R5251[47] = (char *(*)()) F749_6054;
	R5251[48] = (char *(*)()) F750_6054;
	R5251[49] = (char *(*)()) F751_6065;
	R5251[50] = (char *(*)()) F752_6065;
	R5251[51] = (char *(*)()) F753_6065;
	R5251[52] = (char *(*)()) F754_6073;
	R5251[53] = (char *(*)()) F755_6073;
	R5251[54] = (char *(*)()) F756_6073;
	R5251[55] = (char *(*)()) F757_6073;
	R5251[56] = (char *(*)()) F758_6073;
	R5251[57] = (char *(*)()) F759_6073;
	R5251[70] = (char *(*)()) F760_6085;
	R5251[71] = (char *(*)()) F761_6085;
	R5251[72] = (char *(*)()) F762_6085;
	R5251[73] = (char *(*)()) F763_6085;
	R5251[74] = (char *(*)()) F764_6085;
	R5251[75] = (char *(*)()) F765_6085;
	R5251[76] = (char *(*)()) F766_6085;
	R5251[77] = (char *(*)()) F767_6085;
	R5251[78] = (char *(*)()) F768_6085;
	R5251[79] = (char *(*)()) F769_6085;
	R5251[80] = (char *(*)()) F770_6085;
	R5251[81] = (char *(*)()) F771_6085;
	R5251[82] = (char *(*)()) F769_6085;
	R5251[83] = (char *(*)()) F770_6085;
	R5251[84] = (char *(*)()) F760_6085;
	R5251[85] = (char *(*)()) F761_6085;
	R5251[86] = (char *(*)()) F762_6085;
	R5251[87] = (char *(*)()) F763_6085;
	R5251[88] = (char *(*)()) F764_6085;
	R5251[89] = (char *(*)()) F765_6085;
	R5251[90] = (char *(*)()) F766_6085;
	R5251[91] = (char *(*)()) F767_6085;
	R5251[92] = (char *(*)()) F768_6085;
	R5251[93] = (char *(*)()) F769_6085;
	R5251[94] = (char *(*)()) F770_6085;
	R5251[95] = (char *(*)()) F771_6085;
	R5251[96] = (char *(*)()) F760_6085;
	R5251[97] = (char *(*)()) F761_6085;
	R5251[98] = (char *(*)()) F762_6085;
	R5251[99] = (char *(*)()) F763_6085;
	R5251[100] = (char *(*)()) F764_6085;
	R5251[101] = (char *(*)()) F765_6085;
	R5251[102] = (char *(*)()) F766_6085;
	R5251[103] = (char *(*)()) F767_6085;
	R5251[104] = (char *(*)()) F768_6085;
	R5251[105] = (char *(*)()) F769_6085;
	R5251[106] = (char *(*)()) F770_6085;
	R5251[107] = (char *(*)()) F771_6085;
	R5251[227] = (char *(*)()) F929_6975;
	R5251[925] = (char *(*)()) F482_4800;
}

char *(*R5252[926])();
void R5252_init () {
	R5252[0] = (char *(*)()) F702_5937;
	R5252[1] = (char *(*)()) F703_5943;
	R5252[2] = (char *(*)()) F704_5950;
	R5252[3] = (char *(*)()) F705_5959;
	R5252[4] = (char *(*)()) F706_5982;
	{long i; for (i = 5; i < 7; i++) R5252[i] = (char *(*)()) F482_4806;}
	R5252[37] = (char *(*)()) F739_6062;
	R5252[38] = (char *(*)()) F740_6062;
	R5252[39] = (char *(*)()) F741_6062;
	R5252[40] = (char *(*)()) F742_6062;
	R5252[41] = (char *(*)()) F743_6062;
	R5252[42] = (char *(*)()) F744_6062;
	R5252[43] = (char *(*)()) F745_6062;
	R5252[44] = (char *(*)()) F746_6062;
	R5252[45] = (char *(*)()) F747_6062;
	R5252[46] = (char *(*)()) F748_6062;
	R5252[47] = (char *(*)()) F749_6062;
	R5252[48] = (char *(*)()) F750_6062;
	R5252[49] = (char *(*)()) F751_6067;
	R5252[50] = (char *(*)()) F752_6067;
	R5252[51] = (char *(*)()) F753_6067;
	R5252[52] = (char *(*)()) F754_6074;
	R5252[53] = (char *(*)()) F755_6074;
	R5252[54] = (char *(*)()) F756_6074;
	R5252[55] = (char *(*)()) F757_6074;
	R5252[56] = (char *(*)()) F758_6074;
	R5252[57] = (char *(*)()) F759_6074;
	R5252[70] = (char *(*)()) F760_6091;
	R5252[71] = (char *(*)()) F761_6091;
	R5252[72] = (char *(*)()) F762_6091;
	R5252[73] = (char *(*)()) F763_6091;
	R5252[74] = (char *(*)()) F764_6091;
	R5252[75] = (char *(*)()) F765_6091;
	R5252[76] = (char *(*)()) F766_6091;
	R5252[77] = (char *(*)()) F767_6091;
	R5252[78] = (char *(*)()) F768_6091;
	R5252[79] = (char *(*)()) F769_6091;
	R5252[80] = (char *(*)()) F770_6091;
	R5252[81] = (char *(*)()) F771_6091;
	R5252[82] = (char *(*)()) F769_6091;
	R5252[83] = (char *(*)()) F770_6091;
	R5252[84] = (char *(*)()) F760_6091;
	R5252[85] = (char *(*)()) F761_6091;
	R5252[86] = (char *(*)()) F762_6091;
	R5252[87] = (char *(*)()) F763_6091;
	R5252[88] = (char *(*)()) F764_6091;
	R5252[89] = (char *(*)()) F765_6091;
	R5252[90] = (char *(*)()) F766_6091;
	R5252[91] = (char *(*)()) F767_6091;
	R5252[92] = (char *(*)()) F768_6091;
	R5252[93] = (char *(*)()) F769_6091;
	R5252[94] = (char *(*)()) F770_6091;
	R5252[95] = (char *(*)()) F771_6091;
	R5252[96] = (char *(*)()) F760_6091;
	R5252[97] = (char *(*)()) F761_6091;
	R5252[98] = (char *(*)()) F762_6091;
	R5252[99] = (char *(*)()) F763_6091;
	R5252[100] = (char *(*)()) F764_6091;
	R5252[101] = (char *(*)()) F765_6091;
	R5252[102] = (char *(*)()) F766_6091;
	R5252[103] = (char *(*)()) F767_6091;
	R5252[104] = (char *(*)()) F768_6091;
	R5252[105] = (char *(*)()) F769_6091;
	R5252[106] = (char *(*)()) F770_6091;
	R5252[107] = (char *(*)()) F771_6091;
	R5252[227] = (char *(*)()) F929_6976;
	R5252[925] = (char *(*)()) F482_4806;
}

char *(*R5310[6])();
void R5310_init () {
	R5310[0] = (char *(*)()) F754_6071;
	R5310[1] = (char *(*)()) F755_6071_5310_1;
	R5310[2] = (char *(*)()) F756_6071;
	R5310[3] = (char *(*)()) F757_6071_5310_1;
	R5310[4] = (char *(*)()) F758_6071_5310_1;
	R5310[5] = (char *(*)()) F759_6071;
}
static EIF_REFERENCE F755_6071_5310_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F755_6071(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F757_6071_5310_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F757_6071(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F758_6071_5310_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F758_6071(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5313[71])();
void R5313_init () {
	R5313[0] = (char *(*)()) F739_6044;
	R5313[1] = (char *(*)()) F740_6044;
	R5313[2] = (char *(*)()) F741_6044;
	R5313[3] = (char *(*)()) F742_6044;
	R5313[4] = (char *(*)()) F743_6044;
	R5313[5] = (char *(*)()) F744_6044;
	R5313[6] = (char *(*)()) F745_6044;
	R5313[7] = (char *(*)()) F746_6044;
	R5313[8] = (char *(*)()) F747_6044;
	R5313[9] = (char *(*)()) F748_6044;
	R5313[10] = (char *(*)()) F749_6044;
	R5313[11] = (char *(*)()) F750_6044;
	R5313[12] = (char *(*)()) F739_6044;
	R5313[13] = (char *(*)()) F745_6044;
	R5313[14] = (char *(*)()) F746_6044;
	{long i; for (i = 15; i < 17; i++) R5313[i] = (char *(*)()) F739_6044;}
	{long i; for (i = 17; i < 20; i++) R5313[i] = (char *(*)()) F745_6044;}
	R5313[20] = (char *(*)()) F748_6044;
	R5313[33] = (char *(*)()) F760_6078;
	R5313[34] = (char *(*)()) F761_6078;
	R5313[35] = (char *(*)()) F762_6078;
	R5313[36] = (char *(*)()) F763_6078;
	R5313[37] = (char *(*)()) F764_6078;
	R5313[38] = (char *(*)()) F765_6078;
	R5313[39] = (char *(*)()) F766_6078;
	R5313[40] = (char *(*)()) F767_6078;
	R5313[41] = (char *(*)()) F768_6078;
	R5313[42] = (char *(*)()) F769_6078;
	R5313[43] = (char *(*)()) F770_6078;
	R5313[44] = (char *(*)()) F771_6078;
	R5313[45] = (char *(*)()) F769_6078;
	R5313[46] = (char *(*)()) F770_6078;
	R5313[47] = (char *(*)()) F760_6078;
	R5313[48] = (char *(*)()) F761_6078;
	R5313[49] = (char *(*)()) F762_6078;
	R5313[50] = (char *(*)()) F763_6078;
	R5313[51] = (char *(*)()) F764_6078;
	R5313[52] = (char *(*)()) F765_6078;
	R5313[53] = (char *(*)()) F766_6078;
	R5313[54] = (char *(*)()) F767_6078;
	R5313[55] = (char *(*)()) F768_6078;
	R5313[56] = (char *(*)()) F769_6078;
	R5313[57] = (char *(*)()) F770_6078;
	R5313[58] = (char *(*)()) F771_6078;
	R5313[59] = (char *(*)()) F760_6078;
	R5313[60] = (char *(*)()) F761_6078;
	R5313[61] = (char *(*)()) F762_6078;
	R5313[62] = (char *(*)()) F763_6078;
	R5313[63] = (char *(*)()) F764_6078;
	R5313[64] = (char *(*)()) F765_6078;
	R5313[65] = (char *(*)()) F766_6078;
	R5313[66] = (char *(*)()) F767_6078;
	R5313[67] = (char *(*)()) F768_6078;
	R5313[68] = (char *(*)()) F769_6078;
	R5313[69] = (char *(*)()) F770_6078;
	R5313[70] = (char *(*)()) F771_6078;
}

char *(*R5314[71])();
void R5314_init () {
	R5314[0] = (char *(*)()) F739_6045;
	R5314[1] = (char *(*)()) F740_6045;
	R5314[2] = (char *(*)()) F741_6045;
	R5314[3] = (char *(*)()) F742_6045;
	R5314[4] = (char *(*)()) F743_6045;
	R5314[5] = (char *(*)()) F744_6045;
	R5314[6] = (char *(*)()) F745_6045;
	R5314[7] = (char *(*)()) F746_6045;
	R5314[8] = (char *(*)()) F747_6045;
	R5314[9] = (char *(*)()) F748_6045;
	R5314[10] = (char *(*)()) F749_6045;
	R5314[11] = (char *(*)()) F750_6045;
	R5314[12] = (char *(*)()) F739_6045;
	R5314[13] = (char *(*)()) F745_6045;
	R5314[14] = (char *(*)()) F746_6045;
	{long i; for (i = 15; i < 17; i++) R5314[i] = (char *(*)()) F739_6045;}
	{long i; for (i = 17; i < 20; i++) R5314[i] = (char *(*)()) F745_6045;}
	R5314[20] = (char *(*)()) F748_6045;
	R5314[33] = (char *(*)()) F772_6097;
	R5314[34] = (char *(*)()) F773_6097;
	R5314[35] = (char *(*)()) F774_6097;
	R5314[36] = (char *(*)()) F775_6097;
	R5314[37] = (char *(*)()) F776_6097;
	R5314[38] = (char *(*)()) F777_6097;
	R5314[39] = (char *(*)()) F778_6097;
	R5314[40] = (char *(*)()) F779_6097;
	R5314[41] = (char *(*)()) F780_6097;
	R5314[42] = (char *(*)()) F781_6097;
	R5314[43] = (char *(*)()) F782_6097;
	R5314[44] = (char *(*)()) F783_6097;
	R5314[45] = (char *(*)()) F784_6103;
	R5314[46] = (char *(*)()) F785_6109;
	R5314[47] = (char *(*)()) F786_6115;
	R5314[48] = (char *(*)()) F787_6115;
	R5314[49] = (char *(*)()) F788_6115;
	R5314[50] = (char *(*)()) F789_6115;
	R5314[51] = (char *(*)()) F790_6115;
	R5314[52] = (char *(*)()) F791_6115;
	R5314[53] = (char *(*)()) F792_6115;
	R5314[54] = (char *(*)()) F793_6115;
	R5314[55] = (char *(*)()) F794_6115;
	R5314[56] = (char *(*)()) F795_6115;
	R5314[57] = (char *(*)()) F796_6115;
	R5314[58] = (char *(*)()) F797_6115;
	R5314[59] = (char *(*)()) F798_6121;
	R5314[60] = (char *(*)()) F799_6121;
	R5314[61] = (char *(*)()) F800_6121;
	R5314[62] = (char *(*)()) F801_6121;
	R5314[63] = (char *(*)()) F802_6121;
	R5314[64] = (char *(*)()) F803_6121;
	R5314[65] = (char *(*)()) F804_6121;
	R5314[66] = (char *(*)()) F805_6121;
	R5314[67] = (char *(*)()) F806_6121;
	R5314[68] = (char *(*)()) F807_6121;
	R5314[69] = (char *(*)()) F808_6121;
	R5314[70] = (char *(*)()) F809_6121;
}

char *(*R5322[21])();
void R5322_init () {
	R5322[0] = (char *(*)()) F739_6056;
	R5322[1] = (char *(*)()) F740_6056;
	R5322[2] = (char *(*)()) F741_6056;
	R5322[3] = (char *(*)()) F742_6056;
	R5322[4] = (char *(*)()) F743_6056;
	R5322[5] = (char *(*)()) F744_6056;
	R5322[6] = (char *(*)()) F745_6056;
	R5322[7] = (char *(*)()) F746_6056;
	R5322[8] = (char *(*)()) F747_6056;
	R5322[9] = (char *(*)()) F748_6056;
	R5322[10] = (char *(*)()) F749_6056;
	R5322[11] = (char *(*)()) F750_6056;
	R5322[12] = (char *(*)()) F739_6056;
	R5322[13] = (char *(*)()) F745_6056;
	R5322[14] = (char *(*)()) F746_6056;
	{long i; for (i = 15; i < 17; i++) R5322[i] = (char *(*)()) F739_6056;}
	{long i; for (i = 17; i < 20; i++) R5322[i] = (char *(*)()) F745_6056;}
	R5322[20] = (char *(*)()) F748_6056;
}

char *(*R5325[71])();
void R5325_init () {
	R5325[0] = (char *(*)()) F739_6061;
	R5325[1] = (char *(*)()) F740_6061;
	R5325[2] = (char *(*)()) F741_6061;
	R5325[3] = (char *(*)()) F742_6061;
	R5325[4] = (char *(*)()) F743_6061;
	R5325[5] = (char *(*)()) F744_6061;
	R5325[6] = (char *(*)()) F745_6061;
	R5325[7] = (char *(*)()) F746_6061;
	R5325[8] = (char *(*)()) F747_6061;
	R5325[9] = (char *(*)()) F748_6061;
	R5325[10] = (char *(*)()) F749_6061;
	R5325[11] = (char *(*)()) F750_6061;
	R5325[12] = (char *(*)()) F751_6066;
	R5325[13] = (char *(*)()) F752_6066;
	R5325[14] = (char *(*)()) F753_6066;
	{long i; for (i = 15; i < 17; i++) R5325[i] = (char *(*)()) F739_6061;}
	{long i; for (i = 17; i < 20; i++) R5325[i] = (char *(*)()) F745_6061;}
	R5325[20] = (char *(*)()) F748_6061;
	R5325[33] = (char *(*)()) F760_6090;
	R5325[34] = (char *(*)()) F761_6090;
	R5325[35] = (char *(*)()) F762_6090;
	R5325[36] = (char *(*)()) F763_6090;
	R5325[37] = (char *(*)()) F764_6090;
	R5325[38] = (char *(*)()) F765_6090;
	R5325[39] = (char *(*)()) F766_6090;
	R5325[40] = (char *(*)()) F767_6090;
	R5325[41] = (char *(*)()) F768_6090;
	R5325[42] = (char *(*)()) F769_6090;
	R5325[43] = (char *(*)()) F770_6090;
	R5325[44] = (char *(*)()) F771_6090;
	R5325[45] = (char *(*)()) F769_6090;
	R5325[46] = (char *(*)()) F770_6090;
	R5325[47] = (char *(*)()) F760_6090;
	R5325[48] = (char *(*)()) F761_6090;
	R5325[49] = (char *(*)()) F762_6090;
	R5325[50] = (char *(*)()) F763_6090;
	R5325[51] = (char *(*)()) F764_6090;
	R5325[52] = (char *(*)()) F765_6090;
	R5325[53] = (char *(*)()) F766_6090;
	R5325[54] = (char *(*)()) F767_6090;
	R5325[55] = (char *(*)()) F768_6090;
	R5325[56] = (char *(*)()) F769_6090;
	R5325[57] = (char *(*)()) F770_6090;
	R5325[58] = (char *(*)()) F771_6090;
	R5325[59] = (char *(*)()) F760_6090;
	R5325[60] = (char *(*)()) F761_6090;
	R5325[61] = (char *(*)()) F762_6090;
	R5325[62] = (char *(*)()) F763_6090;
	R5325[63] = (char *(*)()) F764_6090;
	R5325[64] = (char *(*)()) F765_6090;
	R5325[65] = (char *(*)()) F766_6090;
	R5325[66] = (char *(*)()) F767_6090;
	R5325[67] = (char *(*)()) F768_6090;
	R5325[68] = (char *(*)()) F769_6090;
	R5325[69] = (char *(*)()) F770_6090;
	R5325[70] = (char *(*)()) F771_6090;
}

char *(*R5326[71])();
void R5326_init () {
	R5326[0] = (char *(*)()) F739_6063;
	R5326[1] = (char *(*)()) F740_6063;
	R5326[2] = (char *(*)()) F741_6063;
	R5326[3] = (char *(*)()) F742_6063;
	R5326[4] = (char *(*)()) F743_6063;
	R5326[5] = (char *(*)()) F744_6063;
	R5326[6] = (char *(*)()) F745_6063;
	R5326[7] = (char *(*)()) F746_6063;
	R5326[8] = (char *(*)()) F747_6063;
	R5326[9] = (char *(*)()) F748_6063;
	R5326[10] = (char *(*)()) F749_6063;
	R5326[11] = (char *(*)()) F750_6063;
	R5326[12] = (char *(*)()) F751_6068;
	R5326[13] = (char *(*)()) F752_6068;
	R5326[14] = (char *(*)()) F753_6068;
	R5326[15] = (char *(*)()) F754_6075;
	R5326[16] = (char *(*)()) F755_6075;
	R5326[17] = (char *(*)()) F756_6075;
	R5326[18] = (char *(*)()) F757_6075;
	R5326[19] = (char *(*)()) F758_6075;
	R5326[20] = (char *(*)()) F759_6075;
	R5326[33] = (char *(*)()) F772_6100;
	R5326[34] = (char *(*)()) F773_6100;
	R5326[35] = (char *(*)()) F774_6100;
	R5326[36] = (char *(*)()) F775_6100;
	R5326[37] = (char *(*)()) F776_6100;
	R5326[38] = (char *(*)()) F777_6100;
	R5326[39] = (char *(*)()) F778_6100;
	R5326[40] = (char *(*)()) F779_6100;
	R5326[41] = (char *(*)()) F780_6100;
	R5326[42] = (char *(*)()) F781_6100;
	R5326[43] = (char *(*)()) F782_6100;
	R5326[44] = (char *(*)()) F783_6100;
	R5326[45] = (char *(*)()) F784_6106;
	R5326[46] = (char *(*)()) F785_6112;
	R5326[47] = (char *(*)()) F786_6118;
	R5326[48] = (char *(*)()) F787_6118;
	R5326[49] = (char *(*)()) F788_6118;
	R5326[50] = (char *(*)()) F789_6118;
	R5326[51] = (char *(*)()) F790_6118;
	R5326[52] = (char *(*)()) F791_6118;
	R5326[53] = (char *(*)()) F792_6118;
	R5326[54] = (char *(*)()) F793_6118;
	R5326[55] = (char *(*)()) F794_6118;
	R5326[56] = (char *(*)()) F795_6118;
	R5326[57] = (char *(*)()) F796_6118;
	R5326[58] = (char *(*)()) F797_6118;
	R5326[59] = (char *(*)()) F760_6092;
	R5326[60] = (char *(*)()) F761_6092;
	R5326[61] = (char *(*)()) F762_6092;
	R5326[62] = (char *(*)()) F763_6092;
	R5326[63] = (char *(*)()) F764_6092;
	R5326[64] = (char *(*)()) F765_6092;
	R5326[65] = (char *(*)()) F766_6092;
	R5326[66] = (char *(*)()) F767_6092;
	R5326[67] = (char *(*)()) F768_6092;
	R5326[68] = (char *(*)()) F769_6092;
	R5326[69] = (char *(*)()) F770_6092;
	R5326[70] = (char *(*)()) F771_6092;
}

char *(*R5328[21])();
void R5328_init () {
	R5328[0] = (char *(*)()) F739_6042;
	R5328[1] = (char *(*)()) F740_6042;
	R5328[2] = (char *(*)()) F741_6042;
	R5328[3] = (char *(*)()) F742_6042;
	R5328[4] = (char *(*)()) F743_6042;
	R5328[5] = (char *(*)()) F744_6042;
	R5328[6] = (char *(*)()) F745_6042;
	R5328[7] = (char *(*)()) F746_6042;
	R5328[8] = (char *(*)()) F747_6042;
	R5328[9] = (char *(*)()) F748_6042;
	R5328[10] = (char *(*)()) F749_6042;
	R5328[11] = (char *(*)()) F750_6042;
	R5328[12] = (char *(*)()) F739_6042;
	R5328[13] = (char *(*)()) F745_6042;
	R5328[14] = (char *(*)()) F746_6042;
	{long i; for (i = 15; i < 17; i++) R5328[i] = (char *(*)()) F739_6042;}
	{long i; for (i = 17; i < 20; i++) R5328[i] = (char *(*)()) F745_6042;}
	R5328[20] = (char *(*)()) F748_6042;
}

char *(*R5341[38])();
void R5341_init () {
	R5341[0] = (char *(*)()) F772_6101;
	R5341[1] = (char *(*)()) F773_6101;
	R5341[2] = (char *(*)()) F774_6101;
	R5341[3] = (char *(*)()) F775_6101;
	R5341[4] = (char *(*)()) F776_6101;
	R5341[5] = (char *(*)()) F777_6101;
	R5341[6] = (char *(*)()) F778_6101;
	R5341[7] = (char *(*)()) F779_6101;
	R5341[8] = (char *(*)()) F780_6101;
	R5341[9] = (char *(*)()) F781_6101;
	R5341[10] = (char *(*)()) F782_6101;
	R5341[11] = (char *(*)()) F783_6101;
	R5341[12] = (char *(*)()) F784_6107;
	R5341[13] = (char *(*)()) F785_6113;
	R5341[14] = (char *(*)()) F786_6119;
	R5341[15] = (char *(*)()) F787_6119;
	R5341[16] = (char *(*)()) F788_6119;
	R5341[17] = (char *(*)()) F789_6119;
	R5341[18] = (char *(*)()) F790_6119;
	R5341[19] = (char *(*)()) F791_6119;
	R5341[20] = (char *(*)()) F792_6119;
	R5341[21] = (char *(*)()) F793_6119;
	R5341[22] = (char *(*)()) F794_6119;
	R5341[23] = (char *(*)()) F795_6119;
	R5341[24] = (char *(*)()) F796_6119;
	R5341[25] = (char *(*)()) F797_6119;
	R5341[26] = (char *(*)()) F798_6123;
	R5341[27] = (char *(*)()) F799_6123;
	R5341[28] = (char *(*)()) F800_6123;
	R5341[29] = (char *(*)()) F801_6123;
	R5341[30] = (char *(*)()) F802_6123;
	R5341[31] = (char *(*)()) F803_6123;
	R5341[32] = (char *(*)()) F804_6123;
	R5341[33] = (char *(*)()) F805_6123;
	R5341[34] = (char *(*)()) F806_6123;
	R5341[35] = (char *(*)()) F807_6123;
	R5341[36] = (char *(*)()) F808_6123;
	R5341[37] = (char *(*)()) F809_6123;
}

char *(*R5343[12])();
void R5343_init () {
	R5343[0] = (char *(*)()) F772_6096;
	R5343[1] = (char *(*)()) F773_6096;
	R5343[2] = (char *(*)()) F774_6096;
	R5343[3] = (char *(*)()) F775_6096;
	R5343[4] = (char *(*)()) F776_6096;
	R5343[5] = (char *(*)()) F777_6096;
	R5343[6] = (char *(*)()) F778_6096;
	R5343[7] = (char *(*)()) F779_6096;
	R5343[8] = (char *(*)()) F780_6096;
	R5343[9] = (char *(*)()) F781_6096;
	R5343[10] = (char *(*)()) F782_6096;
	R5343[11] = (char *(*)()) F783_6096;
}

char *(*R5351[12])();
void R5351_init () {
	R5351[0] = (char *(*)()) F786_6114;
	R5351[1] = (char *(*)()) F787_6114;
	R5351[2] = (char *(*)()) F788_6114;
	R5351[3] = (char *(*)()) F789_6114;
	R5351[4] = (char *(*)()) F790_6114;
	R5351[5] = (char *(*)()) F791_6114;
	R5351[6] = (char *(*)()) F792_6114;
	R5351[7] = (char *(*)()) F793_6114;
	R5351[8] = (char *(*)()) F794_6114;
	R5351[9] = (char *(*)()) F795_6114;
	R5351[10] = (char *(*)()) F796_6114;
	R5351[11] = (char *(*)()) F797_6114;
}

char *(*R5951[12])();
void R5951_init () {
	R5951[0] = (char *(*)()) F865_6822;
	R5951[1] = (char *(*)()) F866_6822;
	R5951[2] = (char *(*)()) F867_6822;
	R5951[3] = (char *(*)()) F868_6822;
	R5951[4] = (char *(*)()) F869_6822;
	R5951[5] = (char *(*)()) F870_6822;
	R5951[6] = (char *(*)()) F871_6822;
	R5951[7] = (char *(*)()) F872_6822;
	R5951[8] = (char *(*)()) F873_6822;
	R5951[9] = (char *(*)()) F874_6822;
	R5951[10] = (char *(*)()) F875_6822;
	R5951[11] = (char *(*)()) F876_6822;
}

char *(*R5952[12])();
void R5952_init () {
	R5952[0] = (char *(*)()) F865_6823;
	R5952[1] = (char *(*)()) F866_6823;
	R5952[2] = (char *(*)()) F867_6823;
	R5952[3] = (char *(*)()) F868_6823;
	R5952[4] = (char *(*)()) F869_6823;
	R5952[5] = (char *(*)()) F870_6823;
	R5952[6] = (char *(*)()) F871_6823;
	R5952[7] = (char *(*)()) F872_6823;
	R5952[8] = (char *(*)()) F873_6823;
	R5952[9] = (char *(*)()) F874_6823;
	R5952[10] = (char *(*)()) F875_6823;
	R5952[11] = (char *(*)()) F876_6823;
}

char *(*R5954[12])();
void R5954_init () {
	R5954[0] = (char *(*)()) F865_6809;
	R5954[1] = (char *(*)()) F866_6809;
	R5954[2] = (char *(*)()) F867_6809;
	R5954[3] = (char *(*)()) F868_6809;
	R5954[4] = (char *(*)()) F869_6809;
	R5954[5] = (char *(*)()) F870_6809;
	R5954[6] = (char *(*)()) F871_6809;
	R5954[7] = (char *(*)()) F872_6809;
	R5954[8] = (char *(*)()) F873_6809;
	R5954[9] = (char *(*)()) F874_6809;
	R5954[10] = (char *(*)()) F875_6809;
	R5954[11] = (char *(*)()) F876_6809;
}

char *(*R5955[12])();
void R5955_init () {
	R5955[0] = (char *(*)()) F865_6810;
	R5955[1] = (char *(*)()) F866_6810_5955_243;
	R5955[2] = (char *(*)()) F867_6810_5955_243;
	R5955[3] = (char *(*)()) F868_6810_5955_243;
	R5955[4] = (char *(*)()) F869_6810_5955_243;
	R5955[5] = (char *(*)()) F870_6810_5955_243;
	R5955[6] = (char *(*)()) F871_6810_5955_243;
	R5955[7] = (char *(*)()) F872_6810_5955_243;
	R5955[8] = (char *(*)()) F873_6810_5955_243;
	R5955[9] = (char *(*)()) F874_6810_5955_243;
	R5955[10] = (char *(*)()) F875_6810_5955_243;
	R5955[11] = (char *(*)()) F876_6810_5955_243;
}
static void F866_6810_5955_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F866_6810(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F867_6810_5955_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F867_6810(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F868_6810_5955_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F868_6810(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F869_6810_5955_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F869_6810(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F870_6810_5955_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F870_6810(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F871_6810_5955_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F871_6810(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F872_6810_5955_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F872_6810(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F873_6810_5955_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F873_6810(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F874_6810_5955_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F874_6810(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F875_6810_5955_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F875_6810(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F876_6810_5955_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F876_6810(Current, *(EIF_REAL_32 *)arg1, arg2);
}

char *(*R5964[12])();
void R5964_init () {
	R5964[0] = (char *(*)()) F865_6825;
	R5964[1] = (char *(*)()) F866_6825;
	R5964[2] = (char *(*)()) F867_6825;
	R5964[3] = (char *(*)()) F868_6825;
	R5964[4] = (char *(*)()) F869_6825;
	R5964[5] = (char *(*)()) F870_6825;
	R5964[6] = (char *(*)()) F871_6825;
	R5964[7] = (char *(*)()) F872_6825;
	R5964[8] = (char *(*)()) F873_6825;
	R5964[9] = (char *(*)()) F874_6825;
	R5964[10] = (char *(*)()) F875_6825;
	R5964[11] = (char *(*)()) F876_6825;
}

char *(*R5965[12])();
void R5965_init () {
	R5965[0] = (char *(*)()) F865_6827;
	R5965[1] = (char *(*)()) F866_6827_5965_243;
	R5965[2] = (char *(*)()) F867_6827_5965_243;
	R5965[3] = (char *(*)()) F868_6827_5965_243;
	R5965[4] = (char *(*)()) F869_6827_5965_243;
	R5965[5] = (char *(*)()) F870_6827_5965_243;
	R5965[6] = (char *(*)()) F871_6827_5965_243;
	R5965[7] = (char *(*)()) F872_6827_5965_243;
	R5965[8] = (char *(*)()) F873_6827_5965_243;
	R5965[9] = (char *(*)()) F874_6827_5965_243;
	R5965[10] = (char *(*)()) F875_6827_5965_243;
	R5965[11] = (char *(*)()) F876_6827_5965_243;
}
static void F866_6827_5965_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F866_6827(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F867_6827_5965_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F867_6827(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F868_6827_5965_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F868_6827(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F869_6827_5965_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F869_6827(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F870_6827_5965_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F870_6827(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F871_6827_5965_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F871_6827(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F872_6827_5965_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F872_6827(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F873_6827_5965_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F873_6827(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F874_6827_5965_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F874_6827(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F875_6827_5965_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F875_6827(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F876_6827_5965_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F876_6827(Current, *(EIF_REAL_32 *)arg1, arg2);
}

char *(*R5966[12])();
void R5966_init () {
	R5966[0] = (char *(*)()) F865_6828;
	R5966[1] = (char *(*)()) F866_6828_5966_243;
	R5966[2] = (char *(*)()) F867_6828_5966_243;
	R5966[3] = (char *(*)()) F868_6828_5966_243;
	R5966[4] = (char *(*)()) F869_6828_5966_243;
	R5966[5] = (char *(*)()) F870_6828_5966_243;
	R5966[6] = (char *(*)()) F871_6828_5966_243;
	R5966[7] = (char *(*)()) F872_6828_5966_243;
	R5966[8] = (char *(*)()) F873_6828_5966_243;
	R5966[9] = (char *(*)()) F874_6828_5966_243;
	R5966[10] = (char *(*)()) F875_6828_5966_243;
	R5966[11] = (char *(*)()) F876_6828_5966_243;
}
static void F866_6828_5966_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F866_6828(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F867_6828_5966_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F867_6828(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F868_6828_5966_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F868_6828(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F869_6828_5966_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F869_6828(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F870_6828_5966_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F870_6828(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F871_6828_5966_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F871_6828(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F872_6828_5966_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F872_6828(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F873_6828_5966_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F873_6828(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F874_6828_5966_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F874_6828(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F875_6828_5966_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F875_6828(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F876_6828_5966_243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F876_6828(Current, *(EIF_REAL_32 *)arg1, arg2);
}

char *(*R5967[12])();
void R5967_init () {
	R5967[0] = (char *(*)()) F865_6829;
	R5967[1] = (char *(*)()) F866_6829_5967_4;
	R5967[2] = (char *(*)()) F867_6829_5967_4;
	R5967[3] = (char *(*)()) F868_6829_5967_4;
	R5967[4] = (char *(*)()) F869_6829_5967_4;
	R5967[5] = (char *(*)()) F870_6829_5967_4;
	R5967[6] = (char *(*)()) F871_6829_5967_4;
	R5967[7] = (char *(*)()) F872_6829_5967_4;
	R5967[8] = (char *(*)()) F873_6829_5967_4;
	R5967[9] = (char *(*)()) F874_6829_5967_4;
	R5967[10] = (char *(*)()) F875_6829_5967_4;
	R5967[11] = (char *(*)()) F876_6829_5967_4;
}
static void F866_6829_5967_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F866_6829(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F867_6829_5967_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F867_6829(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F868_6829_5967_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F868_6829(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F869_6829_5967_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F869_6829(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F870_6829_5967_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F870_6829(Current, *(EIF_BOOLEAN *)arg1);
}
static void F871_6829_5967_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F871_6829(Current, *(EIF_REAL_64 *)arg1);
}
static void F872_6829_5967_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F872_6829(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F873_6829_5967_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F873_6829(Current, *(EIF_POINTER *)arg1);
}
static void F874_6829_5967_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F874_6829(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F875_6829_5967_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F875_6829(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F876_6829_5967_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F876_6829(Current, *(EIF_REAL_32 *)arg1);
}

char *(*R5969[12])();
void R5969_init () {
	R5969[0] = (char *(*)()) F865_6831;
	R5969[1] = (char *(*)()) F866_6831_5969_276;
	R5969[2] = (char *(*)()) F867_6831_5969_276;
	R5969[3] = (char *(*)()) F868_6831_5969_276;
	R5969[4] = (char *(*)()) F869_6831_5969_276;
	R5969[5] = (char *(*)()) F870_6831_5969_276;
	R5969[6] = (char *(*)()) F871_6831_5969_276;
	R5969[7] = (char *(*)()) F872_6831_5969_276;
	R5969[8] = (char *(*)()) F873_6831_5969_276;
	R5969[9] = (char *(*)()) F874_6831_5969_276;
	R5969[10] = (char *(*)()) F875_6831_5969_276;
	R5969[11] = (char *(*)()) F876_6831_5969_276;
}
static void F866_6831_5969_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F866_6831(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F867_6831_5969_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F867_6831(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F868_6831_5969_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F868_6831(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F869_6831_5969_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F869_6831(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F870_6831_5969_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F870_6831(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F871_6831_5969_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F871_6831(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}
static void F872_6831_5969_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F872_6831(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F873_6831_5969_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F873_6831(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F874_6831_5969_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F874_6831(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F875_6831_5969_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F875_6831(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F876_6831_5969_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F876_6831(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}

char *(*R5970[12])();
void R5970_init () {
	R5970[0] = (char *(*)()) F865_6832;
	R5970[1] = (char *(*)()) F866_6832;
	R5970[2] = (char *(*)()) F867_6832;
	R5970[3] = (char *(*)()) F868_6832;
	R5970[4] = (char *(*)()) F869_6832;
	R5970[5] = (char *(*)()) F870_6832;
	R5970[6] = (char *(*)()) F871_6832;
	R5970[7] = (char *(*)()) F872_6832;
	R5970[8] = (char *(*)()) F873_6832;
	R5970[9] = (char *(*)()) F874_6832;
	R5970[10] = (char *(*)()) F875_6832;
	R5970[11] = (char *(*)()) F876_6832;
}

char *(*R5972[12])();
void R5972_init () {
	R5972[0] = (char *(*)()) F865_6834;
	R5972[1] = (char *(*)()) F866_6834;
	R5972[2] = (char *(*)()) F867_6834;
	R5972[3] = (char *(*)()) F868_6834;
	R5972[4] = (char *(*)()) F869_6834;
	R5972[5] = (char *(*)()) F870_6834;
	R5972[6] = (char *(*)()) F871_6834;
	R5972[7] = (char *(*)()) F872_6834;
	R5972[8] = (char *(*)()) F873_6834;
	R5972[9] = (char *(*)()) F874_6834;
	R5972[10] = (char *(*)()) F875_6834;
	R5972[11] = (char *(*)()) F876_6834;
}

char *(*R5973[12])();
void R5973_init () {
	R5973[0] = (char *(*)()) F865_6835;
	R5973[1] = (char *(*)()) F866_6835;
	R5973[2] = (char *(*)()) F867_6835;
	R5973[3] = (char *(*)()) F868_6835;
	R5973[4] = (char *(*)()) F869_6835;
	R5973[5] = (char *(*)()) F870_6835;
	R5973[6] = (char *(*)()) F871_6835;
	R5973[7] = (char *(*)()) F872_6835;
	R5973[8] = (char *(*)()) F873_6835;
	R5973[9] = (char *(*)()) F874_6835;
	R5973[10] = (char *(*)()) F875_6835;
	R5973[11] = (char *(*)()) F876_6835;
}

char *(*R5974[12])();
void R5974_init () {
	R5974[0] = (char *(*)()) F865_6836;
	R5974[1] = (char *(*)()) F866_6836;
	R5974[2] = (char *(*)()) F867_6836;
	R5974[3] = (char *(*)()) F868_6836;
	R5974[4] = (char *(*)()) F869_6836;
	R5974[5] = (char *(*)()) F870_6836;
	R5974[6] = (char *(*)()) F871_6836;
	R5974[7] = (char *(*)()) F872_6836;
	R5974[8] = (char *(*)()) F873_6836;
	R5974[9] = (char *(*)()) F874_6836;
	R5974[10] = (char *(*)()) F875_6836;
	R5974[11] = (char *(*)()) F876_6836;
}

char *(*R5975[12])();
void R5975_init () {
	R5975[0] = (char *(*)()) F865_6837;
	R5975[1] = (char *(*)()) F866_6837;
	R5975[2] = (char *(*)()) F867_6837;
	R5975[3] = (char *(*)()) F868_6837;
	R5975[4] = (char *(*)()) F869_6837;
	R5975[5] = (char *(*)()) F870_6837;
	R5975[6] = (char *(*)()) F871_6837;
	R5975[7] = (char *(*)()) F872_6837;
	R5975[8] = (char *(*)()) F873_6837;
	R5975[9] = (char *(*)()) F874_6837;
	R5975[10] = (char *(*)()) F875_6837;
	R5975[11] = (char *(*)()) F876_6837;
}

char *(*R5976[12])();
void R5976_init () {
	R5976[0] = (char *(*)()) F865_6838;
	R5976[1] = (char *(*)()) F866_6838;
	R5976[2] = (char *(*)()) F867_6838;
	R5976[3] = (char *(*)()) F868_6838;
	R5976[4] = (char *(*)()) F869_6838;
	R5976[5] = (char *(*)()) F870_6838;
	R5976[6] = (char *(*)()) F871_6838;
	R5976[7] = (char *(*)()) F872_6838;
	R5976[8] = (char *(*)()) F873_6838;
	R5976[9] = (char *(*)()) F874_6838;
	R5976[10] = (char *(*)()) F875_6838;
	R5976[11] = (char *(*)()) F876_6838;
}

char *(*R5979[12])();
void R5979_init () {
	R5979[0] = (char *(*)()) F865_6841;
	R5979[1] = (char *(*)()) F866_6841;
	R5979[2] = (char *(*)()) F867_6841;
	R5979[3] = (char *(*)()) F868_6841;
	R5979[4] = (char *(*)()) F869_6841;
	R5979[5] = (char *(*)()) F870_6841;
	R5979[6] = (char *(*)()) F871_6841;
	R5979[7] = (char *(*)()) F872_6841;
	R5979[8] = (char *(*)()) F873_6841;
	R5979[9] = (char *(*)()) F874_6841;
	R5979[10] = (char *(*)()) F875_6841;
	R5979[11] = (char *(*)()) F876_6841;
}

char *(*R5982[12])();
void R5982_init () {
	R5982[0] = (char *(*)()) F865_6844;
	R5982[1] = (char *(*)()) F866_6844;
	R5982[2] = (char *(*)()) F867_6844;
	R5982[3] = (char *(*)()) F868_6844;
	R5982[4] = (char *(*)()) F869_6844;
	R5982[5] = (char *(*)()) F870_6844;
	R5982[6] = (char *(*)()) F871_6844;
	R5982[7] = (char *(*)()) F872_6844;
	R5982[8] = (char *(*)()) F873_6844;
	R5982[9] = (char *(*)()) F874_6844;
	R5982[10] = (char *(*)()) F875_6844;
	R5982[11] = (char *(*)()) F876_6844;
}

char *(*R5983[12])();
void R5983_init () {
	R5983[0] = (char *(*)()) F865_6845;
	R5983[1] = (char *(*)()) F866_6845_5983_238;
	R5983[2] = (char *(*)()) F867_6845_5983_238;
	R5983[3] = (char *(*)()) F868_6845_5983_238;
	R5983[4] = (char *(*)()) F869_6845_5983_238;
	R5983[5] = (char *(*)()) F870_6845_5983_238;
	R5983[6] = (char *(*)()) F871_6845_5983_238;
	R5983[7] = (char *(*)()) F872_6845_5983_238;
	R5983[8] = (char *(*)()) F873_6845_5983_238;
	R5983[9] = (char *(*)()) F874_6845_5983_238;
	R5983[10] = (char *(*)()) F875_6845_5983_238;
	R5983[11] = (char *(*)()) F876_6845_5983_238;
}
static EIF_REFERENCE F866_6845_5983_238 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F866_6845(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F867_6845_5983_238 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F867_6845(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F868_6845_5983_238 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F868_6845(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F869_6845_5983_238 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F869_6845(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F870_6845_5983_238 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F870_6845(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F871_6845_5983_238 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F871_6845(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F872_6845_5983_238 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F872_6845(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F873_6845_5983_238 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F873_6845(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F874_6845_5983_238 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F874_6845(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F875_6845_5983_238 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F875_6845(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F876_6845_5983_238 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F876_6845(Current, *(EIF_REAL_32 *)arg1, arg2);
}

char *(*R5985[12])();
void R5985_init () {
	R5985[0] = (char *(*)()) F865_6847;
	R5985[1] = (char *(*)()) F866_6847;
	R5985[2] = (char *(*)()) F867_6847;
	R5985[3] = (char *(*)()) F868_6847;
	R5985[4] = (char *(*)()) F869_6847;
	R5985[5] = (char *(*)()) F870_6847;
	R5985[6] = (char *(*)()) F871_6847;
	R5985[7] = (char *(*)()) F872_6847;
	R5985[8] = (char *(*)()) F873_6847;
	R5985[9] = (char *(*)()) F874_6847;
	R5985[10] = (char *(*)()) F875_6847;
	R5985[11] = (char *(*)()) F876_6847;
}

char *(*R5987[12])();
void R5987_init () {
	R5987[0] = (char *(*)()) F865_6849;
	R5987[1] = (char *(*)()) F866_6849;
	R5987[2] = (char *(*)()) F867_6849;
	R5987[3] = (char *(*)()) F868_6849;
	R5987[4] = (char *(*)()) F869_6849;
	R5987[5] = (char *(*)()) F870_6849;
	R5987[6] = (char *(*)()) F871_6849;
	R5987[7] = (char *(*)()) F872_6849;
	R5987[8] = (char *(*)()) F873_6849;
	R5987[9] = (char *(*)()) F874_6849;
	R5987[10] = (char *(*)()) F875_6849;
	R5987[11] = (char *(*)()) F876_6849;
}

char *(*R5994[12])();
void R5994_init () {
	R5994[0] = (char *(*)()) F865_6857;
	R5994[1] = (char *(*)()) F866_6857;
	R5994[2] = (char *(*)()) F867_6857;
	R5994[3] = (char *(*)()) F868_6857;
	R5994[4] = (char *(*)()) F869_6857;
	R5994[5] = (char *(*)()) F870_6857;
	R5994[6] = (char *(*)()) F871_6857;
	R5994[7] = (char *(*)()) F872_6857;
	R5994[8] = (char *(*)()) F873_6857;
	R5994[9] = (char *(*)()) F874_6857;
	R5994[10] = (char *(*)()) F875_6857;
	R5994[11] = (char *(*)()) F876_6857;
}

char *(*R6041[39])();
void R6041_init () {
	R6041[0] = (char *(*)()) F999_8315;
	R6041[1] = (char *(*)()) F1000_8369_6041_1;
	R6041[2] = (char *(*)()) F1001_8369_6041_1;
	R6041[15] = (char *(*)()) F1014_8808;
	R6041[16] = (char *(*)()) F1015_8826_6041_1;
	R6041[17] = (char *(*)()) F1016_8826_6041_1;
	R6041[18] = (char *(*)()) F1017_8874;
	R6041[19] = (char *(*)()) F1018_8892_6041_1;
	R6041[20] = (char *(*)()) F1019_8892_6041_1;
	R6041[30] = (char *(*)()) F1029_9035;
	R6041[31] = (char *(*)()) F1030_9088_6041_1;
	R6041[32] = (char *(*)()) F1031_9088_6041_1;
	R6041[33] = (char *(*)()) F1032_9133;
	R6041[34] = (char *(*)()) F1033_9187_6041_1;
	R6041[35] = (char *(*)()) F1034_9187_6041_1;
	R6041[36] = (char *(*)()) F1035_9232;
	R6041[37] = (char *(*)()) F1036_9286_6041_1;
	R6041[38] = (char *(*)()) F1037_9286_6041_1;
}
static EIF_REFERENCE F1000_8369_6041_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1000_8369(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1001_8369_6041_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1001_8369(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1015_8826_6041_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1015_8826(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1016_8826_6041_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1016_8826(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1018_8892_6041_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1018_8892(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1018, 0x00).id, 1018, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1019_8892_6041_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1019_8892(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1018, 0x00).id, 1018, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1030_9088_6041_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1030_9088(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1030, 0x00).id, 1030, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1031_9088_6041_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1031_9088(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1030, 0x00).id, 1030, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1033_9187_6041_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1033_9187(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1034_9187_6041_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1034_9187(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1036_9286_6041_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1036_9286(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1036, 0x00).id, 1036, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1037_9286_6041_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1037_9286(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1036, 0x00).id, 1036, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}

char *(*R6273[586])();
void R6273_init () {
	{long i; for (i = 0; i < 2; i++) R6273[i] = (char *(*)()) F934_7279;}
	R6273[585] = (char *(*)()) F1520_16504;
}

char *(*R6286[586])();
void R6286_init () {
	{long i; for (i = 0; i < 2; i++) R6286[i] = (char *(*)()) F934_7353;}
	R6286[585] = (char *(*)()) F1520_16527;
}

char *(*R6287[586])();
void R6287_init () {
	{long i; for (i = 0; i < 2; i++) R6287[i] = (char *(*)()) F934_7354;}
	R6287[585] = (char *(*)()) F1520_16528;
}

char *(*R6288[586])();
void R6288_init () {
	{long i; for (i = 0; i < 2; i++) R6288[i] = (char *(*)()) F934_7356;}
	R6288[585] = (char *(*)()) F1520_16525;
}


#ifdef __cplusplus
}
#endif
