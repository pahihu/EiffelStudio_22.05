#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O3060[1355];
void O3060_init () {
	O3060[0] =  + _REFACS_12_;
	{long i; for (i = 1205; i < 1207; i++) O3060[i] =  + _REFACS_21_;}
	{long i; for (i = 1207; i < 1214; i++) O3060[i] =  + _REFACS_22_;}
	{long i; for (i = 1214; i < 1218; i++) O3060[i] =  + _REFACS_23_;}
	{long i; for (i = 1218; i < 1225; i++) O3060[i] =  + _REFACS_22_;}
	{long i; for (i = 1225; i < 1234; i++) O3060[i] =  + _REFACS_23_;}
	{long i; for (i = 1234; i < 1236; i++) O3060[i] =  + _REFACS_27_;}
	{long i; for (i = 1236; i < 1238; i++) O3060[i] =  + _REFACS_30_;}
	{long i; for (i = 1238; i < 1243; i++) O3060[i] =  + _REFACS_23_;}
	{long i; for (i = 1243; i < 1245; i++) O3060[i] =  + _REFACS_27_;}
	{long i; for (i = 1245; i < 1247; i++) O3060[i] =  + _REFACS_30_;}
	O3060[1247] =  + _REFACS_21_;
	O3060[1248] =  + _REFACS_26_;
	O3060[1249] =  + _REFACS_22_;
	O3060[1250] =  + _REFACS_25_;
	O3060[1251] =  + _REFACS_21_;
	O3060[1252] =  + _REFACS_23_;
	O3060[1253] =  + _REFACS_25_;
	{long i; for (i = 1254; i < 1257; i++) O3060[i] =  + _REFACS_21_;}
	{long i; for (i = 1257; i < 1259; i++) O3060[i] =  + _REFACS_22_;}
	O3060[1259] =  + _REFACS_25_;
	{long i; for (i = 1260; i < 1262; i++) O3060[i] =  + _REFACS_23_;}
	{long i; for (i = 1262; i < 1266; i++) O3060[i] =  + _REFACS_22_;}
	O3060[1266] =  + _REFACS_23_;
	O3060[1267] =  + _REFACS_27_;
	O3060[1268] =  + _REFACS_23_;
	O3060[1269] =  + _REFACS_25_;
	O3060[1270] =  + _REFACS_22_;
	O3060[1271] =  + _REFACS_24_;
	{long i; for (i = 1272; i < 1281; i++) O3060[i] =  + _REFACS_22_;}
	O3060[1281] =  + _REFACS_21_;
	O3060[1282] =  + _REFACS_26_;
	O3060[1283] =  + _REFACS_22_;
	O3060[1284] =  + _REFACS_25_;
	O3060[1285] =  + _REFACS_21_;
	O3060[1286] =  + _REFACS_23_;
	O3060[1287] =  + _REFACS_25_;
	{long i; for (i = 1288; i < 1291; i++) O3060[i] =  + _REFACS_21_;}
	{long i; for (i = 1291; i < 1293; i++) O3060[i] =  + _REFACS_22_;}
	O3060[1293] =  + _REFACS_25_;
	{long i; for (i = 1294; i < 1297; i++) O3060[i] =  + _REFACS_23_;}
	O3060[1297] =  + _REFACS_27_;
	O3060[1298] =  + _REFACS_23_;
	O3060[1299] =  + _REFACS_25_;
	{long i; for (i = 1300; i < 1305; i++) O3060[i] =  + _REFACS_22_;}
	O3060[1305] =  + _REFACS_24_;
	{long i; for (i = 1306; i < 1315; i++) O3060[i] =  + _REFACS_22_;}
	O3060[1346] =  + _REFACS_22_;
	O3060[1349] =  + _REFACS_22_;
	O3060[1351] =  + _REFACS_22_;
	O3060[1354] =  + _REFACS_22_;
}

long O3063[1355];
void O3063_init () {
	O3063[0] =  + _REFACS_13_;
	{long i; for (i = 1205; i < 1207; i++) O3063[i] =  + _REFACS_22_;}
	{long i; for (i = 1207; i < 1214; i++) O3063[i] =  + _REFACS_23_;}
	{long i; for (i = 1214; i < 1218; i++) O3063[i] =  + _REFACS_24_;}
	{long i; for (i = 1218; i < 1225; i++) O3063[i] =  + _REFACS_23_;}
	{long i; for (i = 1225; i < 1234; i++) O3063[i] =  + _REFACS_24_;}
	{long i; for (i = 1234; i < 1236; i++) O3063[i] =  + _REFACS_28_;}
	{long i; for (i = 1236; i < 1238; i++) O3063[i] =  + _REFACS_31_;}
	{long i; for (i = 1238; i < 1243; i++) O3063[i] =  + _REFACS_24_;}
	{long i; for (i = 1243; i < 1245; i++) O3063[i] =  + _REFACS_28_;}
	{long i; for (i = 1245; i < 1247; i++) O3063[i] =  + _REFACS_31_;}
	O3063[1247] =  + _REFACS_22_;
	O3063[1248] =  + _REFACS_27_;
	O3063[1249] =  + _REFACS_23_;
	O3063[1250] =  + _REFACS_26_;
	O3063[1251] =  + _REFACS_22_;
	O3063[1252] =  + _REFACS_24_;
	O3063[1253] =  + _REFACS_26_;
	{long i; for (i = 1254; i < 1257; i++) O3063[i] =  + _REFACS_22_;}
	{long i; for (i = 1257; i < 1259; i++) O3063[i] =  + _REFACS_23_;}
	O3063[1259] =  + _REFACS_26_;
	{long i; for (i = 1260; i < 1262; i++) O3063[i] =  + _REFACS_24_;}
	{long i; for (i = 1262; i < 1266; i++) O3063[i] =  + _REFACS_23_;}
	O3063[1266] =  + _REFACS_24_;
	O3063[1267] =  + _REFACS_28_;
	O3063[1268] =  + _REFACS_24_;
	O3063[1269] =  + _REFACS_26_;
	O3063[1270] =  + _REFACS_23_;
	O3063[1271] =  + _REFACS_25_;
	{long i; for (i = 1272; i < 1281; i++) O3063[i] =  + _REFACS_23_;}
	O3063[1281] =  + _REFACS_22_;
	O3063[1282] =  + _REFACS_27_;
	O3063[1283] =  + _REFACS_23_;
	O3063[1284] =  + _REFACS_26_;
	O3063[1285] =  + _REFACS_22_;
	O3063[1286] =  + _REFACS_24_;
	O3063[1287] =  + _REFACS_26_;
	{long i; for (i = 1288; i < 1291; i++) O3063[i] =  + _REFACS_22_;}
	{long i; for (i = 1291; i < 1293; i++) O3063[i] =  + _REFACS_23_;}
	O3063[1293] =  + _REFACS_26_;
	{long i; for (i = 1294; i < 1297; i++) O3063[i] =  + _REFACS_24_;}
	O3063[1297] =  + _REFACS_28_;
	O3063[1298] =  + _REFACS_24_;
	O3063[1299] =  + _REFACS_26_;
	{long i; for (i = 1300; i < 1305; i++) O3063[i] =  + _REFACS_23_;}
	O3063[1305] =  + _REFACS_25_;
	{long i; for (i = 1306; i < 1315; i++) O3063[i] =  + _REFACS_23_;}
	O3063[1346] =  + _REFACS_23_;
	O3063[1349] =  + _REFACS_23_;
	O3063[1351] =  + _REFACS_23_;
	O3063[1354] =  + _REFACS_23_;
}

long O3065[1355];
void O3065_init () {
	O3065[0] =  + _REFACS_14_;
	{long i; for (i = 1205; i < 1207; i++) O3065[i] =  + _REFACS_23_;}
	{long i; for (i = 1207; i < 1214; i++) O3065[i] =  + _REFACS_24_;}
	{long i; for (i = 1214; i < 1218; i++) O3065[i] =  + _REFACS_25_;}
	{long i; for (i = 1218; i < 1225; i++) O3065[i] =  + _REFACS_24_;}
	{long i; for (i = 1225; i < 1234; i++) O3065[i] =  + _REFACS_25_;}
	{long i; for (i = 1234; i < 1236; i++) O3065[i] =  + _REFACS_29_;}
	{long i; for (i = 1236; i < 1238; i++) O3065[i] =  + _REFACS_32_;}
	{long i; for (i = 1238; i < 1243; i++) O3065[i] =  + _REFACS_25_;}
	{long i; for (i = 1243; i < 1245; i++) O3065[i] =  + _REFACS_29_;}
	{long i; for (i = 1245; i < 1247; i++) O3065[i] =  + _REFACS_32_;}
	O3065[1247] =  + _REFACS_23_;
	O3065[1248] =  + _REFACS_28_;
	O3065[1249] =  + _REFACS_24_;
	O3065[1250] =  + _REFACS_27_;
	O3065[1251] =  + _REFACS_23_;
	O3065[1252] =  + _REFACS_25_;
	O3065[1253] =  + _REFACS_27_;
	{long i; for (i = 1254; i < 1257; i++) O3065[i] =  + _REFACS_23_;}
	{long i; for (i = 1257; i < 1259; i++) O3065[i] =  + _REFACS_24_;}
	O3065[1259] =  + _REFACS_27_;
	{long i; for (i = 1260; i < 1262; i++) O3065[i] =  + _REFACS_25_;}
	{long i; for (i = 1262; i < 1266; i++) O3065[i] =  + _REFACS_24_;}
	O3065[1266] =  + _REFACS_25_;
	O3065[1267] =  + _REFACS_29_;
	O3065[1268] =  + _REFACS_25_;
	O3065[1269] =  + _REFACS_27_;
	O3065[1270] =  + _REFACS_24_;
	O3065[1271] =  + _REFACS_26_;
	{long i; for (i = 1272; i < 1281; i++) O3065[i] =  + _REFACS_24_;}
	O3065[1281] =  + _REFACS_23_;
	O3065[1282] =  + _REFACS_28_;
	O3065[1283] =  + _REFACS_24_;
	O3065[1284] =  + _REFACS_27_;
	O3065[1285] =  + _REFACS_23_;
	O3065[1286] =  + _REFACS_25_;
	O3065[1287] =  + _REFACS_27_;
	{long i; for (i = 1288; i < 1291; i++) O3065[i] =  + _REFACS_23_;}
	{long i; for (i = 1291; i < 1293; i++) O3065[i] =  + _REFACS_24_;}
	O3065[1293] =  + _REFACS_27_;
	{long i; for (i = 1294; i < 1297; i++) O3065[i] =  + _REFACS_25_;}
	O3065[1297] =  + _REFACS_29_;
	O3065[1298] =  + _REFACS_25_;
	O3065[1299] =  + _REFACS_27_;
	{long i; for (i = 1300; i < 1305; i++) O3065[i] =  + _REFACS_24_;}
	O3065[1305] =  + _REFACS_26_;
	{long i; for (i = 1306; i < 1315; i++) O3065[i] =  + _REFACS_24_;}
	O3065[1346] =  + _REFACS_24_;
	O3065[1349] =  + _REFACS_24_;
	O3065[1351] =  + _REFACS_24_;
	O3065[1354] =  + _REFACS_24_;
}

long O3203[4];
void O3203_init () {
	O3203[0] = + _CHROFF_2_0_;
	O3203[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O3203[i] = + _CHROFF_2_0_;}
}

long O3204[4];
void O3204_init () {
	O3204[0] = + _CHROFF_2_1_;
	O3204[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O3204[i] = + _CHROFF_2_1_;}
}

long O3285[170];
void O3285_init () {
	O3285[0] = 0;
	O3285[1] = + _LNGOFF_0_0_0_0_;
	O3285[2] = + _I64OFF_0_0_0_0_0_0_0_;
	O3285[3] = + _LNGOFF_0_0_0_0_;
	O3285[4] = + _CHROFF_0_0_;
	O3285[5] = 0;
	O3285[6] = + _LNGOFF_1_0_0_0_;
	O3285[7] = + _CHROFF_1_0_;
	{long i; for (i = 168; i < 170; i++) O3285[i] = 0;}
}

long O3289[3];
void O3289_init () {
	O3289[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O3289[i] = 0;}
}

long O3886[1292];
void O3886_init () {
	{long i; for (i = 0; i < 3; i++) O3886[i] = + _PTROFF_1_1_0_0_0_0_;}
	O3886[667] = + _PTROFF_1_1_0_0_0_0_;
	{long i; for (i = 1290; i < 1292; i++) O3886[i] = + _PTROFF_1_1_0_1_0_0_;}
}

static EIF_TYPE_INDEX Y4239_pgtype0[] = {864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype1[] = {865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype2[] = {866,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype3[] = {867,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype4[] = {868,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype5[] = {869,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype6[] = {870,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype7[] = {871,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype8[] = {872,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype9[] = {873,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype10[] = {874,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype11[] = {875,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype12[] = {864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype13[] = {865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype14[] = {866,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype15[] = {867,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype16[] = {868,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype17[] = {869,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype18[] = {870,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype19[] = {871,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype20[] = {872,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype21[] = {873,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype22[] = {874,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype23[] = {875,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype24[] = {867,1012,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype25[] = {867,1012,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype26[] = {867,1012,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype27[] = {864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype28[] = {865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype29[] = {866,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype30[] = {867,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype31[] = {868,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype32[] = {869,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype33[] = {870,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype34[] = {871,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype35[] = {872,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype36[] = {873,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype37[] = {874,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype38[] = {875,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype39[] = {864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype40[] = {871,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype41[] = {869,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype42[] = {864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype43[] = {871,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype44[] = {864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype45[] = {871,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype46[] = {864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype47[] = {871,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype48[] = {864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype49[] = {871,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype50[] = {864,1098,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype51[] = {864,1071,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype52[] = {864,1071,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype53[] = {864,1071,0xFFF9,1,997,0,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype54[] = {864,1071,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype55[] = {864,1071,0xFFF9,1,997,1033,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype56[] = {864,1071,0xFFF9,1,997,1175,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype57[] = {864,1071,0xFFF9,1,997,1184,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype58[] = {864,1071,0xFFF9,1,997,1168,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype59[] = {864,1071,0xFFF9,1,997,1126,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype60[] = {864,1071,0xFFF9,1,997,1128,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype61[] = {864,1071,0xFFF9,1,997,1193,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype62[] = {864,1071,0xFFF9,1,997,1033,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype63[] = {864,1071,0xFFF9,1,997,1167,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype64[] = {864,1071,0xFFF9,1,997,942,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype65[] = {864,1071,0xFFF9,1,997,1163,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype66[] = {864,1071,0xFFF9,1,997,1189,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype67[] = {864,1071,0xFFF9,5,997,1006,1033,1033,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype68[] = {864,1071,0xFFF9,4,997,1033,1033,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype69[] = {864,1071,0xFFF9,1,997,1082,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype70[] = {864,1071,0xFFF9,1,997,1033,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype71[] = {864,1071,0xFFF9,1,997,1518,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype72[] = {864,1071,0xFFF9,7,997,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype73[] = {864,1071,0xFFF9,2,997,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype74[] = {864,1071,0xFFF9,3,997,1033,1033,942,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype75[] = {864,1071,0xFFF9,0,997,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype76[] = {864,1071,0xFFF9,8,997,1033,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype77[] = {864,943,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype78[] = {864,943,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype79[] = {864,943,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype80[] = {873,1021,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype81[] = {874,1024,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype82[] = {874,1024,0xFFFF};
static EIF_TYPE_INDEX Y4239_pgtype83[] = {864,1082,0xFFFF};
EIF_TYPE_INDEX *Y4239_gen_type [867];
EIF_TYPE_INDEX Y4239 [867];
void Y4239_init (void)
{
	egc_routines_types [4239] = Y4239;
	egc_routines_gen_types [4239] = Y4239_gen_type;
	egc_routines_offset [4239] = 301;
	Y4239_gen_type [0] = Y4239_pgtype0;
	Y4239_gen_type [1] = Y4239_pgtype1;
	Y4239_gen_type [2] = Y4239_pgtype2;
	Y4239_gen_type [3] = Y4239_pgtype3;
	Y4239_gen_type [4] = Y4239_pgtype4;
	Y4239_gen_type [5] = Y4239_pgtype5;
	Y4239_gen_type [6] = Y4239_pgtype6;
	Y4239_gen_type [7] = Y4239_pgtype7;
	Y4239_gen_type [8] = Y4239_pgtype8;
	Y4239_gen_type [9] = Y4239_pgtype9;
	Y4239_gen_type [10] = Y4239_pgtype10;
	Y4239_gen_type [11] = Y4239_pgtype11;
	Y4239_gen_type [276] = Y4239_pgtype12;
	Y4239_gen_type [277] = Y4239_pgtype13;
	Y4239_gen_type [278] = Y4239_pgtype14;
	Y4239_gen_type [279] = Y4239_pgtype15;
	Y4239_gen_type [280] = Y4239_pgtype16;
	Y4239_gen_type [281] = Y4239_pgtype17;
	Y4239_gen_type [282] = Y4239_pgtype18;
	Y4239_gen_type [283] = Y4239_pgtype19;
	Y4239_gen_type [284] = Y4239_pgtype20;
	Y4239_gen_type [285] = Y4239_pgtype21;
	Y4239_gen_type [286] = Y4239_pgtype22;
	Y4239_gen_type [287] = Y4239_pgtype23;
	Y4239_gen_type [288] = Y4239_pgtype24;
	Y4239_gen_type [346] = Y4239_pgtype25;
	Y4239_gen_type [347] = Y4239_pgtype26;
	Y4239_gen_type [362] = Y4239_pgtype27;
	Y4239_gen_type [363] = Y4239_pgtype28;
	Y4239_gen_type [364] = Y4239_pgtype29;
	Y4239_gen_type [365] = Y4239_pgtype30;
	Y4239_gen_type [366] = Y4239_pgtype31;
	Y4239_gen_type [367] = Y4239_pgtype32;
	Y4239_gen_type [368] = Y4239_pgtype33;
	Y4239_gen_type [369] = Y4239_pgtype34;
	Y4239_gen_type [370] = Y4239_pgtype35;
	Y4239_gen_type [371] = Y4239_pgtype36;
	Y4239_gen_type [372] = Y4239_pgtype37;
	Y4239_gen_type [373] = Y4239_pgtype38;
	Y4239_gen_type [374] = Y4239_pgtype39;
	Y4239_gen_type [375] = Y4239_pgtype40;
	Y4239_gen_type [376] = Y4239_pgtype41;
	Y4239_gen_type [377] = Y4239_pgtype42;
	Y4239_gen_type [378] = Y4239_pgtype43;
	Y4239_gen_type [379] = Y4239_pgtype44;
	Y4239_gen_type [380] = Y4239_pgtype45;
	Y4239_gen_type [381] = Y4239_pgtype46;
	Y4239_gen_type [382] = Y4239_pgtype47;
	Y4239_gen_type [383] = Y4239_pgtype48;
	Y4239_gen_type [384] = Y4239_pgtype49;
	Y4239_gen_type [385] = Y4239_pgtype50;
	Y4239_gen_type [386] = Y4239_pgtype51;
	Y4239_gen_type [511] = Y4239_pgtype52;
	Y4239_gen_type [512] = Y4239_pgtype53;
	Y4239_gen_type [513] = Y4239_pgtype54;
	Y4239_gen_type [514] = Y4239_pgtype55;
	Y4239_gen_type [515] = Y4239_pgtype56;
	Y4239_gen_type [516] = Y4239_pgtype57;
	Y4239_gen_type [517] = Y4239_pgtype58;
	Y4239_gen_type [518] = Y4239_pgtype59;
	Y4239_gen_type [519] = Y4239_pgtype60;
	Y4239_gen_type [520] = Y4239_pgtype61;
	Y4239_gen_type [521] = Y4239_pgtype62;
	Y4239_gen_type [522] = Y4239_pgtype63;
	Y4239_gen_type [523] = Y4239_pgtype64;
	Y4239_gen_type [524] = Y4239_pgtype65;
	Y4239_gen_type [525] = Y4239_pgtype66;
	Y4239_gen_type [526] = Y4239_pgtype67;
	Y4239_gen_type [527] = Y4239_pgtype68;
	Y4239_gen_type [528] = Y4239_pgtype69;
	Y4239_gen_type [529] = Y4239_pgtype70;
	Y4239_gen_type [530] = Y4239_pgtype71;
	Y4239_gen_type [531] = Y4239_pgtype72;
	Y4239_gen_type [532] = Y4239_pgtype73;
	Y4239_gen_type [533] = Y4239_pgtype74;
	Y4239_gen_type [534] = Y4239_pgtype75;
	Y4239_gen_type [535] = Y4239_pgtype76;
	Y4239_gen_type [643] = Y4239_pgtype77;
	Y4239_gen_type [644] = Y4239_pgtype78;
	Y4239_gen_type [645] = Y4239_pgtype79;
	Y4239_gen_type [781] = Y4239_pgtype80;
	Y4239_gen_type [784] = Y4239_pgtype81;
	Y4239_gen_type [785] = Y4239_pgtype82;
	Y4239_gen_type [866] = Y4239_pgtype83;
	Y4239[0] = 864;
	Y4239[1] = 865;
	Y4239[2] = 866;
	Y4239[3] = 867;
	Y4239[4] = 868;
	Y4239[5] = 869;
	Y4239[6] = 870;
	Y4239[7] = 871;
	Y4239[8] = 872;
	Y4239[9] = 873;
	Y4239[10] = 874;
	Y4239[11] = 875;
	Y4239[276] = 864;
	Y4239[277] = 865;
	Y4239[278] = 866;
	Y4239[279] = 867;
	Y4239[280] = 868;
	Y4239[281] = 869;
	Y4239[282] = 870;
	Y4239[283] = 871;
	Y4239[284] = 872;
	Y4239[285] = 873;
	Y4239[286] = 874;
	Y4239[287] = 875;
	Y4239[288] = 867;
	{long i; for (i = 346; i < 348; i++) Y4239[i] = 867;};
	Y4239[362] = 864;
	Y4239[363] = 865;
	Y4239[364] = 866;
	Y4239[365] = 867;
	Y4239[366] = 868;
	Y4239[367] = 869;
	Y4239[368] = 870;
	Y4239[369] = 871;
	Y4239[370] = 872;
	Y4239[371] = 873;
	Y4239[372] = 874;
	Y4239[373] = 875;
	Y4239[374] = 864;
	Y4239[375] = 871;
	Y4239[376] = 869;
	Y4239[377] = 864;
	Y4239[378] = 871;
	Y4239[379] = 864;
	Y4239[380] = 871;
	Y4239[381] = 864;
	Y4239[382] = 871;
	Y4239[383] = 864;
	Y4239[384] = 871;
	{long i; for (i = 385; i < 387; i++) Y4239[i] = 864;};
	{long i; for (i = 511; i < 536; i++) Y4239[i] = 864;};
	{long i; for (i = 643; i < 646; i++) Y4239[i] = 864;};
	Y4239[781] = 873;
	{long i; for (i = 784; i < 786; i++) Y4239[i] = 874;};
	Y4239[866] = 864;
}

long O4307[1378];
void O4307_init () {
	{long i; for (i = 0; i < 12; i++) O4307[i] = + _CHROFF_0_0_;}
	O4307[12] = + _CHROFF_1_0_;
	{long i; for (i = 13; i < 15; i++) O4307[i] = + _CHROFF_4_0_;}
	{long i; for (i = 15; i < 199; i++) O4307[i] = + _CHROFF_0_0_;}
	O4307[199] = + _CHROFF_1_0_;
	{long i; for (i = 200; i < 216; i++) O4307[i] = + _CHROFF_0_0_;}
	{long i; for (i = 228; i < 241; i++) O4307[i] = + _CHROFF_0_0_;}
	{long i; for (i = 241; i < 254; i++) O4307[i] = + _CHROFF_1_0_;}
	O4307[254] = + _CHROFF_2_0_;
	{long i; for (i = 255; i < 303; i++) O4307[i] = + _CHROFF_0_0_;}
	{long i; for (i = 303; i < 310; i++) O4307[i] = + _CHROFF_2_0_;}
	O4307[317] = + _CHROFF_1_0_;
	O4307[319] = + _CHROFF_7_0_;
	O4307[320] = + _CHROFF_6_0_;
	O4307[321] = + _CHROFF_5_0_;
	{long i; for (i = 322; i < 324; i++) O4307[i] = + _CHROFF_4_0_;}
	O4307[324] = + _CHROFF_5_0_;
	O4307[325] = + _CHROFF_7_0_;
	O4307[326] = + _CHROFF_5_0_;
	O4307[327] = + _CHROFF_9_0_;
	{long i; for (i = 328; i < 347; i++) O4307[i] = + _CHROFF_1_0_;}
	{long i; for (i = 347; i < 349; i++) O4307[i] = + _CHROFF_3_0_;}
	{long i; for (i = 349; i < 352; i++) O4307[i] = + _CHROFF_5_0_;}
	O4307[352] = + _CHROFF_9_0_;
	O4307[369] = + _CHROFF_2_0_;
	{long i; for (i = 371; i < 373; i++) O4307[i] = + _CHROFF_0_0_;}
	O4307[477] = + _CHROFF_9_0_;
	O4307[478] = + _CHROFF_10_0_;
	{long i; for (i = 479; i < 502; i++) O4307[i] = + _CHROFF_9_0_;}
	O4307[598] = + _CHROFF_3_2_;
	O4307[599] = + _CHROFF_4_2_;
	O4307[600] = + _CHROFF_5_2_;
	O4307[609] = + _CHROFF_22_0_;
	O4307[610] = + _CHROFF_28_0_;
	O4307[611] = + _CHROFF_24_0_;
	O4307[747] = + _CHROFF_1_0_;
	{long i; for (i = 750; i < 752; i++) O4307[i] = + _CHROFF_1_0_;}
	O4307[784] = + _CHROFF_3_0_;
	{long i; for (i = 786; i < 788; i++) O4307[i] = + _CHROFF_3_0_;}
	{long i; for (i = 802; i < 804; i++) O4307[i] = + _CHROFF_3_0_;}
	O4307[832] = + _CHROFF_7_0_;
	O4307[843] = + _CHROFF_6_0_;
	O4307[849] = + _CHROFF_6_0_;
	O4307[850] = + _CHROFF_8_0_;
	O4307[851] = + _CHROFF_6_0_;
	{long i; for (i = 859; i < 870; i++) O4307[i] = + _CHROFF_6_0_;}
	O4307[870] = + _CHROFF_15_0_;
	O4307[871] = + _CHROFF_12_0_;
	O4307[872] = + _CHROFF_10_0_;
	O4307[873] = + _CHROFF_7_0_;
	{long i; for (i = 874; i < 879; i++) O4307[i] = + _CHROFF_6_0_;}
	{long i; for (i = 879; i < 886; i++) O4307[i] = + _CHROFF_15_0_;}
	{long i; for (i = 886; i < 889; i++) O4307[i] = + _CHROFF_6_0_;}
	O4307[889] = + _CHROFF_83_0_;
	O4307[890] = + _CHROFF_6_0_;
	O4307[891] = + _CHROFF_7_0_;
	O4307[892] = + _CHROFF_6_0_;
	O4307[893] = + _CHROFF_39_0_;
	O4307[894] = + _CHROFF_46_0_;
	O4307[895] = + _CHROFF_39_0_;
	O4307[896] = + _CHROFF_49_0_;
	{long i; for (i = 897; i < 899; i++) O4307[i] = + _CHROFF_28_0_;}
	{long i; for (i = 899; i < 903; i++) O4307[i] = + _CHROFF_14_0_;}
	{long i; for (i = 904; i < 906; i++) O4307[i] = + _CHROFF_5_0_;}
	O4307[907] = + _CHROFF_5_0_;
	O4307[908] = + _CHROFF_6_0_;
	{long i; for (i = 917; i < 921; i++) O4307[i] = + _CHROFF_5_0_;}
	{long i; for (i = 925; i < 927; i++) O4307[i] = + _CHROFF_5_0_;}
	O4307[1184] = + _CHROFF_5_2_;
	O4307[1291] = + _CHROFF_6_0_;
	O4307[1368] = + _CHROFF_25_0_;
	O4307[1373] = + _CHROFF_13_0_;
	O4307[1375] = + _CHROFF_14_0_;
	O4307[1376] = + _CHROFF_5_0_;
	O4307[1377] = + _CHROFF_84_0_;
}

static EIF_TYPE_INDEX Y4375_pgtype0[] = {348,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4375_pgtype1[] = {349,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y4375_gen_type [2];
EIF_TYPE_INDEX Y4375 [2];
void Y4375_init (void)
{
	egc_routines_types [4375] = Y4375;
	egc_routines_gen_types [4375] = Y4375_gen_type;
	egc_routines_offset [4375] = 348;
	Y4375_gen_type [0] = Y4375_pgtype0;
	Y4375_gen_type [1] = Y4375_pgtype1;
	Y4375[0] = 348;
	Y4375[1] = 349;
}

long O4461[1146];
void O4461_init () {
	O4461[0] = + _LNGOFF_0_1_0_0_;
	{long i; for (i = 225; i < 227; i++) O4461[i] = + _LNGOFF_0_1_0_0_;}
	O4461[1145] = + _LNGOFF_6_1_0_0_;
}

long O4506[2];
void O4506_init () {
	O4506[0] = + _LNGOFF_0_1_0_0_;
	O4506[1] = + _LNGOFF_1_1_0_0_;
}

long O4507[2];
void O4507_init () {
	O4507[0] = + _LNGOFF_0_1_0_1_;
	O4507[1] = + _LNGOFF_1_1_0_1_;
}

long O4548[13];
void O4548_init () {
	{long i; for (i = 0; i < 12; i++) O4548[i] = + _LNGOFF_1_1_0_0_;}
	O4548[12] = + _LNGOFF_2_1_0_0_;
}

long O4549[13];
void O4549_init () {
	{long i; for (i = 0; i < 12; i++) O4549[i] = + _LNGOFF_1_1_0_1_;}
	O4549[12] = + _LNGOFF_2_1_0_1_;
}

long O4706[1064];
void O4706_init () {
	{long i; for (i = 0; i < 2; i++) O4706[i] = + _LNGOFF_0_0_0_0_;}
	O4706[290] = + _LNGOFF_1_0_0_0_;
	O4706[653] = + _LNGOFF_1_1_0_0_;
	O4706[655] = + _LNGOFF_49_16_0_2_;
	O4706[1063] = + _LNGOFF_84_3_0_0_;
}


#ifdef __cplusplus
}
#endif
