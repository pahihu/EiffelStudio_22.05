#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O2508[1404];
void O2508_init () {
	O2508[0] = 0;
	{long i; for (i = 1252; i < 1254; i++) O2508[i] = 0;}
	{long i; for (i = 1254; i < 1256; i++) O2508[i] =  + _REFACS_2_;}
	{long i; for (i = 1256; i < 1263; i++) O2508[i] =  + _REFACS_3_;}
	{long i; for (i = 1263; i < 1267; i++) O2508[i] =  + _REFACS_4_;}
	{long i; for (i = 1267; i < 1274; i++) O2508[i] =  + _REFACS_3_;}
	{long i; for (i = 1274; i < 1285; i++) O2508[i] =  + _REFACS_4_;}
	{long i; for (i = 1285; i < 1287; i++) O2508[i] =  + _REFACS_7_;}
	{long i; for (i = 1287; i < 1294; i++) O2508[i] =  + _REFACS_4_;}
	{long i; for (i = 1294; i < 1296; i++) O2508[i] =  + _REFACS_7_;}
	O2508[1296] =  + _REFACS_2_;
	O2508[1297] =  + _REFACS_7_;
	O2508[1298] =  + _REFACS_3_;
	O2508[1299] =  + _REFACS_6_;
	{long i; for (i = 1300; i < 1302; i++) O2508[i] =  + _REFACS_2_;}
	O2508[1302] =  + _REFACS_4_;
	{long i; for (i = 1303; i < 1306; i++) O2508[i] =  + _REFACS_2_;}
	{long i; for (i = 1306; i < 1308; i++) O2508[i] =  + _REFACS_3_;}
	O2508[1308] =  + _REFACS_6_;
	{long i; for (i = 1309; i < 1311; i++) O2508[i] =  + _REFACS_4_;}
	{long i; for (i = 1311; i < 1315; i++) O2508[i] =  + _REFACS_3_;}
	O2508[1315] =  + _REFACS_4_;
	O2508[1316] =  + _REFACS_8_;
	O2508[1317] =  + _REFACS_4_;
	O2508[1318] =  + _REFACS_6_;
	O2508[1319] =  + _REFACS_3_;
	O2508[1320] =  + _REFACS_5_;
	{long i; for (i = 1321; i < 1330; i++) O2508[i] =  + _REFACS_3_;}
	O2508[1330] =  + _REFACS_2_;
	O2508[1331] =  + _REFACS_7_;
	O2508[1332] =  + _REFACS_3_;
	O2508[1333] =  + _REFACS_6_;
	{long i; for (i = 1334; i < 1336; i++) O2508[i] =  + _REFACS_2_;}
	O2508[1336] =  + _REFACS_4_;
	{long i; for (i = 1337; i < 1340; i++) O2508[i] =  + _REFACS_2_;}
	{long i; for (i = 1340; i < 1342; i++) O2508[i] =  + _REFACS_3_;}
	O2508[1342] =  + _REFACS_6_;
	{long i; for (i = 1343; i < 1346; i++) O2508[i] =  + _REFACS_4_;}
	O2508[1346] =  + _REFACS_8_;
	O2508[1347] =  + _REFACS_4_;
	O2508[1348] =  + _REFACS_6_;
	{long i; for (i = 1349; i < 1354; i++) O2508[i] =  + _REFACS_3_;}
	O2508[1354] =  + _REFACS_5_;
	{long i; for (i = 1355; i < 1368; i++) O2508[i] =  + _REFACS_3_;}
	{long i; for (i = 1368; i < 1370; i++) O2508[i] =  + _REFACS_5_;}
	{long i; for (i = 1370; i < 1374; i++) O2508[i] =  + _REFACS_7_;}
	{long i; for (i = 1374; i < 1376; i++) O2508[i] =  + _REFACS_3_;}
	{long i; for (i = 1376; i < 1379; i++) O2508[i] =  + _REFACS_4_;}
	O2508[1379] =  + _REFACS_5_;
	{long i; for (i = 1380; i < 1384; i++) O2508[i] =  + _REFACS_4_;}
	O2508[1384] =  + _REFACS_5_;
	O2508[1385] =  + _REFACS_4_;
	{long i; for (i = 1386; i < 1388; i++) O2508[i] =  + _REFACS_5_;}
	{long i; for (i = 1388; i < 1394; i++) O2508[i] =  + _REFACS_7_;}
	O2508[1395] =  + _REFACS_2_;
	O2508[1398] =  + _REFACS_2_;
	O2508[1400] =  + _REFACS_2_;
	O2508[1403] =  + _REFACS_2_;
}

long O2510[1404];
void O2510_init () {
	O2510[0] =  + _REFACS_1_;
	{long i; for (i = 1252; i < 1254; i++) O2510[i] =  + _REFACS_1_;}
	{long i; for (i = 1254; i < 1256; i++) O2510[i] =  + _REFACS_3_;}
	{long i; for (i = 1256; i < 1263; i++) O2510[i] =  + _REFACS_4_;}
	{long i; for (i = 1263; i < 1267; i++) O2510[i] =  + _REFACS_5_;}
	{long i; for (i = 1267; i < 1274; i++) O2510[i] =  + _REFACS_4_;}
	{long i; for (i = 1274; i < 1285; i++) O2510[i] =  + _REFACS_5_;}
	{long i; for (i = 1285; i < 1287; i++) O2510[i] =  + _REFACS_8_;}
	{long i; for (i = 1287; i < 1294; i++) O2510[i] =  + _REFACS_5_;}
	{long i; for (i = 1294; i < 1296; i++) O2510[i] =  + _REFACS_8_;}
	O2510[1296] =  + _REFACS_3_;
	O2510[1297] =  + _REFACS_8_;
	O2510[1298] =  + _REFACS_4_;
	O2510[1299] =  + _REFACS_7_;
	{long i; for (i = 1300; i < 1302; i++) O2510[i] =  + _REFACS_3_;}
	O2510[1302] =  + _REFACS_5_;
	{long i; for (i = 1303; i < 1306; i++) O2510[i] =  + _REFACS_3_;}
	{long i; for (i = 1306; i < 1308; i++) O2510[i] =  + _REFACS_4_;}
	O2510[1308] =  + _REFACS_7_;
	{long i; for (i = 1309; i < 1311; i++) O2510[i] =  + _REFACS_5_;}
	{long i; for (i = 1311; i < 1315; i++) O2510[i] =  + _REFACS_4_;}
	O2510[1315] =  + _REFACS_5_;
	O2510[1316] =  + _REFACS_9_;
	O2510[1317] =  + _REFACS_5_;
	O2510[1318] =  + _REFACS_7_;
	O2510[1319] =  + _REFACS_4_;
	O2510[1320] =  + _REFACS_6_;
	{long i; for (i = 1321; i < 1330; i++) O2510[i] =  + _REFACS_4_;}
	O2510[1330] =  + _REFACS_3_;
	O2510[1331] =  + _REFACS_8_;
	O2510[1332] =  + _REFACS_4_;
	O2510[1333] =  + _REFACS_7_;
	{long i; for (i = 1334; i < 1336; i++) O2510[i] =  + _REFACS_3_;}
	O2510[1336] =  + _REFACS_5_;
	{long i; for (i = 1337; i < 1340; i++) O2510[i] =  + _REFACS_3_;}
	{long i; for (i = 1340; i < 1342; i++) O2510[i] =  + _REFACS_4_;}
	O2510[1342] =  + _REFACS_7_;
	{long i; for (i = 1343; i < 1346; i++) O2510[i] =  + _REFACS_5_;}
	O2510[1346] =  + _REFACS_9_;
	O2510[1347] =  + _REFACS_5_;
	O2510[1348] =  + _REFACS_7_;
	{long i; for (i = 1349; i < 1354; i++) O2510[i] =  + _REFACS_4_;}
	O2510[1354] =  + _REFACS_6_;
	{long i; for (i = 1355; i < 1368; i++) O2510[i] =  + _REFACS_4_;}
	{long i; for (i = 1368; i < 1370; i++) O2510[i] =  + _REFACS_6_;}
	{long i; for (i = 1370; i < 1374; i++) O2510[i] =  + _REFACS_8_;}
	{long i; for (i = 1374; i < 1376; i++) O2510[i] =  + _REFACS_4_;}
	{long i; for (i = 1376; i < 1379; i++) O2510[i] =  + _REFACS_5_;}
	O2510[1379] =  + _REFACS_6_;
	{long i; for (i = 1380; i < 1384; i++) O2510[i] =  + _REFACS_5_;}
	O2510[1384] =  + _REFACS_6_;
	O2510[1385] =  + _REFACS_5_;
	{long i; for (i = 1386; i < 1388; i++) O2510[i] =  + _REFACS_6_;}
	{long i; for (i = 1388; i < 1394; i++) O2510[i] =  + _REFACS_8_;}
	O2510[1395] =  + _REFACS_3_;
	O2510[1398] =  + _REFACS_3_;
	O2510[1400] =  + _REFACS_3_;
	O2510[1403] =  + _REFACS_3_;
}

long O2514[1404];
void O2514_init () {
	O2514[0] =  + _REFACS_3_;
	{long i; for (i = 1252; i < 1254; i++) O2514[i] =  + _REFACS_3_;}
	{long i; for (i = 1254; i < 1256; i++) O2514[i] =  + _REFACS_5_;}
	{long i; for (i = 1256; i < 1263; i++) O2514[i] =  + _REFACS_6_;}
	{long i; for (i = 1263; i < 1267; i++) O2514[i] =  + _REFACS_7_;}
	{long i; for (i = 1267; i < 1274; i++) O2514[i] =  + _REFACS_6_;}
	{long i; for (i = 1274; i < 1285; i++) O2514[i] =  + _REFACS_7_;}
	{long i; for (i = 1285; i < 1287; i++) O2514[i] =  + _REFACS_10_;}
	{long i; for (i = 1287; i < 1294; i++) O2514[i] =  + _REFACS_7_;}
	{long i; for (i = 1294; i < 1296; i++) O2514[i] =  + _REFACS_10_;}
	O2514[1296] =  + _REFACS_5_;
	O2514[1297] =  + _REFACS_10_;
	O2514[1298] =  + _REFACS_6_;
	O2514[1299] =  + _REFACS_9_;
	{long i; for (i = 1300; i < 1302; i++) O2514[i] =  + _REFACS_5_;}
	O2514[1302] =  + _REFACS_7_;
	{long i; for (i = 1303; i < 1306; i++) O2514[i] =  + _REFACS_5_;}
	{long i; for (i = 1306; i < 1308; i++) O2514[i] =  + _REFACS_6_;}
	O2514[1308] =  + _REFACS_9_;
	{long i; for (i = 1309; i < 1311; i++) O2514[i] =  + _REFACS_7_;}
	{long i; for (i = 1311; i < 1315; i++) O2514[i] =  + _REFACS_6_;}
	O2514[1315] =  + _REFACS_7_;
	O2514[1316] =  + _REFACS_11_;
	O2514[1317] =  + _REFACS_7_;
	O2514[1318] =  + _REFACS_9_;
	O2514[1319] =  + _REFACS_6_;
	O2514[1320] =  + _REFACS_8_;
	{long i; for (i = 1321; i < 1330; i++) O2514[i] =  + _REFACS_6_;}
	O2514[1330] =  + _REFACS_5_;
	O2514[1331] =  + _REFACS_10_;
	O2514[1332] =  + _REFACS_6_;
	O2514[1333] =  + _REFACS_9_;
	{long i; for (i = 1334; i < 1336; i++) O2514[i] =  + _REFACS_5_;}
	O2514[1336] =  + _REFACS_7_;
	{long i; for (i = 1337; i < 1340; i++) O2514[i] =  + _REFACS_5_;}
	{long i; for (i = 1340; i < 1342; i++) O2514[i] =  + _REFACS_6_;}
	O2514[1342] =  + _REFACS_9_;
	{long i; for (i = 1343; i < 1346; i++) O2514[i] =  + _REFACS_7_;}
	O2514[1346] =  + _REFACS_11_;
	O2514[1347] =  + _REFACS_7_;
	O2514[1348] =  + _REFACS_9_;
	{long i; for (i = 1349; i < 1354; i++) O2514[i] =  + _REFACS_6_;}
	O2514[1354] =  + _REFACS_8_;
	{long i; for (i = 1355; i < 1368; i++) O2514[i] =  + _REFACS_6_;}
	{long i; for (i = 1368; i < 1370; i++) O2514[i] =  + _REFACS_8_;}
	{long i; for (i = 1370; i < 1374; i++) O2514[i] =  + _REFACS_10_;}
	{long i; for (i = 1374; i < 1376; i++) O2514[i] =  + _REFACS_6_;}
	{long i; for (i = 1376; i < 1379; i++) O2514[i] =  + _REFACS_7_;}
	O2514[1379] =  + _REFACS_8_;
	{long i; for (i = 1380; i < 1384; i++) O2514[i] =  + _REFACS_7_;}
	O2514[1384] =  + _REFACS_8_;
	O2514[1385] =  + _REFACS_7_;
	{long i; for (i = 1386; i < 1388; i++) O2514[i] =  + _REFACS_8_;}
	{long i; for (i = 1388; i < 1394; i++) O2514[i] =  + _REFACS_10_;}
	O2514[1395] =  + _REFACS_5_;
	O2514[1398] =  + _REFACS_5_;
	O2514[1400] =  + _REFACS_5_;
	O2514[1403] =  + _REFACS_5_;
}

long O2521[1294];
void O2521_init () {
	O2521[0] = 0;
	{long i; for (i = 1281; i < 1283; i++) O2521[i] =  + _REFACS_8_;}
	{long i; for (i = 1283; i < 1285; i++) O2521[i] =  + _REFACS_11_;}
	{long i; for (i = 1290; i < 1292; i++) O2521[i] =  + _REFACS_8_;}
	{long i; for (i = 1292; i < 1294; i++) O2521[i] =  + _REFACS_11_;}
}

long O2523[1294];
void O2523_init () {
	O2523[0] =  + _REFACS_1_;
	{long i; for (i = 1281; i < 1283; i++) O2523[i] =  + _REFACS_9_;}
	{long i; for (i = 1283; i < 1285; i++) O2523[i] =  + _REFACS_12_;}
	{long i; for (i = 1290; i < 1292; i++) O2523[i] =  + _REFACS_9_;}
	{long i; for (i = 1292; i < 1294; i++) O2523[i] =  + _REFACS_12_;}
}

long O2525[1294];
void O2525_init () {
	O2525[0] =  + _REFACS_2_;
	{long i; for (i = 1281; i < 1283; i++) O2525[i] =  + _REFACS_10_;}
	{long i; for (i = 1283; i < 1285; i++) O2525[i] =  + _REFACS_13_;}
	{long i; for (i = 1290; i < 1292; i++) O2525[i] =  + _REFACS_10_;}
	{long i; for (i = 1292; i < 1294; i++) O2525[i] =  + _REFACS_13_;}
}

long O2527[1294];
void O2527_init () {
	O2527[0] =  + _REFACS_3_;
	{long i; for (i = 1281; i < 1283; i++) O2527[i] =  + _REFACS_11_;}
	{long i; for (i = 1283; i < 1285; i++) O2527[i] =  + _REFACS_14_;}
	{long i; for (i = 1290; i < 1292; i++) O2527[i] =  + _REFACS_11_;}
	{long i; for (i = 1292; i < 1294; i++) O2527[i] =  + _REFACS_14_;}
}

long O2822[1422];
void O2822_init () {
	O2822[0] = + _R64OFF_0_0_0_1_0_0_0_0_;
	{long i; for (i = 1415; i < 1417; i++) O2822[i] = + _R64OFF_0_0_0_1_0_0_0_0_;}
	O2822[1419] = + _R64OFF_0_0_0_2_0_0_0_0_;
	O2822[1420] = + _R64OFF_5_1_0_8_0_0_0_0_;
	O2822[1421] = + _R64OFF_2_0_0_2_0_0_0_0_;
}


#ifdef __cplusplus
}
#endif
