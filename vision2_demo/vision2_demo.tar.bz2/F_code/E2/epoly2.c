#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O1293[1420];
void O1293_init () {
	O1293[0] =  + _REFACS_1_;
	{long i; for (i = 1229; i < 1231; i++) O1293[i] =  + _REFACS_1_;}
	{long i; for (i = 1270; i < 1272; i++) O1293[i] =  + _REFACS_1_;}
	{long i; for (i = 1272; i < 1279; i++) O1293[i] =  + _REFACS_2_;}
	O1293[1279] =  + _REFACS_3_;
	{long i; for (i = 1280; i < 1290; i++) O1293[i] =  + _REFACS_2_;}
	O1293[1290] =  + _REFACS_3_;
	{long i; for (i = 1291; i < 1312; i++) O1293[i] =  + _REFACS_2_;}
	O1293[1312] =  + _REFACS_1_;
	O1293[1313] =  + _REFACS_6_;
	O1293[1314] =  + _REFACS_1_;
	O1293[1315] =  + _REFACS_5_;
	{long i; for (i = 1316; i < 1318; i++) O1293[i] =  + _REFACS_1_;}
	O1293[1318] =  + _REFACS_3_;
	{long i; for (i = 1319; i < 1322; i++) O1293[i] =  + _REFACS_1_;}
	{long i; for (i = 1322; i < 1324; i++) O1293[i] =  + _REFACS_2_;}
	O1293[1324] =  + _REFACS_5_;
	{long i; for (i = 1325; i < 1327; i++) O1293[i] =  + _REFACS_3_;}
	{long i; for (i = 1327; i < 1331; i++) O1293[i] =  + _REFACS_2_;}
	O1293[1331] =  + _REFACS_3_;
	O1293[1332] =  + _REFACS_7_;
	{long i; for (i = 1333; i < 1335; i++) O1293[i] =  + _REFACS_3_;}
	O1293[1335] =  + _REFACS_2_;
	O1293[1336] =  + _REFACS_4_;
	{long i; for (i = 1337; i < 1346; i++) O1293[i] =  + _REFACS_2_;}
	O1293[1346] =  + _REFACS_1_;
	O1293[1347] =  + _REFACS_6_;
	O1293[1348] =  + _REFACS_1_;
	O1293[1349] =  + _REFACS_5_;
	{long i; for (i = 1350; i < 1352; i++) O1293[i] =  + _REFACS_1_;}
	O1293[1352] =  + _REFACS_3_;
	{long i; for (i = 1353; i < 1356; i++) O1293[i] =  + _REFACS_1_;}
	{long i; for (i = 1356; i < 1358; i++) O1293[i] =  + _REFACS_2_;}
	O1293[1358] =  + _REFACS_5_;
	{long i; for (i = 1359; i < 1362; i++) O1293[i] =  + _REFACS_3_;}
	O1293[1362] =  + _REFACS_7_;
	{long i; for (i = 1363; i < 1365; i++) O1293[i] =  + _REFACS_3_;}
	{long i; for (i = 1365; i < 1370; i++) O1293[i] =  + _REFACS_2_;}
	O1293[1370] =  + _REFACS_4_;
	{long i; for (i = 1371; i < 1380; i++) O1293[i] =  + _REFACS_2_;}
	{long i; for (i = 1404; i < 1410; i++) O1293[i] =  + _REFACS_6_;}
	O1293[1411] =  + _REFACS_1_;
	O1293[1414] =  + _REFACS_1_;
	O1293[1416] =  + _REFACS_1_;
	O1293[1419] =  + _REFACS_1_;
}

long O1301[1347];
void O1301_init () {
	O1301[0] = 0;
	{long i; for (i = 1233; i < 1235; i++) O1301[i] = 0;}
	{long i; for (i = 1278; i < 1281; i++) O1301[i] =  + _REFACS_3_;}
	{long i; for (i = 1289; i < 1299; i++) O1301[i] =  + _REFACS_3_;}
	{long i; for (i = 1299; i < 1301; i++) O1301[i] =  + _REFACS_6_;}
	{long i; for (i = 1301; i < 1308; i++) O1301[i] =  + _REFACS_3_;}
	{long i; for (i = 1308; i < 1310; i++) O1301[i] =  + _REFACS_6_;}
	O1301[1312] =  + _REFACS_2_;
	O1301[1346] =  + _REFACS_2_;
}

long O2406[1449];
void O2406_init () {
	O2406[0] = + _LNGOFF_1_4_0_0_;
	O2406[1448] = + _LNGOFF_1_8_0_0_;
}

long O2408[1449];
void O2408_init () {
	O2408[0] = + _LNGOFF_1_4_0_1_;
	O2408[1448] = + _LNGOFF_1_8_0_1_;
}

long O2409[1449];
void O2409_init () {
	O2409[0] = + _CHROFF_1_2_;
	O2409[1448] = + _CHROFF_1_3_;
}

long O2410[1449];
void O2410_init () {
	O2410[0] = + _LNGOFF_1_4_0_2_;
	O2410[1448] = + _LNGOFF_1_8_0_2_;
}

long O2412[1449];
void O2412_init () {
	O2412[0] = + _CHROFF_1_3_;
	O2412[1448] = + _CHROFF_1_4_;
}


#ifdef __cplusplus
}
#endif
