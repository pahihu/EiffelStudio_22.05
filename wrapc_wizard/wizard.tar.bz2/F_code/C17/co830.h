
#ifndef _C17_co830_
#define _C17_co830_

#ifdef __cplusplus
extern "C" {
#endif

extern void F403_5728(EIF_REFERENCE);
extern void F403_5729(EIF_REFERENCE);
extern void EIF_Minit830(void);
extern long O5484[];

#ifdef __cplusplus
}
#endif

#endif
