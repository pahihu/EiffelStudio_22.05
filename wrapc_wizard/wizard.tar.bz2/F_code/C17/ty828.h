
#ifndef _C17_ty828_
#define _C17_ty828_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F756_6388(EIF_REFERENCE);
extern void EIF_Minit828(void);
extern char *(*R5852[])();
extern char *(*R5662[])();
extern char *(*R5865[])();

#ifdef __cplusplus
}
#endif

#endif
