/*
 * Code for class RX_PCRE_COMPILER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "rx814.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RX_PCRE_COMPILER}.make */
void F1570_16303 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1466, 1).id);
	F1467_14893(RTCW(tr1), ((EIF_INTEGER_32) 1024L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(29, 1).id);
	F30_205(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = F1_14(RTOSCF(16388,F1570_16388, (Current)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	F1571_16392(Current);
	tr1 = RTOSCF(1860,F121_1860, (Current));
	F1570_16335(Current, tr1);
	tr1 = RTOSCF(1861,F121_1861, (Current));
	F1570_16336(Current, tr1);
	F1570_16321(Current);
	RTLE;
}

/* {RX_PCRE_COMPILER}.is_compiled */
EIF_BOOLEAN F1570_16304 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(5438,F365_5438, (Current));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr3 = RTOSCF(1904,F123_1904, (Current));
	Result = F900_6994(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {RX_PCRE_COMPILER}.set_default_options */
void F1570_16321 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1570_16323(Current, (EIF_BOOLEAN) 0);
	F1570_16327(Current, (EIF_BOOLEAN) 0);
	F1570_16328(Current, (EIF_BOOLEAN) 0);
	F1570_16324(Current, (EIF_BOOLEAN) 0);
	F1570_16329(Current, (EIF_BOOLEAN) 1);
	F1570_16330(Current, (EIF_BOOLEAN) 0);
	F1570_16331(Current, (EIF_BOOLEAN) 1);
	F1570_16332(Current, (EIF_BOOLEAN) 1);
	F1570_16333(Current, (EIF_BOOLEAN) 0);
	F1570_16325(Current, (EIF_BOOLEAN) 1);
	F1570_16326(Current, (EIF_BOOLEAN) 0);
	RTLE;
}

/* {RX_PCRE_COMPILER}.set_caseless */
void F1570_16323 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_0_) = (EIF_BOOLEAN) arg1;
}

/* {RX_PCRE_COMPILER}.set_extended */
void F1570_16324 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_1_) = (EIF_BOOLEAN) arg1;
}

/* {RX_PCRE_COMPILER}.set_greedy */
void F1570_16325 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_2_) = (EIF_BOOLEAN) arg1;
}

/* {RX_PCRE_COMPILER}.set_strict */
void F1570_16326 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_10_) = (EIF_BOOLEAN) arg1;
}

/* {RX_PCRE_COMPILER}.set_multiline */
void F1570_16327 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_3_) = (EIF_BOOLEAN) arg1;
}

/* {RX_PCRE_COMPILER}.set_dotall */
void F1570_16328 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_4_) = (EIF_BOOLEAN) arg1;
}

/* {RX_PCRE_COMPILER}.set_empty_allowed */
void F1570_16329 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_5_) = (EIF_BOOLEAN) arg1;
}

/* {RX_PCRE_COMPILER}.set_dollar_endonly */
void F1570_16330 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_6_) = (EIF_BOOLEAN) arg1;
}

/* {RX_PCRE_COMPILER}.set_bol */
void F1570_16331 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_7_) = (EIF_BOOLEAN) arg1;
}

/* {RX_PCRE_COMPILER}.set_eol */
void F1570_16332 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_8_) = (EIF_BOOLEAN) arg1;
}

/* {RX_PCRE_COMPILER}.set_anchored */
void F1570_16333 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_9_) = (EIF_BOOLEAN) arg1;
}

/* {RX_PCRE_COMPILER}.set_ims_options */
void F1570_16334 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = F122_1878(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_0_) = (EIF_BOOLEAN) tb1;
	tb1 = F122_1879(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_3_) = (EIF_BOOLEAN) tb1;
	tb1 = F122_1880(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_4_) = (EIF_BOOLEAN) tb1;
	RTLE;
}

/* {RX_PCRE_COMPILER}.set_character_case_mapping */
void F1570_16335 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {RX_PCRE_COMPILER}.set_word_set */
void F1570_16336 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

/* {RX_PCRE_COMPILER}.compile */
void F1570_16337 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tr1 = RTLNSMART(eif_new_type(1133, 1).id);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8271[Dtype(RTCW(arg1))-1132])(arg1);
	F1132_9913(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1134_10027(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1131_9883(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8271[Dtype(RTCW(arg1))-1132])(arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_8_) = (EIF_INTEGER_32) ti4_1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1467_14912(RTCW(tr1));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_9_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_10_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	F1570_16355(Current);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_12_16_0_0_) = (EIF_NATURAL_32) ((EIF_NATURAL_32) 32U);
	*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_) = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_) = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_11_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
	tr1 = RTOSCF(1934,F123_1934, (Current));
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
	F1570_16342(Current, tr1, ((EIF_INTEGER_32) 99L), ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 70U));
	F1570_16370(Current, *(EIF_NATURAL_32 *)(Current+ _LNGOFF_12_16_0_0_), (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, (EIF_INTEGER_64) ((EIF_INTEGER_32) -1L));
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	if ((EIF_BOOLEAN)(tr1 == RTOSCF(1934,F123_1934, (Current)))) {
		tb1 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_8_));
	}
	if (tb1) {
		tr1 = RTOSCF(1920,F123_1920, (Current));
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
		F1570_16342(Current, tr1, ((EIF_INTEGER_32) 22L), ti4_1);
	} else {
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_10_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_9_))) {
			tr1 = RTOSCF(1918,F123_1918, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
			F1570_16342(Current, tr1, ((EIF_INTEGER_32) 15L), ti4_1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	if ((EIF_BOOLEAN)(tr1 == RTOSCF(1934,F123_1934, (Current)))) {
		tr1 = RTOSCF(1904,F123_1904, (Current));
		F1570_16342(Current, tr1, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 0U));
		loc1 = F1570_16354(Current);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_9_)) {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			if (F1570_16385(Current, loc1)) {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				F1570_16333(Current, (EIF_BOOLEAN) 1);
			} else {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				tu4_1 = F1570_16384(Current, loc1);
				loc1 = (EIF_NATURAL_32) tu4_1;
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				tb1 = '\0';
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_) < (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
					tb1 = F1570_16386(Current);
				}
				if (tb1) {
					F1570_16356(Current, (EIF_BOOLEAN) 1);
				}
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_11_) <= ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_) >= (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L)))) {
			*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_) = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) -1L);
		}
	}
	RTLE;
}

/* {RX_PCRE_COMPILER}.set_error */
void F1570_16342 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_4_) = (EIF_INTEGER_32) arg2;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_5_) = (EIF_INTEGER_32) arg3;
	RTLE;
}

/* {RX_PCRE_COMPILER}.reset */
void F1570_16343 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(1934,F123_1934, (Current));
	F1570_16342(Current, tr1, ((EIF_INTEGER_32) 99L), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1134_10057(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1131_9883(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_8_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {RX_PCRE_COMPILER}.print_options */
void F1570_16344 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_9_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_0_)) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_1_)) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_3_)) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_4_)) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_6_)) && *(EIF_BOOLEAN *)(Current+ _CHROFF_12_2_))) {
		tr1 = RTMS_EX_H("No options",10,929784947);
		F369_5471(RTCW(arg1), tr1);
	} else {
		tr1 = RTMS_EX_H("Options:",8,506073658);
		F369_5471(RTCW(arg1), tr1);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_9_)) {
			tr1 = RTMS_EX_H(" anchored",9,1357852260);
			F369_5471(RTCW(arg1), tr1);
		}
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_0_)) {
			tr1 = RTMS_EX_H(" caseless",9,1237892467);
			F369_5471(RTCW(arg1), tr1);
		}
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_1_)) {
			tr1 = RTMS_EX_H(" extended",9,2112684644);
			F369_5471(RTCW(arg1), tr1);
		}
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_3_)) {
			tr1 = RTMS_EX_H(" multiline",10,585888357);
			F369_5471(RTCW(arg1), tr1);
		}
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_4_)) {
			tr1 = RTMS_EX_H(" dotall",7,1076291180);
			F369_5471(RTCW(arg1), tr1);
		}
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_6_)) {
			tr1 = RTMS_EX_H(" dollar_endonly",15,2000853881);
			F369_5471(RTCW(arg1), tr1);
		}
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_2_)) {
			tr1 = RTMS_EX_H(" ungreedy",9,1201777017);
			F369_5471(RTCW(arg1), tr1);
		}
	}
	F367_5456(RTCW(arg1));
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_12_)) {
		tr1 = RTMS_EX_H("Case state changes",18,1019536755);
		F367_5455(RTCW(arg1), tr1);
	}
	RTLE;
}

/* {RX_PCRE_COMPILER}.print_start_bits */
void F1570_16345 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLIU(5);
	
	RTGC;
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	if ((EIF_BOOLEAN)(loc3 == NULL)) {
		tr1 = RTMS_EX_H("Study returned NULL",19,1926693708);
		F369_5471(RTCW(arg1), tr1);
	} else {
		tr1 = RTMS_EX_H("Starting character set: ",24,1381252896);
		F369_5471(RTCW(arg1), tr1);
		loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
		loc2 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 24L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > ((EIF_NATURAL_32) 1114111U))) break;
			tb1 = F30_209(RTCW(loc3), loc1);
			if (tb1) {
				if ((EIF_BOOLEAN) (loc2 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 75L))) {
					F367_5456(RTCW(arg1));
					tr1 = RTMS_EX_H("  ",2,8224);
					F369_5471(RTCW(arg1), tr1);
					loc2 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L);
				}
				tb1 = '\0';
				tb2 = '\0';
				tu4_1 = (EIF_NATURAL_32) ((EIF_INTEGER_32) 255L);
				if ((EIF_BOOLEAN) (loc1 <= tu4_1)) {
					tr1 = RTOSCF(1870,F121_1870, (Current));
					tb3 = F30_209(RTCW(tr1), loc1);
					tb2 = tb3;
				}
				if (tb2) {
					tb1 = (EIF_BOOLEAN)(loc1 != ((EIF_NATURAL_32) 32U));
				}
				if (tb1) {
					tc1 = (EIF_CHARACTER_8) loc1;
					F369_5470(RTCW(arg1), tc1);
					loc2 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L);
				} else {
					tr1 = RTMS_EX_H("\\x",2,23672);
					F369_5471(RTCW(arg1), tr1);
					tr1 = RTLNS(eif_new_type(900, 0x01).id, 900, _OBJSIZ_0_0_0_0_0_0_0_0_);
					loc4 = F901_7020(RTCW(tr1), loc1, (EIF_BOOLEAN) 0);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
						F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '{');
						F369_5471(RTCW(arg1), loc4);
						F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '}');
					} else {
						tr1 = RTOSCF(4287,F244_4287, (Current));
						F1569_16302(RTCW(tr1), arg1, loc4, ((EIF_INTEGER_32) 2L), (EIF_CHARACTER_8) '0');
					}
					loc2 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 5L);
				}
				F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ' ');
			}
			loc1 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
		}
	}
	F367_5456(RTCW(arg1));
	RTLE;
}

/* {RX_PCRE_COMPILER}.print_compiled_pattern_code */
void F1570_16346 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc6 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc7 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc8 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc9 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc12);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,loc13);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN) !arg2) {
		loc12 = F1570_16350(Current);
		F1570_16349(Current, loc12);
	}
	tr1 = RTMS_EX_H("------------------------------------------------------------------",66,364498733);
	F367_5455(RTCW(arg1), tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		if (arg2) {
			loc11 = (EIF_INTEGER_32) loc1;
		} else {
			RTCT0("a_position_map_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc12 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			loc11 = F1570_16348(Current, loc1, loc12);
		}
		tr1 = RTOSCF(4287,F244_4287, (Current));
		tr2 = eif_out__i4_s1(loc11);
		F1569_16302(RTCW(tr1), arg1, tr2, ((EIF_INTEGER_32) 3L), (EIF_CHARACTER_8) ' ');
		F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ' ');
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc6 = F1467_14894(RTCW(tr1), loc1);
		if ((EIF_BOOLEAN) (loc6 >= ((EIF_NATURAL_32) 70U))) {
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= loc2)) {
				if (arg2) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
					loc11 = (EIF_INTEGER_32) tu4_1;
				} else {
					RTCT0("a_position_map_not_void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc12 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
					ti4_1 = (EIF_INTEGER_32) tu4_1;
					loc11 = F1570_16348(Current, (EIF_INTEGER_32) (loc1 + ti4_1), loc12);
					ti4_1 = F1570_16348(Current, loc1, loc12);
					loc11 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc11 - ti4_1);
				}
				tr1 = RTOSCF(4287,F244_4287, (Current));
				tr2 = eif_out__i4_s1(loc11);
				F1569_16302(RTCW(tr1), arg1, tr2, ((EIF_INTEGER_32) 3L), (EIF_CHARACTER_8) ' ');
			} else {
				tr1 = RTMS_EX_H("end-of-byte-code",16,1519359333);
				F369_5471(RTCW(arg1), tr1);
			}
			tr1 = RTMS_EX_H(" Bra ",5,1115037984);
			F369_5471(RTCW(arg1), tr1);
			F366_5448(RTCW(arg1), (EIF_NATURAL_32) (loc6 - ((EIF_NATURAL_32) 70U)));
			loc1++;
		} else {
			switch (loc6) {
				case 56U:
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= loc2)) {
						if (arg2) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
							loc11 = (EIF_INTEGER_32) tu4_1;
						} else {
							RTCT0("a_position_map_not_void", EX_CHECK);
							if ((EIF_BOOLEAN)(loc12 != NULL)) {
								RTCK0;
							} else {
								RTCF0;
							}
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
							ti4_1 = (EIF_INTEGER_32) tu4_1;
							loc11 = F1570_16348(Current, (EIF_INTEGER_32) (loc1 + ti4_1), loc12);
							ti4_1 = F1570_16348(Current, loc1, loc12);
							loc11 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc11 - ti4_1);
						}
						tr1 = RTOSCF(4287,F244_4287, (Current));
						tr2 = eif_out__i4_s1(loc11);
						F1569_16302(RTCW(tr1), arg1, tr2, ((EIF_INTEGER_32) 3L), (EIF_CHARACTER_8) ' ');
					} else {
						tr1 = RTMS_EX_H("end-of-byte-code",16,1519359333);
						F369_5471(RTCW(arg1), tr1);
					}
					F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ' ');
					tr1 = F124_2008(Current, loc6);
					F369_5471(RTCW(arg1), tr1);
					loc1++;
					break;
				case 57U:
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= loc2)) {
						if (arg2) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
							loc11 = (EIF_INTEGER_32) tu4_1;
						} else {
							RTCT0("a_position_map_not_void", EX_CHECK);
							if ((EIF_BOOLEAN)(loc12 != NULL)) {
								RTCK0;
							} else {
								RTCF0;
							}
							loc11 = F1570_16348(Current, loc1, loc12);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
							ti4_1 = (EIF_INTEGER_32) tu4_1;
							ti4_1 = F1570_16348(Current, (EIF_INTEGER_32) (loc1 - ti4_1), loc12);
							loc11 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc11 - ti4_1);
						}
						tr1 = RTOSCF(4287,F244_4287, (Current));
						tr2 = eif_out__i4_s1(loc11);
						F1569_16302(RTCW(tr1), arg1, tr2, ((EIF_INTEGER_32) 3L), (EIF_CHARACTER_8) ' ');
					} else {
						tr1 = RTMS_EX_H("end-of-byte-code",16,1519359333);
						F369_5471(RTCW(arg1), tr1);
					}
					F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ' ');
					tr1 = F124_2008(Current, loc6);
					F369_5471(RTCW(arg1), tr1);
					loc1++;
					break;
				case 12U:
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= loc2)) {
						F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ' ');
						tr1 = RTOSCF(4287,F244_4287, (Current));
						tr2 = RTOSCF(6857,F894_6857, (Current));
						tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_1 = F1467_14896(RTCW(tr3), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						ti4_1 = (EIF_INTEGER_32) tu4_1;
						tr2 = F899_6960(RTCW(tr2), ti4_1, (EIF_BOOLEAN) 0);
						F1569_16302(RTCW(tr1), arg1, tr2, ((EIF_INTEGER_32) 2L), (EIF_CHARACTER_8) '0');
					} else {
						tr1 = RTMS_EX_H("end-of-byte-code",16,1519359333);
						F369_5471(RTCW(arg1), tr1);
					}
					F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ' ');
					tr1 = F124_2008(Current, loc6);
					F369_5471(RTCW(arg1), tr1);
					loc1++;
					break;
				case 58U:
				case 59U:
				case 60U:
				case 61U:
				case 62U:
				case 63U:
				case 64U:
				case 65U:
				case 66U:
				case 67U:
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= loc2)) {
						tr1 = RTOSCF(4287,F244_4287, (Current));
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_1 = F1467_14896(RTCW(tr2), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						tr2 = eif_out__u4_s1(tu4_1);
						F1569_16302(RTCW(tr1), arg1, tr2, ((EIF_INTEGER_32) 3L), (EIF_CHARACTER_8) ' ');
					} else {
						tr1 = RTMS_EX_H("end-of-byte-code",16,1519359333);
						F369_5471(RTCW(arg1), tr1);
					}
					F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ' ');
					tr1 = F124_2008(Current, loc6);
					F369_5471(RTCW(arg1), tr1);
					loc1++;
					break;
				case 16U:
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= loc2)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						loc5 = (EIF_INTEGER_32) tu4_1;
						tr1 = RTOSCF(4287,F244_4287, (Current));
						tr2 = eif_out__i4_s1(loc5);
						F1569_16302(RTCW(tr1), arg1, tr2, ((EIF_INTEGER_32) 3L), (EIF_CHARACTER_8) ' ');
						F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ' ');
						loc1++;
						if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + loc5) <= loc2)) {
							loc1++;
							for (;;) {
								if ((EIF_BOOLEAN) (loc5 <= ((EIF_INTEGER_32) 0L))) break;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								loc7 = F1467_14895(RTCW(tr1), loc1);
								tb1 = '\0';
								tu4_1 = (EIF_NATURAL_32) ((EIF_INTEGER_32) 255L);
								if ((EIF_BOOLEAN) (loc7 <= tu4_1)) {
									tr1 = RTOSCF(1870,F121_1870, (Current));
									tb2 = F30_209(RTCW(tr1), loc7);
									tb1 = tb2;
								}
								if (tb1) {
									tc1 = (EIF_CHARACTER_8) loc7;
									F369_5470(RTCW(arg1), tc1);
								} else {
									tr1 = RTMS_EX_H("\\x",2,23672);
									F369_5471(RTCW(arg1), tr1);
									tr1 = RTLNS(eif_new_type(900, 0x01).id, 900, _OBJSIZ_0_0_0_0_0_0_0_0_);
									loc13 = F901_7020(RTCW(tr1), loc7, (EIF_BOOLEAN) 0);
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_1_1_0_2_);
									if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
										F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '{');
										F369_5471(RTCW(arg1), loc13);
										F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '}');
									} else {
										tr1 = RTOSCF(4287,F244_4287, (Current));
										F1569_16302(RTCW(tr1), arg1, loc13, ((EIF_INTEGER_32) 2L), (EIF_CHARACTER_8) '0');
									}
								}
								loc1++;
								loc5--;
							}
							loc1--;
						} else {
							tr1 = RTMS_EX_H("chars wrong-length",18,652120936);
							F369_5471(RTCW(arg1), tr1);
						}
					} else {
						tr1 = RTMS_EX_H("chars missing-length",20,1645442408);
						F369_5471(RTCW(arg1), tr1);
					}
					break;
				case 18U:
				case 19U:
				case 20U:
				case 21U:
				case 22U:
				case 23U:
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= loc2)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						loc7 = F1467_14895(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						tb1 = '\0';
						tu4_1 = (EIF_NATURAL_32) ((EIF_INTEGER_32) 255L);
						if ((EIF_BOOLEAN) (loc7 <= tu4_1)) {
							tr1 = RTOSCF(1870,F121_1870, (Current));
							tb2 = F30_209(RTCW(tr1), loc7);
							tb1 = tb2;
						}
						if (tb1) {
							tc1 = (EIF_CHARACTER_8) loc7;
							F369_5470(RTCW(arg1), tc1);
						} else {
							tr1 = RTMS_EX_H("\\x",2,23672);
							F369_5471(RTCW(arg1), tr1);
							tr1 = RTLNS(eif_new_type(900, 0x01).id, 900, _OBJSIZ_0_0_0_0_0_0_0_0_);
							loc13 = F901_7020(RTCW(tr1), loc7, (EIF_BOOLEAN) 0);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_1_1_0_2_);
							if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
								F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '{');
								F369_5471(RTCW(arg1), loc13);
								F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '}');
							} else {
								tr1 = RTOSCF(4287,F244_4287, (Current));
								F1569_16302(RTCW(tr1), arg1, loc13, ((EIF_INTEGER_32) 2L), (EIF_CHARACTER_8) '0');
							}
						}
					} else {
						tr1 = RTMS_EX_H("end-of-byte-code",16,1519359333);
						F369_5471(RTCW(arg1), tr1);
					}
					F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ' ');
					tr1 = F124_2008(Current, loc6);
					F369_5471(RTCW(arg1), tr1);
					loc1++;
					break;
				case 36U:
				case 37U:
				case 38U:
				case 39U:
				case 40U:
				case 41U:
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= loc2)) {
						tr1 = RTMS_EX_H("    ",4,538976288);
						F369_5471(RTCW(arg1), tr1);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_1 = F1467_14894(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						tr1 = F124_2008(Current, tu4_1);
						F369_5471(RTCW(arg1), tr1);
					} else {
						tr1 = RTMS_EX_H("end-of-byte-code ",17,262144032);
						F369_5471(RTCW(arg1), tr1);
					}
					tr1 = F124_2008(Current, loc6);
					F369_5471(RTCW(arg1), tr1);
					loc1++;
					break;
				case 24U:
				case 25U:
				case 26U:
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)) <= loc2)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						loc7 = F1467_14895(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
						tb1 = '\0';
						tu4_1 = (EIF_NATURAL_32) ((EIF_INTEGER_32) 255L);
						if ((EIF_BOOLEAN) (loc7 <= tu4_1)) {
							tr1 = RTOSCF(1870,F121_1870, (Current));
							tb2 = F30_209(RTCW(tr1), loc7);
							tb1 = tb2;
						}
						if (tb1) {
							tc1 = (EIF_CHARACTER_8) loc7;
							F369_5470(RTCW(arg1), tc1);
						} else {
							tr1 = RTMS_EX_H("\\x",2,23672);
							F369_5471(RTCW(arg1), tr1);
							tr1 = RTLNS(eif_new_type(900, 0x01).id, 900, _OBJSIZ_0_0_0_0_0_0_0_0_);
							loc13 = F901_7020(RTCW(tr1), loc7, (EIF_BOOLEAN) 0);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_1_1_0_2_);
							if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
								F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '{');
								F369_5471(RTCW(arg1), loc13);
								F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '}');
							} else {
								tr1 = RTOSCF(4287,F244_4287, (Current));
								F1569_16302(RTCW(tr1), arg1, loc13, ((EIF_INTEGER_32) 2L), (EIF_CHARACTER_8) '0');
							}
						}
						F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '{');
						if ((EIF_BOOLEAN)(loc6 != ((EIF_NATURAL_32) 26U))) {
							tr1 = RTMS_EX_H("0,",2,12332);
							F369_5471(RTCW(arg1), tr1);
						}
						tr1 = RTOSCF(4287,F244_4287, (Current));
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_1 = F1467_14896(RTCW(tr2), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						tr2 = eif_out__u4_s1(tu4_1);
						F1569_16302(RTCW(tr1), arg1, tr2, ((EIF_INTEGER_32) 3L), (EIF_CHARACTER_8) ' ');
						if ((EIF_BOOLEAN)(loc6 == ((EIF_NATURAL_32) 25U))) {
							F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '\?');
						}
						F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '}');
					} else {
						tr1 = RTMS_EX_H("end-of-byte-code",16,1519359333);
						F369_5471(RTCW(arg1), tr1);
						F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ' ');
						tr1 = F124_2008(Current, loc6);
						F369_5471(RTCW(arg1), tr1);
					}
					loc1 += ((EIF_INTEGER_32) 2L);
					break;
				case 42U:
				case 43U:
				case 44U:
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)) <= loc2)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_1 = F1467_14894(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
						tr1 = F124_2008(Current, tu4_1);
						F369_5471(RTCW(arg1), tr1);
						F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '(');
						if ((EIF_BOOLEAN)(loc6 != ((EIF_NATURAL_32) 44U))) {
							F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ',');
						}
						tr1 = RTOSCF(4287,F244_4287, (Current));
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_1 = F1467_14896(RTCW(tr2), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						tr2 = eif_out__u4_s1(tu4_1);
						F1569_16302(RTCW(tr1), arg1, tr2, ((EIF_INTEGER_32) 3L), (EIF_CHARACTER_8) ' ');
						F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ')');
						if ((EIF_BOOLEAN)(loc6 == ((EIF_NATURAL_32) 43U))) {
							F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '\?');
						}
					} else {
						tr1 = RTMS_EX_H("end-of-byte-code",16,1519359333);
						F369_5471(RTCW(arg1), tr1);
						F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ' ');
						tr1 = F124_2008(Current, loc6);
						F369_5471(RTCW(arg1), tr1);
					}
					loc1 += ((EIF_INTEGER_32) 2L);
					break;
				case 17U:
					tr1 = RTMS_EX_H("[^",2,23390);
					F369_5471(RTCW(arg1), tr1);
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= loc2)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						loc7 = F1467_14895(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						tb1 = '\0';
						tu4_1 = (EIF_NATURAL_32) ((EIF_INTEGER_32) 255L);
						if ((EIF_BOOLEAN) (loc7 <= tu4_1)) {
							tr1 = RTOSCF(1870,F121_1870, (Current));
							tb2 = F30_209(RTCW(tr1), loc7);
							tb1 = tb2;
						}
						if (tb1) {
							tc1 = (EIF_CHARACTER_8) loc7;
							F369_5470(RTCW(arg1), tc1);
						} else {
							tr1 = RTMS_EX_H("\\x",2,23672);
							F369_5471(RTCW(arg1), tr1);
							tr1 = RTLNS(eif_new_type(900, 0x01).id, 900, _OBJSIZ_0_0_0_0_0_0_0_0_);
							loc13 = F901_7020(RTCW(tr1), loc7, (EIF_BOOLEAN) 0);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_1_1_0_2_);
							if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
								F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '{');
								F369_5471(RTCW(arg1), loc13);
								F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '}');
							} else {
								tr1 = RTOSCF(4287,F244_4287, (Current));
								F1569_16302(RTCW(tr1), arg1, loc13, ((EIF_INTEGER_32) 2L), (EIF_CHARACTER_8) '0');
							}
						}
					} else {
						tr1 = RTMS_EX_H("end-of-byte-code",16,1519359333);
						F369_5471(RTCW(arg1), tr1);
					}
					F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ']');
					loc1++;
					break;
				case 27U:
				case 28U:
				case 29U:
				case 30U:
				case 31U:
				case 32U:
					tr1 = RTMS_EX_H("[^",2,23390);
					F369_5471(RTCW(arg1), tr1);
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= loc2)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						loc7 = F1467_14895(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						tb1 = '\0';
						tu4_1 = (EIF_NATURAL_32) ((EIF_INTEGER_32) 255L);
						if ((EIF_BOOLEAN) (loc7 <= tu4_1)) {
							tr1 = RTOSCF(1870,F121_1870, (Current));
							tb2 = F30_209(RTCW(tr1), loc7);
							tb1 = tb2;
						}
						if (tb1) {
							tc1 = (EIF_CHARACTER_8) loc7;
							F369_5470(RTCW(arg1), tc1);
						} else {
							tr1 = RTMS_EX_H("\\x",2,23672);
							F369_5471(RTCW(arg1), tr1);
							tr1 = RTLNS(eif_new_type(900, 0x01).id, 900, _OBJSIZ_0_0_0_0_0_0_0_0_);
							loc13 = F901_7020(RTCW(tr1), loc7, (EIF_BOOLEAN) 0);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_1_1_0_2_);
							if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
								F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '{');
								F369_5471(RTCW(arg1), loc13);
								F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '}');
							} else {
								tr1 = RTOSCF(4287,F244_4287, (Current));
								F1569_16302(RTCW(tr1), arg1, loc13, ((EIF_INTEGER_32) 2L), (EIF_CHARACTER_8) '0');
							}
						}
					} else {
						tr1 = RTMS_EX_H("end-of-byte-code",16,1519359333);
						F369_5471(RTCW(arg1), tr1);
					}
					F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ']');
					tr1 = F124_2008(Current, loc6);
					F369_5471(RTCW(arg1), tr1);
					loc1++;
					break;
				case 33U:
				case 34U:
				case 35U:
					tr1 = RTMS_EX_H("[^",2,23390);
					F369_5471(RTCW(arg1), tr1);
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)) <= loc2)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						loc7 = F1467_14895(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
						tb1 = '\0';
						tu4_1 = (EIF_NATURAL_32) ((EIF_INTEGER_32) 255L);
						if ((EIF_BOOLEAN) (loc7 <= tu4_1)) {
							tr1 = RTOSCF(1870,F121_1870, (Current));
							tb2 = F30_209(RTCW(tr1), loc7);
							tb1 = tb2;
						}
						if (tb1) {
							tc1 = (EIF_CHARACTER_8) loc7;
							F369_5470(RTCW(arg1), tc1);
						} else {
							tr1 = RTMS_EX_H("\\x",2,23672);
							F369_5471(RTCW(arg1), tr1);
							tr1 = RTLNS(eif_new_type(900, 0x01).id, 900, _OBJSIZ_0_0_0_0_0_0_0_0_);
							loc13 = F901_7020(RTCW(tr1), loc7, (EIF_BOOLEAN) 0);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_1_1_0_2_);
							if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
								F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '{');
								F369_5471(RTCW(arg1), loc13);
								F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '}');
							} else {
								tr1 = RTOSCF(4287,F244_4287, (Current));
								F1569_16302(RTCW(tr1), arg1, loc13, ((EIF_INTEGER_32) 2L), (EIF_CHARACTER_8) '0');
							}
						}
						tr1 = RTMS_EX_H("](",2,23848);
						F369_5471(RTCW(arg1), tr1);
						if ((EIF_BOOLEAN)(loc6 != ((EIF_NATURAL_32) 35U))) {
							F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ',');
						}
						tr1 = RTOSCF(4287,F244_4287, (Current));
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_1 = F1467_14896(RTCW(tr2), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						tr2 = eif_out__u4_s1(tu4_1);
						F1569_16302(RTCW(tr1), arg1, tr2, ((EIF_INTEGER_32) 3L), (EIF_CHARACTER_8) ' ');
						F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ')');
						if ((EIF_BOOLEAN)(loc6 == ((EIF_NATURAL_32) 34U))) {
							F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '\?');
						}
					} else {
						tr1 = RTMS_EX_H("end-of-byte-code",16,1519359333);
						F369_5471(RTCW(arg1), tr1);
					}
					loc1 += ((EIF_INTEGER_32) 2L);
					break;
				case 53U:
				case 54U:
					if ((EIF_BOOLEAN)(loc6 == ((EIF_NATURAL_32) 54U))) {
						tr1 = F124_2008(Current, loc6);
						F369_5471(RTCW(arg1), tr1);
						if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= loc2)) {
							tr1 = RTOSCF(4287,F244_4287, (Current));
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tu4_1 = F1467_14896(RTCW(tr2), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
							tr2 = eif_out__u4_s1(tu4_1);
							F1569_16302(RTCW(tr1), arg1, tr2, ((EIF_INTEGER_32) 3L), (EIF_CHARACTER_8) ' ');
						}
						loc1++;
					} else {
						tr1 = RTMS_EX_H("    [",5,539222107);
						F369_5471(RTCW(arg1), tr1);
						if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= loc2)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
							loc10 = (EIF_INTEGER_32) tu4_1;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tb1 = F1467_14899(RTCW(tr1), loc10);
							if (tb1) {
								loc3 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
								for (;;) {
									if ((EIF_BOOLEAN) (loc3 > ((EIF_NATURAL_32) 1114111U))) break;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tb1 = F1467_14898(RTCW(tr1), loc10, loc3);
									if (tb1) {
										loc4 = (EIF_NATURAL_32) (EIF_NATURAL_32) (loc3 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L));
										for (;;) {
											tb1 = '\01';
											if (!(EIF_BOOLEAN) (loc4 > ((EIF_NATURAL_32) 1114111U))) {
												tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tb2 = F1467_14898(RTCW(tr1), loc10, loc4);
												tb1 = (EIF_BOOLEAN) !tb2;
											}
											if (tb1) break;
											loc4 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
										}
										tb2 = '\0';
										tu4_1 = (EIF_NATURAL_32) ((EIF_INTEGER_32) 255L);
										if ((EIF_BOOLEAN) (loc3 <= tu4_1)) {
											tr1 = RTOSCF(1870,F121_1870, (Current));
											tb3 = F30_209(RTCW(tr1), loc3);
											tb2 = tb3;
										}
										if (tb2) {
											tc1 = (EIF_CHARACTER_8) loc3;
											F369_5470(RTCW(arg1), tc1);
										} else {
											tr1 = RTMS_EX_H("\\x",2,23672);
											F369_5471(RTCW(arg1), tr1);
											tr1 = RTLNS(eif_new_type(900, 0x01).id, 900, _OBJSIZ_0_0_0_0_0_0_0_0_);
											loc13 = F901_7020(RTCW(tr1), loc3, (EIF_BOOLEAN) 0);
											ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_1_1_0_2_);
											if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
												F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '{');
												F369_5471(RTCW(arg1), loc13);
												F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '}');
											} else {
												tr1 = RTOSCF(4287,F244_4287, (Current));
												F1569_16302(RTCW(tr1), arg1, loc13, ((EIF_INTEGER_32) 2L), (EIF_CHARACTER_8) '0');
											}
										}
										loc4 -= (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
										if ((EIF_BOOLEAN) (loc4 > loc3)) {
											F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '-');
											tb2 = '\0';
											tu4_1 = (EIF_NATURAL_32) ((EIF_INTEGER_32) 255L);
											if ((EIF_BOOLEAN) (loc4 <= tu4_1)) {
												tr1 = RTOSCF(1870,F121_1870, (Current));
												tb3 = F30_209(RTCW(tr1), loc4);
												tb2 = tb3;
											}
											if (tb2) {
												tc1 = (EIF_CHARACTER_8) loc4;
												F369_5470(RTCW(arg1), tc1);
											} else {
												tr1 = RTMS_EX_H("\\x",2,23672);
												F369_5471(RTCW(arg1), tr1);
												tr1 = RTLNS(eif_new_type(900, 0x01).id, 900, _OBJSIZ_0_0_0_0_0_0_0_0_);
												loc13 = F901_7020(RTCW(tr1), loc4, (EIF_BOOLEAN) 0);
												ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_1_1_0_2_);
												if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
													F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '{');
													F369_5471(RTCW(arg1), loc13);
													F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '}');
												} else {
													tr1 = RTOSCF(4287,F244_4287, (Current));
													F1569_16302(RTCW(tr1), arg1, loc13, ((EIF_INTEGER_32) 2L), (EIF_CHARACTER_8) '0');
												}
											}
										}
										loc3 = (EIF_NATURAL_32) loc4;
									}
									loc3 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
								}
							} else {
								tr1 = RTMS_EX_H("invalid character set: ",23,415342624);
								F369_5471(RTCW(arg1), tr1);
								tr1 = RTOSCF(4287,F244_4287, (Current));
								tr2 = eif_out__i4_s1(loc10);
								F1569_16302(RTCW(tr1), arg1, tr2, ((EIF_INTEGER_32) 3L), (EIF_CHARACTER_8) ' ');
							}
							loc1++;
						} else {
							tr1 = RTMS_EX_H("end-of-byte-code",16,1519359333);
							F369_5471(RTCW(arg1), tr1);
						}
						F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ']');
					}
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= loc2)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_1 = F1467_14894(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						switch (tu4_1) {
							case 45U:
							case 46U:
							case 47U:
							case 48U:
							case 49U:
							case 50U:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tu4_1 = F1467_14894(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
								tr1 = F124_2008(Current, tu4_1);
								F369_5471(RTCW(arg1), tr1);
								loc1++;
								break;
							case 51U:
							case 52U:
								if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 3L)) <= loc2)) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									loc8 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									loc9 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 3L)));
									F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '{');
									tr1 = RTOSCF(4287,F244_4287, (Current));
									tr2 = eif_out__u4_s1(loc8);
									F1569_16302(RTCW(tr1), arg1, tr2, ((EIF_INTEGER_32) 3L), (EIF_CHARACTER_8) ' ');
									F369_5470(RTCW(arg1), (EIF_CHARACTER_8) ',');
									if ((EIF_BOOLEAN)(loc9 != (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
										tr1 = RTOSCF(4287,F244_4287, (Current));
										tr2 = eif_out__u4_s1(loc9);
										F1569_16302(RTCW(tr1), arg1, tr2, ((EIF_INTEGER_32) 3L), (EIF_CHARACTER_8) ' ');
									}
									F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '}');
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tu4_1 = F1467_14894(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
									if ((EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 52U))) {
										F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '\?');
									}
								} else {
									tr1 = RTMS_EX_H("end-of-byte-code",16,1519359333);
									F369_5471(RTCW(arg1), tr1);
								}
								loc1 += ((EIF_INTEGER_32) 3L);
								break;
						}
					}
					break;
				default:
					tr1 = RTMS_EX_H("    ",4,538976288);
					F369_5471(RTCW(arg1), tr1);
					tr1 = F124_2008(Current, loc6);
					F369_5471(RTCW(arg1), tr1);
					break;
			}
		}
		loc1++;
		F367_5456(RTCW(arg1));
	}
	tr1 = RTMS_EX_H("------------------------------------------------------------------",66,364498733);
	F367_5455(RTCW(arg1), tr1);
	RTLE;
}

/* {RX_PCRE_COMPILER}.print_compiled_pattern_info */
void F1570_16347 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_64 ti8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTMS_EX_H("Capturing subpattern count = ",29,1111938336);
	F369_5471(RTCW(arg1), tr1);
	F366_5441(RTCW(arg1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_9_));
	F367_5456(RTCW(arg1));
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_10_) > ((EIF_INTEGER_32) 0L))) {
		tr1 = RTMS_EX_H("Max back reference = ",21,1379591968);
		F369_5471(RTCW(arg1), tr1);
		F366_5441(RTCW(arg1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_10_));
		F367_5456(RTCW(arg1));
	}
	F1570_16344(Current, arg1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_) >= (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
		tr1 = RTMS_EX_H("First char = ",13,1096991520);
		F369_5471(RTCW(arg1), tr1);
		tb1 = '\0';
		ti8_1 = (EIF_INTEGER_64) ((EIF_INTEGER_32) 255L);
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_) <= ti8_1)) {
			tr1 = RTOSCF(1870,F121_1870, (Current));
			ti8_1 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_);
			tu4_1 = (EIF_NATURAL_32) ti8_1;
			tb2 = F30_209(RTCW(tr1), tu4_1);
			tb1 = tb2;
		}
		if (tb1) {
			F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '\'');
			ti8_1 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_);
			tc1 = (EIF_CHARACTER_8) ti8_1;
			F369_5470(RTCW(arg1), tc1);
			F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '\'');
		} else {
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_) < (EIF_INTEGER_64) ((EIF_INTEGER_32) 32L))) {
				F366_5445(RTCW(arg1), *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_));
			} else {
				tr1 = RTMS_EX_H("\\x",2,23672);
				F369_5471(RTCW(arg1), tr1);
				ti8_1 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_);
				tu4_1 = (EIF_NATURAL_32) ti8_1;
				tr1 = RTLNS(eif_new_type(900, 0x01).id, 900, _OBJSIZ_0_0_0_0_0_0_0_0_);
				loc1 = F901_7020(RTCW(tr1), tu4_1, (EIF_BOOLEAN) 0);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
					F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '{');
					F369_5471(RTCW(arg1), loc1);
					F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '}');
				} else {
					tr1 = RTOSCF(4287,F244_4287, (Current));
					F1569_16302(RTCW(tr1), arg1, loc1, ((EIF_INTEGER_32) 2L), (EIF_CHARACTER_8) '0');
				}
			}
		}
		F367_5456(RTCW(arg1));
	} else {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_11_)) {
			tr1 = RTMS_EX_H("First char at start or follows \\n",33,1908101230);
			F367_5455(RTCW(arg1), tr1);
		} else {
			tr1 = RTMS_EX_H("No first char",13,1373969778);
			F367_5455(RTCW(arg1), tr1);
		}
	}
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_) >= (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
		tr1 = RTMS_EX_H("Need char = ",12,1488413216);
		F369_5471(RTCW(arg1), tr1);
		tb1 = '\0';
		ti8_1 = (EIF_INTEGER_64) ((EIF_INTEGER_32) 255L);
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_) <= ti8_1)) {
			tr1 = RTOSCF(1870,F121_1870, (Current));
			ti8_1 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_);
			tu4_1 = (EIF_NATURAL_32) ti8_1;
			tb2 = F30_209(RTCW(tr1), tu4_1);
			tb1 = tb2;
		}
		if (tb1) {
			F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '\'');
			ti8_1 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_);
			tc1 = (EIF_CHARACTER_8) ti8_1;
			F369_5470(RTCW(arg1), tc1);
			F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '\'');
		} else {
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_) < (EIF_INTEGER_64) ((EIF_INTEGER_32) 32L))) {
				F366_5445(RTCW(arg1), *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_));
			} else {
				tr1 = RTMS_EX_H("\\x",2,23672);
				F369_5471(RTCW(arg1), tr1);
				ti8_1 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_);
				tu4_1 = (EIF_NATURAL_32) ti8_1;
				tr1 = RTLNS(eif_new_type(900, 0x01).id, 900, _OBJSIZ_0_0_0_0_0_0_0_0_);
				loc1 = F901_7020(RTCW(tr1), tu4_1, (EIF_BOOLEAN) 0);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
					F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '{');
					F369_5471(RTCW(arg1), loc1);
					F369_5470(RTCW(arg1), (EIF_CHARACTER_8) '}');
				} else {
					tr1 = RTOSCF(4287,F244_4287, (Current));
					F1569_16302(RTCW(tr1), arg1, loc1, ((EIF_INTEGER_32) 2L), (EIF_CHARACTER_8) '0');
				}
			}
		}
		F367_5456(RTCW(arg1));
	} else {
		tr1 = RTMS_EX_H("No need char",12,429707378);
		F367_5455(RTCW(arg1), tr1);
	}
	RTLE;
}

/* {RX_PCRE_COMPILER}.map_position */
EIF_INTEGER_32 F1570_16348 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,arg2);
	RTLIU(1);
	
	RTGC;
	F1550_15649(RTCW(arg2), arg1);
	tb1 = F1548_15548(RTCW(arg2));
	if (tb1) {
		ti4_1 = F1548_15540(RTCW(arg2));
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 10000L) + arg1);
	}/* NOTREACHED */
	
}

/* {RX_PCRE_COMPILER}.fill_position_map */
void F1570_16349 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		F1550_15658(RTCW(arg1), loc5, loc1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = F1467_14894(RTCW(tr1), loc1);
		if ((EIF_BOOLEAN) (loc4 >= ((EIF_NATURAL_32) 70U))) {
			loc5 += ((EIF_INTEGER_32) 3L);
			loc1++;
		} else {
			switch (loc4) {
				case 12U:
					loc5 += ((EIF_INTEGER_32) 2L);
					loc1++;
					break;
				case 66U:
					loc5 += ((EIF_INTEGER_32) 2L);
					loc1++;
					break;
				case 67U:
					loc5 += ((EIF_INTEGER_32) 2L);
					loc1++;
					break;
				case 16U:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
					loc3 = (EIF_INTEGER_32) tu4_1;
					loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + loc3) + ((EIF_INTEGER_32) 2L));
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc3) + ((EIF_INTEGER_32) 1L));
					break;
				case 56U:
				case 57U:
				case 58U:
				case 59U:
				case 60U:
				case 61U:
				case 62U:
				case 63U:
				case 65U:
					loc5 += ((EIF_INTEGER_32) 3L);
					loc1++;
					break;
				case 64U:
					loc5 += ((EIF_INTEGER_32) 3L);
					loc1++;
					break;
				case 18U:
				case 19U:
				case 20U:
				case 21U:
				case 22U:
				case 23U:
				case 36U:
				case 37U:
				case 38U:
				case 39U:
				case 40U:
				case 41U:
					loc5 += ((EIF_INTEGER_32) 2L);
					loc1++;
					break;
				case 24U:
				case 25U:
				case 26U:
					loc5 += ((EIF_INTEGER_32) 4L);
					loc1 += ((EIF_INTEGER_32) 2L);
					break;
				case 42U:
				case 43U:
				case 44U:
					loc5 += ((EIF_INTEGER_32) 4L);
					loc1 += ((EIF_INTEGER_32) 2L);
					break;
				case 17U:
					loc5 += ((EIF_INTEGER_32) 2L);
					loc1++;
					break;
				case 27U:
				case 28U:
				case 29U:
				case 30U:
				case 31U:
				case 32U:
					loc5 += ((EIF_INTEGER_32) 2L);
					loc1++;
					break;
				case 33U:
				case 34U:
				case 35U:
					loc5 += ((EIF_INTEGER_32) 4L);
					loc1 += ((EIF_INTEGER_32) 2L);
					break;
				case 54U:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_1 = F1467_14894(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
					switch (tu4_1) {
						case 45U:
						case 46U:
						case 47U:
						case 48U:
						case 49U:
						case 50U:
							loc5 += ((EIF_INTEGER_32) 3L);
							loc1++;
							break;
						case 51U:
						case 52U:
							loc5 += ((EIF_INTEGER_32) 7L);
							loc1 += ((EIF_INTEGER_32) 3L);
							break;
						default:
							loc5 += ((EIF_INTEGER_32) 2L);
							break;
					}
					break;
				case 53U:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_1 = F1467_14894(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
					switch (tu4_1) {
						case 45U:
						case 46U:
						case 47U:
						case 48U:
						case 49U:
						case 50U:
							loc5 += ((EIF_INTEGER_32) 33L);
							loc1++;
							break;
						case 51U:
						case 52U:
							loc5 += ((EIF_INTEGER_32) 37L);
							loc1 += ((EIF_INTEGER_32) 3L);
							break;
						default:
							loc5 += ((EIF_INTEGER_32) 32L);
							break;
					}
					break;
				default:
					loc5++;
					break;
			}
		}
		loc1++;
	}
	F1550_15658(RTCW(arg1), loc5, loc1);
	RTLE;
}

/* {RX_PCRE_COMPILER}.new_position_map */
EIF_REFERENCE F1570_16350 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1553,1067,1067,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1553, _OBJSIZ_11_0_0_9_0_0_0_0_);
	}
	F1550_15633(RTCW(tr1), ((EIF_INTEGER_32) 50L));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {RX_PCRE_COMPILER}.ims_options */
EIF_NATURAL_32 F1570_16354 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = (EIF_NATURAL_32) ((EIF_NATURAL_32) 0U);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_0_)) {
		tu4_1 = F122_1885(Current, Result);
		Result = (EIF_NATURAL_32) tu4_1;
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_3_)) {
		tu4_1 = F122_1887(Current, Result);
		Result = (EIF_NATURAL_32) tu4_1;
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_4_)) {
		RTLE;
		return (EIF_NATURAL_32) F122_1889(Current, Result);
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_COMPILER}.set_default_internal_options */
void F1570_16355 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1570_16356(Current, (EIF_BOOLEAN) 0);
	F1570_16357(Current, (EIF_BOOLEAN) 0);
	RTLE;
}

/* {RX_PCRE_COMPILER}.set_startline */
void F1570_16356 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_11_) = (EIF_BOOLEAN) arg1;
}

/* {RX_PCRE_COMPILER}.set_ichanged */
void F1570_16357 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_12_) = (EIF_BOOLEAN) arg1;
}

/* {RX_PCRE_COMPILER}.find_fixed_code_length */
EIF_INTEGER_32 F1570_16369 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 tu4_3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 2L));
	for (;;) {
		if (loc5) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc3 = F1467_14894(RTCW(tr1), loc1);
		if ((EIF_BOOLEAN) (loc3 > ((EIF_NATURAL_32) 70U))) {
			loc3 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 70U);
		}
		switch (loc3) {
			case 65U:
			case 66U:
			case 70U:
				loc2 = F1570_16369(Current, loc1);
				if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					loc4 += loc2;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
					ti4_1 = (EIF_INTEGER_32) tu4_1;
					loc1 += ti4_1;
					for (;;) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_1 = F1467_14894(RTCW(tr1), loc1);
						if ((EIF_BOOLEAN)(tu4_1 != ((EIF_NATURAL_32) 56U))) break;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						ti4_1 = (EIF_INTEGER_32) tu4_2;
						loc1 += ti4_1;
					}
					loc1 += ((EIF_INTEGER_32) 2L);
				}
				break;
			case 0U:
			case 56U:
			case 57U:
			case 58U:
			case 59U:
				if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
					Result = (EIF_INTEGER_32) loc4;
				} else {
					if ((EIF_BOOLEAN)(Result != loc4)) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
				if ((EIF_BOOLEAN) !loc5) {
					if ((EIF_BOOLEAN)(loc3 != ((EIF_NATURAL_32) 56U))) {
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						loc1 += ((EIF_INTEGER_32) 2L);
						loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					}
				}
				break;
			case 60U:
			case 61U:
			case 62U:
			case 63U:
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
				ti4_1 = (EIF_INTEGER_32) tu4_2;
				loc1 += ti4_1;
				for (;;) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_2 = F1467_14894(RTCW(tr1), loc1);
					if ((EIF_BOOLEAN)(tu4_2 != ((EIF_NATURAL_32) 56U))) break;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_3 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
					ti4_1 = (EIF_INTEGER_32) tu4_3;
					loc1 += ti4_1;
				}
				loc1 += ((EIF_INTEGER_32) 2L);
				break;
			case 64U:
				loc1 += ((EIF_INTEGER_32) 2L);
				break;
			case 12U:
			case 67U:
				loc1 += ((EIF_INTEGER_32) 2L);
				break;
			case 1U:
			case 2U:
			case 3U:
			case 10U:
			case 11U:
			case 13U:
			case 14U:
				loc1++;
				break;
			case 16U:
				loc1++;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tu4_3 = F1467_14896(RTCW(tr1), loc1);
				loc2 = (EIF_INTEGER_32) tu4_3;
				loc4 += loc2;
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc2) + ((EIF_INTEGER_32) 1L));
				break;
			case 26U:
			case 44U:
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tu4_3 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
				ti4_1 = (EIF_INTEGER_32) tu4_3;
				loc4 += ti4_1;
				loc1 += ((EIF_INTEGER_32) 3L);
				break;
			case 4U:
			case 5U:
			case 6U:
			case 7U:
			case 8U:
			case 9U:
			case 15U:
				loc4++;
				loc1++;
				break;
			case 53U:
				loc1 += ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tu4_3 = F1467_14894(RTCW(tr1), loc1);
				switch (tu4_3) {
					case 45U:
					case 46U:
					case 49U:
					case 50U:
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						break;
					case 51U:
					case 52U:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_3 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						loc2 = (EIF_INTEGER_32) tu4_3;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_3 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
						ti4_1 = (EIF_INTEGER_32) tu4_3;
						if ((EIF_BOOLEAN)(loc2 != ti4_1)) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							loc4 += loc2;
							loc1 += ((EIF_INTEGER_32) 3L);
						}
						break;
					default:
						loc4++;
						break;
				}
				break;
			default:
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				break;
		}
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_COMPILER}.compile_regexp */
void F1570_16370 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_INTEGER_64 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_64 loc4 = (EIF_INTEGER_64) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc7 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc8 = (EIF_NATURAL_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc7 = (EIF_NATURAL_32) arg1;
	loc8 = F1570_16354(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
	loc2 = (EIF_INTEGER_32) loc1;
	*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_) = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) -1L);
	ti4_1 = RTOSCF(16389,F1570_16389, (Current));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_11_) = (EIF_INTEGER_32) ti4_1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1467_14908(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
	if ((EIF_BOOLEAN) (arg4 >= (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 67U));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tu4_1 = (EIF_NATURAL_32) arg4;
		F1467_14908(RTCW(tr1), tu4_1);
	}
	for (;;) {
		if (loc9) break;
		if ((EIF_BOOLEAN) !F122_1883(Current, loc7)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 12U));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1467_14908(RTCW(tr1), loc7);
			F1570_16334(Current, loc7);
		}
		if (arg3) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 64U));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1467_14908(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
		}
		loc4 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_);
		loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_11_);
		*(EIF_NATURAL_32 *)(Current+ _LNGOFF_12_16_0_0_) = (EIF_NATURAL_32) loc7;
		F1570_16371(Current, arg2);
		loc7 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_12_16_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		if ((EIF_BOOLEAN)(tr1 == RTOSCF(1934,F123_1934, (Current)))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
			loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 - loc1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tu4_1 = (EIF_NATURAL_32) loc6;
			F1467_14905(RTCW(tr1), tu4_1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			if ((EIF_BOOLEAN)(loc4 != (EIF_INTEGER_64) ((EIF_INTEGER_32) -2L))) {
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_) >= (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
					if ((EIF_BOOLEAN)(loc4 == (EIF_INTEGER_64) ((EIF_INTEGER_32) -1L))) {
						loc4 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_);
					} else {
						if ((EIF_BOOLEAN)(loc4 != *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_))) {
							loc4 = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) -2L);
						}
					}
				} else {
					loc4 = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) -2L);
				}
			}
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_11_) < loc5)) {
				loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_11_);
			}
			*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_) = (EIF_INTEGER_64) loc4;
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_11_) = (EIF_INTEGER_32) loc5;
			if (arg3) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 0U));
				loc6 = F1570_16369(Current, loc1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_2_0_0_0_);
				F1467_14902(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
				if ((EIF_BOOLEAN) (loc6 < ((EIF_INTEGER_32) 0L))) {
					tr1 = RTOSCF(1922,F123_1922, (Current));
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
					F1570_16342(Current, tr1, ((EIF_INTEGER_32) 25L), ti4_1);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_1 = (EIF_NATURAL_32) loc6;
					F1467_14905(RTCW(tr1), tu4_1, loc3);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tu4_1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
			if ((EIF_BOOLEAN)(tu4_1 != ((EIF_NATURAL_32) 124U))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
				loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 - loc2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 57U));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tu4_1 = (EIF_NATURAL_32) loc6;
				F1467_14908(RTCW(tr1), tu4_1);
				tb1 = '\0';
				if (arg2) {
					tb1 = (EIF_BOOLEAN) !F122_1883(Current, loc7);
				}
				if (tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 12U));
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					F1467_14908(RTCW(tr1), loc8);
				}
				loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 56U));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1467_14908(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
			}
		} else {
			loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTLE;
}

/* {RX_PCRE_COMPILER}.compile_branch */
void F1570_16371 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_64 loc4 = (EIF_INTEGER_64) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_64 loc9 = (EIF_INTEGER_64) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_64 loc11 = (EIF_INTEGER_64) 0;
	EIF_INTEGER_64 loc12 = (EIF_INTEGER_64) 0;
	EIF_INTEGER_64 loc13 = (EIF_INTEGER_64) 0;
	EIF_INTEGER_32 loc14 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc15 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc16 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc17 = (EIF_NATURAL_32) 0;
	EIF_BOOLEAN loc18 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc19 = (EIF_BOOLEAN) 0;
	EIF_NATURAL_32 loc20 = (EIF_NATURAL_32) 0;
	EIF_BOOLEAN loc21 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc22 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_64 ti8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_) = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_11_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc12 = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) -1L);
	loc17 = F1570_16354(Current);
	loc18 = *(EIF_BOOLEAN *)(Current+ _CHROFF_12_1_);
	loc19 = *(EIF_BOOLEAN *)(Current+ _CHROFF_12_2_);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_1_)) {
		F1570_16381(Current);
	}
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc21 || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_8_)))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			tb1 = (EIF_BOOLEAN)(tr1 != RTOSCF(1934,F123_1934, (Current)));
		}
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc20 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
		tb2 = '\0';
		if ((EIF_BOOLEAN)(loc20 == ((EIF_NATURAL_32) 123U))) {
			tb2 = F1570_16375(Current, loc6, loc12, loc10);
		}
		if (tb2) {
			loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		} else {
			switch (loc20) {
				case 41U:
				case 124U:
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))--;
					loc21 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					break;
				case 94U:
					loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 13U));
					break;
				case 36U:
					loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 14U));
					break;
				case 46U:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 15U));
					break;
				case 91U:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
					F1570_16372(Current);
					break;
				case 42U:
					F1570_16373(Current, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) -1L), loc6, loc12, loc10);
					loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					break;
				case 43U:
					F1570_16373(Current, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) -1L), loc6, loc12, loc10);
					loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					break;
				case 63U:
					F1570_16373(Current, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), loc6, loc12, loc10);
					loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					break;
				case 40U:
					loc16 = F1570_16354(Current);
					loc15 = (EIF_NATURAL_32) loc16;
					loc9 = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) -1L);
					loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					tu4_1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
					if ((EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 63U))) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						tu4_1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
						switch (tu4_1) {
							case 35U:
								loc8 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
								loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
								for (;;) {
									tb2 = '\01';
									if (!(EIF_BOOLEAN) (loc8 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_8_))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
										tu4_1 = F1134_9997(RTCW(tr1), loc8);
										tb2 = (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 41U));
									}
									if (tb2) break;
									loc8++;
								}
								if ((EIF_BOOLEAN) (loc8 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_8_))) {
									*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 - ((EIF_INTEGER_32) 1L));
									tr1 = RTOSCF(1919,F123_1919, (Current));
									F1570_16342(Current, tr1, ((EIF_INTEGER_32) 18L), loc8);
								} else {
									*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) = (EIF_INTEGER_32) loc8;
								}
								break;
							case 58U:
								loc1 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 70U);
								loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
								break;
							case 40U:
								loc1 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 66U);
								loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								tu4_1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
								switch (tu4_1) {
									case 48U:
									case 49U:
									case 50U:
									case 51U:
									case 52U:
									case 53U:
									case 54U:
									case 55U:
									case 56U:
									case 57U:
										tu4_1 = F1570_16378(Current, ((EIF_INTEGER_32) 10L));
										ti4_1 = (EIF_INTEGER_32) tu4_1;
										loc9 = (EIF_INTEGER_64) ti4_1;
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
										tu4_1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
										if ((EIF_BOOLEAN)(tu4_1 != ((EIF_NATURAL_32) 41U))) {
											tr1 = RTOSCF(1923,F123_1923, (Current));
											ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
											F1570_16342(Current, tr1, ((EIF_INTEGER_32) 26L), ti4_1);
										}
										if ((EIF_BOOLEAN)(loc9 == (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
											tr1 = RTOSCF(1928,F123_1928, (Current));
											ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
											F1570_16342(Current, tr1, ((EIF_INTEGER_32) 35L), ti4_1);
										} else {
											(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
										}
										break;
									default:
										loc8 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
										tu4_1 = F1134_9997(RTCW(tr1), loc8);
										if ((EIF_BOOLEAN)(tu4_1 != ((EIF_NATURAL_32) 63U))) {
											tr1 = RTOSCF(1925,F123_1925, (Current));
											ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
											F1570_16342(Current, tr1, ((EIF_INTEGER_32) 28L), ti4_1);
										} else {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
											tu4_1 = F1134_9997(RTCW(tr1), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
											switch (tu4_1) {
												case 33U:
												case 60U:
												case 61U:
													break;
												default:
													tr1 = RTOSCF(1925,F123_1925, (Current));
													ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
													F1570_16342(Current, tr1, ((EIF_INTEGER_32) 28L), ti4_1);
													break;
											}
										}
										*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 - ((EIF_INTEGER_32) 1L));
										break;
								}
								break;
							case 61U:
								loc1 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 60U);
								loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
								break;
							case 33U:
								loc1 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 61U);
								loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
								break;
							case 60U:
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								tu4_1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
								switch (tu4_1) {
									case 61U:
										loc1 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 62U);
										loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
										(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
										break;
									case 33U:
										loc1 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 63U);
										loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
										(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
										break;
									default:
										tr1 = RTOSCF(1921,F123_1921, (Current));
										ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
										F1570_16342(Current, tr1, ((EIF_INTEGER_32) 24L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 3L)));
										break;
								}
								break;
							case 62U:
								loc1 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 65U);
								loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
								break;
							case 82U:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 55U));
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
								break;
							default:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								loc20 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
								loc22 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								for (;;) {
									tb3 = '\01';
									if (!(EIF_BOOLEAN) ((EIF_BOOLEAN)(loc20 == ((EIF_NATURAL_32) 41U)) || (EIF_BOOLEAN)(loc20 == ((EIF_NATURAL_32) 58U)))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
										tb3 = (EIF_BOOLEAN)(tr1 != RTOSCF(1934,F123_1934, (Current)));
									}
									if (tb3) break;
									switch (loc20) {
										case 45U:
											loc22 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc22;
											break;
										case 105U:
											if (loc22) {
												tu4_1 = F122_1885(Current, loc15);
												loc15 = (EIF_NATURAL_32) tu4_1;
											} else {
												tu4_1 = F122_1886(Current, loc15);
												loc15 = (EIF_NATURAL_32) tu4_1;
											}
											break;
										case 109U:
											if (loc22) {
												tu4_1 = F122_1887(Current, loc15);
												loc15 = (EIF_NATURAL_32) tu4_1;
											} else {
												tu4_1 = F122_1888(Current, loc15);
												loc15 = (EIF_NATURAL_32) tu4_1;
											}
											break;
										case 115U:
											if (loc22) {
												tu4_1 = F122_1889(Current, loc15);
												loc15 = (EIF_NATURAL_32) tu4_1;
											} else {
												tu4_1 = F122_1890(Current, loc15);
												loc15 = (EIF_NATURAL_32) tu4_1;
											}
											break;
										case 120U:
											*(EIF_BOOLEAN *)(Current+ _CHROFF_12_1_) = (EIF_BOOLEAN) loc22;
											break;
										case 88U:
											*(EIF_BOOLEAN *)(Current+ _CHROFF_12_10_) = (EIF_BOOLEAN) loc22;
											break;
										case 85U:
											*(EIF_BOOLEAN *)(Current+ _CHROFF_12_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc22;
											break;
										default:
											tr1 = RTOSCF(1915,F123_1915, (Current));
											ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
											F1570_16342(Current, tr1, ((EIF_INTEGER_32) 12L), ti4_1);
											break;
									}
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
									if ((EIF_BOOLEAN)(tr1 != RTOSCF(1934,F123_1934, (Current)))) {
										loc20 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
									} else {
										(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
										loc20 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
									}
								}
								if ((EIF_BOOLEAN)(loc20 == ((EIF_NATURAL_32) 41U))) {
									if (arg1) {
										if ((EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_12_0_) != F122_1878(Current, loc15))) {
											F1570_16357(Current, (EIF_BOOLEAN) 1);
										}
										if ((EIF_BOOLEAN)(F122_1897(Current, loc16) != loc15)) {
											*(EIF_NATURAL_32 *)(Current+ _LNGOFF_12_16_0_0_) = (EIF_NATURAL_32) loc15;
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 12U));
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											F1467_14908(RTCW(tr1), *(EIF_NATURAL_32 *)(Current+ _LNGOFF_12_16_0_0_));
										}
									} else {
										loc19 = *(EIF_BOOLEAN *)(Current+ _CHROFF_12_2_);
										loc18 = *(EIF_BOOLEAN *)(Current+ _CHROFF_12_1_);
										loc17 = (EIF_NATURAL_32) loc15;
									}
									F1570_16334(Current, loc15);
									loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								} else {
									loc1 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 70U);
									loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
									if ((EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_12_0_) != F122_1878(Current, loc15))) {
										F1570_16357(Current, (EIF_BOOLEAN) 1);
									}
								}
								break;
						}
					} else {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_9_))++;
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_9_) > ((EIF_INTEGER_32) 99L))) {
							tr1 = RTOSCF(1916,F123_1916, (Current));
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
							F1570_16342(Current, tr1, ((EIF_INTEGER_32) 13L), ti4_1);
						} else {
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_9_);
							loc1 = (EIF_NATURAL_32) ti4_1;
							loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) (((EIF_NATURAL_32) 70U) + loc1);
							loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						}
					}
					if (loc2) {
						if ((EIF_BOOLEAN) (loc1 >= ((EIF_NATURAL_32) 65U))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
						} else {
							loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						}
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						loc7 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						F1467_14906(RTCW(tr1), loc1);
						loc13 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_);
						loc14 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_11_);
						if ((EIF_BOOLEAN)(F122_1897(Current, loc16) == loc15)) {
							loc16 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 32U);
						} else {
							loc16 = (EIF_NATURAL_32) loc15;
						}
						F1570_16370(Current, loc16, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 62U)) || (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 63U))), loc9);
						loc10 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_11_);
						loc11 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_11_) = (EIF_INTEGER_32) loc14;
						*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_) = (EIF_INTEGER_64) loc13;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						if ((EIF_BOOLEAN)(tr1 == RTOSCF(1934,F123_1934, (Current)))) {
							if ((EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 66U))) {
								loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L)));
								loc8 = (EIF_INTEGER_32) tu4_1;
								loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 + loc8);
								for (;;) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tu4_1 = F1467_14894(RTCW(tr1), loc8);
									if ((EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 57U))) break;
									loc5++;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
									ti4_1 = (EIF_INTEGER_32) tu4_2;
									loc8 += ti4_1;
								}
								if ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 2L))) {
									tr1 = RTOSCF(1924,F123_1924, (Current));
									ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
									F1570_16342(Current, tr1, ((EIF_INTEGER_32) 27L), ti4_1);
								}
							}
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc11 > (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 >= ((EIF_NATURAL_32) 70U)) || (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 65U))) || (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 60U))) || (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 66U)) && (EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 2L)))))) {
								loc12 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_);
								*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_) = (EIF_INTEGER_64) loc11;
								if ((EIF_BOOLEAN)(loc1 != ((EIF_NATURAL_32) 60U))) {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_11_)) += loc10;
								}
							}
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
							tu4_2 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
							if ((EIF_BOOLEAN)(tu4_2 != ((EIF_NATURAL_32) 41U))) {
								tr1 = RTOSCF(1917,F123_1917, (Current));
								ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
								F1570_16342(Current, tr1, ((EIF_INTEGER_32) 14L), ti4_1);
							}
						}
					}
					break;
				default:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 16U));
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					loc7 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					F1467_14908(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
					loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					loc20 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
					loc22 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					for (;;) {
						if (loc22) break;
						if ((EIF_BOOLEAN)(loc20 == ((EIF_NATURAL_32) 92U))) {
							loc4 = F1570_16382(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_9_), (EIF_BOOLEAN) 0);
							if ((EIF_BOOLEAN) (loc4 < (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
								if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									F1467_14902(RTCW(tr1), loc6);
								} else {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
								}
								if ((EIF_BOOLEAN) ((EIF_INTEGER_64) -loc4 >= ((EIF_INTEGER_64) RTI64C(12)))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 54U));
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tu4_2 = (EIF_NATURAL_32) (EIF_INTEGER_64) ((EIF_INTEGER_64) -loc4 - ((EIF_INTEGER_64) RTI64C(12)));
									F1467_14908(RTCW(tr1), tu4_2);
								} else {
									if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_64) -loc4 <= ((EIF_INTEGER_64) RTI64C(3))) || (EIF_BOOLEAN) ((EIF_INTEGER_64) -loc4 >= ((EIF_INTEGER_64) RTI64C(10))))) {
										loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
									}
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tu4_2 = (EIF_NATURAL_32) (EIF_INTEGER_64) -loc4;
									F1467_14906(RTCW(tr1), tu4_2);
								}
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
								loc22 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								loc20 = (EIF_NATURAL_32) loc4;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								F1467_14907(RTCW(tr1), loc20);
								loc3++;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
								tr2 = RTOSCF(1934,F123_1934, (Current));
								loc22 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != tr2);
							}
						} else {
							tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
							if (F1566_16111(RTCW(tr1), loc20)) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								F1467_14907(RTCW(tr1), loc20);
								loc3++;
							} else {
								tr1 = RTOSCF(1929,F123_1929, (Current));
								ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
								F1570_16342(Current, tr1, ((EIF_INTEGER_32) 61L), ti4_1);
								loc22 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							}
						}
						if ((EIF_BOOLEAN) !loc22) {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
							if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_1_)) {
								F1570_16381(Current);
							}
							tb4 = '\01';
							if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_8_))) {
								tb4 = (EIF_BOOLEAN) (loc3 >= RTOSCF(16390,F1570_16390, (Current)));
							}
							if (tb4) {
								loc22 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								loc20 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
								tr1 = RTOSCF(1874,F121_1874, (Current));
								loc22 = F30_209(RTCW(tr1), loc20);
							}
						}
					}
					if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
						if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 1L))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tu4_2 = F1467_14895(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc7 + loc3) - ((EIF_INTEGER_32) 1L)));
							loc12 = (EIF_INTEGER_64) tu4_2;
						} else {
							loc12 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_);
						}
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_2 = F1467_14895(RTCW(tr1), (EIF_INTEGER_32) (loc7 + loc3));
						ti8_1 = (EIF_INTEGER_64) tu4_2;
						*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_) = (EIF_INTEGER_64) ti8_1;
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_11_)) += loc3;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_2 = (EIF_NATURAL_32) loc3;
						F1467_14905(RTCW(tr1), tu4_2, loc7);
					}
					if ((EIF_BOOLEAN) (loc3 <= RTOSCF(16390,F1570_16390, (Current)))) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))--;
					}
					break;
			}
		}
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_1_)) {
			F1570_16381(Current);
		}
	}
	F1570_16334(Current, loc17);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_1_) = (EIF_BOOLEAN) loc18;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_2_) = (EIF_BOOLEAN) loc19;
	RTLE;
}

/* {RX_PCRE_COMPILER}.compile_character_class */
void F1570_16372 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_64 loc4 = (EIF_INTEGER_64) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_64 loc6 = (EIF_INTEGER_64) 0;
	EIF_NATURAL_32 loc7 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc8 = (EIF_NATURAL_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(29, 0x01).id, 29, _OBJSIZ_1_3_0_0_0_0_4_0_);
	F30_205(RTCW(loc1));
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc7 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
	if ((EIF_BOOLEAN)(loc7 == ((EIF_NATURAL_32) 94U))) {
		loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc7 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
	}
	loc5 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		tb1 = '\01';
		if (!((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc5 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(loc7 == ((EIF_NATURAL_32) 93U))))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			tb1 = (EIF_BOOLEAN)(tr1 != RTOSCF(1934,F123_1934, (Current)));
		}
		if (tb1) break;
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_8_))) {
			tr1 = RTOSCF(1910,F123_1910, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
			F1570_16342(Current, tr1, ((EIF_INTEGER_32) 6L), ti4_1);
		} else {
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			if ((EIF_BOOLEAN)(loc7 == ((EIF_NATURAL_32) 91U))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				tu4_1 = F1134_9997(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) + ((EIF_INTEGER_32) 1L)));
				switch (tu4_1) {
					case 46U:
					case 58U:
					case 61U:
						loc2 = F1570_16376(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
						break;
				}
			}
			if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
				loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				tu4_1 = F1134_9997(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) + ((EIF_INTEGER_32) 1L)));
				if ((EIF_BOOLEAN)(tu4_1 != ((EIF_NATURAL_32) 58U))) {
					tr1 = RTOSCF(1927,F123_1927, (Current));
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
					F1570_16342(Current, tr1, ((EIF_INTEGER_32) 31L), ti4_1);
				} else {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_)) += ((EIF_INTEGER_32) 2L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					tu4_1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
					if ((EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 94U))) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
					loc3 = F1570_16377(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_), (EIF_INTEGER_32) (loc2 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_)));
					if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) {
						tr1 = RTOSCF(1926,F123_1926, (Current));
						ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
						F1570_16342(Current, tr1, ((EIF_INTEGER_32) 30L), ti4_1);
					} else {
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 <= ((EIF_INTEGER_32) 3L)) && *(EIF_BOOLEAN *)(Current+ _CHROFF_12_0_))) {
							loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						}
						if (loc10) {
							tr1 = RTOSCF(1876,F121_1876, (Current));
							tr1 = F700_6207(RTCW(tr1), loc3);
							F30_215(RTCW(loc1), tr1);
						} else {
							tr1 = RTOSCF(1876,F121_1876, (Current));
							tr1 = F700_6207(RTCW(tr1), loc3);
							F30_214(RTCW(loc1), tr1);
						}
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
						loc5 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 10L);
					}
				}
			} else {
				loc4 = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L);
				if ((EIF_BOOLEAN)(loc7 == ((EIF_NATURAL_32) 92U))) {
					loc4 = F1570_16382(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_9_), (EIF_BOOLEAN) 1);
					if ((EIF_BOOLEAN)((EIF_INTEGER_64) -loc4 == ((EIF_INTEGER_64) RTI64C(3)))) {
						loc7 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 8U);
						loc4 = (EIF_INTEGER_64) loc7;
					} else {
						if ((EIF_BOOLEAN) (loc4 < (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
							loc5 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
							loc6 = (EIF_INTEGER_64) loc4;
							switch ((EIF_INTEGER_64) -loc4) {
								case RTI64C(5):
									tr1 = RTOSCF(1865,F121_1865, (Current));
									F30_214(RTCW(loc1), tr1);
									break;
								case RTI64C(4):
									tr1 = RTOSCF(1865,F121_1865, (Current));
									F30_215(RTCW(loc1), tr1);
									break;
								case RTI64C(9):
									F30_214(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_4_));
									break;
								case RTI64C(8):
									F30_215(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_4_));
									break;
								case RTI64C(7):
									tr1 = RTOSCF(1873,F121_1873, (Current));
									F30_214(RTCW(loc1), tr1);
									break;
								case RTI64C(6):
									tr1 = RTOSCF(1873,F121_1873, (Current));
									F30_215(RTCW(loc1), tr1);
									break;
								default:
									tr1 = RTOSCF(1911,F123_1911, (Current));
									ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
									F1570_16342(Current, tr1, ((EIF_INTEGER_32) 7L), ti4_1);
									break;
							}
						} else {
							loc7 = (EIF_NATURAL_32) loc4;
						}
					}
				} else {
					tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
					if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), loc7)) {
						tr1 = RTOSCF(1929,F123_1929, (Current));
						ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
						F1570_16342(Current, tr1, ((EIF_INTEGER_32) 61L), ti4_1);
						loc7 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
					}
				}
				if ((EIF_BOOLEAN) (loc4 >= (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
					tb2 = '\0';
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					tu4_1 = F1134_9997(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) + ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 45U))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						tu4_1 = F1134_9997(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) + ((EIF_INTEGER_32) 2L)));
						tb2 = (EIF_BOOLEAN)(tu4_1 != ((EIF_NATURAL_32) 93U));
					}
					if (tb2) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_)) += ((EIF_INTEGER_32) 2L);
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_8_))) {
							tr1 = RTOSCF(1910,F123_1910, (Current));
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
							F1570_16342(Current, tr1, ((EIF_INTEGER_32) 6L), ti4_1);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
							loc8 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
							loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
							if ((EIF_BOOLEAN)(loc8 == ((EIF_NATURAL_32) 92U))) {
								loc4 = F1570_16382(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_9_), (EIF_BOOLEAN) 1);
								if ((EIF_BOOLEAN) (loc4 < (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
									if ((EIF_BOOLEAN)(loc4 == (EIF_INTEGER_64) -((EIF_INTEGER_64) RTI64C(3)))) {
										loc8 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 8U);
									} else {
										*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 2L));
										loc8 = (EIF_NATURAL_32) loc7;
									}
								} else {
									loc8 = (EIF_NATURAL_32) loc4;
								}
							} else {
								tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
								if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), loc8)) {
									tr1 = RTOSCF(1929,F123_1929, (Current));
									ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
									F1570_16342(Current, tr1, ((EIF_INTEGER_32) 61L), ti4_1);
									loc8 = (EIF_NATURAL_32) loc7;
								}
							}
							if ((EIF_BOOLEAN) (loc8 < loc7)) {
								tr1 = RTOSCF(1912,F123_1912, (Current));
								ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
								F1570_16342(Current, tr1, ((EIF_INTEGER_32) 8L), ti4_1);
							} else {
								loc5 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc5 + loc8) - loc7) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L));
								loc6 = (EIF_INTEGER_64) loc8;
								for (;;) {
									if ((EIF_BOOLEAN) (loc7 > loc8)) break;
									tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
									if (F1566_16111(RTCW(tr1), loc7)) {
										F30_213(RTCW(loc1), loc7);
										if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_0_)) {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
											tu4_1 = F1557_15809(RTCW(tr1), loc7);
											F30_213(RTCW(loc1), tu4_1);
										}
									}
									loc7 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
								}
							}
						}
					} else {
						F30_213(RTCW(loc1), loc7);
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_0_)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
							tu4_1 = F1557_15809(RTCW(tr1), loc7);
							F30_213(RTCW(loc1), tu4_1);
						}
						loc5 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
						loc6 = (EIF_INTEGER_64) loc7;
					}
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		if ((EIF_BOOLEAN)(tr1 == RTOSCF(1934,F123_1934, (Current)))) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			loc7 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
		}
	}
	if ((EIF_BOOLEAN)(loc5 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L))) {
		if ((EIF_BOOLEAN) (loc6 < (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
			if (loc9) {
				if ((EIF_BOOLEAN)((EIF_INTEGER_64) ((EIF_INTEGER_64) -loc6 % (EIF_INTEGER_64) ((EIF_INTEGER_32) 2L)) == (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_1 = (EIF_NATURAL_32) ((EIF_INTEGER_64) ((EIF_INTEGER_64) -loc6 + (EIF_INTEGER_64) ((EIF_INTEGER_32) 1L)));
					F1467_14906(RTCW(tr1), tu4_1);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_1 = (EIF_NATURAL_32) ((EIF_INTEGER_64) ((EIF_INTEGER_64) -loc6 - (EIF_INTEGER_64) ((EIF_INTEGER_32) 1L)));
					F1467_14906(RTCW(tr1), tu4_1);
				}
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tu4_1 = (EIF_NATURAL_32) (EIF_INTEGER_64) -loc6;
				F1467_14906(RTCW(tr1), tu4_1);
			}
		} else {
			if (loc9) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 17U));
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 16U));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1467_14908(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L));
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tu4_1 = (EIF_NATURAL_32) loc6;
			F1467_14907(RTCW(tr1), tu4_1);
		}
	} else {
		F30_211(RTCW(loc1), loc9);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 53U));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1467_14909(RTCW(tr1), loc1);
	}
	RTLE;
}

/* {RX_PCRE_COMPILER}.compile_repeats */
void F1570_16373 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_64 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc13 = (EIF_NATURAL_32) 0;
	EIF_BOOLEAN loc14 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc15 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc14 = *(EIF_BOOLEAN *)(Current+ _CHROFF_12_2_);
	loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc14;
	loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc14;
	loc3 = (EIF_INTEGER_32) arg1;
	loc4 = (EIF_INTEGER_32) arg2;
	loc8 = (EIF_INTEGER_32) arg3;
	if ((EIF_BOOLEAN)(loc8 == ((EIF_INTEGER_32) 0L))) {
		tr1 = RTOSCF(1913,F123_1913, (Current));
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
		F1570_16342(Current, tr1, ((EIF_INTEGER_32) 9L), ti4_1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tu4_1 = F1134_9997(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) + ((EIF_INTEGER_32) 1L)));
		if ((EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 63U))) {
			if (loc15) {
				loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
			} else {
				loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
			}
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
		} else {
			if (loc14) {
				loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
			} else {
				loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc5 = F1467_14894(RTCW(tr1), loc8);
		if ((EIF_BOOLEAN)(loc5 == ((EIF_NATURAL_32) 16U))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
			loc7 = (EIF_INTEGER_32) tu4_1;
			if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
				*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_) = (EIF_INTEGER_64) arg4;
			}
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_11_) = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_11_) + loc3) - ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 1L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc13 = F1467_14895(RTCW(tr1), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 2L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1467_14902(RTCW(tr1), loc8);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc13 = F1467_14895(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc8 + loc7) + ((EIF_INTEGER_32) 1L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tu4_1 = F1467_14896(RTCW(tr2), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
				F1467_14905(RTCW(tr1), (EIF_NATURAL_32) (tu4_1 - (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_2_0_0_0_);
				F1467_14902(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
			}
			loc2 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
			if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
				F1570_16374(Current, loc13, loc8, loc3, loc4, loc2, loc1);
			}
		} else {
			if ((EIF_BOOLEAN)(loc5 == ((EIF_NATURAL_32) 17U))) {
				loc2 = (EIF_NATURAL_32) (EIF_NATURAL_32) (((EIF_NATURAL_32) 27U) - ((EIF_NATURAL_32) 18U));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc13 = F1467_14895(RTCW(tr1), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1467_14902(RTCW(tr1), loc8);
				if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
					F1570_16374(Current, loc13, loc8, loc3, loc4, loc2, loc1);
				}
			} else {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc5 < ((EIF_NATURAL_32) 10U)) || (EIF_BOOLEAN)(loc5 == ((EIF_NATURAL_32) 15U)))) {
					loc2 = (EIF_NATURAL_32) (EIF_NATURAL_32) (((EIF_NATURAL_32) 36U) - ((EIF_NATURAL_32) 18U));
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					loc13 = F1467_14895(RTCW(tr1), loc8);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					F1467_14902(RTCW(tr1), loc8);
					if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
						F1570_16374(Current, loc13, loc8, loc3, loc4, loc2, loc1);
					}
				} else {
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 == ((EIF_NATURAL_32) 53U)) || (EIF_BOOLEAN)(loc5 == ((EIF_NATURAL_32) 54U)))) {
						if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							F1467_14902(RTCW(tr1), loc8);
						} else {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L)))) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								F1467_14906(RTCW(tr1), (EIF_NATURAL_32) (((EIF_NATURAL_32) 45U) + loc1));
							} else {
								if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L)))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									F1467_14906(RTCW(tr1), (EIF_NATURAL_32) (((EIF_NATURAL_32) 47U) + loc1));
								} else {
									if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 1L)))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										F1467_14906(RTCW(tr1), (EIF_NATURAL_32) (((EIF_NATURAL_32) 49U) + loc1));
									} else {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										F1467_14906(RTCW(tr1), (EIF_NATURAL_32) (((EIF_NATURAL_32) 51U) + loc1));
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tu4_1 = (EIF_NATURAL_32) loc3;
										F1467_14908(RTCW(tr1), tu4_1);
										if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L))) {
											loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											F1467_14908(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
										} else {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tu4_1 = (EIF_NATURAL_32) loc4;
											F1467_14908(RTCW(tr1), tu4_1);
										}
									}
								}
							}
						}
					} else {
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc5 >= ((EIF_NATURAL_32) 70U)) || (EIF_BOOLEAN)(loc5 == ((EIF_NATURAL_32) 65U))) || (EIF_BOOLEAN)(loc5 == ((EIF_NATURAL_32) 66U)))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							loc7 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
							loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 - loc8);
							if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L))) {
								loc6 = (EIF_INTEGER_32) loc8;
								for (;;) {
									if ((EIF_BOOLEAN)(loc5 == ((EIF_NATURAL_32) 57U))) break;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)));
									ti4_1 = (EIF_INTEGER_32) tu4_1;
									loc6 += ti4_1;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									loc5 = F1467_14894(RTCW(tr1), loc6);
								}
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								loc9 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
								loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 - loc6);
							}
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
								if ((EIF_BOOLEAN) (arg5 > ((EIF_INTEGER_32) 0L))) {
									*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_) = (EIF_INTEGER_64) arg4;
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_11_)) -= arg5;
								}
								if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									F1467_14902(RTCW(tr1), loc8);
								} else {
									if ((EIF_BOOLEAN) (loc4 <= ((EIF_INTEGER_32) 1L))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										F1467_14911(RTCW(tr1), loc8, ((EIF_INTEGER_32) 1L));
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										F1467_14903(RTCW(tr1), (EIF_NATURAL_32) (((EIF_NATURAL_32) 68U) + loc1), loc8);
										loc8++;
									} else {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										F1467_14911(RTCW(tr1), loc8, ((EIF_INTEGER_32) 3L));
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										F1467_14903(RTCW(tr1), (EIF_NATURAL_32) (((EIF_NATURAL_32) 68U) + loc1), loc8);
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										F1467_14903(RTCW(tr1), ((EIF_NATURAL_32) 70U), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
										loc8 += ((EIF_INTEGER_32) 2L);
										if ((EIF_BOOLEAN)(loc12 == ((EIF_INTEGER_32) 0L))) {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											F1467_14905(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L), loc8);
										} else {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tu4_1 = (EIF_NATURAL_32) (EIF_INTEGER_32) (loc8 - loc12);
											F1467_14905(RTCW(tr1), tu4_1, loc8);
										}
										loc12 = (EIF_INTEGER_32) loc8;
										loc8++;
									}
									loc4--;
								}
							} else {
								loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								for (;;) {
									if ((EIF_BOOLEAN) (loc6 >= loc3)) break;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									F1467_14910(RTCW(tr1), loc8, loc7);
									loc6++;
								}
								if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
									loc4 -= loc3;
								}
							}
							if ((EIF_BOOLEAN) (loc4 >= ((EIF_INTEGER_32) 0L))) {
								loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L));
								for (;;) {
									if ((EIF_BOOLEAN) (loc6 < ((EIF_INTEGER_32) 0L))) break;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									F1467_14906(RTCW(tr1), (EIF_NATURAL_32) (((EIF_NATURAL_32) 68U) + loc1));
									if ((EIF_BOOLEAN)(loc6 != ((EIF_INTEGER_32) 0L))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 70U));
										if ((EIF_BOOLEAN)(loc12 == ((EIF_INTEGER_32) 0L))) {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											loc12 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											F1467_14908(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
										} else {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											loc10 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
											loc10 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc10 - loc12);
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											loc12 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tu4_1 = (EIF_NATURAL_32) loc10;
											F1467_14908(RTCW(tr1), tu4_1);
										}
									}
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									F1467_14910(RTCW(tr1), loc8, loc7);
									loc6--;
								}
								for (;;) {
									if ((EIF_BOOLEAN)(loc12 == ((EIF_INTEGER_32) 0L))) break;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									loc10 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
									loc10 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc10 - loc12) + ((EIF_INTEGER_32) 1L));
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
									loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 - loc10) + ((EIF_INTEGER_32) 1L));
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tu4_1 = F1467_14896(RTCW(tr1), loc6);
									loc11 = (EIF_INTEGER_32) tu4_1;
									if ((EIF_BOOLEAN)(loc11 == ((EIF_INTEGER_32) 0L))) {
										loc12 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
									} else {
										loc12 -= loc11;
									}
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									F1467_14906(RTCW(tr1), ((EIF_NATURAL_32) 57U));
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tu4_1 = (EIF_NATURAL_32) loc10;
									F1467_14908(RTCW(tr1), tu4_1);
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tu4_1 = (EIF_NATURAL_32) loc10;
									F1467_14905(RTCW(tr1), tu4_1, loc6);
								}
							} else {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_2_0_0_0_);
								F1467_14903(RTCW(tr1), (EIF_NATURAL_32) (((EIF_NATURAL_32) 58U) + loc1), (EIF_INTEGER_32) (ti4_1 - loc9));
							}
						} else {
							tr1 = RTOSCF(1914,F123_1914, (Current));
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
							F1570_16342(Current, tr1, ((EIF_INTEGER_32) 11L), ti4_1);
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {RX_PCRE_COMPILER}.compile_single_repeat */
void F1570_16374 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_NATURAL_32 arg5, EIF_NATURAL_32 arg6)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) (arg6 + arg5);
	if ((EIF_BOOLEAN)(arg3 == ((EIF_INTEGER_32) 0L))) {
		if ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) -1L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1467_14906(RTCW(tr1), (EIF_NATURAL_32) (((EIF_NATURAL_32) 18U) + loc1));
		} else {
			if ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 1L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1467_14906(RTCW(tr1), (EIF_NATURAL_32) (((EIF_NATURAL_32) 22U) + loc1));
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1467_14906(RTCW(tr1), (EIF_NATURAL_32) (((EIF_NATURAL_32) 24U) + loc1));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tu4_1 = (EIF_NATURAL_32) arg4;
				F1467_14908(RTCW(tr1), tu4_1);
			}
		}
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg3 == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) -1L)))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1467_14906(RTCW(tr1), (EIF_NATURAL_32) (((EIF_NATURAL_32) 20U) + loc1));
		} else {
			if ((EIF_BOOLEAN)(arg3 != ((EIF_INTEGER_32) 1L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1467_14906(RTCW(tr1), (EIF_NATURAL_32) (((EIF_NATURAL_32) 26U) + arg5));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tu4_1 = (EIF_NATURAL_32) arg3;
				F1467_14908(RTCW(tr1), tu4_1);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1467_14902(RTCW(tr1), (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tu4_1 = F1467_14894(RTCW(tr1), arg2);
				switch (tu4_1) {
					case 16U:
						if ((EIF_BOOLEAN)(loc2 == arg2)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							F1467_14902(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							F1467_14902(RTCW(tr1), loc2);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tu4_1 = F1467_14896(RTCW(tr2), (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
							F1467_14905(RTCW(tr1), (EIF_NATURAL_32) (tu4_1 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
						}
						break;
					case 17U:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						F1467_14902(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
						break;
					default:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						F1467_14902(RTCW(tr1), loc2);
						break;
				}
			}
			if ((EIF_BOOLEAN) (arg4 < ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1467_14907(RTCW(tr1), arg1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1467_14906(RTCW(tr1), (EIF_NATURAL_32) (((EIF_NATURAL_32) 18U) + loc1));
			} else {
				if ((EIF_BOOLEAN)(arg4 != arg3)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					F1467_14907(RTCW(tr1), arg1);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					F1467_14906(RTCW(tr1), (EIF_NATURAL_32) (((EIF_NATURAL_32) 24U) + loc1));
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_1 = (EIF_NATURAL_32) (EIF_INTEGER_32) (arg4 - arg3);
					F1467_14908(RTCW(tr1), tu4_1);
				}
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1467_14907(RTCW(tr1), arg1);
	RTLE;
}

/* {RX_PCRE_COMPILER}.compile_counted_repeats */
EIF_BOOLEAN F1570_16375 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_64 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc4 = F1134_9997(RTCW(tr1), loc3);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 < ((EIF_NATURAL_32) 48U)) || (EIF_BOOLEAN) (loc4 > ((EIF_NATURAL_32) 57U)))) {
			ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 65535U);
			tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
		}
		if (tb1) break;
		ti4_1 = (EIF_INTEGER_32) (EIF_NATURAL_32) (loc4 - ((EIF_NATURAL_32) 48U));
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 10L)) + ti4_1);
		loc3++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc4 = F1134_9997(RTCW(tr1), loc3);
	}
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 65535U);
	if ((EIF_BOOLEAN) (loc1 > ti4_1)) {
		tr1 = RTOSCF(1909,F123_1909, (Current));
		F1570_16342(Current, tr1, ((EIF_INTEGER_32) 5L), loc3);
	} else {
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_)) > ((EIF_INTEGER_32) 1L))) {
			if ((EIF_BOOLEAN)(loc4 == ((EIF_NATURAL_32) 125U))) {
				loc2 = (EIF_INTEGER_32) loc1;
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				if ((EIF_BOOLEAN)(loc4 == ((EIF_NATURAL_32) 44U))) {
					loc3++;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					loc4 = F1134_9997(RTCW(tr1), loc3);
					if ((EIF_BOOLEAN)(loc4 != ((EIF_NATURAL_32) 125U))) {
						loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						for (;;) {
							tb2 = '\01';
							if (!(EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 < ((EIF_NATURAL_32) 48U)) || (EIF_BOOLEAN) (loc4 > ((EIF_NATURAL_32) 57U)))) {
								ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 65535U);
								tb2 = (EIF_BOOLEAN) (loc2 > ti4_1);
							}
							if (tb2) break;
							ti4_1 = (EIF_INTEGER_32) (EIF_NATURAL_32) (loc4 - ((EIF_NATURAL_32) 48U));
							loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 * ((EIF_INTEGER_32) 10L)) + ti4_1);
							loc3++;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
							loc4 = F1134_9997(RTCW(tr1), loc3);
						}
					}
					if ((EIF_BOOLEAN)(loc4 == ((EIF_NATURAL_32) 125U))) {
						ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 65535U);
						if ((EIF_BOOLEAN) (loc2 > ti4_1)) {
							tr1 = RTOSCF(1909,F123_1909, (Current));
							F1570_16342(Current, tr1, ((EIF_INTEGER_32) 5L), loc3);
						} else {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc1 > loc2))) {
								tr1 = RTOSCF(1908,F123_1908, (Current));
								F1570_16342(Current, tr1, ((EIF_INTEGER_32) 4L), loc3);
							} else {
								Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							}
						}
					}
				}
			}
		}
	}
	if (Result) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) = (EIF_INTEGER_32) loc3;
		F1570_16373(Current, loc1, loc2, arg1, arg2, arg3);
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_COMPILER}.check_posix_syntax */
EIF_INTEGER_32 F1570_16376 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTOSCF(1864,F121_1864, (Current));
	loc2 = (EIF_INTEGER_32) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc3 = F1134_9997(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tu4_1 = F1134_9997(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
	if ((EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 94U))) {
		loc2 += ((EIF_INTEGER_32) 3L);
	} else {
		loc2 += ((EIF_INTEGER_32) 2L);
	}
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tu4_1 = F1134_9997(RTCW(tr1), loc2);
		tb1 = F30_209(RTCW(loc1), tu4_1);
		if ((EIF_BOOLEAN) !tb1) break;
		loc2++;
	}
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tu4_1 = F1134_9997(RTCW(tr1), loc2);
	if ((EIF_BOOLEAN)(tu4_1 == loc3)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tu4_1 = F1134_9997(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
		tb2 = (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 93U));
	}
	if (tb2) {
		RTLE;
		return (EIF_INTEGER_32) loc2;
	} else {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}/* NOTREACHED */
	
}

/* {RX_PCRE_COMPILER}.check_posix_name */
EIF_INTEGER_32 F1570_16377 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc4 = F700_6214(RTCV(RTOSCF(1875,F121_1875, (Current))));
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc4)) break;
		tr1 = RTOSCF(1875,F121_1875, (Current));
		loc5 = F700_6207(RTCW(tr1), loc1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(arg2 == ti4_1)) {
			Result = (EIF_INTEGER_32) loc1;
			loc3 = (EIF_INTEGER_32) arg1;
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc2 > arg2)) break;
				tu4_1 = F1137_10162(RTCW(loc5), loc2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				tu4_2 = F1134_9997(RTCW(tr1), loc3);
				if ((EIF_BOOLEAN)(tu4_1 != tu4_2)) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
				} else {
					loc2++;
					loc3++;
				}
			}
		}
		if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) -1L))) {
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
		} else {
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_COMPILER}.scan_decimal_number */
EIF_NATURAL_32 F1570_16378 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + arg1);
	loc3 = (EIF_NATURAL_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > ((EIF_NATURAL_32) 57U)) || (EIF_BOOLEAN) (loc1 < ((EIF_NATURAL_32) 48U))) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) >= loc2)) || (EIF_BOOLEAN) (Result > loc3))) break;
		Result = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (Result * (EIF_NATURAL_32) ((EIF_INTEGER_32) 10L)) + loc1) - ((EIF_NATURAL_32) 48U));
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
	}
	if ((EIF_BOOLEAN) (Result > loc3)) {
		tr1 = RTOSCF(1933,F123_1933, (Current));
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
		F1570_16342(Current, tr1, ((EIF_INTEGER_32) 65L), ti4_1);
		RTLE;
		return (EIF_NATURAL_32) loc3;
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_COMPILER}.scan_octal_number */
EIF_NATURAL_32 F1570_16379 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > ((EIF_NATURAL_32) 55U)) || (EIF_BOOLEAN) (loc1 < ((EIF_NATURAL_32) 48U))) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) >= loc2))) break;
		Result = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (Result * (EIF_NATURAL_32) ((EIF_INTEGER_32) 8L)) + loc1) - ((EIF_NATURAL_32) 48U));
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_COMPILER}.scan_hex_number */
EIF_NATURAL_32 F1570_16380 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
	for (;;) {
		tb1 = '\01';
		tr1 = RTOSCF(1867,F121_1867, (Current));
		tb2 = F30_209(RTCW(tr1), loc1);
		if (!(EIF_BOOLEAN) !tb2) {
			tb1 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) >= loc2);
		}
		if (tb1) break;
		if ((EIF_BOOLEAN) (loc1 < ((EIF_NATURAL_32) 65U))) {
			Result = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (Result * (EIF_NATURAL_32) ((EIF_INTEGER_32) 16L)) + loc1) - ((EIF_NATURAL_32) 48U));
		} else {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_NATURAL_32) 97U))) {
				Result = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_NATURAL_32) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (Result * (EIF_NATURAL_32) ((EIF_INTEGER_32) 16L)) + loc1) - ((EIF_NATURAL_32) 65U)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 10L));
			} else {
				Result = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_NATURAL_32) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (Result * (EIF_NATURAL_32) ((EIF_INTEGER_32) 16L)) + loc1) - ((EIF_NATURAL_32) 97U)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 10L));
			}
		}
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_COMPILER}.scan_comment */
void F1570_16381 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == loc2)) break;
		loc1 = (EIF_INTEGER_32) loc2;
		for (;;) {
			tr1 = RTOSCF(1873,F121_1873, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tu4_1 = F1134_9997(RTCW(tr2), loc2);
			tb1 = F30_209(RTCW(tr1), tu4_1);
			if ((EIF_BOOLEAN) !tb1) break;
			loc2++;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tu4_1 = F1134_9997(RTCW(tr1), loc2);
		if ((EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 35U))) {
			loc2++;
			for (;;) {
				tb2 = '\01';
				if (!(EIF_BOOLEAN) (loc2 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_8_))) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					tu4_1 = F1134_9997(RTCW(tr1), loc2);
					tb2 = (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 10U));
				}
				if (tb2) break;
				loc2++;
			}
		}
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) = (EIF_INTEGER_32) loc2;
	RTLE;
}

/* {RX_PCRE_COMPILER}.scan_escape */
EIF_INTEGER_64 F1570_16382 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_64 loc3 = (EIF_INTEGER_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_64 ti8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_64 Result = ((EIF_INTEGER_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc2 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_8_))) {
		tr1 = RTOSCF(1905,F123_1905, (Current));
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
		F1570_16342(Current, tr1, ((EIF_INTEGER_32) 1L), ti4_1);
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 < ((EIF_NATURAL_32) 48U)) || (EIF_BOOLEAN) (loc2 > ((EIF_NATURAL_32) 122U)))) {
			tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
			if (F1566_16111(RTCW(tr1), loc2)) {
				ti8_1 = (EIF_INTEGER_64) loc2;
				RTLE;
				return (EIF_INTEGER_64) ti8_1;
			} else {
				tr1 = RTOSCF(1929,F123_1929, (Current));
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
				F1570_16342(Current, tr1, ((EIF_INTEGER_32) 61L), ti4_1);
			}
		} else {
			loc3 = F1476_15069(Current, loc2);
			if ((EIF_BOOLEAN) (loc3 > (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
				tu4_1 = (EIF_NATURAL_32) loc3;
				tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
				if (F1566_16111(RTCW(tr1), tu4_1)) {
					RTLE;
					return (EIF_INTEGER_64) loc3;
				} else {
					tr1 = RTOSCF(1929,F123_1929, (Current));
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
					F1570_16342(Current, tr1, ((EIF_INTEGER_32) 61L), ti4_1);
				}
			} else {
				if ((EIF_BOOLEAN) (loc3 < (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
					RTLE;
					return (EIF_INTEGER_64) loc3;
				} else {
					switch (loc2) {
						case 49U:
						case 50U:
						case 51U:
						case 52U:
						case 53U:
						case 54U:
						case 55U:
						case 56U:
						case 57U:
							if ((EIF_BOOLEAN) !arg2) {
								loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
								tu4_1 = F1570_16378(Current, ((EIF_INTEGER_32) 10L));
								Result = (EIF_INTEGER_64) tu4_1;
								tb1 = '\01';
								if (!((EIF_BOOLEAN) (Result < (EIF_INTEGER_64) ((EIF_INTEGER_32) 10L)))) {
									ti8_1 = (EIF_INTEGER_64) arg1;
									tb1 = (EIF_BOOLEAN) (Result <= ti8_1);
								}
								if (tb1) {
									ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_10_);
									ti8_1 = (EIF_INTEGER_64) ti4_1;
									if ((EIF_BOOLEAN) (Result > ti8_1)) {
										ti4_1 = (EIF_INTEGER_32) Result;
										*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_10_) = (EIF_INTEGER_32) ti4_1;
									}
									Result = (EIF_INTEGER_64) (EIF_INTEGER_64) -(EIF_INTEGER_64) (((EIF_INTEGER_64) RTI64C(12)) + Result);
								} else {
									*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) = (EIF_INTEGER_32) loc1;
									if ((EIF_BOOLEAN) (loc2 >= ((EIF_NATURAL_32) 56U))) {
										Result = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L);
									} else {
										Result = (EIF_INTEGER_64) ((EIF_NATURAL_32) (F1570_16379(Current, ((EIF_INTEGER_32) 3L)) % (EIF_NATURAL_32) ((EIF_INTEGER_32) 256L)));
									}
								}
							} else {
								if ((EIF_BOOLEAN) (loc2 >= ((EIF_NATURAL_32) 56U))) {
									Result = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L);
								} else {
									Result = (EIF_INTEGER_64) ((EIF_NATURAL_32) (F1570_16379(Current, ((EIF_INTEGER_32) 3L)) % (EIF_NATURAL_32) ((EIF_INTEGER_32) 256L)));
								}
							}
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))--;
							break;
						case 48U:
							Result = (EIF_INTEGER_64) ((EIF_NATURAL_32) (F1570_16379(Current, ((EIF_INTEGER_32) 3L)) % (EIF_NATURAL_32) ((EIF_INTEGER_32) 256L)));
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))--;
							break;
						case 120U:
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
							tu4_1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
							if ((EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 123U))) {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
								loc2 = F1570_16380(Current, ((EIF_INTEGER_32) 6L));
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								tu4_1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
								if ((EIF_BOOLEAN)(tu4_1 != ((EIF_NATURAL_32) 125U))) {
									tr1 = RTOSCF(1931,F123_1931, (Current));
									ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
									F1570_16342(Current, tr1, ((EIF_INTEGER_32) 63L), ti4_1);
								} else {
									tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
									if (F1566_16111(RTCW(tr1), loc2)) {
										Result = (EIF_INTEGER_64) loc2;
									} else {
										tr1 = RTOSCF(1929,F123_1929, (Current));
										ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
										F1570_16342(Current, tr1, ((EIF_INTEGER_32) 61L), ti4_1);
									}
								}
							} else {
								loc2 = F1570_16380(Current, ((EIF_INTEGER_32) 2L));
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))--;
								tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
								if (F1566_16111(RTCW(tr1), loc2)) {
									Result = (EIF_INTEGER_64) loc2;
								} else {
									tr1 = RTOSCF(1929,F123_1929, (Current));
									ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
									F1570_16342(Current, tr1, ((EIF_INTEGER_32) 61L), ti4_1);
								}
							}
							break;
						case 117U:
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
							tu4_1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
							if ((EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 123U))) {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
								loc2 = F1570_16380(Current, ((EIF_INTEGER_32) 6L));
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								tu4_1 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
								if ((EIF_BOOLEAN)(tu4_1 != ((EIF_NATURAL_32) 125U))) {
									tr1 = RTOSCF(1932,F123_1932, (Current));
									ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
									F1570_16342(Current, tr1, ((EIF_INTEGER_32) 64L), ti4_1);
								} else {
									tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
									if (F1566_16111(RTCW(tr1), loc2)) {
										Result = (EIF_INTEGER_64) loc2;
									} else {
										tr1 = RTOSCF(1929,F123_1929, (Current));
										ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
										F1570_16342(Current, tr1, ((EIF_INTEGER_32) 61L), ti4_1);
									}
								}
							} else {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))--;
								if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_10_)) {
									tr1 = RTOSCF(1907,F123_1907, (Current));
									ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
									F1570_16342(Current, tr1, ((EIF_INTEGER_32) 3L), ti4_1);
								} else {
									tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
									if (F1566_16111(RTCW(tr1), loc2)) {
										Result = (EIF_INTEGER_64) loc2;
									} else {
										tr1 = RTOSCF(1929,F123_1929, (Current));
										ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
										F1570_16342(Current, tr1, ((EIF_INTEGER_32) 61L), ti4_1);
									}
								}
							}
							break;
						case 99U:
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_))++;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
							loc2 = F1134_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_));
							if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_8_))) {
								tr1 = RTOSCF(1906,F123_1906, (Current));
								ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
								F1570_16342(Current, tr1, ((EIF_INTEGER_32) 2L), ti4_1);
								Result = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L);
							} else {
								if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_NATURAL_32) 97U) <= loc2) && (EIF_BOOLEAN) (loc2 <= ((EIF_NATURAL_32) 122U)))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
									tu4_1 = F1557_15809(RTCW(tr1), loc2);
									loc2 = (EIF_NATURAL_32) tu4_1;
								}
								if ((EIF_BOOLEAN) (loc2 < ((EIF_NATURAL_32) 64U))) {
									Result = (EIF_INTEGER_64) (EIF_NATURAL_32) (loc2 + ((EIF_NATURAL_32) 64U));
								} else {
									if ((EIF_BOOLEAN) (loc2 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
										Result = (EIF_INTEGER_64) (EIF_NATURAL_32) (loc2 - ((EIF_NATURAL_32) 64U));
									} else {
										tr1 = RTOSCF(1930,F123_1930, (Current));
										ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
										F1570_16342(Current, tr1, ((EIF_INTEGER_32) 62L), ti4_1);
									}
								}
							}
							break;
						default:
							if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_10_)) {
								tr1 = RTOSCF(1907,F123_1907, (Current));
								ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
								F1570_16342(Current, tr1, ((EIF_INTEGER_32) 3L), ti4_1);
							} else {
								tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
								if (F1566_16111(RTCW(tr1), loc2)) {
									Result = (EIF_INTEGER_64) loc2;
								} else {
									tr1 = RTOSCF(1929,F123_1929, (Current));
									ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_7_);
									F1570_16342(Current, tr1, ((EIF_INTEGER_32) 61L), ti4_1);
								}
							}
							break;
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_COMPILER}.first_significant_code */
EIF_NATURAL_32 F1570_16383 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_NATURAL_32 arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = (EIF_NATURAL_32) arg1;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_);
	for (;;) {
		if (loc3) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tu4_1 = F1467_14894(RTCW(tr1), loc1);
		switch (tu4_1) {
			case 12U:
				switch (arg2) {
					case 1U:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						loc4 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						if ((EIF_BOOLEAN)(F122_1878(Current, loc4) != F122_1878(Current, Result))) {
							if (arg3) {
								loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								Result = (EIF_NATURAL_32) loc4;
								loc1 += ((EIF_INTEGER_32) 2L);
							}
						} else {
							loc1 += ((EIF_INTEGER_32) 2L);
						}
						break;
					case 2U:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						loc4 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						if ((EIF_BOOLEAN)(F122_1879(Current, loc4) != F122_1879(Current, Result))) {
							if (arg3) {
								loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								Result = (EIF_NATURAL_32) loc4;
								loc1 += ((EIF_INTEGER_32) 2L);
							}
						} else {
							loc1 += ((EIF_INTEGER_32) 2L);
						}
						break;
					default:
						loc1 += ((EIF_INTEGER_32) 2L);
						break;
				}
				break;
			case 67U:
				loc1 += ((EIF_INTEGER_32) 2L);
				break;
			case 2U:
			case 3U:
				loc1++;
				break;
			case 61U:
			case 62U:
			case 63U:
				loc2 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 56U);
				for (;;) {
					if ((EIF_BOOLEAN)(loc2 != ((EIF_NATURAL_32) 56U))) break;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
					ti4_1 = (EIF_INTEGER_32) tu4_1;
					loc1 += ti4_1;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					loc2 = F1467_14894(RTCW(tr1), loc1);
				}
				loc1 += ((EIF_INTEGER_32) 2L);
				break;
			default:
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				break;
		}
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) = (EIF_INTEGER_32) loc1;
	RTLE;
	return Result;
}

/* {RX_PCRE_COMPILER}.find_firstchar */
EIF_NATURAL_32 F1570_16384 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_64 loc3 = (EIF_INTEGER_64) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_64 ti8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_);
	Result = (EIF_NATURAL_32) arg1;
	*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_) = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) -1L);
	loc2 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 56U);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != ((EIF_NATURAL_32) 56U)) || loc4)) break;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L));
		tu4_1 = F1570_16383(Current, Result, ((EIF_NATURAL_32) 1U), (EIF_BOOLEAN) 1);
		Result = (EIF_NATURAL_32) tu4_1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc2 = F1467_14894(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_));
		if ((EIF_BOOLEAN) (loc2 >= ((EIF_NATURAL_32) 70U))) {
			loc2 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 70U);
		}
		switch (loc2) {
			case 60U:
			case 65U:
			case 66U:
			case 70U:
				loc3 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_);
				tu4_1 = F1570_16384(Current, Result);
				Result = (EIF_NATURAL_32) tu4_1;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_) < (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					if ((EIF_BOOLEAN) (loc3 < (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
					} else {
						if ((EIF_BOOLEAN)(loc3 != *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_))) {
							*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_) = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) -1L);
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						}
					}
				}
				break;
			case 16U:
			case 20U:
			case 21U:
			case 26U:
				if ((EIF_BOOLEAN)(loc2 == ((EIF_NATURAL_32) 26U))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_))++;
				} else {
					if ((EIF_BOOLEAN)(loc2 == ((EIF_NATURAL_32) 16U))) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_))++;
					}
				}
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_) < (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_1 = F1467_14895(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) + ((EIF_INTEGER_32) 1L)));
					ti8_1 = (EIF_INTEGER_64) tu4_1;
					*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_) = (EIF_INTEGER_64) ti8_1;
				} else {
					ti8_1 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_);
					tu4_1 = (EIF_NATURAL_32) ti8_1;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_2 = F1467_14895(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) + ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(tu4_1 != tu4_2)) {
						*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_) = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) -1L);
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
				break;
			default:
				*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_) = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) -1L);
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				break;
		}
		if ((EIF_BOOLEAN) !loc4) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			ti4_1 = (EIF_INTEGER_32) tu4_1;
			loc1 += ti4_1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc2 = F1467_14894(RTCW(tr1), loc1);
		}
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_COMPILER}.can_anchored */
EIF_BOOLEAN F1570_16385 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc3 = (EIF_NATURAL_32) arg1;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc2 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 56U);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != ((EIF_NATURAL_32) 56U)) || (EIF_BOOLEAN) !Result)) break;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L));
		tu4_1 = F1570_16383(Current, loc3, ((EIF_NATURAL_32) 2U), (EIF_BOOLEAN) 0);
		loc3 = (EIF_NATURAL_32) tu4_1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc2 = F1467_14894(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_));
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 >= ((EIF_NATURAL_32) 70U)) || (EIF_BOOLEAN)(loc2 == ((EIF_NATURAL_32) 60U))) || (EIF_BOOLEAN)(loc2 == ((EIF_NATURAL_32) 65U))) || (EIF_BOOLEAN)(loc2 == ((EIF_NATURAL_32) 66U)))) {
			Result = F1570_16385(Current, loc3);
		} else {
			tb1 = '\0';
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 == ((EIF_NATURAL_32) 36U)) || (EIF_BOOLEAN)(loc2 == ((EIF_NATURAL_32) 37U)))) {
				tb1 = F122_1880(Current, loc3);
			}
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tu4_1 = F1467_14894(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) + ((EIF_INTEGER_32) 1L)));
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 15U));
			} else {
				Result = '\01';
				if (!(EIF_BOOLEAN)(loc2 == ((EIF_NATURAL_32) 1U))) {
					tb1 = '\0';
					if ((EIF_BOOLEAN)(loc2 == ((EIF_NATURAL_32) 13U))) {
						tb1 = (EIF_BOOLEAN) !F122_1879(Current, loc3);
					}
					Result = tb1;
				}
			}
		}
		if (Result) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			ti4_1 = (EIF_INTEGER_32) tu4_1;
			loc1 += ti4_1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc2 = F1467_14894(RTCW(tr1), loc1);
		}
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_COMPILER}.has_startline */
EIF_BOOLEAN F1570_16386 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc2 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 56U);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != ((EIF_NATURAL_32) 56U)) || (EIF_BOOLEAN) !Result)) break;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L));
		tu4_1 = F1570_16383(Current, loc3, (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L), (EIF_BOOLEAN) 0);
		loc3 = (EIF_NATURAL_32) tu4_1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc2 = F1467_14894(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_));
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 >= ((EIF_NATURAL_32) 70U)) || (EIF_BOOLEAN)(loc2 == ((EIF_NATURAL_32) 60U))) || (EIF_BOOLEAN)(loc2 == ((EIF_NATURAL_32) 65U))) || (EIF_BOOLEAN)(loc2 == ((EIF_NATURAL_32) 66U)))) {
			Result = F1570_16386(Current);
		} else {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 == ((EIF_NATURAL_32) 36U)) || (EIF_BOOLEAN)(loc2 == ((EIF_NATURAL_32) 37U)))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tu4_1 = F1467_14894(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) + ((EIF_INTEGER_32) 1L)));
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 15U));
			} else {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc2 == ((EIF_NATURAL_32) 13U));
			}
		}
		if (Result) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			ti4_1 = (EIF_INTEGER_32) tu4_1;
			loc1 += ti4_1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc2 = F1467_14894(RTCW(tr1), loc1);
		}
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_COMPILER}.empty_pattern_buffer */
static EIF_REFERENCE F1570_16388_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (16388);
#define Result RTOSR(16388)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H("\000\000\000\000",1,0);
	RTOSE (16388);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1570_16388 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16388,F1570_16388_body,(Current));
}

/* {RX_PCRE_COMPILER}.infinity */
static EIF_INTEGER_32 F1570_16389_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (16389);
#define Result RTOSR(16389)
	Result = RTOSCF(5230,F353_5230, (RTCV(RTOSCF(1703,F105_1703, (Current)))));
	RTOSE (16389);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1570_16389 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16389,F1570_16389_body,(Current));
}

/* {RX_PCRE_COMPILER}.maxlit */
static EIF_INTEGER_32 F1570_16390_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (16390);
#define Result RTOSR(16390)
	Result = RTOSCF(5230,F353_5230, (RTCV(RTOSCF(1703,F105_1703, (Current)))));
	RTOSE (16390);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1570_16390 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16390,F1570_16390_body,(Current));
}

void EIF_Minit814 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
