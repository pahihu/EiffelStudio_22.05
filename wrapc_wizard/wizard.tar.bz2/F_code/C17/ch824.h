
#ifndef _C17_ch824_
#define _C17_ch824_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F645_6072(EIF_REFERENCE);
extern EIF_REFERENCE F645_6073(EIF_REFERENCE);
extern EIF_BOOLEAN F645_6074(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F645_6075(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F645_6076(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F645_6077(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F645_6079(EIF_REFERENCE);
extern void F645_6081(EIF_REFERENCE);
extern EIF_BOOLEAN F645_6084(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F645_6085(EIF_REFERENCE);
extern EIF_BOOLEAN F645_6087(EIF_REFERENCE);
extern void F645_6092(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit824(void);
extern EIF_BOOLEAN F430_5881(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F430_5882(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R5639[])();
extern char *(*R5488[])();
extern char *(*R5600[])();
extern char *(*R5605[])();
extern char *(*R5606[])();
extern char *(*R5609[])();
extern char *(*R5692[])();
extern char *(*R5613[])();
extern char *(*R5627[])();
extern char *(*R5591[])();
extern char *(*R5592[])();
extern char *(*R5593[])();
extern char *(*R5633[])();
extern char *(*R5635[])();
extern char *(*R5482[])();

#ifdef __cplusplus
}
#endif

#endif
