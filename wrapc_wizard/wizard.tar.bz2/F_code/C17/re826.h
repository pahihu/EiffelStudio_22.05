
#ifndef _C17_re826_
#define _C17_re826_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F619_6019(EIF_REFERENCE);
extern void EIF_Minit826(void);
extern char *(*R5864[])();
extern char *(*R5867[])();
extern EIF_TYPE_INDEX Y5430[];
extern EIF_TYPE_INDEX *Y5430_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
