/*
 * Code for class EC_EIFFEL_LAYOUT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ec812.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EC_EIFFEL_LAYOUT}.application_name */

EIF_REFERENCE F1568_16293 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (16293,RTMS_EX_H("ec",2,25955));
}

void EIF_Minit812 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
