/*
 * Code for class COMPILER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co806.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {COMPILER}.default_create */
void F1562_15944 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(17, 1).id);
	F18_86(RTCW(tr1), ((EIF_INTEGER_32) 1024L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(20, 1).id);
	F21_163(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = F1_14(RTOSCF(16020,F1562_16020, (Current)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	F1563_16025(Current);
	tr1 = RTOSCF(1773,F110_1773, (Current));
	F1562_15973(Current, tr1);
	tr1 = RTOSCF(1774,F110_1774, (Current));
	F1562_15974(Current, tr1);
	F1562_15960(Current);
	RTLE;
}

/* {COMPILER}.is_compiled */
EIF_BOOLEAN F1562_15945 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = RTOSCF(112,F19_112, (Current));
	Result = F1135_10108(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {COMPILER}.set_default_options */
void F1562_15960 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1562_15961(Current, (EIF_BOOLEAN) 0);
	F1562_15965(Current, (EIF_BOOLEAN) 0);
	F1562_15966(Current, (EIF_BOOLEAN) 0);
	F1562_15962(Current, (EIF_BOOLEAN) 0);
	F1562_15967(Current, (EIF_BOOLEAN) 1);
	F1562_15968(Current, (EIF_BOOLEAN) 0);
	F1562_15969(Current, (EIF_BOOLEAN) 1);
	F1562_15970(Current, (EIF_BOOLEAN) 1);
	F1562_15971(Current, (EIF_BOOLEAN) 0);
	F1562_15963(Current, (EIF_BOOLEAN) 1);
	F1562_15964(Current, (EIF_BOOLEAN) 0);
	RTLE;
}

/* {COMPILER}.set_caseless */
void F1562_15961 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_extended */
void F1562_15962 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_greedy */
void F1562_15963 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_strict */
void F1562_15964 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_10_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_multiline */
void F1562_15965 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_3_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_dotall */
void F1562_15966 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_4_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_empty_allowed */
void F1562_15967 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_5_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_dollar_endonly */
void F1562_15968 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_6_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_bol */
void F1562_15969 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_7_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_eol */
void F1562_15970 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_8_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_anchored */
void F1562_15971 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_9_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_ims_options */
void F1562_15972 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = F111_1791(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_) = (EIF_BOOLEAN) tb1;
	tb1 = F111_1792(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_3_) = (EIF_BOOLEAN) tb1;
	tb1 = F111_1793(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_4_) = (EIF_BOOLEAN) tb1;
	RTLE;
}

/* {COMPILER}.set_character_case_mapping */
void F1562_15973 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {COMPILER}.set_word_set */
void F1562_15974 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {COMPILER}.compile */
void F1562_15975 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1136, 1).id);
	F1135_10082(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1137_10206(RTCW(tr1), (EIF_CHARACTER_8) '\000');
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8470[Dtype(arg1)-1134]);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_) = (EIF_INTEGER_32) ti4_1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F18_105(RTCW(tr1));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_4_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	F1562_15986(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_15_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 32L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
	tr1 = RTOSCF(149,F19_149, (Current));
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
	F1562_15980(Current, tr1, ((EIF_INTEGER_32) 99L), ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F18_99(RTCW(tr1), ((EIF_INTEGER_32) 70L));
	F1562_16001(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_15_), (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, ((EIF_INTEGER_32) -1L));
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	if ((EIF_BOOLEAN)(tr1 == RTOSCF(149,F19_149, (Current)))) {
		tb1 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_));
	}
	if (tb1) {
		tr1 = RTOSCF(134,F19_134, (Current));
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
		F1562_15980(Current, tr1, ((EIF_INTEGER_32) 22L), ti4_1);
	} else {
		if ((EIF_BOOLEAN) (*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_4_) > *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_))) {
			tr1 = RTOSCF(127,F19_127, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
			F1562_15980(Current, tr1, ((EIF_INTEGER_32) 15L), ti4_1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	if ((EIF_BOOLEAN)(tr1 == RTOSCF(149,F19_149, (Current)))) {
		tr1 = RTOSCF(112,F19_112, (Current));
		F1562_15980(Current, tr1, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F18_99(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		loc1 = F1562_15985(Current);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_9_)) {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			if (F1562_16016(Current, loc1)) {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				F1562_15971(Current, (EIF_BOOLEAN) 1);
			} else {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				ti4_1 = F1562_16015(Current, loc1);
				loc1 = (EIF_INTEGER_32) ti4_1;
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				tb1 = '\0';
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) < ((EIF_INTEGER_32) 0L))) {
					tb1 = F1562_16017(Current);
				}
				if (tb1) {
					F1562_15987(Current, (EIF_BOOLEAN) 1);
				}
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) <= ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) >= ((EIF_INTEGER_32) 0L)))) {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		}
	}
	RTLE;
}

/* {COMPILER}.set_error */
void F1562_15980 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_13_) = (EIF_INTEGER_32) arg2;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_14_) = (EIF_INTEGER_32) arg3;
	RTLE;
}

/* {COMPILER}.reset */
void F1562_15981 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(149,F19_149, (Current));
	F1562_15980(Current, tr1, ((EIF_INTEGER_32) 99L), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1137_10222(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1137_10206(RTCW(tr1), (EIF_CHARACTER_8) '\000');
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {COMPILER}.ims_options */
EIF_INTEGER_32 F1562_15985 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_)) {
		ti4_1 = F111_1798(Current, Result);
		Result = (EIF_INTEGER_32) ti4_1;
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_3_)) {
		ti4_1 = F111_1800(Current, Result);
		Result = (EIF_INTEGER_32) ti4_1;
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_4_)) {
		RTLE;
		return (EIF_INTEGER_32) F111_1802(Current, Result);
	}
	RTLE;
	return Result;
}

/* {COMPILER}.set_default_internal_options */
void F1562_15986 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1562_15987(Current, (EIF_BOOLEAN) 0);
	F1562_15988(Current, (EIF_BOOLEAN) 0);
	RTLE;
}

/* {COMPILER}.set_startline */
void F1562_15987 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_11_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_ichanged */
void F1562_15988 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_12_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.find_fixed_code_length */
EIF_INTEGER_32 F1562_16000 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 2L));
	for (;;) {
		if (loc5) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc3 = F18_87(RTCW(tr1), loc1);
		if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 70L))) {
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
		}
		switch (loc3) {
			case 65L:
			case 66L:
			case 70L:
				loc2 = F1562_16000(Current, loc1);
				if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					loc4 += loc2;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
					loc1 += ti4_1;
					for (;;) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_1 = F18_87(RTCW(tr1), loc1);
						if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 56L))) break;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_2 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						loc1 += ti4_2;
					}
					loc1 += ((EIF_INTEGER_32) 2L);
				}
				break;
			case 0L:
			case 56L:
			case 57L:
			case 58L:
			case 59L:
				if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
					Result = (EIF_INTEGER_32) loc4;
				} else {
					if ((EIF_BOOLEAN)(Result != loc4)) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
				if ((EIF_BOOLEAN) !loc5) {
					if ((EIF_BOOLEAN)(loc3 != ((EIF_INTEGER_32) 56L))) {
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						loc1 += ((EIF_INTEGER_32) 2L);
						loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					}
				}
				break;
			case 60L:
			case 61L:
			case 62L:
			case 63L:
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_2 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
				loc1 += ti4_2;
				for (;;) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_2 = F18_87(RTCW(tr1), loc1);
					if ((EIF_BOOLEAN)(ti4_2 != ((EIF_INTEGER_32) 56L))) break;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_3 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
					loc1 += ti4_3;
				}
				loc1 += ((EIF_INTEGER_32) 2L);
				break;
			case 64L:
				loc1 += ((EIF_INTEGER_32) 2L);
				break;
			case 12L:
			case 67L:
				loc1 += ((EIF_INTEGER_32) 2L);
				break;
			case 1L:
			case 2L:
			case 3L:
			case 10L:
			case 11L:
			case 13L:
			case 14L:
				loc1++;
				break;
			case 16L:
				loc1++;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc2 = F18_89(RTCW(tr1), loc1);
				loc4 += loc2;
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc2) + ((EIF_INTEGER_32) 1L));
				break;
			case 26L:
			case 44L:
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_3 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
				loc4 += ti4_3;
				loc1 += ((EIF_INTEGER_32) 3L);
				break;
			case 4L:
			case 5L:
			case 6L:
			case 7L:
			case 8L:
			case 9L:
			case 15L:
				loc4++;
				loc1++;
				break;
			case 53L:
				loc1 += ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_3 = F18_87(RTCW(tr1), loc1);
				switch (ti4_3) {
					case 45L:
					case 46L:
					case 49L:
					case 50L:
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						break;
					case 51L:
					case 52L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc2 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_3 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
						if ((EIF_BOOLEAN)(loc2 != ti4_3)) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							loc4 += loc2;
							loc1 += ((EIF_INTEGER_32) 3L);
						}
						break;
					default:
						loc4++;
						break;
				}
				break;
			default:
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				break;
		}
	}
	RTLE;
	return Result;
}

/* {COMPILER}.compile_regexp */
void F1562_16001 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc7 = (EIF_INTEGER_32) arg1;
	loc8 = F1562_15985(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
	loc2 = (EIF_INTEGER_32) loc1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	ti4_1 = RTOSCF(16022,F1562_16022, (Current));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) = (EIF_INTEGER_32) ti4_1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F18_101(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	if ((EIF_BOOLEAN) (arg4 >= ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F18_99(RTCW(tr1), ((EIF_INTEGER_32) 67L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F18_101(RTCW(tr1), arg4);
	}
	for (;;) {
		if (loc9) break;
		if ((EIF_BOOLEAN) !F111_1796(Current, loc7)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F18_99(RTCW(tr1), ((EIF_INTEGER_32) 12L));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F18_101(RTCW(tr1), loc7);
			F1562_15972(Current, loc7);
		}
		if (arg3) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F18_99(RTCW(tr1), ((EIF_INTEGER_32) 64L));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F18_101(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		}
		loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_);
		loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_15_) = (EIF_INTEGER_32) loc7;
		F1562_16002(Current, arg2);
		loc7 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_15_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		if ((EIF_BOOLEAN)(tr1 == RTOSCF(149,F19_149, (Current)))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
			loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 - loc1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F18_98(RTCW(tr1), loc6, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) -2L))) {
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) >= ((EIF_INTEGER_32) 0L))) {
					if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L))) {
						loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_);
					} else {
						if ((EIF_BOOLEAN)(loc4 != *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_))) {
							loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -2L);
						}
					}
				} else {
					loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -2L);
				}
			}
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) < loc5)) {
				loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_);
			}
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) loc4;
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) = (EIF_INTEGER_32) loc5;
			if (arg3) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_99(RTCW(tr1), ((EIF_INTEGER_32) 0L));
				loc6 = F1562_16000(Current, loc1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_2_0_0_0_);
				F18_95(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
				if ((EIF_BOOLEAN) (loc6 < ((EIF_INTEGER_32) 0L))) {
					tr1 = RTOSCF(137,F19_137, (Current));
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
					F1562_15980(Current, tr1, ((EIF_INTEGER_32) 25L), ti4_1);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F18_98(RTCW(tr1), loc6, loc3);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			ti4_1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
			if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 124L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
				loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 - loc2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_99(RTCW(tr1), ((EIF_INTEGER_32) 57L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_101(RTCW(tr1), loc6);
				tb1 = '\0';
				if (arg2) {
					tb1 = (EIF_BOOLEAN) !F111_1796(Current, loc7);
				}
				if (tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F18_99(RTCW(tr1), ((EIF_INTEGER_32) 12L));
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F18_101(RTCW(tr1), loc8);
				}
				loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_99(RTCW(tr1), ((EIF_INTEGER_32) 56L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_101(RTCW(tr1), ((EIF_INTEGER_32) 0L));
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
			}
		} else {
			loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTLE;
}

/* {COMPILER}.compile_branch */
void F1562_16002 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc14 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc15 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc16 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc17 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc18 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc19 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc20 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc21 = (EIF_BOOLEAN) 0;
	struct eif_ex_16 sloc22;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) sloc22.data;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	memset (&sloc22.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc22.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc22.overhead, eif_new_type(31, 0x00).id);
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc22);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc11 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc16 = F1562_15985(Current);
	loc17 = *(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_);
	loc18 = *(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_)) {
		F1562_16012(Current);
	}
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc20 || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_)))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tb1 = (EIF_BOOLEAN)(tr1 != RTOSCF(149,F19_149, (Current)));
		}
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc19 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
		tb2 = '\0';
		if ((EIF_BOOLEAN)(loc19 == ((EIF_INTEGER_32) 123L))) {
			tb2 = F1562_16006(Current, loc5, loc11, loc9);
		}
		if (tb2) {
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		} else {
			switch (loc19) {
				case 41L:
				case 124L:
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))--;
					loc20 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					break;
				case 94L:
					loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F18_99(RTCW(tr1), ((EIF_INTEGER_32) 13L));
					break;
				case 36L:
					loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F18_99(RTCW(tr1), ((EIF_INTEGER_32) 14L));
					break;
				case 46L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F18_99(RTCW(tr1), ((EIF_INTEGER_32) 15L));
					break;
				case 91L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
					F1562_16003(Current);
					break;
				case 42L:
					F1562_16004(Current, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) -1L), loc5, loc11, loc9);
					loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					break;
				case 43L:
					F1562_16004(Current, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) -1L), loc5, loc11, loc9);
					loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					break;
				case 63L:
					F1562_16004(Current, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), loc5, loc11, loc9);
					loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					break;
				case 40L:
					loc15 = F1562_15985(Current);
					loc14 = (EIF_INTEGER_32) loc15;
					loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					ti4_1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 63L))) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						ti4_1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
						switch (ti4_1) {
							case 35L:
								loc7 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
								loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L));
								for (;;) {
									tb2 = '\01';
									if (!(EIF_BOOLEAN) (loc7 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
										ti4_1 = F1137_10163(RTCW(tr1), loc7);
										tb2 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 41L));
									}
									if (tb2) break;
									loc7++;
								}
								if ((EIF_BOOLEAN) (loc7 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_))) {
									*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 - ((EIF_INTEGER_32) 1L));
									tr1 = RTOSCF(130,F19_130, (Current));
									F1562_15980(Current, tr1, ((EIF_INTEGER_32) 18L), loc7);
								} else {
									*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) loc7;
								}
								break;
							case 58L:
								loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
								break;
							case 40L:
								loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
								ti4_1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
								switch (ti4_1) {
									case 48L:
									case 49L:
									case 50L:
									case 51L:
									case 52L:
									case 53L:
									case 54L:
									case 55L:
									case 56L:
									case 57L:
										loc8 = F1562_16009(Current, ((EIF_INTEGER_32) 10L));
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
										ti4_1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
										if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 41L))) {
											tr1 = RTOSCF(138,F19_138, (Current));
											ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
											F1562_15980(Current, tr1, ((EIF_INTEGER_32) 26L), ti4_1);
										}
										if ((EIF_BOOLEAN)(loc8 == ((EIF_INTEGER_32) 0L))) {
											tr1 = RTOSCF(147,F19_147, (Current));
											ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
											F1562_15980(Current, tr1, ((EIF_INTEGER_32) 35L), ti4_1);
										} else {
											(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
										}
										break;
									default:
										loc7 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
										ti4_1 = F1137_10163(RTCW(tr1), loc7);
										if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 63L))) {
											tr1 = RTOSCF(140,F19_140, (Current));
											ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
											F1562_15980(Current, tr1, ((EIF_INTEGER_32) 28L), ti4_1);
										} else {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
											ti4_1 = F1137_10163(RTCW(tr1), (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L)));
											switch (ti4_1) {
												case 33L:
												case 60L:
												case 61L:
													break;
												default:
													tr1 = RTOSCF(140,F19_140, (Current));
													ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
													F1562_15980(Current, tr1, ((EIF_INTEGER_32) 28L), ti4_1);
													break;
											}
										}
										*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 - ((EIF_INTEGER_32) 1L));
										break;
								}
								break;
							case 61L:
								loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
								break;
							case 33L:
								loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
								break;
							case 60L:
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
								ti4_1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
								switch (ti4_1) {
									case 61L:
										loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 62L);
										(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
										break;
									case 33L:
										loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 63L);
										(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
										break;
									default:
										tr1 = RTOSCF(136,F19_136, (Current));
										ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
										F1562_15980(Current, tr1, ((EIF_INTEGER_32) 24L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 3L)));
										break;
								}
								break;
							case 62L:
								loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 65L);
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
								break;
							case 82L:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								F18_99(RTCW(tr1), ((EIF_INTEGER_32) 55L));
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
								break;
							default:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
								loc19 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
								loc21 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								for (;;) {
									tb3 = '\01';
									if (!(EIF_BOOLEAN) ((EIF_BOOLEAN)(loc19 == ((EIF_INTEGER_32) 41L)) || (EIF_BOOLEAN)(loc19 == ((EIF_INTEGER_32) 58L)))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
										tb3 = (EIF_BOOLEAN)(tr1 != RTOSCF(149,F19_149, (Current)));
									}
									if (tb3) break;
									switch (loc19) {
										case 45L:
											loc21 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc21;
											break;
										case 105L:
											if (loc21) {
												ti4_1 = F111_1798(Current, loc14);
												loc14 = (EIF_INTEGER_32) ti4_1;
											} else {
												ti4_1 = F111_1799(Current, loc14);
												loc14 = (EIF_INTEGER_32) ti4_1;
											}
											break;
										case 109L:
											if (loc21) {
												ti4_1 = F111_1800(Current, loc14);
												loc14 = (EIF_INTEGER_32) ti4_1;
											} else {
												ti4_1 = F111_1801(Current, loc14);
												loc14 = (EIF_INTEGER_32) ti4_1;
											}
											break;
										case 115L:
											if (loc21) {
												ti4_1 = F111_1802(Current, loc14);
												loc14 = (EIF_INTEGER_32) ti4_1;
											} else {
												ti4_1 = F111_1803(Current, loc14);
												loc14 = (EIF_INTEGER_32) ti4_1;
											}
											break;
										case 120L:
											*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_) = (EIF_BOOLEAN) loc21;
											break;
										case 88L:
											*(EIF_BOOLEAN *)(Current+ _CHROFF_11_10_) = (EIF_BOOLEAN) loc21;
											break;
										case 85L:
											*(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc21;
											break;
										default:
											tr1 = RTOSCF(124,F19_124, (Current));
											ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
											F1562_15980(Current, tr1, ((EIF_INTEGER_32) 12L), ti4_1);
											break;
									}
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
									if ((EIF_BOOLEAN)(tr1 != RTOSCF(149,F19_149, (Current)))) {
										loc19 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
									} else {
										(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
										loc19 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
									}
								}
								if ((EIF_BOOLEAN)(loc19 == ((EIF_INTEGER_32) 41L))) {
									if (arg1) {
										if ((EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_) != F111_1791(Current, loc14))) {
											F1562_15988(Current, (EIF_BOOLEAN) 1);
										}
										if ((EIF_BOOLEAN)(F111_1810(Current, loc15) != loc14)) {
											*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_15_) = (EIF_INTEGER_32) loc14;
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F18_99(RTCW(tr1), ((EIF_INTEGER_32) 12L));
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F18_101(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_15_));
										}
									} else {
										loc18 = *(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_);
										loc17 = *(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_);
										loc16 = (EIF_INTEGER_32) loc14;
									}
									F1562_15972(Current, loc14);
									loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								} else {
									loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
									if ((EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_) != F111_1791(Current, loc14))) {
										F1562_15988(Current, (EIF_BOOLEAN) 1);
									}
								}
								break;
						}
					} else {
						(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_)) += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
						tu4_1 = F32_296(RTCW(loc22));
						if ((EIF_BOOLEAN) (*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_) > tu4_1)) {
							tr1 = RTOSCF(125,F19_125, (Current));
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
							F1562_15980(Current, tr1, ((EIF_INTEGER_32) 13L), ti4_1);
						} else {
							tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_);
							loc1 = (EIF_INTEGER_32) tu4_1;
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 70L) + loc1);
						}
					}
					if ((EIF_BOOLEAN) (loc1 >= ((EIF_INTEGER_32) 0L))) {
						if ((EIF_BOOLEAN) (loc1 >= ((EIF_INTEGER_32) 65L))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
						} else {
							loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						}
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F18_99(RTCW(tr1), loc1);
						loc13 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_);
						loc12 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_);
						if ((EIF_BOOLEAN)(F111_1810(Current, loc15) == loc14)) {
							loc15 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 32L);
						} else {
							loc15 = (EIF_INTEGER_32) loc14;
						}
						F1562_16001(Current, loc15, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 62L)) || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 63L))), loc8);
						loc9 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_);
						loc10 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) = (EIF_INTEGER_32) loc12;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) loc13;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
						if ((EIF_BOOLEAN)(tr1 == RTOSCF(149,F19_149, (Current)))) {
							if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 66L))) {
								loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								loc7 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)));
								loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 + loc7);
								for (;;) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									ti4_1 = F18_87(RTCW(tr1), loc7);
									if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 57L))) break;
									loc4++;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									ti4_2 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L)));
									loc7 += ti4_2;
								}
								if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 2L))) {
									tr1 = RTOSCF(139,F19_139, (Current));
									ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
									F1562_15980(Current, tr1, ((EIF_INTEGER_32) 27L), ti4_2);
								}
							}
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc10 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 >= ((EIF_INTEGER_32) 70L)) || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 65L))) || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 60L))) || (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 66L)) && (EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 2L)))))) {
								loc11 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_);
								*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) loc10;
								if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 60L))) {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_)) += loc9;
								}
							}
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
							ti4_2 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
							if ((EIF_BOOLEAN)(ti4_2 != ((EIF_INTEGER_32) 41L))) {
								tr1 = RTOSCF(126,F19_126, (Current));
								ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
								F1562_15980(Current, tr1, ((EIF_INTEGER_32) 14L), ti4_2);
							}
						}
					}
					break;
				default:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F18_99(RTCW(tr1), ((EIF_INTEGER_32) 16L));
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F18_101(RTCW(tr1), ((EIF_INTEGER_32) 0L));
					loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					loc19 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
					loc21 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					for (;;) {
						if (loc21) break;
						if ((EIF_BOOLEAN)(loc19 == ((EIF_INTEGER_32) 92L))) {
							tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_);
							ti4_2 = (EIF_INTEGER_32) tu4_1;
							loc3 = F1562_16013(Current, ti4_2, (EIF_BOOLEAN) 0);
							if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) {
								if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F18_95(RTCW(tr1), loc5);
								} else {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
								}
								if ((EIF_BOOLEAN) ((EIF_INTEGER_32) -loc3 >= ((EIF_INTEGER_32) 12L))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F18_99(RTCW(tr1), ((EIF_INTEGER_32) 54L));
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F18_101(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) -loc3 - ((EIF_INTEGER_32) 12L)));
								} else {
									if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) -loc3 <= ((EIF_INTEGER_32) 3L)) || (EIF_BOOLEAN) ((EIF_INTEGER_32) -loc3 >= ((EIF_INTEGER_32) 10L)))) {
										loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
									}
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F18_99(RTCW(tr1), (EIF_INTEGER_32) -loc3);
								}
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
								loc21 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								loc19 = (EIF_INTEGER_32) loc3;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								F18_100(RTCW(tr1), loc19);
								loc2++;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
								tr2 = RTOSCF(149,F19_149, (Current));
								loc21 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != tr2);
							}
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							F18_100(RTCW(tr1), loc19);
							loc2++;
						}
						if ((EIF_BOOLEAN) !loc21) {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
							if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_)) {
								F1562_16012(Current);
							}
							tb4 = '\01';
							if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_))) {
								tb4 = (EIF_BOOLEAN) (loc2 >= RTOSCF(16023,F1562_16023, (Current)));
							}
							if (tb4) {
								loc21 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
								loc19 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
								tr1 = RTOSCF(1787,F110_1787, (Current));
								loc21 = F21_166(RTCW(tr1), loc19);
							}
						}
					}
					if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
						if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 1L))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							loc11 = F18_88(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 + loc2) - ((EIF_INTEGER_32) 1L)));
						} else {
							loc11 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_);
						}
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_2 = F18_88(RTCW(tr1), (EIF_INTEGER_32) (loc6 + loc2));
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) ti4_2;
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_)) += loc2;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F18_98(RTCW(tr1), loc2, loc6);
					}
					if ((EIF_BOOLEAN) (loc2 <= RTOSCF(16023,F1562_16023, (Current)))) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))--;
					}
					break;
			}
		}
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_)) {
			F1562_16012(Current);
		}
	}
	F1562_15972(Current, loc16);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_) = (EIF_BOOLEAN) loc17;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_) = (EIF_BOOLEAN) loc18;
	RTLE;
}

/* {COMPILER}.compile_character_class */
void F1562_16003 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTOSCF(16021,F1562_16021, (Current));
	F21_171(RTCW(loc1));
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc7 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 94L))) {
		loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc7 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	}
	loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 93L)))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tb1 = (EIF_BOOLEAN)(tr1 != RTOSCF(149,F19_149, (Current)));
		}
		if (tb1) break;
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_))) {
			tr1 = RTOSCF(118,F19_118, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
			F1562_15980(Current, tr1, ((EIF_INTEGER_32) 6L), ti4_1);
		} else {
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 91L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				ti4_1 = F1137_10163(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) + ((EIF_INTEGER_32) 1L)));
				switch (ti4_1) {
					case 46L:
					case 58L:
					case 61L:
						loc2 = F1562_16007(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
						break;
				}
			}
			if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
				loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				ti4_1 = F1137_10163(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) + ((EIF_INTEGER_32) 1L)));
				if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 58L))) {
					tr1 = RTOSCF(143,F19_143, (Current));
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
					F1562_15980(Current, tr1, ((EIF_INTEGER_32) 31L), ti4_1);
				} else {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_)) += ((EIF_INTEGER_32) 2L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					ti4_1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 94L))) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
					loc3 = F1562_16008(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_), (EIF_INTEGER_32) (loc2 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_)));
					if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) {
						tr1 = RTOSCF(142,F19_142, (Current));
						ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
						F1562_15980(Current, tr1, ((EIF_INTEGER_32) 30L), ti4_1);
					} else {
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 <= ((EIF_INTEGER_32) 3L)) && *(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_))) {
							loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						}
						if (loc10) {
							tr1 = RTOSCF(1789,F110_1789, (Current));
							tr1 = F700_6207(RTCW(tr1), loc3);
							F21_170(RTCW(loc1), tr1);
						} else {
							tr1 = RTOSCF(1789,F110_1789, (Current));
							tr1 = F700_6207(RTCW(tr1), loc3);
							F21_169(RTCW(loc1), tr1);
						}
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
						loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
					}
				}
			} else {
				loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 92L))) {
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_);
					ti4_1 = (EIF_INTEGER_32) tu4_1;
					loc4 = F1562_16013(Current, ti4_1, (EIF_BOOLEAN) 1);
					if ((EIF_BOOLEAN)((EIF_INTEGER_32) -loc4 == ((EIF_INTEGER_32) 3L))) {
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
						loc4 = (EIF_INTEGER_32) loc7;
					} else {
						if ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 0L))) {
							loc5++;
							loc6 = (EIF_INTEGER_32) loc4;
							switch ((EIF_INTEGER_32) -loc4) {
								case 5L:
									tr1 = RTOSCF(1778,F110_1778, (Current));
									F21_169(RTCW(loc1), tr1);
									break;
								case 4L:
									tr1 = RTOSCF(1778,F110_1778, (Current));
									F21_170(RTCW(loc1), tr1);
									break;
								case 9L:
									F21_169(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
									break;
								case 8L:
									F21_170(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
									break;
								case 7L:
									tr1 = RTOSCF(1786,F110_1786, (Current));
									F21_169(RTCW(loc1), tr1);
									break;
								case 6L:
									tr1 = RTOSCF(1786,F110_1786, (Current));
									F21_170(RTCW(loc1), tr1);
									break;
								default:
									tr1 = RTOSCF(119,F19_119, (Current));
									ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
									F1562_15980(Current, tr1, ((EIF_INTEGER_32) 7L), ti4_1);
									break;
							}
						} else {
							loc7 = (EIF_INTEGER_32) loc4;
						}
					}
				}
				if ((EIF_BOOLEAN) (loc4 >= ((EIF_INTEGER_32) 0L))) {
					tb2 = '\0';
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					ti4_1 = F1137_10163(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) + ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 45L))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						ti4_1 = F1137_10163(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) + ((EIF_INTEGER_32) 2L)));
						tb2 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 93L));
					}
					if (tb2) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_)) += ((EIF_INTEGER_32) 2L);
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_))) {
							tr1 = RTOSCF(118,F19_118, (Current));
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
							F1562_15980(Current, tr1, ((EIF_INTEGER_32) 6L), ti4_1);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
							loc8 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
							loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
							if ((EIF_BOOLEAN)(loc8 == ((EIF_INTEGER_32) 92L))) {
								tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_);
								ti4_1 = (EIF_INTEGER_32) tu4_1;
								loc4 = F1562_16013(Current, ti4_1, (EIF_BOOLEAN) 1);
								if ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 0L))) {
									if ((EIF_BOOLEAN)(loc4 == (EIF_INTEGER_32) -((EIF_INTEGER_32) 3L))) {
										loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
									} else {
										*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 2L));
										loc8 = (EIF_INTEGER_32) loc7;
									}
								} else {
									loc8 = (EIF_INTEGER_32) loc4;
								}
							}
							if ((EIF_BOOLEAN) (loc8 < loc7)) {
								tr1 = RTOSCF(120,F19_120, (Current));
								ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
								F1562_15980(Current, tr1, ((EIF_INTEGER_32) 8L), ti4_1);
							} else {
								F21_168(RTCW(loc1), loc8);
								if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_)) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									ti4_1 = F22_177(RTCW(tr1), loc8);
									F21_168(RTCW(loc1), ti4_1);
								}
								loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + loc8) - loc7) + ((EIF_INTEGER_32) 1L));
								loc6 = (EIF_INTEGER_32) loc8;
								for (;;) {
									if ((EIF_BOOLEAN) (loc7 >= loc8)) break;
									F21_168(RTCW(loc1), loc7);
									if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_)) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										ti4_1 = F22_177(RTCW(tr1), loc7);
										F21_168(RTCW(loc1), ti4_1);
									}
									loc7++;
								}
							}
						}
					} else {
						F21_168(RTCW(loc1), loc7);
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							ti4_1 = F22_177(RTCW(tr1), loc7);
							F21_168(RTCW(loc1), ti4_1);
						}
						loc5++;
						loc6 = (EIF_INTEGER_32) loc7;
					}
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		if ((EIF_BOOLEAN)(tr1 == RTOSCF(149,F19_149, (Current)))) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			loc7 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
		}
	}
	if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 1L))) {
		if ((EIF_BOOLEAN) (loc6 < ((EIF_INTEGER_32) 0L))) {
			if (loc9) {
				if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) -loc6 % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 0L))) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F18_99(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) -loc6 + ((EIF_INTEGER_32) 1L)));
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F18_99(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) -loc6 - ((EIF_INTEGER_32) 1L)));
				}
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_99(RTCW(tr1), (EIF_INTEGER_32) -loc6);
			}
		} else {
			if (loc9) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_99(RTCW(tr1), ((EIF_INTEGER_32) 17L));
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_99(RTCW(tr1), ((EIF_INTEGER_32) 16L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_101(RTCW(tr1), ((EIF_INTEGER_32) 1L));
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F18_100(RTCW(tr1), loc6);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F18_99(RTCW(tr1), ((EIF_INTEGER_32) 53L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F18_102(RTCW(tr1), loc1, loc9);
	}
	RTLE;
}

/* {COMPILER}.compile_repeats */
void F1562_16004 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc14 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc15 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc14 = *(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_);
	loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc14;
	loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc14;
	loc3 = (EIF_INTEGER_32) arg1;
	loc4 = (EIF_INTEGER_32) arg2;
	loc8 = (EIF_INTEGER_32) arg3;
	if ((EIF_BOOLEAN)(loc8 == ((EIF_INTEGER_32) 0L))) {
		tr1 = RTOSCF(121,F19_121, (Current));
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
		F1562_15980(Current, tr1, ((EIF_INTEGER_32) 9L), ti4_1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		ti4_1 = F1137_10163(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) + ((EIF_INTEGER_32) 1L)));
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 63L))) {
			if (loc15) {
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			} else {
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			}
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
		} else {
			if (loc14) {
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			} else {
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc5 = F18_87(RTCW(tr1), loc8);
		if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 16L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc7 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
			if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) arg4;
			}
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) + loc3) - ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 1L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc13 = F18_88(RTCW(tr1), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 2L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_95(RTCW(tr1), loc8);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc13 = F18_88(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc8 + loc7) + ((EIF_INTEGER_32) 1L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_1 = F18_89(RTCW(tr2), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
				F18_98(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_2_0_0_0_);
				F18_95(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
			}
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
				F1562_16005(Current, loc13, loc8, loc3, loc4, loc2, loc1);
			}
		} else {
			if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 17L))) {
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 27L) - ((EIF_INTEGER_32) 18L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc13 = F18_88(RTCW(tr1), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_95(RTCW(tr1), loc8);
				if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
					F1562_16005(Current, loc13, loc8, loc3, loc4, loc2, loc1);
				}
			} else {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc5 < ((EIF_INTEGER_32) 10L)) || (EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 15L)))) {
					loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 36L) - ((EIF_INTEGER_32) 18L));
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc13 = F18_88(RTCW(tr1), loc8);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F18_95(RTCW(tr1), loc8);
					if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
						F1562_16005(Current, loc13, loc8, loc3, loc4, loc2, loc1);
					}
				} else {
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 53L)) || (EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 54L)))) {
						if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							F18_95(RTCW(tr1), loc8);
						} else {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L)))) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								F18_99(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 45L) + loc1));
							} else {
								if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L)))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F18_99(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 47L) + loc1));
								} else {
									if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 1L)))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F18_99(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 49L) + loc1));
									} else {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F18_99(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 51L) + loc1));
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F18_101(RTCW(tr1), loc3);
										if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L))) {
											loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F18_101(RTCW(tr1), ((EIF_INTEGER_32) 0L));
										} else {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F18_101(RTCW(tr1), loc4);
										}
									}
								}
							}
						}
					} else {
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc5 >= ((EIF_INTEGER_32) 70L)) || (EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 65L))) || (EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 66L)))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							loc7 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
							loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 - loc8);
							if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L))) {
								loc6 = (EIF_INTEGER_32) loc8;
								for (;;) {
									if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 57L))) break;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									ti4_1 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)));
									loc6 += ti4_1;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									loc5 = F18_87(RTCW(tr1), loc6);
								}
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								loc9 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
								loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 - loc6);
							}
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
								if ((EIF_BOOLEAN) (arg5 > ((EIF_INTEGER_32) 0L))) {
									*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) arg4;
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_)) -= arg5;
								}
								if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F18_95(RTCW(tr1), loc8);
								} else {
									if ((EIF_BOOLEAN) (loc4 <= ((EIF_INTEGER_32) 1L))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F18_104(RTCW(tr1), loc8, ((EIF_INTEGER_32) 1L));
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F18_96(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 68L) + loc1), loc8);
										loc8++;
									} else {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F18_104(RTCW(tr1), loc8, ((EIF_INTEGER_32) 3L));
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F18_96(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 68L) + loc1), loc8);
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F18_96(RTCW(tr1), ((EIF_INTEGER_32) 70L), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
										loc8 += ((EIF_INTEGER_32) 2L);
										if ((EIF_BOOLEAN)(loc12 == ((EIF_INTEGER_32) 0L))) {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F18_98(RTCW(tr1), ((EIF_INTEGER_32) 0L), loc8);
										} else {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F18_98(RTCW(tr1), (EIF_INTEGER_32) (loc8 - loc12), loc8);
										}
										loc12 = (EIF_INTEGER_32) loc8;
										loc8++;
									}
									loc4--;
								}
							} else {
								loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								for (;;) {
									if ((EIF_BOOLEAN) (loc6 >= loc3)) break;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F18_103(RTCW(tr1), loc8, loc7);
									loc6++;
								}
								if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
									loc4 -= loc3;
								}
							}
							if ((EIF_BOOLEAN) (loc4 >= ((EIF_INTEGER_32) 0L))) {
								loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L));
								for (;;) {
									if ((EIF_BOOLEAN) (loc6 < ((EIF_INTEGER_32) 0L))) break;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F18_99(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 68L) + loc1));
									if ((EIF_BOOLEAN)(loc6 != ((EIF_INTEGER_32) 0L))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F18_99(RTCW(tr1), ((EIF_INTEGER_32) 70L));
										if ((EIF_BOOLEAN)(loc12 == ((EIF_INTEGER_32) 0L))) {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											loc12 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F18_101(RTCW(tr1), ((EIF_INTEGER_32) 0L));
										} else {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											loc10 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
											loc10 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc10 - loc12);
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											loc12 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F18_101(RTCW(tr1), loc10);
										}
									}
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F18_103(RTCW(tr1), loc8, loc7);
									loc6--;
								}
								for (;;) {
									if ((EIF_BOOLEAN)(loc12 == ((EIF_INTEGER_32) 0L))) break;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									loc10 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
									loc10 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc10 - loc12) + ((EIF_INTEGER_32) 1L));
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
									loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 - loc10) + ((EIF_INTEGER_32) 1L));
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									loc11 = F18_89(RTCW(tr1), loc6);
									if ((EIF_BOOLEAN)(loc11 == ((EIF_INTEGER_32) 0L))) {
										loc12 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
									} else {
										loc12 -= loc11;
									}
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F18_99(RTCW(tr1), ((EIF_INTEGER_32) 57L));
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F18_101(RTCW(tr1), loc10);
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F18_98(RTCW(tr1), loc10, loc6);
								}
							} else {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_2_0_0_0_);
								F18_96(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 58L) + loc1), (EIF_INTEGER_32) (ti4_1 - loc9));
							}
						} else {
							tr1 = RTOSCF(123,F19_123, (Current));
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
							F1562_15980(Current, tr1, ((EIF_INTEGER_32) 11L), ti4_1);
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {COMPILER}.compile_single_repeat */
void F1562_16005 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg6 + arg5);
	if ((EIF_BOOLEAN)(arg3 == ((EIF_INTEGER_32) 0L))) {
		if ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) -1L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F18_99(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 18L) + loc1));
		} else {
			if ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 1L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_99(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 22L) + loc1));
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_99(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 24L) + loc1));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_101(RTCW(tr1), arg4);
			}
		}
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg3 == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) -1L)))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F18_99(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 20L) + loc1));
		} else {
			if ((EIF_BOOLEAN)(arg3 != ((EIF_INTEGER_32) 1L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_99(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 26L) + arg5));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_101(RTCW(tr1), arg3);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_95(RTCW(tr1), (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_1 = F18_87(RTCW(tr1), arg2);
				switch (ti4_1) {
					case 16L:
						if ((EIF_BOOLEAN)(loc2 == arg2)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							F18_95(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							F18_95(RTCW(tr1), loc2);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							ti4_1 = F18_89(RTCW(tr2), (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
							F18_98(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
						}
						break;
					case 17L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F18_95(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
						break;
					default:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F18_95(RTCW(tr1), loc2);
						break;
				}
			}
			if ((EIF_BOOLEAN) (arg4 < ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_100(RTCW(tr1), arg1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F18_99(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 18L) + loc1));
			} else {
				if ((EIF_BOOLEAN)(arg4 != arg3)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F18_100(RTCW(tr1), arg1);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F18_99(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 24L) + loc1));
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F18_101(RTCW(tr1), (EIF_INTEGER_32) (arg4 - arg3));
				}
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F18_100(RTCW(tr1), arg1);
	RTLE;
}

/* {COMPILER}.compile_counted_repeats */
EIF_BOOLEAN F1562_16006 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc4 = F1137_10163(RTCW(tr1), loc3);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 48L)) || (EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 57L)))) break;
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 10L)) + loc4) - ((EIF_INTEGER_32) 48L));
		loc3++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc4 = F1137_10163(RTCW(tr1), loc3);
	}
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 65535L))) {
		tr1 = RTOSCF(117,F19_117, (Current));
		F1562_15980(Current, tr1, ((EIF_INTEGER_32) 5L), loc3);
	} else {
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_)) > ((EIF_INTEGER_32) 1L))) {
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 125L))) {
				loc2 = (EIF_INTEGER_32) loc1;
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 44L))) {
					loc3++;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					loc4 = F1137_10163(RTCW(tr1), loc3);
					if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 125L))) {
						loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						for (;;) {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 48L)) || (EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 57L)))) break;
							loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 * ((EIF_INTEGER_32) 10L)) + loc4) - ((EIF_INTEGER_32) 48L));
							loc3++;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
							loc4 = F1137_10163(RTCW(tr1), loc3);
						}
					}
					if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 125L))) {
						if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 65535L))) {
							tr1 = RTOSCF(117,F19_117, (Current));
							F1562_15980(Current, tr1, ((EIF_INTEGER_32) 5L), loc3);
						} else {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc1 > loc2))) {
								tr1 = RTOSCF(116,F19_116, (Current));
								F1562_15980(Current, tr1, ((EIF_INTEGER_32) 4L), loc3);
							} else {
								Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							}
						}
					}
				}
			}
		}
	}
	if (Result) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) loc3;
		F1562_16004(Current, loc1, loc2, arg1, arg2, arg3);
	}
	RTLE;
	return Result;
}

/* {COMPILER}.check_posix_syntax */
EIF_INTEGER_32 F1562_16007 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTOSCF(1777,F110_1777, (Current));
	loc2 = (EIF_INTEGER_32) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = F1137_10163(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	ti4_1 = F1137_10163(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 94L))) {
		loc2 += ((EIF_INTEGER_32) 3L);
	} else {
		loc2 += ((EIF_INTEGER_32) 2L);
	}
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		ti4_1 = F1137_10163(RTCW(tr1), loc2);
		tb1 = F21_166(RTCW(loc1), ti4_1);
		if ((EIF_BOOLEAN) !tb1) break;
		loc2++;
	}
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	ti4_1 = F1137_10163(RTCW(tr1), loc2);
	if ((EIF_BOOLEAN)(ti4_1 == loc3)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		ti4_1 = F1137_10163(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
		tb2 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 93L));
	}
	if (tb2) {
		RTLE;
		return (EIF_INTEGER_32) loc2;
	} else {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}/* NOTREACHED */
	
}

/* {COMPILER}.check_posix_name */
EIF_INTEGER_32 F1562_16008 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc4 = F700_6214(RTCV(RTOSCF(1788,F110_1788, (Current))));
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc4)) break;
		tr1 = RTOSCF(1788,F110_1788, (Current));
		loc5 = F700_6207(RTCW(tr1), loc1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(arg2 == ti4_1)) {
			Result = (EIF_INTEGER_32) loc1;
			loc3 = (EIF_INTEGER_32) arg1;
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc2 > arg2)) break;
				ti4_1 = F1137_10163(RTCW(loc5), loc2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				ti4_2 = F1137_10163(RTCW(tr1), loc3);
				if ((EIF_BOOLEAN)(ti4_1 != ti4_2)) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
				} else {
					loc2++;
					loc3++;
				}
			}
		}
		if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) -1L))) {
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
		} else {
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {COMPILER}.scan_decimal_number */
EIF_INTEGER_32 F1562_16009 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 57L)) || (EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 48L))) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) >= loc2))) break;
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (Result * ((EIF_INTEGER_32) 10L)) + loc1) - ((EIF_INTEGER_32) 48L));
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	}
	RTLE;
	return Result;
}

/* {COMPILER}.scan_octal_number */
EIF_INTEGER_32 F1562_16010 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 55L)) || (EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 48L))) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) >= loc2))) break;
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (Result * ((EIF_INTEGER_32) 8L)) + loc1) - ((EIF_INTEGER_32) 48L));
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	}
	RTLE;
	return Result;
}

/* {COMPILER}.scan_hex_number */
EIF_INTEGER_32 F1562_16011 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	for (;;) {
		tb1 = '\01';
		tr1 = RTOSCF(1780,F110_1780, (Current));
		tb2 = F21_166(RTCW(tr1), loc1);
		if (!(EIF_BOOLEAN) !tb2) {
			tb1 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) >= loc2);
		}
		if (tb1) break;
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 65L))) {
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (Result * ((EIF_INTEGER_32) 16L)) + loc1) - ((EIF_INTEGER_32) 48L));
		} else {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 97L))) {
				Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (Result * ((EIF_INTEGER_32) 16L)) + loc1) - ((EIF_INTEGER_32) 65L)) + ((EIF_INTEGER_32) 10L));
			} else {
				Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (Result * ((EIF_INTEGER_32) 16L)) + loc1) - ((EIF_INTEGER_32) 97L)) + ((EIF_INTEGER_32) 10L));
			}
		}
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	}
	RTLE;
	return Result;
}

/* {COMPILER}.scan_comment */
void F1562_16012 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == loc2)) break;
		loc1 = (EIF_INTEGER_32) loc2;
		for (;;) {
			tr1 = RTOSCF(1786,F110_1786, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			ti4_1 = F1137_10163(RTCW(tr2), loc2);
			tb1 = F21_166(RTCW(tr1), ti4_1);
			if ((EIF_BOOLEAN) !tb1) break;
			loc2++;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		ti4_1 = F1137_10163(RTCW(tr1), loc2);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 35L))) {
			loc2++;
			for (;;) {
				tb2 = '\01';
				if (!(EIF_BOOLEAN) (loc2 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_))) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					ti4_1 = F1137_10163(RTCW(tr1), loc2);
					tb2 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 10L));
				}
				if (tb2) break;
				loc2++;
			}
		}
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) loc2;
	RTLE;
}

/* {COMPILER}.scan_escape */
EIF_INTEGER_32 F1562_16013 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc2 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_))) {
		tr1 = RTOSCF(113,F19_113, (Current));
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
		F1562_15980(Current, tr1, ((EIF_INTEGER_32) 1L), ti4_1);
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 48L)) || (EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 122L)))) {
			RTLE;
			return (EIF_INTEGER_32) loc2;
		} else {
			Result = F1562_16019(Current, loc2);
			if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
				switch (loc2) {
					case 49L:
					case 50L:
					case 51L:
					case 52L:
					case 53L:
					case 54L:
					case 55L:
					case 56L:
					case 57L:
						if ((EIF_BOOLEAN) !arg2) {
							loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
							Result = F1562_16009(Current, ((EIF_INTEGER_32) 10L));
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 10L)) || (EIF_BOOLEAN) (Result <= arg1))) {
								tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_4_);
								ti4_1 = (EIF_INTEGER_32) tu4_1;
								if ((EIF_BOOLEAN) (Result > ti4_1)) {
									tu4_1 = (EIF_NATURAL_32) Result;
									*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_4_) = (EIF_NATURAL_32) tu4_1;
								}
								Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -(EIF_INTEGER_32) (((EIF_INTEGER_32) 12L) + Result);
							} else {
								*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) loc1;
								if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 56L))) {
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								} else {
									Result = F1562_16010(Current, ((EIF_INTEGER_32) 3L));
									Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 256L));
								}
							}
						} else {
							if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 56L))) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
							} else {
								Result = F1562_16010(Current, ((EIF_INTEGER_32) 3L));
								Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 256L));
							}
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))--;
						break;
					case 48L:
						Result = F1562_16010(Current, ((EIF_INTEGER_32) 3L));
						Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 256L));
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))--;
						break;
					case 120L:
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
						Result = F1562_16011(Current, ((EIF_INTEGER_32) 2L));
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))--;
						break;
					case 99L:
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						loc2 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_))) {
							tr1 = RTOSCF(114,F19_114, (Current));
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
							F1562_15980(Current, tr1, ((EIF_INTEGER_32) 2L), ti4_1);
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						} else {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_INTEGER_32) 97L) <= loc2) && (EIF_BOOLEAN) (loc2 <= ((EIF_INTEGER_32) 122L)))) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								ti4_1 = F22_177(RTCW(tr1), loc2);
								loc2 = (EIF_INTEGER_32) ti4_1;
							}
							if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 64L))) {
								Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 64L));
							} else {
								if ((EIF_BOOLEAN) (loc2 <= ((EIF_INTEGER_32) 127L))) {
									Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 64L));
								} else {
									Result = (EIF_INTEGER_32) loc2;
								}
							}
						}
						break;
					default:
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_10_)) {
							tr1 = RTOSCF(115,F19_115, (Current));
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
							F1562_15980(Current, tr1, ((EIF_INTEGER_32) 3L), ti4_1);
						}
						Result = (EIF_INTEGER_32) loc2;
						break;
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {COMPILER}.first_significant_code */
EIF_INTEGER_32 F1562_16014 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = (EIF_INTEGER_32) arg1;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_);
	for (;;) {
		if (loc3) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = F18_87(RTCW(tr1), loc1);
		switch (ti4_1) {
			case 12L:
				switch (arg2) {
					case 1L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc4 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						if ((EIF_BOOLEAN)(F111_1791(Current, loc4) != F111_1791(Current, Result))) {
							if (arg3) {
								loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								Result = (EIF_INTEGER_32) loc4;
								loc1 += ((EIF_INTEGER_32) 2L);
							}
						} else {
							loc1 += ((EIF_INTEGER_32) 2L);
						}
						break;
					case 2L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc4 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						if ((EIF_BOOLEAN)(F111_1792(Current, loc4) != F111_1792(Current, Result))) {
							if (arg3) {
								loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								Result = (EIF_INTEGER_32) loc4;
								loc1 += ((EIF_INTEGER_32) 2L);
							}
						} else {
							loc1 += ((EIF_INTEGER_32) 2L);
						}
						break;
					default:
						loc1 += ((EIF_INTEGER_32) 2L);
						break;
				}
				break;
			case 67L:
				loc1 += ((EIF_INTEGER_32) 2L);
				break;
			case 2L:
			case 3L:
				loc1++;
				break;
			case 61L:
			case 62L:
			case 63L:
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
				for (;;) {
					if ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 56L))) break;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
					loc1 += ti4_1;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc2 = F18_87(RTCW(tr1), loc1);
				}
				loc1 += ((EIF_INTEGER_32) 2L);
				break;
			default:
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				break;
		}
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) loc1;
	RTLE;
	return Result;
}

/* {COMPILER}.find_firstchar */
EIF_INTEGER_32 F1562_16015 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_);
	Result = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 56L)) || loc4)) break;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L));
		ti4_1 = F1562_16014(Current, Result, ((EIF_INTEGER_32) 1L), (EIF_BOOLEAN) 1);
		Result = (EIF_INTEGER_32) ti4_1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = F18_87(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_));
		if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 70L))) {
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
		}
		switch (loc2) {
			case 60L:
			case 65L:
			case 66L:
			case 70L:
				loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_);
				ti4_1 = F1562_16015(Current, Result);
				Result = (EIF_INTEGER_32) ti4_1;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) < ((EIF_INTEGER_32) 0L))) {
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) {
					} else {
						if ((EIF_BOOLEAN)(loc3 != *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_))) {
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						}
					}
				}
				break;
			case 16L:
			case 20L:
			case 21L:
			case 26L:
				if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 26L))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_))++;
				} else {
					if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 16L))) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_))++;
					}
				}
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) < ((EIF_INTEGER_32) 0L))) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F18_88(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) + ((EIF_INTEGER_32) 1L)));
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) = (EIF_INTEGER_32) ti4_1;
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F18_88(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) + ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) != ti4_1)) {
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
				break;
			default:
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				break;
		}
		if ((EIF_BOOLEAN) !loc4) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			ti4_1 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			loc1 += ti4_1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc2 = F18_87(RTCW(tr1), loc1);
		}
	}
	RTLE;
	return Result;
}

/* {COMPILER}.can_anchored */
EIF_BOOLEAN F1562_16016 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc3 = (EIF_INTEGER_32) arg1;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 56L)) || (EIF_BOOLEAN) !Result)) break;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L));
		ti4_1 = F1562_16014(Current, loc3, ((EIF_INTEGER_32) 2L), (EIF_BOOLEAN) 0);
		loc3 = (EIF_INTEGER_32) ti4_1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = F18_87(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_));
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 70L)) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 60L))) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 65L))) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 66L)))) {
			Result = F1562_16016(Current, loc3);
		} else {
			tb1 = '\0';
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 36L)) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 37L)))) {
				tb1 = F111_1793(Current, loc3);
			}
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_1 = F18_87(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) + ((EIF_INTEGER_32) 1L)));
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 15L));
			} else {
				Result = '\01';
				if (!(EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 1L))) {
					tb1 = '\0';
					if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 13L))) {
						tb1 = (EIF_BOOLEAN) !F111_1792(Current, loc3);
					}
					Result = tb1;
				}
			}
		}
		if (Result) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			ti4_1 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			loc1 += ti4_1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc2 = F18_87(RTCW(tr1), loc1);
		}
	}
	RTLE;
	return Result;
}

/* {COMPILER}.has_startline */
EIF_BOOLEAN F1562_16017 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 56L)) || (EIF_BOOLEAN) !Result)) break;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L));
		ti4_1 = F1562_16014(Current, loc3, ((EIF_INTEGER_32) 0L), (EIF_BOOLEAN) 0);
		loc3 = (EIF_INTEGER_32) ti4_1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = F18_87(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_));
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 70L)) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 60L))) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 65L))) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 66L)))) {
			Result = F1562_16017(Current);
		} else {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 36L)) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 37L)))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_1 = F18_87(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) + ((EIF_INTEGER_32) 1L)));
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 15L));
			} else {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 13L));
			}
		}
		if (Result) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			ti4_1 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			loc1 += ti4_1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc2 = F18_87(RTCW(tr1), loc1);
		}
	}
	RTLE;
	return Result;
}

/* {COMPILER}.escape_character */
EIF_INTEGER_32 F1562_16019 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	switch (arg1) {
		case 58L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 58L);
			break;
		case 59L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 59L);
			break;
		case 60L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
			break;
		case 61L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
			break;
		case 62L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 62L);
			break;
		case 63L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 63L);
			break;
		case 64L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 64L);
			break;
		case 65L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 1L);
			break;
		case 66L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 2L);
			break;
		case 68L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 4L);
			break;
		case 83L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 6L);
			break;
		case 87L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 8L);
			break;
		case 90L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 10L);
			break;
		case 91L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 91L);
			break;
		case 92L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 92L);
			break;
		case 93L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 93L);
			break;
		case 124L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 124L);
			break;
		case 95L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 95L);
			break;
		case 96L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 96L);
			break;
		case 97L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			break;
		case 98L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 3L);
			break;
		case 100L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 5L);
			break;
		case 101L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 27L);
			break;
		case 102L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
			break;
		case 110L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
			break;
		case 114L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
			break;
		case 115L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 7L);
			break;
		case 116L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
			break;
		case 119L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 9L);
			break;
		case 122L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 11L);
			break;
		default:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			break;
	}
	return Result;
}

/* {COMPILER}.empty_pattern */
static EIF_REFERENCE F1562_16020_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (16020);
#define Result RTOSR(16020)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("T",1,84);
	F1137_10180(RTCW(Result), (EIF_CHARACTER_8) '\000', ((EIF_INTEGER_32) 1L));
	RTOSE (16020);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1562_16020 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16020,F1562_16020_body,(Current));
}

/* {COMPILER}.actual_set */
static EIF_REFERENCE F1562_16021_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (16021);
#define Result RTOSR(16021)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(20, 0x01).id, 20, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F21_163(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (16021);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1562_16021 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16021,F1562_16021_body,(Current));
}

/* {COMPILER}.infinity */
static EIF_INTEGER_32 F1562_16022_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (16022);
#define Result RTOSR(16022)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	RTOSE (16022);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1562_16022 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16022,F1562_16022_body,(Current));
}

/* {COMPILER}.maxlit */
static EIF_INTEGER_32 F1562_16023_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (16023);
#define Result RTOSR(16023)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	RTOSE (16023);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1562_16023 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16023,F1562_16023_body,(Current));
}

void EIF_Minit806 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
