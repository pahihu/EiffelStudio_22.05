
#ifndef _C17_fi843_
#define _C17_fi843_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F550_5957(EIF_REFERENCE);
extern void EIF_Minit843(void);
extern char *(*R5639[])();

#ifdef __cplusplus
}
#endif

#endif
