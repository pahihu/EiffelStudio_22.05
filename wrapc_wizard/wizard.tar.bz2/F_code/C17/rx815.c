/*
 * Code for class RX_PCRE_MATCHER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "rx815.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RX_PCRE_MATCHER}.make */
void F1571_16391 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1570_16303(Current);
	tr1 = RTOSCF(4459,F289_4459, (Current));
	tr1 = F27_196(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 64L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_15_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_19_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	tr1 = RTOSCF(4459,F289_4459, (Current));
	tr1 = F27_196(RTCW(tr1), ((EIF_INTEGER_32) 0L), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_19_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_17_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_18_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_22_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	tr1 = RTOSCF(4459,F289_4459, (Current));
	tr1 = F27_196(RTCW(tr1), ((EIF_INTEGER_32) 0L), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_22_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_20_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_21_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTLE;
}

/* {RX_PCRE_MATCHER}.reset */
void F1571_16392 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1570_16343(Current);
	F1571_16393(Current);
	RTLE;
}

/* {RX_PCRE_MATCHER}.wipe_out */
void F1571_16393 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1564_16071(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_12_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_);
	RTLE;
}

/* {RX_PCRE_MATCHER}.compile */
void F1571_16394 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1571_16393(Current);
	F1570_16337(Current, arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_15_) = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_9_) * ((EIF_INTEGER_32) 2L)) + ((EIF_INTEGER_32) 2L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
	if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_15_))) {
		tr1 = RTOSCF(4459,F289_4459, (Current));
		tr1 = F27_204(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_9_), ((EIF_INTEGER_32) 0L), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_15_));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {RX_PCRE_MATCHER}.captured_start_position */
EIF_INTEGER_32 F1571_16395 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg1 * ((EIF_INTEGER_32) 2L))));
	/* END INLINED CODE */
	Result = ti4_3;
	RTLE;
	return Result;
}

/* {RX_PCRE_MATCHER}.captured_end_position */
EIF_INTEGER_32 F1571_16396 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 * ((EIF_INTEGER_32) 2L)) + ((EIF_INTEGER_32) 1L))));
	/* END INLINED CODE */
	Result = ti4_3;
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result - ((EIF_INTEGER_32) 1L));
	RTLE;
	return Result;
}

/* {RX_PCRE_MATCHER}.match_substring */
void F1571_16397 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_) = (EIF_INTEGER_32) arg2;
	F1571_16420(Current, arg1, arg2, arg3);
	RTLE;
}

/* {RX_PCRE_MATCHER}.set_next_start */
void F1571_16418 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_12_) = (EIF_INTEGER_32) arg1;
}

/* {RX_PCRE_MATCHER}.set_match_count */
void F1571_16419 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_3_) = (EIF_INTEGER_32) arg1;
}

/* {RX_PCRE_MATCHER}.match_it */
void F1571_16420 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_64 loc1 = (EIF_INTEGER_64) 0;
	EIF_INTEGER_64 loc2 = (EIF_INTEGER_64) 0;
	EIF_INTEGER_64 loc3 = (EIF_INTEGER_64) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_64 ti8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	EIF_BOOLEAN tb7;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc7);
	RTLIU(5);
	
	RTGC;
	F1564_16095(Current, arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_12_) = (EIF_INTEGER_32) arg2;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_) = (EIF_INTEGER_32) arg3;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_) = (EIF_INTEGER_32) arg2;
	loc1 = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) -1L);
	loc2 = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) -1L);
	loc3 = (EIF_INTEGER_64) (EIF_INTEGER_64) ((EIF_INTEGER_32) -1L);
	loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_);
	loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_9_)) {
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_) >= (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_0_)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				ti8_1 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_);
				tu4_1 = (EIF_NATURAL_32) ti8_1;
				tu4_1 = F1557_15807(RTCW(tr1), tu4_1);
				loc1 = (EIF_INTEGER_64) tu4_1;
			} else {
				loc1 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_0_);
			}
		}
	}
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_) >= (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
		loc2 = *(EIF_INTEGER_64 *)(Current+ _I64OFF_12_16_0_23_0_0_1_);
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_0_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_12_12_))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tu4_1 = (EIF_NATURAL_32) loc2;
			tu4_1 = F1557_15809(RTCW(tr1), tu4_1);
			loc3 = (EIF_INTEGER_64) tu4_1;
		} else {
			loc3 = (EIF_INTEGER_64) loc2;
		}
	}
	for (;;) {
		if (loc6) break;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_15_);
		loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - ((EIF_INTEGER_32) 1L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc5 < ((EIF_INTEGER_32) 0L))) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			/* INLINED CODE (SPECIAL.put) */
			*((EIF_INTEGER_32 *)RTCW(tr1) + (loc5)) = ((EIF_INTEGER_32) 0L);
			/* END INLINED CODE */
			;
			loc5--;
		}
		if ((EIF_BOOLEAN) (loc1 >= (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_0_)) {
				for (;;) {
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_) > arg3)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
						tr2 = *(EIF_REFERENCE *)(Current);
						tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_));
						tu4_1 = F1557_15807(RTCW(tr1), tu4_1);
						ti8_1 = (EIF_INTEGER_64) tu4_1;
						tb1 = (EIF_BOOLEAN)(ti8_1 == loc1);
					}
					if (tb1) break;
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_))++;
				}
			} else {
				for (;;) {
					tb2 = '\01';
					if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_) > arg3)) {
						tr1 = *(EIF_REFERENCE *)(Current);
						tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_));
						ti8_1 = (EIF_INTEGER_64) tu4_1;
						tb2 = (EIF_BOOLEAN)(ti8_1 == loc1);
					}
					if (tb2) break;
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_))++;
				}
			}
		} else {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_11_)) {
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_) > arg2)) {
					for (;;) {
						tb3 = '\01';
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_) > arg3)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_) - ((EIF_INTEGER_32) 1L)));
							tb3 = (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 10U));
						}
						if (tb3) break;
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_))++;
					}
				}
			} else {
				loc7 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
				if ((EIF_BOOLEAN)(loc7 != NULL)) {
					for (;;) {
						tb4 = '\01';
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_) > arg3)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_));
							tb5 = F30_209(RTCW(loc7), tu4_1);
							tb4 = tb5;
						}
						if (tb4) break;
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_))++;
					}
				}
			}
		}
		if ((EIF_BOOLEAN) (loc2 >= (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
			if ((EIF_BOOLEAN) (loc1 >= (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
				loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_);
				loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L));
			} else {
				loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_);
			}
			if ((EIF_BOOLEAN) (loc5 > loc4)) {
				if ((EIF_BOOLEAN)(loc2 == loc3)) {
					for (;;) {
						tb5 = '\01';
						if (!(EIF_BOOLEAN) (loc5 > arg3)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, loc5);
							ti8_1 = (EIF_INTEGER_64) tu4_1;
							tb5 = (EIF_BOOLEAN)(ti8_1 == loc2);
						}
						if (tb5) break;
						loc5++;
					}
				} else {
					for (;;) {
						tb6 = '\01';
						tb7 = '\01';
						if (!(EIF_BOOLEAN) (loc5 > arg3)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, loc5);
							ti8_1 = (EIF_INTEGER_64) tu4_1;
							tb7 = (EIF_BOOLEAN)(ti8_1 == loc2);
						}
						if (!tb7) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, loc5);
							ti8_1 = (EIF_INTEGER_64) tu4_1;
							tb6 = (EIF_BOOLEAN)(ti8_1 == loc3);
						}
						if (tb6) break;
						loc5++;
					}
				}
				if ((EIF_BOOLEAN) (loc5 > arg3)) {
					loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					loc4 = (EIF_INTEGER_32) loc5;
				}
			}
		}
		if ((EIF_BOOLEAN) !loc6) {
			if (F1571_16421(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
				/* INLINED CODE (SPECIAL.put) */
				*((EIF_INTEGER_32 *)RTCW(tr1) + (((EIF_INTEGER_32) 0L))) = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_);
				/* END INLINED CODE */
				;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
				/* INLINED CODE (SPECIAL.put) */
				*((EIF_INTEGER_32 *)RTCW(tr1) + (((EIF_INTEGER_32) 1L))) = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_12_);
				/* END INLINED CODE */
				;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_3_)) /= ((EIF_INTEGER_32) 2L);
				loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				loc6 = *(EIF_BOOLEAN *)(Current+ _CHROFF_12_9_);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_);
				loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc6 || (EIF_BOOLEAN) (ti4_1 > arg3));
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_))++;
			}
		}
	}
	RTLE;
}

/* {RX_PCRE_MATCHER}.match_start */
EIF_BOOLEAN F1571_16421 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_20_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_21_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_16_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_18_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_15_);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_17_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_18_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ti4_1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_19_) < loc1)) {
		tr1 = RTOSCF(4459,F289_4459, (Current));
		tr1 = F27_204(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_10_), ((EIF_INTEGER_32) 0L), loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_19_) = (EIF_INTEGER_32) loc1;
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_13_) = (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current+ _CHROFF_12_0_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_14_) = (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current+ _CHROFF_12_3_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_15_) = (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current+ _CHROFF_12_4_);
	ti4_1 = F1571_16423(Current, ((EIF_INTEGER_32) 0L), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L));
	RTLE;
	return Result;
}

/* {RX_PCRE_MATCHER}.match_recursive */
EIF_INTEGER_32 F1571_16422 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_);
	loc3 = *(EIF_BOOLEAN *)(Current+ _CHROFF_12_13_);
	loc4 = *(EIF_BOOLEAN *)(Current+ _CHROFF_12_15_);
	loc5 = *(EIF_BOOLEAN *)(Current+ _CHROFF_12_14_);
	loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_16_);
	loc7 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_21_);
	Result = F1571_16423(Current, arg1, arg2, arg3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) = (EIF_INTEGER_32) loc1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) = (EIF_INTEGER_32) loc2;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_13_) = (EIF_BOOLEAN) loc3;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_15_) = (EIF_BOOLEAN) loc4;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_14_) = (EIF_BOOLEAN) loc5;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_16_) = (EIF_INTEGER_32) loc6;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_21_) = (EIF_INTEGER_32) loc7;
	RTLE;
	return Result;
}

/* {RX_PCRE_MATCHER}.match_internal */
EIF_INTEGER_32 F1571_16423 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc7 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc14 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc15 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 tu4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc2 = (EIF_INTEGER_32) arg1;
	if (arg2) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_21_))++;
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_22_) <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_21_))) {
			loc14 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_21_);
			loc14 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * (EIF_INTEGER_32) (loc14 + ((EIF_INTEGER_32) 1L)));
			tr1 = RTOSCF(4459,F289_4459, (Current));
			tr1 = F27_204(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_11_), ((EIF_INTEGER_32) 0L), loc14);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_22_) = (EIF_INTEGER_32) loc14;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_21_))) = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
		/* END INLINED CODE */
		;
	}
	for (;;) {
		if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1467_14894(RTCW(tr1), loc2);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_NATURAL_32) 70U))) {
			ti4_1 = (EIF_INTEGER_32) (EIF_NATURAL_32) (loc1 - ((EIF_NATURAL_32) 70U));
			Result = F1571_16424(Current, loc2, ti4_1);
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_);
		} else {
			switch (loc1) {
				case 70U:
					Result = F1571_16425(Current, loc2);
					if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					}
					break;
				case 66U:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_1 = F1467_14894(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
					if ((EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 67U))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 3L)));
						loc5 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (tu4_1 * (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L)));
						tb1 = '\0';
						if ((EIF_BOOLEAN) (loc5 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_16_))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
							/* INLINED CODE (SPECIAL.item) */
							ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
							/* END INLINED CODE */
							ti4_1 = ti4_2;
							tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
						}
						if (tb1) {
							Result = F1571_16422(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 4L)), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
							ti4_1 = (EIF_INTEGER_32) tu4_1;
							Result = F1571_16422(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)) + ti4_1), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
						}
					} else {
						Result = F1571_16422(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 1);
						if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 1L))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 3L)));
							ti4_1 = (EIF_INTEGER_32) tu4_1;
							loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)) + ti4_1);
							for (;;) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tu4_1 = F1467_14894(RTCW(tr1), loc2);
								if ((EIF_BOOLEAN)(tu4_1 != ((EIF_NATURAL_32) 56U))) break;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
								ti4_1 = (EIF_INTEGER_32) tu4_2;
								loc2 += ti4_1;
							}
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
							ti4_1 = (EIF_INTEGER_32) tu4_2;
							loc2 += ti4_1;
						}
						Result = F1571_16422(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
					}
					break;
				case 67U:
					loc2 += ((EIF_INTEGER_32) 2L);
					break;
				case 0U:
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_5_) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_13_)))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						F1571_16418(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
						F1571_16419(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_16_));
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					}
					break;
				case 12U:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					loc7 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					tb1 = F122_1878(Current, loc7);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_12_13_) = (EIF_BOOLEAN) tb1;
					tb1 = F122_1879(Current, loc7);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_12_14_) = (EIF_BOOLEAN) tb1;
					tb1 = F122_1880(Current, loc7);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_12_15_) = (EIF_BOOLEAN) tb1;
					loc2 += ((EIF_INTEGER_32) 2L);
					break;
				case 60U:
				case 62U:
					loc12 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_20_);
					loc13 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_21_);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_20_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc13 + ((EIF_INTEGER_32) 1L));
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_21_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_20_) - ((EIF_INTEGER_32) 1L));
					Result = F1571_16425(Current, loc2);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_20_) = (EIF_INTEGER_32) loc12;
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_21_) = (EIF_INTEGER_32) loc13;
					loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_2 = F1467_14894(RTCW(tr1), loc2);
					if ((EIF_BOOLEAN)(tu4_2 == ((EIF_NATURAL_32) 57U))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						if (arg3) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
							loc1 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 56U);
							for (;;) {
								if ((EIF_BOOLEAN)(loc1 != ((EIF_NATURAL_32) 56U))) break;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
								ti4_1 = (EIF_INTEGER_32) tu4_2;
								loc2 += ti4_1;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								loc1 = F1467_14894(RTCW(tr1), loc2);
							}
							loc2 += ((EIF_INTEGER_32) 2L);
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_16_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_3_);
						}
					}
					break;
				case 61U:
				case 63U:
					if ((EIF_BOOLEAN)(F1571_16425(Current, loc2) == ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						if (arg3) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_);
							loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L));
						}
					}
					break;
				case 64U:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					ti4_1 = (EIF_INTEGER_32) tu4_2;
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_)) -= ti4_1;
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2 += ((EIF_INTEGER_32) 2L);
					}
					break;
				case 55U:
					loc11 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_17_);
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_17_)) += *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_18_);
					loc15 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_17_);
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_18_);
					loc15 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc15 + ti4_1);
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_19_) < loc15)) {
						tr1 = RTOSCF(4459,F289_4459, (Current));
						tr1 = F27_204(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_10_), ((EIF_INTEGER_32) 0L), loc15);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_19_) = (EIF_INTEGER_32) loc15;
					}
					loc9 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_17_);
					loc10 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_18_);
					loc10 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc11 + loc10) - ((EIF_INTEGER_32) 1L));
					loc8 = (EIF_INTEGER_32) loc11;
					for (;;) {
						if ((EIF_BOOLEAN) (loc8 > loc10)) break;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr2) + (loc8));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						/* INLINED CODE (SPECIAL.put) */
						*((EIF_INTEGER_32 *)RTCW(tr1) + (loc9)) = ti4_1;
						/* END INLINED CODE */
						;
						loc9++;
						loc8++;
					}
					loc5 = F1571_16422(Current, ((EIF_INTEGER_32) 0L), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_17_) = (EIF_INTEGER_32) loc11;
					if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 1L))) {
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_16_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_3_);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_12_);
						loc2++;
					} else {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					}
					break;
				case 65U:
					loc5 = (EIF_INTEGER_32) loc2;
					loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
					loc3 = F1571_16425(Current, loc2);
					loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					loc1 = F1467_14894(RTCW(tr1), loc2);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != ((EIF_NATURAL_32) 65U)) && (EIF_BOOLEAN)(loc1 != ((EIF_NATURAL_32) 56U)))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc1 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 56U);
						for (;;) {
							if ((EIF_BOOLEAN)(loc1 != ((EIF_NATURAL_32) 56U))) break;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
							ti4_1 = (EIF_INTEGER_32) tu4_2;
							loc2 += ti4_1;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							loc1 = F1467_14894(RTCW(tr1), loc2);
						}
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_16_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_3_);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_12_);
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 57U)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) == loc6))) {
							loc2 += ((EIF_INTEGER_32) 2L);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tu4_2 = F1467_14894(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
							if ((EIF_BOOLEAN)(tu4_2 == ((EIF_NATURAL_32) 12U))) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 3L)));
								F1570_16334(Current, tu4_2);
							}
							if ((EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 59U))) {
								Result = F1571_16422(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)), (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
								if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 1L))) {
									Result = F1571_16422(Current, loc5, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
								}
							} else {
								Result = F1571_16422(Current, loc5, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
								if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 1L))) {
									Result = F1571_16422(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)), (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
								}
							}
						}
					}
					break;
				case 56U:
					for (;;) {
						if ((EIF_BOOLEAN)(loc1 != ((EIF_NATURAL_32) 56U))) break;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
						ti4_1 = (EIF_INTEGER_32) tu4_2;
						loc2 += ti4_1;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						loc1 = F1467_14894(RTCW(tr1), loc2);
					}
					break;
				case 68U:
					loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					if ((EIF_BOOLEAN)(F1571_16422(Current, loc6, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					} else {
						loc1 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 56U);
						for (;;) {
							if ((EIF_BOOLEAN)(loc1 != ((EIF_NATURAL_32) 56U))) break;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)));
							ti4_1 = (EIF_INTEGER_32) tu4_2;
							loc6 += ti4_1;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							loc1 = F1467_14894(RTCW(tr1), loc6);
						}
						loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 2L));
					}
					break;
				case 69U:
					loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					loc1 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 56U);
					for (;;) {
						if ((EIF_BOOLEAN)(loc1 != ((EIF_NATURAL_32) 56U))) break;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)));
						ti4_1 = (EIF_INTEGER_32) tu4_2;
						loc6 += ti4_1;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						loc1 = F1467_14894(RTCW(tr1), loc6);
					}
					if ((EIF_BOOLEAN)(F1571_16422(Current, (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 2L)), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					} else {
						loc2++;
					}
					break;
				case 57U:
				case 58U:
				case 59U:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc5 = (EIF_INTEGER_32) tu4_2;
					loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - loc5);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
					/* INLINED CODE (SPECIAL.item) */
					ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_21_)));
					/* END INLINED CODE */
					loc6 = ti4_3;
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_21_))--;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					loc1 = F1467_14894(RTCW(tr1), loc5);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 60U)) || (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 61U))) || (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 65U))) || (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 62U))) || (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 63U)))) {
						F1571_16418(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
						F1571_16419(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_16_));
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					} else {
						if ((EIF_BOOLEAN)(loc1 != ((EIF_NATURAL_32) 66U))) {
							loc3 = (EIF_INTEGER_32) (EIF_NATURAL_32) (loc1 - ((EIF_NATURAL_32) 70U));
							loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 * ((EIF_INTEGER_32) 2L));
							if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
								tr2 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
								/* INLINED CODE (SPECIAL.item) */
								ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_17_) + loc4)));
								/* END INLINED CODE */
								ti4_1 = ti4_3;
								/* INLINED CODE (SPECIAL.put) */
								*((EIF_INTEGER_32 *)RTCW(tr1) + (loc4)) = ti4_1;
								/* END INLINED CODE */
								;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
								/* INLINED CODE (SPECIAL.put) */
								*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)))) = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
								/* END INLINED CODE */
								;
								if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_16_) <= loc4)) {
									*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_16_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 2L));
								}
							}
						}
						*(EIF_BOOLEAN *)(Current+ _CHROFF_12_13_) = (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current+ _CHROFF_12_0_);
						*(EIF_BOOLEAN *)(Current+ _CHROFF_12_14_) = (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current+ _CHROFF_12_3_);
						*(EIF_BOOLEAN *)(Current+ _CHROFF_12_15_) = (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current+ _CHROFF_12_4_);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						loc1 = F1467_14894(RTCW(tr1), loc2);
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 57U)) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) <= loc6))) {
							loc2 += ((EIF_INTEGER_32) 2L);
						} else {
							if ((EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 59U))) {
								Result = F1571_16422(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)), (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
								if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 1L))) {
									Result = F1571_16422(Current, loc5, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
								}
							} else {
								Result = F1571_16422(Current, loc5, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
								if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 1L))) {
									Result = F1571_16422(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)), (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
								}
							}
						}
					}
					break;
				case 13U:
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_7_) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_)))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_14_)) {
							tb1 = '\0';
							if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_))) {
								tr1 = *(EIF_REFERENCE *)(Current);
								tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) - ((EIF_INTEGER_32) 1L)));
								tb1 = (EIF_BOOLEAN)(tu4_2 != ((EIF_NATURAL_32) 10U));
							}
							if (tb1) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								loc2++;
							}
						} else {
							if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_))) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								loc2++;
							}
						}
					}
					break;
				case 1U:
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2++;
					}
					break;
				case 14U:
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_14_)) {
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							if ((EIF_BOOLEAN)(tu4_2 != ((EIF_NATURAL_32) 10U))) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								loc2++;
							}
						} else {
							if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_8_)) {
								loc2++;
							} else {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							}
						}
					} else {
						if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_8_)) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						} else {
							if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_6_)) {
								tb1 = '\01';
								if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
									tb2 = '\0';
									if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
										tr1 = *(EIF_REFERENCE *)(Current);
										tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
										tb2 = (EIF_BOOLEAN)(tu4_2 != ((EIF_NATURAL_32) 10U));
									}
									tb1 = tb2;
								}
								if (tb1) {
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								} else {
									loc2++;
								}
							} else {
								if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								} else {
									loc2++;
								}
							}
						}
					}
					break;
				case 11U:
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2++;
					}
					break;
				case 10U:
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
						tb2 = '\0';
						if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							tb2 = (EIF_BOOLEAN)(tu4_2 != ((EIF_NATURAL_32) 10U));
						}
						tb1 = tb2;
					}
					if (tb1) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2++;
					}
					break;
				case 2U:
					tb1 = '\0';
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
						tr2 = *(EIF_REFERENCE *)(Current);
						tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) - ((EIF_INTEGER_32) 1L)));
						tb2 = F30_209(RTCW(tr1), tu4_2);
						tb1 = tb2;
					}
					tb2 = '\0';
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
						tr2 = *(EIF_REFERENCE *)(Current);
						tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
						tb3 = F30_209(RTCW(tr1), tu4_2);
						tb2 = tb3;
					}
					if ((EIF_BOOLEAN)(tb1 != tb2)) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2++;
					}
					break;
				case 3U:
					tb1 = '\0';
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
						tr2 = *(EIF_REFERENCE *)(Current);
						tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) - ((EIF_INTEGER_32) 1L)));
						tb2 = F30_209(RTCW(tr1), tu4_2);
						tb1 = tb2;
					}
					tb2 = '\0';
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
						tr2 = *(EIF_REFERENCE *)(Current);
						tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
						tb3 = F30_209(RTCW(tr1), tu4_2);
						tb2 = tb3;
					}
					if ((EIF_BOOLEAN)(tb1 == tb2)) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2++;
					}
					break;
				case 15U:
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						tb1 = '\0';
						if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_15_)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							tb1 = (EIF_BOOLEAN)(tu4_2 == ((EIF_NATURAL_32) 10U));
						}
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						} else {
							tr2 = *(EIF_REFERENCE *)(Current);
							tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
							if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), tu4_2)) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
								loc2++;
							}
						}
					}
					break;
				case 4U:
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						tr1 = RTOSCF(1865,F121_1865, (Current));
						tr2 = *(EIF_REFERENCE *)(Current);
						tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
						tb1 = F30_209(RTCW(tr1), tu4_2);
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						} else {
							tr2 = *(EIF_REFERENCE *)(Current);
							tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
							if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), tu4_2)) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
								loc2++;
							}
						}
					}
					break;
				case 5U:
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
						tr1 = RTOSCF(1865,F121_1865, (Current));
						tr2 = *(EIF_REFERENCE *)(Current);
						tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
						tb2 = F30_209(RTCW(tr1), tu4_2);
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
						loc2++;
					}
					break;
				case 6U:
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						tr1 = RTOSCF(1873,F121_1873, (Current));
						tr2 = *(EIF_REFERENCE *)(Current);
						tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
						tb1 = F30_209(RTCW(tr1), tu4_2);
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						} else {
							tr2 = *(EIF_REFERENCE *)(Current);
							tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
							if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), tu4_2)) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
								loc2++;
							}
						}
					}
					break;
				case 7U:
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
						tr1 = RTOSCF(1873,F121_1873, (Current));
						tr2 = *(EIF_REFERENCE *)(Current);
						tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
						tb2 = F30_209(RTCW(tr1), tu4_2);
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
						loc2++;
					}
					break;
				case 8U:
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
						tr2 = *(EIF_REFERENCE *)(Current);
						tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
						tb1 = F30_209(RTCW(tr1), tu4_2);
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						} else {
							tr2 = *(EIF_REFERENCE *)(Current);
							tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
							if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), tu4_2)) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
								loc2++;
							}
						}
					}
					break;
				case 9U:
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
						tr2 = *(EIF_REFERENCE *)(Current);
						tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
						tb2 = F30_209(RTCW(tr1), tu4_2);
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
						loc2++;
					}
					break;
				case 54U:
					Result = F1571_16427(Current, loc2);
					loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_);
					break;
				case 53U:
					Result = F1571_16428(Current, loc2);
					loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_);
					break;
				case 16U:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc3 = (EIF_INTEGER_32) tu4_2;
					loc2 += ((EIF_INTEGER_32) 2L);
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) + loc3) - ((EIF_INTEGER_32) 1L)) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_13_)) {
							for (;;) {
								if ((EIF_BOOLEAN) (loc3 <= ((EIF_INTEGER_32) 0L))) break;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
								tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tu4_2 = F1467_14895(RTCW(tr2), loc2);
								tu4_2 = F1557_15807(RTCW(tr1), tu4_2);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
								tr2 = *(EIF_REFERENCE *)(Current);
								tu4_3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								tu4_3 = F1557_15807(RTCW(tr1), tu4_3);
								if ((EIF_BOOLEAN)(tu4_2 != tu4_3)) {
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								} else {
									loc2++;
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
									loc3--;
								}
							}
						} else {
							for (;;) {
								if ((EIF_BOOLEAN) (loc3 <= ((EIF_INTEGER_32) 0L))) break;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tu4_2 = F1467_14895(RTCW(tr1), loc2);
								tr1 = *(EIF_REFERENCE *)(Current);
								tu4_3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								if ((EIF_BOOLEAN)(tu4_2 != tu4_3)) {
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								} else {
									loc2++;
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
									loc3--;
								}
							}
						}
					}
					break;
				case 26U:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc5 = (EIF_INTEGER_32) tu4_2;
					loc2 += ((EIF_INTEGER_32) 3L);
					Result = F1571_16429(Current, loc2, loc5, loc5, (EIF_BOOLEAN) 0);
					break;
				case 24U:
				case 25U:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc5 = (EIF_INTEGER_32) tu4_2;
					loc2 += ((EIF_INTEGER_32) 3L);
					Result = F1571_16429(Current, loc2, ((EIF_INTEGER_32) 0L), loc5, (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 25U)));
					break;
				case 18U:
				case 19U:
					loc2 += ((EIF_INTEGER_32) 2L);
					ti4_1 = RTOSCF(16389,F1570_16389, (Current));
					Result = F1571_16429(Current, loc2, ((EIF_INTEGER_32) 0L), ti4_1, (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 19U)));
					break;
				case 20U:
				case 21U:
					loc2 += ((EIF_INTEGER_32) 2L);
					ti4_1 = RTOSCF(16389,F1570_16389, (Current));
					Result = F1571_16429(Current, loc2, ((EIF_INTEGER_32) 1L), ti4_1, (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 21U)));
					break;
				case 22U:
				case 23U:
					loc2 += ((EIF_INTEGER_32) 2L);
					Result = F1571_16429(Current, loc2, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 23U)));
					break;
				case 17U:
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2++;
						tr2 = *(EIF_REFERENCE *)(Current);
						tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
						tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
						if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), tu4_2)) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						} else {
							if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_13_)) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
								tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tu4_2 = F1467_14895(RTCW(tr2), loc2);
								tu4_2 = F1557_15807(RTCW(tr1), tu4_2);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
								tr2 = *(EIF_REFERENCE *)(Current);
								tu4_3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								tu4_3 = F1557_15807(RTCW(tr1), tu4_3);
								if ((EIF_BOOLEAN)(tu4_2 == tu4_3)) {
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								}
							} else {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tu4_2 = F1467_14895(RTCW(tr1), loc2);
								tr1 = *(EIF_REFERENCE *)(Current);
								tu4_3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								if ((EIF_BOOLEAN)(tu4_2 == tu4_3)) {
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								}
							}
						}
						if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
							loc2++;
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
						}
					}
					break;
				case 35U:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc5 = (EIF_INTEGER_32) tu4_2;
					loc2 += ((EIF_INTEGER_32) 3L);
					Result = F1571_16430(Current, loc2, loc5, loc5, (EIF_BOOLEAN) 0);
					break;
				case 33U:
				case 34U:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc5 = (EIF_INTEGER_32) tu4_2;
					loc2 += ((EIF_INTEGER_32) 3L);
					Result = F1571_16430(Current, loc2, ((EIF_INTEGER_32) 0L), loc5, (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 34U)));
					break;
				case 27U:
				case 28U:
					loc2 += ((EIF_INTEGER_32) 2L);
					ti4_1 = RTOSCF(16389,F1570_16389, (Current));
					Result = F1571_16430(Current, loc2, ((EIF_INTEGER_32) 0L), ti4_1, (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 28U)));
					break;
				case 29U:
				case 30U:
					loc2 += ((EIF_INTEGER_32) 2L);
					ti4_1 = RTOSCF(16389,F1570_16389, (Current));
					Result = F1571_16430(Current, loc2, ((EIF_INTEGER_32) 1L), ti4_1, (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 30U)));
					break;
				case 31U:
				case 32U:
					loc2 += ((EIF_INTEGER_32) 2L);
					Result = F1571_16430(Current, loc2, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 32U)));
					break;
				case 44U:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc5 = (EIF_INTEGER_32) tu4_2;
					loc2 += ((EIF_INTEGER_32) 3L);
					Result = F1571_16431(Current, loc2, loc5, loc5, (EIF_BOOLEAN) 1);
					break;
				case 42U:
				case 43U:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tu4_2 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc5 = (EIF_INTEGER_32) tu4_2;
					loc2 += ((EIF_INTEGER_32) 3L);
					Result = F1571_16431(Current, loc2, ((EIF_INTEGER_32) 0L), loc5, (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 43U)));
					break;
				case 36U:
				case 37U:
					loc2 += ((EIF_INTEGER_32) 2L);
					ti4_1 = RTOSCF(16389,F1570_16389, (Current));
					Result = F1571_16431(Current, loc2, ((EIF_INTEGER_32) 0L), ti4_1, (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 37U)));
					break;
				case 38U:
				case 39U:
					loc2 += ((EIF_INTEGER_32) 2L);
					ti4_1 = RTOSCF(16389,F1570_16389, (Current));
					Result = F1571_16431(Current, loc2, ((EIF_INTEGER_32) 1L), ti4_1, (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 39U)));
					break;
				case 40U:
				case 41U:
					loc2 += ((EIF_INTEGER_32) 2L);
					Result = F1571_16431(Current, loc2, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), (EIF_BOOLEAN)(loc1 == ((EIF_NATURAL_32) 41U)));
					break;
				default:
					break;
			}
		}
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_MATCHER}.match_additional_bracket */
EIF_INTEGER_32 F1571_16424 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 * ((EIF_INTEGER_32) 2L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc1));
	/* END INLINED CODE */
	loc2 = ti4_2;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L))));
	/* END INLINED CODE */
	loc3 = ti4_3;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_17_) + loc1)));
	/* END INLINED CODE */
	loc4 = ti4_3;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_17_) + loc1))) = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
	/* END INLINED CODE */
	;
	Result = F1571_16425(Current, arg1);
	if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 1L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + (loc1)) = loc2;
		/* END INLINED CODE */
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)))) = loc3;
		/* END INLINED CODE */
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_17_) + loc1))) = loc4;
		/* END INLINED CODE */
		;
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_MATCHER}.next_matching_alternate */
EIF_INTEGER_32 F1571_16425 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) = (EIF_INTEGER_32) arg1;
	loc1 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 56U);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 != ((EIF_NATURAL_32) 56U))) break;
		loc2 = F1571_16422(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) + ((EIF_INTEGER_32) 2L)), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
		if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 1L))) {
			loc1 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 0U);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) + ((EIF_INTEGER_32) 1L)));
			ti4_1 = (EIF_INTEGER_32) tu4_1;
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_)) += ti4_1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc1 = F1467_14894(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_));
		}
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_MATCHER}.match_ref */
EIF_INTEGER_32 F1571_16426 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg3 > (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_) - arg1) + ((EIF_INTEGER_32) 1L)))) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		/* INLINED CODE (SPECIAL.item) */
		ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (arg2));
		/* END INLINED CODE */
		loc1 = ti4_2;
		loc2 = (EIF_INTEGER_32) arg1;
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + arg3);
		Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_13_)) {
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 >= loc3)) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tr2 = *(EIF_REFERENCE *)(Current);
				tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, loc1);
				tu4_1 = F1557_15807(RTCW(tr1), tu4_1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tr2 = *(EIF_REFERENCE *)(Current);
				tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, loc2);
				tu4_2 = F1557_15807(RTCW(tr1), tu4_2);
				if ((EIF_BOOLEAN)(tu4_1 == tu4_2)) {
					loc1++;
					loc2++;
				} else {
					loc1 = (EIF_INTEGER_32) loc3;
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				}
			}
		} else {
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 >= loc3)) break;
				tr1 = *(EIF_REFERENCE *)(Current);
				tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, loc1);
				tr1 = *(EIF_REFERENCE *)(Current);
				tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, loc2);
				if ((EIF_BOOLEAN)(tu4_1 == tu4_2)) {
					loc1++;
					loc2++;
				} else {
					loc1 = (EIF_INTEGER_32) loc3;
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_MATCHER}.match_repeated_refs */
EIF_INTEGER_32 F1571_16427 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
	loc5 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (tu4_1 * (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L)));
	loc1 += ((EIF_INTEGER_32) 2L);
	tb1 = '\01';
	if (!(EIF_BOOLEAN) (loc5 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_16_))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		/* INLINED CODE (SPECIAL.item) */
		ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
		/* END INLINED CODE */
		ti4_1 = ti4_2;
		tb1 = (EIF_BOOLEAN) (ti4_1 <= ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
		loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 - ti4_1) + ((EIF_INTEGER_32) 2L));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		/* INLINED CODE (SPECIAL.item) */
		ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L))));
		/* END INLINED CODE */
		loc6 = ti4_3;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		/* INLINED CODE (SPECIAL.item) */
		ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
		/* END INLINED CODE */
		ti4_1 = ti4_2;
		loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 - ti4_1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tu4_1 = F1467_14894(RTCW(tr1), loc1);
	switch (tu4_1) {
		case 45U:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc4 = RTOSCF(16389,F1570_16389, (Current));
			break;
		case 46U:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc4 = RTOSCF(16389,F1570_16389, (Current));
			break;
		case 47U:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc4 = RTOSCF(16389,F1570_16389, (Current));
			break;
		case 48U:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc4 = RTOSCF(16389,F1570_16389, (Current));
			break;
		case 49U:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			break;
		case 50U:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			break;
		case 51U:
		case 52U:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tu4_1 = F1467_14894(RTCW(tr1), loc1);
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 52U));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			loc3 = (EIF_INTEGER_32) tu4_1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
			loc4 = (EIF_INTEGER_32) tu4_1;
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
				loc4 = RTOSCF(16389,F1570_16389, (Current));
			}
			loc1 += ((EIF_INTEGER_32) 3L);
			break;
		default:
			if ((EIF_BOOLEAN)(F1571_16426(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_), loc5, loc6) == ((EIF_INTEGER_32) 1L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_)) += loc6;
				loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			} else {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			}
			break;
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc6 > ((EIF_INTEGER_32) 0L)))) {
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc2 > loc3)) break;
			if ((EIF_BOOLEAN)(F1571_16426(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_), loc5, loc6) == ((EIF_INTEGER_32) 1L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_)) += loc6;
				loc2++;
			} else {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc3 < loc4))) {
			if (loc8) {
				loc2 = (EIF_INTEGER_32) loc3;
				for (;;) {
					if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) break;
					if ((EIF_BOOLEAN)(F1571_16422(Current, loc1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					} else {
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (loc2 >= loc4)) {
							tb1 = (EIF_BOOLEAN)(F1571_16426(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_), loc5, loc6) != ((EIF_INTEGER_32) 1L));
						}
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						} else {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_)) += loc6;
							loc2++;
						}
					}
				}
			} else {
				loc7 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
				loc2 = (EIF_INTEGER_32) loc3;
				for (;;) {
					if ((EIF_BOOLEAN) (loc2 >= loc4)) break;
					if ((EIF_BOOLEAN)(F1571_16426(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_), loc5, loc6) == ((EIF_INTEGER_32) 1L))) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_)) += loc6;
						loc2++;
					} else {
						loc2 = (EIF_INTEGER_32) loc4;
					}
				}
				for (;;) {
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) < loc7)) break;
					if ((EIF_BOOLEAN)(F1571_16422(Current, loc1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 - ((EIF_INTEGER_32) 1L));
					} else {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_)) -= loc6;
					}
				}
				if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				}
			}
		}
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) = (EIF_INTEGER_32) loc1;
	RTLE;
	return Result;
}

/* {RX_PCRE_MATCHER}.match_repeated_classes */
EIF_INTEGER_32 F1571_16428 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc7 = (EIF_NATURAL_32) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tu4_1 = F1467_14896(RTCW(tr1), loc3);
	loc9 = (EIF_INTEGER_32) tu4_1;
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 2L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tu4_1 = F1467_14894(RTCW(tr1), loc1);
	switch (tu4_1) {
		case 45U:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc6 = RTOSCF(16389,F1570_16389, (Current));
			break;
		case 46U:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc6 = RTOSCF(16389,F1570_16389, (Current));
			break;
		case 47U:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc6 = RTOSCF(16389,F1570_16389, (Current));
			break;
		case 48U:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc6 = RTOSCF(16389,F1570_16389, (Current));
			break;
		case 49U:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			break;
		case 50U:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			break;
		case 51U:
		case 52U:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tu4_1 = F1467_14894(RTCW(tr1), loc1);
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 52U));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			loc5 = (EIF_INTEGER_32) tu4_1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tu4_1 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
			loc6 = (EIF_INTEGER_32) tu4_1;
			if ((EIF_BOOLEAN)(loc6 == ((EIF_INTEGER_32) 0L))) {
				loc6 = RTOSCF(16389,F1570_16389, (Current));
			}
			loc1 += ((EIF_INTEGER_32) 3L);
			break;
		default:
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			break;
	}
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc5)) break;
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L));
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			loc7 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tb1 = F1467_14898(RTCW(tr1), loc9, loc7);
			if (tb1) {
				loc2++;
			} else {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L));
			}
		}
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc5 < loc6))) {
		if (loc8) {
			loc2 = (EIF_INTEGER_32) loc5;
			for (;;) {
				if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) break;
				if ((EIF_BOOLEAN)(F1571_16422(Current, loc1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				} else {
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 >= loc6) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_)))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current);
						loc7 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tb1 = F1467_14898(RTCW(tr1), loc9, loc7);
						if (tb1) {
							loc2++;
						} else {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						}
					}
				}
			}
		} else {
			loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
			loc2 = (EIF_INTEGER_32) loc5;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 >= loc6) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_)))) break;
				tr1 = *(EIF_REFERENCE *)(Current);
				loc7 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tb1 = F1467_14898(RTCW(tr1), loc9, loc7);
				if (tb1) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
					loc2++;
				} else {
					loc2 = (EIF_INTEGER_32) loc6;
				}
			}
			for (;;) {
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) < loc4)) break;
				if ((EIF_BOOLEAN)(F1571_16422(Current, loc1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
				}
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))--;
			}
			if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			}
		}
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_6_) = (EIF_INTEGER_32) loc1;
	RTLE;
	return Result;
}

/* {RX_PCRE_MATCHER}.match_repeated_characters */
EIF_INTEGER_32 F1571_16429 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_BOOLEAN arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 > (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_) - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_)) + ((EIF_INTEGER_32) 1L)))) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc3 = F1467_14895(RTCW(tr1), (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)));
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_13_)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tu4_1 = F1557_15807(RTCW(tr1), loc3);
			loc3 = (EIF_NATURAL_32) tu4_1;
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > arg2)) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tr2 = *(EIF_REFERENCE *)(Current);
				tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
				tu4_1 = F1557_15807(RTCW(tr1), tu4_1);
				if ((EIF_BOOLEAN)(loc3 != tu4_1)) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
				} else {
					loc1++;
				}
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
			}
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg2 < arg3))) {
				if (arg4) {
					loc1 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) break;
						if ((EIF_BOOLEAN)(F1571_16422(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 >= arg3) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_)))) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
								tr2 = *(EIF_REFERENCE *)(Current);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								tu4_1 = F1557_15807(RTCW(tr1), tu4_1);
								if ((EIF_BOOLEAN)(loc3 != tu4_1)) {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								} else {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
									loc1++;
								}
							}
						}
					}
				} else {
					loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
					loc1 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
							tr2 = *(EIF_REFERENCE *)(Current);
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							tu4_1 = F1557_15807(RTCW(tr1), tu4_1);
							tb1 = (EIF_BOOLEAN)(loc3 != tu4_1);
						}
						if (tb1) {
							loc1 = (EIF_INTEGER_32) arg3;
						} else {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
							loc1++;
						}
					}
					for (;;) {
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) < loc2)) break;
						if ((EIF_BOOLEAN)(F1571_16422(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))--;
					}
					if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
						RTLE;
						return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					}
				}
			}
		} else {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > arg2)) break;
				tr1 = *(EIF_REFERENCE *)(Current);
				tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
				if ((EIF_BOOLEAN)(loc3 != tu4_1)) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
				} else {
					loc1++;
				}
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
			}
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg2 < arg3))) {
				if (arg4) {
					loc1 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) break;
						if ((EIF_BOOLEAN)(F1571_16422(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 >= arg3) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_)))) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								tr1 = *(EIF_REFERENCE *)(Current);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								if ((EIF_BOOLEAN)(loc3 != tu4_1)) {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								} else {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
									loc1++;
								}
							}
						}
					}
				} else {
					loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
					loc1 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							tb1 = (EIF_BOOLEAN)(loc3 != tu4_1);
						}
						if (tb1) {
							loc1 = (EIF_INTEGER_32) arg3;
						} else {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
							loc1++;
						}
					}
					for (;;) {
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) < loc2)) break;
						if ((EIF_BOOLEAN)(F1571_16422(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))--;
					}
					if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
						RTLE;
						return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_MATCHER}.match_not_repeated_characters */
EIF_INTEGER_32 F1571_16430 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_BOOLEAN arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 > (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_) - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_)) + ((EIF_INTEGER_32) 1L)))) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc3 = F1467_14895(RTCW(tr1), (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)));
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_13_)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tu4_1 = F1557_15807(RTCW(tr1), loc3);
			loc3 = (EIF_NATURAL_32) tu4_1;
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > arg2)) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tr2 = *(EIF_REFERENCE *)(Current);
				tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
				tu4_1 = F1557_15807(RTCW(tr1), tu4_1);
				if ((EIF_BOOLEAN)(loc3 == tu4_1)) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
				} else {
					loc1++;
				}
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
			}
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg2 < arg3))) {
				if (arg4) {
					loc1 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) break;
						if ((EIF_BOOLEAN)(F1571_16422(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 >= arg3) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_)))) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
								tr2 = *(EIF_REFERENCE *)(Current);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								tu4_1 = F1557_15807(RTCW(tr1), tu4_1);
								if ((EIF_BOOLEAN)(loc3 != tu4_1)) {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								} else {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
									loc1++;
								}
							}
						}
					}
				} else {
					loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
					loc1 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
							tr2 = *(EIF_REFERENCE *)(Current);
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							tu4_1 = F1557_15807(RTCW(tr1), tu4_1);
							tb1 = (EIF_BOOLEAN)(loc3 == tu4_1);
						}
						if (tb1) {
							loc1 = (EIF_INTEGER_32) arg3;
						} else {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
							loc1++;
						}
					}
					for (;;) {
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) < loc2)) break;
						if ((EIF_BOOLEAN)(F1571_16422(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))--;
					}
					if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
						RTLE;
						return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					}
				}
			}
		} else {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > arg2)) break;
				tr1 = *(EIF_REFERENCE *)(Current);
				tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
				if ((EIF_BOOLEAN)(loc3 == tu4_1)) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
				} else {
					loc1++;
				}
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
			}
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg2 < arg3))) {
				if (arg4) {
					loc1 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) break;
						if ((EIF_BOOLEAN)(F1571_16422(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 >= arg3) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_)))) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								tr1 = *(EIF_REFERENCE *)(Current);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								if ((EIF_BOOLEAN)(loc3 == tu4_1)) {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								} else {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
									loc1++;
								}
							}
						}
					}
				} else {
					loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
					loc1 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							tb1 = (EIF_BOOLEAN)(loc3 == tu4_1);
						}
						if (tb1) {
							loc1 = (EIF_INTEGER_32) arg3;
						} else {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
							loc1++;
						}
					}
					for (;;) {
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) < loc2)) break;
						if ((EIF_BOOLEAN)(F1571_16422(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))--;
					}
					if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
						RTLE;
						return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {RX_PCRE_MATCHER}.match_repeated_type */
EIF_INTEGER_32 F1571_16431 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_BOOLEAN arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc3 = F1467_14896(RTCW(tr1), (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)));
	if ((EIF_BOOLEAN) (arg2 > (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_) - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_)) + ((EIF_INTEGER_32) 1L)))) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	} else {
		if ((EIF_BOOLEAN) (arg2 > ((EIF_INTEGER_32) 0L))) {
			switch (loc3) {
				case 15U:
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > arg2)) break;
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
						} else {
							tb1 = '\0';
							if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_15_)) {
								tr1 = *(EIF_REFERENCE *)(Current);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								tb1 = (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 10U));
							}
							if (tb1) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
							} else {
								tr2 = *(EIF_REFERENCE *)(Current);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
								if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), tu4_1)) {
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
								} else {
									loc1++;
								}
							}
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
					}
					break;
				case 4U:
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > arg2)) break;
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
						} else {
							tr1 = RTOSCF(1865,F121_1865, (Current));
							tr2 = *(EIF_REFERENCE *)(Current);
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							tb1 = F30_209(RTCW(tr1), tu4_1);
							if (tb1) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
							} else {
								tr2 = *(EIF_REFERENCE *)(Current);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
								if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), tu4_1)) {
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
								} else {
									loc1++;
								}
							}
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
					}
					break;
				case 5U:
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > arg2)) break;
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
							tr1 = RTOSCF(1865,F121_1865, (Current));
							tr2 = *(EIF_REFERENCE *)(Current);
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							tb2 = F30_209(RTCW(tr1), tu4_1);
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
						} else {
							loc1++;
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
					}
					break;
				case 6U:
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > arg2)) break;
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
						} else {
							tr1 = RTOSCF(1873,F121_1873, (Current));
							tr2 = *(EIF_REFERENCE *)(Current);
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							tb1 = F30_209(RTCW(tr1), tu4_1);
							if (tb1) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
							} else {
								tr2 = *(EIF_REFERENCE *)(Current);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
								if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), tu4_1)) {
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
								} else {
									loc1++;
								}
							}
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
					}
					break;
				case 7U:
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > arg2)) break;
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
							tr1 = RTOSCF(1873,F121_1873, (Current));
							tr2 = *(EIF_REFERENCE *)(Current);
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							tb2 = F30_209(RTCW(tr1), tu4_1);
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
						} else {
							loc1++;
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
					}
					break;
				case 8U:
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > arg2)) break;
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
							tr2 = *(EIF_REFERENCE *)(Current);
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							tb1 = F30_209(RTCW(tr1), tu4_1);
							if (tb1) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
							} else {
								tr2 = *(EIF_REFERENCE *)(Current);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
								if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), tu4_1)) {
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
								} else {
									loc1++;
								}
							}
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
					}
					break;
				case 9U:
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > arg2)) break;
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
							tr2 = *(EIF_REFERENCE *)(Current);
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							tb2 = F30_209(RTCW(tr1), tu4_1);
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
						} else {
							loc1++;
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
					}
					break;
				default:
					RTEC(EN_WHEN);
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg2 < arg3))) {
			if (arg4) {
				loc1 = (EIF_INTEGER_32) arg2;
				for (;;) {
					if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) break;
					if ((EIF_BOOLEAN)(F1571_16422(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					} else {
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 >= arg3) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_)))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current);
							loc4 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
							switch (loc3) {
								case 15U:
									if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_15_) && (EIF_BOOLEAN)(loc4 == ((EIF_NATURAL_32) 10U)))) {
										Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									} else {
										tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
										if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), loc4)) {
											Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
										}
									}
									break;
								case 4U:
									tr1 = RTOSCF(1865,F121_1865, (Current));
									tr2 = *(EIF_REFERENCE *)(Current);
									tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
									tb1 = F30_209(RTCW(tr1), tu4_1);
									if (tb1) {
										Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									} else {
										tr2 = *(EIF_REFERENCE *)(Current);
										tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
										tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
										if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), tu4_1)) {
											Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
										}
									}
									break;
								case 5U:
									tr1 = RTOSCF(1865,F121_1865, (Current));
									tr2 = *(EIF_REFERENCE *)(Current);
									tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
									tb1 = F30_209(RTCW(tr1), tu4_1);
									if ((EIF_BOOLEAN) !tb1) {
										Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									}
									break;
								case 6U:
									tr1 = RTOSCF(1873,F121_1873, (Current));
									tr2 = *(EIF_REFERENCE *)(Current);
									tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
									tb1 = F30_209(RTCW(tr1), tu4_1);
									if (tb1) {
										Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									} else {
										tr2 = *(EIF_REFERENCE *)(Current);
										tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
										tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
										if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), tu4_1)) {
											Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
										}
									}
									break;
								case 7U:
									tr1 = RTOSCF(1873,F121_1873, (Current));
									tr2 = *(EIF_REFERENCE *)(Current);
									tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
									tb1 = F30_209(RTCW(tr1), tu4_1);
									if ((EIF_BOOLEAN) !tb1) {
										Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									}
									break;
								case 8U:
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
									tr2 = *(EIF_REFERENCE *)(Current);
									tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
									tb1 = F30_209(RTCW(tr1), tu4_1);
									if (tb1) {
										Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									} else {
										tr2 = *(EIF_REFERENCE *)(Current);
										tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
										tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
										if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), tu4_1)) {
											Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
										}
									}
									break;
								case 9U:
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
									tr2 = *(EIF_REFERENCE *)(Current);
									tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
									tb1 = F30_209(RTCW(tr1), tu4_1);
									if ((EIF_BOOLEAN) !tb1) {
										Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									}
									break;
								default:
									RTEC(EN_WHEN);
							}
							loc1++;
						}
					}
				}
			} else {
				loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
				switch (loc3) {
					case 15U:
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_15_)) {
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg3 - arg2);
							if ((EIF_BOOLEAN) (loc1 > (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_) - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_)))) {
								loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_);
								ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ti4_1) + ((EIF_INTEGER_32) 1L));
							}
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_)) += loc1;
						} else {
							loc1 = (EIF_INTEGER_32) arg2;
							for (;;) {
								if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
								if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
									loc1 = (EIF_INTEGER_32) arg3;
								} else {
									tb1 = '\0';
									if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_15_)) {
										tr1 = *(EIF_REFERENCE *)(Current);
										tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr1))-1132])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
										tb1 = (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 10U));
									}
									if (tb1) {
										loc1 = (EIF_INTEGER_32) arg3;
									} else {
										tr2 = *(EIF_REFERENCE *)(Current);
										tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
										tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
										if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), tu4_1)) {
											loc1 = (EIF_INTEGER_32) arg3;
										} else {
											(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
											loc1++;
										}
									}
								}
							}
						}
						break;
					case 4U:
						loc1 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
							if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
								loc1 = (EIF_INTEGER_32) arg3;
							} else {
								tr1 = RTOSCF(1865,F121_1865, (Current));
								tr2 = *(EIF_REFERENCE *)(Current);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								tb1 = F30_209(RTCW(tr1), tu4_1);
								if (tb1) {
									loc1 = (EIF_INTEGER_32) arg3;
								} else {
									tr2 = *(EIF_REFERENCE *)(Current);
									tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
									tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
									if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), tu4_1)) {
										loc1 = (EIF_INTEGER_32) arg3;
									} else {
										(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
										loc1++;
									}
								}
							}
						}
						break;
					case 5U:
						loc1 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
							tb1 = '\01';
							if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
								tr1 = RTOSCF(1865,F121_1865, (Current));
								tr2 = *(EIF_REFERENCE *)(Current);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								tb2 = F30_209(RTCW(tr1), tu4_1);
								tb1 = (EIF_BOOLEAN) !tb2;
							}
							if (tb1) {
								loc1 = (EIF_INTEGER_32) arg3;
							} else {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
								loc1++;
							}
						}
						break;
					case 6U:
						loc1 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
							if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
								loc1 = (EIF_INTEGER_32) arg3;
							} else {
								tr1 = RTOSCF(1873,F121_1873, (Current));
								tr2 = *(EIF_REFERENCE *)(Current);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								tb1 = F30_209(RTCW(tr1), tu4_1);
								if (tb1) {
									loc1 = (EIF_INTEGER_32) arg3;
								} else {
									tr2 = *(EIF_REFERENCE *)(Current);
									tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
									tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
									if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), tu4_1)) {
										loc1 = (EIF_INTEGER_32) arg3;
									} else {
										(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
										loc1++;
									}
								}
							}
						}
						break;
					case 7U:
						loc1 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
							tb1 = '\01';
							if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
								tr1 = RTOSCF(1873,F121_1873, (Current));
								tr2 = *(EIF_REFERENCE *)(Current);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								tb2 = F30_209(RTCW(tr1), tu4_1);
								tb1 = (EIF_BOOLEAN) !tb2;
							}
							if (tb1) {
								loc1 = (EIF_INTEGER_32) arg3;
							} else {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
								loc1++;
							}
						}
						break;
					case 8U:
						loc1 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
							if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
								loc1 = (EIF_INTEGER_32) arg3;
							} else {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
								tr2 = *(EIF_REFERENCE *)(Current);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								tb1 = F30_209(RTCW(tr1), tu4_1);
								if (tb1) {
									loc1 = (EIF_INTEGER_32) arg3;
								} else {
									tr2 = *(EIF_REFERENCE *)(Current);
									tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
									tr1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_0_0_0_0_0_0_0_0_);
									if ((EIF_BOOLEAN) !F1566_16111(RTCW(tr1), tu4_1)) {
										loc1 = (EIF_INTEGER_32) arg3;
									} else {
										(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
										loc1++;
									}
								}
							}
						}
						break;
					case 9U:
						loc1 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
							tb1 = '\01';
							if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
								tr2 = *(EIF_REFERENCE *)(Current);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8234[Dtype(RTCW(tr2))-1132])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_));
								tb2 = F30_209(RTCW(tr1), tu4_1);
								tb1 = (EIF_BOOLEAN) !tb2;
							}
							if (tb1) {
								loc1 = (EIF_INTEGER_32) arg3;
							} else {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))++;
								loc1++;
							}
						}
						break;
					default:
						RTEC(EN_WHEN);
				}
				for (;;) {
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) < loc2)) break;
					if ((EIF_BOOLEAN)(F1571_16422(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
					} else {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_14_))--;
					}
				}
				if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
					RTLE;
					return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				}
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit815 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
