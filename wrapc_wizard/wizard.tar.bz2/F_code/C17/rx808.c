/*
 * Code for class RX_PATTERN_MATCHER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "rx808.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RX_PATTERN_MATCHER}.wipe_out */
void F1564_16071 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = RTOSCF(16096,F1564_16096, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {RX_PATTERN_MATCHER}.has_matched */
EIF_BOOLEAN F1564_16074 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_3_) > ((EIF_INTEGER_32) 0L));
}

/* {RX_PATTERN_MATCHER}.recognizes */
EIF_BOOLEAN F1564_16078 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1564_16090(Current, arg1);
	if (F1564_16074(Current)) {
		Result = '\0';
		if ((EIF_BOOLEAN)(F1571_16395(Current, ((EIF_INTEGER_32) 0L)) == ((EIF_INTEGER_32) 1L))) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8271[Dtype(RTCW(arg1))-1132])(arg1);
			Result = (EIF_BOOLEAN)(F1571_16396(Current, ((EIF_INTEGER_32) 0L)) == ti4_1);
		}
	}
	RTLE;
	return Result;
}

/* {RX_PATTERN_MATCHER}.match */
void F1564_16090 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8271[Dtype(RTCW(arg1))-1132])(arg1);
	F1571_16397(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
	RTLE;
}

/* {RX_PATTERN_MATCHER}.set_subject */
void F1564_16095 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {RX_PATTERN_MATCHER}.no_subject */

EIF_REFERENCE F1564_16096 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (16096,RTMS_EX_H("",0,0));
}

void EIF_Minit808 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
