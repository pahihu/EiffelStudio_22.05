/*
 * Code for class ROUTINE [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ro836.h"
#include "eif_built_in.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ROUTINE}.operands */
EIF_REFERENCE F1123_9731 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current);
}


/* {ROUTINE}.target */
EIF_REFERENCE F1123_9732 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O8197[Dtype(Current)-1122])) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = '\0';
		tb2 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			ti4_1 = (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (loc1);
			tb2 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
		}
		if (tb2) {
			tr1 = F1050_8550(RTCW(loc1), ((EIF_INTEGER_32) 1L));
			loc2 = RTCCL(tr1);
			tb1 = EIF_TEST(loc2);
		}
		if (tb1) {
			RTLE;
			return (EIF_REFERENCE) loc2;
		}
	} else {
		tb1 = '\0';
		tb2 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			ti4_1 = (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (loc3);
			tb2 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
		}
		if (tb2) {
			tr1 = F1050_8550(loc3, ((EIF_INTEGER_32) 1L));
			loc4 = RTCCL(tr1);
			tb1 = EIF_TEST(loc4);
		}
		if (tb1) {
			RTLE;
			return (EIF_REFERENCE) loc4;
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {ROUTINE}.hash_code */
EIF_INTEGER_32 F1123_9733 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8206[dtype-1122]);
	ti4_1 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (tp1)));
	ti4_2 = *(EIF_INTEGER_32 *)(Current + O8210[dtype-1122]);
	ti4_2 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (ti4_2)));
	Result = eif_bit_xor(ti4_1,ti4_2);
	RTLE;
	return Result;
}

/* {ROUTINE}.is_equal */
EIF_BOOLEAN F1123_9738 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	tb4 = '\0';
	tb5 = '\0';
	tb6 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	if (RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_1_), tr1)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		tb6 = RTEQ(*(EIF_REFERENCE *)(Current), tr1);
	}
	if (tb6) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		tb5 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_2_), tr1);
	}
	if (tb5) {
		tp1 = *(EIF_POINTER *)(RTCW(arg1) + O8206[Dtype(arg1)-1122]);
		tb4 = (EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O8206[dtype-1122]) == tp1);
	}
	if (tb4) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8210[Dtype(arg1)-1122]);
		tb3 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O8210[dtype-1122]) == ti4_1);
	}
	if (tb3) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8212[Dtype(arg1)-1122]);
		tb2 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O8212[dtype-1122]) == ti4_1);
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(RTCW(arg1) + O8209[Dtype(arg1)-1122]);
		tb1 = (EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O8209[dtype-1122]) == tp1);
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(RTCW(arg1) + O8207[Dtype(arg1)-1122]);
		Result = (EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O8207[dtype-1122]) == tp1);
	}
	RTLE;
	return Result;
}

/* {ROUTINE}.valid_operands */
EIF_BOOLEAN F1123_9739 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(Current + O8198[dtype-1122]);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
	} else {
		ti4_1 = (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (arg1);
		if ((EIF_BOOLEAN) (ti4_1 >= *(EIF_INTEGER_32 *)(Current + O8198[dtype-1122]))) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current + O8198[dtype-1122])) || (EIF_BOOLEAN) !Result)) break;
				tu1_1 = (EIF_NATURAL_8) eif_builtin_TUPLE_item_code__i4_u1 (arg1, loc1);
				loc2 = (EIF_INTEGER_32) tu1_1;
				loc4 = F1123_9763(Current, loc1);
				switch (loc2) {
					case 1L:
						tr1 = RTLNTY2(eif_new_type(1061, 0x00), 0x00);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (tr1);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 == ti4_1);
						break;
					case 2L:
						tr1 = RTLNTY2(eif_new_type(1058, 0x00), 0x00);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (tr1);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 == ti4_1);
						break;
					case 14L:
						tr1 = RTLNTY2(eif_new_type(1055, 0x00), 0x00);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (tr1);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 == ti4_1);
						break;
					case 6L:
						tr1 = RTLNTY2(eif_new_type(1073, 0x00), 0x00);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (tr1);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 == ti4_1);
						break;
					case 7L:
						tr1 = RTLNTY2(eif_new_type(1070, 0x00), 0x00);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (tr1);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 == ti4_1);
						break;
					case 8L:
						tr1 = RTLNTY2(eif_new_type(1067, 0x00), 0x00);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (tr1);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 == ti4_1);
						break;
					case 9L:
						tr1 = RTLNTY2(eif_new_type(1064, 0x00), 0x00);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (tr1);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 == ti4_1);
						break;
					case 10L:
						tr1 = RTLNTY2(eif_new_type(1085, 0x00), 0x00);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (tr1);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 == ti4_1);
						break;
					case 11L:
						tr1 = RTLNTY2(eif_new_type(1082, 0x00), 0x00);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (tr1);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 == ti4_1);
						break;
					case 12L:
						tr1 = RTLNTY2(eif_new_type(1079, 0x00), 0x00);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (tr1);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 == ti4_1);
						break;
					case 13L:
						tr1 = RTLNTY2(eif_new_type(1076, 0x00), 0x00);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (tr1);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 == ti4_1);
						break;
					case 5L:
						tr1 = RTLNTY2(eif_new_type(1121, 0x00), 0x00);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (tr1);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 == ti4_1);
						break;
					case 4L:
						tr1 = RTLNTY2(eif_new_type(1088, 0x00), 0x00);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (tr1);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 == ti4_1);
						break;
					case 3L:
						tr1 = RTLNTY2(eif_new_type(1052, 0x00), 0x00);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (tr1);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 == ti4_1);
						break;
					case 0L:
						loc3 = F1050_8550(RTCW(arg1), loc1);
						if (F307_4864(Current, loc4)) {
							Result = '\0';
							if ((EIF_BOOLEAN)(loc3 != NULL)) {
								tr1 = RTCCL(loc3);
								ti4_1 = (EIF_INTEGER_32) eif_builtin_ISE_RUNTIME_dynamic_type__o_i4 (tr1);
								Result = F307_4854(Current, ti4_1, loc4);
							}
						} else {
							Result = '\01';
							if (!(EIF_BOOLEAN)(loc3 == NULL)) {
								tr1 = RTCCL(loc3);
								ti4_1 = (EIF_INTEGER_32) eif_builtin_ISE_RUNTIME_dynamic_type__o_i4 (tr1);
								Result = F307_4854(Current, ti4_1, loc4);
							}
						}
						break;
					default:
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						break;
				}
				loc1++;
			}
		}
	}
	if ((EIF_BOOLEAN) (Result && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O8197[dtype-1122]))) {
		Result = '\0';
		tb1 = '\0';
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			tb2 = F1050_8582(RTCW(arg1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			tr1 = F1050_8550(RTCW(arg1), ((EIF_INTEGER_32) 1L));
			Result = (EIF_BOOLEAN)(tr1 != NULL);
		}
	}
	RTLE;
	return Result;
}

/* {ROUTINE}.copy */
void F1123_9745 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = F1_14(loc1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {ROUTINE}.flexible_call */
void F1123_9748 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,tr1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(arg1 != NULL)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8201[dtype-1123])(Current, loc1);
	} else {
		loc3 = arg1;
		loc3 = RTRV(eif_gen_param(dftype, 1),loc3);
		if (EIF_TEST(loc3)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8201[dtype-1123])(Current, loc3);
		} else {
			RTCT0("from_precondition", EX_CHECK);
			tr1 = RTLNTY2(eif_gen_param(dftype, 1), 0x00);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7427[Dtype(tr1)-1015])(tr1);
			tr1 = F72_1360(Current, ti4_1);
			loc4 = tr1;
			loc4 = RTRV(eif_gen_param(dftype, 1),loc4);
			if (EIF_TEST(loc4)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tb1 = (EIF_BOOLEAN) eif_builtin_TUPLE_object_comparison__b (arg1);
			if (tb1) {
				F1050_8574(loc4);
			}
			loc2 = (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (loc4);
			for (;;) {
				if ((EIF_BOOLEAN) (loc2 <= ((EIF_INTEGER_32) 0L))) break;
				tr1 = F1050_8550(RTCW(arg1), loc2);
				tr2 = RTCCL(tr1);
				F1050_8583(loc4, tr2, loc2);
				loc2--;
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8201[dtype-1123])(Current, loc4);
		}
	}
	RTLE;
}

/* {ROUTINE}.correct_mismatch */
void F1123_9749 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {ROUTINE}.closed_count */
EIF_INTEGER_32 F1123_9751 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		ti4_1 = (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (loc1);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {ROUTINE}.set_rout_disp_final */
void F1123_9760 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_REFERENCE arg4, EIF_BOOLEAN arg5, EIF_INTEGER_32 arg6)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg4);
	RTLIU(2);
	
	RTGC;
	*(EIF_POINTER *)(Current + O8206[dtype-1122]) = (EIF_POINTER) arg1;
	*(EIF_POINTER *)(Current + O8209[dtype-1122]) = (EIF_POINTER) arg2;
	*(EIF_POINTER *)(Current + O8207[dtype-1122]) = (EIF_POINTER) arg3;
	RTAR(Current, arg4);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg4;
	*(EIF_BOOLEAN *)(Current + O8197[dtype-1122]) = (EIF_BOOLEAN) arg5;
	*(EIF_INTEGER_32 *)(Current + O8198[dtype-1122]) = (EIF_INTEGER_32) arg6;
	RTLE;
}

/* {ROUTINE}.open_operand_type */
EIF_INTEGER_32 F1123_9763 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {701,1067,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F702_6202(RTCW(loc1), ((EIF_INTEGER_32) -1L), ((EIF_INTEGER_32) 1L), *(EIF_INTEGER_32 *)(Current + O8198[Dtype(Current)-1122]));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc1;
	}
	Result = F702_6207(RTCW(loc1), arg1);
	if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) -1L))) {
		tr1 = RTLNTY2(eif_gen_param(dftype, 1), 0x00);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7426[Dtype(tr1)-1015])(tr1, arg1);
		Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7427[Dtype(RTCW(tr1))-1015])(tr1);
		F702_6226(RTCW(loc1), Result, arg1);
	}
	RTLE;
	return Result;
}

void EIF_Minit836 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
