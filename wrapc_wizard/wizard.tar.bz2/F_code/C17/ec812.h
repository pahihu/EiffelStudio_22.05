
#ifndef _C17_ec812_
#define _C17_ec812_

#ifdef __cplusplus
extern "C" {
#endif
RTOSHF (EIF_REFERENCE, 16293)


extern EIF_REFERENCE F1568_16293(EIF_REFERENCE);
extern void EIF_Minit812(void);

#ifdef __cplusplus
}
#endif

#endif
