
#ifndef _C17_bi847_
#define _C17_bi847_

#ifdef __cplusplus
extern "C" {
#endif

extern void F442_5900(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit847(void);
extern void F430_5883(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5606[])();
extern char *(*R5607[])();
extern char *(*R5482[])();

#ifdef __cplusplus
}
#endif

#endif
