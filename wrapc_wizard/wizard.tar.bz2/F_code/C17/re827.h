
#ifndef _C17_re827_
#define _C17_re827_

#ifdef __cplusplus
extern "C" {
#endif

extern void F768_6394(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F768_6396(EIF_REFERENCE);
extern EIF_INTEGER_32 F768_6397(EIF_REFERENCE);
extern EIF_INTEGER_32 F768_6398(EIF_REFERENCE);
extern EIF_INTEGER_32 F768_6399(EIF_REFERENCE);
extern EIF_REFERENCE F768_6400(EIF_REFERENCE);
extern EIF_BOOLEAN F768_6406(EIF_REFERENCE);
extern EIF_BOOLEAN F768_6407(EIF_REFERENCE);
extern EIF_BOOLEAN F768_6408(EIF_REFERENCE);
extern void F768_6413(EIF_REFERENCE);
extern void F768_6414(EIF_REFERENCE);
extern EIF_REFERENCE F768_6415(EIF_REFERENCE);
extern void EIF_Minit827(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R5663[])();
extern char *(*R5664[])();
extern char *(*R5666[])();
extern char *(*R5861[])();
extern char *(*R5864[])();
extern long O5868[];
extern long O5872[];
extern long O5873[];
extern long O5874[];
extern long O5875[];
extern long O5876[];

#ifdef __cplusplus
}
#endif

#endif
