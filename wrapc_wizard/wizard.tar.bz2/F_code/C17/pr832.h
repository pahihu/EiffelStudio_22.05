
#ifndef _C17_pr832_
#define _C17_pr832_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1124_9770(EIF_REFERENCE, EIF_REFERENCE);
extern void F1124_9771(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32, EIF_BOOLEAN, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_POINTER);
extern void EIF_Minit832(void);
extern EIF_INTEGER_32 F1123_9751(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
