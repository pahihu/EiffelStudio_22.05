
#ifndef _C17_li831_
#define _C17_li831_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F430_5881(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F430_5882(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F430_5883(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F430_5887(EIF_REFERENCE);
extern EIF_BOOLEAN F430_5889(EIF_REFERENCE);
extern EIF_REFERENCE F430_5896(EIF_REFERENCE);
extern void EIF_Minit831(void);
extern char *(*R5603[])();
extern char *(*R5604[])();
extern char *(*R5606[])();
extern char *(*R5591[])();
extern char *(*R5592[])();
extern char *(*R5593[])();
extern char *(*R5599[])();
extern char *(*R5482[])();
extern long O5484[];

#ifdef __cplusplus
}
#endif

#endif
