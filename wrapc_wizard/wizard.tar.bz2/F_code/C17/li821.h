
#ifndef _C17_li821_
#define _C17_li821_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F669_6110(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F669_6111(EIF_REFERENCE);
extern EIF_BOOLEAN F669_6112(EIF_REFERENCE);
extern void EIF_Minit821(void);
extern char *(*R5639[])();
extern char *(*R5600[])();
extern char *(*R5604[])();
extern char *(*R5606[])();
extern char *(*R5627[])();
extern char *(*R5593[])();
extern char *(*R5633[])();
extern char *(*R5635[])();
extern char *(*R5482[])();
extern long O5484[];

#ifdef __cplusplus
}
#endif

#endif
