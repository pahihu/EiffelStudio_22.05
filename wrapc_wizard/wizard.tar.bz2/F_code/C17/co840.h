
#ifndef _C17_co840_
#define _C17_co840_

#ifdef __cplusplus
extern "C" {
#endif

extern void F454_5908(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit840(void);
extern char *(*R5615[])();
extern char *(*R5481[])();

#ifdef __cplusplus
}
#endif

#endif
