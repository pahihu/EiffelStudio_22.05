
#ifndef _C17_se846_
#define _C17_se846_

#ifdef __cplusplus
extern "C" {
#endif

extern void F586_5970(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit846(void);
extern char *(*R5613[])();

#ifdef __cplusplus
}
#endif

#endif
