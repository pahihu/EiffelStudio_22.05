
#ifndef _C17_uc810_
#define _C17_uc810_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1566_16111(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit810(void);

#ifdef __cplusplus
}
#endif

#endif
