/*
 * Code for class EIFFEL_ENV
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei811.h"
#include "eif_built_in.h"
#include "eif_path_name.h"
#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1567_16135
static int inline_F1567_16135 (void)
{
	return (int) (EIF_IS_WORKBENCH)
	;
}
#define INLINE_F1567_16135
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_ENV}.product_name */
static EIF_REFERENCE F1567_16117_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (16117);
#define Result RTOSR(16117)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("Eiffel",6,1854452588);
	RTOSE (16117);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1567_16117 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16117,F1567_16117_body,(Current));
}

/* {EIFFEL_ENV}.version_name */
static EIF_REFERENCE F1567_16121_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (16121);
#define Result RTOSR(16121)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1136, 0x01).id, 1136, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1135_10080(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(3484,F174_3484, (Current));
	F1137_10195(RTCW(Result), tr1);
	F1137_10206(RTCW(Result), (EIF_CHARACTER_8) '.');
	tr1 = RTOSCF(3485,F174_3485, (Current));
	F1137_10195(RTCW(Result), tr1);
	RTOSE (16121);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1567_16121 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16121,F1567_16121_body,(Current));
}

/* {EIFFEL_ENV}.is_workbench */
EIF_BOOLEAN F1567_16135 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F1567_16135 ());
	return Result;
}

/* {EIFFEL_ENV}.environment */
static EIF_REFERENCE F1567_16139_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (16139);
#define Result RTOSR(16139)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(377, 0x01).id, 377, _OBJSIZ_0_0_0_1_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (16139);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1567_16139 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16139,F1567_16139_body,(Current));
}

/* {EIFFEL_ENV}.versionless_user_files_path */
static EIF_REFERENCE F1567_16179_body (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	

	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (16179);
#define Result RTOSR(16179)
	RTOC_NEW(Result);
	RTCT0("attached user_directory_name as l_user_directory_name", EX_CHECK);
	tr1 = RTOSCF(16284,F1567_16284, (Current));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc3;
	tb1 = '\0';
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) eif_builtin_PLATFORM_is_mac__b;
	}
	if (tb1) {
		tr1 = RTOSCF(16283,F1567_16283, (Current));
		tr1 = F1015_8487(RTCW(Result), tr1);
		Result = (EIF_REFERENCE) tr1;
		if (arg1) {
			F1567_16232(Current, Result);
		}
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	loc1 = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1132_9913(RTCW(loc1), ((EIF_INTEGER_32) 30L));
	tb1 = '\0';
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) eif_builtin_PLATFORM_is_mac__b;
	}
	if (tb1) {
		tr1 = F1137_10228(RTCV(RTOSCF(16117,F1567_16117, (Current))));
		F1134_10027(RTCW(loc1), tr1);
		tr1 = RTMS_EX_H("_user_files",11,1637806195);
		F1134_10027(RTCW(loc1), tr1);
	} else {
		tr1 = RTOSCF(16117,F1567_16117, (Current));
		F1134_10027(RTCW(loc1), tr1);
		tr1 = RTMS_EX_H(" User Files",11,1077377395);
		F1134_10027(RTCW(loc1), tr1);
	}
	tb1 = '\0';
	if (EIF_TEST (inline_F1567_16135())) {
		tb1 = loc2;
	}
	if (tb1) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F1134_10041(RTCW(loc1), tw1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '(';
		F1134_10041(RTCW(loc1), tw1);
		tr1 = RTOSCF(16247,F1567_16247, (Current));
		F1134_10027(RTCW(loc1), tr1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ')';
		F1134_10041(RTCW(loc1), tw1);
	}
	tr1 = F1015_8487(RTCW(Result), loc1);
	Result = (EIF_REFERENCE) tr1;
	if (arg1) {
		F1567_16232(Current, Result);
	}
	RTOSE (16179);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1567_16179 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	return RTOSCF(16179,F1567_16179_body,(Current,arg1));
}

/* {EIFFEL_ENV}.user_files_path_for_version */
EIF_REFERENCE F1567_16180 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = RTOSCF(16179,F1567_16179, (Current, arg2));
	tr1 = F1015_8487(RTCW(Result), arg1);
	Result = (EIF_REFERENCE) tr1;
	if (arg2) {
		F1567_16232(Current, Result);
	}
	RTLE;
	return Result;
}

/* {EIFFEL_ENV}.user_files_path */
static EIF_REFERENCE F1567_16181_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (16181);
#define Result RTOSR(16181)
	RTOC_NEW(Result);
	tr1 = RTOSCF(3476,F174_3476, (Current));
	loc1 = F1567_16229(Current, tr1);
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(loc1 == NULL)) {
		tb2 = F554_5957(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = RTOSCF(16121,F1567_16121, (Current));
		Result = F1567_16180(Current, tr1, (EIF_BOOLEAN) 1);
	} else {
		tr1 = RTLNS(eif_new_type(1014, 0x01).id, 1014, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F1015_8460(RTCW(tr1), loc1);
		Result = (EIF_REFERENCE) tr1;
	}
	RTOSE (16181);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1567_16181 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16181,F1567_16181_body,(Current));
}

/* {EIFFEL_ENV}.user_projects_path */
static EIF_REFERENCE F1567_16188_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	

	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOSP (16188);
#define Result RTOSR(16188)
	RTOC_NEW(Result);
	tr1 = RTOSCF(3475,F174_3475, (Current));
	loc1 = F1567_16229(Current, tr1);
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(loc1 == NULL)) {
		tb2 = F554_5957(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			tb1 = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_mac__b;
		}
		if (tb1) {
			tr1 = RTOSCF(16181,F1567_16181, (Current));
			tr2 = RTOSCF(16273,F1567_16273, (Current));
			Result = F1015_8487(RTCW(tr1), tr2);
		} else {
			tb1 = '\0';
			tb2 = (EIF_BOOLEAN) EIF_TEST(eif_home_dir_supported());
			if (tb2) {
				tr1 = RTOSCF(5614,F377_5614, (RTCV(RTOSCF(16139,F1567_16139, (Current)))));
				loc2 = tr1;
				tb1 = EIF_TEST(loc2);
			}
			if (tb1) {
				Result = (EIF_REFERENCE) loc2;
			} else {
				tr1 = RTLNS(eif_new_type(1014, 0x01).id, 1014, _OBJSIZ_2_1_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("\\Invalid path",13,1573736552);
				F1015_8460(RTCW(tr1), tr2);
				Result = (EIF_REFERENCE) tr1;
			}
		}
	} else {
		tr1 = RTLNS(eif_new_type(1014, 0x01).id, 1014, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F1015_8460(RTCW(tr1), loc1);
		Result = (EIF_REFERENCE) tr1;
	}
	RTOSE (16188);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1567_16188 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16188,F1567_16188_body,(Current));
}

/* {EIFFEL_ENV}.get_environment_32 */
EIF_REFERENCE F1567_16229 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(16139,F1567_16139, (Current));
	tr2 = RTOSCF(16293,F1568_16293, (Current));
	tr3 = RTOSCF(16121,F1567_16121, (Current));
	Result = F378_5645(RTCW(tr1), arg1, tr2, tr3);
	RTLE;
	return Result;
}

/* {EIFFEL_ENV}.safe_create_dir */
void F1567_16232 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	struct eif_ex_46 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(62, 0x00).id);
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1015_8499(RTCW(arg1));
	F63_1111(RTCW(loc1), tr1);
	RTLE;
}

/* {EIFFEL_ENV}.wkbench_suffix */

EIF_REFERENCE F1567_16247 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (16247,RTMS_EX_H("workbench",9,1911020904));
}

/* {EIFFEL_ENV}.projects_name */

EIF_REFERENCE F1567_16273 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (16273,RTMS_EX_H("projects",8,1341994355));
}

/* {EIFFEL_ENV}.hidden_directory_name */
static EIF_REFERENCE F1567_16283_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (16283);
#define Result RTOSR(16283)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr2 = RTMS_EX_H(".es",3,3040627);
	F1134_9989(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	if (EIF_TEST (inline_F1567_16135())) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
		F1134_10041(RTCW(Result), tw1);
		tr1 = RTOSCF(16247,F1567_16247, (Current));
		F1134_10027(RTCW(Result), tr1);
	}
	RTOSE (16283);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1567_16283 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16283,F1567_16283_body,(Current));
}

/* {EIFFEL_ENV}.user_directory_name */
static EIF_REFERENCE F1567_16284_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (16284);
#define Result RTOSR(16284)
	RTOC_NEW(Result);
	Result = RTOSCF(5615,F377_5615, (RTCV(RTOSCF(16139,F1567_16139, (Current)))));
	RTOSE (16284);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1567_16284 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16284,F1567_16284_body,(Current));
}

void EIF_Minit811 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
