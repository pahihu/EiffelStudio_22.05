/*
 * Code for class RX_CASE_MAPPING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "rx801.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RX_CASE_MAPPING}.make_default */
void F1557_15805 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(4460,F289_4460, (Current));
	tr1 = F25_196(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 256L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(4460,F289_4460, (Current));
	tr1 = F25_196(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 256L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F1557_15810(Current);
	RTLE;
}

/* {RX_CASE_MAPPING}.make */
void F1557_15806 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	F1557_15805(Current);
	F1557_15811(Current, arg1, arg2);
	RTLE;
}

/* {RX_CASE_MAPPING}.to_lower */
EIF_NATURAL_32 F1557_15807 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 256L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = (EIF_INTEGER_32) arg1;
		/* INLINED CODE (SPECIAL.item) */
		tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1));
		/* END INLINED CODE */
		Result = tu4_2;
	} else {
		RTLE;
		return (EIF_NATURAL_32) arg1;
	}
	RTLE;
	return Result;
}

/* {RX_CASE_MAPPING}.flip_case */
EIF_NATURAL_32 F1557_15809 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 256L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = (EIF_INTEGER_32) arg1;
		/* INLINED CODE (SPECIAL.item) */
		tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1));
		/* END INLINED CODE */
		Result = tu4_2;
	} else {
		RTLE;
		return (EIF_NATURAL_32) arg1;
	}
	RTLE;
	return Result;
}

/* {RX_CASE_MAPPING}.clear */
void F1557_15810 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 255L))) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		tu4_1 = (EIF_NATURAL_32) loc1;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_32 *)RTCW(tr1) + (loc1)) = tu4_1;
		/* END INLINED CODE */
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tu4_1 = (EIF_NATURAL_32) loc1;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_32 *)RTCW(tr1) + (loc1)) = tu4_1;
		/* END INLINED CODE */
		;
		loc1++;
	}
	RTLE;
}

/* {RX_CASE_MAPPING}.add */
void F1557_15811 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc4 = (EIF_CHARACTER_8) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc6 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = F1137_10159(RTCW(arg2), loc1);
		loc4 = F1137_10159(RTCW(arg1), loc1);
		loc5 = (EIF_NATURAL_32) loc3;
		loc6 = (EIF_NATURAL_32) loc4;
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = (EIF_INTEGER_32) loc6;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1)) = loc5;
		/* END INLINED CODE */
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = (EIF_INTEGER_32) loc6;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1)) = loc5;
		/* END INLINED CODE */
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = (EIF_INTEGER_32) loc5;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1)) = loc6;
		/* END INLINED CODE */
		;
		loc1++;
	}
	RTLE;
}

void EIF_Minit801 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
