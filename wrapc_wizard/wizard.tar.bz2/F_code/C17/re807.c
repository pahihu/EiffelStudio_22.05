/*
 * Code for class REGULAR_EXPRESSION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re807.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {REGULAR_EXPRESSION}.default_create */
void F1563_16024 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1562_15944(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,918,1067,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 64L),sizeof(EIF_INTEGER_32), EIF_TRUE);
	}
	F919_7187(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 64L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_7_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_11_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 8L);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_11_);
	ti4_1 = (EIF_INTEGER_32) tu4_1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,918,1067,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSP2(typres0.id,0,ti4_1,sizeof(EIF_INTEGER_32), EIF_TRUE);
	}
	F919_7187(RTCW(tr1), ((EIF_INTEGER_32) 0L), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_9_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_10_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_12_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 8L);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_12_);
	ti4_1 = (EIF_INTEGER_32) tu4_1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,918,1067,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSP2(typres0.id,0,ti4_1,sizeof(EIF_INTEGER_32), EIF_TRUE);
	}
	F919_7187(RTCW(tr1), ((EIF_INTEGER_32) 0L), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_23_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_24_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTLE;
}

/* {REGULAR_EXPRESSION}.reset */
void F1563_16025 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1562_15981(Current);
	F1563_16026(Current);
	RTLE;
}

/* {REGULAR_EXPRESSION}.wipe_out */
void F1563_16026 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F125_2011(Current);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_5_) = (EIF_NATURAL_32) *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_0_);
	RTLE;
}

/* {REGULAR_EXPRESSION}.compile */
void F1563_16027 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1563_16026(Current);
	F1562_15975(Current, arg1);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_7_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_NATURAL_32) (*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_) * (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
	tu4_1 = (EIF_NATURAL_32) ti4_1;
	if ((EIF_BOOLEAN) (tu4_1 < *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_7_))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_7_);
		ti4_1 = (EIF_INTEGER_32) tu4_1;
		tr1 = F919_7222(RTCW(tr1), ((EIF_INTEGER_32) 0L), ti4_1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {REGULAR_EXPRESSION}.captured_start_position */
EIF_NATURAL_32 F1563_16028 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	ti4_1 = (EIF_INTEGER_32) arg1;
	/* INLINED CODE (SPECIAL.item) */
	ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 2L))));
	/* END INLINED CODE */
	ti4_1 = ti4_3;
	Result = (EIF_NATURAL_32) ti4_1;
	RTLE;
	return Result;
}

/* {REGULAR_EXPRESSION}.captured_end_position */
EIF_INTEGER_32 F1563_16029 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	ti4_1 = (EIF_INTEGER_32) arg1;
	/* INLINED CODE (SPECIAL.item) */
	ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 2L)) + ((EIF_INTEGER_32) 1L))));
	/* END INLINED CODE */
	Result = ti4_3;
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result - ((EIF_INTEGER_32) 1L));
	RTLE;
	return Result;
}

/* {REGULAR_EXPRESSION}.match_substring */
void F1563_16030 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_32 arg2, EIF_NATURAL_32 arg3)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_0_) = (EIF_NATURAL_32) arg2;
	F1563_16053(Current, arg1, arg2, arg3);
	RTLE;
}

/* {REGULAR_EXPRESSION}.next_match */
void F1563_16033 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (((EIF_INTEGER_32) 0L)));
	/* END INLINED CODE */
	ti4_1 = ti4_2;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (((EIF_INTEGER_32) 1L)));
	/* END INLINED CODE */
	ti4_2 = ti4_3;
	if ((EIF_BOOLEAN) (ti4_1 >= ti4_2)) {
		tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_11_5_);
	}
	if (tb1) {
		F1563_16053(Current, *(EIF_REFERENCE *)(Current), (EIF_NATURAL_32) (*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_5_) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)), *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_));
	} else {
		F1563_16053(Current, *(EIF_REFERENCE *)(Current), *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_5_), *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_));
	}
	RTLE;
}

/* {REGULAR_EXPRESSION}.set_next_start */
void F1563_16051 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	
	
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_5_) = (EIF_NATURAL_32) arg1;
}

/* {REGULAR_EXPRESSION}.set_match_count */
void F1563_16052 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	
	
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_2_) = (EIF_NATURAL_32) arg1;
}

/* {REGULAR_EXPRESSION}.match_it */
void F1563_16053 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_32 arg2, EIF_NATURAL_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	EIF_BOOLEAN tb7;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,loc7);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1136, 1).id);
	F1135_10082(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_5_) = (EIF_NATURAL_32) arg2;
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_) = (EIF_NATURAL_32) arg3;
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_2_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_) = (EIF_NATURAL_32) arg2;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_);
	loc4 = (EIF_INTEGER_32) tu4_1;
	loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_9_)) {
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) >= ((EIF_INTEGER_32) 0L))) {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc1 = F22_175(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_));
			} else {
				loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_);
			}
		}
	}
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) >= ((EIF_INTEGER_32) 0L))) {
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_);
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_11_12_))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc3 = F22_177(RTCW(tr1), loc2);
		} else {
			loc3 = (EIF_INTEGER_32) loc2;
		}
	}
	for (;;) {
		if (loc6) break;
		*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_2_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
		tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_7_);
		loc5 = (EIF_INTEGER_32) tu4_1;
		loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - ((EIF_INTEGER_32) 1L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc5 < ((EIF_INTEGER_32) 0L))) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			/* INLINED CODE (SPECIAL.put) */
			*((EIF_INTEGER_32 *)RTCW(tr1) + (loc5)) = ((EIF_INTEGER_32) 0L);
			/* END INLINED CODE */
			;
			loc5--;
		}
		if ((EIF_BOOLEAN) (loc1 >= ((EIF_INTEGER_32) 0L))) {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_)) {
				for (;;) {
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_) > arg3)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr2 = *(EIF_REFERENCE *)(Current);
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_);
						ti4_1 = (EIF_INTEGER_32) tu4_1;
						ti4_1 = F1137_10163(RTCW(tr2), ti4_1);
						ti4_1 = F22_175(RTCW(tr1), ti4_1);
						tb1 = (EIF_BOOLEAN)(ti4_1 == loc1);
					}
					if (tb1) break;
					(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_)) += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
				}
			} else {
				for (;;) {
					tb2 = '\01';
					if (!(EIF_BOOLEAN) (*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_) > arg3)) {
						tr1 = *(EIF_REFERENCE *)(Current);
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_);
						ti4_1 = (EIF_INTEGER_32) tu4_1;
						ti4_1 = F1137_10163(RTCW(tr1), ti4_1);
						tb2 = (EIF_BOOLEAN)(ti4_1 == loc1);
					}
					if (tb2) break;
					(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_)) += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
				}
			}
		} else {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_11_)) {
				if ((EIF_BOOLEAN) (*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_) > arg2)) {
					for (;;) {
						tb3 = '\01';
						if (!(EIF_BOOLEAN) (*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_) > arg3)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_);
							ti4_1 = (EIF_INTEGER_32) tu4_1;
							ti4_1 = F1137_10163(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
							tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 10L));
						}
						if (tb3) break;
						(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_)) += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
					}
				}
			} else {
				loc7 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				if ((EIF_BOOLEAN)(loc7 != NULL)) {
					for (;;) {
						tb4 = '\01';
						if (!(EIF_BOOLEAN) (*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_) > arg3)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_);
							ti4_1 = (EIF_INTEGER_32) tu4_1;
							ti4_1 = F1137_10163(RTCW(tr1), ti4_1);
							tb5 = F21_166(RTCW(loc7), ti4_1);
							tb4 = tb5;
						}
						if (tb4) break;
						(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_)) += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
					}
				}
			}
		}
		if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 0L))) {
			if ((EIF_BOOLEAN) (loc1 >= ((EIF_INTEGER_32) 0L))) {
				tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_);
				loc5 = (EIF_INTEGER_32) tu4_1;
				loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L));
			} else {
				tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_);
				loc5 = (EIF_INTEGER_32) tu4_1;
			}
			if ((EIF_BOOLEAN) (loc5 > loc4)) {
				if ((EIF_BOOLEAN)(loc2 == loc3)) {
					for (;;) {
						tb5 = '\01';
						ti4_1 = (EIF_INTEGER_32) arg3;
						if (!(EIF_BOOLEAN) (loc5 > ti4_1)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							ti4_1 = F1137_10163(RTCW(tr1), loc5);
							tb5 = (EIF_BOOLEAN)(ti4_1 == loc2);
						}
						if (tb5) break;
						loc5++;
					}
				} else {
					for (;;) {
						tb6 = '\01';
						tb7 = '\01';
						ti4_1 = (EIF_INTEGER_32) arg3;
						if (!(EIF_BOOLEAN) (loc5 > ti4_1)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							ti4_1 = F1137_10163(RTCW(tr1), loc5);
							tb7 = (EIF_BOOLEAN)(ti4_1 == loc2);
						}
						if (!tb7) {
							tr1 = *(EIF_REFERENCE *)(Current);
							ti4_1 = F1137_10163(RTCW(tr1), loc5);
							tb6 = (EIF_BOOLEAN)(ti4_1 == loc3);
						}
						if (tb6) break;
						loc5++;
					}
				}
				ti4_1 = (EIF_INTEGER_32) arg3;
				if ((EIF_BOOLEAN) (loc5 > ti4_1)) {
					loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					loc4 = (EIF_INTEGER_32) loc5;
				}
			}
		}
		if ((EIF_BOOLEAN) !loc6) {
			if (F1563_16054(Current, *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
				tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_);
				ti4_1 = (EIF_INTEGER_32) tu4_1;
				/* INLINED CODE (SPECIAL.put) */
				*((EIF_INTEGER_32 *)RTCW(tr1) + (((EIF_INTEGER_32) 0L))) = ti4_1;
				/* END INLINED CODE */
				;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
				tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_5_);
				ti4_1 = (EIF_INTEGER_32) tu4_1;
				/* INLINED CODE (SPECIAL.put) */
				*((EIF_INTEGER_32 *)RTCW(tr1) + (((EIF_INTEGER_32) 1L))) = ti4_1;
				/* END INLINED CODE */
				;
				(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_2_)) /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L);
				loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_2_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
				loc6 = *(EIF_BOOLEAN *)(Current+ _CHROFF_11_9_);
				tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_);
				loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc6 || (EIF_BOOLEAN) (tu4_1 > arg3));
				(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_)) += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
			}
		}
	}
	RTLE;
}

/* {REGULAR_EXPRESSION}.match_start */
EIF_BOOLEAN F1563_16054 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	ti4_1 = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) = (EIF_INTEGER_32) ti4_1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_23_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_24_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_8_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_10_) = (EIF_NATURAL_32) *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_7_);
	loc1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_9_);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_10_);
	loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) (loc1 + tu4_1);
	if ((EIF_BOOLEAN) (*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_11_) < loc1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		ti4_1 = (EIF_INTEGER_32) loc1;
		tr1 = F919_7222(RTCW(tr1), ((EIF_INTEGER_32) 0L), ti4_1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
		*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_11_) = (EIF_NATURAL_32) loc1;
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_13_) = (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_14_) = (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current+ _CHROFF_11_3_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_15_) = (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current+ _CHROFF_11_4_);
	ti4_1 = F1563_16056(Current, ((EIF_INTEGER_32) 0L), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L));
	RTLE;
	return Result;
}

/* {REGULAR_EXPRESSION}.match_recursive */
EIF_INTEGER_32 F1563_16055 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_NATURAL_32 loc6 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_);
	loc3 = *(EIF_BOOLEAN *)(Current+ _CHROFF_11_13_);
	loc4 = *(EIF_BOOLEAN *)(Current+ _CHROFF_11_15_);
	loc5 = *(EIF_BOOLEAN *)(Current+ _CHROFF_11_14_);
	loc6 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_8_);
	loc7 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_24_);
	Result = F1563_16056(Current, arg1, arg2, arg3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) = (EIF_INTEGER_32) loc1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) loc2;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_13_) = (EIF_BOOLEAN) loc3;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_15_) = (EIF_BOOLEAN) loc4;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_14_) = (EIF_BOOLEAN) loc5;
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_8_) = (EIF_NATURAL_32) loc6;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_24_) = (EIF_INTEGER_32) loc7;
	RTLE;
	return Result;
}

/* {REGULAR_EXPRESSION}.match_internal */
EIF_INTEGER_32 F1563_16056 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc8 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc9 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc10 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc11 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc14 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc15 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc2 = (EIF_INTEGER_32) arg1;
	if (arg2) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_24_))++;
		tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_12_);
		ti4_1 = (EIF_INTEGER_32) tu4_1;
		if ((EIF_BOOLEAN) (ti4_1 <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_24_))) {
			loc14 = (EIF_NATURAL_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_24_) + ((EIF_INTEGER_32) 1L)));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
			ti4_1 = (EIF_INTEGER_32) loc14;
			tr1 = F919_7222(RTCW(tr1), ((EIF_INTEGER_32) 0L), ti4_1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
			*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_12_) = (EIF_NATURAL_32) loc14;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_24_);
		ti4_2 = (EIF_INTEGER_32) ti4_2;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + (ti4_2)) = ti4_1;
		/* END INLINED CODE */
		;
	}
	for (;;) {
		if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = F18_87(RTCW(tr1), loc2);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 70L))) {
			Result = F1563_16057(Current, loc2, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 70L)));
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_);
		} else {
			switch (loc1) {
				case 70L:
					Result = F1563_16058(Current, loc2);
					if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					}
					break;
				case 66L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F18_87(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 67L))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc5 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 3L)));
						loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 * ((EIF_INTEGER_32) 2L));
						tb1 = '\0';
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_8_);
						ti4_1 = (EIF_INTEGER_32) tu4_1;
						if ((EIF_BOOLEAN) (loc5 < ti4_1)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
							/* INLINED CODE (SPECIAL.item) */
							ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
							/* END INLINED CODE */
							ti4_1 = ti4_2;
							tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
						}
						if (tb1) {
							Result = F1563_16055(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 4L)), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							ti4_1 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
							Result = F1563_16055(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)) + ti4_1), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
						}
					} else {
						Result = F1563_16055(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 1);
						if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 1L))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							ti4_1 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 3L)));
							loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)) + ti4_1);
							for (;;) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								ti4_1 = F18_87(RTCW(tr1), loc2);
								if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 56L))) break;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								ti4_2 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
								loc2 += ti4_2;
							}
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							ti4_2 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
							loc2 += ti4_2;
						}
						Result = F1563_16055(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
					}
					break;
				case 67L:
					loc2 += ((EIF_INTEGER_32) 2L);
					break;
				case 0L:
					tb1 = '\0';
					if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_5_)) {
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_6_);
						ti4_2 = (EIF_INTEGER_32) tu4_1;
						tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) == ti4_2);
					}
					if (tb1) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
						tu4_1 = (EIF_NATURAL_32) ti4_2;
						F1563_16051(Current, tu4_1);
						F1563_16052(Current, *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_8_));
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					}
					break;
				case 12L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc7 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					tb1 = F111_1791(Current, loc7);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_11_13_) = (EIF_BOOLEAN) tb1;
					tb1 = F111_1792(Current, loc7);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_11_14_) = (EIF_BOOLEAN) tb1;
					tb1 = F111_1793(Current, loc7);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_11_15_) = (EIF_BOOLEAN) tb1;
					loc2 += ((EIF_INTEGER_32) 2L);
					break;
				case 60L:
				case 62L:
					loc12 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_23_);
					loc13 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_24_);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_23_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc13 + ((EIF_INTEGER_32) 1L));
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_24_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_23_) - ((EIF_INTEGER_32) 1L));
					Result = F1563_16058(Current, loc2);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_23_) = (EIF_INTEGER_32) loc12;
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_24_) = (EIF_INTEGER_32) loc13;
					loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_2 = F18_87(RTCW(tr1), loc2);
					if ((EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 57L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						if (arg3) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
							loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
							for (;;) {
								if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 56L))) break;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								ti4_2 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
								loc2 += ti4_2;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								loc1 = F18_87(RTCW(tr1), loc2);
							}
							loc2 += ((EIF_INTEGER_32) 2L);
							*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_8_) = (EIF_NATURAL_32) *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_2_);
						}
					}
					break;
				case 61L:
				case 63L:
					if ((EIF_BOOLEAN)(F1563_16058(Current, loc2) == ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						if (arg3) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_);
							loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L));
						}
					}
					break;
				case 64L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_2 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_)) -= ti4_2;
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_0_);
					ti4_2 = (EIF_INTEGER_32) tu4_1;
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) < ti4_2)) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2 += ((EIF_INTEGER_32) 2L);
					}
					break;
				case 55L:
					loc11 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_9_);
					(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_9_)) += *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_10_);
					loc15 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_9_);
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_10_);
					loc15 = (EIF_NATURAL_32) (EIF_NATURAL_32) (loc15 + tu4_1);
					if ((EIF_BOOLEAN) (*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_11_) < loc15)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
						ti4_2 = (EIF_INTEGER_32) loc15;
						tr1 = F919_7222(RTCW(tr1), ((EIF_INTEGER_32) 0L), ti4_2);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
						*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_11_) = (EIF_NATURAL_32) loc15;
					}
					loc9 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_9_);
					loc10 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_10_);
					loc10 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_NATURAL_32) (loc11 + loc10) - (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L));
					loc8 = (EIF_NATURAL_32) loc11;
					for (;;) {
						if ((EIF_BOOLEAN) (loc8 > loc10)) break;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
						ti4_2 = (EIF_INTEGER_32) loc8;
						/* INLINED CODE (SPECIAL.item) */
						ti4_4 = *((EIF_INTEGER_32 *)RTCW(tr2) + (ti4_2));
						/* END INLINED CODE */
						ti4_2 = ti4_4;
						ti4_3 = (EIF_INTEGER_32) loc9;
						/* INLINED CODE (SPECIAL.put) */
						*((EIF_INTEGER_32 *)RTCW(tr1) + (ti4_3)) = ti4_2;
						/* END INLINED CODE */
						;
						loc9 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
						loc8 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
					}
					loc5 = F1563_16055(Current, ((EIF_INTEGER_32) 0L), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
					*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_9_) = (EIF_NATURAL_32) loc11;
					if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 1L))) {
						*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_8_) = (EIF_NATURAL_32) *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_2_);
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_5_);
						ti4_2 = (EIF_INTEGER_32) tu4_1;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) = (EIF_INTEGER_32) ti4_2;
						loc2++;
					} else {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					}
					break;
				case 65L:
					loc5 = (EIF_INTEGER_32) loc2;
					loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
					loc3 = F1563_16058(Current, loc2);
					loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc1 = F18_87(RTCW(tr1), loc2);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 65L)) && (EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 56L)))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
						for (;;) {
							if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 56L))) break;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							ti4_2 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
							loc2 += ti4_2;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							loc1 = F18_87(RTCW(tr1), loc2);
						}
						*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_8_) = (EIF_NATURAL_32) *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_2_);
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_5_);
						ti4_2 = (EIF_INTEGER_32) tu4_1;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) = (EIF_INTEGER_32) ti4_2;
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 57L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) == loc6))) {
							loc2 += ((EIF_INTEGER_32) 2L);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							ti4_2 = F18_87(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
							if ((EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 12L))) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								ti4_2 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 3L)));
								F1562_15972(Current, ti4_2);
							}
							if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 59L))) {
								Result = F1563_16055(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)), (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
								if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 1L))) {
									Result = F1563_16055(Current, loc5, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
								}
							} else {
								Result = F1563_16055(Current, loc5, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
								if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 1L))) {
									Result = F1563_16055(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)), (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
								}
							}
						}
					}
					break;
				case 56L:
					for (;;) {
						if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 56L))) break;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_2 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
						loc2 += ti4_2;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc1 = F18_87(RTCW(tr1), loc2);
					}
					break;
				case 68L:
					loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					if ((EIF_BOOLEAN)(F1563_16055(Current, loc6, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					} else {
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
						for (;;) {
							if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 56L))) break;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							ti4_2 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)));
							loc6 += ti4_2;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							loc1 = F18_87(RTCW(tr1), loc6);
						}
						loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 2L));
					}
					break;
				case 69L:
					loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
					for (;;) {
						if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 56L))) break;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_2 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)));
						loc6 += ti4_2;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc1 = F18_87(RTCW(tr1), loc6);
					}
					if ((EIF_BOOLEAN)(F1563_16055(Current, (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 2L)), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					} else {
						loc2++;
					}
					break;
				case 57L:
				case 58L:
				case 59L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc5 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - loc5);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
					ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_24_);
					ti4_2 = (EIF_INTEGER_32) ti4_2;
					/* INLINED CODE (SPECIAL.item) */
					ti4_4 = *((EIF_INTEGER_32 *)RTCW(tr1) + (ti4_2));
					/* END INLINED CODE */
					loc6 = ti4_4;
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_24_))--;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc1 = F18_87(RTCW(tr1), loc5);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 60L)) || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 61L))) || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 65L))) || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 62L))) || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 63L)))) {
						ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
						tu4_1 = (EIF_NATURAL_32) ti4_2;
						F1563_16051(Current, tu4_1);
						F1563_16052(Current, *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_8_));
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					} else {
						if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 66L))) {
							loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 70L));
							loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 * ((EIF_INTEGER_32) 2L));
							if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
								tr2 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
								tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_9_);
								ti4_2 = (EIF_INTEGER_32) tu4_1;
								/* INLINED CODE (SPECIAL.item) */
								ti4_4 = *((EIF_INTEGER_32 *)RTCW(tr2) + ((EIF_INTEGER_32) (ti4_2 + loc4)));
								/* END INLINED CODE */
								ti4_2 = ti4_4;
								/* INLINED CODE (SPECIAL.put) */
								*((EIF_INTEGER_32 *)RTCW(tr1) + (loc4)) = ti4_2;
								/* END INLINED CODE */
								;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
								/* INLINED CODE (SPECIAL.put) */
								*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)))) = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
								/* END INLINED CODE */
								;
								tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_8_);
								ti4_2 = (EIF_INTEGER_32) tu4_1;
								if ((EIF_BOOLEAN) (ti4_2 <= loc4)) {
									tu4_1 = (EIF_NATURAL_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 2L));
									*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_8_) = (EIF_NATURAL_32) tu4_1;
								}
							}
						}
						*(EIF_BOOLEAN *)(Current+ _CHROFF_11_13_) = (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_);
						*(EIF_BOOLEAN *)(Current+ _CHROFF_11_14_) = (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current+ _CHROFF_11_3_);
						*(EIF_BOOLEAN *)(Current+ _CHROFF_11_15_) = (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current+ _CHROFF_11_4_);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc1 = F18_87(RTCW(tr1), loc2);
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 57L)) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) <= loc6))) {
							loc2 += ((EIF_INTEGER_32) 2L);
						} else {
							if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 59L))) {
								Result = F1563_16055(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)), (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
								if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 1L))) {
									Result = F1563_16055(Current, loc5, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
								}
							} else {
								Result = F1563_16055(Current, loc5, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
								if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 1L))) {
									Result = F1563_16055(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)), (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
								}
							}
						}
					}
					break;
				case 13L:
					tb1 = '\0';
					if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_7_)) {
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_0_);
						ti4_2 = (EIF_INTEGER_32) tu4_1;
						tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) == ti4_2);
					}
					if (tb1) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_14_)) {
							tb1 = '\0';
							tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_0_);
							ti4_2 = (EIF_INTEGER_32) tu4_1;
							if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_2)) {
								tr1 = *(EIF_REFERENCE *)(Current);
								ti4_2 = F1137_10163(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) - ((EIF_INTEGER_32) 1L)));
								tb1 = (EIF_BOOLEAN)(ti4_2 != ((EIF_INTEGER_32) 10L));
							}
							if (tb1) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								loc2++;
							}
						} else {
							tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_0_);
							ti4_2 = (EIF_INTEGER_32) tu4_1;
							if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_2)) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								loc2++;
							}
						}
					}
					break;
				case 1L:
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_0_);
					ti4_2 = (EIF_INTEGER_32) tu4_1;
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_2)) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2++;
					}
					break;
				case 14L:
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_14_)) {
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
						ti4_2 = (EIF_INTEGER_32) tu4_1;
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) <= ti4_2)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							ti4_2 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
							if ((EIF_BOOLEAN)(ti4_2 != ((EIF_INTEGER_32) 10L))) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								loc2++;
							}
						} else {
							if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_8_)) {
								loc2++;
							} else {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							}
						}
					} else {
						if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_8_)) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						} else {
							if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_6_)) {
								tb1 = '\01';
								tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
								ti4_2 = (EIF_INTEGER_32) tu4_1;
								if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) < ti4_2)) {
									tb2 = '\0';
									tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
									ti4_2 = (EIF_INTEGER_32) tu4_1;
									if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) == ti4_2)) {
										tr1 = *(EIF_REFERENCE *)(Current);
										ti4_2 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
										tb2 = (EIF_BOOLEAN)(ti4_2 != ((EIF_INTEGER_32) 10L));
									}
									tb1 = tb2;
								}
								if (tb1) {
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								} else {
									loc2++;
								}
							} else {
								tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
								ti4_2 = (EIF_INTEGER_32) tu4_1;
								if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) <= ti4_2)) {
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								} else {
									loc2++;
								}
							}
						}
					}
					break;
				case 11L:
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
					ti4_2 = (EIF_INTEGER_32) tu4_1;
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) <= ti4_2)) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2++;
					}
					break;
				case 10L:
					tb1 = '\01';
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
					ti4_2 = (EIF_INTEGER_32) tu4_1;
					if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) < ti4_2)) {
						tb2 = '\0';
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
						ti4_2 = (EIF_INTEGER_32) tu4_1;
						if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) == ti4_2)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							ti4_2 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
							tb2 = (EIF_BOOLEAN)(ti4_2 != ((EIF_INTEGER_32) 10L));
						}
						tb1 = tb2;
					}
					if (tb1) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2++;
					}
					break;
				case 2L:
					tb1 = '\0';
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_0_);
					ti4_2 = (EIF_INTEGER_32) tu4_1;
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_2)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
						tr2 = *(EIF_REFERENCE *)(Current);
						ti4_2 = F1137_10163(RTCW(tr2), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) - ((EIF_INTEGER_32) 1L)));
						tb2 = F21_166(RTCW(tr1), ti4_2);
						tb1 = tb2;
					}
					tb2 = '\0';
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
					ti4_2 = (EIF_INTEGER_32) tu4_1;
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) <= ti4_2)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
						tr2 = *(EIF_REFERENCE *)(Current);
						ti4_2 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
						tb3 = F21_166(RTCW(tr1), ti4_2);
						tb2 = tb3;
					}
					if ((EIF_BOOLEAN)(tb1 != tb2)) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2++;
					}
					break;
				case 3L:
					tb1 = '\0';
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_0_);
					ti4_2 = (EIF_INTEGER_32) tu4_1;
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_2)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
						tr2 = *(EIF_REFERENCE *)(Current);
						ti4_2 = F1137_10163(RTCW(tr2), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) - ((EIF_INTEGER_32) 1L)));
						tb2 = F21_166(RTCW(tr1), ti4_2);
						tb1 = tb2;
					}
					tb2 = '\0';
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
					ti4_2 = (EIF_INTEGER_32) tu4_1;
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) <= ti4_2)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
						tr2 = *(EIF_REFERENCE *)(Current);
						ti4_2 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
						tb3 = F21_166(RTCW(tr1), ti4_2);
						tb2 = tb3;
					}
					if ((EIF_BOOLEAN)(tb1 == tb2)) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2++;
					}
					break;
				case 15L:
					tb1 = '\0';
					tb2 = '\0';
					if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_15_)) {
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
						ti4_2 = (EIF_INTEGER_32) tu4_1;
						tb2 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) <= ti4_2);
					}
					if (tb2) {
						tr1 = *(EIF_REFERENCE *)(Current);
						ti4_2 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
						tb1 = (EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 10L));
					}
					if (tb1) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
						ti4_2 = (EIF_INTEGER_32) tu4_1;
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_2)) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						} else {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
							loc2++;
						}
					}
					break;
				case 4L:
					tb1 = '\01';
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
					ti4_2 = (EIF_INTEGER_32) tu4_1;
					if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_2)) {
						tr1 = RTOSCF(1778,F110_1778, (Current));
						tr2 = *(EIF_REFERENCE *)(Current);
						ti4_2 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
						tb2 = F21_166(RTCW(tr1), ti4_2);
						tb1 = tb2;
					}
					if (tb1) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
						loc2++;
					}
					break;
				case 5L:
					tb1 = '\01';
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
					ti4_2 = (EIF_INTEGER_32) tu4_1;
					if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_2)) {
						tr1 = RTOSCF(1778,F110_1778, (Current));
						tr2 = *(EIF_REFERENCE *)(Current);
						ti4_2 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
						tb2 = F21_166(RTCW(tr1), ti4_2);
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
						loc2++;
					}
					break;
				case 6L:
					tb1 = '\01';
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
					ti4_2 = (EIF_INTEGER_32) tu4_1;
					if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_2)) {
						tr1 = RTOSCF(1786,F110_1786, (Current));
						tr2 = *(EIF_REFERENCE *)(Current);
						ti4_2 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
						tb2 = F21_166(RTCW(tr1), ti4_2);
						tb1 = tb2;
					}
					if (tb1) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
						loc2++;
					}
					break;
				case 7L:
					tb1 = '\01';
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
					ti4_2 = (EIF_INTEGER_32) tu4_1;
					if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_2)) {
						tr1 = RTOSCF(1786,F110_1786, (Current));
						tr2 = *(EIF_REFERENCE *)(Current);
						ti4_2 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
						tb2 = F21_166(RTCW(tr1), ti4_2);
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
						loc2++;
					}
					break;
				case 8L:
					tb1 = '\01';
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
					ti4_2 = (EIF_INTEGER_32) tu4_1;
					if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_2)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
						tr2 = *(EIF_REFERENCE *)(Current);
						ti4_2 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
						tb2 = F21_166(RTCW(tr1), ti4_2);
						tb1 = tb2;
					}
					if (tb1) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
						loc2++;
					}
					break;
				case 9L:
					tb1 = '\01';
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
					ti4_2 = (EIF_INTEGER_32) tu4_1;
					if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_2)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
						tr2 = *(EIF_REFERENCE *)(Current);
						ti4_2 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
						tb2 = F21_166(RTCW(tr1), ti4_2);
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
						loc2++;
					}
					break;
				case 54L:
					Result = F1563_16060(Current, loc2);
					loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_);
					break;
				case 53L:
					Result = F1563_16061(Current, loc2);
					loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_);
					break;
				case 16L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc3 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc2 += ((EIF_INTEGER_32) 2L);
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
					ti4_2 = (EIF_INTEGER_32) tu4_1;
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) + loc3) - ((EIF_INTEGER_32) 1L)) > ti4_2)) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_13_)) {
							for (;;) {
								if ((EIF_BOOLEAN) (loc3 <= ((EIF_INTEGER_32) 0L))) break;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								ti4_2 = F18_88(RTCW(tr2), loc2);
								ti4_2 = F22_175(RTCW(tr1), ti4_2);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr2 = *(EIF_REFERENCE *)(Current);
								ti4_3 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
								ti4_3 = F22_175(RTCW(tr1), ti4_3);
								if ((EIF_BOOLEAN)(ti4_2 != ti4_3)) {
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								} else {
									loc2++;
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
									loc3--;
								}
							}
						} else {
							for (;;) {
								if ((EIF_BOOLEAN) (loc3 <= ((EIF_INTEGER_32) 0L))) break;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								ti4_2 = F18_88(RTCW(tr1), loc2);
								tr1 = *(EIF_REFERENCE *)(Current);
								ti4_3 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
								if ((EIF_BOOLEAN)(ti4_2 != ti4_3)) {
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								} else {
									loc2++;
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
									loc3--;
								}
							}
						}
					}
					break;
				case 26L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc5 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc2 += ((EIF_INTEGER_32) 3L);
					Result = F1563_16062(Current, loc2, loc5, loc5, (EIF_BOOLEAN) 0);
					break;
				case 24L:
				case 25L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc5 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc2 += ((EIF_INTEGER_32) 3L);
					Result = F1563_16062(Current, loc2, ((EIF_INTEGER_32) 0L), loc5, (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 25L)));
					break;
				case 18L:
				case 19L:
					loc2 += ((EIF_INTEGER_32) 2L);
					ti4_2 = RTOSCF(16022,F1562_16022, (Current));
					Result = F1563_16062(Current, loc2, ((EIF_INTEGER_32) 0L), ti4_2, (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 19L)));
					break;
				case 20L:
				case 21L:
					loc2 += ((EIF_INTEGER_32) 2L);
					ti4_2 = RTOSCF(16022,F1562_16022, (Current));
					Result = F1563_16062(Current, loc2, ((EIF_INTEGER_32) 1L), ti4_2, (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 21L)));
					break;
				case 22L:
				case 23L:
					loc2 += ((EIF_INTEGER_32) 2L);
					Result = F1563_16062(Current, loc2, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 23L)));
					break;
				case 17L:
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
					ti4_2 = (EIF_INTEGER_32) tu4_1;
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_2)) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2++;
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_13_)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							ti4_2 = F18_88(RTCW(tr2), loc2);
							ti4_2 = F22_175(RTCW(tr1), ti4_2);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr2 = *(EIF_REFERENCE *)(Current);
							ti4_3 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
							ti4_3 = F22_175(RTCW(tr1), ti4_3);
							if ((EIF_BOOLEAN)(ti4_2 == ti4_3)) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							}
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							ti4_2 = F18_88(RTCW(tr1), loc2);
							tr1 = *(EIF_REFERENCE *)(Current);
							ti4_3 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
							if ((EIF_BOOLEAN)(ti4_2 == ti4_3)) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							}
						}
						if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
							loc2++;
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
						}
					}
					break;
				case 35L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc5 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc2 += ((EIF_INTEGER_32) 3L);
					Result = F1563_16063(Current, loc2, loc5, loc5, (EIF_BOOLEAN) 0);
					break;
				case 33L:
				case 34L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc5 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc2 += ((EIF_INTEGER_32) 3L);
					Result = F1563_16063(Current, loc2, ((EIF_INTEGER_32) 0L), loc5, (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 34L)));
					break;
				case 27L:
				case 28L:
					loc2 += ((EIF_INTEGER_32) 2L);
					ti4_2 = RTOSCF(16022,F1562_16022, (Current));
					Result = F1563_16063(Current, loc2, ((EIF_INTEGER_32) 0L), ti4_2, (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 28L)));
					break;
				case 29L:
				case 30L:
					loc2 += ((EIF_INTEGER_32) 2L);
					ti4_2 = RTOSCF(16022,F1562_16022, (Current));
					Result = F1563_16063(Current, loc2, ((EIF_INTEGER_32) 1L), ti4_2, (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 30L)));
					break;
				case 31L:
				case 32L:
					loc2 += ((EIF_INTEGER_32) 2L);
					Result = F1563_16063(Current, loc2, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 32L)));
					break;
				case 44L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc5 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc2 += ((EIF_INTEGER_32) 3L);
					Result = F1563_16064(Current, loc2, loc5, loc5, (EIF_BOOLEAN) 1);
					break;
				case 42L:
				case 43L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc5 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc2 += ((EIF_INTEGER_32) 3L);
					Result = F1563_16064(Current, loc2, ((EIF_INTEGER_32) 0L), loc5, (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 43L)));
					break;
				case 36L:
				case 37L:
					loc2 += ((EIF_INTEGER_32) 2L);
					ti4_2 = RTOSCF(16022,F1562_16022, (Current));
					Result = F1563_16064(Current, loc2, ((EIF_INTEGER_32) 0L), ti4_2, (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 37L)));
					break;
				case 38L:
				case 39L:
					loc2 += ((EIF_INTEGER_32) 2L);
					ti4_2 = RTOSCF(16022,F1562_16022, (Current));
					Result = F1563_16064(Current, loc2, ((EIF_INTEGER_32) 1L), ti4_2, (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 39L)));
					break;
				case 40L:
				case 41L:
					loc2 += ((EIF_INTEGER_32) 2L);
					Result = F1563_16064(Current, loc2, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 41L)));
					break;
				default:
					break;
			}
		}
	}
	RTLE;
	return Result;
}

/* {REGULAR_EXPRESSION}.match_additional_bracket */
EIF_INTEGER_32 F1563_16057 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 * ((EIF_INTEGER_32) 2L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc1));
	/* END INLINED CODE */
	loc2 = ti4_2;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L))));
	/* END INLINED CODE */
	loc3 = ti4_3;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_9_);
	ti4_1 = (EIF_INTEGER_32) tu4_1;
	/* INLINED CODE (SPECIAL.item) */
	ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_1 + loc1)));
	/* END INLINED CODE */
	loc4 = ti4_3;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_9_);
	ti4_2 = (EIF_INTEGER_32) tu4_1;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_2 + loc1))) = ti4_1;
	/* END INLINED CODE */
	;
	Result = F1563_16058(Current, arg1);
	if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 1L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + (loc1)) = loc2;
		/* END INLINED CODE */
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)))) = loc3;
		/* END INLINED CODE */
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_9_);
		ti4_1 = (EIF_INTEGER_32) tu4_1;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_1 + loc1))) = loc4;
		/* END INLINED CODE */
		;
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}
	RTLE;
	return Result;
}

/* {REGULAR_EXPRESSION}.next_matching_alternate */
EIF_INTEGER_32 F1563_16058 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) arg1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 56L))) break;
		loc2 = F1563_16055(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) + ((EIF_INTEGER_32) 2L)), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
		if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 1L))) {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			ti4_1 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) + ((EIF_INTEGER_32) 1L)));
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_)) += ti4_1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc1 = F18_87(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_));
		}
	}
	RTLE;
	return Result;
}

/* {REGULAR_EXPRESSION}.match_ref */
EIF_INTEGER_32 F1563_16059 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
	ti4_1 = (EIF_INTEGER_32) tu4_1;
	if ((EIF_BOOLEAN) (arg3 > (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - arg1) + ((EIF_INTEGER_32) 1L)))) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		/* INLINED CODE (SPECIAL.item) */
		ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (arg2));
		/* END INLINED CODE */
		loc1 = ti4_2;
		loc2 = (EIF_INTEGER_32) arg1;
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + arg3);
		Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_13_)) {
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 >= loc3)) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tr2 = *(EIF_REFERENCE *)(Current);
				ti4_1 = F1137_10163(RTCW(tr2), loc1);
				ti4_1 = F22_175(RTCW(tr1), ti4_1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tr2 = *(EIF_REFERENCE *)(Current);
				ti4_2 = F1137_10163(RTCW(tr2), loc2);
				ti4_2 = F22_175(RTCW(tr1), ti4_2);
				if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
					loc1++;
					loc2++;
				} else {
					loc1 = (EIF_INTEGER_32) loc3;
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				}
			}
		} else {
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 >= loc3)) break;
				tr1 = *(EIF_REFERENCE *)(Current);
				ti4_1 = F1137_10163(RTCW(tr1), loc1);
				tr1 = *(EIF_REFERENCE *)(Current);
				ti4_2 = F1137_10163(RTCW(tr1), loc2);
				if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
					loc1++;
					loc2++;
				} else {
					loc1 = (EIF_INTEGER_32) loc3;
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {REGULAR_EXPRESSION}.match_repeated_refs */
EIF_INTEGER_32 F1563_16060 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc5 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
	loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 * ((EIF_INTEGER_32) 2L));
	loc1 += ((EIF_INTEGER_32) 2L);
	tb1 = '\01';
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_8_);
	ti4_1 = (EIF_INTEGER_32) tu4_1;
	if (!(EIF_BOOLEAN) (loc5 >= ti4_1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		/* INLINED CODE (SPECIAL.item) */
		ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
		/* END INLINED CODE */
		ti4_1 = ti4_2;
		tb1 = (EIF_BOOLEAN) (ti4_1 <= ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
		loc6 = (EIF_INTEGER_32) tu4_1;
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
		loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 - ti4_1) + ((EIF_INTEGER_32) 2L));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		/* INLINED CODE (SPECIAL.item) */
		ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L))));
		/* END INLINED CODE */
		loc6 = ti4_3;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		/* INLINED CODE (SPECIAL.item) */
		ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
		/* END INLINED CODE */
		ti4_1 = ti4_2;
		loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 - ti4_1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = F18_87(RTCW(tr1), loc1);
	switch (ti4_1) {
		case 45L:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc4 = RTOSCF(16022,F1562_16022, (Current));
			break;
		case 46L:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc4 = RTOSCF(16022,F1562_16022, (Current));
			break;
		case 47L:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc4 = RTOSCF(16022,F1562_16022, (Current));
			break;
		case 48L:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc4 = RTOSCF(16022,F1562_16022, (Current));
			break;
		case 49L:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			break;
		case 50L:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			break;
		case 51L:
		case 52L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			ti4_1 = F18_87(RTCW(tr1), loc1);
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 52L));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc3 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc4 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
				loc4 = RTOSCF(16022,F1562_16022, (Current));
			}
			loc1 += ((EIF_INTEGER_32) 3L);
			break;
		default:
			if ((EIF_BOOLEAN)(F1563_16059(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_), loc5, loc6) == ((EIF_INTEGER_32) 1L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_)) += loc6;
				loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			} else {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			}
			break;
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc6 > ((EIF_INTEGER_32) 0L)))) {
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc2 > loc3)) break;
			if ((EIF_BOOLEAN)(F1563_16059(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_), loc5, loc6) == ((EIF_INTEGER_32) 1L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_)) += loc6;
				loc2++;
			} else {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc3 < loc4))) {
			if (loc8) {
				loc2 = (EIF_INTEGER_32) loc3;
				for (;;) {
					if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) break;
					if ((EIF_BOOLEAN)(F1563_16055(Current, loc1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					} else {
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (loc2 >= loc4)) {
							tb1 = (EIF_BOOLEAN)(F1563_16059(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_), loc5, loc6) != ((EIF_INTEGER_32) 1L));
						}
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						} else {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_)) += loc6;
							loc2++;
						}
					}
				}
			} else {
				loc7 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
				loc2 = (EIF_INTEGER_32) loc3;
				for (;;) {
					if ((EIF_BOOLEAN) (loc2 >= loc4)) break;
					if ((EIF_BOOLEAN)(F1563_16059(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_), loc5, loc6) == ((EIF_INTEGER_32) 1L))) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_)) += loc6;
						loc2++;
					} else {
						loc2 = (EIF_INTEGER_32) loc4;
					}
				}
				for (;;) {
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) < loc7)) break;
					if ((EIF_BOOLEAN)(F1563_16055(Current, loc1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 - ((EIF_INTEGER_32) 1L));
					} else {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_)) -= loc6;
					}
				}
				if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				}
			}
		}
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) loc1;
	RTLE;
	return Result;
}

/* {REGULAR_EXPRESSION}.match_repeated_classes */
EIF_INTEGER_32 F1563_16061 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc9 = F18_89(RTCW(tr1), loc3);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 2L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = F18_87(RTCW(tr1), loc1);
	switch (ti4_1) {
		case 45L:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc6 = RTOSCF(16022,F1562_16022, (Current));
			break;
		case 46L:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc6 = RTOSCF(16022,F1562_16022, (Current));
			break;
		case 47L:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc6 = RTOSCF(16022,F1562_16022, (Current));
			break;
		case 48L:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc6 = RTOSCF(16022,F1562_16022, (Current));
			break;
		case 49L:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			break;
		case 50L:
			loc1++;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			break;
		case 51L:
		case 52L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			ti4_1 = F18_87(RTCW(tr1), loc1);
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 52L));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc5 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc6 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
			if ((EIF_BOOLEAN)(loc6 == ((EIF_INTEGER_32) 0L))) {
				loc6 = RTOSCF(16022,F1562_16022, (Current));
			}
			loc1 += ((EIF_INTEGER_32) 3L);
			break;
		default:
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			break;
	}
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc5)) break;
		tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
		ti4_1 = (EIF_INTEGER_32) tu4_1;
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L));
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			loc7 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tb1 = F18_91(RTCW(tr1), loc9, loc7);
			if (tb1) {
				loc2++;
			} else {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L));
			}
		}
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc5 < loc6))) {
		if (loc8) {
			loc2 = (EIF_INTEGER_32) loc5;
			for (;;) {
				if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) break;
				if ((EIF_BOOLEAN)(F1563_16055(Current, loc1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				} else {
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (loc2 >= loc6)) {
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
						ti4_1 = (EIF_INTEGER_32) tu4_1;
						tb1 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1);
					}
					if (tb1) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current);
						loc7 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						tb1 = F18_91(RTCW(tr1), loc9, loc7);
						if (tb1) {
							loc2++;
						} else {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						}
					}
				}
			}
		} else {
			loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
			loc2 = (EIF_INTEGER_32) loc5;
			for (;;) {
				tb1 = '\01';
				if (!(EIF_BOOLEAN) (loc2 >= loc6)) {
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
					ti4_1 = (EIF_INTEGER_32) tu4_1;
					tb1 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1);
				}
				if (tb1) break;
				tr1 = *(EIF_REFERENCE *)(Current);
				loc7 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tb2 = F18_91(RTCW(tr1), loc9, loc7);
				if (tb2) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
					loc2++;
				} else {
					loc2 = (EIF_INTEGER_32) loc6;
				}
			}
			for (;;) {
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) < loc4)) break;
				if ((EIF_BOOLEAN)(F1563_16055(Current, loc1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
				}
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))--;
			}
			if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			}
		}
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) loc1;
	RTLE;
	return Result;
}

/* {REGULAR_EXPRESSION}.match_repeated_characters */
EIF_INTEGER_32 F1563_16062 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_BOOLEAN arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
	ti4_1 = (EIF_INTEGER_32) tu4_1;
	if ((EIF_BOOLEAN) (arg2 > (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_)) + ((EIF_INTEGER_32) 1L)))) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc3 = F18_88(RTCW(tr1), (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)));
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_13_)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			ti4_1 = F22_175(RTCW(tr1), loc3);
			loc3 = (EIF_INTEGER_32) ti4_1;
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > arg2)) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tr2 = *(EIF_REFERENCE *)(Current);
				ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
				ti4_1 = F22_175(RTCW(tr1), ti4_1);
				if ((EIF_BOOLEAN)(loc3 != ti4_1)) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
				} else {
					loc1++;
				}
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
			}
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg2 < arg3))) {
				if (arg4) {
					loc1 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) break;
						if ((EIF_BOOLEAN)(F1563_16055(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							tb1 = '\01';
							if (!(EIF_BOOLEAN) (loc1 >= arg3)) {
								tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
								ti4_1 = (EIF_INTEGER_32) tu4_1;
								tb1 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1);
							}
							if (tb1) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr2 = *(EIF_REFERENCE *)(Current);
								ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
								ti4_1 = F22_175(RTCW(tr1), ti4_1);
								if ((EIF_BOOLEAN)(loc3 != ti4_1)) {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								} else {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
									loc1++;
								}
							}
						}
					}
				} else {
					loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
					loc1 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
						tb1 = '\01';
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
						ti4_1 = (EIF_INTEGER_32) tu4_1;
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr2 = *(EIF_REFERENCE *)(Current);
							ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
							ti4_1 = F22_175(RTCW(tr1), ti4_1);
							tb1 = (EIF_BOOLEAN)(loc3 != ti4_1);
						}
						if (tb1) {
							loc1 = (EIF_INTEGER_32) arg3;
						} else {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
							loc1++;
						}
					}
					for (;;) {
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) < loc2)) break;
						if ((EIF_BOOLEAN)(F1563_16055(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))--;
					}
					if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
						RTLE;
						return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					}
				}
			}
		} else {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > arg2)) break;
				tr1 = *(EIF_REFERENCE *)(Current);
				ti4_1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
				if ((EIF_BOOLEAN)(loc3 != ti4_1)) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
				} else {
					loc1++;
				}
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
			}
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg2 < arg3))) {
				if (arg4) {
					loc1 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) break;
						if ((EIF_BOOLEAN)(F1563_16055(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							tb1 = '\01';
							if (!(EIF_BOOLEAN) (loc1 >= arg3)) {
								tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
								ti4_1 = (EIF_INTEGER_32) tu4_1;
								tb1 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1);
							}
							if (tb1) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								tr1 = *(EIF_REFERENCE *)(Current);
								ti4_1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
								if ((EIF_BOOLEAN)(loc3 != ti4_1)) {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								} else {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
									loc1++;
								}
							}
						}
					}
				} else {
					loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
					loc1 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
						tb1 = '\01';
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
						ti4_1 = (EIF_INTEGER_32) tu4_1;
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							ti4_1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
							tb1 = (EIF_BOOLEAN)(loc3 != ti4_1);
						}
						if (tb1) {
							loc1 = (EIF_INTEGER_32) arg3;
						} else {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
							loc1++;
						}
					}
					for (;;) {
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) < loc2)) break;
						if ((EIF_BOOLEAN)(F1563_16055(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))--;
					}
					if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
						RTLE;
						return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {REGULAR_EXPRESSION}.match_not_repeated_characters */
EIF_INTEGER_32 F1563_16063 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_BOOLEAN arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
	ti4_1 = (EIF_INTEGER_32) tu4_1;
	if ((EIF_BOOLEAN) (arg2 > (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_)) + ((EIF_INTEGER_32) 1L)))) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc3 = F18_88(RTCW(tr1), (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)));
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_13_)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			ti4_1 = F22_175(RTCW(tr1), loc3);
			loc3 = (EIF_INTEGER_32) ti4_1;
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > arg2)) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tr2 = *(EIF_REFERENCE *)(Current);
				ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
				ti4_1 = F22_175(RTCW(tr1), ti4_1);
				if ((EIF_BOOLEAN)(loc3 == ti4_1)) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
				} else {
					loc1++;
				}
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
			}
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg2 < arg3))) {
				if (arg4) {
					loc1 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) break;
						if ((EIF_BOOLEAN)(F1563_16055(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							tb1 = '\01';
							if (!(EIF_BOOLEAN) (loc1 >= arg3)) {
								tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
								ti4_1 = (EIF_INTEGER_32) tu4_1;
								tb1 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1);
							}
							if (tb1) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr2 = *(EIF_REFERENCE *)(Current);
								ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
								ti4_1 = F22_175(RTCW(tr1), ti4_1);
								if ((EIF_BOOLEAN)(loc3 != ti4_1)) {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								} else {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
									loc1++;
								}
							}
						}
					}
				} else {
					loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
					loc1 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
						tb1 = '\01';
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
						ti4_1 = (EIF_INTEGER_32) tu4_1;
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr2 = *(EIF_REFERENCE *)(Current);
							ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
							ti4_1 = F22_175(RTCW(tr1), ti4_1);
							tb1 = (EIF_BOOLEAN)(loc3 == ti4_1);
						}
						if (tb1) {
							loc1 = (EIF_INTEGER_32) arg3;
						} else {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
							loc1++;
						}
					}
					for (;;) {
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) < loc2)) break;
						if ((EIF_BOOLEAN)(F1563_16055(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))--;
					}
					if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
						RTLE;
						return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					}
				}
			}
		} else {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > arg2)) break;
				tr1 = *(EIF_REFERENCE *)(Current);
				ti4_1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
				if ((EIF_BOOLEAN)(loc3 == ti4_1)) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
				} else {
					loc1++;
				}
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
			}
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg2 < arg3))) {
				if (arg4) {
					loc1 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) break;
						if ((EIF_BOOLEAN)(F1563_16055(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							tb1 = '\01';
							if (!(EIF_BOOLEAN) (loc1 >= arg3)) {
								tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
								ti4_1 = (EIF_INTEGER_32) tu4_1;
								tb1 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1);
							}
							if (tb1) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								tr1 = *(EIF_REFERENCE *)(Current);
								ti4_1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
								if ((EIF_BOOLEAN)(loc3 == ti4_1)) {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								} else {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
									loc1++;
								}
							}
						}
					}
				} else {
					loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
					loc1 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
						tb1 = '\01';
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
						ti4_1 = (EIF_INTEGER_32) tu4_1;
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							ti4_1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
							tb1 = (EIF_BOOLEAN)(loc3 == ti4_1);
						}
						if (tb1) {
							loc1 = (EIF_INTEGER_32) arg3;
						} else {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
							loc1++;
						}
					}
					for (;;) {
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) < loc2)) break;
						if ((EIF_BOOLEAN)(F1563_16055(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))--;
					}
					if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
						RTLE;
						return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {REGULAR_EXPRESSION}.match_repeated_type */
EIF_INTEGER_32 F1563_16064 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_BOOLEAN arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc3 = F18_89(RTCW(tr1), (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)));
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
	ti4_1 = (EIF_INTEGER_32) tu4_1;
	if ((EIF_BOOLEAN) (arg2 > (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_)) + ((EIF_INTEGER_32) 1L)))) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	} else {
		if ((EIF_BOOLEAN) (arg2 > ((EIF_INTEGER_32) 0L))) {
			switch (loc3) {
				case 15L:
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_15_)) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_)) += arg2;
					} else {
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 > arg2)) break;
							tr1 = *(EIF_REFERENCE *)(Current);
							ti4_1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
							if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 10L))) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
							} else {
								loc1++;
							}
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
						}
					}
					break;
				case 4L:
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > arg2)) break;
						tb1 = '\01';
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
						ti4_1 = (EIF_INTEGER_32) tu4_1;
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
							tr1 = RTOSCF(1778,F110_1778, (Current));
							tr2 = *(EIF_REFERENCE *)(Current);
							ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
							tb2 = F21_166(RTCW(tr1), ti4_1);
							tb1 = tb2;
						}
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
						} else {
							loc1++;
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
					}
					break;
				case 5L:
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > arg2)) break;
						tb1 = '\01';
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
						ti4_1 = (EIF_INTEGER_32) tu4_1;
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
							tr1 = RTOSCF(1778,F110_1778, (Current));
							tr2 = *(EIF_REFERENCE *)(Current);
							ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
							tb2 = F21_166(RTCW(tr1), ti4_1);
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
						} else {
							loc1++;
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
					}
					break;
				case 6L:
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > arg2)) break;
						tb1 = '\01';
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
						ti4_1 = (EIF_INTEGER_32) tu4_1;
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
							tr1 = RTOSCF(1786,F110_1786, (Current));
							tr2 = *(EIF_REFERENCE *)(Current);
							ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
							tb2 = F21_166(RTCW(tr1), ti4_1);
							tb1 = tb2;
						}
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
						} else {
							loc1++;
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
					}
					break;
				case 7L:
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > arg2)) break;
						tb1 = '\01';
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
						ti4_1 = (EIF_INTEGER_32) tu4_1;
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
							tr1 = RTOSCF(1786,F110_1786, (Current));
							tr2 = *(EIF_REFERENCE *)(Current);
							ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
							tb2 = F21_166(RTCW(tr1), ti4_1);
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
						} else {
							loc1++;
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
					}
					break;
				case 8L:
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > arg2)) break;
						tb1 = '\01';
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
						ti4_1 = (EIF_INTEGER_32) tu4_1;
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
							tr2 = *(EIF_REFERENCE *)(Current);
							ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
							tb2 = F21_166(RTCW(tr1), ti4_1);
							tb1 = tb2;
						}
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
						} else {
							loc1++;
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
					}
					break;
				case 9L:
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > arg2)) break;
						tb1 = '\01';
						tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
						ti4_1 = (EIF_INTEGER_32) tu4_1;
						if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
							tr2 = *(EIF_REFERENCE *)(Current);
							ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
							tb2 = F21_166(RTCW(tr1), ti4_1);
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
						} else {
							loc1++;
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
					}
					break;
				default:
					RTEC(EN_WHEN);
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg2 < arg3))) {
			if (arg4) {
				loc1 = (EIF_INTEGER_32) arg2;
				for (;;) {
					if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) break;
					if ((EIF_BOOLEAN)(F1563_16055(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					} else {
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (loc1 >= arg3)) {
							tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
							ti4_1 = (EIF_INTEGER_32) tu4_1;
							tb1 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1);
						}
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current);
							loc4 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
							switch (loc3) {
								case 15L:
									if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_15_) && (EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 10L)))) {
										Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									}
									break;
								case 4L:
									tr1 = RTOSCF(1778,F110_1778, (Current));
									tr2 = *(EIF_REFERENCE *)(Current);
									ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
									tb1 = F21_166(RTCW(tr1), ti4_1);
									if (tb1) {
										Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									}
									break;
								case 5L:
									tr1 = RTOSCF(1778,F110_1778, (Current));
									tr2 = *(EIF_REFERENCE *)(Current);
									ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
									tb1 = F21_166(RTCW(tr1), ti4_1);
									if ((EIF_BOOLEAN) !tb1) {
										Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									}
									break;
								case 6L:
									tr1 = RTOSCF(1786,F110_1786, (Current));
									tr2 = *(EIF_REFERENCE *)(Current);
									ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
									tb1 = F21_166(RTCW(tr1), ti4_1);
									if (tb1) {
										Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									}
									break;
								case 7L:
									tr1 = RTOSCF(1786,F110_1786, (Current));
									tr2 = *(EIF_REFERENCE *)(Current);
									ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
									tb1 = F21_166(RTCW(tr1), ti4_1);
									if ((EIF_BOOLEAN) !tb1) {
										Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									}
									break;
								case 8L:
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
									tr2 = *(EIF_REFERENCE *)(Current);
									ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
									tb1 = F21_166(RTCW(tr1), ti4_1);
									if (tb1) {
										Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									}
									break;
								case 9L:
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
									tr2 = *(EIF_REFERENCE *)(Current);
									ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
									tb1 = F21_166(RTCW(tr1), ti4_1);
									if ((EIF_BOOLEAN) !tb1) {
										Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
									}
									break;
								default:
									RTEC(EN_WHEN);
							}
							loc1++;
						}
					}
				}
			} else {
				loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
				switch (loc3) {
					case 15L:
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_15_)) {
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg3 - arg2);
							tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
							ti4_1 = (EIF_INTEGER_32) tu4_1;
							if ((EIF_BOOLEAN) (loc1 > (EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_)))) {
								tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
								loc1 = (EIF_INTEGER_32) tu4_1;
								ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ti4_1) + ((EIF_INTEGER_32) 1L));
							}
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_)) += loc1;
						} else {
							loc1 = (EIF_INTEGER_32) arg2;
							for (;;) {
								if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
								tb1 = '\01';
								tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
								ti4_1 = (EIF_INTEGER_32) tu4_1;
								if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
									tr1 = *(EIF_REFERENCE *)(Current);
									ti4_1 = F1137_10163(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
									tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 10L));
								}
								if (tb1) {
									loc1 = (EIF_INTEGER_32) arg3;
								} else {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
									loc1++;
								}
							}
						}
						break;
					case 4L:
						loc1 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
							tb1 = '\01';
							tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
							ti4_1 = (EIF_INTEGER_32) tu4_1;
							if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
								tr1 = RTOSCF(1778,F110_1778, (Current));
								tr2 = *(EIF_REFERENCE *)(Current);
								ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
								tb2 = F21_166(RTCW(tr1), ti4_1);
								tb1 = tb2;
							}
							if (tb1) {
								loc1 = (EIF_INTEGER_32) arg3;
							} else {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
								loc1++;
							}
						}
						break;
					case 5L:
						loc1 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
							tb1 = '\01';
							tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
							ti4_1 = (EIF_INTEGER_32) tu4_1;
							if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
								tr1 = RTOSCF(1778,F110_1778, (Current));
								tr2 = *(EIF_REFERENCE *)(Current);
								ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
								tb2 = F21_166(RTCW(tr1), ti4_1);
								tb1 = (EIF_BOOLEAN) !tb2;
							}
							if (tb1) {
								loc1 = (EIF_INTEGER_32) arg3;
							} else {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
								loc1++;
							}
						}
						break;
					case 6L:
						loc1 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
							tb1 = '\01';
							tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
							ti4_1 = (EIF_INTEGER_32) tu4_1;
							if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
								tr1 = RTOSCF(1786,F110_1786, (Current));
								tr2 = *(EIF_REFERENCE *)(Current);
								ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
								tb2 = F21_166(RTCW(tr1), ti4_1);
								tb1 = tb2;
							}
							if (tb1) {
								loc1 = (EIF_INTEGER_32) arg3;
							} else {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
								loc1++;
							}
						}
						break;
					case 7L:
						loc1 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
							tb1 = '\01';
							tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
							ti4_1 = (EIF_INTEGER_32) tu4_1;
							if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
								tr1 = RTOSCF(1786,F110_1786, (Current));
								tr2 = *(EIF_REFERENCE *)(Current);
								ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
								tb2 = F21_166(RTCW(tr1), ti4_1);
								tb1 = (EIF_BOOLEAN) !tb2;
							}
							if (tb1) {
								loc1 = (EIF_INTEGER_32) arg3;
							} else {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
								loc1++;
							}
						}
						break;
					case 8L:
						loc1 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
							tb1 = '\01';
							tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
							ti4_1 = (EIF_INTEGER_32) tu4_1;
							if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
								tr2 = *(EIF_REFERENCE *)(Current);
								ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
								tb2 = F21_166(RTCW(tr1), ti4_1);
								tb1 = tb2;
							}
							if (tb1) {
								loc1 = (EIF_INTEGER_32) arg3;
							} else {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
								loc1++;
							}
						}
						break;
					case 9L:
						loc1 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 >= arg3)) break;
							tb1 = '\01';
							tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_);
							ti4_1 = (EIF_INTEGER_32) tu4_1;
							if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) > ti4_1)) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
								tr2 = *(EIF_REFERENCE *)(Current);
								ti4_1 = F1137_10163(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_));
								tb2 = F21_166(RTCW(tr1), ti4_1);
								tb1 = (EIF_BOOLEAN) !tb2;
							}
							if (tb1) {
								loc1 = (EIF_INTEGER_32) arg3;
							} else {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))++;
								loc1++;
							}
						}
						break;
					default:
						RTEC(EN_WHEN);
				}
				for (;;) {
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) < loc2)) break;
					if ((EIF_BOOLEAN)(F1563_16055(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0) == ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
					} else {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_22_))--;
					}
				}
				if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
					RTLE;
					return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				}
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit807 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
