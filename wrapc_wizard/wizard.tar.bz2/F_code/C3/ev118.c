/*
 * Code for class EV_LAYOUT_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev118.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_LAYOUT_CONSTANTS}.default_button_width */
static EIF_INTEGER_32 F154_3267_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (3267);
#define Result RTOSR(3267)
	Result = F154_3277(Current, ((EIF_INTEGER_32) 75L));
	RTOSE (3267);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F154_3267 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3267,F154_3267_body,(Current));
}

/* {EV_LAYOUT_CONSTANTS}.default_button_height */
static EIF_INTEGER_32 F154_3268_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (3268);
#define Result RTOSR(3268)
	Result = F154_3277(Current, ((EIF_INTEGER_32) 23L));
	RTOSE (3268);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F154_3268 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3268,F154_3268_body,(Current));
}

/* {EV_LAYOUT_CONSTANTS}.small_padding_size */
static EIF_INTEGER_32 F154_3270_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (3270);
#define Result RTOSR(3270)
	Result = F154_3277(Current, ((EIF_INTEGER_32) 10L));
	RTOSE (3270);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F154_3270 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3270,F154_3270_body,(Current));
}

/* {EV_LAYOUT_CONSTANTS}.dialog_unit_to_pixels */
EIF_INTEGER_32 F154_3277 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(RTOSCF(3278,F154_3278, (Current)) == ((EIF_INTEGER_32) 96L))) {
		RTLE;
		return (EIF_INTEGER_32) arg1;
	} else {
		Result = RTOSCF(3278,F154_3278, (Current));
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 * Result) / ((EIF_INTEGER_32) 96L));
	}
	RTLE;
	return Result;
}

/* {EV_LAYOUT_CONSTANTS}.resolution */
static EIF_INTEGER_32 F154_3278_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3278);
#define Result RTOSR(3278)
	tr1 = RTLNS(eif_new_type(1201, 0x01).id, 1201, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1168_10363(RTCW(tr1));
	Result = F1202_10855(RTCW(tr1));
	RTOSE (3278);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F154_3278 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3278,F154_3278_body,(Current));
}

void EIF_Minit118 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
