/*
 * Code for class EIFFEL_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei138.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_CONSTANTS}.ise_projects_env */

EIF_REFERENCE F174_3475 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (3475,RTMS_EX_H("ISE_PROJECTS",12,53375059));
}

/* {EIFFEL_CONSTANTS}.ise_user_files_env */

EIF_REFERENCE F174_3476 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (3476,RTMS_EX_H("ISE_USER_FILES",14,1880819283));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_major_version */
static EIF_REFERENCE F174_3484_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3484);
#define Result RTOSR(3484)
	RTOC_NEW(Result);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 22U);
	Result = F174_3486(Current, ti4_1);
	RTOSE (3484);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F174_3484 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3484,F174_3484_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_minor_version */
static EIF_REFERENCE F174_3485_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3485);
#define Result RTOSR(3485)
	RTOC_NEW(Result);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 5U);
	Result = F174_3486(Current, ti4_1);
	RTOSE (3485);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F174_3485 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3485,F174_3485_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_string */
EIF_REFERENCE F174_3486 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTLNS(eif_new_type(1136, 0x01).id, 1136, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1135_10080(RTCW(Result), ((EIF_INTEGER_32) 2L));
	if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 10L))) {
		F1137_10206(RTCW(Result), (EIF_CHARACTER_8) '0');
	}
	F1137_10196(RTCW(Result), arg1);
	RTLE;
	return Result;
}

void EIF_Minit138 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
