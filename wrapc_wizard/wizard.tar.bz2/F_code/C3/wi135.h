
#ifndef _C3_wi135_
#define _C3_wi135_

#ifdef __cplusplus
extern "C" {
#endif

extern void F171_3440(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F171_3444(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,3446)
static EIF_REFERENCE F171_3446_body(EIF_REFERENCE);
extern EIF_REFERENCE F171_3446(EIF_REFERENCE);
extern EIF_REFERENCE F171_3453(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit135(void);
extern void F1129_9783(EIF_REFERENCE);
extern void F1134_9989(EIF_REFERENCE, EIF_REFERENCE);
extern void F1134_10028(EIF_REFERENCE, EIF_REFERENCE);
extern void F1134_10041(EIF_REFERENCE, EIF_CHARACTER_32);
extern void F939_7333(EIF_REFERENCE, EIF_REFERENCE);
extern void F939_7334(EIF_REFERENCE, EIF_REFERENCE);
extern void F1132_9914(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F1134_10027(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R8271[])();
extern char *(*R5184[])();
extern char *(*R5429[])();
extern char *(*R5789[])();
extern char *(*R5790[])();
extern char *(*R5791[])();

#ifdef __cplusplus
}
#endif

#endif
