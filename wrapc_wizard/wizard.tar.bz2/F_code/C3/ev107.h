
#ifndef _C3_ev107_
#define _C3_ev107_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F143_2146(EIF_REFERENCE);
extern void EIF_Minit107(void);
extern void F1416_14178(EIF_REFERENCE, EIF_REFERENCE);
extern void F872_6758(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
