
#ifndef _C3_ev122_
#define _C3_ev122_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F158_3308(EIF_REFERENCE);
extern EIF_REFERENCE F158_3310(EIF_REFERENCE);
extern void EIF_Minit122(void);
extern void F872_6758(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
