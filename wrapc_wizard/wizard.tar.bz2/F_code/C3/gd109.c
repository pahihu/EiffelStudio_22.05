/*
 * Code for class GDK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gd109.h"
#include <stdlib.h>
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F145_2202
static void inline_F145_2202 (EIF_POINTER arg1)
{
	return gdk_set_allowed_backends ( (const gchar*) arg1);
	;
}
#define INLINE_F145_2202
#endif
#ifndef INLINE_F145_2223
static int inline_F145_2223 (EIF_POINTER arg1)
{
	return (int) (GDK_IS_PIXBUF(arg1))
	;
}
#define INLINE_F145_2223
#endif
#ifndef INLINE_F145_2225
static void inline_F145_2225 (EIF_POINTER arg1)
{
	printf((char*) arg1)
	;
}
#define INLINE_F145_2225
#endif
#ifndef INLINE_F145_2226
static EIF_NATURAL_32 inline_F145_2226 (EIF_POINTER arg1)
{
	return (EIF_NATURAL_32) (((GObject*)arg1)->ref_count)
	;
}
#define INLINE_F145_2226
#endif
#ifndef INLINE_F145_2227
static int inline_F145_2227 (EIF_POINTER arg1)
{
	return (int) (g_object_is_floating((gpointer) arg1))
	;
}
#define INLINE_F145_2227
#endif
#ifndef INLINE_F145_2228
static EIF_POINTER inline_F145_2228 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref_sink((gpointer) arg1))
	;
}
#define INLINE_F145_2228
#endif
#ifndef INLINE_F145_2229
static EIF_POINTER inline_F145_2229 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref((gpointer) arg1))
	;
}
#define INLINE_F145_2229
#endif
#ifndef INLINE_F145_2230
static void inline_F145_2230 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F145_2230
#endif
#ifndef INLINE_F145_2233
static void inline_F145_2233 (EIF_POINTER arg1)
{
	g_object_run_dispose((GObject *) arg1)
	;
}
#define INLINE_F145_2233
#endif
#ifndef INLINE_F145_2239
static EIF_POINTER inline_F145_2239 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gdk_display_get_default_screen ((GdkDisplay*) arg1))
	;
}
#define INLINE_F145_2239
#endif
#ifndef INLINE_F145_2241
static EIF_INTEGER_32 inline_F145_2241 (EIF_POINTER arg1)
{
	return gdk_display_get_n_monitors ((GdkDisplay*) arg1)
	;
}
#define INLINE_F145_2241
#endif
#ifndef INLINE_F145_2246
static void inline_F145_2246 (EIF_POINTER arg1)
{
	gdk_display_flush ((GdkDisplay *)arg1);
	;
}
#define INLINE_F145_2246
#endif
#ifndef INLINE_F145_2247
static void inline_F145_2247 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gdk_monitor_get_geometry ((GdkMonitor*) arg1, (GdkRectangle*) arg2)
	;
}
#define INLINE_F145_2247
#endif
#ifndef INLINE_F145_2277
static EIF_POINTER inline_F145_2277 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	return gdk_window_create_similar_surface ((GdkWindow *)arg1,
                                   (cairo_content_t)arg2,
                                   (int)arg3,
                                   (int)arg4);
	;
}
#define INLINE_F145_2277
#endif
#ifndef INLINE_F145_2290
static void inline_F145_2290 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	return gdk_cairo_set_source_pixbuf ((cairo_t *) arg1, (const GdkPixbuf *) arg2, (gdouble) arg3, (gdouble) arg4);
	;
}
#define INLINE_F145_2290
#endif
#ifndef INLINE_F145_2296
static EIF_INTEGER_32 inline_F145_2296 (EIF_POINTER arg1)
{
	return (EIF_INTEGER_32) (gdk_visual_get_depth ((GdkVisual*) arg1))
	;
}
#define INLINE_F145_2296
#endif
#ifndef INLINE_F145_2365
static EIF_INTEGER_32 inline_F145_2365 (void)
{
	return GDK_COLORSPACE_RGB;
	;
}
#define INLINE_F145_2365
#endif
#ifndef INLINE_F145_2367
static void inline_F145_2367 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	{
	GType type = G_TYPE_BOOLEAN;
	memcpy ((char *) arg1 + arg2, &type, sizeof(GType));
}
	;
}
#define INLINE_F145_2367
#endif
#ifndef INLINE_F145_2368
static void inline_F145_2368 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	{
	GType type = G_TYPE_STRING;
	memcpy ((char *) arg1 + arg2, &type, sizeof(GType));
}
	;
}
#define INLINE_F145_2368
#endif
#ifndef INLINE_F145_2369
static void inline_F145_2369 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	{
	GType type = GDK_TYPE_PIXBUF;
	memcpy ((char *) arg1 + arg2, &type, sizeof(GType));
}
	;
}
#define INLINE_F145_2369
#endif
#ifndef INLINE_F145_2370
static EIF_POINTER inline_F145_2370 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	return (EIF_POINTER) (gdk_pixbuf_scale_simple ((GdkPixbuf*) arg1, (int) arg2, (int) arg3, (int) arg4))
	;
}
#define INLINE_F145_2370
#endif
#ifndef INLINE_F145_2379
static EIF_POINTER inline_F145_2379 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_get_from_surface ((cairo_surface_t *) arg1, (gint) arg2, (gint) arg3, (gint) arg4, (gint) arg5);
	;
}
#define INLINE_F145_2379
#endif
#ifndef INLINE_F145_2380
static EIF_POINTER inline_F145_2380 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_get_from_window ((GdkWindow *) arg1, (gint) arg2, (gint) arg3, (gint) arg4, (gint) arg5);
	;
}
#define INLINE_F145_2380
#endif
#ifndef INLINE_F145_2382
static EIF_POINTER inline_F145_2382 (EIF_POINTER arg1)
{
	return gdk_pixbuf_copy ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F145_2382
#endif
#ifndef INLINE_F145_2383
static EIF_INTEGER_32 inline_F145_2383 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_width ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F145_2383
#endif
#ifndef INLINE_F145_2384
static EIF_INTEGER_32 inline_F145_2384 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_height ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F145_2384
#endif
#ifndef INLINE_F145_2390
static EIF_POINTER inline_F145_2390 (EIF_POINTER arg1)
{
	return gdk_pixbuf_new_from_xpm_data ((const char**) arg1);
	;
}
#define INLINE_F145_2390
#endif
#ifndef INLINE_F145_2392
static EIF_POINTER inline_F145_2392 (EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_new ((GdkColorspace) arg1, (gboolean) arg2, (int) arg3, (int) arg4, (int) arg5);
	;
}
#define INLINE_F145_2392
#endif
#ifndef INLINE_F145_2394
static void inline_F145_2394 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gdk_pixbuf_fill ((GdkPixbuf*)arg1, (guint32) arg2);
	;
}
#define INLINE_F145_2394
#endif
#ifndef INLINE_F145_2396
static EIF_INTEGER_32 inline_F145_2396 (EIF_POINTER arg1)
{
	return gdk_screen_get_resolution ((GdkScreen*)arg1);
	;
}
#define INLINE_F145_2396
#endif
#ifndef INLINE_F145_2397
static int inline_F145_2397 (EIF_POINTER arg1)
{
	return gdk_screen_is_composited ((GdkScreen*)arg1);
	;
}
#define INLINE_F145_2397
#endif
#ifndef INLINE_F145_2398
static EIF_POINTER inline_F145_2398 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gdk_screen_get_system_visual ((GdkScreen*) arg1))
	;
}
#define INLINE_F145_2398
#endif
#ifndef INLINE_F145_2399
static EIF_POINTER inline_F145_2399 (EIF_POINTER arg1)
{
	return gdk_screen_get_rgba_visual ((GdkScreen*)arg1);
	;
}
#define INLINE_F145_2399
#endif
#ifndef INLINE_F145_2401
static EIF_POINTER inline_F145_2401 (void)
{
	return gdk_screen_get_default()
	;
}
#define INLINE_F145_2401
#endif
#ifndef INLINE_F145_2403
static EIF_POINTER inline_F145_2403 (EIF_POINTER arg1)
{
	return gdk_screen_get_root_window ((GdkScreen *)arg1);;
	;
}
#define INLINE_F145_2403
#endif
#ifndef INLINE_F145_2404
static EIF_POINTER inline_F145_2404 (void)
{
	return gdk_get_default_root_window();
	;
}
#define INLINE_F145_2404
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GDK}.gdk_set_allowed_backends */
void F145_2202 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F145_2202 ((EIF_POINTER) arg1);
}

/* {GDK}.g_free */
void F145_2203 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	g_free((gpointer) arg1);
	
}

/* {GDK}.g_malloc */
EIF_POINTER F145_2204 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) g_malloc((gulong) arg1);
	
	return Result;
}

/* {GDK}.g_realloc */
EIF_POINTER F145_2205 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) g_realloc((gpointer) arg1, (gulong) arg2);
	
	return Result;
}

/* {GDK}.g_list_free */
void F145_2207 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	g_list_free((GList*) arg1);
	
}

/* {GDK}.g_list_nth_data */
EIF_POINTER F145_2212 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) g_list_nth_data((GList*) arg1, (guint) arg2);
	
	return Result;
}

/* {GDK}.glist_struct_data */
EIF_POINTER F145_2214 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((GList *)arg1)->data);
	
	return Result;
}

/* {GDK}.glist_struct_next */
EIF_POINTER F145_2215 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((GList *)arg1)->next);
	
	return Result;
}

/* {GDK}.g_slist_free */
void F145_2217 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	g_slist_free((GSList*) arg1);
	
}

/* {GDK}.g_slist_index */
EIF_INTEGER_32 F145_2218 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) g_slist_index((GSList*) arg1, (gpointer) arg2);
	
	return Result;
}

/* {GDK}.g_slist_length */
EIF_INTEGER_32 F145_2219 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) g_slist_length((GSList*) arg1);
	
	return Result;
}

/* {GDK}.g_slist_nth_data */
EIF_POINTER F145_2220 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) g_slist_nth_data((GSList*) arg1, (guint) arg2);
	
	return Result;
}

/* {GDK}.gslist_struct_data */
EIF_POINTER F145_2221 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((GSList *)arg1)->data);
	
	return Result;
}

/* {GDK}.gslist_struct_next */
EIF_POINTER F145_2222 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((GSList *)arg1)->next);
	
	return Result;
}

/* {GDK}.gdk_is_pixbuf */
EIF_BOOLEAN F145_2223 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F145_2223 ((EIF_POINTER) arg1));
	return Result;
}

/* {GDK}.printf */
void F145_2224 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1));
	inline_F145_2225(loc1);
	RTLE;
}

/* {GDK}.c_printf */
void F145_2225 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F145_2225 ((EIF_POINTER) arg1);
}

/* {GDK}.internal_g_object_ref_count */
EIF_NATURAL_32 F145_2226 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	Result = inline_F145_2226 ((EIF_POINTER) arg1);
	return Result;
}

/* {GDK}.g_object_is_floating */
EIF_BOOLEAN F145_2227 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F145_2227 ((EIF_POINTER) arg1));
	return Result;
}

/* {GDK}.g_object_ref_sink */
EIF_POINTER F145_2228 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F145_2228 ((EIF_POINTER) arg1);
	return Result;
}

/* {GDK}.g_object_ref */
EIF_POINTER F145_2229 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F145_2229 ((EIF_POINTER) arg1);
	return Result;
}

/* {GDK}.g_object_unref */
void F145_2230 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F145_2230 ((EIF_POINTER) arg1);
}

/* {GDK}.g_object_run_dispose */
void F145_2233 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F145_2233 ((EIF_POINTER) arg1);
}

/* {GDK}.gdk_display_get_default */
EIF_POINTER F145_2235 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gdk_display_get_default();
	
	return Result;
}

/* {GDK}.gdk_display_get_default_seat */
EIF_POINTER F145_2236 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gdk_display_get_default_seat((GdkDisplay*) arg1);
	
	return Result;
}

/* {GDK}.gdk_display_get_primary_monitor */
EIF_POINTER F145_2237 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gdk_display_get_primary_monitor((GdkDisplay*) arg1);
	
	return Result;
}

/* {GDK}.gdk_display_get_default_screen */
EIF_POINTER F145_2239 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F145_2239 ((EIF_POINTER) arg1);
	return Result;
}

/* {GDK}.gdk_display_get_n_monitors */
EIF_INTEGER_32 F145_2241 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F145_2241 ((EIF_POINTER) arg1);
	return Result;
}

/* {GDK}.gdk_display_flush */
void F145_2246 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F145_2246 ((EIF_POINTER) arg1);
}

/* {GDK}.gdk_monitor_get_geometry */
void F145_2247 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F145_2247 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {GDK}.gdk_window_get_device_position */
EIF_POINTER F145_2256 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3, EIF_INTEGER_32* arg4, EIF_POINTER arg5)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gdk_window_get_device_position((GdkWindow*) arg1, (GdkDevice *) arg2, (gint*) arg3, (gint*) arg4, (GdkModifierType*) arg5);
	
	return Result;
}

/* {GDK}.gdk_window_get_origin */
EIF_INTEGER_32 F145_2261 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) gdk_window_get_origin((GdkWindow*) arg1, (gint*) arg2, (gint*) arg3);
	
	return Result;
}

/* {GDK}.gdk_window_get_user_data */
void F145_2262 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER* arg2)
{
	GTCX
	
	gdk_window_get_user_data((GdkWindow*) arg1, (gpointer*) arg2);
	
}

/* {GDK}.gdk_window_hide */
void F145_2263 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gdk_window_hide((GdkWindow*) arg1);
	
}

/* {GDK}.gdk_window_raise */
void F145_2267 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gdk_window_raise((GdkWindow*) arg1);
	
}

/* {GDK}.gdk_window_set_cursor */
void F145_2268 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gdk_window_set_cursor((GdkWindow*) arg1, (GdkCursor*) arg2);
	
}

/* {GDK}.gdk_window_set_decorations */
void F145_2269 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	gdk_window_set_decorations((GdkWindow*) arg1, (GdkWMDecoration) arg2);
	
}

/* {GDK}.gdk_window_set_functions */
void F145_2271 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	gdk_window_set_functions((GdkWindow*) arg1, (GdkWMFunction) arg2);
	
}

/* {GDK}.gdk_window_create_similar_surface */
EIF_POINTER F145_2277 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F145_2277 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4);
	return Result;
}

/* {GDK}.gdk_window_invalidate_rect */
void F145_2281 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	GTCX
	
	gdk_window_invalidate_rect((GdkWindow*) arg1, (GdkRectangle*) arg2, (gboolean) arg3);
	
}

/* {GDK}.gdk_cairo_set_source_pixbuf */
void F145_2290 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	
	
	inline_F145_2290 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_REAL_64) arg3, (EIF_REAL_64) arg4);
}

/* {GDK}.gdk_seat_grab */
EIF_INTEGER_32 F145_2292 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_BOOLEAN arg4, EIF_POINTER arg5, EIF_POINTER arg6, EIF_POINTER arg7, EIF_POINTER arg8)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) gdk_seat_grab((GdkSeat*) arg1, (GdkWindow*) arg2, (GdkSeatCapabilities) arg3, (gboolean) arg4, (GdkCursor*) arg5, (const GdkEvent*) arg6, (GdkSeatGrabPrepareFunc) arg7, (gpointer) arg8);
	
	return Result;
}

/* {GDK}.gdk_seat_ungrab */
void F145_2293 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gdk_seat_ungrab((GdkSeat*) arg1);
	
}

/* {GDK}.gdk_device_get_window_at_position */
EIF_POINTER F145_2295 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gdk_device_get_window_at_position((GdkDevice*) arg1, (gint*) arg2, (gint*) arg3);
	
	return Result;
}

/* {GDK}.gdk_visual_get_depth */
EIF_INTEGER_32 F145_2296 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F145_2296 ((EIF_POINTER) arg1);
	return Result;
}

/* {GDK}.gdk_event_free */
void F145_2297 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gdk_event_free((GdkEvent*) arg1);
	
}

/* {GDK}.gdk_event_get */
EIF_POINTER F145_2298 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gdk_event_get();
	
	return Result;
}

/* {GDK}.gdk_event_focus_struct_in */
EIF_INTEGER_8 F145_2300 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	Result = (EIF_INTEGER_8) (((GdkEventFocus *)arg1)->in);
	
	return Result;
}

/* {GDK}.gdk_event_any_struct_send_event */
EIF_INTEGER_8 F145_2301 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	Result = (EIF_INTEGER_8) (((GdkEventAny *)arg1)->send_event);
	
	return Result;
}

/* {GDK}.gdk_event_any_struct_window */
EIF_POINTER F145_2302 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((GdkEventAny *)arg1)->window);
	
	return Result;
}

/* {GDK}.set_gdk_event_any_struct_window */
void F145_2303 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	(((GdkEventAny *)arg1)->window = (GdkWindow*)(arg2));
	
}

/* {GDK}.gdk_event_any_struct_type */
EIF_INTEGER_8 F145_2304 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	Result = (EIF_INTEGER_8) (((GdkEventAny *)arg1)->type);
	
	return Result;
}

/* {GDK}.gdk_event_button_struct_button */
EIF_INTEGER_32 F145_2305 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GdkEventButton *)arg1)->button);
	
	return Result;
}

/* {GDK}.gdk_event_button_struct_window */
EIF_POINTER F145_2306 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((GdkEventButton *)arg1)->window);
	
	return Result;
}

/* {GDK}.gdk_event_button_struct_state */
EIF_NATURAL_32 F145_2307 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	Result = (EIF_NATURAL_32) (((GdkEventButton *)arg1)->state);
	
	return Result;
}

/* {GDK}.gdk_event_button_struct_type */
EIF_INTEGER_32 F145_2308 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GdkEventButton *)arg1)->type);
	
	return Result;
}

/* {GDK}.gdk_event_button_struct_x */
EIF_REAL_64 F145_2309 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	Result = (EIF_REAL_64) (((GdkEventButton *)arg1)->x);
	
	return Result;
}

/* {GDK}.gdk_event_button_struct_x_root */
EIF_REAL_64 F145_2310 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	Result = (EIF_REAL_64) (((GdkEventButton *)arg1)->x_root);
	
	return Result;
}

/* {GDK}.gdk_event_scroll_struct_x_root */
EIF_REAL_64 F145_2311 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	Result = (EIF_REAL_64) (((GdkEventScroll *)arg1)->x_root);
	
	return Result;
}

/* {GDK}.gdk_event_button_struct_y */
EIF_REAL_64 F145_2312 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	Result = (EIF_REAL_64) (((GdkEventButton *)arg1)->y);
	
	return Result;
}

/* {GDK}.gdk_event_button_struct_y_root */
EIF_REAL_64 F145_2313 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	Result = (EIF_REAL_64) (((GdkEventButton *)arg1)->y_root);
	
	return Result;
}

/* {GDK}.gdk_event_scroll_struct_y_root */
EIF_REAL_64 F145_2314 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	Result = (EIF_REAL_64) (((GdkEventScroll *)arg1)->y_root);
	
	return Result;
}

/* {GDK}.gdk_event_configure_struct_x */
EIF_INTEGER_32 F145_2315 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GdkEventConfigure *)arg1)->x);
	
	return Result;
}

/* {GDK}.gdk_event_configure_struct_y */
EIF_INTEGER_32 F145_2316 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GdkEventConfigure *)arg1)->y);
	
	return Result;
}

/* {GDK}.gdk_event_configure_struct_height */
EIF_INTEGER_32 F145_2317 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GdkEventConfigure *)arg1)->height);
	
	return Result;
}

/* {GDK}.gdk_event_configure_struct_width */
EIF_INTEGER_32 F145_2318 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GdkEventConfigure *)arg1)->width);
	
	return Result;
}

/* {GDK}.gdk_event_setting_struct_name */
EIF_POINTER F145_2319 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((GdkEventSetting *)arg1)->name);
	
	return Result;
}

/* {GDK}.gdk_event_crossing_struct_mode */
EIF_INTEGER_32 F145_2321 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GdkEventCrossing *)arg1)->mode);
	
	return Result;
}

/* {GDK}.gdk_event_key_struct_keyval */
EIF_NATURAL_32 F145_2329 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	Result = (EIF_NATURAL_32) (((GdkEventKey *)arg1)->keyval);
	
	return Result;
}

/* {GDK}.gdk_event_key_struct_state */
EIF_NATURAL_32 F145_2330 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	Result = (EIF_NATURAL_32) (((GdkEventKey *)arg1)->state);
	
	return Result;
}

/* {GDK}.gdk_event_key_struct_type */
EIF_INTEGER_32 F145_2331 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GdkEventKey *)arg1)->type);
	
	return Result;
}

/* {GDK}.gdk_event_motion_struct_is_hint */
EIF_INTEGER_32 F145_2332 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GdkEventMotion *)arg1)->is_hint);
	
	return Result;
}

/* {GDK}.gdk_event_motion_struct_state */
EIF_NATURAL_32 F145_2333 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	Result = (EIF_NATURAL_32) (((GdkEventMotion *)arg1)->state);
	
	return Result;
}

/* {GDK}.gdk_event_motion_struct_window */
EIF_POINTER F145_2334 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((GdkEventMotion *)arg1)->window);
	
	return Result;
}

/* {GDK}.gdk_event_motion_struct_x */
EIF_REAL_64 F145_2335 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	Result = (EIF_REAL_64) (((GdkEventMotion *)arg1)->x);
	
	return Result;
}

/* {GDK}.gdk_event_motion_struct_x_root */
EIF_REAL_64 F145_2336 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	Result = (EIF_REAL_64) (((GdkEventMotion *)arg1)->x_root);
	
	return Result;
}

/* {GDK}.gdk_event_motion_struct_y */
EIF_REAL_64 F145_2337 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	Result = (EIF_REAL_64) (((GdkEventMotion *)arg1)->y);
	
	return Result;
}

/* {GDK}.gdk_event_motion_struct_y_root */
EIF_REAL_64 F145_2338 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	Result = (EIF_REAL_64) (((GdkEventMotion *)arg1)->y_root);
	
	return Result;
}

/* {GDK}.gdk_event_dnd_struct_context */
EIF_POINTER F145_2339 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((GdkEventDND *)arg1)->context);
	
	return Result;
}

/* {GDK}.gdk_event_dnd_struct_time */
EIF_NATURAL_32 F145_2340 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	Result = (EIF_NATURAL_32) (((GdkEventDND *)arg1)->time);
	
	return Result;
}

/* {GDK}.gdk_event_scroll_struct_scroll_direction */
EIF_INTEGER_32 F145_2341 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GdkEventScroll *)arg1)->direction);
	
	return Result;
}

/* {GDK}.c_gdk_rgba_struct_allocate */
EIF_POINTER F145_2347 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) calloc (sizeof(GdkRGBA), 1);
	return Result;
}

/* {GDK}.rgba_free */
void F145_2348 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gdk_rgba_free((GdkRGBA*) arg1);
	
}

/* {GDK}.rgba_struct_red */
EIF_REAL_64 F145_2359 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	Result = (EIF_REAL_64) (((GdkRGBA *)arg1)->red);
	
	return Result;
}

/* {GDK}.rgba_struct_green */
EIF_REAL_64 F145_2360 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	Result = (EIF_REAL_64) (((GdkRGBA *)arg1)->green);
	
	return Result;
}

/* {GDK}.rgba_struct_blue */
EIF_REAL_64 F145_2361 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	Result = (EIF_REAL_64) (((GdkRGBA *)arg1)->blue);
	
	return Result;
}

/* {GDK}.rgba_struct_alpha */
EIF_REAL_64 F145_2362 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	Result = (EIF_REAL_64) (((GdkRGBA *)arg1)->alpha);
	
	return Result;
}

/* {GDK}.gdk_colorspace_rgb_enum */
EIF_INTEGER_32 F145_2365 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F145_2365 ();
	return Result;
}

/* {GDK}.sizeof_gtype */
EIF_INTEGER_32 F145_2366 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) sizeof(GType);
	return Result;
}

/* {GDK}.add_g_type_boolean */
void F145_2367 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	inline_F145_2367 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
}

/* {GDK}.add_g_type_string */
void F145_2368 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	inline_F145_2368 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
}

/* {GDK}.add_gdk_type_pixbuf */
void F145_2369 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	inline_F145_2369 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
}

/* {GDK}.gdk_pixbuf_scale_simple */
EIF_POINTER F145_2370 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F145_2370 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4);
	return Result;
}

/* {GDK}.gdk_pixbuf_get_has_alpha */
EIF_BOOLEAN F145_2375 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(gdk_pixbuf_get_has_alpha((GdkPixbuf*) arg1));
	
	return Result;
}

/* {GDK}.gdk_pixbuf_get_from_surface */
EIF_POINTER F145_2379 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F145_2379 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4, (EIF_INTEGER_32) arg5);
	return Result;
}

/* {GDK}.gdk_pixbuf_get_from_window */
EIF_POINTER F145_2380 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F145_2380 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4, (EIF_INTEGER_32) arg5);
	return Result;
}

/* {GDK}.gdk_pixbuf_copy */
EIF_POINTER F145_2382 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F145_2382 ((EIF_POINTER) arg1);
	return Result;
}

/* {GDK}.gdk_pixbuf_get_width */
EIF_INTEGER_32 F145_2383 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F145_2383 ((EIF_POINTER) arg1);
	return Result;
}

/* {GDK}.gdk_pixbuf_get_height */
EIF_INTEGER_32 F145_2384 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F145_2384 ((EIF_POINTER) arg1);
	return Result;
}

/* {GDK}.gdk_pixbuf_new_from_xpm_data */
EIF_POINTER F145_2390 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F145_2390 ((EIF_POINTER) arg1);
	return Result;
}

/* {GDK}.gdk_pixbuf_new */
EIF_POINTER F145_2392 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F145_2392 ((EIF_INTEGER_32) arg1, (EIF_BOOLEAN) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4, (EIF_INTEGER_32) arg5);
	return Result;
}

/* {GDK}.gdk_pixbuf_fill */
void F145_2394 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	inline_F145_2394 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
}

/* {GDK}.gdk_pixbuf_add_alpha */
EIF_POINTER F145_2395 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2, EIF_NATURAL_8 arg3, EIF_NATURAL_8 arg4, EIF_NATURAL_8 arg5)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gdk_pixbuf_add_alpha((GdkPixbuf*) arg1, (gboolean) arg2, (guchar) arg3, (guchar) arg4, (guchar) arg5);
	
	return Result;
}

/* {GDK}.gdk_screen_get_resolution */
EIF_INTEGER_32 F145_2396 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F145_2396 ((EIF_POINTER) arg1);
	return Result;
}

/* {GDK}.gdk_screen_is_composited */
EIF_BOOLEAN F145_2397 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F145_2397 ((EIF_POINTER) arg1));
	return Result;
}

/* {GDK}.gdk_screen_get_system_visual */
EIF_POINTER F145_2398 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F145_2398 ((EIF_POINTER) arg1);
	return Result;
}

/* {GDK}.gdk_screen_get_rgba_visual */
EIF_POINTER F145_2399 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F145_2399 ((EIF_POINTER) arg1);
	return Result;
}

/* {GDK}.gdk_screen_get_default */
EIF_POINTER F145_2401 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F145_2401 ();
	return Result;
}

/* {GDK}.gdk_set_show_events */
void F145_2402 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	gdk_set_show_events((gboolean) arg1);
	
}

/* {GDK}.gdk_screen_get_root_window */
EIF_POINTER F145_2403 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F145_2403 ((EIF_POINTER) arg1);
	return Result;
}

/* {GDK}.gdk_get_default_root_window */
EIF_POINTER F145_2404 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F145_2404 ();
	return Result;
}

/* {GDK}.c_gdk_geometry_struct_allocate */
EIF_POINTER F145_2407 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) calloc (sizeof(GdkGeometry), 1);
	return Result;
}

/* {GDK}.set_gdk_geometry_struct_max_height */
void F145_2412 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	(((GdkGeometry *)arg1)->max_height = (gint)(arg2));
	
}

/* {GDK}.set_gdk_geometry_struct_max_width */
void F145_2413 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	(((GdkGeometry *)arg1)->max_width = (gint)(arg2));
	
}

/* {GDK}.set_gdk_geometry_struct_min_height */
void F145_2415 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	(((GdkGeometry *)arg1)->min_height = (gint)(arg2));
	
}

/* {GDK}.set_gdk_geometry_struct_min_width */
void F145_2416 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	(((GdkGeometry *)arg1)->min_width = (gint)(arg2));
	
}

/* {GDK}.gdk_rectangle_struct_height */
EIF_INTEGER_32 F145_2420 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GdkRectangle *)arg1)->height);
	
	return Result;
}

/* {GDK}.gdk_rectangle_struct_width */
EIF_INTEGER_32 F145_2421 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GdkRectangle *)arg1)->width);
	
	return Result;
}

/* {GDK}.gdk_rectangle_struct_x */
EIF_INTEGER_32 F145_2422 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GdkRectangle *)arg1)->x);
	
	return Result;
}

/* {GDK}.gdk_rectangle_struct_y */
EIF_INTEGER_32 F145_2423 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GdkRectangle *)arg1)->y);
	
	return Result;
}

/* {GDK}.c_gdk_rectangle_struct_allocate */
EIF_POINTER F145_2424 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) calloc (sizeof(GdkRectangle), 1);
	return Result;
}

/* {GDK}.gdk_cursor_new_for_display */
EIF_POINTER F145_2426 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) arg2);
	
	return Result;
}

/* {GDK}.gdk_cursor_new_from_pixbuf */
EIF_POINTER F145_2427 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gdk_cursor_new_from_pixbuf((GdkDisplay*) arg1, (GdkPixbuf*) arg2, (gint) arg3, (gint) arg4);
	
	return Result;
}

/* {GDK}.gdk_selection_property_get */
EIF_INTEGER_32 F145_2428 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER* arg2, EIF_POINTER arg3, EIF_INTEGER_32* arg4)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) gdk_selection_property_get((GdkWindow*) arg1, (guchar**) arg2, (GdkAtom*) arg3, (gint*) arg4);
	
	return Result;
}

/* {GDK}.gdk_drag_get_selection */
EIF_POINTER F145_2429 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gdk_drag_get_selection((GdkDragContext*) arg1);
	
	return Result;
}

/* {GDK}.gdk_drag_context_get_source_window */
EIF_POINTER F145_2430 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gdk_drag_context_get_source_window((GdkDragContext*) arg1);
	
	return Result;
}

/* {GDK}.gdk_drag_context_get_dest_window */
EIF_POINTER F145_2431 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gdk_drag_context_get_dest_window((GdkDragContext*) arg1);
	
	return Result;
}

/* {GDK}.gdk_drag_context_list_targets */
EIF_POINTER F145_2432 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gdk_drag_context_list_targets((GdkDragContext*) arg1);
	
	return Result;
}

/* {GDK}.gdk_selection_convert */
void F145_2433 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_NATURAL_32 arg4)
{
	GTCX
	
	gdk_selection_convert((GdkWindow*) arg1, (GdkAtom) arg2, (GdkAtom) arg3, (guint32) arg4);
	
}

/* {GDK}.gdk_drop_finish */
void F145_2434 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2, EIF_NATURAL_32 arg3)
{
	GTCX
	
	gdk_drop_finish((GdkDragContext*) arg1, (gboolean) arg2, (guint32) arg3);
	
}

/* {GDK}.gdk_atom_name */
EIF_POINTER F145_2437 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gdk_atom_name((GdkAtom) arg1);
	
	return Result;
}

/* {GDK}.gdk_control_mask_enum */
EIF_NATURAL_32 F145_2446 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	Result = (EIF_NATURAL_32) GDK_CONTROL_MASK;
	return Result;
}

/* {GDK}.gdk_mod1_mask_enum */
EIF_NATURAL_32 F145_2447 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	Result = (EIF_NATURAL_32) GDK_MOD1_MASK;
	return Result;
}

/* {GDK}.gdk_shift_mask_enum */
EIF_NATURAL_32 F145_2448 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	Result = (EIF_NATURAL_32) GDK_SHIFT_MASK;
	return Result;
}

/* {GDK}.gdk_button_press_enum */
EIF_INTEGER_32 F145_2450 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_BUTTON_PRESS;
	return Result;
}

/* {GDK}.gdk_2button_press_enum */
EIF_INTEGER_32 F145_2451 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_2BUTTON_PRESS;
	return Result;
}

/* {GDK}.gdk_3button_press_enum */
EIF_INTEGER_32 F145_2452 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_3BUTTON_PRESS;
	return Result;
}

/* {GDK}.gdk_button_release_enum */
EIF_INTEGER_32 F145_2453 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_BUTTON_RELEASE;
	return Result;
}

/* {GDK}.gdk_exposure_mask_enum */
EIF_INTEGER_32 F145_2454 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_EXPOSURE_MASK;
	return Result;
}

/* {GDK}.gdk_pointer_motion_mask_enum */
EIF_INTEGER_32 F145_2455 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_POINTER_MOTION_MASK;
	return Result;
}

/* {GDK}.gdk_pointer_motion_hint_mask_enum */
EIF_INTEGER_32 F145_2456 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_POINTER_MOTION_HINT_MASK;
	return Result;
}

/* {GDK}.gdk_button_press_mask_enum */
EIF_INTEGER_32 F145_2460 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_BUTTON_PRESS_MASK;
	return Result;
}

/* {GDK}.gdk_button_release_mask_enum */
EIF_INTEGER_32 F145_2461 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_BUTTON_RELEASE_MASK;
	return Result;
}

/* {GDK}.gdk_key_press_enum */
EIF_INTEGER_32 F145_2466 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_KEY_PRESS;
	return Result;
}

/* {GDK}.gdk_key_press_mask_enum */
EIF_INTEGER_32 F145_2468 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_KEY_PRESS_MASK;
	return Result;
}

/* {GDK}.gdk_key_release_mask_enum */
EIF_INTEGER_32 F145_2469 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_KEY_RELEASE_MASK;
	return Result;
}

/* {GDK}.gdk_enter_notify_mask_enum */
EIF_INTEGER_32 F145_2470 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_ENTER_NOTIFY_MASK;
	return Result;
}

/* {GDK}.gdk_leave_notify_mask_enum */
EIF_INTEGER_32 F145_2471 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_LEAVE_NOTIFY_MASK;
	return Result;
}

/* {GDK}.gdk_focus_change_mask_enum */
EIF_INTEGER_32 F145_2472 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_FOCUS_CHANGE_MASK;
	return Result;
}

/* {GDK}.gdk_visibility_notify_mask_enum */
EIF_INTEGER_32 F145_2473 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_VISIBILITY_NOTIFY_MASK;
	return Result;
}

/* {GDK}.gdk_structure_mask_enum */
EIF_INTEGER_32 F145_2474 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_STRUCTURE_MASK;
	return Result;
}

/* {GDK}.gdk_scroll_mask_enum */
EIF_INTEGER_32 F145_2479 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_SCROLL_MASK;
	return Result;
}

/* {GDK}.gdk_decor_all_enum */
EIF_INTEGER_32 F145_2486 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_DECOR_ALL;
	return Result;
}

/* {GDK}.gdk_decor_border_enum */
EIF_INTEGER_32 F145_2487 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_DECOR_BORDER;
	return Result;
}

/* {GDK}.gdk_hint_max_size_enum */
EIF_INTEGER_32 F145_2490 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_HINT_MAX_SIZE;
	return Result;
}

/* {GDK}.gdk_hint_min_size_enum */
EIF_INTEGER_32 F145_2491 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_HINT_MIN_SIZE;
	return Result;
}

/* {GDK}.gdk_func_close_enum */
EIF_INTEGER_32 F145_2492 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_FUNC_CLOSE;
	return Result;
}

/* {GDK}.gdk_func_move_enum */
EIF_INTEGER_32 F145_2493 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_FUNC_MOVE;
	return Result;
}

/* {GDK}.gdk_func_resize_enum */
EIF_INTEGER_32 F145_2494 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_FUNC_RESIZE;
	return Result;
}

/* {GDK}.gdk_window_state_iconified_enum */
EIF_INTEGER_32 F145_2499 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_WINDOW_STATE_ICONIFIED;
	return Result;
}

/* {GDK}.gdk_window_state_maximized_enum */
EIF_INTEGER_32 F145_2500 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_WINDOW_STATE_MAXIMIZED;
	return Result;
}

/* {GDK}.gdk_scroll_up_enum */
EIF_INTEGER_32 F145_2505 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_SCROLL_UP;
	return Result;
}

/* {GDK}.gdk_interp_bilinear */
EIF_INTEGER_32 F145_2508 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_INTERP_BILINEAR;
	return Result;
}

/* {GDK}.gdk_interp_nearest */
EIF_INTEGER_32 F145_2510 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_INTERP_NEAREST;
	return Result;
}

void EIF_Minit109 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
