
#ifndef _C3_ev104_
#define _C3_ev104_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F140_2140(EIF_REFERENCE);
extern void EIF_Minit104(void);
extern void F872_6758(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
