/*
 * Code for class WIZARD_GENERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi130.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_GENERATOR}.make */
void F166_3367 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	F166_3368(Current);
	RTLE;
}

/* {WIZARD_GENERATOR}.initialize */
void F166_3368 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,846,0xFF01,1131,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F847_6622(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {WIZARD_GENERATOR}.application */
EIF_REFERENCE F166_3370 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_REFERENCE *)(RTCW(tr1));
	RTLE;
	return Result;
}

/* {WIZARD_GENERATOR}.send_response */
void F166_3373 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = F166_3370(Current);
	F360_5383(RTCW(tr1), arg1);
	RTLE;
}

/* {WIZARD_GENERATOR}.new_uuid */
EIF_REFERENCE F166_3374 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(43, 0x01).id, 43, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F1014_8450(RTCV(F44_787(RTCW(tr1))));
	RTLE;
	return Result;
}

/* {WIZARD_GENERATOR}.copy_file */
void F166_3375 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1001, 0x01).id, 1001, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F1001_7869(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = F1001_7903(RTCW(loc1));
	if (tb2) {
		tb2 = F1001_7906(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		loc2 = RTLNS(eif_new_type(1001, 0x01).id, 1001, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F1001_7869(RTCW(loc2), arg2);
		tb1 = '\01';
		tb2 = F1001_7903(RTCW(loc2));
		if (!(EIF_BOOLEAN) !tb2) {
			tb2 = F1001_7907(RTCW(loc2));
			tb1 = tb2;
		}
		if (tb1) {
			F1001_7938(RTCW(loc1));
			F1001_7939(RTCW(loc2));
			F1001_8025(RTCW(loc1), loc2);
			F1001_7955(RTCW(loc2));
			F1001_7955(RTCW(loc1));
		}
	}
	RTLE;
}

/* {WIZARD_GENERATOR}.recursive_copy_templates */
void F166_3379 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,loc6);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc2);
	RTLR(8,loc5);
	RTLR(9,Current);
	RTLIU(10);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(995, 0x01).id, 995, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F996_7522(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = F996_7545(RTCW(loc1));
	if (tb2) {
		tb2 = F996_7546(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(995, 0x01).id, 995, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F996_7522(RTCW(tr1), arg2);
		F996_7525(RTCW(tr1));
		tr1 = F996_7536(RTCW(loc1));
		tr1 = F850_6655(RTCW(tr1));
		loc6 = (EIF_REFERENCE) tr1;
		for (;;) {
			tb1 = F789_6437(loc6);
			if (tb1) break;
			loc3 = F789_6428(loc6);
			tb2 = '\0';
			tb3 = F1015_8466(RTCW(loc3));
			if ((EIF_BOOLEAN) !tb3) {
				tb3 = F1015_8465(RTCW(loc3));
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				loc4 = F1015_8488(RTCW(arg1), loc3);
				loc2 = RTLNS(eif_new_type(995, 0x01).id, 995, _OBJSIZ_3_0_0_1_0_2_0_0_);
				F996_7522(RTCW(loc2), loc4);
				tr1 = F166_3384(Current, loc3);
				loc5 = F1015_8488(RTCW(arg2), tr1);
				tb2 = F996_7545(RTCW(loc2));
				if (tb2) {
					F166_3379(Current, loc4, loc5);
				} else {
					if (F207_3957(Current, loc4)) {
						F207_3958(Current, loc4, loc5);
					} else {
						F166_3375(Current, loc4, loc5);
					}
				}
			}
			F789_6443(loc6);
		}
	}
	RTLE;
}

/* {WIZARD_GENERATOR}.copy_template */
void F166_3380 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,Current);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1002, 0x01).id, 1002, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F1003_8150(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6852[Dtype(RTCW(loc1))-1001])(loc1);
	if (tb2) {
		tb2 = F1001_7906(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		loc2 = RTLNS(eif_new_type(1002, 0x01).id, 1002, _OBJSIZ_5_7_2_4_1_1_2_1_);
		F1003_8150(RTCW(loc2), arg2);
		tb1 = '\01';
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6852[Dtype(RTCW(loc2))-1001])(loc2);
		if (!(EIF_BOOLEAN) !tb2) {
			tb2 = F1001_7907(RTCW(loc2));
			tb1 = tb2;
		}
		if (tb1) {
			F1001_7938(RTCW(loc1));
			F1001_7942(RTCW(loc2));
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R6911[Dtype(RTCW(loc1))-1001])(loc1);
			for (;;) {
				tb1 = F438_5887(RTCW(loc1));
				if (tb1) break;
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
				tr1 = F166_3381(Current, tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6865[Dtype(RTCW(loc2))-1001])(loc2, tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R6863[Dtype(RTCW(loc2))-1001])(loc2);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R6911[Dtype(RTCW(loc1))-1001])(loc1);
			}
			F1001_7955(RTCW(loc2));
			F1001_7955(RTCW(loc1));
		}
	}
	RTLE;
}

/* {WIZARD_GENERATOR}.resolved_string_8 */
EIF_REFERENCE F166_3381 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1136, 0x01).id, 1136, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8470[Dtype(arg1)-1134]);
	F1135_10080(RTCW(loc1), ti4_1);
	F166_3382(Current, arg1, loc1);
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {WIZARD_GENERATOR}.append_resolved_string_to */
void F166_3382 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,loc5);
	RTLR(4,loc6);
	RTLR(5,Current);
	RTLIU(6);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8271[Dtype(RTCW(arg1))-1132])(arg1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = RTMS_EX_H("${",2,9339);
		loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R8282[Dtype(RTCW(arg1))-1132])(arg1, tr1, loc1);
		tb1 = '\0';
		if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
			tb2 = '\01';
			if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 1L))) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8235[Dtype(RTCW(arg1))-1132])(arg1, (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '$';
				tb2 = (EIF_BOOLEAN)(tw1 != tw2);
			}
			tb1 = tb2;
		}
		if (tb1) {
			if ((EIF_BOOLEAN) (loc3 > loc1)) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8312[Dtype(RTCW(arg1))-1132])(arg1, loc1, (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8342[Dtype(RTCW(arg2))-1133])(arg2, tr1);
			}
			loc1 = (EIF_INTEGER_32) loc3;
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '}';
			loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32)) R8236[Dtype(RTCW(arg1))-1132])(arg1, tw1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
			if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
				loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8312[Dtype(RTCW(arg1))-1132])(arg1, (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 2L)), (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr1 = F841_6516(RTCW(tr1), loc5);
				loc6 = tr1;
				if (EIF_TEST(loc6)) {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8293[Dtype(loc6)-1132])(loc6);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8342[Dtype(RTCW(arg2))-1133])(arg2, tr1);
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8312[Dtype(RTCW(arg1))-1132])(arg1, loc3, loc4);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8342[Dtype(RTCW(arg2))-1133])(arg2, tr1);
				}
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8312[Dtype(RTCW(arg1))-1132])(arg1, loc1, loc2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8342[Dtype(RTCW(arg2))-1133])(arg2, tr1);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
			}
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8312[Dtype(RTCW(arg1))-1132])(arg1, loc1, loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8342[Dtype(RTCW(arg2))-1133])(arg2, tr1);
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		}
	}
	RTLE;
}

/* {WIZARD_GENERATOR}.resolved_string */
EIF_REFERENCE F166_3383 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8390[Dtype(arg1)-1131]);
	F1132_9913(RTCW(loc1), ti4_1);
	F166_3382(Current, arg1, loc1);
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {WIZARD_GENERATOR}.resolved_path_name */
EIF_REFERENCE F166_3384 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = F1015_8499(RTCW(arg1));
	loc2 = F166_3383(Current, loc1);
	tb1 = F1132_9940(RTCW(loc2), loc1);
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) arg1;
	} else {
		tr1 = RTLNS(eif_new_type(1014, 0x01).id, 1014, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F1015_8460(RTCW(tr1), loc2);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

void EIF_Minit130 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
