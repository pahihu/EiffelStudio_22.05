/*
 * Code for class CODE_SETS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co101.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CODE_SETS}.two_byte_code_pages */
static EIF_REFERENCE F137_2132_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (2132);
#define Result RTOSR(2132)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,846,0xFF01,1134,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 846, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F847_6622(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("UCS-2",5,1130177330);
	tr2 = RTMS_EX_H("ucs-2",5,1669391154);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("ISO-10646-UCS-2",15,137660722);
	tr2 = RTMS_EX_H("iso-10646-ucs-2",15,932466994);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("csUnicode",9,1140938597);
	tr2 = RTMS_EX_H("csunicode",9,67227493);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-2BE",7,722937925);
	tr2 = RTMS_EX_H("ucs-2be",7,1859875173);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UNICODEBIG",10,266927431);
	tr2 = RTMS_EX_H("unicodebig",10,1691026535);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UNICODE-1-1",11,1407647281);
	tr2 = RTMS_EX_H("unicode-1-1",11,366474289);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("csUnicode11",11,1599950641);
	tr2 = RTMS_EX_H("csunicode11",11,1339907633);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-2LE",7,722940485);
	tr2 = RTMS_EX_H("ucs-2le",7,1859877733);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UNICODELITTLE",13,852373061);
	tr2 = RTMS_EX_H("unicodelittle",13,1164725349);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(1021,F56_1021, (Current));
	tr2 = RTMS_EX_H("utf-16",6,1945159990);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(1025,F56_1025, (Current));
	tr2 = RTMS_EX_H("utf-16be",8,1456247141);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(1023,F56_1023, (Current));
	tr2 = RTMS_EX_H("utf-16le",8,1456249701);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-2-INTERNAL",14,834453068);
	tr2 = RTMS_EX_H("ucs-2-internal",14,1377880940);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-2-SWAPPED",13,297507908);
	tr2 = RTMS_EX_H("ucs-2-swapped",13,861666404);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("JAVA",4,1245795905);
	tr2 = RTMS_EX_H("java",4,1784772193);
	F841_6556(RTCW(Result), tr1, tr2);
	RTOSE (2132);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F137_2132 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2132,F137_2132_body,(Current));
}

/* {CODE_SETS}.four_byte_code_pages */
static EIF_REFERENCE F137_2133_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (2133);
#define Result RTOSR(2133)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,846,0xFF01,1134,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 846, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F847_6622(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("UCS-4",5,1130177332);
	tr2 = RTMS_EX_H("ucs-4",5,1669391156);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("ISO-10646-UCS-4",15,137660724);
	tr2 = RTMS_EX_H("iso-10646-ucs-4",15,932466996);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("csUCS4",6,1626000692);
	tr2 = RTMS_EX_H("csucs4",6,17497140);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4BE",7,723068997);
	tr2 = RTMS_EX_H("ucs-4be",7,1860006245);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4LE",7,723071557);
	tr2 = RTMS_EX_H("ucs-4le",7,1860008805);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(1022,F56_1022, (Current));
	tr2 = RTMS_EX_H("utf-32",6,1945160498);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(1026,F56_1026, (Current));
	tr2 = RTMS_EX_H("utf-32be",8,1489539429);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(1024,F56_1024, (Current));
	tr2 = RTMS_EX_H("utf-32le",8,1489541989);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4-INTERNAL",14,968724556);
	tr2 = RTMS_EX_H("ucs-4-internal",14,1512152428);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4-SWAPPED",13,415472708);
	tr2 = RTMS_EX_H("ucs-4-swapped",13,979631204);
	F841_6556(RTCW(Result), tr1, tr2);
	RTOSE (2133);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F137_2133 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2133,F137_2133_body,(Current));
}

/* {CODE_SETS}.little_endian_code_pages */
static EIF_REFERENCE F137_2134_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (2134);
#define Result RTOSR(2134)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,846,0xFF01,1134,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 846, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F847_6622(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("UCS-2LE",7,722940485);
	tr2 = RTMS_EX_H("ucs-2le",7,1859877733);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UNICODELITTLE",13,852373061);
	tr2 = RTMS_EX_H("unicodelittle",13,1164725349);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(1023,F56_1023, (Current));
	tr2 = RTMS_EX_H("utf-16le",8,1456249701);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4LE",7,723071557);
	tr2 = RTMS_EX_H("ucs-4le",7,1860008805);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(1024,F56_1024, (Current));
	tr2 = RTMS_EX_H("utf-32le",8,1489541989);
	F841_6556(RTCW(Result), tr1, tr2);
	RTOSE (2134);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F137_2134 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2134,F137_2134_body,(Current));
}

/* {CODE_SETS}.big_endian_code_pages */
static EIF_REFERENCE F137_2135_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (2135);
#define Result RTOSR(2135)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,846,0xFF01,1134,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 846, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F847_6622(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("UCS-2BE",7,722937925);
	tr2 = RTMS_EX_H("ucs-2be",7,1859875173);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UNICODEBIG",10,266927431);
	tr2 = RTMS_EX_H("unicodebig",10,1691026535);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(1025,F56_1025, (Current));
	tr2 = RTMS_EX_H("utf-16be",8,1456247141);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4BE",7,723068997);
	tr2 = RTMS_EX_H("ucs-4be",7,1860006245);
	F841_6556(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(1026,F56_1026, (Current));
	tr2 = RTMS_EX_H("utf-32be",8,1489539429);
	F841_6556(RTCW(Result), tr1, tr2);
	RTOSE (2135);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F137_2135 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2135,F137_2135_body,(Current));
}

void EIF_Minit101 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
