/*
 * Code for class WIZARD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi135.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD}.make */
void F171_3440 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {WIZARD}.new_page */
EIF_REFERENCE F171_3444 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5184[Dtype(RTCW(tr1))-1228])(tr1, arg1);
	RTLE;
	return Result;
}

/* {WIZARD}.notfound_page */
static EIF_REFERENCE F171_3446_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (3446);
#define Result RTOSR(3446)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("notfound",8,10334052);
	Result = F171_3444(Current, tr1);
	tr1 = RTMS_EX_H("Page Not Found",14,292060516);
	F939_7333(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Internal error in the wizard state machine.",43,925323566);
	F939_7334(RTCW(Result), tr1);
	RTOSE (3446);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F171_3446 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3446,F171_3446_body,(Current));
}

/* {WIZARD}.formatted_title_value_items */
EIF_REFERENCE F171_3453 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc4);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5429[Dtype(RTCW(arg1))-394])(arg1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5790[Dtype(loc3)-730])(loc3);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5789[Dtype(loc3)-730])(loc3);
		tr1 = eif_boxed_item(tr1,1);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8271[Dtype(RTCW(tr1))-1132])(tr1);
		ti4_1 = eif_max_int32 (loc2,ti4_1);
		loc2 = (EIF_INTEGER_32) ti4_1;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5791[Dtype(loc3)-730])(loc3);
	}
	loc2++;
	Result = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1129_9783(RTCW(Result));
	loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5429[Dtype(RTCW(arg1))-394])(arg1);
	for (;;) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5790[Dtype(loc4)-730])(loc4);
		if (tb2) break;
		loc1 = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_1_0_3_0_0_0_0_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5789[Dtype(loc4)-730])(loc4);
		tr1 = eif_boxed_item(tr1,1);
		F1134_9989(RTCW(loc1), tr1);
		tr1 = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_1_0_3_0_0_0_0_);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		F1132_9914(RTCW(tr1), tw1, (EIF_INTEGER_32) (loc2 - ti4_1));
		F1134_10028(RTCW(loc1), tr1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
		F1134_10041(RTCW(loc1), tw1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F1134_10041(RTCW(loc1), tw1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5789[Dtype(loc4)-730])(loc4);
		tr1 = eif_boxed_item(tr1,2);
		F1134_10027(RTCW(loc1), tr1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
		F1134_10041(RTCW(loc1), tw1);
		F1134_10028(RTCW(Result), loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5791[Dtype(loc4)-730])(loc4);
	}
	RTLE;
	return Result;
}

void EIF_Minit135 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
