/*
 * Code for class GTK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt112.h"
#include <stdlib.h>
#include <string.h>
#include <ev_gtk.h>
#include "eif_helpers.h"
#include <gmodule.h>
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F148_2973
static EIF_POINTER inline_F148_2973 (void)
{
	return gtk_settings_get_default();
	;
}
#define INLINE_F148_2973
#endif
#ifndef INLINE_F148_2975
static void inline_F148_2975 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_window_set_skip_taskbar_hint ((GtkWindow*) arg1, (gboolean) arg2);
	;
}
#define INLINE_F148_2975
#endif
#ifndef INLINE_F148_2998
static int inline_F148_2998 (EIF_POINTER arg1)
{
	return (int) (GTK_IS_WIDGET(arg1))
	;
}
#define INLINE_F148_2998
#endif
#ifndef INLINE_F148_3009
static EIF_POINTER inline_F148_3009 (EIF_POINTER arg1)
{
	return gtk_widget_get_display ((GtkWidget *)arg1)
	;
}
#define INLINE_F148_3009
#endif
#ifndef INLINE_F148_3023
static void inline_F148_3023 (EIF_POINTER arg1)
{
	gtk_widget_show_all ((GtkWidget *)arg1)
	;
}
#define INLINE_F148_3023
#endif
#ifndef INLINE_F148_3033
static void inline_F148_3033 (EIF_POINTER arg1)
{
	gtk_widget_queue_draw ((GtkWidget *)arg1)
	;
}
#define INLINE_F148_3033
#endif
#ifndef INLINE_F148_3074
static EIF_INTEGER_32 inline_F148_3074 (void)
{
	return (EIF_INTEGER_32) (GTK_JUSTIFY_CENTER)
	;
}
#define INLINE_F148_3074
#endif
#ifndef INLINE_F148_3124
static void inline_F148_3124 (EIF_POINTER arg1)
{
	gtk_menu_shell_cancel((GtkMenuShell*)arg1);
	;
}
#define INLINE_F148_3124
#endif
#ifndef INLINE_F148_3140
static void inline_F148_3140 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_entry_set_width_chars ((GtkEntry *)arg1, (gint)arg2)
	;
}
#define INLINE_F148_3140
#endif
#ifndef INLINE_F148_3165
static void inline_F148_3165 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_xalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F148_3165
#endif
#ifndef INLINE_F148_3166
static void inline_F148_3166 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_yalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F148_3166
#endif
#ifndef INLINE_F148_3168
static void inline_F148_3168 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_label_set_attributes ((GtkLabel *)arg1, (PangoAttrList *)arg2);
	;
}
#define INLINE_F148_3168
#endif
#ifndef INLINE_F146_2535
static int inline_F146_2535 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	return gtk_style_context_lookup_color((GtkStyleContext*) arg1, (gchar*) arg2, (GdkRGBA*) arg3);
	;
}
#define INLINE_F146_2535
#endif
#ifndef INLINE_F146_2513
static EIF_POINTER inline_F146_2513 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_BACKGROUND_COLOR)
	;
}
#define INLINE_F146_2513
#endif
#ifndef INLINE_F146_2536
static void inline_F146_2536 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	gtk_style_context_get (arg1, arg2, arg3, arg4, NULL)
	;
}
#define INLINE_F146_2536
#endif
#ifndef INLINE_F146_2614
static void inline_F146_2614 (EIF_POINTER arg1)
{
	gtk_widget_destroy((GtkWidget*) arg1)
	;
}
#define INLINE_F146_2614
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK}.is_x11_session */
static EIF_BOOLEAN F148_2964_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (2964);
#define Result RTOSR(2964)
	Result = '\0';
	tr2 = RTMS_EX_H("XDG_SESSION_TYPE",16,1292423749);
	tr1 = RTLNS(eif_new_type(376, 0x01).id, 376, _OBJSIZ_0_0_0_1_0_0_0_0_);
	tr2 = F377_5613(RTCW(tr1), tr2);
	loc1 = tr2;
	if (EIF_TEST(loc1)) {
		tr1 = RTMS_EX_H("x11",3,7876913);
		tb1 = F1129_9825(loc1, tr1);
		Result = tb1;
	}
	RTOSE (2964);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F148_2964 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2964,F148_2964_body,(Current));
}

/* {GTK}.is_wayland_session */
static EIF_BOOLEAN F148_2965_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (2965);
#define Result RTOSR(2965)
	Result = '\0';
	tr2 = RTMS_EX_H("XDG_SESSION_TYPE",16,1292423749);
	tr1 = RTLNS(eif_new_type(376, 0x01).id, 376, _OBJSIZ_0_0_0_1_0_0_0_0_);
	tr2 = F377_5613(RTCW(tr1), tr2);
	loc1 = tr2;
	if (EIF_TEST(loc1)) {
		tr1 = RTMS_EX_H("wayland",7,1775190116);
		tb1 = F1129_9825(loc1, tr1);
		Result = tb1;
	}
	RTOSE (2965);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F148_2965 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2965,F148_2965_body,(Current));
}

/* {GTK}.gtk_maj_ver */
EIF_INTEGER_32 F148_2966 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_MAJOR_VERSION;
	return Result;
}

/* {GTK}.g_module_supported */
EIF_BOOLEAN F148_2969 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(g_module_supported());
	
	return Result;
}

/* {GTK}.g_module_symbol */
EIF_BOOLEAN F148_2970 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER* arg3)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(g_module_symbol((GModule*) arg1, (gchar*) arg2, (gpointer*) arg3));
	
	return Result;
}

/* {GTK}.g_module_open */
EIF_POINTER F148_2971 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) g_module_open((gchar*) arg1, (GModuleFlags) arg2);
	
	return Result;
}

/* {GTK}.gtk_settings_get_default */
EIF_POINTER F148_2973 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F148_2973 ();
	return Result;
}

/* {GTK}.gtk_is_window */
EIF_BOOLEAN F148_2974 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((arg1)));
	return Result;
}

/* {GTK}.gtk_window_set_skip_taskbar_hint */
void F148_2975 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	
	inline_F148_2975 ((EIF_POINTER) arg1, (EIF_BOOLEAN) arg2);
}

/* {GTK}.gtk_window_get_title */
EIF_POINTER F148_2977 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_window_get_title((GtkWindow*) arg1);
	
	return Result;
}

/* {GTK}.gtk_window_new */
EIF_POINTER F148_2979 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_window_new((GtkWindowType) arg1);
	
	return Result;
}

/* {GTK}.gtk_window_set_default_size */
void F148_2980 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	gtk_window_set_default_size((GtkWindow*) arg1, (gint) arg2, (gint) arg3);
	
}

/* {GTK}.gtk_window_get_default_size */
void F148_2982 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	
	gtk_window_get_default_size((GtkWindow*) arg1, (EIF_INTEGER_32*) arg2, (EIF_INTEGER_32*) arg3);
	
}

/* {GTK}.gtk_window_set_focus */
void F148_2983 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_window_set_focus((GtkWindow*) arg1, (GtkWidget*) arg2);
	
}

/* {GTK}.gtk_window_set_geometry_hints */
void F148_2984 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	
	gtk_window_set_geometry_hints((GtkWindow*) arg1, (GtkWidget*) arg2, (GdkGeometry*) arg3, (GdkWindowHints) arg4);
	
}

/* {GTK}.gtk_window_set_position */
void F148_2986 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	gtk_window_set_position((GtkWindow*) arg1, (GtkWindowPosition) arg2);
	
}

/* {GTK}.gtk_window_set_title */
void F148_2987 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_window_set_title((GtkWindow*) arg1, (gchar*) arg2);
	
}

/* {GTK}.gtk_window_set_transient_for */
void F148_2988 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_window_set_transient_for((GtkWindow*) arg1, (GtkWindow*) arg2);
	
}

/* {GTK}.gtk_is_container */
EIF_BOOLEAN F148_2991 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(GTK_IS_CONTAINER((arg1)));
	return Result;
}

/* {GTK}.gtk_container_add */
void F148_2992 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_container_add((GtkContainer*) arg1, (GtkWidget*) arg2);
	
}

/* {GTK}.gtk_container_check_resize */
void F148_2993 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_container_check_resize((GtkContainer*) arg1);
	
}

/* {GTK}.gtk_container_get_children */
EIF_POINTER F148_2994 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_container_get_children((GtkContainer*) arg1);
	
	return Result;
}

/* {GTK}.gtk_container_remove */
void F148_2995 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_container_remove((GtkContainer*) arg1, (GtkWidget*) arg2);
	
}

/* {GTK}.gtk_container_set_border_width */
void F148_2996 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	gtk_container_set_border_width((GtkContainer*) arg1, (guint) arg2);
	
}

/* {GTK}.gtk_container_get_border_width */
EIF_INTEGER_32 F148_2997 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) gtk_container_get_border_width((GtkContainer*) arg1);
	
	return Result;
}

/* {GTK}.gtk_is_widget */
EIF_BOOLEAN F148_2998 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F148_2998 ((EIF_POINTER) arg1));
	return Result;
}

/* {GTK}.gtk_widget_set_hexpand */
void F148_2999 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	gtk_widget_set_hexpand((GtkWidget*) arg1, (gboolean) arg2);
	
}

/* {GTK}.gtk_widget_set_vexpand */
void F148_3000 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	gtk_widget_set_vexpand((GtkWidget*) arg1, (gboolean) arg2);
	
}

/* {GTK}.gtk_widget_get_display */
EIF_POINTER F148_3009 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F148_3009 ((EIF_POINTER) arg1);
	return Result;
}

/* {GTK}.gtk_widget_is_sensitive */
EIF_BOOLEAN F148_3010 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_sensitive((GtkWidget*) arg1));
	
	return Result;
}

/* {GTK}.gtk_widget_get_visible */
EIF_BOOLEAN F148_3012 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_visible((GtkWidget*) arg1));
	
	return Result;
}

/* {GTK}.gtk_widget_is_focus */
EIF_BOOLEAN F148_3014 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_focus((GtkWidget*) arg1));
	
	return Result;
}

/* {GTK}.gtk_widget_has_focus */
EIF_BOOLEAN F148_3015 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_has_focus((GtkWidget*) arg1));
	
	return Result;
}

/* {GTK}.gtk_widget_get_allocation */
void F148_3016 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_widget_get_allocation((GtkWidget*) arg1, (GtkAllocation*) arg2);
	
}

/* {GTK}.gtk_widget_get_allocated_width */
EIF_INTEGER_32 F148_3018 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) gtk_widget_get_allocated_width((GtkWidget*) arg1);
	
	return Result;
}

/* {GTK}.gtk_widget_get_allocated_height */
EIF_INTEGER_32 F148_3019 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) gtk_widget_get_allocated_height((GtkWidget*) arg1);
	
	return Result;
}

/* {GTK}.gtk_widget_get_parent */
EIF_POINTER F148_3020 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_widget_get_parent((GtkWidget*) arg1);
	
	return Result;
}

/* {GTK}.gtk_widget_get_window */
EIF_POINTER F148_3021 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) arg1);
	
	return Result;
}

/* {GTK}.gtk_widget_show_all */
void F148_3023 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F148_3023 ((EIF_POINTER) arg1);
}

/* {GTK}.gtk_widget_get_state_flags */
EIF_INTEGER_32 F148_3024 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) gtk_widget_get_state_flags((GtkWidget*) arg1);
	
	return Result;
}

/* {GTK}.gtk_widget_add_events */
void F148_3025 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	gtk_widget_add_events((GtkWidget*) arg1, (gint) arg2);
	
}

/* {GTK}.gtk_widget_event */
EIF_BOOLEAN F148_3028 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_event((GtkWidget*) arg1, (GdkEvent*) arg2));
	
	return Result;
}

/* {GTK}.gtk_widget_get_toplevel */
EIF_POINTER F148_3029 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_widget_get_toplevel((GtkWidget*) arg1);
	
	return Result;
}

/* {GTK}.gtk_widget_grab_focus */
void F148_3031 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_widget_grab_focus((GtkWidget*) arg1);
	
}

/* {GTK}.gtk_widget_hide */
void F148_3032 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_widget_hide((GtkWidget*) arg1);
	
}

/* {GTK}.gtk_widget_queue_draw */
void F148_3033 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F148_3033 ((EIF_POINTER) arg1);
}

/* {GTK}.gtk_widget_realize */
void F148_3036 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_widget_realize((GtkWidget*) arg1);
	
}

/* {GTK}.gtk_widget_set_name */
void F148_3037 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_widget_set_name((GtkWidget*) arg1, (gchar*) arg2);
	
}

/* {GTK}.gtk_widget_get_name */
EIF_POINTER F148_3038 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_widget_get_name((GtkWidget*) arg1);
	
	return Result;
}

/* {GTK}.gtk_widget_set_sensitive */
void F148_3039 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	gtk_widget_set_sensitive((GtkWidget*) arg1, (gboolean) arg2);
	
}

/* {GTK}.gtk_widget_set_can_focus */
void F148_3040 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	gtk_widget_set_can_focus((GtkWidget*) arg1, (gboolean) arg2);
	
}

/* {GTK}.gtk_widget_get_can_focus */
EIF_BOOLEAN F148_3041 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_can_focus((GtkWidget*) arg1));
	
	return Result;
}

/* {GTK}.gtk_widget_show */
void F148_3042 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_widget_show((GtkWidget*) arg1);
	
}

/* {GTK}.gtk_style_context_save */
void F148_3046 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_style_context_save((GtkStyleContext*) arg1);
	
}

/* {GTK}.gtk_style_context_restore */
void F148_3047 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_style_context_restore((GtkStyleContext*) arg1);
	
}

/* {GTK}.gtk_style_context_set_state */
void F148_3048 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	gtk_style_context_set_state((GtkStyleContext*) arg1, (GtkStateFlags) arg2);
	
}

/* {GTK}.gtk_style_context_get_state */
EIF_INTEGER_32 F148_3049 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) arg1);
	
	return Result;
}

/* {GTK}.gtk_drawing_area_new */
EIF_POINTER F148_3055 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_drawing_area_new();
	
	return Result;
}

/* {GTK}.g_source_remove */
void F148_3056 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	
	g_source_remove((guint) arg1);
	
}

/* {GTK}.gtk_cell_layout_get_cells */
EIF_POINTER F148_3057 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_cell_layout_get_cells((GtkCellLayout*) arg1);
	
	return Result;
}

/* {GTK}.gtk_state_flag_normal_enum */
EIF_INTEGER_32 F148_3067 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_STATE_NORMAL;
	return Result;
}

/* {GTK}.gtk_state_flag_insensitive_enum */
EIF_INTEGER_32 F148_3071 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_STATE_FLAG_INSENSITIVE;
	return Result;
}

/* {GTK}.gtk_justify_center_enum */
EIF_INTEGER_32 F148_3074 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F148_3074 ();
	return Result;
}

/* {GTK}.gtk_justify_left_enum */
EIF_INTEGER_32 F148_3075 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_JUSTIFY_LEFT;
	return Result;
}

/* {GTK}.gtk_justify_right_enum */
EIF_INTEGER_32 F148_3076 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_JUSTIFY_RIGHT;
	return Result;
}

/* {GTK}.gtk_shadow_none_enum */
EIF_INTEGER_32 F148_3078 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_SHADOW_NONE;
	return Result;
}

/* {GTK}.gtk_shadow_etched_in_enum */
EIF_INTEGER_32 F148_3079 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_SHADOW_ETCHED_IN;
	return Result;
}

/* {GTK}.gtk_shadow_etched_out_enum */
EIF_INTEGER_32 F148_3080 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_SHADOW_ETCHED_OUT;
	return Result;
}

/* {GTK}.gtk_shadow_in_enum */
EIF_INTEGER_32 F148_3081 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_SHADOW_IN;
	return Result;
}

/* {GTK}.gtk_shadow_out_enum */
EIF_INTEGER_32 F148_3082 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_SHADOW_OUT;
	return Result;
}

/* {GTK}.gtk_window_toplevel_enum */
EIF_INTEGER_32 F148_3083 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_WINDOW_TOPLEVEL;
	return Result;
}

/* {GTK}.gtk_window_popup_enum */
EIF_INTEGER_32 F148_3084 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_WINDOW_POPUP;
	return Result;
}

/* {GTK}.gtk_win_pos_center_enum */
EIF_INTEGER_32 F148_3085 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_WIN_POS_CENTER;
	return Result;
}

/* {GTK}.gtk_win_pos_none_enum */
EIF_INTEGER_32 F148_3086 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_WIN_POS_NONE;
	return Result;
}

/* {GTK}.gtk_policy_automatic_enum */
EIF_INTEGER_32 F148_3088 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_POLICY_AUTOMATIC;
	return Result;
}

/* {GTK}.gtk_policy_always_enum */
EIF_INTEGER_32 F148_3089 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_POLICY_ALWAYS;
	return Result;
}

/* {GTK}.gtk_policy_never_enum */
EIF_INTEGER_32 F148_3090 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_POLICY_NEVER;
	return Result;
}

/* {GTK}.gtk_drag_finish */
void F148_3095 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_NATURAL_32 arg4)
{
	GTCX
	
	gtk_drag_finish((GdkDragContext*) arg1, (gboolean) arg2, (gboolean) arg3, (guint32) arg4);
	
}

/* {GTK}.gtk_box_get_spacing */
EIF_INTEGER_32 F148_3098 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) gtk_box_get_spacing((GtkBox*) arg1);
	
	return Result;
}

/* {GTK}.gtk_box_pack_start */
void F148_3100 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	
	gtk_box_pack_start((GtkBox*) arg1, (GtkWidget*) arg2, (gboolean) arg3, (gboolean) arg4, (guint) arg5);
	
}

/* {GTK}.gtk_box_query_child_packing */
void F148_3101 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_POINTER arg5, EIF_POINTER arg6)
{
	GTCX
	
	gtk_box_query_child_packing((GtkBox*) arg1, (GtkWidget*) arg2, (gboolean*) arg3, (gboolean*) arg4, (guint*) arg5, (GtkPackType*) arg6);
	
}

/* {GTK}.gtk_box_reorder_child */
void F148_3102 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	gtk_box_reorder_child((GtkBox*) arg1, (GtkWidget*) arg2, (gint) arg3);
	
}

/* {GTK}.gtk_box_set_child_packing */
void F148_3103 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6)
{
	GTCX
	
	gtk_box_set_child_packing((GtkBox*) arg1, (GtkWidget*) arg2, (gboolean) arg3, (gboolean) arg4, (guint) arg5, (GtkPackType) arg6);
	
}

/* {GTK}.gtk_box_set_homogeneous */
void F148_3104 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	gtk_box_set_homogeneous((GtkBox*) arg1, (gboolean) arg2);
	
}

/* {GTK}.gtk_box_set_spacing */
void F148_3105 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	gtk_box_set_spacing((GtkBox*) arg1, (gint) arg2);
	
}

/* {GTK}.gtk_button_new */
EIF_POINTER F148_3107 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_button_new();
	
	return Result;
}

/* {GTK}.gtk_check_button_new */
EIF_POINTER F148_3108 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_check_button_new();
	
	return Result;
}

/* {GTK}.gtk_radio_button_get_group */
EIF_POINTER F148_3109 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_radio_button_get_group((GtkRadioButton*) arg1);
	
	return Result;
}

/* {GTK}.gtk_radio_button_set_group */
void F148_3111 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_radio_button_set_group((GtkRadioButton*) arg1, (GSList*) arg2);
	
}

/* {GTK}.gtk_is_menu */
EIF_BOOLEAN F148_3112 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(GTK_IS_MENU((arg1)));
	return Result;
}

/* {GTK}.gtk_check_menu_item_set_active */
void F148_3115 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	gtk_check_menu_item_set_active((GtkCheckMenuItem*) arg1, (gboolean) arg2);
	
}

/* {GTK}.gtk_menu_item_deselect */
void F148_3119 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_menu_item_deselect((GtkMenuItem*) arg1);
	
}

/* {GTK}.gtk_menu_item_new */
EIF_POINTER F148_3120 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_menu_item_new();
	
	return Result;
}

/* {GTK}.gtk_menu_item_set_submenu */
void F148_3122 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_menu_item_set_submenu((GtkMenuItem*) arg1, (GtkWidget*) arg2);
	
}

/* {GTK}.gtk_menu_new */
EIF_POINTER F148_3123 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_menu_new();
	
	return Result;
}

/* {GTK}.gtk_menu_shell_cancel */
void F148_3124 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F148_3124 ((EIF_POINTER) arg1);
}

/* {GTK}.gtk_menu_shell_deactivate */
void F148_3125 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_menu_shell_deactivate((GtkMenuShell*) arg1);
	
}

/* {GTK}.gtk_menu_shell_insert */
void F148_3127 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	gtk_menu_shell_insert((GtkMenuShell*) arg1, (GtkWidget*) arg2, (gint) arg3);
	
}

/* {GTK}.gtk_editable_set_editable */
void F148_3135 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	gtk_editable_set_editable((GtkEditable*) arg1, (gboolean) arg2);
	
}

/* {GTK}.gtk_entry_get_text */
EIF_POINTER F148_3137 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_entry_get_text((GtkEntry*) arg1);
	
	return Result;
}

/* {GTK}.gtk_entry_new */
EIF_POINTER F148_3138 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_entry_new();
	
	return Result;
}

/* {GTK}.gtk_entry_set_text */
void F148_3139 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_entry_set_text((GtkEntry*) arg1, (gchar*) arg2);
	
}

/* {GTK}.gtk_entry_set_width_chars */
void F148_3140 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	inline_F148_3140 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
}

/* {GTK}.gtk_frame_new */
EIF_POINTER F148_3147 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_frame_new((gchar*) arg1);
	
	return Result;
}

/* {GTK}.gtk_frame_set_label */
void F148_3148 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_frame_set_label((GtkFrame*) arg1, (gchar*) arg2);
	
}

/* {GTK}.gtk_frame_set_label_align */
void F148_3149 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2, EIF_REAL_32 arg3)
{
	GTCX
	
	gtk_frame_set_label_align((GtkFrame*) arg1, (gfloat) arg2, (gfloat) arg3);
	
}

/* {GTK}.gtk_frame_set_shadow_type */
void F148_3150 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	gtk_frame_set_shadow_type((GtkFrame*) arg1, (GtkShadowType) arg2);
	
}

/* {GTK}.gtk_grab_add */
void F148_3152 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_grab_add((GtkWidget*) arg1);
	
}

/* {GTK}.gtk_grab_get_current */
EIF_POINTER F148_3153 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_grab_get_current();
	
	return Result;
}

/* {GTK}.gtk_grab_remove */
void F148_3154 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_grab_remove((GtkWidget*) arg1);
	
}

/* {GTK}.gtk_is_label */
EIF_BOOLEAN F148_3161 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(GTK_IS_LABEL((arg1)));
	return Result;
}

/* {GTK}.gtk_label_new */
EIF_POINTER F148_3162 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_label_new((gchar*) arg1);
	
	return Result;
}

/* {GTK}.gtk_label_set_justify */
void F148_3163 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	gtk_label_set_justify((GtkLabel*) arg1, (GtkJustification) arg2);
	
}

/* {GTK}.gtk_label_set_text */
void F148_3164 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_label_set_text((GtkLabel*) arg1, (gchar*) arg2);
	
}

/* {GTK}.gtk_label_set_xalign */
void F148_3165 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	GTCX
	
	
	inline_F148_3165 ((EIF_POINTER) arg1, (EIF_REAL_32) arg2);
}

/* {GTK}.gtk_label_set_yalign */
void F148_3166 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	GTCX
	
	
	inline_F148_3166 ((EIF_POINTER) arg1, (EIF_REAL_32) arg2);
}

/* {GTK}.gtk_label_set_attributes */
void F148_3168 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F148_3168 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {GTK}.gtk_radio_menu_item_set_group */
void F148_3172 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_radio_menu_item_set_group((GtkRadioMenuItem*) arg1, (GSList*) arg2);
	
}

/* {GTK}.gtk_scrolled_window_get_hadjustment */
EIF_POINTER F148_3178 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_scrolled_window_get_hadjustment((GtkScrolledWindow*) arg1);
	
	return Result;
}

/* {GTK}.gtk_scrolled_window_get_vadjustment */
EIF_POINTER F148_3179 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_scrolled_window_get_vadjustment((GtkScrolledWindow*) arg1);
	
	return Result;
}

/* {GTK}.gtk_scrolled_window_new */
EIF_POINTER F148_3180 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_scrolled_window_new((GtkAdjustment*) arg1, (GtkAdjustment*) arg2);
	
	return Result;
}

/* {GTK}.gtk_scrolled_window_set_policy */
void F148_3181 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	gtk_scrolled_window_set_policy((GtkScrolledWindow*) arg1, (GtkPolicyType) arg2, (GtkPolicyType) arg3);
	
}

/* {GTK}.gtk_toggle_button_get_active */
EIF_BOOLEAN F148_3184 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_toggle_button_get_active((GtkToggleButton*) arg1));
	
	return Result;
}

/* {GTK}.gtk_toggle_button_set_active */
void F148_3186 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	gtk_toggle_button_set_active((GtkToggleButton*) arg1, (gboolean) arg2);
	
}

/* {GTK}.gtk_get_event_widget */
EIF_POINTER F148_3187 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_get_event_widget((GdkEvent*) arg1);
	
	return Result;
}

/* {GTK}.gtk_main_do_event */
void F148_3188 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_main_do_event((GdkEvent*) arg1);
	
}

/* {GTK}.gtk_propagate_event */
void F148_3189 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_propagate_event((GtkWidget*) arg1, (GdkEvent*) arg2);
	
}

/* {GTK}.gtk_allocation_struct_height */
EIF_INTEGER_32 F148_3190 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GtkAllocation *)arg1)->height);
	
	return Result;
}

/* {GTK}.gtk_allocation_struct_width */
EIF_INTEGER_32 F148_3191 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GtkAllocation *)arg1)->width);
	
	return Result;
}

/* {GTK}.gtk_allocation_struct_x */
EIF_INTEGER_32 F148_3192 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GtkAllocation *)arg1)->x);
	
	return Result;
}

/* {GTK}.gtk_allocation_struct_y */
EIF_INTEGER_32 F148_3193 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GtkAllocation *)arg1)->y);
	
	return Result;
}

/* {GTK}.set_gtk_allocation_struct_height */
void F148_3194 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	(((GtkAllocation *)arg1)->height = (gint)(arg2));
	
}

/* {GTK}.set_gtk_allocation_struct_width */
void F148_3195 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	(((GtkAllocation *)arg1)->width = (gint)(arg2));
	
}

/* {GTK}.c_gtk_allocation_struct_size */
EIF_INTEGER_32 F148_3198 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) sizeof(GtkAllocation);
	return Result;
}

/* {GTK}.gtk_bin_get_child */
EIF_POINTER F148_3200 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_bin_get_child((GtkBin*) arg1);
	
	return Result;
}

/* {GTK}.gtk_viewport_new */
EIF_POINTER F148_3214 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_viewport_new((GtkAdjustment*) arg1, (GtkAdjustment*) arg2);
	
	return Result;
}

/* {GTK}.gtk_adjustment_set_value */
void F148_3217 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	GTCX
	
	gtk_adjustment_set_value((GtkAdjustment*) arg1, (gfloat) arg2);
	
}

/* {GTK}.gtk_adjustment_get_lower */
EIF_REAL_32 F148_3218 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	
	Result = (EIF_REAL_32) gtk_adjustment_get_lower((GtkAdjustment*) arg1);
	
	return Result;
}

/* {GTK}.gtk_adjustment_get_step_increment */
EIF_REAL_32 F148_3221 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	
	Result = (EIF_REAL_32) gtk_adjustment_get_step_increment((GtkAdjustment*) arg1);
	
	return Result;
}

/* {GTK}.gtk_adjustment_get_upper */
EIF_REAL_32 F148_3222 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	
	Result = (EIF_REAL_32) gtk_adjustment_get_upper((GtkAdjustment*) arg1);
	
	return Result;
}

/* {GTK}.gtk_adjustment_get_value */
EIF_REAL_32 F148_3223 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	
	Result = (EIF_REAL_32) gtk_adjustment_get_value((GtkAdjustment*) arg1);
	
	return Result;
}

/* {GTK}.gtk_adjustment_set_lower */
void F148_3225 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	GTCX
	
	gtk_adjustment_set_lower((GtkAdjustment*) arg1, (gdouble) arg2);
	
}

/* {GTK}.gtk_adjustment_set_step_increment */
void F148_3228 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	GTCX
	
	gtk_adjustment_set_step_increment((GtkAdjustment*) arg1, (gdouble) arg2);
	
}

/* {GTK}.gtk_adjustment_set_upper */
void F148_3229 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	GTCX
	
	gtk_adjustment_set_upper((GtkAdjustment*) arg1, (gdouble) arg2);
	
}

/* {GTK}.gtk_requisition_struct_height */
EIF_INTEGER_32 F148_3230 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GtkRequisition *)arg1)->height);
	
	return Result;
}

/* {GTK}.gtk_requisition_struct_width */
EIF_INTEGER_32 F148_3231 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GtkRequisition *)arg1)->width);
	
	return Result;
}

/* {GTK}.c_gtk_requisition_struct_size */
EIF_INTEGER_32 F148_3232 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) sizeof(GtkRequisition);
	return Result;
}

/* {GTK}.rgba_struct_to_style_color_string */
EIF_REFERENCE F148_3234 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REAL_64 loc4 = (EIF_REAL_64) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc5);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 255L));
	loc1 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) (((GdkRGBA *)arg1)->red) * tr8_1);
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 255L));
	loc2 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) (((GdkRGBA *)arg1)->green) * tr8_1);
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 255L));
	loc3 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) (((GdkRGBA *)arg1)->blue) * tr8_1);
	loc4 = (EIF_REAL_64) (((GdkRGBA *)arg1)->alpha);
	if ((EIF_BOOLEAN) eif_is_less_real_64 (loc4, (EIF_REAL_64) 1.0)) {
		loc5 = RTLNS(eif_new_type(1557, 0x01).id, 1557, _OBJSIZ_1_8_0_4_0_0_0_0_);
		F1558_15814(RTCW(loc5), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 7L));
		tr1 = RTMS_EX_H("rgb(",4,1919377960);
		tr2 = eif_out__i4_s1(loc1);
		tr1 = F1137_10212(tr1, tr2);
		tr2 = RTMS_EX_H(",",1,44);
		tr1 = F1137_10212(RTCW(tr1), tr2);
		tr2 = eif_out__i4_s1(loc2);
		tr1 = F1137_10212(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(",",1,44);
		tr1 = F1137_10212(RTCW(tr1), tr2);
		tr2 = eif_out__i4_s1(loc3);
		tr1 = F1137_10212(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(",",1,44);
		tr1 = F1137_10212(RTCW(tr1), tr2);
		tr2 = F1558_15832(RTCW(loc5), loc4);
		tr1 = F1137_10212(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(")",1,41);
		Result = F1137_10212(RTCW(tr1), tr2);
	} else {
		tr1 = RTMS_EX_H("rgb(",4,1919377960);
		tr2 = eif_out__i4_s1(loc1);
		tr1 = F1137_10212(tr1, tr2);
		tr2 = RTMS_EX_H(",",1,44);
		tr1 = F1137_10212(RTCW(tr1), tr2);
		tr2 = eif_out__i4_s1(loc2);
		tr1 = F1137_10212(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(",",1,44);
		tr1 = F1137_10212(RTCW(tr1), tr2);
		tr2 = eif_out__i4_s1(loc3);
		tr1 = F1137_10212(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(")",1,41);
		Result = F1137_10212(RTCW(tr1), tr2);
	}
	RTLE;
	return Result;
}

/* {GTK}.rgba_struct_to_color */
EIF_REFERENCE F148_3235 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_64 tr8_1;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTLNS(eif_new_type(1174, 0x01).id, 1174, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr8_1 = (EIF_REAL_64) (((GdkRGBA *)arg1)->red);
	tr4_1 = (EIF_REAL_32) (tr8_1);
	tr8_1 = (EIF_REAL_64) (((GdkRGBA *)arg1)->green);
	tr4_2 = (EIF_REAL_32) (tr8_1);
	tr8_1 = (EIF_REAL_64) (((GdkRGBA *)arg1)->blue);
	tr4_3 = (EIF_REAL_32) (tr8_1);
	F1175_10481(RTCW(Result), tr4_1, tr4_2, tr4_3);
	RTLE;
	return Result;
}

/* {GTK}.style_color */
EIF_REFERENCE F148_3236 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc2 = (EIF_POINTER) calloc (sizeof(GdkRGBA), 1);
	loc1 = RTLNS(eif_new_type(992, 0x01).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F993_7487(RTCW(loc1), arg2);
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	loc3 = EIF_TEST (inline_F146_2535(arg1, tp1, loc2));
	if (loc3) {
		Result = F148_3235(Current, loc2);
	}
	free(loc2);
	RTLE;
	return Result;
}

/* {GTK}.rgba_string_style_color */
EIF_REFERENCE F148_3237 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc2 = (EIF_POINTER) calloc (sizeof(GdkRGBA), 1);
	loc1 = RTLNS(eif_new_type(992, 0x01).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F993_7487(RTCW(loc1), arg2);
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	loc3 = EIF_TEST (inline_F146_2535(arg1, tp1, loc2));
	if (loc3) {
		Result = F148_3234(Current, loc2);
	}
	free(loc2);
	RTLE;
	return Result;
}

/* {GTK}.rgba_string_default_background_color */
EIF_REFERENCE F148_3238 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	loc2 = (EIF_POINTER) gtk_dialog_new();
	tb1 = !loc2;
	if ((EIF_BOOLEAN) !tb1) {
		loc3 = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) loc2);
		ti4_1 = (EIF_INTEGER_32) GTK_STATE_NORMAL;
		tp1 = inline_F146_2513();
		inline_F146_2536(loc3, ti4_1, tp1, (EIF_POINTER *) &(loc1));
		Result = F148_3234(Current, loc1);
		gdk_rgba_free((GdkRGBA*) loc1);
		inline_F146_2614(loc2);
	} else {
		Result = RTMS_EX_H("rgb(0,0,0)",10,427135529);
	}
	RTLE;
	return Result;
}

void EIF_Minit112 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
