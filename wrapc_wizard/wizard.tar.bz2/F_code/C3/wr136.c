/*
 * Code for class WRAPC_WIZARD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wr136.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WRAPC_WIZARD}.title */

EIF_REFERENCE F172_3454 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (3454,RTMS32_EX_H("E\000\000\000i\000\000\000f\000\000\000f\000\000\000e\000\000\000l\000\000\000 \000\000\000W\000\000\000r\000\000\000a\000\000\000p\000\000\000C\000\000\000 \000\000\000W\000\000\000i\000\000\000z\000\000\000a\000\000\000r\000\000\000d\000\000\000",19,177863780));
}

/* {WRAPC_WIZARD}.default_project_name */

EIF_REFERENCE F172_3455 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (3455,RTMS32_EX_H("n\000\000\000e\000\000\000w\000\000\000_\000\000\000l\000\000\000i\000\000\000b\000\000\000r\000\000\000a\000\000\000r\000\000\000y\000\000\000",11,199349881));
}

/* {WRAPC_WIZARD}.wizard_generator */
EIF_REFERENCE F172_3456 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(206, 0x01).id, 206, _OBJSIZ_4_0_0_0_0_0_0_0_);
	F166_3367(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {WRAPC_WIZARD}.first_page */
static EIF_REFERENCE F172_3457_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (3457);
#define Result RTOSR(3457)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("first",5,1769891700);
	Result = F171_3444(Current, tr1);
	tr1 = RTMS_EX_H("Eiffel WrapC Wizard",19,177863780);
	F939_7333(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Create a reusable Eiffel WrapC Library.",39,1397869870);
	F939_7338(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("WrapC is an Eiffel wrapper generator for C libraries\012It can be used to create libraries that bridge the gap between Eiffel and C. \012It aims to work for arbitrary ANSI C and with EiffelSoftware compiler\012\011\012\012More information at:",224,699514938);
	F939_7339(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("- https://github.com/eiffel-wrap-c",34,1713720419);
	tr2 = RTMS_EX_H("https://github.com/eiffel-wrap-c",32,1395383395);
	F939_7346(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("- https://github.com/eiffel-wrap-c/WrapC/blob/master/doc/Readme.md",66,827879268);
	tr2 = RTMS_EX_H("https://github.com/eiffel-wrap-c/WrapC/blob/master/doc/Readme.md",64,1420794468);
	F939_7346(RTCW(Result), tr1, tr2);
	RTOSE (3457);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F172_3457 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3457,F172_3457_body,(Current));
}

/* {WRAPC_WIZARD}.library_page */
static EIF_REFERENCE F172_3458_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(8);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc2);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLIU(8);
	
	RTEV;
	RTGC;
	RTOSP (3458);
#define Result RTOSR(3458)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("library",7,649884793);
	Result = F171_3444(Current, tr1);
	tr1 = RTOSCF(3459,F172_3459, (Current));
	F939_7335(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Library Name and Project Location",33,1451097966);
	F939_7333(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("You can choose the name of the project and\012the directory where the project will be generated.",93,1036771374);
	F939_7334(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Please fill in:\012\011The name of the project (without space).\012\011The directory where you want the eiffel classes to be generated.",123,1372568622);
	F939_7339(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Project name:",13,853875770);
	tr2 = RTMS_EX_H("name",4,1851878757);
	tr3 = RTMS_EX_H("ASCII name, without space",25,481648485);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R6547[Dtype(RTCW(Result))-939])(Result, tr1, tr2, tr3);
	F939_7337(RTCW(Result), loc1);
	tr1 = RTMS_EX_H("Project location:",17,271127098);
	tr2 = RTMS_EX_H("location",8,59511406);
	tr3 = RTMS_EX_H("Valid directory path, it will be created if missing",51,1461816167);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R6548[Dtype(RTCW(Result))-939])(Result, tr1, tr2, tr3);
	F939_7337(RTCW(Result), loc2);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1049,0xFF01,0,0xFF01,320,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = loc2;
	RTAR(tr2,loc2);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,321,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A136_55_2, (EIF_POINTER) _A136_55_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	F865_6724(RTCW(tr1), tr5);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
	tr2 = RTOSCF(3455,F172_3455, (Current));
	tr3 = RTMS_EX_H("name",4,1851878757);
	F914_7124(RTCW(tr1), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
	tr2 = *(EIF_REFERENCE *)(Current);
	tr3 = RTOSCF(3455,F172_3455, (Current));
	tr4 = *(EIF_REFERENCE *)(Current);
	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + _REFACS_2_);
	tr4 = F356_5253(RTCW(tr4));
	tr5 = RTMS_EX_H("demo",4,1684368751);
	tr4 = F1015_8487(RTCW(tr4), tr5);
	tr2 = F360_5367(RTCW(tr2), tr3, tr4);
	tr2 = F1015_8499(RTCW(tr2));
	tr3 = RTMS_EX_H("location",8,59511406);
	F914_7124(RTCW(tr1), tr2, tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1049,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,938,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A136_56_2, (EIF_POINTER) _A136_56_2, (EIF_POINTER)(0),tr1, 1, 1);
	}
	F939_7336(RTCW(Result), tr4);
	RTOSE (3458);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F172_3458 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3458,F172_3458_body,(Current));
}

/* {WRAPC_WIZARD}.c_library_page */
static EIF_REFERENCE F172_3459_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOSP (3459);
#define Result RTOSR(3459)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("c_library",9,68590969);
	Result = F171_3444(Current, tr1);
	tr1 = RTOSCF(3457,F172_3457, (Current));
	F939_7335(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("C Library Name and Location",27,919826286);
	F939_7333(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Set the C library name and\012the directory where the C header will be located and the header to be used",101,1869090916);
	F939_7334(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("C Library name:",15,1683713850);
	tr2 = RTMS_EX_H("name",4,1851878757);
	tr3 = RTMS_EX_H("ASCII name, without space",25,481648485);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R6547[Dtype(RTCW(Result))-939])(Result, tr1, tr2, tr3);
	F939_7337(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("C library header location:",26,1139333690);
	tr2 = RTMS_EX_H("c_header_location",17,403451502);
	tr3 = RTMS_EX_H("Filename (including pathname) to the C header to be preprocessed,\012and name of header file, that should be used in Eiffel external clauses",137,1218803827);
	F939_7345(RTCW(Result), tr1, tr2, tr3);
	tr1 = RTMS_EX_H("C compiler options:",19,233786938);
	tr2 = RTMS_EX_H("c_compile_options",17,1319005043);
	tr3 = RTMS_EX_H("Optional c compile options",26,1271369331);
	F939_7341(RTCW(Result), tr1, tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
	tr2 = F1129_9842(RTMS_EX_H("c_library",9,68590969));
	tr3 = RTMS_EX_H("name",4,1851878757);
	F914_7124(RTCW(tr1), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
	tr2 = F1129_9842(RTMS_EX_H("",0,0));
	tr3 = RTMS_EX_H("c_header_location",17,403451502);
	F914_7124(RTCW(tr1), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
	tr2 = F1129_9842(RTMS_EX_H("",0,0));
	tr3 = RTMS_EX_H("c_compile_options",17,1319005043);
	F914_7124(RTCW(tr1), tr2, tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1049,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,938,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A136_53_2, (EIF_POINTER) _A136_53_2, (EIF_POINTER)(0),tr1, 1, 1);
	}
	F939_7336(RTCW(Result), tr4);
	RTOSE (3459);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F172_3459 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3459,F172_3459_body,(Current));
}

/* {WRAPC_WIZARD}.select_c_functions_page */
EIF_REFERENCE F172_3460 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,tr2);
	RTLR(6,loc1);
	RTLR(7,loc3);
	RTLIU(8);
	
	RTGC;
	tr1 = RTMS_EX_H("c_functions",11,1715247475);
	Result = F171_3444(Current, tr1);
	tr1 = RTOSCF(3458,F172_3458, (Current));
	F939_7335(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("List of C functions",19,2093768563);
	F939_7333(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Select the C funtions that you want to wrap.",44,1668811310);
	F939_7334(RTCW(Result), tr1);
	loc2 = RTMS32_EX_H("",0,0);
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(3459,F172_3459, (Current))) + _REFACS_8_);
	tr2 = RTMS_EX_H("c_header_location",17,403451502);
	tr1 = F914_7115(RTCW(tr1), tr2);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc2 = F1129_9842(loc4);
		tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
		tr2 = RTMS_EX_H("c_full_header_path",18,736680296);
		F914_7124(RTCW(tr1), loc2, tr2);
	}
	loc1 = RTLNS(eif_new_type(60, 0x01).id, 60, _OBJSIZ_4_0_0_0_0_0_0_0_);
	F61_1087(RTCW(loc1), loc2);
	loc3 = RTLNS(eif_new_type(324, 0x01).id, 324, _OBJSIZ_11_0_0_0_0_0_0_0_);
	tr1 = RTMS_EX_H("select_c_functions",18,1932044147);
	tr2 = *(EIF_REFERENCE *)(RTCW(loc1));
	F325_5072(RTCW(loc3), tr1, tr2, loc2);
	F939_7337(RTCW(Result), loc3);
	RTLE;
	return Result;
}

/* {WRAPC_WIZARD}.final_page */
static EIF_REFERENCE F172_3462_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(8);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLIU(8);
	
	RTEV;
	RTGC;
	RTOSP (3462);
#define Result RTOSR(3462)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("final",5,1769624940);
	Result = F171_3444(Current, tr1);
	tr1 = RTMS_EX_H("Completing the New Eiffel WrapC Library Wizard",46,1175116132);
	F939_7333(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("You have specified the following settings:\012\012",44,412579594);
	F939_7339(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("...",3,3026478);
	loc1 = F939_7349(RTCW(Result), tr1);
	F939_7337(RTCW(Result), loc1);
	tr1 = RTMS_EX_H("List of C functions to be wrapped",33,1088122212);
	loc2 = F939_7349(RTCW(Result), tr1);
	F939_7337(RTCW(Result), loc2);
	loc3 = RTLNS(eif_new_type(1270, 0x01).id, 1270, _OBJSIZ_5_3_0_1_0_0_0_0_);
	F1168_10363(RTCW(loc3));
	loc4 = RTLNS(eif_new_type(1218, 0x01).id, 1218, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1168_10363(RTCW(loc4));
	F1212_11014(RTCW(loc3), ((EIF_INTEGER_32) 50L), ((EIF_INTEGER_32) 100L));
	F1210_10953(RTCW(loc4), loc3);
	F1217_11095(RTCW(loc4), ((EIF_INTEGER_32) 5L));
	F1217_11096(RTCW(loc4), ((EIF_INTEGER_32) 5L));
	tr1 = RTMS_EX_H("List of C functions to be wrapped",33,1088122212);
	F1194_10741(RTCW(loc3), tr1);
	F1217_11099(RTCW(loc4), loc3);
	tr1 = RTLNS(eif_new_type(325, 0x01).id, 325, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F326_5086(RTCW(tr1), loc4);
	F939_7337(RTCW(Result), tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_5_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,5,1049,0xFF01,0,0xFF01,938,0xFF01,314,0xFF01,314,0xFF01,1270,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 6, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = Result;
	RTAR(tr2,Result);
	((EIF_TYPED_VALUE *)tr2+3)->it_r = loc1;
	RTAR(tr2,loc1);
	((EIF_TYPED_VALUE *)tr2+4)->it_r = loc2;
	RTAR(tr2,loc2);
	((EIF_TYPED_VALUE *)tr2+5)->it_r = loc3;
	RTAR(tr2,loc3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,0,1049,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A136_52, (EIF_POINTER) _A136_52, (EIF_POINTER)(0),tr2, 1, 0);
	}
	F865_6724(RTCW(tr1), tr3);
	RTOSE (3462);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F172_3462 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3462,F172_3462_body,(Current));
}

/* {WRAPC_WIZARD}.next_page */
EIF_REFERENCE F172_3463 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	Result = RTOSCF(3446,F171_3446, (Current));
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		Result = RTOSCF(3457,F172_3457, (Current));
		RTLE;
		return (EIF_REFERENCE) Result;
	} else {
		if ((EIF_BOOLEAN)(arg1 == RTOSCF(3457,F172_3457, (Current)))) {
			Result = RTOSCF(3459,F172_3459, (Current));
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			tr2 = RTMS_EX_H("c_library",9,68590969);
			tb1 = F1135_10106(RTCW(tr1), tr2);
			if (tb1) {
				Result = RTOSCF(3458,F172_3458, (Current));
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
				tr2 = RTMS_EX_H("library",7,649884793);
				tb1 = F1135_10106(RTCW(tr1), tr2);
				if (tb1) {
					Result = F172_3460(Current);
				} else {
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
					tr2 = RTMS_EX_H("c_functions",11,1715247475);
					tb1 = F1135_10106(RTCW(tr1), tr2);
					if (tb1) {
						F172_3464(Current, arg1);
						Result = RTOSCF(3462,F172_3462, (Current));
						RTLE;
						return (EIF_REFERENCE) Result;
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {WRAPC_WIZARD}.copy_functions_to_wizard_data */
void F172_3464 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc4);
	RTLR(4,loc5);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	F850_6672(RTCW(tr1));
	for (;;) {
		tb1 = '\01';
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		tb2 = F669_6111(RTCW(tr1));
		if (!tb2) {
			tb1 = (EIF_BOOLEAN)(loc1 != NULL);
		}
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		tr1 = F850_6646(RTCW(tr1));
		loc4 = tr1;
		loc4 = RTRV(eif_new_type(324, 0x01),loc4);
		if (EIF_TEST(loc4)) {
			loc1 = *(EIF_REFERENCE *)(loc4 + _REFACS_6_);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		F850_6674(RTCW(tr1));
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = F1272_11646(RTCW(loc1));
		loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5429[Dtype(RTCW(tr1))-394])(tr1);
		for (;;) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5790[Dtype(loc5)-730])(loc5);
			if (tb2) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5789[Dtype(loc5)-730])(loc5);
			tr1 = F1197_10756(RTCW(tr1));
			loc3 = F1129_9836(RTCW(tr1));
			loc2 = F1135_10093(RTCW(loc3), (EIF_CHARACTER_8) '(', ((EIF_INTEGER_32) 1L));
			tr1 = F1137_10240(RTCW(loc3), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
			loc3 = (EIF_REFERENCE) tr1;
			F1131_9906(RTCW(loc3));
			tc1 = F1137_10160(RTCW(loc3), ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '*')) {
				F1137_10215(RTCW(loc3), ((EIF_INTEGER_32) 1L));
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5648[Dtype(RTCW(tr1))-692])(tr1, loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5791[Dtype(loc5)-730])(loc5);
		}
	}
	RTLE;
}

/* {WRAPC_WIZARD}.inline-agent#1 of final_page */
void F172_16595 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLR(6,arg4);
	RTLR(7,loc4);
	RTLR(8,tr2);
	RTLR(9,loc5);
	RTLR(10,loc6);
	RTLR(11,loc7);
	RTLR(12,loc8);
	RTLR(13,loc9);
	RTLR(14,loc10);
	RTLR(15,arg2);
	RTLIU(16);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,849,0xFF01,0xFFF9,2,1049,0xFF01,1128,0xFF01,1128,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 849, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F850_6641(RTCW(loc1), ((EIF_INTEGER_32) 10L));
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_6_);
		tr1 = F850_6648(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(324, 0x01),loc3);
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		F1210_10966(RTCW(arg4));
		tr1 = *(EIF_REFERENCE *)(loc3 + _REFACS_6_);
		tr1 = F1272_11646(RTCW(tr1));
		loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5429[Dtype(RTCW(tr1))-394])(tr1);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5790[Dtype(loc4)-730])(loc4);
			if (tb1) break;
			tr1 = RTLNS(eif_new_type(1249, 0x01).id, 1249, _OBJSIZ_6_0_0_1_0_0_0_0_);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5789[Dtype(loc4)-730])(loc4);
			tr2 = F1197_10756(RTCW(tr2));
			F1197_10755(RTCW(tr1), tr2);
			F1210_10952(RTCW(arg4), tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5791[Dtype(loc4)-730])(loc4);
		}
	}
	tr1 = RTOSCF(3458,F172_3458, (Current));
	tr2 = RTMS_EX_H("name",4,1851878757);
	tr1 = F939_7325(RTCW(tr1), tr2);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1049,0xFF01,1136,0xFF01,1131,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = RTMS_EX_H("Project name",12,1823660133);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = loc5;
		RTAR(tr1,loc5);
		F850_6681(RTCW(loc1), tr1);
	}
	tr1 = RTOSCF(3458,F172_3458, (Current));
	tr2 = RTMS_EX_H("location",8,59511406);
	tr1 = F939_7325(RTCW(tr1), tr2);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1049,0xFF01,1136,0xFF01,1131,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = RTMS_EX_H("Location",8,52138606);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = loc6;
		RTAR(tr1,loc6);
		F850_6681(RTCW(loc1), tr1);
	}
	tr1 = RTOSCF(3459,F172_3459, (Current));
	tr2 = RTMS_EX_H("name",4,1851878757);
	tr1 = F939_7325(RTCW(tr1), tr2);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1049,0xFF01,1136,0xFF01,1131,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = RTMS_EX_H("C library name",14,1516624997);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = loc7;
		RTAR(tr1,loc7);
		F850_6681(RTCW(loc1), tr1);
	}
	tr1 = RTOSCF(3459,F172_3459, (Current));
	tr2 = RTMS_EX_H("c_header_location",17,403451502);
	tr1 = F939_7325(RTCW(tr1), tr2);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1049,0xFF01,1136,0xFF01,1131,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = RTMS_EX_H("C header location",17,370077038);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = loc8;
		RTAR(tr1,loc8);
		F850_6681(RTCW(loc1), tr1);
	}
	tr1 = RTOSCF(3459,F172_3459, (Current));
	tr2 = RTMS_EX_H("c_header",8,285057138);
	tr1 = F939_7325(RTCW(tr1), tr2);
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1049,0xFF01,1136,0xFF01,1131,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = RTMS_EX_H("C header ",9,205841696);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = loc9;
		RTAR(tr1,loc9);
		F850_6681(RTCW(loc1), tr1);
	}
	tr1 = RTOSCF(3459,F172_3459, (Current));
	tr2 = RTMS_EX_H("c_compile_options",17,1319005043);
	tr1 = F939_7325(RTCW(tr1), tr2);
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1049,0xFF01,1136,0xFF01,1131,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = RTMS_EX_H("C compile options ",18,1070678304);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = loc10;
		RTAR(tr1,loc10);
		F850_6681(RTCW(loc1), tr1);
	}
	tr1 = F171_3453(Current, loc1);
	F315_5026(RTCW(arg2), tr1);
	RTLE;
}

/* {WRAPC_WIZARD}.inline-agent#1 of c_library_page */
void F172_16596 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1049,0xFF01,0,0xFF01,938,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = arg1;
	RTAR(tr2,arg1);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,0,1049,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A136_54, (EIF_POINTER) _A136_54, (EIF_POINTER)(0),tr2, 1, 0);
	}
	F865_6724(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6042[Dtype(RTCW(tr1))-871])(tr1, NULL);
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	tr2 = RTMS_EX_H("name",4,1851878757);
	tr1 = F914_7115(RTCW(tr1), tr2);
	loc1 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc1))) {
		tb2 = F1129_9801(loc1);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = RTMS_EX_H("Invalid value for `name\'!",25,1415550497);
		F939_7364(RTCW(arg1), tr1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	tr2 = RTMS_EX_H("c_header_location",17,403451502);
	tb1 = F914_7121(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTMS_EX_H("Missing value for `c_header_location\'!",38,1001521185);
		F939_7364(RTCW(arg1), tr1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	tr2 = RTMS_EX_H("c_header",8,285057138);
	tb1 = F914_7121(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTMS_EX_H("Missing value for `c_header\'!",29,319349281);
		F939_7364(RTCW(arg1), tr1);
	}
	RTLE;
}

/* {WRAPC_WIZARD}.inline-agent#2 of c_library_page */
void F172_16597 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	tr2 = RTMS_EX_H("c_header_location",17,403451502);
	tr1 = F914_7115(RTCW(tr1), tr2);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		loc1 = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1132_9915(RTCW(loc1), loc3);
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			loc2 = F1132_9926(RTCW(loc1), tw1, ti4_1);
		} else {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			loc2 = F1132_9926(RTCW(loc1), tw1, ti4_1);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
		tr2 = F1134_10075(RTCW(loc1), ((EIF_INTEGER_32) 1L), loc2);
		tr3 = RTMS_EX_H("c_header_path",13,2038711400);
		F914_7124(RTCW(tr1), tr2, tr3);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		tr2 = F1134_10075(RTCW(loc1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)), ti4_1);
		tr3 = RTMS_EX_H("c_header",8,285057138);
		F914_7124(RTCW(tr1), tr2, tr3);
	}
	RTLE;
}

/* {WRAPC_WIZARD}.inline-agent#1 of library_page */
void F172_16598 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,loc1);
	RTLR(7,Current);
	RTLIU(8);
	
	RTGC;
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4935[Dtype(RTCW(arg1))-329])(arg1);
	loc3 = RTLNS(eif_new_type(1014, 0x01).id, 1014, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4918[Dtype(RTCW(arg2))-329])(arg2);
	F1015_8460(RTCW(loc3), tr1);
	tb1 = '\01';
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4918[Dtype(RTCW(arg2))-329])(arg2);
	tr2 = RTMS_EX_H("/",1,47);
	tb2 = F1129_9831(RTCW(tr1), tr2);
	if (!tb2) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4918[Dtype(RTCW(arg2))-329])(arg2);
		tr2 = RTMS_EX_H("\\",1,92);
		tb2 = F1129_9831(RTCW(tr1), tr2);
		tb1 = tb2;
	}
	if (tb1) {
	} else {
		tr1 = F1015_8475(RTCW(loc3));
		loc3 = (EIF_REFERENCE) tr1;
	}
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTOSCF(3455,F172_3455, (Current));
		tr1 = F360_5367(RTCW(tr1), tr2, loc3);
		loc1 = F1015_8499(RTCW(tr1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4919[Dtype(RTCW(arg2))-329])(arg2, loc1);
	} else {
		tb1 = F1129_9801(RTCW(loc2));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = F360_5367(RTCW(tr1), loc2, loc3);
			loc1 = F1015_8499(RTCW(tr1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4919[Dtype(RTCW(arg2))-329])(arg2, loc1);
		}
	}
	RTLE;
}

/* {WRAPC_WIZARD}.inline-agent#2 of library_page */
void F172_16599 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	tr2 = RTMS_EX_H("name",4,1851878757);
	tr1 = F914_7115(RTCW(tr1), tr2);
	loc1 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc1))) {
		tb2 = F1129_9801(loc1);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = RTMS_EX_H("Invalid value for `name\'!",25,1415550497);
		F939_7364(RTCW(arg1), tr1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	tr2 = RTMS_EX_H("location",8,59511406);
	tb1 = F914_7121(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTMS_EX_H("Missing value for `location\'!",29,57775393);
		F939_7364(RTCW(arg1), tr1);
	}
	RTLE;
}

void EIF_Minit136 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
