
#ifndef _C3_ev100_
#define _C3_ev100_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F136_2126_body(EIF_REFERENCE);
extern EIF_REFERENCE F136_2126(EIF_REFERENCE);
extern void EIF_Minit100(void);
extern long O2137[];

#ifdef __cplusplus
}
#endif

#endif
