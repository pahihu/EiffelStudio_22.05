
#ifndef _C3_ev103_
#define _C3_ev103_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F139_2137(EIF_REFERENCE);
extern void EIF_Minit103(void);
extern void F872_6758(EIF_REFERENCE);
extern long O2150[];

#ifdef __cplusplus
}
#endif

#endif
