
#ifndef _C3_th127_
#define _C3_th127_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F163_3352(EIF_REFERENCE);
extern void EIF_Minit127(void);

#ifdef __cplusplus
}
#endif

#endif
