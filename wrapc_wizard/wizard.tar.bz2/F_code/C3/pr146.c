/*
 * Code for class PROCESS_UNIX_OS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr146.h"
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F182_3624
static void inline_F182_3624 (EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	{
  int rc;
  rc = dup2(arg1, arg2);
  if (rc < 0) {
	    eraise(Strerror(errno), EN_SYS);
  }
}
	;
}
#define INLINE_F182_3624
#endif
#ifndef INLINE_F182_3625
static void inline_F182_3625 (EIF_INTEGER_32 arg1)
{
	{
	 int rc;
	  rc = close(arg1);
	  if (rc != 0) {
	    eraise(Strerror(errno), EN_SYS);
	  }
}
	;
}
#define INLINE_F182_3625
#endif
#ifndef INLINE_F182_3628
static void inline_F182_3628 (void)
{
	{
	setpgid (0, 0);
}
	;
}
#define INLINE_F182_3628
#endif
#ifndef INLINE_F182_3642
static void inline_F182_3642 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3)
{
	{
				  char ** arguments;
 				  arguments = (char **) arg1;
				  arguments[arg2] = (char *) arg3;
				}
	;
}
#define INLINE_F182_3642
#endif
#ifndef INLINE_F182_3640
static void inline_F182_3640 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_BOOLEAN arg4)
{
	{
				  int max_descriptors;
				  int k, rc;
  				  if (arg4 == EIF_TRUE) {
				    max_descriptors = getdtablesize();
					for (k = 3; k < max_descriptors; k++) {
					    rc = fcntl(k, F_SETFD, 1);
					    if (rc == -1 && errno != EBADF) {
						      eraise(Strerror(errno), EN_SYS);
					    }
			  	    }
				  }
				  if (arg3 == NULL) {
				    (void) execv((char *) arg1, (char **) arg2);
				  } else {
				    (void) execve((char *) arg1, (char **) arg2, (char **) arg3);
				  }
				  _exit(127);
				}
	;
}
#define INLINE_F182_3640
#endif
#ifndef INLINE_F182_3639
static void inline_F182_3639 (EIF_INTEGER_32* arg1)
{
	{
  pid_t pid;
  pid = fork();
  *arg1 = (EIF_INTEGER)pid;
}
	;
}
#define INLINE_F182_3639
#endif
#ifndef INLINE_F182_3635
static void inline_F182_3635 (EIF_POINTER arg1, EIF_POINTER* arg2)
{
	{
	  char *result;
	  result = (char *) malloc((unsigned) (strlen((char *) arg1) + 1));
	  if (result == NULL) {
    	enomem();
	  }
	  strcpy(result, arg1);
	  *arg2 = result;
	}
	;
}
#define INLINE_F182_3635
#endif
#ifndef INLINE_F182_3641
static void inline_F182_3641 (EIF_INTEGER_32 arg1, EIF_POINTER* arg2)
{
	{
	EIF_POINTER result;
	result = (EIF_POINTER) malloc((size_t) (arg1 * sizeof(char *)));
	if (result == NULL) {
		enomem();
	}
	*arg2 = result;
}
	;
}
#define INLINE_F182_3641
#endif
#ifndef INLINE_F182_3636
static void inline_F182_3636 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	{
  int rc;
  int fd[2];
  EIF_INTEGER * read_ptr;
  EIF_INTEGER * write_ptr;
  rc = pipe(fd);
  if (rc != 0) {
    eraise(Strerror(errno), EN_SYS);
  }
  read_ptr = (EIF_INTEGER *) arg1;
  write_ptr = (EIF_INTEGER *) arg2;
  *read_ptr = fd[0];
  *write_ptr = fd[1];
}
	;
}
#define INLINE_F182_3636
#endif
#ifndef INLINE_F182_3643
static void inline_F182_3643 (EIF_INTEGER_32 arg1)
{
	{
	pid_t pgid = getpgid (arg1);
	tcsetpgrp (1, pgid);
	tcsetpgrp (2, pgid);
}
	;
}
#define INLINE_F182_3643
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PROCESS_UNIX_OS}.duplicate_file_descriptor */
void F182_3624 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	inline_F182_3624 ((EIF_INTEGER_32) arg1, (EIF_INTEGER_32) arg2);
}

/* {PROCESS_UNIX_OS}.close_file_descriptor */
void F182_3625 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	inline_F182_3625 ((EIF_INTEGER_32) arg1);
}

/* {PROCESS_UNIX_OS}.fork_process */
EIF_INTEGER_32 F182_3627 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F182_3632(Current);
}

/* {PROCESS_UNIX_OS}.new_process_group */
void F182_3628 (EIF_REFERENCE Current)
{
	GTCX
	
	
	inline_F182_3628 ();
}

/* {PROCESS_UNIX_OS}.exec_process */
void F182_3629 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3, EIF_POINTER arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	loc2 = F700_6214(RTCW(arg2));
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_1_);
	loc4 = F182_3634(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
	loc5 = RTLNS(eif_new_type(373, 0x01).id, 373, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F374_5528(RTCW(loc5), ((EIF_INTEGER_32) 0L));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = F700_6207(RTCW(arg2), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 + loc1) - ((EIF_INTEGER_32) 1L)));
		F374_5542(RTCW(loc5), tr1);
		tp1 = F374_5534(RTCW(loc5));
		tp1 = F182_3633(Current, tp1);
		inline_F182_3642(loc4, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)), tp1);
		loc1++;
	}
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	inline_F182_3642(loc4, loc2, tp2);
	loc5 = RTLNS(eif_new_type(373, 0x01).id, 373, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F374_5527(RTCW(loc5), arg1);
	tp1 = F374_5534(RTCW(loc5));
	inline_F182_3640(tp1, loc4, arg4, arg3);
	RTLE;
}

/* {PROCESS_UNIX_OS}.unix_fork_process */
EIF_INTEGER_32 F182_3632 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	inline_F182_3639((EIF_INTEGER_32 *) &(Result));
	return Result;
}

/* {PROCESS_UNIX_OS}.str_dup */
EIF_POINTER F182_3633 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	inline_F182_3635(arg1, (EIF_POINTER *) &(Result));
	return Result;
}

/* {PROCESS_UNIX_OS}.unix_allocate_arg_memory */
EIF_POINTER F182_3634 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	inline_F182_3641(arg1, (EIF_POINTER *) &(Result));
	return Result;
}

/* {PROCESS_UNIX_OS}.c_str_dup */
void F182_3635 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER* arg2)
{
	GTCX
	
	
	inline_F182_3635 ((EIF_POINTER) arg1, (EIF_POINTER*) arg2);
}

/* {PROCESS_UNIX_OS}.unix_pipe */
void F182_3636 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F182_3636 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {PROCESS_UNIX_OS}.c_unix_fork_process */
void F182_3639 (EIF_REFERENCE Current, EIF_INTEGER_32* arg1)
{
	GTCX
	
	
	inline_F182_3639 ((EIF_INTEGER_32*) arg1);
}

/* {PROCESS_UNIX_OS}.unix_exec_process */
void F182_3640 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_BOOLEAN arg4)
{
	GTCX
	
	
	inline_F182_3640 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3, (EIF_BOOLEAN) arg4);
}

/* {PROCESS_UNIX_OS}.c_unix_allocate_arg_memory */
void F182_3641 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_POINTER* arg2)
{
	GTCX
	
	
	inline_F182_3641 ((EIF_INTEGER_32) arg1, (EIF_POINTER*) arg2);
}

/* {PROCESS_UNIX_OS}.unix_set_arg_value */
void F182_3642 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3)
{
	GTCX
	
	
	inline_F182_3642 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_POINTER) arg3);
}

/* {PROCESS_UNIX_OS}.attach_terminals */
void F182_3643 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	inline_F182_3643 ((EIF_INTEGER_32) arg1);
}

void EIF_Minit146 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
