
#ifndef _C3_un147_
#define _C3_un147_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F183_3644(EIF_REFERENCE);
extern void EIF_Minit147(void);
extern void F1000_7777(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
