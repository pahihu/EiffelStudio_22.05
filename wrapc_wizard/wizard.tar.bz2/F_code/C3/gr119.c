/*
 * Code for class GRAPHICAL_WIZARD_STYLER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gr119.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GRAPHICAL_WIZARD_STYLER}.apply_title_style */
void F155_3281 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1198_10767(RTCW(arg1));
	F1238_11363(RTCW(arg1));
	tr1 = RTOSCF(1028,F57_1028, (RTCV(RTOSCF(3291,F155_3291, (Current)))));
	F1186_10676(RTCW(arg1), tr1);
	tr1 = RTOSCF(3297,F155_3297, (Current));
	F1199_10770(RTCW(arg1), tr1);
	RTLE;
}

/* {GRAPHICAL_WIZARD_STYLER}.apply_subtitle_style */
void F155_3282 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1198_10767(RTCW(arg1));
	F1238_11363(RTCW(arg1));
	tr1 = RTOSCF(1028,F57_1028, (RTCV(RTOSCF(3291,F155_3291, (Current)))));
	F1186_10676(RTCW(arg1), tr1);
	tr1 = RTOSCF(3298,F155_3298, (Current));
	F1199_10770(RTCW(arg1), tr1);
	RTLE;
}

/* {GRAPHICAL_WIZARD_STYLER}.apply_text_style */
void F155_3283 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1197, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		F1198_10767(loc1);
		loc2 = arg1;
		loc2 = RTRV(eif_new_type(1237, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			F1238_11362(loc2);
		}
	}
	tr1 = RTOSCF(1028,F57_1028, (RTCV(RTOSCF(3291,F155_3291, (Current)))));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8881[Dtype(RTCW(arg1))-1201])(arg1, tr1);
	loc3 = arg1;
	loc3 = RTRV(eif_new_type(1198, 0x01),loc3);
	if (EIF_TEST(loc3)) {
		tr1 = RTOSCF(3300,F155_3300, (Current));
		F1199_10770(loc3, tr1);
	}
	RTLE;
}

/* {GRAPHICAL_WIZARD_STYLER}.apply_fixed_size_text_style */
void F155_3284 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	F155_3283(Current, arg1);
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1198, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = RTOSCF(3301,F155_3301, (Current));
		F1199_10770(loc1, tr1);
	}
	RTLE;
}

/* {GRAPHICAL_WIZARD_STYLER}.apply_link_style */
void F155_3285 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F155_3283(Current, arg1);
	tr1 = RTOSCF(1033,F57_1033, (RTCV(RTOSCF(3291,F155_3291, (Current)))));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8881[Dtype(RTCW(arg1))-1201])(arg1, tr1);
	RTLE;
}

/* {GRAPHICAL_WIZARD_STYLER}.apply_section_style */
void F155_3287 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	F155_3283(Current, arg1);
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1198, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = RTOSCF(3299,F155_3299, (Current));
		F1199_10770(loc1, tr1);
	}
	RTLE;
}

/* {GRAPHICAL_WIZARD_STYLER}.apply_report_style */
void F155_3288 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,Current);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1197, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		F1198_10767(loc1);
		loc2 = arg1;
		loc2 = RTRV(eif_new_type(1237, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			F1238_11362(loc2);
		}
	}
	loc3 = arg1;
	loc3 = RTRV(eif_new_type(1198, 0x01),loc3);
	if (EIF_TEST(loc3)) {
		tr1 = RTOSCF(3303,F155_3303, (Current));
		F1199_10770(loc3, tr1);
	}
	RTLE;
}

/* {GRAPHICAL_WIZARD_STYLER}.apply_field_description_style */
void F155_3289 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	F155_3283(Current, arg1);
	tr1 = RTOSCF(1032,F57_1032, (RTCV(RTOSCF(3291,F155_3291, (Current)))));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8881[Dtype(RTCW(arg1))-1201])(arg1, tr1);
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1198, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = RTOSCF(3302,F155_3302, (Current));
		F1199_10770(loc1, tr1);
	}
	RTLE;
}

/* {GRAPHICAL_WIZARD_STYLER}.apply_button_style */
void F155_3290 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = RTOSCF(3267,F154_3267, (Current));
	F1212_11012(RTCW(arg1), ti4_1);
	ti4_1 = RTOSCF(3268,F154_3268, (Current));
	F1212_11013(RTCW(arg1), ti4_1);
	RTLE;
}

/* {GRAPHICAL_WIZARD_STYLER}.colors */
static EIF_REFERENCE F155_3291_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3291);
#define Result RTOSR(3291)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(56, 0x01).id, 56, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) RTCCL(tr1);
	RTOSE (3291);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F155_3291 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3291,F155_3291_body,(Current));
}

/* {GRAPHICAL_WIZARD_STYLER}.color_light_green */
static EIF_REFERENCE F155_3293_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3293);
#define Result RTOSR(3293)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1174, 0x01).id, 1174, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1175_10480(RTCW(tr1), ((EIF_INTEGER_32) 150L), ((EIF_INTEGER_32) 255L), ((EIF_INTEGER_32) 150L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3293);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F155_3293 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3293,F155_3293_body,(Current));
}

/* {GRAPHICAL_WIZARD_STYLER}.color_light_orange */
static EIF_REFERENCE F155_3294_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3294);
#define Result RTOSR(3294)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1174, 0x01).id, 1174, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1175_10480(RTCW(tr1), ((EIF_INTEGER_32) 255L), ((EIF_INTEGER_32) 210L), ((EIF_INTEGER_32) 50L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3294);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F155_3294 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3294,F155_3294_body,(Current));
}

/* {GRAPHICAL_WIZARD_STYLER}.color_light_red */
static EIF_REFERENCE F155_3295_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3295);
#define Result RTOSR(3295)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1174, 0x01).id, 1174, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1175_10480(RTCW(tr1), ((EIF_INTEGER_32) 255L), ((EIF_INTEGER_32) 210L), ((EIF_INTEGER_32) 210L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3295);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F155_3295 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3295,F155_3295_body,(Current));
}

/* {GRAPHICAL_WIZARD_STYLER}.title_font */
static EIF_REFERENCE F155_3297_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3297);
#define Result RTOSR(3297)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1176, 0x01).id, 1176, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1168_10363(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F1177_10544(RTCW(Result), ((EIF_INTEGER_32) 3L));
	F1177_10548(RTCW(Result), ((EIF_INTEGER_32) 10L));
	F1177_10545(RTCW(Result), ((EIF_INTEGER_32) 8L));
	RTOSE (3297);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F155_3297 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3297,F155_3297_body,(Current));
}

/* {GRAPHICAL_WIZARD_STYLER}.subtitle_font */
static EIF_REFERENCE F155_3298_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3298);
#define Result RTOSR(3298)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1176, 0x01).id, 1176, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1168_10363(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F1177_10548(RTCW(Result), ((EIF_INTEGER_32) 9L));
	RTOSE (3298);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F155_3298 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3298,F155_3298_body,(Current));
}

/* {GRAPHICAL_WIZARD_STYLER}.section_font */
static EIF_REFERENCE F155_3299_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3299);
#define Result RTOSR(3299)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1176, 0x01).id, 1176, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1168_10363(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F1177_10544(RTCW(Result), ((EIF_INTEGER_32) 3L));
	F1177_10548(RTCW(Result), ((EIF_INTEGER_32) 12L));
	F1177_10545(RTCW(Result), ((EIF_INTEGER_32) 8L));
	RTOSE (3299);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F155_3299 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3299,F155_3299_body,(Current));
}

/* {GRAPHICAL_WIZARD_STYLER}.text_font */
static EIF_REFERENCE F155_3300_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3300);
#define Result RTOSR(3300)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1176, 0x01).id, 1176, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1168_10363(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F1177_10548(RTCW(Result), ((EIF_INTEGER_32) 9L));
	RTOSE (3300);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F155_3300 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3300,F155_3300_body,(Current));
}

/* {GRAPHICAL_WIZARD_STYLER}.fixed_size_text_font */
static EIF_REFERENCE F155_3301_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3301);
#define Result RTOSR(3301)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1176, 0x01).id, 1176, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1168_10363(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F1177_10548(RTCW(Result), ((EIF_INTEGER_32) 9L));
	F1177_10544(RTCW(Result), ((EIF_INTEGER_32) 4L));
	RTOSE (3301);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F155_3301 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3301,F155_3301_body,(Current));
}

/* {GRAPHICAL_WIZARD_STYLER}.field_description_font */
static EIF_REFERENCE F155_3302_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3302);
#define Result RTOSR(3302)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1176, 0x01).id, 1176, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1168_10363(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F1177_10546(RTCW(Result), ((EIF_INTEGER_32) 11L));
	F1177_10548(RTCW(Result), ((EIF_INTEGER_32) 9L));
	RTOSE (3302);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F155_3302 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3302,F155_3302_body,(Current));
}

/* {GRAPHICAL_WIZARD_STYLER}.report_font */
static EIF_REFERENCE F155_3303_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3303);
#define Result RTOSR(3303)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1176, 0x01).id, 1176, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1168_10363(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F1177_10548(RTCW(Result), ((EIF_INTEGER_32) 9L));
	RTOSE (3303);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F155_3303 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3303,F155_3303_body,(Current));
}

void EIF_Minit119 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
