
#ifndef _C3_ev106_
#define _C3_ev106_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F142_2144(EIF_REFERENCE);
extern void EIF_Minit106(void);
extern void F872_6758(EIF_REFERENCE);
extern long O2156[];

#ifdef __cplusplus
}
#endif

#endif
