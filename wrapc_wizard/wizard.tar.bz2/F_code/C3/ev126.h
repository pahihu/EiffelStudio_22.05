
#ifndef _C3_ev126_
#define _C3_ev126_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F162_3344(EIF_REFERENCE);
extern void EIF_Minit126(void);
extern void F872_6758(EIF_REFERENCE);
extern long O3352[];

#ifdef __cplusplus
}
#endif

#endif
