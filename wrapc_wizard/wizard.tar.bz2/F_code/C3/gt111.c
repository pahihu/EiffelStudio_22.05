/*
 * Code for class GTK3
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt111.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F147_2936
static void inline_F147_2936 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return gtk_widget_set_halign ((GtkWidget *)arg1, (GtkAlign)arg2)
	;
}
#define INLINE_F147_2936
#endif
#ifndef INLINE_F147_2939
static void inline_F147_2939 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return gtk_widget_set_valign ((GtkWidget *)arg1, (GtkAlign)arg2)
	;
}
#define INLINE_F147_2939
#endif
#ifndef INLINE_F147_2941
static void inline_F147_2941 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_widget_set_margin_start ((GtkWidget *)arg1, (gint)arg2)
	;
}
#define INLINE_F147_2941
#endif
#ifndef INLINE_F147_2943
static void inline_F147_2943 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_widget_set_margin_end ((GtkWidget *)arg1, (gint)arg2)
	;
}
#define INLINE_F147_2943
#endif
#ifndef INLINE_F147_2948
static void inline_F147_2948 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_widget_set_visual ((GtkWidget *)arg1, (GdkVisual *)arg2)
	;
}
#define INLINE_F147_2948
#endif
#ifndef INLINE_F147_2949
static EIF_POINTER inline_F147_2949 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F147_2949
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK3}.gtk_widget_get_preferred_size */
void F147_2930 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	
	gtk_widget_get_preferred_size((GtkWidget*) arg1, (GtkRequisition*) arg2, (GtkRequisition*) arg3);
	
}

/* {GTK3}.gtk_widget_set_halign */
void F147_2936 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	inline_F147_2936 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
}

/* {GTK3}.gtk_widget_set_valign */
void F147_2939 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	inline_F147_2939 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
}

/* {GTK3}.gtk_widget_set_margin_start */
void F147_2941 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	inline_F147_2941 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
}

/* {GTK3}.gtk_widget_set_margin_end */
void F147_2943 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	inline_F147_2943 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
}

/* {GTK3}.gtk_widget_set_visual */
void F147_2948 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F147_2948 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {GTK3}.gtk_box_new */
EIF_POINTER F147_2949 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F147_2949 ((EIF_NATURAL_8) arg1, (EIF_INTEGER_32) arg2);
	return Result;
}

/* {GTK3}.gtk_widget_get_style_context */
EIF_POINTER F147_2959 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) arg1);
	
	return Result;
}

void EIF_Minit111 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
