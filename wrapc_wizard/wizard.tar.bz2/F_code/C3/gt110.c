/*
 * Code for class GTK2
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt110.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F146_2513
static EIF_POINTER inline_F146_2513 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_BACKGROUND_COLOR)
	;
}
#define INLINE_F146_2513
#endif
#ifndef INLINE_F146_2514
static EIF_POINTER inline_F146_2514 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_COLOR)
	;
}
#define INLINE_F146_2514
#endif
#ifndef INLINE_F146_2515
static EIF_POINTER inline_F146_2515 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_FONT)
	;
}
#define INLINE_F146_2515
#endif
#ifndef INLINE_F146_2535
static int inline_F146_2535 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	return gtk_style_context_lookup_color((GtkStyleContext*) arg1, (gchar*) arg2, (GdkRGBA*) arg3);
	;
}
#define INLINE_F146_2535
#endif
#ifndef INLINE_F146_2536
static void inline_F146_2536 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	gtk_style_context_get (arg1, arg2, arg3, arg4, NULL)
	;
}
#define INLINE_F146_2536
#endif
#ifndef INLINE_F146_2541
static void inline_F146_2541 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_window_set_accept_focus((GtkWindow*)arg1, (gboolean) arg2)
	;
}
#define INLINE_F146_2541
#endif
#ifndef INLINE_F146_2560
static void inline_F146_2560 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_window_set_icon ((GtkWindow*) arg1, (GdkPixbuf*) arg2)
	;
}
#define INLINE_F146_2560
#endif
#ifndef INLINE_F146_2575
static EIF_POINTER inline_F146_2575 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_8 arg3, EIF_INTEGER_8 arg4, EIF_POINTER arg5)
{
	return (EIF_POINTER) (gtk_icon_theme_load_icon ((GtkIconTheme *)arg1,
                          (const gchar *)arg2,
                          (gint)arg3,
                          (GtkIconLookupFlags)arg4,
                          (GError **)arg5))
	;
}
#define INLINE_F146_2575
#endif
#ifndef INLINE_F146_2576
static EIF_POINTER inline_F146_2576 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_icon_theme_get_for_screen ((GdkScreen*) arg1))
	;
}
#define INLINE_F146_2576
#endif
#ifndef INLINE_F146_2577
static EIF_POINTER inline_F146_2577 (void)
{
	return gtk_icon_theme_get_default ();
	;
}
#define INLINE_F146_2577
#endif
#ifndef INLINE_F146_2611
static int inline_F146_2611 (EIF_POINTER arg1)
{
	return (int) (gtk_widget_has_screen ((GtkWidget*) arg1))
	;
}
#define INLINE_F146_2611
#endif
#ifndef INLINE_F146_2612
static EIF_POINTER inline_F146_2612 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_widget_get_screen ((GtkWidget*) arg1))
	;
}
#define INLINE_F146_2612
#endif
#ifndef INLINE_F146_2614
static void inline_F146_2614 (EIF_POINTER arg1)
{
	gtk_widget_destroy((GtkWidget*) arg1)
	;
}
#define INLINE_F146_2614
#endif
#ifndef INLINE_F146_2635
static void inline_F146_2635 (EIF_POINTER arg1)
{
	g_list_foreach ((GList*) arg1, (GFunc) gtk_tree_path_free, NULL)
	;
}
#define INLINE_F146_2635
#endif
#ifndef INLINE_F146_2653
static void inline_F146_2653 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	gtk_widget_set_size_request ((GtkWidget*) arg1, (gint) arg2, (gint) arg3)
	;
}
#define INLINE_F146_2653
#endif
#ifndef INLINE_F146_2652
static void inline_F146_2652 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	gtk_widget_get_size_request ((GtkWidget*) arg1, (gint*) arg2, (gint*) arg3)
	;
}
#define INLINE_F146_2652
#endif
#ifndef INLINE_F146_2654
static void inline_F146_2654 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_widget_size_allocate ((GtkWidget*) arg1, (GtkAllocation*) arg2)
	;
}
#define INLINE_F146_2654
#endif
#ifndef INLINE_F146_2656
static void inline_F146_2656 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	gtk_widget_style_get ((GtkWidget*) arg1, (gchar*) arg2, (gint*) arg3, NULL);
	;
}
#define INLINE_F146_2656
#endif
#ifndef INLINE_F146_2694
static void inline_F146_2694 (EIF_POINTER arg1)
{
	gtk_tree_path_free ((GtkTreePath*) arg1)
	;
}
#define INLINE_F146_2694
#endif
#ifndef INLINE_F146_2695
static int inline_F146_2695 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4, EIF_POINTER arg5, EIF_POINTER arg6, EIF_POINTER arg7)
{
	return (int) (gtk_tree_view_get_path_at_pos ((GtkTreeView*) arg1, (gint) arg2, (gint) arg3, (GtkTreePath**) arg4, (GtkTreeViewColumn**) arg5, (gint*) arg6, (gint*) arg7))
	;
}
#define INLINE_F146_2695
#endif
#ifndef INLINE_F146_2701
static void inline_F146_2701 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_tree_view_set_headers_visible ((GtkTreeView*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F146_2701
#endif
#ifndef INLINE_F146_2710
static EIF_POINTER inline_F146_2710 (EIF_POINTER arg1, EIF_POINTER* arg2)
{
	return (EIF_POINTER) (gtk_tree_selection_get_selected_rows ((GtkTreeSelection*) arg1, (GtkTreeModel**) arg2))
	;
}
#define INLINE_F146_2710
#endif
#ifndef INLINE_F146_2715
static void inline_F146_2715 (EIF_POINTER arg1)
{
	gtk_tree_selection_unselect_all ((GtkTreeSelection*) arg1)
	;
}
#define INLINE_F146_2715
#endif
#ifndef INLINE_F146_2717
static int inline_F146_2717 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	return (int) (gtk_tree_model_get_iter ((GtkTreeModel*) arg1, (GtkTreeIter*) arg2, (GtkTreePath*) arg3))
	;
}
#define INLINE_F146_2717
#endif
#ifndef INLINE_F146_2719
static void inline_F146_2719 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	gtk_tree_model_get_value ((GtkTreeModel*) arg1, (GtkTreeIter*) arg2, (gint) arg3, (GValue*) arg4)
	;
}
#define INLINE_F146_2719
#endif
#ifndef INLINE_F146_2724
static EIF_POINTER inline_F146_2724 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_tree_view_get_column ((GtkTreeView*) arg1, (gint) arg2))
	;
}
#define INLINE_F146_2724
#endif
#ifndef INLINE_F146_2727
static EIF_POINTER inline_F146_2727 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_tree_view_get_selection ((GtkTreeView*) arg1))
	;
}
#define INLINE_F146_2727
#endif
#ifndef INLINE_F146_2734
static void inline_F146_2734 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_tree_view_column_set_resizable ((GtkTreeViewColumn*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F146_2734
#endif
#ifndef INLINE_F146_2743
static void inline_F146_2743 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4)
{
	gtk_tree_view_column_add_attribute ((GtkTreeViewColumn*) arg1, (GtkCellRenderer*) arg2, (gchar*) arg3, (gint) arg4)
	;
}
#define INLINE_F146_2743
#endif
#ifndef INLINE_F146_2744
static EIF_POINTER inline_F146_2744 (void)
{
	return (EIF_POINTER) (gtk_cell_renderer_text_new())
	;
}
#define INLINE_F146_2744
#endif
#ifndef INLINE_F146_2745
static EIF_POINTER inline_F146_2745 (void)
{
	return (EIF_POINTER) (gtk_cell_renderer_pixbuf_new())
	;
}
#define INLINE_F146_2745
#endif
#ifndef INLINE_F146_2749
static EIF_POINTER inline_F146_2749 (void)
{
	return (EIF_POINTER) (gtk_cell_renderer_toggle_new())
	;
}
#define INLINE_F146_2749
#endif
#ifndef INLINE_F146_2750
static void inline_F146_2750 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	gtk_tree_view_insert_column ((GtkTreeView*) arg1, (GtkTreeViewColumn*) arg2, (gint) arg3)
	;
}
#define INLINE_F146_2750
#endif
#ifndef INLINE_F146_2753
static EIF_POINTER inline_F146_2753 (void)
{
	return (EIF_POINTER) (gtk_tree_view_column_new())
	;
}
#define INLINE_F146_2753
#endif
#ifndef INLINE_F146_2755
static void inline_F146_2755 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	gtk_tree_view_column_pack_start ((GtkTreeViewColumn*) arg1, (GtkCellRenderer*) arg2, (gboolean) arg3)
	;
}
#define INLINE_F146_2755
#endif
#ifndef INLINE_F146_2756
static void inline_F146_2756 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	gtk_tree_view_column_pack_end ((GtkTreeViewColumn*) arg1, (GtkCellRenderer*) arg2, (gboolean) arg3)
	;
}
#define INLINE_F146_2756
#endif
#ifndef INLINE_F146_2763
static void inline_F146_2763 (EIF_POINTER arg1)
{
	g_value_init ((GValue*) arg1, G_TYPE_STRING)
	;
}
#define INLINE_F146_2763
#endif
#ifndef INLINE_F146_2767
static void inline_F146_2767 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	g_value_set_boolean ((GValue*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F146_2767
#endif
#ifndef INLINE_F146_2768
static int inline_F146_2768 (EIF_POINTER arg1)
{
	return (int) (g_value_get_boolean ((GValue*) arg1))
	;
}
#define INLINE_F146_2768
#endif
#ifndef INLINE_F146_2773
static void inline_F146_2773 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	g_value_take_string ((GValue*) arg1, (gchar*) arg2)
	;
}
#define INLINE_F146_2773
#endif
#ifndef INLINE_F146_2777
static EIF_POINTER inline_F146_2777 (EIF_INTEGER_32 arg1, EIF_POINTER arg2)
{
	return (EIF_POINTER) (gtk_list_store_newv ((gint) arg1, (GType*) arg2))
	;
}
#define INLINE_F146_2777
#endif
#ifndef INLINE_F146_2781
static void inline_F146_2781 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	gtk_list_store_insert ((GtkListStore*) arg1, (GtkTreeIter*) arg2, (gint) arg3)
	;
}
#define INLINE_F146_2781
#endif
#ifndef INLINE_F146_2783
static void inline_F146_2783 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_list_store_remove ((GtkListStore*) arg1, (GtkTreeIter*) arg2)
	;
}
#define INLINE_F146_2783
#endif
#ifndef INLINE_F146_2785
static void inline_F146_2785 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	gtk_list_store_set_value ((GtkListStore*) arg1, (GtkTreeIter*) arg2, (gint) arg3, (GValue*) arg4)
	;
}
#define INLINE_F146_2785
#endif
#ifndef INLINE_F146_2787
static void inline_F146_2787 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	gtk_list_store_set ((GtkListStore*) arg1, (GtkTreeIter*) arg2, (gint) arg3, (GdkPixbuf*) arg4, -1)
	;
}
#define INLINE_F146_2787
#endif
#ifndef INLINE_F146_2797
static EIF_POINTER inline_F146_2797 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (((GValue*)arg1 + (int)(arg2)))
	;
}
#define INLINE_F146_2797
#endif
#ifndef INLINE_F146_2818
static void inline_F146_2818 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	g_object_set ((gpointer) arg1, (gchar*) arg2, (gpointer) arg3, NULL)
	;
}
#define INLINE_F146_2818
#endif
#ifndef INLINE_F146_2819
static void inline_F146_2819 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	return g_object_set ((gpointer) arg1, (gchar*) arg2, (gchar*) arg3, NULL);
	;
}
#define INLINE_F146_2819
#endif
#ifndef INLINE_F146_2820
static void inline_F146_2820 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER* arg3)
{
	return g_object_get ((gpointer) arg1, (gchar*) arg2, (gchar**) arg3, NULL);
	;
}
#define INLINE_F146_2820
#endif
#ifndef INLINE_F146_2822
static EIF_INTEGER_32 inline_F146_2822 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gint v;
g_object_get ((gpointer) arg1, (const gchar *) arg2, &v, NULL);
return (EIF_INTEGER) v;
	;
}
#define INLINE_F146_2822
#endif
#ifndef INLINE_F146_2826
static void inline_F146_2826 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	g_object_set((gpointer) arg1, (gchar*) arg2, arg3 ? TRUE : FALSE, NULL)
	;
}
#define INLINE_F146_2826
#endif
#ifndef INLINE_F146_2830
static void inline_F146_2830 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	g_signal_handler_disconnect ((gpointer) arg1, (gulong) arg2)
	;
}
#define INLINE_F146_2830
#endif
#ifndef INLINE_F146_2900
static EIF_POINTER inline_F146_2900 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	return (EIF_POINTER) (gtk_dialog_add_button ((GtkDialog*) arg1, (gchar*) arg2, (gint) arg3))
	;
}
#define INLINE_F146_2900
#endif
#ifndef INLINE_F146_2902
static void inline_F146_2902 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_dialog_set_default_response ((GtkDialog*) arg1, (gint) arg2)
	;
}
#define INLINE_F146_2902
#endif
#ifndef INLINE_F146_2904
static void inline_F146_2904 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_filter_add_pattern ((GtkFileFilter*) arg1, (gchar*) arg2)
	;
}
#define INLINE_F146_2904
#endif
#ifndef INLINE_F146_2905
static void inline_F146_2905 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_filter_set_name ((GtkFileFilter*) arg1, (gchar*) arg2)
	;
}
#define INLINE_F146_2905
#endif
#ifndef INLINE_F146_2907
static void inline_F146_2907 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_chooser_add_filter ((GtkFileChooser*) arg1, (GtkFileFilter*) arg2)
	;
}
#define INLINE_F146_2907
#endif
#ifndef INLINE_F146_2908
static void inline_F146_2908 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_chooser_remove_filter ((GtkFileChooser*) arg1, (GtkFileFilter*) arg2)
	;
}
#define INLINE_F146_2908
#endif
#ifndef INLINE_F146_2916
static EIF_POINTER inline_F146_2916 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	return (EIF_POINTER) (gtk_file_chooser_dialog_new ((gchar*) arg1, (GtkWindow*) arg2, (GtkFileChooserAction) arg3, NULL, NULL))
	;
}
#define INLINE_F146_2916
#endif
#ifndef INLINE_F146_2918
static EIF_POINTER inline_F146_2918 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_file_chooser_get_filename ((GtkFileChooser*) arg1))
	;
}
#define INLINE_F146_2918
#endif
#ifndef INLINE_F146_2919
static EIF_POINTER inline_F146_2919 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_file_chooser_get_filenames ((GtkFileChooser*) arg1))
	;
}
#define INLINE_F146_2919
#endif
#ifndef INLINE_F146_2920
static void inline_F146_2920 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_chooser_set_filename ((GtkFileChooser*) arg1, (gchar*) arg2)
	;
}
#define INLINE_F146_2920
#endif
#ifndef INLINE_F146_2921
static void inline_F146_2921 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_file_chooser_set_local_only ((GtkFileChooser*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F146_2921
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK2}.gtk_style_property_background_color */
EIF_POINTER F146_2513 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2513 ();
	return Result;
}

/* {GTK2}.gtk_style_property_color */
EIF_POINTER F146_2514 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2514 ();
	return Result;
}

/* {GTK2}.gtk_style_property_font */
EIF_POINTER F146_2515 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2515 ();
	return Result;
}

/* {GTK2}.gtk_style_context_add_provider */
void F146_2520 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_NATURAL_32 arg3)
{
	GTCX
	
	gtk_style_context_add_provider((GtkStyleContext*) arg1, (GtkStyleProvider*) arg2, (guint) arg3);
	
}

/* {GTK2}.gtk_style_context_lookup_color */
EIF_BOOLEAN F146_2535 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F146_2535 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3));
	return Result;
}

/* {GTK2}.gtk_style_context_get */
void F146_2536 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	GTCX
	
	
	inline_F146_2536 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_POINTER) arg3, (EIF_POINTER) arg4);
}

/* {GTK2}.gtk_window_set_accept_focus */
void F146_2541 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	
	inline_F146_2541 ((EIF_POINTER) arg1, (EIF_BOOLEAN) arg2);
}

/* {GTK2}.gtk_window_get_focus */
EIF_POINTER F146_2542 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_window_get_focus((GtkWindow*) arg1);
	
	return Result;
}

/* {GTK2}.gtk_window_get_position */
void F146_2543 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	
	gtk_window_get_position((GtkWindow*) arg1, (gint*) arg2, (gint*) arg3);
	
}

/* {GTK2}.gtk_window_get_size */
void F146_2544 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	
	gtk_window_get_size((GtkWindow*) arg1, (gint*) arg2, (gint*) arg3);
	
}

/* {GTK2}.gtk_window_move */
void F146_2546 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	gtk_window_move((GtkWindow*) arg1, (gint) arg2, (gint) arg3);
	
}

/* {GTK2}.gtk_window_close */
void F146_2547 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_window_close((GtkWindow*) arg1);
	
}

/* {GTK2}.gtk_window_is_active */
EIF_BOOLEAN F146_2549 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_window_is_active((GtkWindow*) arg1));
	
	return Result;
}

/* {GTK2}.gtk_window_resize */
void F146_2550 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	gtk_window_resize((GtkWindow*) arg1, (gint) arg2, (gint) arg3);
	
}

/* {GTK2}.gtk_window_deiconify */
void F146_2553 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_window_deiconify((GtkWindow*) arg1);
	
}

/* {GTK2}.gtk_window_unmaximize */
void F146_2557 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_window_unmaximize((GtkWindow*) arg1);
	
}

/* {GTK2}.gtk_window_set_icon */
void F146_2560 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F146_2560 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {GTK2}.gtk_win_pos_center_on_parent_enum */
EIF_INTEGER_32 F146_2561 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_WIN_POS_CENTER_ON_PARENT;
	return Result;
}

/* {GTK2}.gtk_event_box_new */
EIF_POINTER F146_2562 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_event_box_new();
	
	return Result;
}

/* {GTK2}.gtk_is_event_box */
EIF_BOOLEAN F146_2563 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(GTK_IS_EVENT_BOX((arg1)));
	return Result;
}

/* {GTK2}.gtk_event_box_set_visible_window */
void F146_2564 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	gtk_event_box_set_visible_window((GtkEventBox*) arg1, (gboolean) arg2);
	
}

/* {GTK2}.gtk_orientable_set_orientation */
void F146_2566 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_NATURAL_8 arg2)
{
	GTCX
	
	gtk_orientable_set_orientation((GtkOrientable*) arg1, (GtkOrientation) arg2);
	
}

/* {GTK2}.gtk_layout_new */
EIF_POINTER F146_2567 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_layout_new((GtkAdjustment*) arg1, (GtkAdjustment*) arg2);
	
	return Result;
}

/* {GTK2}.gtk_layout_set_size */
void F146_2570 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	gtk_layout_set_size((GtkLayout*) arg1, (guint) arg2, (guint) arg3);
	
}

/* {GTK2}.gtk_icon_theme_load_icon */
EIF_POINTER F146_2575 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_8 arg3, EIF_INTEGER_8 arg4, EIF_POINTER arg5)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2575 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_8) arg3, (EIF_INTEGER_8) arg4, (EIF_POINTER) arg5);
	return Result;
}

/* {GTK2}.gtk_icon_theme_get_for_screen */
EIF_POINTER F146_2576 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2576 ((EIF_POINTER) arg1);
	return Result;
}

/* {GTK2}.gtk_icon_theme_get_default */
EIF_POINTER F146_2577 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2577 ();
	return Result;
}

/* {GTK2}.gtk_im_context_simple_new */
EIF_POINTER F146_2594 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_im_context_simple_new();
	
	return Result;
}

/* {GTK2}.gtk_im_context_reset */
void F146_2595 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_im_context_reset((GtkIMContext*) arg1);
	
}

/* {GTK2}.gtk_im_context_focus_in */
void F146_2596 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	gtk_im_context_focus_in((GtkIMContext*) arg1);
	
}

/* {GTK2}.gtk_im_context_filter_keypress */
EIF_BOOLEAN F146_2598 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_im_context_filter_keypress((GtkIMContext*) arg1, (GdkEventKey*) arg2));
	
	return Result;
}

/* {GTK2}.gtk_im_context_set_client_window */
void F146_2599 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_im_context_set_client_window((GtkIMContext*) arg1, (GdkWindow*) arg2);
	
}

/* {GTK2}.events_pending */
EIF_BOOLEAN F146_2601 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(g_main_context_pending (NULL));
	return Result;
}

/* {GTK2}.gtk_event_iteration */
EIF_BOOLEAN F146_2602 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(g_main_context_iteration(NULL, FALSE));
	return Result;
}

/* {GTK2}.dispatch_events */
void F146_2605 (EIF_REFERENCE Current)
{
	GTCX
	
	
	g_main_context_dispatch(g_main_context_default());
}

/* {GTK2}.gtk_widget_is_toplevel */
EIF_BOOLEAN F146_2610 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_toplevel((GtkWidget*) arg1));
	
	return Result;
}

/* {GTK2}.gtk_widget_has_screen */
EIF_BOOLEAN F146_2611 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F146_2611 ((EIF_POINTER) arg1));
	return Result;
}

/* {GTK2}.gtk_widget_get_screen */
EIF_POINTER F146_2612 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2612 ((EIF_POINTER) arg1);
	return Result;
}

/* {GTK2}.gtk_widget_destroy */
void F146_2614 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F146_2614 ((EIF_POINTER) arg1);
}

/* {GTK2}.gtk_toolbar_new */
EIF_POINTER F146_2615 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_toolbar_new();
	
	return Result;
}

/* {GTK2}.gtk_toolbar_set_style */
void F146_2616 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	gtk_toolbar_set_style((GtkToolbar*) arg1, (GtkToolbarStyle) arg2);
	
}

/* {GTK2}.gtk_toolbar_set_show_arrow */
void F146_2617 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	gtk_toolbar_set_show_arrow((GtkToolbar*) arg1, (gboolean) arg2);
	
}

/* {GTK2}.gtk_toolbar_insert */
void F146_2618 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	gtk_toolbar_insert((GtkToolbar*) arg1, (GtkToolItem*) arg2, (gint) arg3);
	
}

/* {GTK2}.gtk_toolbar_icons_enum */
EIF_INTEGER_32 F146_2619 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_TOOLBAR_ICONS;
	return Result;
}

/* {GTK2}.gtk_toolbar_text_enum */
EIF_INTEGER_32 F146_2620 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_TOOLBAR_TEXT;
	return Result;
}

/* {GTK2}.gtk_toolbar_both_enum */
EIF_INTEGER_32 F146_2621 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_TOOLBAR_BOTH;
	return Result;
}

/* {GTK2}.gtk_toolbar_both_horiz_enum */
EIF_INTEGER_32 F146_2622 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_TOOLBAR_BOTH_HORIZ;
	return Result;
}

/* {GTK2}.gtk_label_get_label */
EIF_POINTER F146_2625 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_label_get_label((GtkLabel*) arg1);
	
	return Result;
}

/* {GTK2}.gtk_scrolled_window_set_shadow_type */
void F146_2627 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	gtk_scrolled_window_set_shadow_type((GtkScrolledWindow*) arg1, (GtkShadowType) arg2);
	
}

/* {GTK2}.gtk_entry_set_alignment */
void F146_2633 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	GTCX
	
	gtk_entry_set_alignment((GtkEntry*) arg1, (gfloat) arg2);
	
}

/* {GTK2}.gtk_get_current_event_time */
EIF_NATURAL_32 F146_2634 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	Result = (EIF_NATURAL_32) gtk_get_current_event_time();
	
	return Result;
}

/* {GTK2}.gtk_tree_path_list_free_contents */
void F146_2635 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F146_2635 ((EIF_POINTER) arg1);
}

/* {GTK2}.gdk_event_window_state_struct_changed_mask */
EIF_INTEGER_32 F146_2640 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GdkEventWindowState *)arg1)->changed_mask);
	
	return Result;
}

/* {GTK2}.gdk_event_window_state_struct_new_window_state */
EIF_INTEGER_32 F146_2641 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((GdkEventWindowState *)arg1)->new_window_state);
	
	return Result;
}

/* {GTK2}.gtk_widget_get_has_window */
EIF_BOOLEAN F146_2642 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_has_window((GtkWidget*) arg1));
	
	return Result;
}

/* {GTK2}.gtk_widget_set_redraw_on_allocate */
void F146_2644 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	gtk_widget_set_redraw_on_allocate((GtkWidget*) arg1, (gboolean) arg2);
	
}

/* {GTK2}.gtk_widget_set_can_default */
void F146_2645 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	gtk_widget_set_can_default((GtkWidget*) arg1, (gboolean) arg2);
	
}

/* {GTK2}.gtk_widget_set_app_paintable */
void F146_2646 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	gtk_widget_set_app_paintable((GtkWidget*) arg1, (gboolean) arg2);
	
}

/* {GTK2}.gtk_widget_set_tooltip_text */
void F146_2647 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_widget_set_tooltip_text((GtkWidget*) arg1, (gchar*) arg2);
	
}

/* {GTK2}.gtk_widget_set_minimum_size */
void F146_2649 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	inline_F146_2653(arg1, arg2, arg3);
}

/* {GTK2}.gtk_widget_get_size_request */
void F146_2652 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	
	
	inline_F146_2652 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3);
}

/* {GTK2}.gtk_widget_set_size_request */
void F146_2653 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	inline_F146_2653 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3);
}

/* {GTK2}.gtk_widget_size_allocate */
void F146_2654 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F146_2654 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {GTK2}.gtk_widget_style_get_integer */
void F146_2656 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	
	
	inline_F146_2656 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32*) arg3);
}

/* {GTK2}.gtk_tree_path_new_from_string */
EIF_POINTER F146_2658 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_tree_path_new_from_string((gchar*) arg1);
	
	return Result;
}

/* {GTK2}.gtk_separator_tool_item_new */
EIF_POINTER F146_2659 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_separator_tool_item_new();
	
	return Result;
}

/* {GTK2}.gtk_radio_tool_button_set_group */
void F146_2666 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_radio_tool_button_set_group((GtkRadioToolButton*) arg1, (GSList*) arg2);
	
}

/* {GTK2}.gtk_radio_tool_button_get_group */
EIF_POINTER F146_2667 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_radio_tool_button_get_group((GtkRadioToolButton*) arg1);
	
	return Result;
}

/* {GTK2}.gtk_ok_enum_label */
EIF_POINTER F146_2672 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(371, 0x01).id, 371, _OBJSIZ_1_0_0_1_0_0_0_0_);
	tr2 = RTMS_EX_H("_OK",3,6246219);
	F372_5491(RTCW(tr1), tr2);
	Result = F372_5513(RTCW(tr1));
	RTLE;
	return Result;
}

/* {GTK2}.gtk_response_ok_enum */
EIF_INTEGER_32 F146_2674 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_RESPONSE_OK;
	return Result;
}

/* {GTK2}.gtk_response_accept_enum */
EIF_INTEGER_32 F146_2678 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_RESPONSE_ACCEPT;
	return Result;
}

/* {GTK2}.gtk_response_cancel_enum */
EIF_INTEGER_32 F146_2679 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_RESPONSE_CANCEL;
	return Result;
}

/* {GTK2}.gtk_cancel_enum_label */
EIF_POINTER F146_2682 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(371, 0x01).id, 371, _OBJSIZ_1_0_0_1_0_0_0_0_);
	tr2 = RTMS_EX_H("_CANCEL",7,2015767884);
	F372_5491(RTCW(tr1), tr2);
	Result = F372_5513(RTCW(tr1));
	RTLE;
	return Result;
}

/* {GTK2}.gtk_tree_path_free */
void F146_2694 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F146_2694 ((EIF_POINTER) arg1);
}

/* {GTK2}.gtk_tree_view_get_path_at_pos */
EIF_BOOLEAN F146_2695 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4, EIF_POINTER arg5, EIF_POINTER arg6, EIF_POINTER arg7)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F146_2695 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_POINTER) arg4, (EIF_POINTER) arg5, (EIF_POINTER) arg6, (EIF_POINTER) arg7));
	return Result;
}

/* {GTK2}.gtk_tree_view_set_headers_visible */
void F146_2701 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	
	inline_F146_2701 ((EIF_POINTER) arg1, (EIF_BOOLEAN) arg2);
}

/* {GTK2}.gtk_tree_path_get_indices */
EIF_POINTER F146_2704 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_tree_path_get_indices((GtkTreePath*) arg1);
	
	return Result;
}

/* {GTK2}.gtk_tree_selection_get_selected_rows */
EIF_POINTER F146_2710 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER* arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2710 ((EIF_POINTER) arg1, (EIF_POINTER*) arg2);
	return Result;
}

/* {GTK2}.gtk_tree_selection_unselect_all */
void F146_2715 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F146_2715 ((EIF_POINTER) arg1);
}

/* {GTK2}.gtk_tree_model_get_iter */
EIF_BOOLEAN F146_2717 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F146_2717 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3));
	return Result;
}

/* {GTK2}.gtk_tree_model_get_value */
void F146_2719 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	GTCX
	
	
	inline_F146_2719 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3, (EIF_POINTER) arg4);
}

/* {GTK2}.gtk_tree_view_get_column */
EIF_POINTER F146_2724 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2724 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	return Result;
}

/* {GTK2}.gtk_tree_view_get_selection */
EIF_POINTER F146_2727 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2727 ((EIF_POINTER) arg1);
	return Result;
}

/* {GTK2}.gtk_tree_view_column_set_resizable */
void F146_2734 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	
	inline_F146_2734 ((EIF_POINTER) arg1, (EIF_BOOLEAN) arg2);
}

/* {GTK2}.gtk_tree_view_column_add_attribute */
void F146_2743 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	
	
	inline_F146_2743 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3, (EIF_INTEGER_32) arg4);
}

/* {GTK2}.gtk_cell_renderer_text_new */
EIF_POINTER F146_2744 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2744 ();
	return Result;
}

/* {GTK2}.gtk_cell_renderer_pixbuf_new */
EIF_POINTER F146_2745 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2745 ();
	return Result;
}

/* {GTK2}.gtk_cell_renderer_get_fixed_size */
void F146_2747 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	
	gtk_cell_renderer_get_fixed_size((GtkCellRenderer*) arg1, (gint*) arg2, (gint*) arg3);
	
}

/* {GTK2}.gtk_cell_renderer_toggle_new */
EIF_POINTER F146_2749 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2749 ();
	return Result;
}

/* {GTK2}.gtk_tree_view_insert_column */
void F146_2750 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	inline_F146_2750 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3);
}

/* {GTK2}.gtk_tree_view_column_new */
EIF_POINTER F146_2753 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2753 ();
	return Result;
}

/* {GTK2}.gtk_tree_view_column_pack_start */
void F146_2755 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	GTCX
	
	
	inline_F146_2755 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_BOOLEAN) arg3);
}

/* {GTK2}.gtk_tree_view_column_pack_end */
void F146_2756 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	GTCX
	
	
	inline_F146_2756 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_BOOLEAN) arg3);
}

/* {GTK2}.c_g_value_struct_allocate */
EIF_POINTER F146_2759 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) calloc (sizeof(GValue), 1);
	return Result;
}

/* {GTK2}.g_value_init_string */
void F146_2763 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F146_2763 ((EIF_POINTER) arg1);
}

/* {GTK2}.g_value_set_boolean */
void F146_2767 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	
	inline_F146_2767 ((EIF_POINTER) arg1, (EIF_BOOLEAN) arg2);
}

/* {GTK2}.g_value_get_boolean */
EIF_BOOLEAN F146_2768 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F146_2768 ((EIF_POINTER) arg1));
	return Result;
}

/* {GTK2}.g_value_take_string */
void F146_2773 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F146_2773 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {GTK2}.gtk_tree_view_new */
EIF_POINTER F146_2774 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_tree_view_new();
	
	return Result;
}

/* {GTK2}.gtk_tree_view_set_model */
void F146_2775 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_tree_view_set_model((GtkTreeView*) arg1, (GtkTreeModel*) arg2);
	
}

/* {GTK2}.gtk_list_store_newv */
EIF_POINTER F146_2777 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2777 ((EIF_INTEGER_32) arg1, (EIF_POINTER) arg2);
	return Result;
}

/* {GTK2}.gtk_list_store_insert */
void F146_2781 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	inline_F146_2781 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3);
}

/* {GTK2}.gtk_list_store_remove */
void F146_2783 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F146_2783 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {GTK2}.gtk_list_store_set_value */
void F146_2785 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	GTCX
	
	
	inline_F146_2785 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3, (EIF_POINTER) arg4);
}

/* {GTK2}.gtk_list_store_set_pixbuf */
void F146_2787 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	GTCX
	
	
	inline_F146_2787 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3, (EIF_POINTER) arg4);
}

/* {GTK2}.gtk_fixed_new */
EIF_POINTER F146_2791 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_fixed_new();
	
	return Result;
}

/* {GTK2}.gtk_args_array_i_th */
EIF_POINTER F146_2797 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2797 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	return Result;
}

/* {GTK2}.gtk_label_set_text_with_mnemonic */
void F146_2804 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_label_set_text_with_mnemonic((GtkLabel*) arg1, (gchar*) arg2);
	
}

/* {GTK2}.gtk_value_pointer */
EIF_POINTER F146_2808 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) g_value_peek_pointer((GValue*) arg1);
	
	return Result;
}

/* {GTK2}.gtk_value_int */
EIF_INTEGER_32 F146_2809 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) g_value_get_int((GValue*) arg1);
	
	return Result;
}

/* {GTK2}.gtk_widget_create_pango_layout */
EIF_POINTER F146_2815 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_widget_create_pango_layout((GtkWidget*) arg1, (gchar*) arg2);
	
	return Result;
}

/* {GTK2}.gtk_widget_get_mapped */
EIF_BOOLEAN F146_2816 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_mapped((GtkWidget*) arg1));
	
	return Result;
}

/* {GTK2}.g_object_set_pointer */
void F146_2818 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	
	
	inline_F146_2818 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3);
}

/* {GTK2}.g_object_set_string */
void F146_2819 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	
	
	inline_F146_2819 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3);
}

/* {GTK2}.g_object_get_string */
void F146_2820 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER* arg3)
{
	GTCX
	
	
	inline_F146_2820 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER*) arg3);
}

/* {GTK2}.g_object_get_integer */
EIF_INTEGER_32 F146_2822 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F146_2822 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
	return Result;
}

/* {GTK2}.g_object_set_menu_icons */
void F146_2826 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	GTCX
	
	
	inline_F146_2826 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_BOOLEAN) arg3);
}

/* {GTK2}.signal_disconnect */
void F146_2829 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	RTGC;
	inline_F146_2830(arg1, arg2);
}

/* {GTK2}.c_signal_disconnect */
void F146_2830 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	inline_F146_2830 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
}

/* {GTK2}.gtk_text_view_new */
EIF_POINTER F146_2834 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_text_view_new();
	
	return Result;
}

/* {GTK2}.gtk_text_view_get_buffer */
EIF_POINTER F146_2838 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_text_view_get_buffer((GtkTextView*) arg1);
	
	return Result;
}

/* {GTK2}.gtk_text_buffer_set_text */
void F146_2840 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	gtk_text_buffer_set_text((GtkTextBuffer*) arg1, (gchar*) arg2, (gint) arg3);
	
}

/* {GTK2}.gtk_text_buffer_get_bounds */
void F146_2846 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	
	gtk_text_buffer_get_bounds((GtkTextBuffer*) arg1, (GtkTextIter*) arg2, (GtkTextIter*) arg3);
	
}

/* {GTK2}.gtk_text_buffer_get_text */
EIF_POINTER F146_2851 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_BOOLEAN arg4)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_text_buffer_get_text((GtkTextBuffer*) arg1, (GtkTextIter*) arg2, (GtkTextIter*) arg3, (gboolean) arg4);
	
	return Result;
}

/* {GTK2}.gtk_text_view_set_editable */
void F146_2856 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	gtk_text_view_set_editable((GtkTextView*) arg1, (gboolean) arg2);
	
}

/* {GTK2}.gtk_text_view_set_wrap_mode */
void F146_2857 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	gtk_text_view_set_wrap_mode((GtkTextView*) arg1, (GtkWrapMode) arg2);
	
}

/* {GTK2}.gtk_image_new_from_pixbuf */
EIF_POINTER F146_2897 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_image_new_from_pixbuf((GdkPixbuf*) arg1);
	
	return Result;
}

/* {GTK2}.gtk_dialog_new */
EIF_POINTER F146_2899 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_dialog_new();
	
	return Result;
}

/* {GTK2}.gtk_dialog_add_button */
EIF_POINTER F146_2900 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2900 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3);
	return Result;
}

/* {GTK2}.gtk_dialog_set_default_response */
void F146_2902 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	inline_F146_2902 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
}

/* {GTK2}.gtk_file_filter_new */
EIF_POINTER F146_2903 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_file_filter_new();
	
	return Result;
}

/* {GTK2}.gtk_file_filter_add_pattern */
void F146_2904 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F146_2904 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {GTK2}.gtk_file_filter_set_name */
void F146_2905 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F146_2905 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {GTK2}.gtk_file_chooser_add_filter */
void F146_2907 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F146_2907 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {GTK2}.gtk_file_chooser_remove_filter */
void F146_2908 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F146_2908 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {GTK2}.gtk_file_chooser_action_open_enum */
EIF_INTEGER_32 F146_2909 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_FILE_CHOOSER_ACTION_OPEN;
	return Result;
}

/* {GTK2}.gtk_file_chooser_action_save_enum */
EIF_INTEGER_32 F146_2910 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_FILE_CHOOSER_ACTION_SAVE;
	return Result;
}

/* {GTK2}.gtk_file_chooser_action_select_folder_enum */
EIF_INTEGER_32 F146_2911 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GTK_FILE_CHOOSER_ACTION_SELECT_FOLDER;
	return Result;
}

/* {GTK2}.gtk_file_chooser_set_current_folder */
void F146_2914 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	gtk_file_chooser_set_current_folder((GtkFileChooser*) arg1, (gchar*) arg2);
	
}

/* {GTK2}.gtk_file_chooser_list_filters */
EIF_POINTER F146_2915 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_file_chooser_list_filters((GtkFileChooser*) arg1);
	
	return Result;
}

/* {GTK2}.gtk_file_chooser_dialog_new */
EIF_POINTER F146_2916 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2916 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3);
	return Result;
}

/* {GTK2}.gtk_file_chooser_get_filename */
EIF_POINTER F146_2918 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2918 ((EIF_POINTER) arg1);
	return Result;
}

/* {GTK2}.gtk_file_chooser_get_filenames */
EIF_POINTER F146_2919 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F146_2919 ((EIF_POINTER) arg1);
	return Result;
}

/* {GTK2}.gtk_file_chooser_set_filename */
void F146_2920 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F146_2920 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {GTK2}.gtk_file_chooser_set_local_only */
void F146_2921 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	
	inline_F146_2921 ((EIF_POINTER) arg1, (EIF_BOOLEAN) arg2);
}

void EIF_Minit110 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
