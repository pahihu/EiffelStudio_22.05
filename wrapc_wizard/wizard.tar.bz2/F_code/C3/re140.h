
#ifndef _C3_re140_
#define _C3_re140_

#ifdef __cplusplus
extern "C" {
#endif

extern void F176_3500(EIF_REFERENCE, EIF_REFERENCE);
extern void F176_3501(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit140(void);

#ifdef __cplusplus
}
#endif

#endif
