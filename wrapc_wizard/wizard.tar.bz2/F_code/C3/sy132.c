/*
 * Code for class SYSTEM_ENCODINGS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sy132.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SYSTEM_ENCODINGS}.console_encoding */
static EIF_REFERENCE F168_3391_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (3391);
#define Result RTOSR(3391)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(54, 0x01).id, 54, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = F194_3839(RTCV(RTOSCF(3396,F168_3396, (Current))));
	F55_1004(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3391);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F168_3391 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3391,F168_3391_body,(Current));
}

/* {SYSTEM_ENCODINGS}.utf8 */
static EIF_REFERENCE F168_3392_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (3392);
#define Result RTOSR(3392)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(54, 0x01).id, 54, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(1020,F56_1020, (Current));
	F55_1004(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3392);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F168_3392 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3392,F168_3392_body,(Current));
}

/* {SYSTEM_ENCODINGS}.utf32 */
static EIF_REFERENCE F168_3394_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (3394);
#define Result RTOSR(3394)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(54, 0x01).id, 54, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(1022,F56_1022, (Current));
	F55_1004(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3394);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F168_3394 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3394,F168_3394_body,(Current));
}

/* {SYSTEM_ENCODINGS}.system_encodings_i */
static EIF_REFERENCE F168_3396_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3396);
#define Result RTOSR(3396)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(193, 0x01).id, 193, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3396);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F168_3396 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3396,F168_3396_body,(Current));
}

void EIF_Minit132 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
