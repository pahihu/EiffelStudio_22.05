
#ifndef _C3_id129_
#define _C3_id129_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F165_3362(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F165_3363(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F165_3364(EIF_REFERENCE);
extern void F165_3366(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit129(void);

#ifdef __cplusplus
}
#endif

#endif
