
#ifndef _C3_ev128_
#define _C3_ev128_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F164_3354(EIF_REFERENCE);
extern EIF_REFERENCE F164_3360(EIF_REFERENCE);
extern void EIF_Minit128(void);
extern void F872_6758(EIF_REFERENCE);
extern long O3362[];
extern long O3368[];

#ifdef __cplusplus
}
#endif

#endif
