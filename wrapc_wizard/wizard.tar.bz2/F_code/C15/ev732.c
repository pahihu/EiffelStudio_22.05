/*
 * Code for class EV_TEXT_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev732.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F145_2228
static EIF_POINTER inline_F145_2228 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref_sink((gpointer) arg1))
	;
}
#define INLINE_F145_2228
#endif
#ifndef INLINE_F146_2653
static void inline_F146_2653 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	gtk_widget_set_size_request ((GtkWidget*) arg1, (gint) arg2, (gint) arg3)
	;
}
#define INLINE_F146_2653
#endif
#ifndef INLINE_F145_2230
static void inline_F145_2230 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F145_2230
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TEXT_IMP}.make */
void F1410_13954 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tp1 = (EIF_POINTER) gtk_event_box_new();
	F1300_12366(Current, tp1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp3 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp4 = tp3;
	tp1 = (EIF_POINTER) gtk_scrolled_window_new((GtkAdjustment*) tp2, (GtkAdjustment*) tp4);
	*(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_2_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_2_);
	ti4_1 = (EIF_INTEGER_32) GTK_SHADOW_IN;
	gtk_scrolled_window_set_shadow_type((GtkScrolledWindow*) tp1, (GtkShadowType) ti4_1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_2_);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_0_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_2_);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) tp2);
	tp1 = (EIF_POINTER) gtk_text_view_new();
	*(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_1_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_1_);
	tp1 = (EIF_POINTER) gtk_text_view_get_buffer((GtkTextView*) tp1);
	*(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_3_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_3_);
	tp1 = inline_F145_2228(tp1);
	*(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_3_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_1_);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_2_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_1_);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) tp2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_1_);
	inline_F146_2653(tp1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	F1410_13989(Current);
	F1410_13964(Current, (EIF_BOOLEAN) 1);
	tr1 = RTLNS(eif_new_type(56, 0x01).id, 56, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(1027,F57_1027, (RTCW(tr1)));
	F1313_12586(Current, tr1);
	F1410_13955(Current);
	F1408_13902(Current);
	RTLE;
}

/* {EV_TEXT_IMP}.initialize_buffer_events */
void F1410_13955 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_3_);
	tr1 = RTOSCF(823,F46_823, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1049,0xFF01,1010,1121,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(12391,F1300_12391, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_0_);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = tp2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,0,1049,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A409_335, (EIF_POINTER) _A409_335, (EIF_POINTER)(F1009_8375),tr2, 1, 0);
	}
	F1300_12370(Current, tp1, tr1, tr3);
	RTLE;
}

/* {EV_TEXT_IMP}.is_editable */
EIF_BOOLEAN F1410_13959 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_44_12_);
}


/* {EV_TEXT_IMP}.set_editable */
void F1410_13964 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_44_12_) = (EIF_BOOLEAN) arg1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_1_);
	gtk_text_view_set_editable((GtkTextView*) tp1, (gboolean) arg1);
	RTLE;
}

/* {EV_TEXT_IMP}.text */
RTEOMS(13972,1);
EIF_REFERENCE F1410_13973 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLR(3,loc4);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(302, 0x01).id, 302, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F302_4751(RTCW(loc1));
	loc2 = RTLNS(eif_new_type(302, 0x01).id, 302, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F302_4751(RTCW(loc2));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_3_);
	tp2 = F302_4754(RTCW(loc1));
	tp3 = F302_4754(RTCW(loc2));
	gtk_text_buffer_get_bounds((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (GtkTextIter*) tp3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_3_);
	tp2 = F302_4754(RTCW(loc1));
	tp3 = F302_4754(RTCW(loc2));
	loc3 = (EIF_POINTER) gtk_text_buffer_get_text((GtkTextBuffer*) tp1, (GtkTextIter*) tp2, (GtkTextIter*) tp3, (gboolean) (EIF_BOOLEAN) 0);
	loc4 = RTLNS(eif_new_type(992, 0x01).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F993_7481(RTCW(loc4), loc3);
	Result = F993_7485(RTCW(loc4));
	F993_7487(RTCW(loc4), RTOMS(13972,0));
	RTLE;
	return Result;
}

/* {EV_TEXT_IMP}.has_word_wrapping */
EIF_BOOLEAN F1410_13981 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_44_11_);
}


/* {EV_TEXT_IMP}.set_text */
void F1410_13983 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F993_7487(RTCW(loc1), arg1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_3_);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	gtk_text_buffer_set_text((GtkTextBuffer*) tp1, (gchar*) tp2, (gint) ((EIF_INTEGER_32) -1L));
	RTLE;
}

/* {EV_TEXT_IMP}.enable_word_wrapping */
void F1410_13989 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_2_);
	ti4_1 = (EIF_INTEGER_32) GTK_POLICY_AUTOMATIC;
	ti4_2 = (EIF_INTEGER_32) GTK_POLICY_ALWAYS;
	gtk_scrolled_window_set_policy((GtkScrolledWindow*) tp1, (GtkPolicyType) ti4_1, (GtkPolicyType) ti4_2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_1_);
	gtk_text_view_set_wrap_mode((GtkTextView*) tp1, (GtkWrapMode) ((EIF_INTEGER_32) 2L));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_44_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {EV_TEXT_IMP}.disable_word_wrapping */
void F1410_13990 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_2_);
	ti4_1 = (EIF_INTEGER_32) GTK_POLICY_ALWAYS;
	ti4_2 = (EIF_INTEGER_32) GTK_POLICY_ALWAYS;
	gtk_scrolled_window_set_policy((GtkScrolledWindow*) tp1, (GtkPolicyType) ti4_1, (GtkPolicyType) ti4_2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_1_);
	gtk_text_view_set_wrap_mode((GtkTextView*) tp1, (GtkWrapMode) ((EIF_INTEGER_32) 0L));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_44_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {EV_TEXT_IMP}.visual_widget */
EIF_POINTER F1410_13991 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_1_);
}

/* {EV_TEXT_IMP}.c_object_dispose */
void F1410_13992 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_3_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_3_);
		inline_F145_2230(tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_44_15_10_6_0_3_) = (EIF_POINTER) tp2;
	}
	F1300_12381(Current);
	RTLE;
}

/* {EV_TEXT_IMP}.on_change_actions */
void F1410_13993 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		F873_6795(RTCW(tr1), NULL);
	}
	RTLE;
}

void EIF_Minit732 (void)
{
	GTCX
	RTPOMS(13972,0,"",0,0);
}


#ifdef __cplusplus
}
#endif
