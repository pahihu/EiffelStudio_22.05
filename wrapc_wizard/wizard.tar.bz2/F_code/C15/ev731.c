/*
 * Code for class EV_TEXT_FIELD_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev731.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F47_854
static EIF_NATURAL_8 inline_F47_854 (void)
{
	return GTK_ORIENTATION_VERTICAL
	;
}
#define INLINE_F47_854
#endif
#ifndef INLINE_F147_2949
static EIF_POINTER inline_F147_2949 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F147_2949
#endif
#ifndef INLINE_F148_3140
static void inline_F148_3140 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_entry_set_width_chars ((GtkEntry *)arg1, (gint)arg2)
	;
}
#define INLINE_F148_3140
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TEXT_FIELD_IMP}.needs_event_box */
EIF_BOOLEAN F1409_13911 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_TEXT_FIELD_IMP}.make */
void F1409_13913 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = inline_F47_854();
	loc1 = inline_F147_2949(tu1_1, ((EIF_INTEGER_32) 0L));
	F1300_12366(Current, loc1);
	tp1 = F1409_13949(Current);
	*(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	gtk_box_pack_start((GtkBox*) loc1, (GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 1, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	F1409_13920(Current);
	F1408_13902(Current);
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.text */
EIF_REFERENCE F1409_13914 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(992, 0x01).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	tp1 = (EIF_POINTER) gtk_entry_get_text((GtkEntry*) tp1);
	F993_7489(RTCW(loc1), tp1);
	tr1 = F993_7485(RTCW(loc1));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {EV_TEXT_FIELD_IMP}.set_minimum_width_in_characters */
void F1409_13915 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	ti4_1 = F1408_13905(Current);
	tr1 = RTLNS(eif_new_type(145, 0x01).id, 145, _OBJSIZ_0_0_0_0_0_0_0_0_);
	F146_2649(RTCW(tr1), tp1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)) * ti4_1), ((EIF_INTEGER_32) -1L));
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.set_text */
void F1409_13916 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F993_7487(RTCW(loc1), arg1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	inline_F148_3140(tp1, ((EIF_INTEGER_32) 1L));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	gtk_entry_set_text((GtkEntry*) tp1, (gchar*) tp2);
	F1409_13946(Current);
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.align_text_left */
void F1409_13920 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_46_14_10_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	gtk_entry_set_alignment((GtkEntry*) tp1, (gfloat) (EIF_REAL_32) 0.0);
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.align_text_center */
void F1409_13922 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_46_14_10_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	gtk_entry_set_alignment((GtkEntry*) tp1, (gfloat) (EIF_REAL_32) 0.5);
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.text_alignment */
EIF_INTEGER_32 F1409_13923 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_46_14_10_6_);
}


/* {EV_TEXT_FIELD_IMP}.on_key_event */
void F1409_13926 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	F1353_13018(Current, arg1, arg2, arg3);
	tb1 = '\0';
	if ((EIF_BOOLEAN) !F1274_11665(Current)) {
		tb1 = arg3;
	}
	if (tb1) {
		F1409_13946(Current);
	}
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.set_editable */
void F1409_13934 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	gtk_editable_set_editable((GtkEditable*) tp1, (gboolean) arg1);
}

/* {EV_TEXT_FIELD_IMP}.on_change_actions */
void F1409_13946 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tb1 = '\0';
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tb3 = F550_5957(loc2);
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !F1274_11665(Current);
	}
	if (tb1) {
		loc1 = F1409_13914(Current);
		tb1 = '\01';
		tb2 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_45_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tb3 = F1132_9937(RTCW(loc1), loc3);
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (!tb2) {
			tb1 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_45_) == NULL);
		}
		if (tb1) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_46_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F873_6795(loc2, NULL);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_46_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			tr1 = F1409_13914(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_45_) = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {EV_TEXT_FIELD_IMP}.style_element_name */
EIF_REFERENCE F1409_13948 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTMS_EX_H("entry",5,1853900921);
	RTLE;
	return Result;
}

/* {EV_TEXT_FIELD_IMP}.new_entry_widget */
EIF_POINTER F1409_13949 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) (EIF_POINTER) gtk_entry_new();
}

/* {EV_TEXT_FIELD_IMP}.visual_widget */
EIF_POINTER F1409_13951 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
}

void EIF_Minit731 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
