/*
 * Code for class EV_PRIMITIVE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev724.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PRIMITIVE_IMP}.make */
void F1402_13722 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1353_13011(Current);
	F1402_13731(Current);
	RTLE;
}

/* {EV_PRIMITIVE_IMP}.update_for_pick_and_drop */
void F1402_13724 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	RTGC;
}

/* {EV_PRIMITIVE_IMP}.is_tabable_to */
EIF_BOOLEAN F1402_13725 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R10419[Dtype(Current)-1405])(Current);
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_can_focus((GtkWidget*) tp1));
	RTLE;
	return Result;
}

/* {EV_PRIMITIVE_IMP}.is_tabable_from */
EIF_BOOLEAN F1402_13726 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O11049[Dtype(Current)-1401]);
}


/* {EV_PRIMITIVE_IMP}.enable_tabable_to */
void F1402_13727 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R10419[Dtype(Current)-1405])(Current);
	gtk_widget_set_can_focus((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_PRIMITIVE_IMP}.disable_tabable_to */
void F1402_13728 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R10419[Dtype(Current)-1405])(Current);
	gtk_widget_set_can_focus((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	RTLE;
}

/* {EV_PRIMITIVE_IMP}.enable_tabable_from */
void F1402_13729 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O11049[Dtype(Current)-1401]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_PRIMITIVE_IMP}.disable_tabable_from */
void F1402_13730 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O11049[Dtype(Current)-1401]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_PRIMITIVE_IMP}.initialize_tab_behavior */
void F1402_13731 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (F1402_13725(Current)) {
		F1402_13729(Current);
	}
	RTLE;
}

void EIF_Minit724 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
