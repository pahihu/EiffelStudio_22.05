/*
 * Code for class EV_CHECKABLE_LIST_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev723.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CHECKABLE_LIST_I}.checked_items */
EIF_REFERENCE F1401_13717 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O10232[Dtype(Current)-1304]);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,849,0xFF01,1249,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 849, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F850_6641(RTCW(Result), ((EIF_INTEGER_32) 0L));
	F1305_12525(Current);
	for (;;) {
		if (F1305_12518(Current)) break;
		tr1 = F1305_12513(Current);
		if (F1415_14156(Current, tr1)) {
			tr1 = F1305_12513(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5613[Dtype(RTCW(Result))-692])(Result, tr1);
		}
		F1305_12527(Current);
	}
	F1305_12528(Current, loc1);
	RTLE;
	return Result;
}

void EIF_Minit723 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
