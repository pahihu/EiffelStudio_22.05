
#ifndef _C15_ev723_
#define _C15_ev723_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1401_13717(EIF_REFERENCE);
extern void EIF_Minit723(void);
extern void F1305_12525(EIF_REFERENCE);
extern EIF_BOOLEAN F1415_14156(EIF_REFERENCE, EIF_REFERENCE);
extern void F1305_12528(EIF_REFERENCE, EIF_INTEGER_32);
extern void F850_6641(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F1305_12518(EIF_REFERENCE);
extern EIF_REFERENCE F1305_12513(EIF_REFERENCE);
extern void F1305_12527(EIF_REFERENCE);
extern char *(*R5613[])();
extern long O10232[];

#ifdef __cplusplus
}
#endif

#endif
