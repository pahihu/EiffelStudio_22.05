
#ifndef _C15_ev744_
#define _C15_ev744_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1422_14203(EIF_REFERENCE);
extern EIF_REFERENCE F1422_14204(EIF_REFERENCE);
extern void EIF_Minit744(void);
extern EIF_REFERENCE F1420_14199(EIF_REFERENCE);
extern EIF_BOOLEAN F1211_10980(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
