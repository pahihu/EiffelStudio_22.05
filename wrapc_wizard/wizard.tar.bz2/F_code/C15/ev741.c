/*
 * Code for class EV_CHECK_BUTTON_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev741.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F148_3165
static void inline_F148_3165 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_xalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F148_3165
#endif
#ifndef INLINE_F148_3166
static void inline_F148_3166 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_yalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F148_3166
#endif
#ifndef INLINE_F40_660
static EIF_INTEGER_32 inline_F40_660 (void)
{
	return GTK_ALIGN_END
	;
}
#define INLINE_F40_660
#endif
#ifndef INLINE_F147_2936
static void inline_F147_2936 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return gtk_widget_set_halign ((GtkWidget *)arg1, (GtkAlign)arg2)
	;
}
#define INLINE_F147_2936
#endif
#ifndef INLINE_F40_661
static EIF_INTEGER_32 inline_F40_661 (void)
{
	return GTK_ALIGN_CENTER
	;
}
#define INLINE_F40_661
#endif
#ifndef INLINE_F147_2939
static void inline_F147_2939 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return gtk_widget_set_valign ((GtkWidget *)arg1, (GtkAlign)arg2)
	;
}
#define INLINE_F147_2939
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CHECK_BUTTON_IMP}.new_gtk_button */
EIF_POINTER F1419_14195 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) (EIF_POINTER) gtk_check_button_new();
}

/* {EV_CHECK_BUTTON_IMP}.make */
void F1419_14196 (EIF_REFERENCE Current)
{
	GTCX
	struct eif_ex_1455 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(57, 0x00).id);
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1416_14162(Current);
	F1416_14169(Current);
	tr1 = F58_1051(RTCW(loc1));
	F1313_12586(Current, tr1);
	tr1 = F58_1052(RTCW(loc1));
	F1416_14174(Current, tr1);
	RTLE;
}

/* {EV_CHECK_BUTTON_IMP}.set_text */
void F1419_14197 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1337_12795(Current, arg1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
	inline_F148_3165(tp1, (EIF_REAL_32) 0.0);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
	inline_F148_3166(tp1, (EIF_REAL_32) 0.5);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(F1333_12774(Current) != tp1)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_1_);
		ti4_1 = inline_F40_660();
		inline_F147_2936(tp1, ti4_1);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_1_);
		ti4_1 = inline_F40_661();
		inline_F147_2939(tp1, ti4_1);
	}
	RTLE;
}

void EIF_Minit741 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
