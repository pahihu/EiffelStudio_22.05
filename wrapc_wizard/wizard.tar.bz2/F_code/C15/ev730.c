/*
 * Code for class EV_TEXT_COMPONENT_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev730.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TEXT_COMPONENT_IMP}.make */
void F1408_13902 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R10957[Dtype(Current)-1408])(Current, ((EIF_INTEGER_32) 4L));
	F1402_13722(Current);
	RTLE;
}

/* {EV_TEXT_COMPONENT_IMP}.set_minimum_width_in_characters */
void F1408_13904 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F1408_13905(Current);
	F1353_13033(Current, (EIF_INTEGER_32) (arg1 * ti4_1));
	RTLE;
}

/* {EV_TEXT_COMPONENT_IMP}.maximum_character_width */
RTEOMS(13904,1);
EIF_INTEGER_32 F1408_13905 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1335_12780(Current);
	Result = F1177_10555(RTCW(tr1), RTOMS(13904,0));
	RTLE;
	return Result;
}

/* {EV_TEXT_COMPONENT_IMP}.adapted_css */
EIF_REFERENCE F1408_13907 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg3);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1136, 0x01).id, 1136, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1135_10082(RTCW(loc1), arg3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10293[Dtype(Current)-1365])(Current);
	tr2 = RTMS_EX_H(" > selection {",14,624141691);
	tr1 = F1137_10212(RTCW(tr1), tr2);
	F1137_10193(RTCW(loc1), tr1);
	tr2 = RTMS_EX_H("theme_selected_bg_color",23,688565106);
	tr1 = RTLNS(eif_new_type(147, 0x01).id, 147, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr2 = F148_3237(RTCW(tr1), arg1, tr2);
	loc2 = tr2;
	if (EIF_TEST(loc2)) {
		tr1 = RTMS_EX_H(" background:",12,1306960442);
		F1137_10193(RTCW(loc1), tr1);
		F1137_10193(RTCW(loc1), loc2);
		F1137_10206(RTCW(loc1), (EIF_CHARACTER_8) ';');
	}
	tr2 = RTMS_EX_H("theme_selected_fg_color",23,689486706);
	tr1 = RTLNS(eif_new_type(147, 0x01).id, 147, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr2 = F148_3237(RTCW(tr1), arg1, tr2);
	loc3 = tr2;
	if (EIF_TEST(loc3)) {
		tr1 = RTMS_EX_H(" color:",7,941026362);
		F1137_10193(RTCW(loc1), tr1);
		F1137_10193(RTCW(loc1), loc3);
		F1137_10206(RTCW(loc1), (EIF_CHARACTER_8) ';');
	}
	tr1 = RTMS_EX_H("}\012",2,32010);
	F1137_10193(RTCW(loc1), tr1);
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_TEXT_COMPONENT_IMP}.apply_background_color_to_style_context */
void F1408_13908 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,arg3);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	tr1 = F1408_13907(Current, arg1, arg2, arg3);
	F1313_12593(Current, arg1, arg2, tr1);
	RTLE;
}

/* {EV_TEXT_COMPONENT_IMP}.apply_foreground_color_to_style_context */
void F1408_13909 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,arg3);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	tr1 = F1408_13907(Current, arg1, arg2, arg3);
	F1313_12594(Current, arg1, arg2, tr1);
	RTLE;
}

void EIF_Minit730 (void)
{
	GTCX
	RTPOMS(13904,0,"W",1,87);
}


#ifdef __cplusplus
}
#endif
