/*
 * Code for class EV_DIALOG_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev705.h"
#include <ev_gtk.h>
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DIALOG_IMP}.new_gtk_window */
EIF_POINTER F1383_13514 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) F197_3858(Current);
}

/* {EV_DIALOG_IMP}.make */
void F1383_13515 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1380_13413(Current);
	F1383_13518(Current);
	RTLE;
}

/* {EV_DIALOG_IMP}.enable_closeable */
void F1383_13518 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1383_13522(Current, (EIF_BOOLEAN) 1);
}

/* {EV_DIALOG_IMP}.disable_closeable */
void F1383_13519 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1383_13522(Current, (EIF_BOOLEAN) 0);
}

/* {EV_DIALOG_IMP}.default_window_position */
EIF_INTEGER_32 F1383_13520 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) GTK_WIN_POS_CENTER;
}

/* {EV_DIALOG_IMP}.client_area */
EIF_POINTER F1383_13521 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) F197_3859(Current, *(EIF_POINTER *)(Current+ _PTROFF_68_26_10_11_0_0_));
}

/* {EV_DIALOG_IMP}.set_closeable */
void F1383_13522 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (arg1) {
		loc1 = (EIF_INTEGER_32) GDK_FUNC_CLOSE;
	}
	ti4_1 = (EIF_INTEGER_32) GDK_FUNC_MOVE;
	ti4_1 = eif_bit_or(loc1,ti4_1);
	loc1 = (EIF_INTEGER_32) ti4_1;
	ti4_1 = (EIF_INTEGER_32) GDK_FUNC_RESIZE;
	ti4_1 = eif_bit_or(loc1,ti4_1);
	loc1 = (EIF_INTEGER_32) ti4_1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_68_26_10_11_0_0_);
	tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
	gdk_window_set_functions((GdkWindow*) tp1, (GdkWMFunction) loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_68_23_) = (EIF_BOOLEAN) arg1;
	RTLE;
}

/* {EV_DIALOG_IMP}.call_close_request_actions */
void F1383_13523 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	if ((EIF_BOOLEAN) !F1380_13456(Current)) {
		tb3 = *(EIF_BOOLEAN *)(Current+ _CHROFF_68_23_);
	}
	if (tb3) {
		tb3 = F1299_12327(RTCV(RTOSCF(12391,F1300_12391, (Current))));
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !F1274_11665(Current);
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(1467, 0x01).id, 1467, _OBJSIZ_0_0_0_1_0_0_0_0_);
		F1468_14917(RTCW(tr1), ((EIF_INTEGER_32) 42L));
		F1379_13405(Current, tr1);
		F1380_13470(Current);
	}
	RTLE;
}

void EIF_Minit705 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
