/*
 * Code for class EV_LIST_ITEM_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev745.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_LIST_ITEM_IMP}.make */
RTEOMS(14207,1);
void F1423_14208 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1129_9842(RTOMS(14207,0));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) tr1;
	F1274_11680(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_LIST_ITEM_IMP}.able_to_transport */
EIF_BOOLEAN F1423_14211 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	tb1 = '\0';
	if (F1350_12921(Current)) {
		tb1 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L));
	}
	if (!tb1) {
		tb1 = '\0';
		tb2 = '\0';
		if (F1350_12920(Current)) {
			tb2 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 3L));
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN) !F1350_12923(Current);
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.ready_for_pnd_menu */
EIF_BOOLEAN F1423_14212 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\01';
	if (!F1350_12922(Current)) {
		tb2 = F1350_12923(Current);
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 3L));
	}
	if (tb1) {
		Result = (EIF_BOOLEAN) !arg2;
	}
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.draw_rubber_band */
void F1423_14214 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_LIST_ITEM_IMP}.erase_rubber_band */
void F1423_14215 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_LIST_ITEM_IMP}.internal_set_pointer_style */
void F1423_14221 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {EV_LIST_ITEM_IMP}.real_pointed_target */
EIF_REFERENCE F1423_14222 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {EV_LIST_ITEM_IMP}.is_selected */
EIF_BOOLEAN F1423_14223 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1414_14132(loc1);
		tr2 = F1274_11666(Current);
		Result = F850_6653(RTCW(tr1), tr2);
	}
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.text */
EIF_REFERENCE F1423_14226 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	Result = F1_14(tr1);
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.set_tooltip */
void F1423_14227 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1129_9842(RTCW(arg1));
	tr1 = F1_14(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {EV_LIST_ITEM_IMP}.set_text */
void F1423_14229 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = F1129_9842(RTCW(arg1));
	tr1 = F1_14(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1274_11666(Current);
		ti4_1 = F1305_12519(loc1, tr1, ((EIF_INTEGER_32) 1L));
		F1412_14094(loc1, ti4_1, arg1);
	}
	RTLE;
}

/* {EV_LIST_ITEM_IMP}.set_pixmap */
void F1423_14230 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = F1_14(arg1);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) loc1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = F1274_11666(Current);
		ti4_1 = F1305_12519(loc2, tr1, ((EIF_INTEGER_32) 1L));
		F1412_14096(loc2, ti4_1, loc1);
	}
	RTLE;
}

/* {EV_LIST_ITEM_IMP}.pixmap */
EIF_REFERENCE F1423_14232 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_22_);
}


/* {EV_LIST_ITEM_IMP}.x_position */
EIF_INTEGER_32 F1423_14233 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1413, 0x01),loc2);
	if (EIF_TEST(loc2)) {
		tp1 = *(EIF_POINTER *)(loc2 + O11192[Dtype(loc2)-1413]);
		loc1 = (EIF_POINTER) gtk_scrolled_window_get_hadjustment((GtkScrolledWindow*) tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc1 != tp1)) {
			tr4_1 = (EIF_REAL_32) gtk_adjustment_get_value((GtkAdjustment*) loc1);
			tr1 = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
			*(EIF_REAL_32 *)tr1 = tr4_1;
			Result = F1087_9660(RTCW(tr1));
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -Result;
		}
	}
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.y_position */
EIF_INTEGER_32 F1423_14234 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		Result = F1305_12519(loc2, *(EIF_REFERENCE *)(Current + _REFACS_12_), ((EIF_INTEGER_32) 1L));
		ti4_1 = F1414_14143(loc2);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result - ((EIF_INTEGER_32) 1L)) * ti4_1);
		loc3 = loc2;
		loc3 = RTRV(eif_new_type(1413, 0x01),loc3);
		if (EIF_TEST(loc3)) {
			tp1 = *(EIF_POINTER *)(loc3 + O11192[Dtype(loc3)-1413]);
			loc1 = (EIF_POINTER) gtk_scrolled_window_get_hadjustment((GtkScrolledWindow*) tp1);
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			if ((EIF_BOOLEAN)(loc1 != tp1)) {
				tr4_1 = (EIF_REAL_32) gtk_adjustment_get_value((GtkAdjustment*) loc1);
				tr1 = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
				*(EIF_REAL_32 *)tr1 = tr4_1;
				ti4_1 = F1087_9660(RTCW(tr1));
				Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result - ti4_1);
			}
		}
	}
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.screen_x */
EIF_INTEGER_32 F1423_14235 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = F1301_12394(loc1);
		ti4_1 = F1423_14233(Current);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	}
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.screen_y */
EIF_INTEGER_32 F1423_14236 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = F1301_12395(loc1);
		ti4_1 = F1423_14234(Current);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	}
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM_IMP}.width */
EIF_INTEGER_32 F1423_14237 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = F1353_13029(loc1);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_LIST_ITEM_IMP}.height */
EIF_INTEGER_32 F1423_14238 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = F1353_13030(loc1);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_LIST_ITEM_IMP}.minimum_width */
EIF_INTEGER_32 F1423_14239 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = F1301_12399(loc1);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_LIST_ITEM_IMP}.destroy */
void F1423_14242 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1274_11666(loc1);
		tr2 = F1274_11666(Current);
		F1210_10962(RTCW(tr1), tr2);
	}
	F1274_11681(Current, (EIF_BOOLEAN) 1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {EV_LIST_ITEM_IMP}.update_for_pick_and_drop */
void F1423_14243 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	RTGC;
}

/* {EV_LIST_ITEM_IMP}.set_list_iter */
void F1423_14245 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) arg1;
}

/* {EV_LIST_ITEM_IMP}.parent_imp */
EIF_REFERENCE F1423_14247 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_21_);
}


/* {EV_LIST_ITEM_IMP}.set_parent_imp */
void F1423_14248 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit745 (void)
{
	GTCX
	RTPOMS(14207,0,"",0,0);
}


#ifdef __cplusplus
}
#endif
