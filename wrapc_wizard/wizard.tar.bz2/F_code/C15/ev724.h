
#ifndef _C15_ev724_
#define _C15_ev724_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1402_13722(EIF_REFERENCE);
extern void F1402_13724(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F1402_13725(EIF_REFERENCE);
extern EIF_BOOLEAN F1402_13726(EIF_REFERENCE);
extern void F1402_13727(EIF_REFERENCE);
extern void F1402_13728(EIF_REFERENCE);
extern void F1402_13729(EIF_REFERENCE);
extern void F1402_13730(EIF_REFERENCE);
extern void F1402_13731(EIF_REFERENCE);
extern void EIF_Minit724(void);
extern void F1353_13011(EIF_REFERENCE);
extern char *(*R10419[])();
extern long O11049[];

#ifdef __cplusplus
}
#endif

#endif
