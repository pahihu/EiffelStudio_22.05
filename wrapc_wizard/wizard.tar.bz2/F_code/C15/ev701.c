/*
 * Code for class EV_DIALOG_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev701.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DIALOG_I}.default_push_button */
EIF_REFERENCE F1379_13394 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_61_);
}

/* {EV_DIALOG_I}.default_cancel_button */
EIF_REFERENCE F1379_13395 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_62_);
}

/* {EV_DIALOG_I}.current_push_button */
EIF_REFERENCE F1379_13396 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_63_) != NULL)) {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_63_);
	} else {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_61_);
	}/* NOTREACHED */
	
}

/* {EV_DIALOG_I}.set_default_push_button */
void F1379_13397 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_63_) == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_61_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			F1244_11465(loc1);
		}
		F1244_11464(RTCW(arg1));
	} else {
	}
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_61_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {EV_DIALOG_I}.remove_default_push_button */
void F1379_13398 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_63_) == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_61_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			F1244_11465(loc1);
		}
	} else {
	}
	*(EIF_REFERENCE *)(Current + _REFACS_61_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {EV_DIALOG_I}.set_default_cancel_button */
void F1379_13399 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_62_) = (EIF_REFERENCE) arg1;
	F1383_13518(Current);
	RTLE;
}

/* {EV_DIALOG_I}.remove_default_cancel_button */
void F1379_13400 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_62_) = (EIF_REFERENCE) NULL;
	F1383_13519(Current);
	RTLE;
}

/* {EV_DIALOG_I}.dialog_key_press_action */
void F1379_13405 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(RTCV(F291_4465(Current)) + _REFACS_1_);
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_29_);
		tb2 = (EIF_BOOLEAN)(tr1 == NULL);
	}
	if (tb2) {
		tr1 = F1299_12328(RTCW(loc2));
		tb1 = (EIF_BOOLEAN)(tr1 == NULL);
	}
	if (tb1) {
		loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 42L))) {
			tr1 = F1379_13395(Current);
			loc3 = tr1;
			tb1 = EIF_TEST(loc3);
		}
		if (tb1) {
			tb1 = F1211_10980(loc3);
			if (tb1) {
				tr1 = F1159_10302(loc3);
				F873_6795(RTCW(tr1), NULL);
			}
		} else {
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 41L))) {
				tr1 = F1379_13396(Current);
				loc4 = tr1;
				tb1 = EIF_TEST(loc4);
			}
			if (tb1) {
				tb1 = '\0';
				tb2 = F1211_10980(loc4);
				if (tb2) {
					tb2 = F1212_10998(loc4);
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) {
					tr1 = F1159_10302(loc4);
					F873_6795(RTCW(tr1), NULL);
				}
			}
		}
	}
	RTLE;
}

/* {EV_DIALOG_I}.set_current_push_button */
void F1379_13409 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = F1379_13396(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1244_11465(loc1);
	}
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb1 = F1244_11463(RTCW(arg1));
		if ((EIF_BOOLEAN) !tb1) {
			F1244_11464(RTCW(arg1));
		}
		if ((EIF_BOOLEAN)(arg1 != *(EIF_REFERENCE *)(Current + _REFACS_61_))) {
			RTAR(Current, arg1);
			*(EIF_REFERENCE *)(Current + _REFACS_63_) = (EIF_REFERENCE) arg1;
		} else {
			*(EIF_REFERENCE *)(Current + _REFACS_63_) = (EIF_REFERENCE) NULL;
		}
	} else {
		*(EIF_REFERENCE *)(Current + _REFACS_63_) = (EIF_REFERENCE) NULL;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_61_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F1244_11464(loc2);
		}
	}
	RTLE;
}

void EIF_Minit701 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
