/*
 * Code for class EV_WINDOW_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev702.h"
#include <stdlib.h>
#include <string.h>
#include <ev_gtk.h>
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F52_940
static EIF_POINTER inline_F52_940 (void)
{
	static char *v = "gtk-menu-bar-accel";
return (EIF_POINTER) v;
	;
}
#define INLINE_F52_940
#endif
#ifndef INLINE_F146_2818
static void inline_F146_2818 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	g_object_set ((gpointer) arg1, (gchar*) arg2, (gpointer) arg3, NULL)
	;
}
#define INLINE_F146_2818
#endif
#ifndef INLINE_F47_854
static EIF_NATURAL_8 inline_F47_854 (void)
{
	return GTK_ORIENTATION_VERTICAL
	;
}
#define INLINE_F47_854
#endif
#ifndef INLINE_F147_2949
static EIF_POINTER inline_F147_2949 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F147_2949
#endif
#ifndef INLINE_F47_853
static EIF_NATURAL_8 inline_F47_853 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F47_853
#endif
#ifndef INLINE_F146_2541
static void inline_F146_2541 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_window_set_accept_focus((GtkWindow*)arg1, (gboolean) arg2)
	;
}
#define INLINE_F146_2541
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WINDOW_IMP}.new_gtk_window */
EIF_POINTER F1380_13412 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) GTK_WINDOW_TOPLEVEL;
	Result = (EIF_POINTER) gtk_window_new((GtkWindowType) ti4_1);
	return Result;
}

/* {EV_WINDOW_IMP}.make */
void F1380_13413 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLIU(8);
	
	RTGC;
	F1274_11680(Current, (EIF_BOOLEAN) 0);
	loc1 = RTOSCF(12391,F1300_12391, (Current));
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R10825[dtype-1379])(Current);
	F1300_12366(Current, tp1);
	loc3 = *(EIF_POINTER *)(Current + O10102[dtype-1299]);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,843,0xFF01,1179,1067,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F844_6510(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O10784[dtype-1375]) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1218, 1).id);
	F1168_10363(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O10756[dtype-1375]) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1218, 1).id);
	F1168_10363(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O10757[dtype-1375]) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current + O10861[dtype-1379]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 32000L);
	*(EIF_INTEGER_32 *)(Current + O10860[dtype-1379]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 32000L);
	loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	F1380_13449(Current);
	tr1 = RTOSCF(806,F46_806, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1049,0xFF01,1010,1067,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = loc2;
	RTAR(tr2,loc2);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O7240[dtype-1005]);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,1121,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A409_334_3, (EIF_POINTER) _A409_334_3, (EIF_POINTER)(F1009_8374),tr2, 1, 1);
	}
	F1300_12371(Current, loc3, tr1, tr5);
	gtk_window_set_default_size((GtkWindow*) loc3, (gint) ((EIF_INTEGER_32) 1L), (gint) ((EIF_INTEGER_32) 1L));
	F1372_13255(Current);
	tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) loc3);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10179[dtype-1302])(Current);
	gdk_window_set_decorations((GdkWindow*) tp1, (GdkWMDecoration) ti4_1);
	*(EIF_BOOLEAN *)(Current + O10787[dtype-1375]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O10176[dtype-1301]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O10763[dtype-1375]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F1274_11680(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_WINDOW_IMP}.has_focus */
EIF_BOOLEAN F1380_13414 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current + O10832[Dtype(Current)-1379]);
}

/* {EV_WINDOW_IMP}.maximum_width */
EIF_INTEGER_32 F1380_13415 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O10861[Dtype(Current)-1379]);
}


/* {EV_WINDOW_IMP}.maximum_height */
EIF_INTEGER_32 F1380_13416 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O10860[Dtype(Current)-1379]);
}


/* {EV_WINDOW_IMP}.title */
EIF_REFERENCE F1380_13417 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O10102[Dtype(Current)-1299]);
	loc1 = (EIF_POINTER) gtk_window_get_title((GtkWindow*) tp1);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		loc2 = RTLNS(eif_new_type(992, 0x01).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
		F993_7489(RTCW(loc2), loc1);
		Result = F993_7485(RTCW(loc2));
		tr1 = RTMS_EX_H("\011",1,9);
		tb1 = F1129_9828(RTCW(Result), tr1);
		if (tb1) {
			Result = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1129_9783(RTCW(Result));
			RTLE;
			return (EIF_REFERENCE) Result;
		}
	} else {
		Result = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1129_9783(RTCW(Result));
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_WINDOW_IMP}.add_transient_child */
void F1380_13419 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg1) + O10102[Dtype(arg1)-1299]);
	tp2 = *(EIF_POINTER *)(Current + O10102[Dtype(Current)-1299]);
	gtk_window_set_transient_for((GtkWindow*) tp1, (GtkWindow*) tp2);
	RTLE;
}

/* {EV_WINDOW_IMP}.remove_transient_child */
void F1380_13420 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg1) + O10102[Dtype(arg1)-1299]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	gtk_window_set_transient_for((GtkWindow*) tp1, (GtkWindow*) tp3);
	RTLE;
}

/* {EV_WINDOW_IMP}.internal_enable_border */
void F1380_13422 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10179[dtype-1302])(Current);
	ti4_2 = (EIF_INTEGER_32) GDK_DECOR_BORDER;
	loc1 = eif_bit_or(ti4_1,ti4_2);
	tp1 = *(EIF_POINTER *)(Current + O10102[dtype-1299]);
	tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
	gdk_window_set_decorations((GdkWindow*) tp1, (GdkWMDecoration) loc1);
	RTLE;
}

/* {EV_WINDOW_IMP}.disable_user_resize */
void F1380_13424 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O10828[dtype-1379]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O10763[dtype-1375]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10574[dtype-1365])(Current)) {
		F1302_12464(Current);
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.allow_resize */
void F1380_13426 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (EIF_POINTER) calloc (sizeof(GdkGeometry), 1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O10861[dtype-1379]);
	(((GdkGeometry *)loc1)->max_width = (gint)(ti4_1));
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O10860[dtype-1379]);
	(((GdkGeometry *)loc1)->max_height = (gint)(ti4_1));
	ti4_1 = F1301_12399(Current);
	(((GdkGeometry *)loc1)->min_width = (gint)(ti4_1));
	ti4_1 = F1301_12400(Current);
	(((GdkGeometry *)loc1)->min_height = (gint)(ti4_1));
	tp1 = *(EIF_POINTER *)(Current + O10102[dtype-1299]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	ti4_1 = (EIF_INTEGER_32) GDK_HINT_MAX_SIZE;
	ti4_2 = (EIF_INTEGER_32) GDK_HINT_MIN_SIZE;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	gtk_window_set_geometry_hints((GtkWindow*) tp1, (GtkWidget*) tp3, (GdkGeometry*) loc1, (GdkWindowHints) ti4_1);
	free(loc1);
	F1380_13422(Current);
	RTLE;
}

/* {EV_WINDOW_IMP}.show */
void F1380_13427 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1301_12422(Current)) {
		*(EIF_BOOLEAN *)(Current + O10829[dtype-1379]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		if (*(EIF_BOOLEAN *)(Current + O10828[dtype-1379])) {
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O10763[dtype-1375])) {
				F1302_12464(Current);
			} else {
				F1380_13426(Current);
			}
		}
		F1302_12451(Current);
	}
	if ((EIF_BOOLEAN)(F1302_12431(Current) != NULL)) {
		F1302_12430(Current, NULL);
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.hide */
void F1380_13430 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (F1301_12422(Current)) {
		*(EIF_BOOLEAN *)(Current + O10830[dtype-1379]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		F1351_12954(Current);
		F1302_12452(Current);
		if (*(EIF_BOOLEAN *)(Current + O10828[dtype-1379])) {
			F1380_13426(Current);
		}
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.set_title */
void F1380_13433 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = F1129_9842(RTCW(arg1));
	tb1 = F554_5957(RTCW(loc1));
	if (tb1) {
		loc1 = F1129_9842(RTMS_EX_H("\011",1,9));
	}
	loc2 = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F993_7487(RTCW(loc2), loc1);
	tp1 = *(EIF_POINTER *)(Current + O10102[Dtype(Current)-1299]);
	tp2 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_0_1_0_1_0_0_);
	gtk_window_set_title((GtkWindow*) tp1, (gchar*) tp2);
	RTLE;
}

/* {EV_WINDOW_IMP}.connect_accelerator */
RTEOMS(13435,4);
void F1380_13436 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = RTRV(eif_new_type(1296, 0x00), loc1);
	RTCT0("acc_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O10784[Dtype(Current)-1375]);
	ti4_1 = F1296_12094(RTCW(loc1));
	F844_6556(RTCW(tr1), arg1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 36L))) {
		loc3 = (EIF_REFERENCE) RTOMS(13435,0);
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 37L))) {
			loc3 = (EIF_REFERENCE) RTOMS(13435,1);
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_0_0_0_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 38L))) {
				loc3 = (EIF_REFERENCE) RTOMS(13435,2);
			}
		}
	}
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		loc2 = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
		tr1 = F1137_10212(RTOMS(13435,3), loc3);
		F993_7487(RTCW(loc2), tr1);
		tp1 = RTOSCF(8341,F1007_8341, (RTCV(RTOSCF(12391,F1300_12391, (Current)))));
		tp2 = inline_F52_940();
		tp3 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_0_1_0_1_0_0_);
		inline_F146_2818(tp1, tp2, tp3);
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.disconnect_accelerator */
void F1380_13437 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = RTRV(eif_new_type(1296, 0x00), loc1);
	RTCT0("acc_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O10784[Dtype(Current)-1375]);
	ti4_1 = F1296_12094(RTCW(loc1));
	F844_6562(RTCW(tr1), ti4_1);
	RTLE;
}

/* {EV_WINDOW_IMP}.destroy */
void F1380_13438 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1351_12954(Current);
	F1380_13430(Current);
	F1302_12453(Current);
	F1355_13105(Current);
	RTLE;
}

/* {EV_WINDOW_IMP}.on_widget_mapped */
void F1380_13439 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1353_13048(Current);
	F1380_13440(Current);
	RTLE;
}

/* {EV_WINDOW_IMP}.process_show_actions */
void F1380_13440 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O3356[dtype-161]) != NULL) && *(EIF_BOOLEAN *)(Current + O10829[dtype-1379]))) {
		tr1 = *(EIF_REFERENCE *)(Current + O3356[dtype-161]);
		F873_6795(RTCW(tr1), NULL);
	}
	*(EIF_BOOLEAN *)(Current + O10829[dtype-1379]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {EV_WINDOW_IMP}.on_widget_hidden */
void F1380_13441 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1353_13050(Current);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O3358[dtype-161]) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + O3358[dtype-161]);
		F873_6795(RTCW(tr1), NULL);
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.set_focused_widget */
void F1380_13445 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tp1 = *(EIF_POINTER *)(RTCW(arg1) + O10102[Dtype(arg1)-1299]);
		*(EIF_POINTER *)(Current + O10834[dtype-1379]) = (EIF_POINTER) tp1;
	} else {
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current + O10834[dtype-1379]) = (EIF_POINTER) tp2;
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.client_area */
EIF_POINTER F1380_13448 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) *(EIF_POINTER *)(Current + O10102[Dtype(Current)-1299]);
}

/* {EV_WINDOW_IMP}.initialize_client_area */
void F1380_13449 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tu1_1 = inline_F47_854();
	tp1 = inline_F147_2949(tu1_1, ((EIF_INTEGER_32) 0L));
	*(EIF_POINTER *)(Current + O10857[dtype-1379]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O10857[dtype-1379]);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R10838[dtype-1379])(Current);
	tp2 = *(EIF_POINTER *)(Current + O10857[dtype-1379]);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) tp2);
	tu1_1 = inline_F47_853();
	tp1 = inline_F147_2949(tu1_1, ((EIF_INTEGER_32) 0L));
	*(EIF_POINTER *)(Current + O10858[dtype-1379]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O10858[dtype-1379]);
	gtk_box_set_homogeneous((GtkBox*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	tp1 = *(EIF_POINTER *)(Current + O10858[dtype-1379]);
	gtk_widget_show((GtkWidget*) tp1);
	tr1 = *(EIF_REFERENCE *)(Current + O10756[dtype-1375]);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1366, 0x00), loc1);
	RTCT0("bar_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = *(EIF_POINTER *)(Current + O10857[dtype-1379]);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_49_13_10_7_0_0_);
	gtk_box_pack_start((GtkBox*) tp1, (GtkWidget*) tp2, (gboolean) (EIF_BOOLEAN) 0, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	tp1 = *(EIF_POINTER *)(Current + O10857[dtype-1379]);
	tp2 = *(EIF_POINTER *)(Current + O10858[dtype-1379]);
	gtk_box_pack_start((GtkBox*) tp1, (GtkWidget*) tp2, (gboolean) (EIF_BOOLEAN) 1, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + O10757[dtype-1375]);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1366, 0x00), loc1);
	RTCT0("bar_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = *(EIF_POINTER *)(Current + O10857[dtype-1379]);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_49_13_10_7_0_0_);
	gtk_box_pack_start((GtkBox*) tp1, (GtkWidget*) tp2, (gboolean) (EIF_BOOLEAN) 0, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(12391,F1300_12391, (Current))) + _REFACS_43_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O7240[dtype-1005]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5613[Dtype(RTCW(tr1))-692])(tr1, (EIF_REFERENCE) &ti4_1);
	RTLE;
}

/* {EV_WINDOW_IMP}.on_size_allocate */
void F1380_13450 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc3 = F1302_12444(Current);
	loc4 = F1302_12445(Current);
	loc1 = F1302_12446(Current);
	loc2 = F1302_12448(Current);
	F1302_12463(Current, loc1, loc2, loc3, loc4);
	F1353_13019(Current, loc1, loc2, loc3, loc4);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != *(EIF_INTEGER_32 *)(Current + O10836[dtype-1379])) || (EIF_BOOLEAN)(loc2 != *(EIF_INTEGER_32 *)(Current + O10837[dtype-1379])))) {
		*(EIF_INTEGER_32 *)(Current + O10836[dtype-1379]) = (EIF_INTEGER_32) loc1;
		*(EIF_INTEGER_32 *)(Current + O10837[dtype-1379]) = (EIF_INTEGER_32) loc2;
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O3354[dtype-161]) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O3354[dtype-161]);
			tr2 = *(EIF_REFERENCE *)(RTCV(RTOSCF(12391,F1300_12391, (Current))) + _REFACS_42_);
			tr2 = F1011_8403(RTCW(tr2), loc1, loc2, loc3, loc4);
			F873_6795(RTCW(tr1), tr2);
		}
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.call_window_state_event */
void F1380_13451 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	RTGC;
}

/* {EV_WINDOW_IMP}.on_set_focus_event */
void F1380_13452 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(12391,F1300_12391, (Current));
	loc2 = F1299_12343(RTCW(tr1), arg1);
	loc2 = RTRV(eif_new_type(1352, 0x00), loc2);
	tr1 = RTOSCF(12391,F1300_12391, (Current));
	loc1 = F1299_12343(RTCW(tr1), *(EIF_POINTER *)(Current + O10834[Dtype(Current)-1379]));
	loc1 = RTRV(eif_new_type(1352, 0x00), loc1);
	F1380_13445(Current, loc2);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) R10600[Dtype(RTCW(loc2))-1365])(loc2, (EIF_BOOLEAN) 1);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && (EIF_BOOLEAN)(loc1 != loc2))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) R10600[Dtype(RTCW(loc1))-1365])(loc1, (EIF_BOOLEAN) 0);
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.increase_modal_window_count */
void F1380_13454 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O10842[dtype-1379]) == ((EIF_INTEGER_32) 0L))) {
		F1380_13458(Current);
	}
	(*(EIF_INTEGER_32 *)(Current + O10842[dtype-1379]))++;
	RTLE;
}

/* {EV_WINDOW_IMP}.decrease_modal_window_count */
void F1380_13455 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current + O10842[dtype-1379]))--;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O10842[dtype-1379]) == ((EIF_INTEGER_32) 0L))) {
		F1380_13457(Current);
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.has_modal_window */
EIF_BOOLEAN F1380_13456 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O10842[Dtype(Current)-1379]) > ((EIF_INTEGER_32) 0L));
}

/* {EV_WINDOW_IMP}.allow_window_manager_focus */
void F1380_13457 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O10102[Dtype(Current)-1299]);
	inline_F146_2541(tp1, (EIF_BOOLEAN) 1);
}

/* {EV_WINDOW_IMP}.disallow_window_manager_focus */
void F1380_13458 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O10102[Dtype(Current)-1299]);
	inline_F146_2541(tp1, (EIF_BOOLEAN) 0);
}

/* {EV_WINDOW_IMP}.on_focus_changed */
void F1380_13468 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O10832[dtype-1379]) = (EIF_BOOLEAN) arg1;
	F1353_13020(Current, arg1);
	if (arg1) {
		tp1 = *(EIF_POINTER *)(Current + O10102[dtype-1299]);
		loc1 = (EIF_POINTER) gtk_window_get_focus((GtkWindow*) tp1);
		if ((EIF_BOOLEAN)(loc1 != *(EIF_POINTER *)(Current + O10102[dtype-1299]))) {
			F1380_13452(Current, loc1);
		} else {
			{
				/* INLINED CODE (ANY.do_nothing) */
				/* END INLINED CODE */
			}
			;
		}
	} else {
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		F1380_13452(Current, tp2);
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.call_close_request_actions */
void F1380_13470 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O3352[dtype-161]) != NULL)) {
		tb4 = F1299_12327(RTCV(RTOSCF(12391,F1300_12391, (Current))));
		tb3 = (EIF_BOOLEAN) !tb4;
	}
	if (tb3) {
		tb2 = (EIF_BOOLEAN) !F1380_13456(Current);
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !F1274_11665(Current);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + O3352[dtype-161]);
		F873_6795(RTCW(tr1), NULL);
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.container_widget */
EIF_POINTER F1380_13471 (EIF_REFERENCE Current)
{
	return *(EIF_POINTER *)(Current + O10858[Dtype(Current)-1379]);
}


void EIF_Minit702 (void)
{
	GTCX
	RTPOMS(13435,3,"<Shift><Control><Mod1><Mod2><Mod3><Mod4><Mod5>",46,1367187518);
	RTPOMS(13435,2,"F12",3,4600114);
	RTPOMS(13435,1,"F11",3,4600113);
	RTPOMS(13435,0,"F10",3,4600112);
}


#ifdef __cplusplus
}
#endif
