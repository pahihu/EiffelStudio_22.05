/*
 * Code for class EV_LABEL_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev729.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F52_933
static EIF_POINTER inline_F52_933 (void)
{
	static char *v = "justify";
return (EIF_POINTER) v;
	;
}
#define INLINE_F52_933
#endif
#ifndef INLINE_F146_2822
static EIF_INTEGER_32 inline_F146_2822 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gint v;
g_object_get ((gpointer) arg1, (const gchar *) arg2, &v, NULL);
return (EIF_INTEGER) v;
	;
}
#define INLINE_F146_2822
#endif
#ifndef INLINE_F148_3165
static void inline_F148_3165 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_xalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F148_3165
#endif
#ifndef INLINE_F148_3166
static void inline_F148_3166 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_yalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F148_3166
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_LABEL_IMP}.make */
void F1407_13893 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1337_12789(Current);
	F1300_12366(Current, *(EIF_POINTER *)(Current+ _PTROFF_44_13_10_6_1_1_));
	F1337_12792(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_13_10_6_1_1_);
	tp2 = inline_F52_933();
	loc1 = inline_F146_2822(tp1, tp2);
	F1402_13722(Current);
	F1274_11680(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_LABEL_IMP}.align_text_top */
void F1407_13896 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REAL_32 tr4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_13_10_6_1_1_);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	inline_F148_3165(tp1, tr4_1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_13_10_6_1_1_);
	inline_F148_3166(tp1, (EIF_REAL_32) (EIF_REAL_64) 0.5);
	RTLE;
}

/* {EV_LABEL_IMP}.align_text_vertical_center */
void F1407_13897 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_13_10_6_1_1_);
	inline_F148_3165(tp1, (EIF_REAL_32) (EIF_REAL_64) 0.5);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_44_13_10_6_1_1_);
	inline_F148_3166(tp1, (EIF_REAL_32) (EIF_REAL_64) 0.5);
	RTLE;
}

/* {EV_LABEL_IMP}.style_element_name */
EIF_REFERENCE F1407_13899 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTMS_EX_H("label",5,1634667884);
	RTLE;
	return Result;
}

/* {EV_LABEL_IMP}.needs_event_box */
EIF_BOOLEAN F1407_13900 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

void EIF_Minit729 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
