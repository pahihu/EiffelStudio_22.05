
#ifndef _C15_ev742_
#define _C15_ev742_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1420_14199(EIF_REFERENCE);
extern void EIF_Minit742(void);
extern char *(*R11203[])();
extern long O9576[];

#ifdef __cplusplus
}
#endif

#endif
