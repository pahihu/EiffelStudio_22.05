/*
 * Code for class EV_LIST_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev736.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F146_2701
static void inline_F146_2701 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_tree_view_set_headers_visible ((GtkTreeView*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F146_2701
#endif
#ifndef INLINE_F146_2753
static EIF_POINTER inline_F146_2753 (void)
{
	return (EIF_POINTER) (gtk_tree_view_column_new())
	;
}
#define INLINE_F146_2753
#endif
#ifndef INLINE_F146_2734
static void inline_F146_2734 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_tree_view_column_set_resizable ((GtkTreeViewColumn*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F146_2734
#endif
#ifndef INLINE_F146_2744
static EIF_POINTER inline_F146_2744 (void)
{
	return (EIF_POINTER) (gtk_cell_renderer_text_new())
	;
}
#define INLINE_F146_2744
#endif
#ifndef INLINE_F146_2756
static void inline_F146_2756 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	gtk_tree_view_column_pack_end ((GtkTreeViewColumn*) arg1, (GtkCellRenderer*) arg2, (gboolean) arg3)
	;
}
#define INLINE_F146_2756
#endif
#ifndef INLINE_F146_2743
static void inline_F146_2743 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4)
{
	gtk_tree_view_column_add_attribute ((GtkTreeViewColumn*) arg1, (GtkCellRenderer*) arg2, (gchar*) arg3, (gint) arg4)
	;
}
#define INLINE_F146_2743
#endif
#ifndef INLINE_F146_2745
static EIF_POINTER inline_F146_2745 (void)
{
	return (EIF_POINTER) (gtk_cell_renderer_pixbuf_new())
	;
}
#define INLINE_F146_2745
#endif
#ifndef INLINE_F146_2750
static void inline_F146_2750 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	gtk_tree_view_insert_column ((GtkTreeView*) arg1, (GtkTreeViewColumn*) arg2, (gint) arg3)
	;
}
#define INLINE_F146_2750
#endif
#ifndef INLINE_F146_2727
static EIF_POINTER inline_F146_2727 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_tree_view_get_selection ((GtkTreeView*) arg1))
	;
}
#define INLINE_F146_2727
#endif
#ifndef INLINE_F146_2710
static EIF_POINTER inline_F146_2710 (EIF_POINTER arg1, EIF_POINTER* arg2)
{
	return (EIF_POINTER) (gtk_tree_selection_get_selected_rows ((GtkTreeSelection*) arg1, (GtkTreeModel**) arg2))
	;
}
#define INLINE_F146_2710
#endif
#ifndef INLINE_F146_2635
static void inline_F146_2635 (EIF_POINTER arg1)
{
	g_list_foreach ((GList*) arg1, (GFunc) gtk_tree_path_free, NULL)
	;
}
#define INLINE_F146_2635
#endif
#ifndef INLINE_F146_2715
static void inline_F146_2715 (EIF_POINTER arg1)
{
	gtk_tree_selection_unselect_all ((GtkTreeSelection*) arg1)
	;
}
#define INLINE_F146_2715
#endif
#ifndef INLINE_F146_2695
static int inline_F146_2695 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4, EIF_POINTER arg5, EIF_POINTER arg6, EIF_POINTER arg7)
{
	return (int) (gtk_tree_view_get_path_at_pos ((GtkTreeView*) arg1, (gint) arg2, (gint) arg3, (GtkTreePath**) arg4, (GtkTreeViewColumn**) arg5, (gint*) arg6, (gint*) arg7))
	;
}
#define INLINE_F146_2695
#endif
#ifndef INLINE_F146_2694
static void inline_F146_2694 (EIF_POINTER arg1)
{
	gtk_tree_path_free ((GtkTreePath*) arg1)
	;
}
#define INLINE_F146_2694
#endif
#ifndef INLINE_F146_2724
static EIF_POINTER inline_F146_2724 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_tree_view_get_column ((GtkTreeView*) arg1, (gint) arg2))
	;
}
#define INLINE_F146_2724
#endif
#ifndef INLINE_F146_2656
static void inline_F146_2656 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	gtk_widget_style_get ((GtkWidget*) arg1, (gchar*) arg2, (gint*) arg3, NULL);
	;
}
#define INLINE_F146_2656
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_LIST_IMP}.make */
void F1414_14129 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp3 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp4 = tp3;
	tp1 = (EIF_POINTER) gtk_scrolled_window_new((GtkAdjustment*) tp2, (GtkAdjustment*) tp4);
	*(EIF_POINTER *)(Current + O11192[dtype-1413]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O11192[dtype-1413]);
	ti4_1 = (EIF_INTEGER_32) GTK_SHADOW_IN;
	gtk_scrolled_window_set_shadow_type((GtkScrolledWindow*) tp1, (GtkShadowType) ti4_1);
	F1300_12366(Current, *(EIF_POINTER *)(Current + O11192[dtype-1413]));
	tp1 = (EIF_POINTER) gtk_tree_view_new();
	*(EIF_POINTER *)(Current + O11195[dtype-1413]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O11192[dtype-1413]);
	tp2 = *(EIF_POINTER *)(Current + O11195[dtype-1413]);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) tp2);
	F1412_14073(Current);
	tp1 = *(EIF_POINTER *)(Current + O11195[dtype-1413]);
	tp2 = *(EIF_POINTER *)(Current + O11180[dtype-1411]);
	gtk_tree_view_set_model((GtkTreeView*) tp1, (GtkTreeModel*) tp2);
	tp1 = *(EIF_POINTER *)(Current + O11192[dtype-1413]);
	ti4_1 = (EIF_INTEGER_32) GTK_POLICY_AUTOMATIC;
	ti4_2 = (EIF_INTEGER_32) GTK_POLICY_AUTOMATIC;
	gtk_scrolled_window_set_policy((GtkScrolledWindow*) tp1, (GtkPolicyType) ti4_1, (GtkPolicyType) ti4_2);
	tp1 = *(EIF_POINTER *)(Current + O11195[dtype-1413]);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current + O11195[dtype-1413]);
	inline_F146_2701(tp1, (EIF_BOOLEAN) 0);
	loc1 = inline_F146_2753();
	inline_F146_2734(loc1, (EIF_BOOLEAN) 1);
	loc2 = inline_F146_2744();
	inline_F146_2756(loc1, loc2, (EIF_BOOLEAN) 1);
	loc3 = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr1 = RTMS_EX_H("text",4,1952807028);
	F993_7487(RTCW(loc3), tr1);
	tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	inline_F146_2743(loc1, loc2, tp1, ((EIF_INTEGER_32) 1L));
	loc2 = inline_F146_2745();
	inline_F146_2756(loc1, loc2, (EIF_BOOLEAN) 0);
	loc3 = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr1 = RTMS_EX_H("pixbuf",6,93246054);
	F993_7487(RTCW(loc3), tr1);
	tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	inline_F146_2743(loc1, loc2, tp1, ((EIF_INTEGER_32) 0L));
	tp1 = *(EIF_POINTER *)(Current + O11195[dtype-1413]);
	inline_F146_2750(tp1, loc1, ((EIF_INTEGER_32) 1L));
	tr1 = F1414_14132(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11194[dtype-1413]) = (EIF_REFERENCE) tr1;
	tp1 = *(EIF_POINTER *)(Current + O11195[dtype-1413]);
	loc4 = inline_F146_2727(tp1);
	tr1 = RTOSCF(823,F46_823, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1049,0xFF01,1010,1067,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(12391,F1300_12391, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O7240[dtype-1005]);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,0,1049,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A409_320, (EIF_POINTER) _A409_320, (EIF_POINTER)(F1008_8359),tr2, 1, 0);
	}
	F1300_12370(Current, loc4, tr1, tr3);
	F1322_12717(Current);
	RTLE;
}

/* {EV_LIST_IMP}.needs_event_box */
EIF_BOOLEAN F1414_14130 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {EV_LIST_IMP}.selected_items */
EIF_REFERENCE F1414_14132 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc6);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,849,0xFF01,1249,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 849, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F850_6641(RTCW(Result), ((EIF_INTEGER_32) 0L));
	tp1 = *(EIF_POINTER *)(Current + O11195[dtype-1413]);
	loc1 = inline_F146_2727(tp1);
	loc2 = inline_F146_2710(loc1, (EIF_POINTER *) &(loc3));
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc2 != tp1)) {
		for (;;) {
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			if ((EIF_BOOLEAN)(loc2 == tp1)) break;
			loc4 = (EIF_POINTER) (((GList *)loc2)->data);
			loc5 = (EIF_POINTER) gtk_tree_path_get_indices((GtkTreePath*) loc4);
			loc6 = RTLNS(eif_new_type(996, 0x01).id, 996, _OBJSIZ_0_1_0_1_0_1_1_0_);
			F997_7582(RTCW(loc6), loc5, ((EIF_INTEGER_32) 4L));
			tr1 = *(EIF_REFERENCE *)(Current + O10266[dtype-1305]);
			ti4_1 = F997_7596(RTCW(loc6), ((EIF_INTEGER_32) 0L));
			tr1 = F850_6648(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5613[Dtype(RTCW(Result))-692])(Result, tr1);
			tp2 = (EIF_POINTER) (((GList *)loc2)->next);
			loc2 = (EIF_POINTER) tp2;
		}
		inline_F146_2635(loc2);
		g_list_free((GList*) loc2);
	}
	RTLE;
	return Result;
}

/* {EV_LIST_IMP}.clear_selection */
void F1414_14139 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O11195[Dtype(Current)-1413]);
	loc1 = inline_F146_2727(tp1);
	inline_F146_2715(loc1);
	RTLE;
}

/* {EV_LIST_IMP}.row_index_from_coords */
EIF_INTEGER_32 F1414_14140 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_POINTER tp5;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O11195[Dtype(Current)-1413]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp4 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp5 = tp4;
	loc3 = EIF_TEST (inline_F146_2695(tp1, ((EIF_INTEGER_32) 1L), arg2, (EIF_POINTER *) &(loc1), (EIF_POINTER *) &(loc2), tp3, tp5));
	if (loc3) {
		loc4 = (EIF_POINTER) gtk_tree_path_get_indices((GtkTreePath*) loc1);
		loc5 = RTLNS(eif_new_type(996, 0x01).id, 996, _OBJSIZ_0_1_0_1_0_1_1_0_);
		F997_7582(RTCW(loc5), loc4, ((EIF_INTEGER_32) 4L));
		Result = F997_7596(RTCW(loc5), ((EIF_INTEGER_32) 0L));
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
		inline_F146_2694(loc1);
	}
	RTLE;
	return Result;
}

/* {EV_LIST_IMP}.item_from_coords */
EIF_REFERENCE F1414_14141 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = F1414_14140(Current, arg1, arg2);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = F1306_12549(Current, loc1);
		Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		RTLE;
		return RTRV(eif_new_type(1328, 0x00), Result);
	}
	RTLE;
	return Result;
}

/* {EV_LIST_IMP}.on_mouse_button_event */
void F1414_14142 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	loc1 = F1414_14140(Current, arg2, arg3);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		tr2 = F1306_12549(Current, loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_3_);
		*(EIF_REFERENCE *)(Current + O11171[dtype-1411]) = RTRV(eif_new_type(1422, 0), tr1);
		RTAR(Current, tr1);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + O11171[dtype-1411]);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tb2 = '\01';
			tb3 = F1423_14211(loc2, arg4);
			if (!tb3) {
				tb3 = F1350_12923(loc2);
				tb2 = tb3;
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			*(EIF_REFERENCE *)(Current + O11171[dtype-1411]) = (EIF_REFERENCE) NULL;
		}
	} else {
		*(EIF_REFERENCE *)(Current + O11171[dtype-1411]) = (EIF_REFERENCE) NULL;
	}
	F1351_12968(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
	RTLE;
}

/* {EV_LIST_IMP}.row_height */
RTEOMS(14142,1);
EIF_INTEGER_32 F1414_14143 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O11195[dtype-1413]);
	loc1 = inline_F146_2724(tp1, ((EIF_INTEGER_32) 0L));
	loc2 = (EIF_POINTER) gtk_cell_layout_get_cells((GtkCellLayout*) loc1);
	loc3 = (EIF_POINTER) g_list_nth_data((GList*) loc2, (guint) ((EIF_INTEGER_32) 0L));
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	gtk_cell_renderer_get_fixed_size((GtkCellRenderer*) loc3, (gint*) tp2, (gint*) (EIF_INTEGER_32 *) &(Result));
	loc4 = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F993_7487(RTCW(loc4), RTOMS(14142,0));
	tp1 = *(EIF_POINTER *)(Current + O11195[dtype-1413]);
	tp2 = *(EIF_POINTER *)(RTCW(loc4)+ _PTROFF_0_1_0_1_0_0_);
	inline_F146_2656(tp1, tp2, (EIF_INTEGER_32 *) &(loc5));
	RTLE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + loc5);
}

/* {EV_LIST_IMP}.visual_widget */
EIF_POINTER F1414_14144 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) *(EIF_POINTER *)(Current + O11195[Dtype(Current)-1413]);
}

/* {EV_LIST_IMP}.call_selection_action_sequences */
void F1414_14147 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	loc1 = F1414_14132(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,849,0xFF01,1422,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc2 = RTLNS(typres0.id, 849, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F850_6641(RTCW(loc2), ((EIF_INTEGER_32) 0L));
	F850_6672(RTCW(loc1));
	for (;;) {
		tb1 = F645_6087(RTCW(loc1));
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + O11194[dtype-1413]);
		tr2 = F850_6646(RTCW(loc1));
		tb2 = F850_6653(RTCW(tr1), tr2);
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = F850_6646(RTCW(loc1));
			loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
			loc3 = RTRV(eif_new_type(1422, 0x00), loc3);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5613[Dtype(RTCW(loc2))-692])(loc2, loc3);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + O11194[dtype-1413]);
		tr2 = F850_6646(RTCW(loc1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5616[Dtype(RTCW(tr1))-642])(tr1, tr2);
		F850_6674(RTCW(loc1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + O11194[dtype-1413]);
	F850_6672(RTCW(tr1));
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + O11194[dtype-1413]);
		tb2 = F645_6087(RTCW(tr1));
		if (tb2) break;
		tr1 = *(EIF_REFERENCE *)(Current + O11194[dtype-1413]);
		tr1 = F850_6646(RTCW(tr1));
		loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		loc3 = RTRV(eif_new_type(1422, 0x00), loc3);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_4_);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				tr1 = F158_3310(RTCW(loc3));
				F873_6795(RTCW(tr1), NULL);
			}
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1049,0xFF01,1249,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr2 = RTLNTS(typres0.id, 2, 0);
				}
				tr3 = F1274_11666(RTCW(loc3));
				((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
				RTAR(tr2,tr3);
				F873_6795(RTCW(tr1), tr2);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + O11194[dtype-1413]);
		F850_6674(RTCW(tr1));
	}
	F850_6672(RTCW(loc2));
	for (;;) {
		tb3 = F645_6087(RTCW(loc2));
		if (tb3) break;
		tr1 = F850_6646(RTCW(loc2));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F850_6646(RTCW(loc2));
			tr1 = F158_3308(RTCW(tr1));
			F873_6795(RTCW(tr1), NULL);
		}
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1049,0xFF01,1249,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F850_6646(RTCW(loc2));
			tr3 = F1274_11666(RTCW(tr3));
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			F873_6795(RTCW(tr1), tr2);
		}
		F850_6674(RTCW(loc2));
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + O11194[dtype-1413]) = (EIF_REFERENCE) loc1;
	RTLE;
}

void EIF_Minit736 (void)
{
	GTCX
	RTPOMS(14142,0,"vertical-separator",18,1613565554);
}


#ifdef __cplusplus
}
#endif
