/*
 * Code for class EV_BUTTON_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev738.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F47_853
static EIF_NATURAL_8 inline_F47_853 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F47_853
#endif
#ifndef INLINE_F147_2949
static EIF_POINTER inline_F147_2949 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F147_2949
#endif
#ifndef INLINE_F40_659
static EIF_INTEGER_32 inline_F40_659 (void)
{
	return GTK_ALIGN_START
	;
}
#define INLINE_F40_659
#endif
#ifndef INLINE_F147_2936
static void inline_F147_2936 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return gtk_widget_set_halign ((GtkWidget *)arg1, (GtkAlign)arg2)
	;
}
#define INLINE_F147_2936
#endif
#ifndef INLINE_F147_2939
static void inline_F147_2939 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return gtk_widget_set_valign ((GtkWidget *)arg1, (GtkAlign)arg2)
	;
}
#define INLINE_F147_2939
#endif
#ifndef INLINE_F147_2941
static void inline_F147_2941 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_widget_set_margin_start ((GtkWidget *)arg1, (gint)arg2)
	;
}
#define INLINE_F147_2941
#endif
#ifndef INLINE_F147_2943
static void inline_F147_2943 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_widget_set_margin_end ((GtkWidget *)arg1, (gint)arg2)
	;
}
#define INLINE_F147_2943
#endif
#ifndef INLINE_F40_661
static EIF_INTEGER_32 inline_F40_661 (void)
{
	return GTK_ALIGN_CENTER
	;
}
#define INLINE_F40_661
#endif
#ifndef INLINE_F148_3033
static void inline_F148_3033 (EIF_POINTER arg1)
{
	gtk_widget_queue_draw ((GtkWidget *)arg1)
	;
}
#define INLINE_F148_3033
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_BUTTON_IMP}.new_gtk_button */
EIF_POINTER F1416_14161 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) (EIF_POINTER) gtk_button_new();
}

/* {EV_BUTTON_IMP}.make */
void F1416_14162 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R11198[Dtype(Current)-1415])(Current);
	F1300_12366(Current, tp1);
	F1333_12767(Current);
	F1337_12789(Current);
	F1416_14163(Current);
	F1416_14168(Current);
	F1402_13722(Current);
	RTLE;
}

/* {EV_BUTTON_IMP}.initialize_button_box */
void F1416_14163 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = inline_F47_853();
	loc1 = inline_F147_2949(tu1_1, ((EIF_INTEGER_32) 0L));
	tp1 = F1300_12390(Current);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) loc1);
	ti4_1 = inline_F40_659();
	inline_F147_2936(loc1, ti4_1);
	ti4_1 = inline_F40_659();
	inline_F147_2939(loc1, ti4_1);
	gtk_widget_set_hexpand((GtkWidget*) loc1, (gboolean) (EIF_BOOLEAN) 0);
	gtk_widget_set_vexpand((GtkWidget*) loc1, (gboolean) (EIF_BOOLEAN) 0);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_1_);
	gtk_container_add((GtkContainer*) loc1, (GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
	ti4_1 = inline_F40_659();
	inline_F147_2936(tp1, ti4_1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
	inline_F147_2941(tp1, ((EIF_INTEGER_32) 4L));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
	inline_F147_2943(tp1, ((EIF_INTEGER_32) 4L));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
	gtk_container_add((GtkContainer*) loc1, (GtkWidget*) tp1);
	gtk_widget_show((GtkWidget*) loc1);
	RTLE;
}

/* {EV_BUTTON_IMP}.fontable_widget */
EIF_POINTER F1416_14164 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
}

/* {EV_BUTTON_IMP}.event_widget */
EIF_POINTER F1416_14165 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) F1300_12390(Current);
}

/* {EV_BUTTON_IMP}.needs_event_box */
EIF_BOOLEAN F1416_14166 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_BUTTON_IMP}.is_default_push_button */
EIF_BOOLEAN F1416_14167 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_46_11_);
}


/* {EV_BUTTON_IMP}.align_text_center */
void F1416_14168 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1337_12792(Current);
	tp1 = F1416_14177(Current);
	ti4_1 = inline_F40_661();
	inline_F147_2936(tp1, ti4_1);
	tp1 = F1416_14177(Current);
	ti4_1 = inline_F40_661();
	inline_F147_2939(tp1, ti4_1);
	tp1 = F1416_14177(Current);
	gtk_widget_set_hexpand((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	tp1 = F1416_14177(Current);
	gtk_widget_set_vexpand((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	RTLE;
}

/* {EV_BUTTON_IMP}.align_text_left */
void F1416_14169 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1337_12793(Current);
	tp1 = F1416_14177(Current);
	ti4_1 = inline_F40_659();
	inline_F147_2936(tp1, ti4_1);
	tp1 = F1416_14177(Current);
	ti4_1 = inline_F40_661();
	inline_F147_2939(tp1, ti4_1);
	tp1 = F1416_14177(Current);
	gtk_widget_set_hexpand((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	tp1 = F1416_14177(Current);
	gtk_widget_set_vexpand((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	RTLE;
}

/* {EV_BUTTON_IMP}.enable_default_push_button */
void F1416_14171 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1416_14173(Current);
}

/* {EV_BUTTON_IMP}.disable_default_push_button */
void F1416_14172 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_46_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tp1 = F1300_12390(Current);
	gtk_widget_set_can_default((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	tp1 = F1300_12390(Current);
	inline_F148_3033(tp1);
	F1353_13044(Current);
	RTLE;
}

/* {EV_BUTTON_IMP}.enable_can_default */
void F1416_14173 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_46_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tp1 = F1300_12390(Current);
	gtk_widget_set_can_default((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	tp1 = F1300_12390(Current);
	inline_F148_3033(tp1);
	F1353_13044(Current);
	RTLE;
}

/* {EV_BUTTON_IMP}.set_foreground_color */
void F1416_14174 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1313_12589(Current, arg1);
	F1313_12590(Current, *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_), arg1);
	RTLE;
}

/* {EV_BUTTON_IMP}.on_focus_changed */
void F1416_14175 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	F1353_13020(Current, arg1);
	loc1 = F1301_12425(Current);
	loc1 = RTRV(eif_new_type(1382, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		if (arg1) {
			loc2 = Current;
			loc2 = RTRV(eif_new_type(1416, 0x00), loc2);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				F1379_13409(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_25_));
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_63_);
			if ((EIF_BOOLEAN)(tr1 == *(EIF_REFERENCE *)(Current + _REFACS_25_))) {
				F1379_13409(RTCW(loc1), NULL);
			}
		}
	}
	RTLE;
}

/* {EV_BUTTON_IMP}.foreground_color_style_context */
EIF_POINTER F1416_14176 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
	return (EIF_POINTER) (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) tp1);
}

/* {EV_BUTTON_IMP}.button_box */
EIF_POINTER F1416_14177 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1300_12390(Current);
	Result = (EIF_POINTER) gtk_bin_get_child((GtkBin*) tp1);
	RTLE;
	return Result;
}

/* {EV_BUTTON_IMP}.init_select_actions */
void F1416_14178 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	loc1 = RTOSCF(12391,F1300_12391, (Current));
	tp1 = F1300_12390(Current);
	tr1 = RTOSCF(819,F46_819, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1049,0xFF01,1010,1121,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_0_);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = tp2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,0,1049,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A409_337, (EIF_POINTER) _A409_337, (EIF_POINTER)(F1009_8377),tr2, 1, 0);
	}
	F1300_12370(Current, tp1, tr1, tr3);
	RTLE;
}

void EIF_Minit738 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
