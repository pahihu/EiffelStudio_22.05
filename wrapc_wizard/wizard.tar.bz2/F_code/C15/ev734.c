/*
 * Code for class EV_LIST_ITEM_LIST_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev734.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1412_14102
static EIF_POINTER inline_F1412_14102 (void)
{
	return (EIF_POINTER) (gtk_list_store_new (2, GDK_TYPE_PIXBUF, G_TYPE_STRING))
	;
}
#define INLINE_F1412_14102
#endif
#ifndef INLINE_F146_2773
static void inline_F146_2773 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	g_value_take_string ((GValue*) arg1, (gchar*) arg2)
	;
}
#define INLINE_F146_2773
#endif
#ifndef INLINE_F146_2785
static void inline_F146_2785 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	gtk_list_store_set_value ((GtkListStore*) arg1, (GtkTreeIter*) arg2, (gint) arg3, (GValue*) arg4)
	;
}
#define INLINE_F146_2785
#endif
#ifndef INLINE_F146_2763
static void inline_F146_2763 (EIF_POINTER arg1)
{
	g_value_init ((GValue*) arg1, G_TYPE_STRING)
	;
}
#define INLINE_F146_2763
#endif
#ifndef INLINE_F146_2787
static void inline_F146_2787 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	gtk_list_store_set ((GtkListStore*) arg1, (GtkTreeIter*) arg2, (gint) arg3, (GdkPixbuf*) arg4, -1)
	;
}
#define INLINE_F146_2787
#endif
#ifndef INLINE_F145_2230
static void inline_F145_2230 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F145_2230
#endif
#ifndef INLINE_F146_2781
static void inline_F146_2781 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	gtk_list_store_insert ((GtkListStore*) arg1, (GtkTreeIter*) arg2, (gint) arg3)
	;
}
#define INLINE_F146_2781
#endif
#ifndef INLINE_F146_2783
static void inline_F146_2783 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_list_store_remove ((GtkListStore*) arg1, (GtkTreeIter*) arg2)
	;
}
#define INLINE_F146_2783
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_LIST_ITEM_LIST_IMP}.make */
void F1412_14073 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1306_12548(Current);
	F1402_13722(Current);
	F1322_12717(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11166[Dtype(Current)-1413])(Current);
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.initialize_model */
void F1412_14074 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = inline_F1412_14102();
	*(EIF_POINTER *)(Current + O11180[Dtype(Current)-1411]) = (EIF_POINTER) tp1;
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.update_pnd_connection */
void F1412_14078 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O10518[dtype-1349])) {
		if ((EIF_BOOLEAN) (arg1 || (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O10493[dtype-1349]) != NULL))) {
			*(EIF_BOOLEAN *)(Current + O10518[dtype-1349]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !arg1 && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O10493[dtype-1349]) == NULL))) {
			*(EIF_BOOLEAN *)(Current + O10518[dtype-1349]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
	}
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.pre_pick_steps */
void F1412_14079 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_16 ti2_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O10497[dtype-1349]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11174[dtype-1411]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O10498[dtype-1349]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11175[dtype-1411]) = (EIF_REFERENCE) tr1;
	loc2 = *(EIF_REFERENCE *)(Current + O10493[dtype-1349]);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tr1 = RTOSCF(12391,F1300_12391, (Current));
		tr2 = RTCCL(loc2);
		F1299_12321(RTCW(tr1), Current, tr2);
	}
	loc1 = *(EIF_REFERENCE *)(Current + O11171[dtype-1411]);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F164_3354(RTCW(loc1));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1049,1067,1067,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNTS(typres0.id, 3, 1);
			}
			((EIF_TYPED_VALUE *)tr2+1)->it_i4 = arg1;
			((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg2;
			F873_6795(RTCW(tr1), tr2);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_16_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O10497[dtype-1349]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_17_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O10498[dtype-1349]) = (EIF_REFERENCE) tr1;
	} else {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O3362[dtype-163]) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O3362[dtype-163]);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1049,1067,1067,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNTS(typres0.id, 3, 1);
			}
			((EIF_TYPED_VALUE *)tr2+1)->it_i4 = arg1;
			((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg2;
			F873_6795(RTCW(tr1), tr2);
		}
	}
	ti2_1 = (EIF_INTEGER_16) arg3;
	*(EIF_INTEGER_16 *)(Current + O3916[dtype-200]) = (EIF_INTEGER_16) ti2_1;
	ti2_1 = (EIF_INTEGER_16) arg4;
	*(EIF_INTEGER_16 *)(Current + O3917[dtype-200]) = (EIF_INTEGER_16) ti2_1;
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_16 *)(Current + O10523[dtype-1349]) == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(*(EIF_INTEGER_16 *)(Current + O10524[dtype-1349]) == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L)))) {
			tr1 = RTOSCF(12391,F1300_12391, (Current));
			F1298_12179(RTCW(tr1), arg3, arg4);
		} else {
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O10523[dtype-1349]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			if ((EIF_BOOLEAN) (ti4_1 > F1353_13029(Current))) {
				ti2_1 = (EIF_INTEGER_16) F1353_13029(Current);
				*(EIF_INTEGER_16 *)(Current + O10523[dtype-1349]) = (EIF_INTEGER_16) ti2_1;
			}
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O10524[dtype-1349]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			if ((EIF_BOOLEAN) (ti4_1 > F1353_13030(Current))) {
				ti2_1 = (EIF_INTEGER_16) F1353_13030(Current);
				*(EIF_INTEGER_16 *)(Current + O10524[dtype-1349]) = (EIF_INTEGER_16) ti2_1;
			}
			tr1 = RTOSCF(12391,F1300_12391, (Current));
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O10523[dtype-1349]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O10524[dtype-1349]);
			ti4_2 = (EIF_INTEGER_32) ti2_1;
			F1298_12179(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + (EIF_INTEGER_32) (arg3 - arg1)), (EIF_INTEGER_32) (ti4_2 + (EIF_INTEGER_32) (arg4 - arg2)));
		}
	} else {
		tb1 = '\0';
		ti2_1 = *(EIF_INTEGER_16 *)(RTCW(loc1)+ _I16OFF_23_5_4_);
		if ((EIF_BOOLEAN)(ti2_1 == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L))) {
			ti2_1 = *(EIF_INTEGER_16 *)(RTCW(loc1)+ _I16OFF_23_5_5_);
			tb1 = (EIF_BOOLEAN)(ti2_1 == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L));
		}
		if (tb1) {
			tr1 = RTOSCF(12391,F1300_12391, (Current));
			F1298_12179(RTCW(tr1), arg3, arg4);
		} else {
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O10523[dtype-1349]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			if ((EIF_BOOLEAN) (ti4_1 > F1353_13029(Current))) {
				ti2_1 = (EIF_INTEGER_16) F1353_13029(Current);
				*(EIF_INTEGER_16 *)(Current + O10523[dtype-1349]) = (EIF_INTEGER_16) ti2_1;
			}
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O10524[dtype-1349]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			if ((EIF_BOOLEAN) (ti4_1 > F1414_14143(Current))) {
				ti2_1 = (EIF_INTEGER_16) F1414_14143(Current);
				*(EIF_INTEGER_16 *)(Current + O10524[dtype-1349]) = (EIF_INTEGER_16) ti2_1;
			}
			tr1 = RTOSCF(12391,F1300_12391, (Current));
			ti2_1 = *(EIF_INTEGER_16 *)(RTCW(loc1)+ _I16OFF_23_5_4_);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			ti2_1 = *(EIF_INTEGER_16 *)(RTCW(loc1)+ _I16OFF_23_5_5_);
			ti4_2 = (EIF_INTEGER_32) ti2_1;
			tr2 = *(EIF_REFERENCE *)(Current + O10266[dtype-1305]);
			tr3 = F1274_11666(RTCW(loc1));
			ti4_3 = F645_6075(RTCW(tr2), tr3, ((EIF_INTEGER_32) 1L));
			ti4_4 = F1414_14143(Current);
			F1298_12179(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + (EIF_INTEGER_32) (arg3 - arg1)), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 + (EIF_INTEGER_32) (arg4 - arg2)) + (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_3 - ((EIF_INTEGER_32) 1L)) * ti4_4)));
		}
	}
	F1350_12941(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.post_drop_steps */
void F1412_14080 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1351_12973(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O11174[dtype-1411]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O10497[dtype-1349]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O11175[dtype-1411]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O10498[dtype-1349]) = (EIF_REFERENCE) tr1;
	*(EIF_REFERENCE *)(Current + O11174[dtype-1411]) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + O11175[dtype-1411]) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + O11171[dtype-1411]) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.pebble_source */
EIF_REFERENCE F1412_14082 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O11171[Dtype(Current)-1411]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1274_11666(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTLE;
		return (EIF_REFERENCE) F1351_12970(Current);
	}/* NOTREACHED */
	
}

/* {EV_LIST_ITEM_LIST_IMP}.able_to_transport */
EIF_BOOLEAN F1412_14083 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O11171[Dtype(Current)-1411]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = F1423_14211(loc1, arg1);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTLE;
		return (EIF_BOOLEAN) F1351_12967(Current, arg1);
	}/* NOTREACHED */
	
}

/* {EV_LIST_ITEM_LIST_IMP}.ready_for_pnd_menu */
EIF_BOOLEAN F1412_14084 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O11171[Dtype(Current)-1411]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = F1423_14212(loc1, arg1, arg2);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTLE;
		return (EIF_BOOLEAN) F1351_12971(Current, arg1, arg2);
	}/* NOTREACHED */
	
}

/* {EV_LIST_ITEM_LIST_IMP}.call_pebble_function */
void F1412_14090 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O10493[dtype-1349]);
	tr1 = RTCCL(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11172[dtype-1411]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O10494[dtype-1349]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11173[dtype-1411]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O11171[dtype-1411]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_13_);
		tr1 = RTCCL(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O10493[dtype-1349]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_14_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O10494[dtype-1349]) = (EIF_REFERENCE) tr1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O10494[dtype-1349]);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1049,1067,1067,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 1);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
		((EIF_TYPED_VALUE *)tr1+2)->it_i4 = arg2;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8226[Dtype(loc2)-1124])(loc2, tr1);
		tr1 = RTCCL(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O10493[dtype-1349]) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.reset_pebble_function */
void F1412_14091 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O11172[dtype-1411]);
	tr1 = RTCCL(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O10493[dtype-1349]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O11173[dtype-1411]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O10494[dtype-1349]) = (EIF_REFERENCE) tr1;
	*(EIF_REFERENCE *)(Current + O11172[dtype-1411]) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + O11173[dtype-1411]) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.set_text_on_position */
void F1412_14094 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	loc1 = RTOSCF(12354,F1299_12354, (RTCV(RTOSCF(12391,F1300_12391, (Current)))));
	F993_7488(RTCW(loc1), arg2);
	loc2 = RTOSCF(14095,F1412_14095, (Current));
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	inline_F146_2773(loc2, tp1);
	tr1 = *(EIF_REFERENCE *)(Current + O10266[dtype-1305]);
	tr1 = F850_6647(RTCW(tr1), arg1);
	loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc3 = RTRV(eif_new_type(1422, 0x00), loc3);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		loc4 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_20_);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tp1 = *(EIF_POINTER *)(Current + O11180[dtype-1411]);
			tp2 = F302_4754(RTCW(loc4));
			inline_F146_2785(tp1, tp2, ((EIF_INTEGER_32) 1L), loc2);
		}
	}
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.g_value_string_struct */
static EIF_POINTER F1412_14095_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (14095);
#define Result RTOSR(14095)
	Result = (EIF_POINTER) calloc (sizeof(GValue), 1);
	inline_F146_2763(Result);
	RTOSE (14095);
	RTEE;
	return Result;
#undef Result
}

EIF_POINTER F1412_14095 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14095,F1412_14095_body,(Current));
}

/* {EV_LIST_ITEM_LIST_IMP}.set_row_pixmap */
void F1412_14096 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1453, 0x00), loc1);
	RTCT0("pixmap_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc4 = F1451_14667(RTCW(loc1), *(EIF_INTEGER_32 *)(Current + O10389[dtype-1321]), *(EIF_INTEGER_32 *)(Current + O10390[dtype-1321]));
	tr1 = *(EIF_REFERENCE *)(Current + O10266[dtype-1305]);
	tr1 = F850_6647(RTCW(tr1), arg1);
	loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc2 = RTRV(eif_new_type(1422, 0x00), loc2);
	RTCT0("a_list_item_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc3 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_20_);
	RTCT0("a_list_iter /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = *(EIF_POINTER *)(Current + O11180[dtype-1411]);
	tp2 = F302_4754(RTCW(loc3));
	inline_F146_2787(tp1, tp2, ((EIF_INTEGER_32) 0L), loc4);
	inline_F145_2230(loc4);
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.insert_i_th */
void F1412_14098 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1422, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1423_14248(RTCW(loc1), Current);
		tr1 = *(EIF_REFERENCE *)(Current + O10266[dtype-1305]);
		F850_6676(RTCW(tr1), arg2);
		tr1 = *(EIF_REFERENCE *)(Current + O10266[dtype-1305]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5700[Dtype(RTCW(tr1))-849])(tr1, arg1);
		loc2 = RTLNS(eif_new_type(303, 0x01).id, 303, _OBJSIZ_1_1_0_0_0_1_0_0_);
		F302_4751(RTCW(loc2));
		F1423_14245(RTCW(loc1), loc2);
		tp1 = *(EIF_POINTER *)(Current + O11180[dtype-1411]);
		tp2 = F302_4754(RTCW(loc2));
		inline_F146_2781(tp1, tp2, (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
		tr1 = F1197_10756(RTCW(arg1));
		F1412_14094(Current, arg2, tr1);
		tr1 = F1193_10732(RTCW(arg1));
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			F1412_14096(Current, arg2, loc3);
		}
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_23_1_);
		if (tb1) {
			F1412_14078(Current, (EIF_BOOLEAN) 1);
		}
	}
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.remove_i_th */
void F1412_14101 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	F1414_14139(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O10266[dtype-1305]);
	tr1 = F850_6648(RTCW(tr1), arg1);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1422, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1423_14248(RTCW(loc1), NULL);
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_20_);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tp1 = *(EIF_POINTER *)(Current + O11180[dtype-1411]);
			tp2 = F302_4754(RTCW(loc2));
			inline_F146_2783(tp1, tp2);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O10266[dtype-1305]);
		F850_6676(RTCW(tr1), arg1);
		tr1 = *(EIF_REFERENCE *)(Current + O10266[dtype-1305]);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5632[Dtype(RTCW(tr1))-692])(tr1);
	}
	RTLE;
}

/* {EV_LIST_ITEM_LIST_IMP}.new_list_store */
EIF_POINTER F1412_14102 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F1412_14102 ();
	return Result;
}

void EIF_Minit734 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
