
#ifndef _C15_ev710_
#define _C15_ev710_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1388_13596(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit710(void);
extern void F1305_12525(EIF_REFERENCE);
extern void F1305_12529(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1305_12515(EIF_REFERENCE);
extern EIF_BOOLEAN F1305_12518(EIF_REFERENCE);
extern EIF_REFERENCE F1305_12513(EIF_REFERENCE);
extern void F1305_12527(EIF_REFERENCE);
extern char *(*R11204[])();

#ifdef __cplusplus
}
#endif

#endif
