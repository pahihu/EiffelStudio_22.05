/*
 * Code for class EV_CHECKABLE_LIST_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev737.h"
#include <string.h>
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F146_2724
static EIF_POINTER inline_F146_2724 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_tree_view_get_column ((GtkTreeView*) arg1, (gint) arg2))
	;
}
#define INLINE_F146_2724
#endif
#ifndef INLINE_F146_2749
static EIF_POINTER inline_F146_2749 (void)
{
	return (EIF_POINTER) (gtk_cell_renderer_toggle_new())
	;
}
#define INLINE_F146_2749
#endif
#ifndef INLINE_F146_2755
static void inline_F146_2755 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	gtk_tree_view_column_pack_start ((GtkTreeViewColumn*) arg1, (GtkCellRenderer*) arg2, (gboolean) arg3)
	;
}
#define INLINE_F146_2755
#endif
#ifndef INLINE_F146_2743
static void inline_F146_2743 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4)
{
	gtk_tree_view_column_add_attribute ((GtkTreeViewColumn*) arg1, (GtkCellRenderer*) arg2, (gchar*) arg3, (gint) arg4)
	;
}
#define INLINE_F146_2743
#endif
#ifndef INLINE_F146_2717
static int inline_F146_2717 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	return (int) (gtk_tree_model_get_iter ((GtkTreeModel*) arg1, (GtkTreeIter*) arg2, (GtkTreePath*) arg3))
	;
}
#define INLINE_F146_2717
#endif
#ifndef INLINE_F146_2719
static void inline_F146_2719 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	gtk_tree_model_get_value ((GtkTreeModel*) arg1, (GtkTreeIter*) arg2, (gint) arg3, (GValue*) arg4)
	;
}
#define INLINE_F146_2719
#endif
#ifndef INLINE_F146_2768
static int inline_F146_2768 (EIF_POINTER arg1)
{
	return (int) (g_value_get_boolean ((GValue*) arg1))
	;
}
#define INLINE_F146_2768
#endif
#ifndef INLINE_F146_2767
static void inline_F146_2767 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	g_value_set_boolean ((GValue*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F146_2767
#endif
#ifndef INLINE_F146_2785
static void inline_F146_2785 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	gtk_list_store_set_value ((GtkListStore*) arg1, (GtkTreeIter*) arg2, (gint) arg3, (GValue*) arg4)
	;
}
#define INLINE_F146_2785
#endif
#ifndef INLINE_F146_2694
static void inline_F146_2694 (EIF_POINTER arg1)
{
	gtk_tree_path_free ((GtkTreePath*) arg1)
	;
}
#define INLINE_F146_2694
#endif
#ifndef INLINE_F145_2369
static void inline_F145_2369 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	{
	GType type = GDK_TYPE_PIXBUF;
	memcpy ((char *) arg1 + arg2, &type, sizeof(GType));
}
	;
}
#define INLINE_F145_2369
#endif
#ifndef INLINE_F145_2368
static void inline_F145_2368 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	{
	GType type = G_TYPE_STRING;
	memcpy ((char *) arg1 + arg2, &type, sizeof(GType));
}
	;
}
#define INLINE_F145_2368
#endif
#ifndef INLINE_F145_2367
static void inline_F145_2367 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	{
	GType type = G_TYPE_BOOLEAN;
	memcpy ((char *) arg1 + arg2, &type, sizeof(GType));
}
	;
}
#define INLINE_F145_2367
#endif
#ifndef INLINE_F146_2777
static EIF_POINTER inline_F146_2777 (EIF_INTEGER_32 arg1, EIF_POINTER arg2)
{
	return (EIF_POINTER) (gtk_list_store_newv ((gint) arg1, (GType*) arg2))
	;
}
#define INLINE_F146_2777
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CHECKABLE_LIST_IMP}.make */
void F1415_14152 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	F1414_14129(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_3_);
	loc1 = inline_F146_2724(tp1, ((EIF_INTEGER_32) 0L));
	loc2 = inline_F146_2749();
	inline_F146_2755(loc1, loc2, (EIF_BOOLEAN) 0);
	loc3 = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr1 = RTMS_EX_H("active",6,2144538725);
	F993_7487(RTCW(loc3), tr1);
	tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	inline_F146_2743(loc1, loc2, tp1, ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("toggled",7,209460068);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1049,0xFF01,1010,1067,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(12391,F1300_12391, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_53_14_10_0_);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,2,1049,1067,1121,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A409_318_3_4, (EIF_POINTER) _A409_318_3_4, (EIF_POINTER)(F1008_8357),tr2, 1, 2);
	}
	F1300_12370(Current, loc2, tr1, tr5);
	RTLE;
}

/* {EV_CHECKABLE_LIST_IMP}.on_tree_path_toggle */
void F1415_14154 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_POINTER loc8 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,loc6);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	loc3 = RTLNS(eif_new_type(303, 0x01).id, 303, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F302_4751(RTCW(loc3));
	loc1 = (EIF_POINTER) gtk_tree_path_new_from_string((gchar*) arg1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_);
	tp2 = F302_4754(RTCW(loc3));
	loc4 = EIF_TEST (inline_F146_2717(tp1, tp2, loc1));
	if (loc4) {
		loc2 = (EIF_POINTER) gtk_tree_path_get_indices((GtkTreePath*) loc1);
		loc5 = RTLNS(eif_new_type(996, 0x01).id, 996, _OBJSIZ_0_1_0_1_0_1_1_0_);
		F997_7582(RTCW(loc5), loc2, ((EIF_INTEGER_32) 4L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
		ti4_1 = F997_7596(RTCW(loc5), ((EIF_INTEGER_32) 0L));
		loc6 = F850_6648(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		loc8 = (EIF_POINTER) calloc (sizeof(GValue), 1);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_);
		tp2 = F302_4754(RTCW(loc3));
		inline_F146_2719(tp1, tp2, ((EIF_INTEGER_32) 2L), loc8);
		loc7 = EIF_TEST (inline_F146_2768(loc8));
		inline_F146_2767(loc8, (EIF_BOOLEAN) !loc7);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_);
		tp2 = F302_4754(RTCW(loc3));
		inline_F146_2785(tp1, tp2, ((EIF_INTEGER_32) 2L), loc8);
		if (loc7) {
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1049,0xFF01,1249,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr2 = RTLNTS(typres0.id, 2, 0);
				}
				((EIF_TYPED_VALUE *)tr2+1)->it_r = loc6;
				RTAR(tr2,loc6);
				(RTNA((RTCW(tr1), tr2)));
			}
		} else {
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1049,0xFF01,1249,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr2 = RTLNTS(typres0.id, 2, 0);
				}
				((EIF_TYPED_VALUE *)tr2+1)->it_r = loc6;
				RTAR(tr2,loc6);
				(RTNA((RTCW(tr1), tr2)));
			}
		}
		free(loc8);
	}
	inline_F146_2694(loc1);
	RTLE;
}

/* {EV_CHECKABLE_LIST_IMP}.initialize_model */
void F1415_14155 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(996, 0x01).id, 996, _OBJSIZ_0_1_0_1_0_1_1_0_);
	ti4_1 = (EIF_INTEGER_32) sizeof(GType);
	F997_7579(RTCW(loc1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * ti4_1));
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	inline_F145_2369(tp1, ((EIF_INTEGER_32) 0L));
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	ti4_1 = (EIF_INTEGER_32) sizeof(GType);
	inline_F145_2368(tp1, (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) * ti4_1));
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	ti4_1 = (EIF_INTEGER_32) sizeof(GType);
	inline_F145_2367(tp1, (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1));
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	tp1 = inline_F146_2777(((EIF_INTEGER_32) 3L), tp1);
	*(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_) = (EIF_POINTER) tp1;
	RTLE;
}

/* {EV_CHECKABLE_LIST_IMP}.is_item_checked */
EIF_BOOLEAN F1415_14156 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1422, 0x00), loc1);
	RTCT0("item_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_20_);
	RTCT0("l_list_iter /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc3 = (EIF_POINTER) calloc (sizeof(GValue), 1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_);
	tp2 = F302_4754(RTCW(loc2));
	inline_F146_2719(tp1, tp2, ((EIF_INTEGER_32) 2L), loc3);
	Result = EIF_TEST (inline_F146_2768(loc3));
	free(loc3);
	RTLE;
	return Result;
}

/* {EV_CHECKABLE_LIST_IMP}.check_item */
void F1415_14157 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1422, 0x00), loc1);
	RTCT0("item_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_20_);
	RTCT0("l_list_iter /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc3 = (EIF_POINTER) calloc (sizeof(GValue), 1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_);
	tp2 = F302_4754(RTCW(loc2));
	inline_F146_2719(tp1, tp2, ((EIF_INTEGER_32) 2L), loc3);
	inline_F146_2767(loc3, (EIF_BOOLEAN) 1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_);
	tp2 = F302_4754(RTCW(loc2));
	inline_F146_2785(tp1, tp2, ((EIF_INTEGER_32) 2L), loc3);
	free(loc3);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1049,0xFF01,1249,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = arg1;
		RTAR(tr2,arg1);
		(RTNA((RTCW(tr1), tr2)));
	}
	RTLE;
}

/* {EV_CHECKABLE_LIST_IMP}.uncheck_item */
void F1415_14158 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1422, 0x00), loc1);
	RTCT0("item_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_20_);
	RTCT0("l_list_iter /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc3 = (EIF_POINTER) calloc (sizeof(GValue), 1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_);
	tp2 = F302_4754(RTCW(loc2));
	inline_F146_2719(tp1, tp2, ((EIF_INTEGER_32) 2L), loc3);
	inline_F146_2767(loc3, (EIF_BOOLEAN) 0);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_53_14_10_9_0_1_);
	tp2 = F302_4754(RTCW(loc2));
	inline_F146_2785(tp1, tp2, ((EIF_INTEGER_32) 2L), loc3);
	free(loc3);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1049,0xFF01,1249,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = arg1;
		RTAR(tr2,arg1);
		(RTNA((RTCW(tr1), tr2)));
	}
	RTLE;
}

void EIF_Minit737 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
