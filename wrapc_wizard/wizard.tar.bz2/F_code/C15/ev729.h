
#ifndef _C15_ev729_
#define _C15_ev729_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1407_13893(EIF_REFERENCE);
extern void F1407_13896(EIF_REFERENCE);
extern void F1407_13897(EIF_REFERENCE);
extern EIF_REFERENCE F1407_13899(EIF_REFERENCE);
extern EIF_BOOLEAN F1407_13900(EIF_REFERENCE);
extern void EIF_Minit729(void);
extern void F1337_12792(EIF_REFERENCE);
extern void F1300_12366(EIF_REFERENCE, EIF_POINTER);
extern void F1274_11680(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1402_13722(EIF_REFERENCE);
extern void F1337_12789(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
