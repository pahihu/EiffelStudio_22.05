/*
 * Code for class EV_TOOL_BAR_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev728.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TOOL_BAR_IMP}.needs_event_box */
EIF_BOOLEAN F1406_13873 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_TOOL_BAR_IMP}.make */
RTEOMS(13874,1);
void F1406_13875 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTGC;
	tp1 = (EIF_POINTER) gtk_toolbar_new();
	F1300_12366(Current, tp1);
	F1306_12548(Current);
	F1402_13722(Current);
	loc1 = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F993_7487(RTCW(loc1), RTOMS(13874,0));
	tp1 = F1406_13876(Current);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	gtk_widget_set_name((GtkWidget*) tp1, (gchar*) tp2);
	tp1 = F1406_13876(Current);
	gtk_toolbar_set_show_arrow((GtkToolbar*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_45_13_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F1406_13883(Current);
	RTLE;
}

/* {EV_TOOL_BAR_IMP}.list_widget */
EIF_POINTER F1406_13876 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) F1300_12390(Current);
}

/* {EV_TOOL_BAR_IMP}.set_parent_imp */
void F1406_13877 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1353_13045(Current, arg1);
	F1406_13886(Current);
	RTLE;
}

/* {EV_TOOL_BAR_IMP}.has_vertical_button_style */
EIF_BOOLEAN F1406_13878 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_45_13_);
}


/* {EV_TOOL_BAR_IMP}.is_vertical */
EIF_BOOLEAN F1406_13879 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_45_12_);
}


/* {EV_TOOL_BAR_IMP}.disable_vertical */
void F1406_13883 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_45_12_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tp1 = F1406_13876(Current);
	gtk_orientable_set_orientation((GtkOrientable*) tp1, (GtkOrientation) (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {EV_TOOL_BAR_IMP}.block_selection_for_docking */
void F1406_13884 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_TOOL_BAR_IMP}.item_from_coords */
EIF_REFERENCE F1406_13885 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 > F1306_12550(Current))) {
			tb1 = (EIF_BOOLEAN)(Result != NULL);
		}
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
		tr1 = F850_6648(RTCW(tr1), loc1);
		loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		loc3 = RTRV(eif_new_type(1427, 0x00), loc3);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			ti4_1 = F1301_12418(RTCW(loc3));
			loc2 += ti4_1;
		}
		if ((EIF_BOOLEAN) (arg1 < loc2)) {
			Result = loc3;
			Result = RTRV(eif_new_type(1328, 0x00), Result);
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {EV_TOOL_BAR_IMP}.update_toolbar_style */
void F1406_13886 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_44_) != NULL)) {
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc4 > F1306_12550(Current))) break;
			tr1 = F1306_12549(Current, loc4);
			loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
			loc1 = RTRV(eif_new_type(1443, 0x00), loc1);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				tr1 = (RTNA((RTCW(loc1))), ((EIF_REFERENCE) 0));
				tb2 = F554_5957(RTCW(tr1));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
				tb1 = (EIF_BOOLEAN)(tr1 != NULL);
			}
			if (tb1) {
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
			loc4++;
		}
		if ((EIF_BOOLEAN) (loc2 && loc3)) {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_45_13_)) {
				loc5 = (EIF_INTEGER_32) GTK_TOOLBAR_BOTH;
			} else {
				loc5 = (EIF_INTEGER_32) GTK_TOOLBAR_BOTH_HORIZ;
			}
		} else {
			if (loc2) {
				loc5 = (EIF_INTEGER_32) GTK_TOOLBAR_TEXT;
			} else {
				loc5 = (EIF_INTEGER_32) GTK_TOOLBAR_ICONS;
			}
		}
		tp1 = F1300_12390(Current);
		gtk_toolbar_set_style((GtkToolbar*) tp1, (GtkToolbarStyle) loc5);
	}
	RTLE;
}

/* {EV_TOOL_BAR_IMP}.insertion_position */
EIF_INTEGER_32 F1406_13887 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	Result = F1306_12550(Current);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	loc1 = F1299_12344(RTCV(RTOSCF(12391,F1300_12391, (Current))));
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + O9576[Dtype(loc1)-1273]);
		loc2 = RTRV(eif_new_type(1250, 0x00), loc2);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tb1 = F1305_12524(Current, loc2);
		}
		if (tb1) {
			Result = F1305_12519(Current, loc2, ((EIF_INTEGER_32) 1L));
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result - ((EIF_INTEGER_32) 1L));
		}
	}
	RTLE;
	return Result;
}

/* {EV_TOOL_BAR_IMP}.insert_i_th */
void F1406_13888 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1427, 0x00), loc1);
	RTCT0("v_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F1428_14326(RTCW(loc1), Current);
	tp1 = F1300_12390(Current);
	tp2 = *(EIF_POINTER *)(RTCW(loc1) + O10102[Dtype(loc1)-1299]);
	gtk_toolbar_insert((GtkToolbar*) tp1, (GtkToolItem*) tp2, (gint) (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	loc2 = loc1;
	loc2 = RTRV(eif_new_type(1444, 0x00), loc2);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_45_16_10_7_0_1_);
		gtk_radio_tool_button_set_group((GtkRadioToolButton*) tp1, (GSList*) tp2);
		tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
		*(EIF_POINTER *)(Current+ _PTROFF_45_16_10_7_0_1_) = (EIF_POINTER) tp1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
	F850_6676(RTCW(tr1), arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5700[Dtype(RTCW(tr1))-849])(tr1, arg1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_44_) != NULL)) {
		F1406_13886(Current);
	}
	RTLE;
}

/* {EV_TOOL_BAR_IMP}.remove_i_th */
void F1406_13889 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
	F850_6676(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
	tr1 = F850_6647(RTCW(tr1), arg1);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1427, 0x00), loc1);
	RTCT0("imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc3 = loc1;
	loc3 = RTRV(eif_new_type(1444, 0x00), loc3);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		tp1 = (RTNA((RTCW(loc3))), ((EIF_POINTER) 0));
		loc4 = (EIF_POINTER) gtk_radio_tool_button_get_group((GtkRadioToolButton*) tp1);
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) g_slist_length((GSList*) loc4) == ((EIF_INTEGER_32) 1L))) {
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			tp2 = tp1;
			*(EIF_POINTER *)(Current+ _PTROFF_45_16_10_7_0_1_) = (EIF_POINTER) tp2;
		}
	}
	loc2 = *(EIF_POINTER *)(RTCW(loc1) + O10102[Dtype(loc1)-1299]);
	tp1 = F1406_13876(Current);
	gtk_container_remove((GtkContainer*) tp1, (GtkWidget*) loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5632[Dtype(RTCW(tr1))-692])(tr1);
	F1428_14326(RTCW(loc1), NULL);
	RTLE;
}

void EIF_Minit728 (void)
{
	GTCX
	RTPOMS(13874,0,"v2toolbar",9,821754994);
}


#ifdef __cplusplus
}
#endif
