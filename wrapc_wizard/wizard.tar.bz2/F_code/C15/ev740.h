
#ifndef _C15_ev740_
#define _C15_ev740_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1418_14192(EIF_REFERENCE);
extern void EIF_Minit740(void);
extern EIF_POINTER F1300_12390(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
