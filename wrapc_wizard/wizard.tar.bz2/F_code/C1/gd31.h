
#ifndef _C1_gd31_
#define _C1_gd31_

#ifdef __cplusplus
extern "C" {
#endif

extern void F45_793(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32*, EIF_INTEGER_32*);
extern EIF_POINTER F45_796(EIF_REFERENCE);
extern EIF_INTEGER_32 F45_798(EIF_REFERENCE);
extern void EIF_Minit31(void);

#ifdef __cplusplus
}
#endif

#endif
