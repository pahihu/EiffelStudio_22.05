
#ifndef _C1_by18_
#define _C1_by18_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F31_296(EIF_REFERENCE);
extern void EIF_Minit18(void);

#ifdef __cplusplus
}
#endif

#endif
