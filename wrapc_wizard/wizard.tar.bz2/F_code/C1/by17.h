
#ifndef _C1_by17_
#define _C1_by17_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F32_296(EIF_REFERENCE);
extern void EIF_Minit17(void);

#ifdef __cplusplus
}
#endif

#endif
