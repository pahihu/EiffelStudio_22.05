
#ifndef _C1_gd21_
#define _C1_gd21_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F35_487(EIF_REFERENCE);
extern void EIF_Minit21(void);

#ifdef __cplusplus
}
#endif

#endif
