/*
 * Code for class UUID_GENERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uu30.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UUID_GENERATOR}.generate_uuid */
EIF_REFERENCE F44_787 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1013, 0x01).id, 1013, _OBJSIZ_0_0_3_1_0_0_1_0_);
	tr1 = RTOSCF(790,F44_790, (Current));
	tr2 = RTOSCF(789,F44_789, (Current));
	tr1 = F44_788(Current, tr1, tr2);
	F1014_8439(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {UUID_GENERATOR}.segments */
EIF_REFERENCE F44_788 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,704,1085,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 704, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F705_6202(RTCW(Result), ((EIF_NATURAL_8) 0U), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 16L));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O4186[Dtype(arg1)-229]);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 16L))) break;
		if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 2147483647L))) {
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			ti4_1 = F44_791(Current);
			F732_6293(RTCW(arg2), ti4_1);
		} else {
			loc2++;
		}
		ti4_1 = F732_6301(RTCW(arg2), loc2);
		tu1_1 = (EIF_NATURAL_8) ti4_1;
		F705_6226(RTCW(Result), tu1_1, loc1);
		loc1++;
	}
	F232_4240(RTCW(arg1), loc2);
	tu1_1 = F705_6207(RTCW(Result), ((EIF_INTEGER_32) 7L));
	tu1_1 = eif_bit_and(tu1_1,(EIF_NATURAL_8) ((EIF_INTEGER_32) 15L));
	tu1_1 = eif_bit_or(tu1_1,(EIF_NATURAL_8) ((EIF_INTEGER_32) 64L));
	F705_6226(RTCW(Result), tu1_1, ((EIF_INTEGER_32) 7L));
	tu1_1 = F705_6207(RTCW(Result), ((EIF_INTEGER_32) 9L));
	tu1_1 = eif_bit_and(tu1_1,(EIF_NATURAL_8) ((EIF_INTEGER_32) 63L));
	tu1_1 = eif_bit_or(tu1_1,(EIF_NATURAL_8) ((EIF_INTEGER_32) 128L));
	F705_6226(RTCW(Result), tu1_1, ((EIF_INTEGER_32) 9L));
	RTLE;
	return Result;
}

/* {UUID_GENERATOR}.rand */
static EIF_REFERENCE F44_789_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (789);
#define Result RTOSR(789)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(731, 0x01).id, 731, _OBJSIZ_0_1_0_4_0_0_0_0_);
	ti4_1 = F44_791(Current);
	F732_6293(RTCW(tr1), ti4_1);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (789);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F44_789 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(789,F44_789_body,(Current));
}

/* {UUID_GENERATOR}.rand_count */
static EIF_REFERENCE F44_790_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (790);
#define Result RTOSR(790)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,231,1067,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 231, _OBJSIZ_0_0_0_1_0_0_0_0_);
	}
	F232_4240(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (790);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F44_790 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(790,F44_790_body,(Current));
}

/* {UUID_GENERATOR}.seed */
EIF_INTEGER_32 F44_791 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_64 loc1 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_NATURAL_64 tu8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,loc2);
	RTLIU(1);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F38_620(RTCW(loc2));
	ti4_1 = F38_624(RTCW(loc2));
	loc1 = (EIF_NATURAL_64) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1970L));
	loc1 = (EIF_NATURAL_64) (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (loc1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 12L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 30L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 24L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	ti4_1 = F38_625(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 30L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 24L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	ti4_1 = F38_626(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 24L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	ti4_1 = F38_627(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	ti4_1 = F38_628(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) ((EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	ti4_1 = F38_629(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	ti4_1 = F38_630(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += tu8_1;
	tu8_1 = eif_bit_shift_right(loc1,((EIF_INTEGER_32) 32L));
	tu8_1 = eif_bit_xor(tu8_1,loc1);
	ti4_1 = (EIF_INTEGER_32) tu8_1;
	Result = eif_bit_and(ti4_1,((EIF_INTEGER_32) 2147483647L));
	RTLE;
	return Result;
}

void EIF_Minit30 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
