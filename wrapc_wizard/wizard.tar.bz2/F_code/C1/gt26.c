/*
 * Code for class GTK_ALIGN
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt26.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F40_659
static EIF_INTEGER_32 inline_F40_659 (void)
{
	return GTK_ALIGN_START
	;
}
#define INLINE_F40_659
#endif
#ifndef INLINE_F40_660
static EIF_INTEGER_32 inline_F40_660 (void)
{
	return GTK_ALIGN_END
	;
}
#define INLINE_F40_660
#endif
#ifndef INLINE_F40_661
static EIF_INTEGER_32 inline_F40_661 (void)
{
	return GTK_ALIGN_CENTER
	;
}
#define INLINE_F40_661
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_ALIGN}.gtk_align_start */
EIF_INTEGER_32 F40_659 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F40_659 ();
	return Result;
}

/* {GTK_ALIGN}.gtk_align_end */
EIF_INTEGER_32 F40_660 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F40_660 ();
	return Result;
}

/* {GTK_ALIGN}.gtk_align_center */
EIF_INTEGER_32 F40_661 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F40_661 ();
	return Result;
}

void EIF_Minit26 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
