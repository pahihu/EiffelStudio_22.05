
#ifndef _C1_ev34_
#define _C1_ev34_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F48_857(EIF_REFERENCE);
extern EIF_REFERENCE F48_860(EIF_REFERENCE);
extern EIF_REFERENCE F48_864(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit34(void);
extern void F1175_10481(EIF_REFERENCE, EIF_REAL_32, EIF_REAL_32, EIF_REAL_32);
extern void F993_7487(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
