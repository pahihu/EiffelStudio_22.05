/*
 * Code for class ERROR_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "er11.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ERROR_CONSTANTS}.err_msg_0 */

EIF_REFERENCE F19_112 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (112,RTMS_EX_H("compilation successfully",24,297046137));
}

/* {ERROR_CONSTANTS}.err_msg_1 */

EIF_REFERENCE F19_113 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (113,RTMS_EX_H("\\ at end of pattern",19,1082148462));
}

/* {ERROR_CONSTANTS}.err_msg_2 */

EIF_REFERENCE F19_114 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (114,RTMS_EX_H("\\c at end of pattern",20,586514030));
}

/* {ERROR_CONSTANTS}.err_msg_3 */

EIF_REFERENCE F19_115 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (115,RTMS_EX_H("unrecognized character follows \\",32,1794949212));
}

/* {ERROR_CONSTANTS}.err_msg_4 */

EIF_REFERENCE F19_116 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (116,RTMS_EX_H("numbers out of order in {} quantifier",37,1764177010));
}

/* {ERROR_CONSTANTS}.err_msg_5 */

EIF_REFERENCE F19_117 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (117,RTMS_EX_H("number too big in {} quantifier",31,236715890));
}

/* {ERROR_CONSTANTS}.err_msg_6 */

EIF_REFERENCE F19_118 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (118,RTMS_EX_H("missing terminating ] for character class",41,461852531));
}

/* {ERROR_CONSTANTS}.err_msg_7 */

EIF_REFERENCE F19_119 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (119,RTMS_EX_H("invalid escape sequence in character class",42,267449459));
}

/* {ERROR_CONSTANTS}.err_msg_8 */

EIF_REFERENCE F19_120 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (120,RTMS_EX_H("range out of order in character class",37,652901747));
}

/* {ERROR_CONSTANTS}.err_msg_9 */

EIF_REFERENCE F19_121 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (121,RTMS_EX_H("nothing to repeat",17,825052276));
}

/* {ERROR_CONSTANTS}.err_msg_11 */

EIF_REFERENCE F19_123 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (123,RTMS_EX_H("internal error: unexpected repeat",33,1855335540));
}

/* {ERROR_CONSTANTS}.err_msg_12 */

EIF_REFERENCE F19_124 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (124,RTMS_EX_H("unrecognized character after (\?",31,636561471));
}

/* {ERROR_CONSTANTS}.err_msg_13 */

EIF_REFERENCE F19_125 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (125,RTMS_EX_H("too many capturing parenthesized sub-patterns",45,1757158771));
}

/* {ERROR_CONSTANTS}.err_msg_14 */

EIF_REFERENCE F19_126 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (126,RTMS_EX_H("missing )",9,1989432361));
}

/* {ERROR_CONSTANTS}.err_msg_15 */

EIF_REFERENCE F19_127 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (127,RTMS_EX_H("back reference to non-existent subpattern",41,1930188142));
}

/* {ERROR_CONSTANTS}.err_msg_18 */

EIF_REFERENCE F19_130 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (130,RTMS_EX_H("missing ) after comment",23,1848893300));
}

/* {ERROR_CONSTANTS}.err_msg_22 */

EIF_REFERENCE F19_134 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (134,RTMS_EX_H("unmatched parentheses",21,366512243));
}

/* {ERROR_CONSTANTS}.err_msg_24 */

EIF_REFERENCE F19_136 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (136,RTMS_EX_H("unrecognized character after (\?<",32,1898751036));
}

/* {ERROR_CONSTANTS}.err_msg_25 */

EIF_REFERENCE F19_137 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (137,RTMS_EX_H("lookbehind assertion is not fixed length",40,831850344));
}

/* {ERROR_CONSTANTS}.err_msg_26 */

EIF_REFERENCE F19_138 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (138,RTMS_EX_H("malformed number after (\?(",26,217491240));
}

/* {ERROR_CONSTANTS}.err_msg_27 */

EIF_REFERENCE F19_139 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (139,RTMS_EX_H("conditional group contains more than two branches",49,572996467));
}

/* {ERROR_CONSTANTS}.err_msg_28 */

EIF_REFERENCE F19_140 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (140,RTMS_EX_H("assertion expected after (\?(",28,1018686248));
}

/* {ERROR_CONSTANTS}.err_msg_30 */

EIF_REFERENCE F19_142 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (142,RTMS_EX_H("unknown POSIX class name",24,1984937317));
}

/* {ERROR_CONSTANTS}.err_msg_31 */

EIF_REFERENCE F19_143 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (143,RTMS_EX_H("POSIX collating elements are not supported",42,1477603940));
}

/* {ERROR_CONSTANTS}.err_msg_35 */

EIF_REFERENCE F19_147 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (147,RTMS_EX_H("invalid condition (\?(0)",23,1170936617));
}

/* {ERROR_CONSTANTS}.err_msg_99 */

EIF_REFERENCE F19_149 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (149,RTMS_EX_H("no pattern compiled",19,1370646116));
}

void EIF_Minit11 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
