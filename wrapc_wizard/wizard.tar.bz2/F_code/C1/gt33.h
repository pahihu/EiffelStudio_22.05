
#ifndef _C1_gt33_
#define _C1_gt33_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F47_853(EIF_REFERENCE);
extern EIF_NATURAL_8 F47_854(EIF_REFERENCE);
extern void EIF_Minit33(void);

#ifdef __cplusplus
}
#endif

#endif
