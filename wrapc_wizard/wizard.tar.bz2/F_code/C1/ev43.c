/*
 * Code for class EV_STOCK_COLORS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev43.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STOCK_COLORS}.white */
static EIF_REFERENCE F57_1027_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1027);
#define Result RTOSR(1027)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1174, 0x01).id, 1174, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	tr4_2 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	tr4_3 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	F1175_10481(RTCW(tr1), tr4_1, tr4_2, tr4_3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1027);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F57_1027 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1027,F57_1027_body,(Current));
}

/* {EV_STOCK_COLORS}.black */
static EIF_REFERENCE F57_1028_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1028);
#define Result RTOSR(1028)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1174, 0x01).id, 1174, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	tr4_2 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	tr4_3 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	F1175_10481(RTCW(tr1), tr4_1, tr4_2, tr4_3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1028);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F57_1028 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1028,F57_1028_body,(Current));
}

/* {EV_STOCK_COLORS}.gray */
static EIF_REFERENCE F57_1030_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1030);
#define Result RTOSR(1030)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1174, 0x01).id, 1174, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1175_10481(RTCW(tr1), (EIF_REAL_32) 0.7, (EIF_REAL_32) 0.7, (EIF_REAL_32) 0.7);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1030);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F57_1030 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1030,F57_1030_body,(Current));
}

/* {EV_STOCK_COLORS}.dark_gray */
static EIF_REFERENCE F57_1032_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1032);
#define Result RTOSR(1032)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1174, 0x01).id, 1174, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1175_10481(RTCW(tr1), (EIF_REAL_32) 0.5, (EIF_REAL_32) 0.5, (EIF_REAL_32) 0.5);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1032);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F57_1032 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1032,F57_1032_body,(Current));
}

/* {EV_STOCK_COLORS}.blue */
static EIF_REFERENCE F57_1033_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1033);
#define Result RTOSR(1033)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1174, 0x01).id, 1174, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	tr4_2 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	tr4_3 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	F1175_10481(RTCW(tr1), tr4_1, tr4_2, tr4_3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1033);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F57_1033 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1033,F57_1033_body,(Current));
}

/* {EV_STOCK_COLORS}.red */
static EIF_REFERENCE F57_1041_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1041);
#define Result RTOSR(1041)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1174, 0x01).id, 1174, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	tr4_2 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	tr4_3 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	F1175_10481(RTCW(tr1), tr4_1, tr4_2, tr4_3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1041);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F57_1041 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1041,F57_1041_body,(Current));
}

/* {EV_STOCK_COLORS}.default_background_color */
EIF_REFERENCE F57_1051 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F48_857(RTCV(RTOSCF(1054,F57_1054, (Current))));
	RTLE;
	return Result;
}

/* {EV_STOCK_COLORS}.default_foreground_color */
EIF_REFERENCE F57_1052 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F48_860(RTCV(RTOSCF(1054,F57_1054, (Current))));
	RTLE;
	return Result;
}

/* {EV_STOCK_COLORS}.implementation */
static EIF_REFERENCE F57_1054_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1054);
#define Result RTOSR(1054)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(47, 0x01).id, 47, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1054);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F57_1054 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1054,F57_1054_body,(Current));
}

void EIF_Minit43 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
