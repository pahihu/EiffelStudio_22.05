/*
 * Code for class GDK_HELPERS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gd31.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F45_793
static void inline_F45_793 (EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	return gdk_device_get_position ((GdkDevice*) arg1, NULL, (gint*) arg2, (gint*) arg3);
	;
}
#define INLINE_F45_793
#endif
#ifndef INLINE_F45_796
static EIF_POINTER inline_F45_796 (void)
{
	return (GdkDevice*) gdk_seat_get_pointer((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default()));
	;
}
#define INLINE_F45_796
#endif
#ifndef INLINE_F45_798
static EIF_INTEGER_32 inline_F45_798 (void)
{
	return gdk_display_get_default_cursor_size ((GdkDisplay*) gdk_display_get_default());
	;
}
#define INLINE_F45_798
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GDK_HELPERS}.device_get_position */
void F45_793 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	
	
	inline_F45_793 ((EIF_POINTER) arg1, (EIF_INTEGER_32*) arg2, (EIF_INTEGER_32*) arg3);
}

/* {GDK_HELPERS}.default_device */
EIF_POINTER F45_796 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F45_796 ();
	return Result;
}

/* {GDK_HELPERS}.default_cursor_size */
EIF_INTEGER_32 F45_798 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F45_798 ();
	return Result;
}

void EIF_Minit31 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
