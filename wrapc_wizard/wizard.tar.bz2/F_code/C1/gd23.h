
#ifndef _C1_gd23_
#define _C1_gd23_

#ifdef __cplusplus
extern "C" {
#endif

extern void F37_614(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_REAL_64, EIF_REAL_64);
extern void EIF_Minit23(void);

#ifdef __cplusplus
}
#endif

#endif
