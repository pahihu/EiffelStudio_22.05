/*
 * Code for class GTK_ORIENTATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt33.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F47_853
static EIF_NATURAL_8 inline_F47_853 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F47_853
#endif
#ifndef INLINE_F47_854
static EIF_NATURAL_8 inline_F47_854 (void)
{
	return GTK_ORIENTATION_VERTICAL
	;
}
#define INLINE_F47_854
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_ORIENTATION}.gtk_orientation_horizontal */
EIF_NATURAL_8 F47_853 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	
	
	Result = inline_F47_853 ();
	return Result;
}

/* {GTK_ORIENTATION}.gtk_orientation_vertical */
EIF_NATURAL_8 F47_854 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	
	
	Result = inline_F47_854 ();
	return Result;
}

void EIF_Minit33 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
