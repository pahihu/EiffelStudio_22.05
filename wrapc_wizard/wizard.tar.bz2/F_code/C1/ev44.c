/*
 * Code for class EV_STOCK_PIXMAPS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev44.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STOCK_PIXMAPS}.information_pixmap */
static EIF_REFERENCE F59_1059_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1059);
#define Result RTOSR(1059)
	RTOC_NEW(Result);
	Result = F363_5401(RTCV(RTOSCF(1079,F59_1079, (Current))));
	RTOSE (1059);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F59_1059 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1059,F59_1059_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.error_pixmap */
static EIF_REFERENCE F59_1060_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1060);
#define Result RTOSR(1060)
	RTOC_NEW(Result);
	Result = F363_5402(RTCV(RTOSCF(1079,F59_1079, (Current))));
	RTOSE (1060);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F59_1060 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1060,F59_1060_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.default_window_icon */
static EIF_REFERENCE F59_1063_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1063);
#define Result RTOSR(1063)
	RTOC_NEW(Result);
	Result = F363_5409(RTCV(RTOSCF(1079,F59_1079, (Current))));
	RTOSE (1063);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F59_1063 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1063,F59_1063_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.standard_cursor */
static EIF_REFERENCE F59_1065_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1065);
#define Result RTOSR(1065)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1176_10521(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1065);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F59_1065 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1065,F59_1065_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.help_cursor */
static EIF_REFERENCE F59_1067_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1067);
#define Result RTOSR(1067)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1176_10521(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1067);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F59_1067 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1067,F59_1067_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.ibeam_cursor */
static EIF_REFERENCE F59_1068_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1068);
#define Result RTOSR(1068)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1176_10521(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1068);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F59_1068 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1068,F59_1068_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.no_cursor */
static EIF_REFERENCE F59_1069_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1069);
#define Result RTOSR(1069)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1176_10521(RTCW(tr1), ((EIF_INTEGER_32) 6L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1069);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F59_1069 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1069,F59_1069_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.sizeall_cursor */
static EIF_REFERENCE F59_1070_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1070);
#define Result RTOSR(1070)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1176_10521(RTCW(tr1), ((EIF_INTEGER_32) 7L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1070);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F59_1070 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1070,F59_1070_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.implementation */
static EIF_REFERENCE F59_1079_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1079);
#define Result RTOSR(1079)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(362, 0x01).id, 362, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1079);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F59_1079 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1079,F59_1079_body,(Current));
}

void EIF_Minit44 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
