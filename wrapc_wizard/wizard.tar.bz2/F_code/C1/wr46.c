/*
 * Code for class WRAPC_WIZARD_FUNCTION_GENERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wr46.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WRAPC_WIZARD_FUNCTION_GENERATOR}.make */
void F61_1087 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,849,0xFF01,1136,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F850_6641(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,846,0xFF01,1136,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F841_6510(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F61_1098(Current);
	F61_1099(Current);
	tr1 = RTLNS(eif_new_type(1014, 0x01).id, 1014, _OBJSIZ_2_1_0_0_0_0_0_0_);
	F1015_8460(RTCW(tr1), arg1);
	F61_1090(Current, tr1);
	RTLE;
}

/* {WRAPC_WIZARD_FUNCTION_GENERATOR}.read_file_line_by_line */
void F61_1090 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1002, 0x01).id, 1002, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F1003_8150(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6852[Dtype(RTCW(loc1))-1001])(loc1);
	if (tb2) {
		tb2 = F1001_7906(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		F1001_7938(RTCW(loc1));
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6964[Dtype(RTCW(loc1))-1001])(loc1);
			if (tb1) break;
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R6911[Dtype(RTCW(loc1))-1001])(loc1);
			loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
			if (F61_1100(Current, loc2)) {
			} else {
				F61_1091(Current, loc2);
			}
		}
		F1001_7955(RTCW(loc1));
	}
	RTLE;
}

/* {WRAPC_WIZARD_FUNCTION_GENERATOR}.extract_function */
void F61_1091 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc5);
	RTLIU(5);
	
	RTGC;
	if (F61_1096(Current, arg1)) {
		loc1 = F1_14(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		loc4 = F1135_10094(RTCW(loc1), (EIF_CHARACTER_8) '(', ti4_1);
		if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 1L))) {
			loc4--;
			loc3 = F1137_10160(RTCW(loc1), loc4);
			if ((EIF_BOOLEAN)(loc3 == (EIF_CHARACTER_8) ' ')) {
				for (;;) {
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN)(loc3 != (EIF_CHARACTER_8) ' '))) break;
					loc4--;
					if ((EIF_BOOLEAN) (loc4 >= ((EIF_INTEGER_32) 1L))) {
						loc3 = F1137_10160(RTCW(loc1), loc4);
					}
				}
			}
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc4--;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L)) || loc2)) break;
				loc3 = F1137_10160(RTCW(loc1), loc4);
				tb1 = '\0';
				tb2 = eif_builtin_CHARACTER_8_is_space__c1_b(loc3);
				if (tb2) {
					tb1 = (EIF_BOOLEAN) !loc2;
				}
				if (tb1) {
					loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					loc4--;
				}
			}
		}
		if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			tr1 = F1137_10240(RTCW(loc1), ((EIF_INTEGER_32) 1L), ti4_1);
			tb1 = F558_5957(RTCW(tr1));
			if ((EIF_BOOLEAN) !tb1) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				loc5 = F1137_10240(RTCW(loc1), ((EIF_INTEGER_32) 1L), ti4_1);
			}
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			tr1 = F1137_10240(RTCW(loc1), loc4, ti4_1);
			tb1 = F558_5957(RTCW(tr1));
			if ((EIF_BOOLEAN) !tb1) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				loc5 = F1137_10240(RTCW(loc1), loc4, ti4_1);
			}
		}
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			F1131_9906(RTCW(loc5));
			tr1 = RTMS_EX_H("(",1,40);
			tb1 = F1135_10116(RTCW(loc5), tr1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = *(EIF_REFERENCE *)(Current);
				F850_6681(RTCW(tr1), loc5);
			}
		}
	}
	RTLE;
}

/* {WRAPC_WIZARD_FUNCTION_GENERATOR}.c_function_pattern */

EIF_REFERENCE F61_1094 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1094,RTMS_EX_H("^(.+)\?([a-zA-Z]\\w*)(\\s*)\?\\(.+\\);",32,648332091));
}

/* {WRAPC_WIZARD_FUNCTION_GENERATOR}.c_callback_pattern */

EIF_REFERENCE F61_1095 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1095,RTMS_EX_H("^(typedef)(\\s+)([a-zA-Z]\\w*)(\\s*)\?\\(.+\\);",41,1406118203));
}

/* {WRAPC_WIZARD_FUNCTION_GENERATOR}.is_valid_function */
EIF_BOOLEAN F61_1096 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1136, 0x01).id, 1136, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1135_10082(RTCW(loc1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = F1564_16078(RTCW(tr1), loc1);
	RTLE;
	return Result;
}

/* {WRAPC_WIZARD_FUNCTION_GENERATOR}.is_valid_callback */
EIF_BOOLEAN F61_1097 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1136, 0x01).id, 1136, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1135_10082(RTCW(loc1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1564_16078(RTCW(tr1), loc1);
	RTLE;
	return Result;
}

/* {WRAPC_WIZARD_FUNCTION_GENERATOR}.compile_function_expression */
void F61_1098 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1571, 1).id);
	F1571_16391(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTOSCF(1094,F61_1094, (Current));
	F1571_16394(RTCW(tr1), tr2);
	RTLE;
}

/* {WRAPC_WIZARD_FUNCTION_GENERATOR}.compile_callback_expression */
void F61_1099 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1571, 1).id);
	F1571_16391(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTOSCF(1095,F61_1095, (Current));
	F1571_16394(RTCW(tr1), tr2);
	RTLE;
}

/* {WRAPC_WIZARD_FUNCTION_GENERATOR}.is_callback_definition */
EIF_BOOLEAN F61_1100 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = F1_14(arg1);
	F1131_9906(RTCW(loc1));
	Result = F61_1097(Current, loc1);
	if (Result) {
		ti4_1 = F1135_10093(RTCW(loc1), (EIF_CHARACTER_8) '*', ((EIF_INTEGER_32) 1L));
		ti4_2 = F1135_10093(RTCW(loc1), (EIF_CHARACTER_8) ')', ((EIF_INTEGER_32) 1L));
		loc2 = F1137_10240(RTCW(loc1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (ti4_2 - ((EIF_INTEGER_32) 1L)));
		F1131_9906(RTCW(loc2));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F841_6557(RTCW(tr1), loc1, loc2);
	}
	RTLE;
	return Result;
}

void EIF_Minit46 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
