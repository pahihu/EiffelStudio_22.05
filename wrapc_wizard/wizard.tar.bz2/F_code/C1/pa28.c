/*
 * Code for class PANGO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pa28.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F42_750
static EIF_POINTER inline_F42_750 (void)
{
	return pango_attr_list_new();
	;
}
#define INLINE_F42_750
#endif
#ifndef INLINE_F42_753
static EIF_POINTER inline_F42_753 (EIF_POINTER arg1)
{
	return pango_attr_font_desc_new ((const PangoFontDescription *)arg1);
	;
}
#define INLINE_F42_753
#endif
#ifndef INLINE_F42_754
static void inline_F42_754 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	pango_attr_list_insert ((PangoAttrList *)arg1, (PangoAttribute *)arg2);
	;
}
#define INLINE_F42_754
#endif
#ifndef INLINE_F42_755
static void inline_F42_755 (EIF_POINTER arg1)
{
	pango_attr_list_unref ((PangoAttrList *)arg1);
	;
}
#define INLINE_F42_755
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PANGO}.scale */
EIF_INTEGER_32 F42_698 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) PANGO_SCALE;
	return Result;
}

/* {PANGO}.font_description_new */
EIF_POINTER F42_701 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) pango_font_description_new();
	
	return Result;
}

/* {PANGO}.font_description_free */
void F42_702 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	pango_font_description_free((PangoFontDescription*) arg1);
	
}

/* {PANGO}.font_description_set_family */
void F42_705 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	pango_font_description_set_family((PangoFontDescription*) arg1, (char*) arg2);
	
}

/* {PANGO}.font_description_set_style */
void F42_707 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	pango_font_description_set_style((PangoFontDescription*) arg1, (PangoStyle) arg2);
	
}

/* {PANGO}.font_description_set_weight */
void F42_709 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	pango_font_description_set_weight((PangoFontDescription*) arg1, (PangoWeight) arg2);
	
}

/* {PANGO}.font_description_set_size */
void F42_711 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	pango_font_description_set_size((PangoFontDescription*) arg1, (gint) arg2);
	
}

/* {PANGO}.layout_set_font_description */
void F42_714 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	pango_layout_set_font_description((PangoLayout*) arg1, (PangoFontDescription*) arg2);
	
}

/* {PANGO}.layout_get_pixel_size */
void F42_716 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	
	pango_layout_get_pixel_size((PangoLayout*) arg1, (gint*) arg2, (gint*) arg3);
	
}

/* {PANGO}.layout_get_iter */
EIF_POINTER F42_717 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) pango_layout_get_iter((PangoLayout*) arg1);
	
	return Result;
}

/* {PANGO}.layout_set_text */
void F42_718 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	pango_layout_set_text((PangoLayout*) arg1, (char*) arg2, (int) arg3);
	
}

/* {PANGO}.layout_iter_get_baseline */
EIF_INTEGER_32 F42_719 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) pango_layout_iter_get_baseline((PangoLayoutIter*) arg1);
	
	return Result;
}

/* {PANGO}.layout_iter_free */
void F42_720 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	pango_layout_iter_free((PangoLayoutIter*) arg1);
	
}

/* {PANGO}.layout_get_pixel_extents */
void F42_722 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	
	pango_layout_get_pixel_extents((PangoLayout*) arg1, (PangoRectangle*) arg2, (PangoRectangle*) arg3);
	
}

/* {PANGO}.new_rectangle_struct */
EIF_POINTER F42_734 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) calloc (sizeof(PangoRectangle), 1);
	return Result;
}

/* {PANGO}.rectangle_struct_x */
EIF_INTEGER_32 F42_735 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->x);
	
	return Result;
}

/* {PANGO}.rectangle_struct_y */
EIF_INTEGER_32 F42_736 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->y);
	
	return Result;
}

/* {PANGO}.rectangle_struct_width */
EIF_INTEGER_32 F42_737 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->width);
	
	return Result;
}

/* {PANGO}.rectangle_struct_height */
EIF_INTEGER_32 F42_738 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->height);
	
	return Result;
}

/* {PANGO}.pango_attr_list_new */
EIF_POINTER F42_750 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F42_750 ();
	return Result;
}

/* {PANGO}.pango_attr_font_desc_new */
EIF_POINTER F42_753 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F42_753 ((EIF_POINTER) arg1);
	return Result;
}

/* {PANGO}.pango_attr_list_insert */
void F42_754 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F42_754 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {PANGO}.pango_attr_list_unref */
void F42_755 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F42_755 ((EIF_POINTER) arg1);
}

void EIF_Minit28 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
