/*
 * Code for class EV_GTK_EVENT_STRINGS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev32.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_EVENT_STRINGS}.set_focus_event_name */

EIF_REFERENCE F46_806 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (806,RTMS_EX_H("set-focus",9,577130099));
}

/* {EV_GTK_EVENT_STRINGS}.configure_event_name */

EIF_REFERENCE F46_807 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (807,RTMS_EX_H("configure-event",15,1205453684));
}

/* {EV_GTK_EVENT_STRINGS}.map_event_name */

EIF_REFERENCE F46_810 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (810,RTMS_EX_H("map-event",9,474090100));
}

/* {EV_GTK_EVENT_STRINGS}.unmap_event_name */

EIF_REFERENCE F46_811 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (811,RTMS_EX_H("unmap-event",11,77806708));
}

/* {EV_GTK_EVENT_STRINGS}.hide_signal_name */

EIF_REFERENCE F46_812 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (812,RTMS_EX_H("hide",4,1751737445));
}

/* {EV_GTK_EVENT_STRINGS}.size_allocate_event_name */

EIF_REFERENCE F46_816 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (816,RTMS_EX_H("size-allocate",13,769151077));
}

/* {EV_GTK_EVENT_STRINGS}.clicked_event_name */

EIF_REFERENCE F46_819 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (819,RTMS_EX_H("clicked",7,169941860));
}

/* {EV_GTK_EVENT_STRINGS}.draw_event_name */

EIF_REFERENCE F46_821 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (821,RTMS_EX_H("draw",4,1685217655));
}

/* {EV_GTK_EVENT_STRINGS}.commit_event_name */

EIF_REFERENCE F46_822 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (822,RTMS_EX_H("commit",6,2031381364));
}

/* {EV_GTK_EVENT_STRINGS}.changed_event_name */

EIF_REFERENCE F46_823 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (823,RTMS_EX_H("changed",7,346303332));
}

/* {EV_GTK_EVENT_STRINGS}.response_event_name */

EIF_REFERENCE F46_827 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (827,RTMS_EX_H("response",8,1418183525));
}

/* {EV_GTK_EVENT_STRINGS}.scroll_event_name */

EIF_REFERENCE F46_833 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (833,RTMS_EX_H("scroll-event",12,2102824820));
}

/* {EV_GTK_EVENT_STRINGS}.commit_event_string */
static EIF_REFERENCE F46_852_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (852);
#define Result RTOSR(852)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr2 = RTOSCF(822,F46_822, (Current));
	F993_7487(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (852);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F46_852 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(852,F46_852_body,(Current));
}

void EIF_Minit32 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
