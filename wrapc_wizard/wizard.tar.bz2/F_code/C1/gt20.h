
#ifndef _C1_gt20_
#define _C1_gt20_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F34_477(EIF_REFERENCE);
extern EIF_BOOLEAN F34_478(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32, EIF_POINTER*);
extern void EIF_Minit20(void);

#ifdef __cplusplus
}
#endif

#endif
