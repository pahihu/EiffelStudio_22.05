/*
 * Code for class reference BYTE_CODE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "by18.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BYTE_CODE_CONSTANTS}.extract_max */
EIF_NATURAL_32 F31_296 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	RTGC;
	Result = (EIF_NATURAL_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2147483647L) - ((EIF_INTEGER_32) 1L)) - ((EIF_INTEGER_32) 70L));
	return Result;
}

void EIF_Minit18 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
