
#ifndef _C1_ba5_
#define _C1_ba5_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F11_64(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit5(void);
extern void F381_5651(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
