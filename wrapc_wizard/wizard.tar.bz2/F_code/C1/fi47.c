/*
 * Code for class FILE_UTILITIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fi47.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FILE_UTILITIES}.directory_path_exists */
EIF_BOOLEAN F63_1106 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tb1 = F1015_8468(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTLNS(eif_new_type(995, 0x01).id, 995, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F996_7522(RTCW(tr1), arg1);
		tb1 = F996_7545(RTCW(tr1));
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {FILE_UTILITIES}.create_directory */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F63_1111 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	RTLD;
	RTXD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,saved_except);
	RTLIU(4);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc1) {
		tr1 = RTLNS(eif_new_type(995, 0x01).id, 995, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F996_7520(RTCW(tr1), arg1);
		loc2 = (EIF_REFERENCE) tr1;
		tb1 = F996_7545(RTCW(loc2));
		if ((EIF_BOOLEAN) !tb1) {
			F996_7525(RTCW(loc2));
		}
	}
	RTE_E
	RTXSC;
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

void EIF_Minit47 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
