
#ifndef _C1_gt26_
#define _C1_gt26_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F40_659(EIF_REFERENCE);
extern EIF_INTEGER_32 F40_660(EIF_REFERENCE);
extern EIF_INTEGER_32 F40_661(EIF_REFERENCE);
extern void EIF_Minit26(void);

#ifdef __cplusplus
}
#endif

#endif
