
#ifndef _C1_gt38_
#define _C1_gt38_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F52_933(EIF_REFERENCE);
extern EIF_POINTER F52_940(EIF_REFERENCE);
extern EIF_POINTER F52_941(EIF_REFERENCE);
extern void EIF_Minit38(void);

#ifdef __cplusplus
}
#endif

#endif
