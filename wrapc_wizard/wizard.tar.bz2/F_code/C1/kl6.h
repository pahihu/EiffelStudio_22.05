
#ifndef _C1_kl6_
#define _C1_kl6_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,67)
static EIF_REFERENCE F12_67_body(EIF_REFERENCE);
extern EIF_REFERENCE F12_67(EIF_REFERENCE);
extern void EIF_Minit6(void);

#ifdef __cplusplus
}
#endif

#endif
