
#ifndef _C1_fi48_
#define _C1_fi48_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F62_1106(EIF_REFERENCE, EIF_REFERENCE);
extern void F62_1111(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit48(void);
extern void F996_7525(EIF_REFERENCE);
extern EIF_BOOLEAN F1015_8468(EIF_REFERENCE);
extern void F996_7522(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F996_7545(EIF_REFERENCE);
extern void F996_7520(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
