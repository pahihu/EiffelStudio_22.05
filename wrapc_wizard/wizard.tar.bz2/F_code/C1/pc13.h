
#ifndef _C1_pc13_
#define _C1_pc13_

#ifdef __cplusplus
extern "C" {
#endif

extern void F21_163(EIF_REFERENCE);
extern void F21_164(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F21_166(EIF_REFERENCE, EIF_INTEGER_32);
extern void F21_167(EIF_REFERENCE, EIF_REFERENCE);
extern void F21_168(EIF_REFERENCE, EIF_INTEGER_32);
extern void F21_169(EIF_REFERENCE, EIF_REFERENCE);
extern void F21_170(EIF_REFERENCE, EIF_REFERENCE);
extern void F21_171(EIF_REFERENCE);
extern void EIF_Minit13(void);
extern void F921_7187(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1137_10163(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
