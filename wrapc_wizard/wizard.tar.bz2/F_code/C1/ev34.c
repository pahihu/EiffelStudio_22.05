/*
 * Code for class EV_STOCK_COLORS_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev34.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F146_2614
static void inline_F146_2614 (EIF_POINTER arg1)
{
	gtk_widget_destroy((GtkWidget*) arg1)
	;
}
#define INLINE_F146_2614
#endif
#ifndef INLINE_F146_2514
static EIF_POINTER inline_F146_2514 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_COLOR)
	;
}
#define INLINE_F146_2514
#endif
#ifndef INLINE_F146_2536
static void inline_F146_2536 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	gtk_style_context_get (arg1, arg2, arg3, arg4, NULL)
	;
}
#define INLINE_F146_2536
#endif
#ifndef INLINE_F146_2513
static EIF_POINTER inline_F146_2513 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_BACKGROUND_COLOR)
	;
}
#define INLINE_F146_2513
#endif
#ifndef INLINE_F146_2515
static EIF_POINTER inline_F146_2515 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_FONT)
	;
}
#define INLINE_F146_2515
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STOCK_COLORS_IMP}.default_background_color */
EIF_REFERENCE F48_857 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_POINTER) gtk_dialog_new();
	ti4_1 = (EIF_INTEGER_32) GTK_STATE_NORMAL;
	Result = F48_864(Current, loc1, ((EIF_INTEGER_32) 4L), ti4_1);
	inline_F146_2614(loc1);
	RTLE;
	return Result;
}

/* {EV_STOCK_COLORS_IMP}.default_foreground_color */
EIF_REFERENCE F48_860 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_POINTER) gtk_dialog_new();
	ti4_1 = (EIF_INTEGER_32) GTK_STATE_NORMAL;
	Result = F48_864(Current, loc1, ((EIF_INTEGER_32) 3L), ti4_1);
	inline_F146_2614(loc1);
	RTLE;
	return Result;
}

/* {EV_STOCK_COLORS_IMP}.color_from_state */
EIF_REFERENCE F48_864 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REAL_32 loc3 = (EIF_REAL_32) 0;
	EIF_REAL_32 loc4 = (EIF_REAL_32) 0;
	EIF_REAL_32 loc5 = (EIF_REAL_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REAL_32 loc7 = (EIF_REAL_32) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc6);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) arg1);
	gtk_style_context_save((GtkStyleContext*) loc1);
	gtk_style_context_set_state((GtkStyleContext*) loc1, (GtkStateFlags) arg3);
	switch (arg2) {
		case 3L:
			ti4_1 = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) loc1);
			tp1 = inline_F146_2514();
			inline_F146_2536(loc1, ti4_1, tp1, (EIF_POINTER *) &(loc2));
			break;
		case 4L:
			ti4_1 = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) loc1);
			tp1 = inline_F146_2513();
			inline_F146_2536(loc1, ti4_1, tp1, (EIF_POINTER *) &(loc2));
			break;
		case 1L:
			ti4_1 = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) loc1);
			tp1 = inline_F146_2515();
			inline_F146_2536(loc1, ti4_1, tp1, (EIF_POINTER *) &(loc2));
			break;
		case 2L:
			loc6 = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
			tr1 = RTMS_EX_H("background-color",16,693867890);
			F993_7487(RTCW(loc6), tr1);
			ti4_1 = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) loc1);
			tp1 = *(EIF_POINTER *)(RTCW(loc6)+ _PTROFF_0_1_0_1_0_0_);
			inline_F146_2536(loc1, ti4_1, tp1, (EIF_POINTER *) &(loc2));
			break;
		default:
			RTEC(EN_WHEN);
	}
	gtk_style_context_restore((GtkStyleContext*) loc1);
	tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->red);
	loc3 = (EIF_REAL_32) (tr8_1);
	tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->green);
	loc4 = (EIF_REAL_32) (tr8_1);
	tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->blue);
	loc5 = (EIF_REAL_32) (tr8_1);
	Result = RTLNS(eif_new_type(1174, 0x01).id, 1174, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1175_10481(RTCW(Result), loc3, loc4, loc5);
	gdk_rgba_free((GdkRGBA*) loc2);
	RTLE;
	return Result;
}

void EIF_Minit34 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
