/*
 * Code for class CAIRO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ca22.h"
#include <cairo.h>
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F36_522
static EIF_NATURAL_32 inline_F36_522 (EIF_POINTER arg1)
{
	return (EIF_NATURAL_32) (cairo_get_reference_count((cairo_t*) arg1))
	;
}
#define INLINE_F36_522
#endif
#ifndef INLINE_F36_528
static void inline_F36_528 (EIF_POINTER arg1)
{
	cairo_surface_destroy((cairo_surface_t*) arg1)
	;
}
#define INLINE_F36_528
#endif
#ifndef INLINE_F36_571
static void inline_F36_571 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	double len = 2.0;
if (arg2) {
	cairo_set_dash ((cairo_t *) arg1, &len, 1, 0.0);
} else {
	cairo_set_dash ((cairo_t *) arg1, NULL, 0, 0.0);
}
	;
}
#define INLINE_F36_571
#endif
#ifndef INLINE_F36_586
static void inline_F36_586 (EIF_POINTER arg1)
{
	cairo_paint ((cairo_t*)arg1)
	;
}
#define INLINE_F36_586
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CAIRO}.operator_source */
EIF_INTEGER_8 F36_505 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_SOURCE;
	return Result;
}

/* {CAIRO}.operator_over */
EIF_INTEGER_8 F36_506 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_OVER;
	return Result;
}

/* {CAIRO}.operator_atop */
EIF_INTEGER_8 F36_511 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_ATOP;
	return Result;
}

/* {CAIRO}.operator_difference */
EIF_INTEGER_8 F36_517 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_DIFFERENCE;
	return Result;
}

/* {CAIRO}.operator_exclusion */
EIF_INTEGER_8 F36_518 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_EXCLUSION;
	return Result;
}

/* {CAIRO}.operator_multiply */
EIF_INTEGER_8 F36_519 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_MULTIPLY;
	return Result;
}

/* {CAIRO}.create_context */
EIF_POINTER F36_520 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) cairo_create((cairo_surface_t*) arg1);
	
	return Result;
}

/* {CAIRO}.get_reference_count */
EIF_NATURAL_32 F36_522 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	Result = inline_F36_522 ((EIF_POINTER) arg1);
	return Result;
}

/* {CAIRO}.destroy */
void F36_523 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_destroy((cairo_t*) arg1);
	
}

/* {CAIRO}.set_source_surface */
void F36_527 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	
	cairo_set_source_surface((cairo_t*) arg1, (cairo_surface_t*) arg2, (double) arg3, (double) arg4);
	
}

/* {CAIRO}.surface_destroy */
void F36_528 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F36_528 ((EIF_POINTER) arg1);
}

/* {CAIRO}.surface_flush */
void F36_531 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_surface_flush((cairo_surface_t*) arg1);
	
}

/* {CAIRO}.image_surface_create */
EIF_POINTER F36_545 (EIF_REFERENCE Current, EIF_INTEGER_8 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) cairo_image_surface_create((cairo_format_t) arg1, (int) arg2, (int) arg3);
	
	return Result;
}

/* {CAIRO}.image_surface_get_width */
EIF_INTEGER_32 F36_549 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) cairo_image_surface_get_width((cairo_surface_t*) arg1);
	
	return Result;
}

/* {CAIRO}.image_surface_get_height */
EIF_INTEGER_32 F36_550 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) cairo_image_surface_get_height((cairo_surface_t*) arg1);
	
	return Result;
}

/* {CAIRO}.clip_extents */
void F36_553 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64* arg2, EIF_REAL_64* arg3, EIF_REAL_64* arg4, EIF_REAL_64* arg5)
{
	GTCX
	
	cairo_clip_extents((cairo_t*) arg1, (double*) arg2, (double*) arg3, (double*) arg4, (double*) arg5);
	
}

/* {CAIRO}.save */
void F36_563 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_save((cairo_t*) arg1);
	
}

/* {CAIRO}.restore */
void F36_564 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_restore((cairo_t*) arg1);
	
}

/* {CAIRO}.set_operator */
void F36_569 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_8 arg2)
{
	GTCX
	
	cairo_set_operator((cairo_t*) arg1, (cairo_operator_t) arg2);
	
}

/* {CAIRO}.set_antialias */
void F36_570 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_8 arg2)
{
	GTCX
	
	cairo_set_antialias((cairo_t*) arg1, (cairo_antialias_t) arg2);
	
}

/* {CAIRO}.set_dashed_line_style */
void F36_571 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	
	inline_F36_571 ((EIF_POINTER) arg1, (EIF_BOOLEAN) arg2);
}

/* {CAIRO}.fill */
void F36_574 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	cairo_fill((cairo_t*) arg1);
}

/* {CAIRO}.cairo_fill */
void F36_575 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_fill((cairo_t*) arg1);
	
}

/* {CAIRO}.scale */
void F36_584 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	
	cairo_scale((cairo_t*) arg1, (double) arg2, (double) arg3);
	
}

/* {CAIRO}.paint */
void F36_586 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F36_586 ((EIF_POINTER) arg1);
}

/* {CAIRO}.stroke */
void F36_587 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_stroke((cairo_t*) arg1);
	
}

/* {CAIRO}.stroke_preserve */
void F36_588 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_stroke_preserve((cairo_t*) arg1);
	
}

/* {CAIRO}.move_to */
void F36_589 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	
	cairo_move_to((cairo_t*) arg1, (double) arg2, (double) arg3);
	
}

/* {CAIRO}.line_to */
void F36_590 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	
	cairo_line_to((cairo_t*) arg1, (double) arg2, (double) arg3);
	
}

/* {CAIRO}.rectangle */
void F36_591 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5)
{
	GTCX
	
	cairo_rectangle((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4, (double) arg5);
	
}

/* {CAIRO}.set_source_rgba */
void F36_592 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5)
{
	GTCX
	
	cairo_set_source_rgba((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4, (double) arg5);
	
}

/* {CAIRO}.set_source_rgb */
void F36_593 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	
	cairo_set_source_rgb((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4);
	
}

/* {CAIRO}.arc_negative */
void F36_596 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6)
{
	GTCX
	
	cairo_arc_negative((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4, (double) arg5, (double) arg6);
	
}

/* {CAIRO}.set_line_width */
void F36_597 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2)
{
	GTCX
	
	cairo_set_line_width((cairo_t*) arg1, (double) arg2);
	
}

/* {CAIRO}.set_line_cap */
void F36_598 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_8 arg2)
{
	GTCX
	
	cairo_set_line_cap((cairo_t*) arg1, (cairo_line_cap_t) arg2);
	
}

/* {CAIRO}.close_path */
void F36_603 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_close_path((cairo_t*) arg1);
	
}

/* {CAIRO}.cairo_content_color_alpha */
EIF_INTEGER_32 F36_612 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) CAIRO_CONTENT_COLOR_ALPHA;
	return Result;
}

void EIF_Minit22 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
