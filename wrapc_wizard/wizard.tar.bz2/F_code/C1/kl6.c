/*
 * Code for class KL_STANDARD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl6.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STANDARD_FILES}.output */
static EIF_REFERENCE F12_67_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (67);
#define Result RTOSR(67)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(368, 0x01).id, 368, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (67);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F12_67 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(67,F12_67_body,(Current));
}

void EIF_Minit6 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
