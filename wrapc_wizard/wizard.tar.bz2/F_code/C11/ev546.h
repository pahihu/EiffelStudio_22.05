
#ifndef _C11_ev546_
#define _C11_ev546_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1219_11104(EIF_REFERENCE);
extern void F1219_11105(EIF_REFERENCE);
extern void EIF_Minit546(void);
extern void F1367_13225(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
