/*
 * Code for class EV_POINTER_STYLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev504.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_POINTER_STYLE}.make_predefined */
void F1176_10521 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1168_10363(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1290_11948(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_POINTER_STYLE}.set_x_hotspot */
void F1176_10524 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1290_11950(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_POINTER_STYLE}.set_y_hotspot */
void F1176_10525 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1290_11951(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_POINTER_STYLE}.x_hotspot */
EIF_INTEGER_32 F1176_10526 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE}.y_hotspot */
EIF_INTEGER_32 F1176_10527 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_1_);
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE}.width */
EIF_INTEGER_32 F1176_10528 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1290_11953(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE}.height */
EIF_INTEGER_32 F1176_10529 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1290_11954(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE}.copy */
void F1176_10530 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) == NULL)) {
		F1168_10363(Current);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1290_11963(RTCW(tr1), arg1);
	ti4_1 = F1176_10526(RTCW(arg1));
	F1176_10524(Current, ti4_1);
	ti4_1 = F1176_10527(RTCW(arg1));
	F1176_10525(Current, ti4_1);
	RTLE;
}

/* {EV_POINTER_STYLE}.is_equal */
EIF_BOOLEAN F1176_10531 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		Result = '\0';
		ti4_1 = F1176_10529(RTCW(arg1));
		ti4_2 = F1176_10528(RTCW(arg1));
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) (F1176_10528(Current) * ti4_1) == (EIF_INTEGER_32) (ti4_2 * F1176_10529(Current)))) {
			tb1 = '\0';
			ti4_1 = F1176_10526(RTCW(arg1));
			if ((EIF_BOOLEAN)(ti4_1 == F1176_10526(Current))) {
				ti4_1 = F1176_10527(RTCW(arg1));
				tb1 = (EIF_BOOLEAN)(ti4_1 == F1176_10527(Current));
			}
			Result = tb1;
		}
	}
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE}.create_interface_objects */
void F1176_10532 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_POINTER_STYLE}.create_implementation */
void F1176_10533 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1289, 0x01).id, 1289, _OBJSIZ_1_1_0_3_0_1_0_0_);
	F1290_11946(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {EV_POINTER_STYLE}.implementation */
EIF_REFERENCE F1176_10534 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


void EIF_Minit504 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
