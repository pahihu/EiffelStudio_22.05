
#ifndef _C11_ev531_
#define _C11_ev531_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1203_10866(EIF_REFERENCE, EIF_REFERENCE);
extern void F1203_10867(EIF_REFERENCE, EIF_REFERENCE);
extern void F1203_10868(EIF_REFERENCE);
extern void EIF_Minit531(void);
extern void F1342_12831(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R10460[])();

#ifdef __cplusplus
}
#endif

#endif
