
#ifndef _C11_ev510_
#define _C11_ev510_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1182_10621(EIF_REFERENCE);
extern void F1182_10623(EIF_REFERENCE);
extern void EIF_Minit510(void);
extern void F1402_13729(EIF_REFERENCE);
extern void F1402_13727(EIF_REFERENCE);
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
