
#ifndef _C11_ev514_
#define _C11_ev514_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1186_10674(EIF_REFERENCE);
extern EIF_REFERENCE F1186_10675(EIF_REFERENCE);
extern void F1186_10676(EIF_REFERENCE, EIF_REFERENCE);
extern void F1186_10677(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit514(void);
extern EIF_REFERENCE F1312_12576(EIF_REFERENCE);
extern EIF_REFERENCE F1312_12577(EIF_REFERENCE);
extern char *(*R10287[])();
extern char *(*R10288[])();
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
