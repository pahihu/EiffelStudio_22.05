/*
 * Code for class EV_ACCELERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev508.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ACCELERATOR}.make_with_key_combination */
void F1180_10587 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1168_10363(Current);
	F1180_10594(Current, arg1);
	if (arg2) {
		F1180_10599(Current);
	}
	if (arg3) {
		F1180_10597(Current);
	}
	if (arg4) {
		F1180_10595(Current);
	}
	RTLE;
}

/* {EV_ACCELERATOR}.actions */
EIF_REFERENCE F1180_10588 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1296_12086(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.key */
EIF_REFERENCE F1180_10590 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.shift_required */
EIF_BOOLEAN F1180_10591 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_3_);
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.alt_required */
EIF_BOOLEAN F1180_10592 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_2_);
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.control_required */
EIF_BOOLEAN F1180_10593 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_1_);
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.set_key */
void F1180_10594 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1297_12104(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_ACCELERATOR}.enable_shift_required */
void F1180_10595 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1297_12105(RTCW(tr1));
	RTLE;
}

/* {EV_ACCELERATOR}.enable_alt_required */
void F1180_10597 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1297_12107(RTCW(tr1));
	RTLE;
}

/* {EV_ACCELERATOR}.enable_control_required */
void F1180_10599 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1297_12109(RTCW(tr1));
	RTLE;
}

/* {EV_ACCELERATOR}.is_equal */
EIF_BOOLEAN F1180_10601 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	tr1 = F1180_10590(Current);
	tr2 = F1180_10590(RTCW(arg1));
	tb3 = (EIF_BOOLEAN) eif_builtin_ANY_is_equal__o_b (tr1, tr2);
	if (tb3) {
		tb3 = F1180_10592(RTCW(arg1));
		tb2 = (EIF_BOOLEAN)(F1180_10592(Current) == tb3);
	}
	if (tb2) {
		tb2 = F1180_10591(RTCW(arg1));
		tb1 = (EIF_BOOLEAN)(F1180_10591(Current) == tb2);
	}
	if (tb1) {
		tb1 = F1180_10593(RTCW(arg1));
		Result = (EIF_BOOLEAN)(F1180_10593(Current) == tb1);
	}
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.text */
EIF_REFERENCE F1180_10602 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1132_9913(RTCW(Result), ((EIF_INTEGER_32) 0L));
	if (F1180_10593(Current)) {
		tr1 = F1129_9842(RTMS_EX_H("Ctrl+",5,1954170411));
		F1134_10028(RTCW(Result), tr1);
	}
	if (F1180_10592(Current)) {
		tr1 = F1129_9842(RTMS_EX_H("Alt+",4,1097626667));
		F1134_10028(RTCW(Result), tr1);
	}
	if (F1180_10591(Current)) {
		tr1 = F1129_9842(RTMS_EX_H("Shift+",6,1932305451));
		F1134_10028(RTCW(Result), tr1);
	}
	loc1 = F1468_14926(RTCV(F1180_10590(Current)));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
		F1134_10070(RTCW(loc1));
	}
	F1134_10028(RTCW(Result), loc1);
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.out */
EIF_REFERENCE F1180_10603 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F1129_9837(RTCV(F1180_10602(Current)));
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.implementation */
EIF_REFERENCE F1180_10604 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {EV_ACCELERATOR}.create_interface_objects */
void F1180_10605 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_ACCELERATOR}.create_implementation */
void F1180_10606 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1296, 0x01).id, 1296, _OBJSIZ_3_5_0_0_0_0_0_0_);
	F1297_12099(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit508 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
