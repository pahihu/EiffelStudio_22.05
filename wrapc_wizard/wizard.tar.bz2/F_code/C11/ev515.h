
#ifndef _C11_ev515_
#define _C11_ev515_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1187_10683(EIF_REFERENCE);
extern void EIF_Minit515(void);
extern long O10312[];
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
