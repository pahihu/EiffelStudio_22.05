
#ifndef _C11_ev534_
#define _C11_ev534_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1206_10901(EIF_REFERENCE);
extern void F1206_10902(EIF_REFERENCE);
extern void EIF_Minit534(void);
extern void F1348_12882(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
