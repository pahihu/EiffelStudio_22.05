
#ifndef _C11_ev528_
#define _C11_ev528_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1200_10772(EIF_REFERENCE);
extern void F1200_10780(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1200_10788(EIF_REFERENCE);
extern void F1200_10790(EIF_REFERENCE);
extern void F1200_10791(EIF_REFERENCE);
extern void F1200_10792(EIF_REFERENCE);
extern void F1200_10794(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1200_10800(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1200_10807(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1200_10810(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1200_10811(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1200_10816(EIF_REFERENCE);
extern void EIF_Minit528(void);
extern void F1451_14633(EIF_REFERENCE);
extern char *(*R11301[])();
extern char *(*R11307[])();
extern char *(*R11308[])();
extern char *(*R11312[])();
extern char *(*R11318[])();
extern char *(*R11325[])();
extern char *(*R11328[])();
extern char *(*R11329[])();
extern char *(*R11294[])();
extern char *(*R11295[])();
extern long O11424[];
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
