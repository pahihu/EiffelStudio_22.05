
#ifndef _C11_ev532_
#define _C11_ev532_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1204_10871(EIF_REFERENCE);
extern void F1204_10875(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1204_10876(EIF_REFERENCE);
extern void F1204_10877(EIF_REFERENCE);
extern void EIF_Minit532(void);
extern void F1343_12844(EIF_REFERENCE);
extern EIF_REFERENCE F1343_12845(EIF_REFERENCE);
extern void F1343_12847(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
