
#ifndef _C11_ev502_
#define _C11_ev502_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1174_10475(EIF_REFERENCE);
extern void F1174_10476(EIF_REFERENCE);
extern EIF_REFERENCE F1174_10477(EIF_REFERENCE);
extern void EIF_Minit502(void);
extern void F1285_11847(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
