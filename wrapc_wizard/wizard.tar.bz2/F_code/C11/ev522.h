
#ifndef _C11_ev522_
#define _C11_ev522_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1194_10741(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit522(void);
extern char *(*R10418[])();
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
