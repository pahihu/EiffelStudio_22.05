
#ifndef _C11_ev525_
#define _C11_ev525_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1197_10755(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1197_10756(EIF_REFERENCE);
extern void F1197_10757(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit525(void);
extern void F1168_10363(EIF_REFERENCE);
extern void F1132_9921(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R10437[])();
extern char *(*R10438[])();
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
