/*
 * Code for class EV_SELECTABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev523.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SELECTABLE}.is_selected */
EIF_BOOLEAN F1195_10747 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (F1195_10748(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10413[Dtype(RTCW(tr1))-1418])(tr1);
	}
	RTLE;
	return Result;
}

/* {EV_SELECTABLE}.is_selectable */
EIF_BOOLEAN F1195_10748 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10412[Dtype(RTCW(tr1))-1418])(tr1);
	RTLE;
	return Result;
}

void EIF_Minit523 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
