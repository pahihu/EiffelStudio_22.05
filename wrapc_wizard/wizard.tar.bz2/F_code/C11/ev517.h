
#ifndef _C11_ev517_
#define _C11_ev517_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1189_10707(EIF_REFERENCE);
extern EIF_INTEGER_32 F1189_10708(EIF_REFERENCE);
extern EIF_INTEGER_32 F1189_10709(EIF_REFERENCE);
extern EIF_INTEGER_32 F1189_10710(EIF_REFERENCE);
extern EIF_INTEGER_32 F1189_10711(EIF_REFERENCE);
extern void EIF_Minit517(void);
extern char *(*R10364[])();
extern char *(*R10365[])();
extern char *(*R10366[])();
extern char *(*R10367[])();
extern char *(*R10363[])();
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
