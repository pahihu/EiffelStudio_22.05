
#ifndef _C11_ev536_
#define _C11_ev536_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1208_10913(EIF_REFERENCE);
extern void EIF_Minit536(void);
extern long O10496[];
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
