
#ifndef _C11_ev519_
#define _C11_ev519_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1191_10722(EIF_REFERENCE);
extern EIF_BOOLEAN F1191_10723(EIF_REFERENCE);
extern void EIF_Minit519(void);
extern long O10396[];
extern long O10397[];
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
