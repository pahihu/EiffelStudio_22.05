
#ifndef _C11_ev527_
#define _C11_ev527_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1199_10770(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit527(void);
extern char *(*R10433[])();
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
