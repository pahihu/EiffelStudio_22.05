/*
 * Code for class EV_SENSITIVE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev538.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SENSITIVE}.is_sensitive */
EIF_BOOLEAN F1211_10980 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	Result = F1325_12727(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_SENSITIVE}.disable_sensitive */
void F1211_10983 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	F1325_12730(RTCW(tr1));
	RTLE;
}

void EIF_Minit538 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
