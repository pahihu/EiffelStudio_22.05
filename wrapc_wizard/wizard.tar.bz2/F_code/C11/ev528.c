/*
 * Code for class EV_DRAWABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev528.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DRAWABLE}.line_width */
EIF_INTEGER_32 F1200_10772 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1) + O11424[Dtype(tr1)-1450]);
	RTLE;
	return Result;
}

/* {EV_DRAWABLE}.set_line_width */
void F1200_10780 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R11294[Dtype(RTCW(tr1))-1451])(tr1, arg1);
	RTLE;
}

/* {EV_DRAWABLE}.enable_dashed_line_style */
void F1200_10788 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11301[Dtype(RTCW(tr1))-1451])(tr1);
	RTLE;
}

/* {EV_DRAWABLE}.start_drawing_session */
void F1200_10790 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11307[Dtype(RTCW(tr1))-1451])(tr1);
	RTLE;
}

/* {EV_DRAWABLE}.end_drawing_session */
void F1200_10791 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11308[Dtype(RTCW(tr1))-1451])(tr1);
	RTLE;
}

/* {EV_DRAWABLE}.clear */
void F1200_10792 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	F1451_14633(RTCW(tr1));
	RTLE;
}

/* {EV_DRAWABLE}.draw_point */
void F1200_10794 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11312[Dtype(RTCW(tr1))-1451])(tr1, arg1, arg2);
	RTLE;
}

/* {EV_DRAWABLE}.draw_segment */
void F1200_10800 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R11318[Dtype(RTCW(tr1))-1451])(tr1, arg1, arg2, arg3, arg4);
	RTLE;
}

/* {EV_DRAWABLE}.draw_ellipse */
void F1200_10807 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R11325[Dtype(RTCW(tr1))-1451])(tr1, arg1, arg2, arg3, arg4);
	RTLE;
}

/* {EV_DRAWABLE}.fill_rectangle */
void F1200_10810 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R11328[Dtype(RTCW(tr1))-1451])(tr1, arg1, arg2, arg3, arg4);
	RTLE;
}

/* {EV_DRAWABLE}.fill_ellipse */
void F1200_10811 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R11329[Dtype(RTCW(tr1))-1451])(tr1, arg1, arg2, arg3, arg4);
	RTLE;
}

/* {EV_DRAWABLE}.set_invert_mode */
void F1200_10816 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R11295[Dtype(RTCW(tr1))-1451])(tr1, ((EIF_INTEGER_32) 2L));
	RTLE;
}

void EIF_Minit528 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
