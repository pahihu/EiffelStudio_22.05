
#ifndef _C11_ev533_
#define _C11_ev533_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1205_10879(EIF_REFERENCE);
extern EIF_REFERENCE F1205_10881(EIF_REFERENCE);
extern void F1205_10891(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit533(void);
extern void F1347_12874(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R10473[])();

#ifdef __cplusplus
}
#endif

#endif
