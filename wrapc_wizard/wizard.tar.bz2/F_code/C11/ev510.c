/*
 * Code for class EV_TAB_CONTROLABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev510.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TAB_CONTROLABLE}.enable_tabable_to */
void F1182_10621 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	F1402_13727(RTCW(tr1));
	RTLE;
}

/* {EV_TAB_CONTROLABLE}.enable_tabable_from */
void F1182_10623 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	F1402_13729(RTCW(tr1));
	RTLE;
}

void EIF_Minit510 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
