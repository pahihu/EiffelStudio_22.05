/*
 * Code for class EV_FRAME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev549.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FRAME}.default_identifier_name */
EIF_REFERENCE F1222_11157 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	tb1 = F554_5957(RTCV(F1197_10756(Current)));
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) F1181_10610(Current);
	} else {
		Result = F1_14(F1197_10756(Current));
		F1134_10069(RTCW(Result));
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
		F1134_10054(RTCW(Result), tw1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
		F1134_10054(RTCW(Result), tw1);
	}
	RTLE;
	return Result;
}

/* {EV_FRAME}.implementation */
EIF_REFERENCE F1222_11162 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_FRAME}.create_implementation */
void F1222_11163 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1372, 0x01).id, 1372, _OBJSIZ_51_13_10_8_0_1_0_0_);
	F1373_13263(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit549 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
