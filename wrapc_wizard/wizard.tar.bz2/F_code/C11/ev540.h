
#ifndef _C11_ev540_
#define _C11_ev540_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1213_11020(EIF_REFERENCE);
extern void F1213_11029(EIF_REFERENCE, EIF_REFERENCE);
extern void F1213_11030(EIF_REFERENCE, EIF_REFERENCE);
extern void F1213_11031(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1213_11033(EIF_REFERENCE);
extern EIF_INTEGER_32 F1213_11034(EIF_REFERENCE);
extern EIF_INTEGER_32 F1213_11035(EIF_REFERENCE);
extern void F1213_11036(EIF_REFERENCE);
extern void F1213_11037(EIF_REFERENCE);
extern void F1213_11052(EIF_REFERENCE, EIF_REFERENCE);
extern void F1213_11053(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit540(void);
extern void F1355_13104(EIF_REFERENCE);
extern void F1355_13103(EIF_REFERENCE);
extern char *(*R5488[])();
extern char *(*R9144[])();
extern char *(*R5429[])();
extern char *(*R9147[])();
extern char *(*R10621[])();
extern char *(*R10625[])();
extern char *(*R10626[])();
extern char *(*R10628[])();
extern char *(*R10629[])();
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
