/*
 * Code for class EV_PATH_FIELD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev547.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PATH_FIELD}.make */
void F1220_11106 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1220_11107(Current, NULL);
}

/* {EV_PATH_FIELD}.make_with_text */
void F1220_11107 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1014, 1).id);
	F1015_8458(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	F1168_10363(Current);
	F1220_11129(Current, arg1);
	RTLE;
}

/* {EV_PATH_FIELD}.parent_window */
EIF_REFERENCE F1220_11111 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		loc1 = F1220_11141(Current, Current);
	}
	RTCT0("l_result /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_PATH_FIELD}.file_path */
EIF_REFERENCE F1220_11116 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	RTCT0("l_field /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = RTLNS(eif_new_type(1014, 0x01).id, 1014, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tr1 = F1197_10756(RTCW(loc1));
	F1015_8460(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {EV_PATH_FIELD}.set_file_path */
void F1220_11120 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	RTCT0("l_field /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = F1015_8499(RTCW(arg1));
	F1197_10757(RTCW(loc1), tr1);
	RTLE;
}

/* {EV_PATH_FIELD}.set_browse_for_open_file */
void F1220_11122 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg1);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	RTCT0("l_browse_button /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = F1159_10302(RTCW(loc1));
	F865_6736(RTCW(tr1));
	tr1 = F1159_10302(RTCW(loc1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1049,0xFF01,0,0xFF01,1128,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = arg1;
	RTAR(tr2,arg1);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,0,1049,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A547_347, (EIF_POINTER) _A547_347, (EIF_POINTER)(F1220_11133),tr2, 1, 0);
	}
	F865_6724(RTCW(tr1), tr3);
	RTLE;
}

/* {EV_PATH_FIELD}.set_browse_for_directory */
void F1220_11124 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	RTCT0("l_browse_button /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = F1159_10302(RTCW(loc1));
	F865_6736(RTCW(tr1));
	tr1 = F1159_10302(RTCW(loc1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1049,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,0,1049,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A547_345, (EIF_POINTER) _A547_345, (EIF_POINTER)(F1220_11131),tr2, 1, 0);
	}
	F865_6724(RTCW(tr1), tr3);
	RTLE;
}

/* {EV_PATH_FIELD}.build_widget */
void F1220_11129 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc4);
	RTLIU(9);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = RTLNS(eif_new_type(1237, 0x01).id, 1237, _OBJSIZ_5_2_0_1_0_0_0_0_);
		F1197_10755(RTCW(loc1), arg1);
		F1198_10767(RTCW(loc1));
		F1210_10953(Current, loc1);
		F1217_11099(Current, loc1);
	}
	loc2 = RTLNS(eif_new_type(1217, 0x01).id, 1217, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1168_10363(RTCW(loc2));
	tr1 = RTLNS(eif_new_type(153, 0x01).id, 153, _OBJSIZ_0_0_0_0_0_0_0_0_);
	ti4_1 = RTOSCF(3270,F154_3270, (RTCW(tr1)));
	F1217_11097(RTCW(loc2), ti4_1);
	tr1 = RTLNSMART(eif_new_type(1240, 0).id);
	F1168_10363(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	loc3 = RTLNSMART(eif_new_type(1243, 0).id);
	tr1 = RTOSCF(11136,F1220_11136, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1049,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,0,1049,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A547_345, (EIF_POINTER) _A547_345, (EIF_POINTER)(F1220_11131),tr2, 1, 0);
	}
	F1244_11461(RTCW(loc3), tr1, tr3);
	RTAR(Current, loc3);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) loc3;
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	RTCT0("l_field /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F1210_10953(RTCW(loc2), loc4);
	F1210_10953(RTCW(loc2), loc3);
	F1217_11099(RTCW(loc2), loc3);
	F1210_10953(Current, loc2);
	RTLE;
}

/* {EV_PATH_FIELD}.browse_for_directory */
void F1220_11131 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1203, 0x01).id, 1203, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1168_10363(RTCW(loc1));
	tr1 = RTOSCF(11137,F1220_11137, (Current));
	F1203_10867(RTCW(loc1), tr1);
	loc2 = F1220_11135(Current);
	tb1 = '\0';
	tb2 = F1015_8468(RTCW(loc2));
	if ((EIF_BOOLEAN) !tb2) {
		tr1 = RTLNS(eif_new_type(995, 0x01).id, 995, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F996_7522(RTCW(tr1), loc2);
		tb2 = F996_7545(RTCW(tr1));
		tb1 = tb2;
	}
	if (tb1) {
		F1204_10875(RTCW(loc1), loc2);
	}
	tr1 = F1220_11111(Current);
	F1203_10866(RTCW(loc1), tr1);
	tb1 = '\0';
	tb2 = '\0';
	tr1 = F1204_10871(RTCW(loc1));
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		tr1 = F1204_10871(RTCW(loc1));
		tb3 = F1015_8468(RTCW(tr1));
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc3 = tr1;
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		tr1 = F1204_10871(RTCW(loc1));
		tr1 = F1015_8499(RTCW(tr1));
		F1197_10757(loc3, tr1);
	}
	RTLE;
}

/* {EV_PATH_FIELD}.browse_for_open_file */
void F1220_11133 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1220_11134(Current, arg1, (EIF_BOOLEAN) 0);
}

/* {EV_PATH_FIELD}.browse_for_file */
void F1220_11134 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLIU(8);
	
	RTGC;
	if (arg2) {
		loc1 = RTLNS(eif_new_type(1206, 0x01).id, 1206, _OBJSIZ_2_0_0_0_0_0_0_0_);
		F1168_10363(RTCW(loc1));
	} else {
		loc1 = RTLNS(eif_new_type(1205, 0x01).id, 1205, _OBJSIZ_2_0_0_0_0_0_0_0_);
		F1168_10363(RTCW(loc1));
	}
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = F1205_10881(RTCW(loc1));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1049,0xFF01,1133,0xFF01,1133,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 0);
		}
		tr3 = F1129_9842(RTCW(arg1));
		((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
		RTAR(tr2,tr3);
		tr3 = F1220_11140(Current, arg1);
		((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
		RTAR(tr2,tr3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5613[Dtype(RTCW(tr1))-692])(tr1, tr2);
		tr1 = F1205_10881(RTCW(loc1));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1049,0xFF01,1133,0xFF01,1133,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 0);
		}
		tr3 = F1129_9842(RTMS_EX_H("*.*",3,2764330));
		((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
		RTAR(tr2,tr3);
		tr3 = F1129_9842(RTCV(RTOSCF(11139,F1220_11139, (Current))));
		((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
		RTAR(tr2,tr3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5613[Dtype(RTCW(tr1))-692])(tr1, tr2);
	}
	tr1 = RTOSCF(11138,F1220_11138, (Current));
	F1203_10867(RTCW(loc1), tr1);
	loc2 = F1220_11135(Current);
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tb3 = F1015_8468(RTCW(loc2));
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tr1 = RTLNS(eif_new_type(995, 0x01).id, 995, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F996_7522(RTCW(tr1), loc2);
		tb2 = F996_7545(RTCW(tr1));
		tb1 = tb2;
	}
	if (tb1) {
		F1205_10891(RTCW(loc1), loc2);
	}
	tr1 = F1220_11111(Current);
	F1203_10866(RTCW(loc1), tr1);
	tb1 = '\0';
	tr1 = F1205_10879(RTCW(loc1));
	tb2 = F1015_8468(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc3 = tr1;
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		tr1 = F1205_10879(RTCW(loc1));
		tr1 = F1015_8499(RTCW(tr1));
		F1197_10757(loc3, tr1);
	}
	RTLE;
}

/* {EV_PATH_FIELD}.start_path */
EIF_REFERENCE F1220_11135 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	RTCT0("l_field /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = RTLNS(eif_new_type(1014, 0x01).id, 1014, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tr1 = F1197_10756(RTCW(loc1));
	F1015_8460(RTCW(Result), tr1);
	tb1 = F1015_8468(RTCW(Result));
	if (tb1) {
		Result = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_PATH_FIELD}.label_browse */

EIF_REFERENCE F1220_11136 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (11136,RTMS_EX_H("Browse...",9,1590170670));
}

/* {EV_PATH_FIELD}.label_select_directory */

EIF_REFERENCE F1220_11137 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (11137,RTMS_EX_H("Select a directory",18,1011494265));
}

/* {EV_PATH_FIELD}.label_select_file */

EIF_REFERENCE F1220_11138 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (11138,RTMS_EX_H("Select a file",13,1484166245));
}

/* {EV_PATH_FIELD}.label_all_files */

EIF_REFERENCE F1220_11139 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (11139,RTMS_EX_H("All Files (*.*)",15,1367844137));
}

/* {EV_PATH_FIELD}.label_files_of_type */
EIF_REFERENCE F1220_11140 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = RTMS_EX_H("Files of type (",15,1966662952);
	F1134_9989(RTCW(Result), tr1);
	F1134_10027(RTCW(Result), arg1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ')';
	F1134_10041(RTCW(Result), tw1);
	RTLE;
	return Result;
}

/* {EV_PATH_FIELD}.parent_window_of */
EIF_REFERENCE F1220_11141 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = arg1;
		loc1 = RTRV(eif_new_type(1224, 0x01),loc1);
		if (EIF_TEST(loc1)) {
			RTLE;
			return (EIF_REFERENCE) loc1;
		} else {
			tr1 = F1212_10988(RTCW(arg1));
			Result = F1220_11141(Current, tr1);
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit547 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
