
#ifndef _C11_ev521_
#define _C11_ev521_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1193_10732(EIF_REFERENCE);
extern void F1193_10734(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit521(void);
extern char *(*R10422[])();
extern char *(*R10423[])();
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
