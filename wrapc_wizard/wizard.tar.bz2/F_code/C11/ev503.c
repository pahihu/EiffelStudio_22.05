/*
 * Code for class EV_COLOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev503.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_COLOR}.make_with_8_bit_rgb */
void F1175_10480 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1168_10363(Current);
	F1175_10500(Current, arg1);
	F1175_10501(Current, arg2);
	F1175_10502(Current, arg3);
	RTLE;
}

/* {EV_COLOR}.make_with_rgb */
void F1175_10481 (EIF_REFERENCE Current, EIF_REAL_32 arg1, EIF_REAL_32 arg2, EIF_REAL_32 arg3)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1168_10363(Current);
	F1175_10491(Current, arg1);
	F1175_10492(Current, arg2);
	F1175_10493(Current, arg3);
	RTLE;
}

/* {EV_COLOR}.red */
EIF_REAL_32 F1175_10482 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_REAL_32 *)(RTCW(tr1)+ _R32OFF_2_1_0_3_2_);
	RTLE;
	return Result;
}

/* {EV_COLOR}.green */
EIF_REAL_32 F1175_10483 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_REAL_32 *)(RTCW(tr1)+ _R32OFF_2_1_0_3_1_);
	RTLE;
	return Result;
}

/* {EV_COLOR}.blue */
EIF_REAL_32 F1175_10484 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_REAL_32 *)(RTCW(tr1)+ _R32OFF_2_1_0_3_0_);
	RTLE;
	return Result;
}

/* {EV_COLOR}.set_red */
void F1175_10491 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1287_11905(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_COLOR}.set_green */
void F1175_10492 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1287_11906(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_COLOR}.set_blue */
void F1175_10493 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1287_11907(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_COLOR}.rgb_24_bit */
EIF_INTEGER_32 F1175_10494 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1287_11909(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_COLOR}.red_8_bit */
EIF_INTEGER_32 F1175_10497 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1287_11911(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_COLOR}.green_8_bit */
EIF_INTEGER_32 F1175_10498 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1287_11912(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_COLOR}.blue_8_bit */
EIF_INTEGER_32 F1175_10499 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1287_11913(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_COLOR}.set_red_with_8_bit */
void F1175_10500 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1287_11914(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_COLOR}.set_green_with_8_bit */
void F1175_10501 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1287_11915(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_COLOR}.set_blue_with_8_bit */
void F1175_10502 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1287_11916(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_COLOR}.red_16_bit */
EIF_INTEGER_32 F1175_10504 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_1_0_2_);
	RTLE;
	return Result;
}

/* {EV_COLOR}.green_16_bit */
EIF_INTEGER_32 F1175_10505 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_1_0_1_);
	RTLE;
	return Result;
}

/* {EV_COLOR}.blue_16_bit */
EIF_INTEGER_32 F1175_10506 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_1_0_0_);
	RTLE;
	return Result;
}

/* {EV_COLOR}.out */
EIF_REFERENCE F1175_10510 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1557, 0x01).id, 1557, _OBJSIZ_1_8_0_4_0_0_0_0_);
	F1558_15814(RTCW(loc1), ((EIF_INTEGER_32) 6L), ((EIF_INTEGER_32) 4L));
	tr8_1 = (EIF_REAL_64) (F1175_10482(Current));
	tr1 = F1558_15832(RTCW(loc1), tr8_1);
	tr2 = RTMS_EX_H(" ",1,32);
	tr1 = F1137_10212(RTCW(tr1), tr2);
	tr8_1 = (EIF_REAL_64) (F1175_10483(Current));
	tr2 = F1558_15832(RTCW(loc1), tr8_1);
	tr1 = F1137_10212(RTCW(tr1), tr2);
	tr2 = RTMS_EX_H(" ",1,32);
	tr1 = F1137_10212(RTCW(tr1), tr2);
	tr8_1 = (EIF_REAL_64) (F1175_10484(Current));
	tr2 = F1558_15832(RTCW(loc1), tr8_1);
	Result = F1137_10212(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {EV_COLOR}.is_equal */
EIF_BOOLEAN F1175_10511 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REAL_32 loc1 = (EIF_REAL_32) 0;
	EIF_REAL_32 tr4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc1 = F1175_10517(Current);
	Result = '\0';
	tb1 = '\0';
	tr4_1 = F1175_10482(RTCW(arg1));
	tr4_1 = eif_abs_real32 ((EIF_REAL_32) (tr4_1 - F1175_10482(Current)));
	if ((EIF_BOOLEAN) eif_is_less_real_32 (tr4_1, loc1)) {
		tr4_1 = F1175_10483(RTCW(arg1));
		tr4_1 = eif_abs_real32 ((EIF_REAL_32) (tr4_1 - F1175_10483(Current)));
		tb1 = (EIF_BOOLEAN) eif_is_less_real_32 (tr4_1, loc1);
	}
	if (tb1) {
		tr4_1 = F1175_10484(RTCW(arg1));
		tr4_1 = eif_abs_real32 ((EIF_REAL_32) (tr4_1 - F1175_10484(Current)));
		Result = (EIF_BOOLEAN) eif_is_less_real_32 (tr4_1, loc1);
	}
	RTLE;
	return Result;
}

/* {EV_COLOR}.copy */
void F1175_10512 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) == NULL)) {
		F1168_10363(Current);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1287_11923(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_COLOR}.hash_code */
EIF_INTEGER_32 F1175_10513 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F1175_10494(Current);
}

/* {EV_COLOR}.delta */
EIF_REAL_32 F1175_10517 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1287_11924(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_COLOR}.implementation */
EIF_REFERENCE F1175_10518 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {EV_COLOR}.create_interface_objects */
void F1175_10519 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_COLOR}.create_implementation */
void F1175_10520 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1286, 0x01).id, 1286, _OBJSIZ_2_1_0_3_3_0_0_0_);
	F1287_11900(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit503 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
