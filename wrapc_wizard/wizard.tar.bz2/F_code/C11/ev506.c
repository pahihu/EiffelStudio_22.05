/*
 * Code for class EV_ENVIRONMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev506.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ENVIRONMENT}.application */
EIF_REFERENCE F1178_10566 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1293_12049(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_ENVIRONMENT}.implementation */
EIF_REFERENCE F1178_10576 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {EV_ENVIRONMENT}.create_interface_objects */
void F1178_10578 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_ENVIRONMENT}.create_implementation */
void F1178_10579 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(10375,F1168_10375, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1274_11680(RTCW(tr1), (EIF_BOOLEAN) 0);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1274_11675(RTCW(tr1), ((EIF_INTEGER_8) 5L), (EIF_BOOLEAN) 0);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1274_11675(RTCW(tr1), ((EIF_INTEGER_8) 4L), (EIF_BOOLEAN) 0);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1274_11675(RTCW(tr1), ((EIF_INTEGER_8) 0L), (EIF_BOOLEAN) 0);
	RTLE;
}

void EIF_Minit506 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
