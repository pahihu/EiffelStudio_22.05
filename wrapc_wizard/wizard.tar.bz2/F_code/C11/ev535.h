
#ifndef _C11_ev535_
#define _C11_ev535_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1207_10904(EIF_REFERENCE);
extern void F1207_10905(EIF_REFERENCE);
extern void EIF_Minit535(void);
extern void F1349_12891(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
