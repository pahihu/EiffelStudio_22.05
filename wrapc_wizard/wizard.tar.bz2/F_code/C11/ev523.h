
#ifndef _C11_ev523_
#define _C11_ev523_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1195_10747(EIF_REFERENCE);
extern EIF_BOOLEAN F1195_10748(EIF_REFERENCE);
extern void EIF_Minit523(void);
extern char *(*R10412[])();
extern char *(*R10413[])();
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
