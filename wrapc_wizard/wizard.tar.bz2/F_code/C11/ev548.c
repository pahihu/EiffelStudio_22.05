/*
 * Code for class EV_CELL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev548.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CELL}.has */
EIF_BOOLEAN F1221_11143 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) !F1168_10367(Current)) {
		tb1 = '\0';
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O10733[Dtype(tr1)-1371]);
			tb1 = (EIF_BOOLEAN)(tr1 == arg1);
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {EV_CELL}.is_empty */
EIF_BOOLEAN F1221_11144 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F1221_11146(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {EV_CELL}.full */
EIF_BOOLEAN F1221_11146 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O10733[Dtype(tr1)-1371]);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		Result = (EIF_BOOLEAN) !F1168_10367(Current);
	}
	RTLE;
	return Result;
}

/* {EV_CELL}.prunable */
EIF_BOOLEAN F1221_11147 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F1168_10367(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {EV_CELL}.readable */
EIF_BOOLEAN F1221_11149 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if (F1221_11146(Current)) {
		Result = (EIF_BOOLEAN) !F1168_10367(Current);
	}
	RTLE;
	return Result;
}

/* {EV_CELL}.prune */
void F1221_11151 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(F1213_11020(Current) == arg1)) {
		F1221_11152(Current);
	}
	RTLE;
}

/* {EV_CELL}.wipe_out */
void F1221_11152 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	F1372_13259(RTCW(tr1), NULL);
	RTLE;
}

/* {EV_CELL}.linear_representation */
EIF_REFERENCE F1221_11153 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,692,0xFF01,1211,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 692, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F693_6122(RTCW(loc1));
	if (F1221_11149(Current)) {
		tr1 = F1213_11020(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5613[Dtype(RTCW(loc1))-692])(loc1, tr1);
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_CELL}.implementation */
EIF_REFERENCE F1221_11154 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
}


/* {EV_CELL}.create_implementation */
void F1221_11155 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1371, 0x01).id, 1371, _OBJSIZ_49_13_10_6_0_1_0_0_);
	F1372_13255(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit548 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
