
#ifndef _C11_ev511_
#define _C11_ev511_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1183_10626(EIF_REFERENCE);
extern void EIF_Minit511(void);
extern EIF_REFERENCE F1288_11927(EIF_REFERENCE);
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
