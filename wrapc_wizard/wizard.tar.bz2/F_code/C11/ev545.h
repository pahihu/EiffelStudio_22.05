
#ifndef _C11_ev545_
#define _C11_ev545_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1218_11102(EIF_REFERENCE);
extern void F1218_11103(EIF_REFERENCE);
extern void EIF_Minit545(void);
extern void F1366_13222(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
