/*
 * Code for class EV_IDENTIFIABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev509.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_IDENTIFIABLE}.identifier_name */
EIF_REFERENCE F1181_10609 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8828[dtype-1180]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1_14(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTLE;
		return (EIF_REFERENCE) (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8822[dtype-1217])(Current);
	}/* NOTREACHED */
	
}

/* {EV_IDENTIFIABLE}.default_identifier_name */
EIF_REFERENCE F1181_10610 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTMS32_EX_H("{\000\000\000",1,123);
	tr2 = F1016_8520(RTCV(F1_5(Current)));
	tr1 = F1134_10047(tr1, tr2);
	tr2 = F1129_9842(RTMS_EX_H("}",1,125));
	Result = F1134_10047(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {EV_IDENTIFIABLE}.debug_output */
EIF_REFERENCE F1181_10612 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1132_9913(RTCW(Result), ((EIF_INTEGER_32) 10L));
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '<';
	F1134_10041(RTCW(Result), tw1);
	tr1 = eif_out__p_s1(Current);
	tr1 = F1129_9842(RTCW(tr1));
	F1134_10028(RTCW(Result), tr1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
	F1134_10041(RTCW(Result), tw1);
	if (F1181_10614(Current)) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F1134_10041(RTCW(Result), tw1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		F1134_10041(RTCW(Result), tw1);
		tr1 = F1181_10609(Current);
		F1134_10028(RTCW(Result), tr1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		F1134_10041(RTCW(Result), tw1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F1134_10041(RTCW(Result), tw1);
	}
	tr1 = F1016_8520(RTCV(F1_5(Current)));
	F1134_10028(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {EV_IDENTIFIABLE}.has_identifier_name_set */
EIF_BOOLEAN F1181_10614 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8828[Dtype(Current)-1180]) != NULL);
}

void EIF_Minit509 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
