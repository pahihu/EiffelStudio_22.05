
#ifndef _C11_ev538_
#define _C11_ev538_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1211_10980(EIF_REFERENCE);
extern void F1211_10983(EIF_REFERENCE);
extern void EIF_Minit538(void);
extern void F1325_12730(EIF_REFERENCE);
extern EIF_BOOLEAN F1325_12727(EIF_REFERENCE);
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
