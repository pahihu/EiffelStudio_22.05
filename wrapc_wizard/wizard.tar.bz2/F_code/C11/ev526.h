
#ifndef _C11_ev526_
#define _C11_ev526_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1198_10765(EIF_REFERENCE);
extern void F1198_10767(EIF_REFERENCE);
extern void EIF_Minit526(void);
extern char *(*R10450[])();
extern char *(*R10451[])();
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
