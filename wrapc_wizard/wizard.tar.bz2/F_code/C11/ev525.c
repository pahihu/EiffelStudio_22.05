/*
 * Code for class EV_TEXTABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev525.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TEXTABLE}.make_with_text */
void F1197_10755 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1168_10363(Current);
	F1197_10757(Current, arg1);
	RTLE;
}

/* {EV_TEXTABLE}.text */
EIF_REFERENCE F1197_10756 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10437[Dtype(RTCW(tr1))-1372])(tr1);
	RTLE;
	return Result;
}

/* {EV_TEXTABLE}.set_text */
void F1197_10757 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = arg1;
	if ((EIF_TRUE)) {
		tr1 = *(EIF_REFERENCE *)(Current + O8637[dtype-1167]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10438[Dtype(RTCW(tr1))-1372])(tr1, loc1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O8637[dtype-1167]);
		tr2 = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1132_9921(RTCW(tr2), arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10438[Dtype(RTCW(tr1))-1372])(tr1, tr2);
	}
	RTLE;
}

void EIF_Minit525 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
