/*
 * Code for class WRAPC_GRAPHICAL_WIZARD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wr513.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WRAPC_GRAPHICAL_WIZARD}.make_and_launch */
void F1185_10672 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	F1168_10363(Current);
	tb1 = '\01';
	tr1 = RTOSCF(5244,F355_5244, (Current));
	tr2 = RTMS_EX_H("ISE_PROJECTS",12,53375059);
	tr1 = F377_5613(RTCW(tr1), tr2);
	loc2 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc2))) {
		tb2 = F1129_9801(loc2);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = RTOSCF(5244,F355_5244, (Current));
		tr2 = RTLNS(eif_new_type(1567, 0x01).id, 1567, _OBJSIZ_0_3_0_0_0_0_0_0_);
		tr2 = RTOSCF(16188,F1567_16188, (RTCW(tr2)));
		tr2 = F1015_8499(RTCW(tr2));
		tr3 = RTMS_EX_H("ISE_PROJECTS",12,53375059);
		F377_5626(RTCW(tr1), tr2, tr3);
	}
	tr1 = RTOSCF(5607,F377_5607, (RTCV(RTOSCF(5244,F355_5244, (Current)))));
	tr2 = RTMS_EX_H("-console",8,454945893);
	ti4_1 = F395_5699(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = RTLNS(eif_new_type(1481, 0x01).id, 1481, _OBJSIZ_5_0_0_0_0_0_0_0_);
		F1482_15145(RTCW(tr1));
		{
			/* INLINED CODE (ANY.do_nothing) */
			tr2 = tr1;
			(void) RTCW(tr2);
			/* END INLINED CODE */
		}
		;
	} else {
		loc1 = RTLNSMART(eif_new_type(1228, 0).id);
		F1168_10363(RTCW(loc1));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) loc1;
		F1225_11216(RTCW(loc1));
		F1184_10641(Current);
	}
	RTLE;
}

void EIF_Minit513 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
