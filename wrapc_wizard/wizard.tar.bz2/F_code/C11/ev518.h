
#ifndef _C11_ev518_
#define _C11_ev518_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1190_10715(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1190_10716(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1190_10720(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit518(void);
extern void F1302_12440(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1302_12441(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1302_12437(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern long O8637[];

#ifdef __cplusplus
}
#endif

#endif
