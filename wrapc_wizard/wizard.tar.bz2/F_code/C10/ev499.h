
#ifndef _C10_ev499_
#define _C10_ev499_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1171_10428(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1171_10431(EIF_REFERENCE);
extern void F1171_10432(EIF_REFERENCE);
extern void F1171_10433(EIF_REFERENCE);
extern void EIF_Minit499(void);
extern void F1280_11786(EIF_REFERENCE);
extern void F1280_11788(EIF_REFERENCE, EIF_INTEGER_32);
extern void F872_6758(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
