
#ifndef _C10_ev494_
#define _C10_ev494_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1166_10343(EIF_REFERENCE);
extern void EIF_Minit494(void);
extern EIF_REFERENCE F169_3402(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
