/*
 * Code for class reference REAL_32
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re453.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {REAL_32}.is_less */
EIF_BOOLEAN F1088_9674 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = arg1;
	Result = F1087_9644(Current, tr1);
	RTLE;
	return Result;
}

/* {REAL_32}.truncated_to_integer */
EIF_INTEGER_32 F1088_9678 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F1087_9655(Current);
}

/* {REAL_32}.to_double */
EIF_REAL_64 F1088_9680 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REAL_64) F1087_9657(Current);
}

/* {REAL_32}.floor_real_32 */
EIF_REAL_32 F1088_9682 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REAL_32) F1087_9662(Current);
}

/* {REAL_32}.plus */
EIF_REAL_32 F1088_9683 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = arg1;
	tr1 = F1087_9665(Current, tr1);
	Result = *(EIF_REAL_32 *)(tr1);
	RTLE;
	return Result;
}

/* {REAL_32}.minus */
EIF_REAL_32 F1088_9684 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = arg1;
	tr1 = F1087_9666(Current, tr1);
	Result = *(EIF_REAL_32 *)(tr1);
	RTLE;
	return Result;
}

/* {REAL_32}.product */
EIF_REAL_32 F1088_9685 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = arg1;
	tr1 = F1087_9667(Current, tr1);
	Result = *(EIF_REAL_32 *)(tr1);
	RTLE;
	return Result;
}

/* {REAL_32}.quotient */
EIF_REAL_32 F1088_9686 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = arg1;
	tr1 = F1087_9668(Current, tr1);
	Result = *(EIF_REAL_32 *)(tr1);
	RTLE;
	return Result;
}

/* {REAL_32}.opposite */
EIF_REAL_32 F1088_9689 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return *(EIF_REAL_32 *)F1087_9671(Current);
}

/* {REAL_32}.out */
EIF_REFERENCE F1088_9697 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1087_9672(Current);
}

void EIF_Minit453 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
