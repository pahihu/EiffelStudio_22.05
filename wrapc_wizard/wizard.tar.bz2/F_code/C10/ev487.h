
#ifndef _C10_ev487_
#define _C10_ev487_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1159_10302(EIF_REFERENCE);
extern void EIF_Minit487(void);
extern EIF_REFERENCE F143_2146(EIF_REFERENCE);
extern char *(*R8571[])();

#ifdef __cplusplus
}
#endif

#endif
