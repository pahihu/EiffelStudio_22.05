
#ifndef _C10_ev493_
#define _C10_ev493_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1165_10326(EIF_REFERENCE);
extern EIF_REFERENCE F1165_10327(EIF_REFERENCE);
extern EIF_REFERENCE F1165_10333(EIF_REFERENCE);
extern void EIF_Minit493(void);
extern EIF_REFERENCE F198_3867(EIF_REFERENCE);
extern EIF_REFERENCE F198_3865(EIF_REFERENCE);
extern EIF_REFERENCE F198_3879(EIF_REFERENCE);
extern char *(*R8594[])();

#ifdef __cplusplus
}
#endif

#endif
