
#ifndef _C10_st459_
#define _C10_st459_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1131_9881(EIF_REFERENCE);
extern void F1131_9883(EIF_REFERENCE, EIF_NATURAL_32);
extern void F1131_9894(EIF_REFERENCE, EIF_REFERENCE);
extern void F1131_9906(EIF_REFERENCE);
extern void EIF_Minit459(void);
extern char *(*R8271[])();
extern char *(*R8272[])();
extern char *(*R8234[])();
extern char *(*R8352[])();
extern char *(*R8353[])();
extern char *(*R8360[])();
extern char *(*R8327[])();
extern char *(*R8330[])();
extern long O8324[];
extern long O8325[];

#ifdef __cplusplus
}
#endif

#endif
