/*
 * Code for class EV_ANY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev496.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ANY}.default_create */
void F1168_10363 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R8640[dtype-1170])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R8639[dtype-1170])(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O8637[dtype-1167]);
	F1274_11675(RTCW(tr1), ((EIF_INTEGER_8) 4L), (EIF_BOOLEAN) 1);
	tr1 = *(EIF_REFERENCE *)(Current + O8637[dtype-1167]);
	F1274_11660(RTCW(tr1), Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R8641[dtype-1170])(Current);
	RTLE;
}

/* {EV_ANY}.set_data */
void F1168_10365 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8633[Dtype(Current)-1167]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {EV_ANY}.destroy */
void F1168_10366 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	F1274_11663(RTCW(tr1));
	RTLE;
}

/* {EV_ANY}.is_destroyed */
EIF_BOOLEAN F1168_10367 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	Result = F1274_11665(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_ANY}.initialize */
void F1168_10372 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8637[Dtype(Current)-1167]);
	F1274_11675(RTCW(tr1), ((EIF_INTEGER_8) 5L), (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_ANY}.copy */
void F1168_10373 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
	RTCT0("can_copy_this_vision2_class", EX_CHECK);
		RTCF0;
}

/* {EV_ANY}.environment_i */
static EIF_REFERENCE F1168_10375_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10375);
#define Result RTOSR(10375)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1293, 0x01).id, 1293, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1294_12067(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10375);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1168_10375 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10375,F1168_10375_body,(Current));
}

void EIF_Minit496 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
