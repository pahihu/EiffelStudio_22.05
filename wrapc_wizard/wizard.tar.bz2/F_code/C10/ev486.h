
#ifndef _C10_ev486_
#define _C10_ev486_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1158_10300(EIF_REFERENCE);
extern void EIF_Minit486(void);
extern EIF_REFERENCE F142_2144(EIF_REFERENCE);
extern char *(*R8569[])();

#ifdef __cplusplus
}
#endif

#endif
