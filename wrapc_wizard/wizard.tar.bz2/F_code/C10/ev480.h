
#ifndef _C10_ev480_
#define _C10_ev480_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1152_10284(EIF_REFERENCE);
extern void EIF_Minit480(void);
extern EIF_REFERENCE F128_2041(EIF_REFERENCE);
extern char *(*R8553[])();

#ifdef __cplusplus
}
#endif

#endif
