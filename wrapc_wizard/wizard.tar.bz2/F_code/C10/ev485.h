
#ifndef _C10_ev485_
#define _C10_ev485_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1157_10298(EIF_REFERENCE);
extern void EIF_Minit485(void);
extern EIF_REFERENCE F140_2140(EIF_REFERENCE);
extern char *(*R8567[])();

#ifdef __cplusplus
}
#endif

#endif
