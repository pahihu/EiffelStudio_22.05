/*
 * Code for class POINTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "po455.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {POINTER}.hash_code */
EIF_INTEGER_32 F1122_9725 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F1090_9699(Current);
}

/* {POINTER}.is_default_pointer */
EIF_BOOLEAN F1122_9726 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F1090_9704(Current);
}

/* {POINTER}.plus */
EIF_POINTER F1122_9727 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_POINTER) F1090_9705(Current, arg1);
}

/* {POINTER}.out */
EIF_REFERENCE F1122_9729 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1090_9716(Current);
}

void EIF_Minit455 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
