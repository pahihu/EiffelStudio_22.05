
#ifndef _C10_ev492_
#define _C10_ev492_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1164_10323(EIF_REFERENCE);
extern void EIF_Minit492(void);
extern EIF_REFERENCE F162_3344(EIF_REFERENCE);
extern char *(*R8589[])();

#ifdef __cplusplus
}
#endif

#endif
