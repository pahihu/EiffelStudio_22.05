
#ifndef _C10_ev488_
#define _C10_ev488_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1160_10307(EIF_REFERENCE);
extern void EIF_Minit488(void);
extern void F1010_8397(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F550_5957(EIF_REFERENCE);
extern EIF_REFERENCE F164_3360(EIF_REFERENCE);
extern char *(*R8573[])();

#ifdef __cplusplus
}
#endif

#endif
