/*
 * Code for class GRAPHICAL_WIZARD_APPLICATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gr300.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GRAPHICAL_WIZARD_APPLICATION}.initialize */
void F361_5384 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F360_5361(Current);
	tr1 = RTLNSMART(eif_new_type(1220, 1).id);
	F1168_10363(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GRAPHICAL_WIZARD_APPLICATION}.build_interface */
void F361_5385 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = RTOSCF(3454,F172_3454, (RTCW(tr1)));
	F1225_11210(Current, tr1);
	F1190_10720(Current, ((EIF_INTEGER_32) 400L), ((EIF_INTEGER_32) 350L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = RTLNS(eif_new_type(1237, 0x01).id, 1237, _OBJSIZ_5_2_0_1_0_0_0_0_);
	tr3 = RTMS_EX_H("Loading ...",11,755025966);
	F1197_10755(RTCW(tr2), tr3);
	F1213_11030(RTCW(tr1), tr2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9144[Dtype(RTCW(arg1))-1217])(arg1, *(EIF_REFERENCE *)(Current + _REFACS_5_));
	F360_5376(Current);
	RTLE;
}

/* {GRAPHICAL_WIZARD_APPLICATION}.new_page */
EIF_REFERENCE F361_5389 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(939, 0x01).id, 939, _OBJSIZ_10_0_0_0_0_0_0_0_);
	F939_7315(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {GRAPHICAL_WIZARD_APPLICATION}.side_bar_items */
EIF_REFERENCE F361_5390 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,849,0xFF01,312,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 849, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F850_6641(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {GRAPHICAL_WIZARD_APPLICATION}.set_page */
void F361_5391 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	F360_5375(Current, arg1);
	loc1 = RTLNS(eif_new_type(1218, 0x01).id, 1218, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1168_10363(RTCW(loc1));
	F361_5392(Current, arg1, loc1);
	F1168_10365(RTCW(loc1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1213_11031(RTCW(tr1), loc1);
	RTLE;
}

/* {GRAPHICAL_WIZARD_APPLICATION}.append_page_to */
void F361_5392 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(24);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLR(3,loc10);
	RTLR(4,Current);
	RTLR(5,tr1);
	RTLR(6,loc5);
	RTLR(7,loc11);
	RTLR(8,loc12);
	RTLR(9,loc4);
	RTLR(10,loc9);
	RTLR(11,loc6);
	RTLR(12,loc13);
	RTLR(13,loc7);
	RTLR(14,loc14);
	RTLR(15,loc3);
	RTLR(16,loc8);
	RTLR(17,loc15);
	RTLR(18,loc16);
	RTLR(19,tr2);
	RTLR(20,loc17);
	RTLR(21,loc18);
	RTLR(22,tr3);
	RTLR(23,arg2);
	RTLIU(24);
	
	RTGC;
	F939_7358(RTCW(arg1));
	loc1 = RTLNS(eif_new_type(1218, 0x01).id, 1218, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1168_10363(RTCW(loc1));
	loc2 = RTLNS(eif_new_type(1217, 0x01).id, 1217, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1168_10363(RTCW(loc2));
	F1210_10953(RTCW(loc1), loc2);
	tb1 = '\0';
	tr1 = F1229_11250(Current, arg1);
	loc10 = tr1;
	if ((EIF_TRUE)) {
		tb2 = F550_5957(loc10);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc5 = RTLNS(eif_new_type(1218, 0x01).id, 1218, _OBJSIZ_6_3_0_1_0_0_0_0_);
		F1168_10363(RTCW(loc5));
		tr1 = RTLNS(eif_new_type(1174, 0x01).id, 1174, _OBJSIZ_2_0_0_0_0_0_0_0_);
		F1175_10480(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 180L));
		F1186_10677(RTCW(loc5), tr1);
		F1212_11012(RTCW(loc5), ((EIF_INTEGER_32) 150L));
		F1217_11095(RTCW(loc5), ((EIF_INTEGER_32) 10L));
		F1217_11096(RTCW(loc5), ((EIF_INTEGER_32) 5L));
		loc11 = F850_6655(loc10);
		for (;;) {
			tb1 = F789_6437(loc11);
			if (tb1) break;
			tb2 = F550_5957(RTCW(loc5));
			if ((EIF_BOOLEAN) !tb2) {
				tr1 = F645_6073(RTCW(loc5));
				F1217_11099(RTCW(loc5), tr1);
			}
			tr1 = F789_6428(loc11);
			loc12 = tr1;
			loc12 = RTRV(eif_new_type(322, 0x01),loc12);
			if (EIF_TEST(loc12)) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4939[Dtype(loc12)-323])(loc12);
				F1210_10953(RTCW(loc5), tr1);
			}
			F789_6443(loc11);
		}
		F1213_11037(RTCW(loc5));
		F1210_10953(RTCW(loc2), loc5);
		F1217_11099(RTCW(loc2), loc5);
	}
	loc4 = RTLNS(eif_new_type(1218, 0x01).id, 1218, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1168_10363(RTCW(loc4));
	F1210_10953(RTCW(loc2), loc4);
	tr1 = RTOSCF(1027,F57_1027, (RTCV(RTOSCF(3291,F155_3291, (Current)))));
	F1186_10677(RTCW(loc4), tr1);
	tb2 = F939_7327(RTCW(arg1));
	if (tb2) {
		loc9 = RTLNS(eif_new_type(1221, 0x01).id, 1221, _OBJSIZ_6_3_0_1_0_0_0_0_);
		F1168_10363(RTCW(loc9));
		tr1 = RTOSCF(1027,F57_1027, (RTCV(RTOSCF(3291,F155_3291, (Current)))));
		F1186_10677(RTCW(loc9), tr1);
		loc6 = RTLNS(eif_new_type(1218, 0x01).id, 1218, _OBJSIZ_6_3_0_1_0_0_0_0_);
		F1168_10363(RTCW(loc6));
		F1213_11029(RTCW(loc9), loc6);
		loc5 = RTLNS(eif_new_type(1218, 0x01).id, 1218, _OBJSIZ_6_3_0_1_0_0_0_0_);
		F1168_10363(RTCW(loc5));
		F1210_10953(RTCW(loc6), loc5);
		F1217_11095(RTCW(loc5), ((EIF_INTEGER_32) 10L));
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		loc13 = tr1;
		if (EIF_TEST(loc13)) {
			loc7 = RTLNS(eif_new_type(1237, 0x01).id, 1237, _OBJSIZ_5_2_0_1_0_0_0_0_);
			F1197_10755(RTCW(loc7), loc13);
			F155_3281(Current, loc7);
			F1210_10953(RTCW(loc5), loc7);
			F1217_11099(RTCW(loc5), loc7);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
			loc14 = tr1;
			if (EIF_TEST(loc14)) {
				loc3 = RTLNS(eif_new_type(1217, 0x01).id, 1217, _OBJSIZ_6_3_0_1_0_0_0_0_);
				F1168_10363(RTCW(loc3));
				loc7 = RTLNS(eif_new_type(1237, 0x01).id, 1237, _OBJSIZ_5_2_0_1_0_0_0_0_);
				F1197_10755(RTCW(loc7), loc14);
				F155_3282(Current, loc7);
				loc8 = RTLNS(eif_new_type(1220, 0x01).id, 1220, _OBJSIZ_6_3_0_1_0_0_0_0_);
				F1168_10363(RTCW(loc8));
				ti4_1 = F1217_11089(RTCW(loc5));
				F1212_11012(RTCW(loc8), ti4_1);
				F1210_10953(RTCW(loc3), loc8);
				F1217_11099(RTCW(loc3), loc8);
				F1210_10953(RTCW(loc3), loc7);
				F1210_10953(RTCW(loc5), loc3);
				F1217_11099(RTCW(loc5), loc3);
			}
		}
		F1213_11037(RTCW(loc9));
		tb2 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_9_);
		loc15 = tr1;
		if (EIF_TEST(loc15)) {
			tb3 = F550_5957(loc15);
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			loc5 = RTLNS(eif_new_type(1218, 0x01).id, 1218, _OBJSIZ_6_3_0_1_0_0_0_0_);
			F1168_10363(RTCW(loc5));
			F1210_10953(RTCW(loc6), loc5);
			loc16 = F850_6655(loc15);
			for (;;) {
				tb2 = F789_6437(loc16);
				if (tb2) break;
				loc7 = RTLNS(eif_new_type(1237, 0x01).id, 1237, _OBJSIZ_5_2_0_1_0_0_0_0_);
				tr1 = RTLNS(eif_new_type(1132, 0x00).id, 1132, _OBJSIZ_1_0_0_4_0_0_0_0_);
				tr2 = RTMS_EX_H(" - ",3,2108704);
				F1133_9967(RTCW(tr1), tr2);
				tr2 = F789_6428(loc16);
				tr2 = eif_boxed_item(tr2,1);
				tr1 = F1133_9976(RTCW(tr1), tr2);
				F1197_10755(RTCW(loc7), tr1);
				tr1 = F789_6428(loc16);
				ti4_1 = eif_integer_32_item(RTCW(tr1),2);
				if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 3L))) {
					tr1 = RTOSCF(3295,F155_3295, (Current));
					F1186_10677(RTCW(loc7), tr1);
					tr1 = RTOSCF(1041,F57_1041, (RTCV(RTOSCF(3291,F155_3291, (Current)))));
					F1186_10676(RTCW(loc7), tr1);
				} else {
					tr1 = F789_6428(loc16);
					ti4_1 = eif_integer_32_item(RTCW(tr1),2);
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
						tr1 = RTOSCF(3294,F155_3294, (Current));
						F1186_10677(RTCW(loc7), tr1);
					} else {
						tr1 = RTOSCF(3293,F155_3293, (Current));
						F1186_10677(RTCW(loc7), tr1);
					}
				}
				F155_3288(Current, loc7);
				F1210_10953(RTCW(loc5), loc7);
				F1217_11099(RTCW(loc5), loc7);
				F789_6443(loc16);
			}
		}
		F1210_10953(RTCW(loc4), loc9);
		F1217_11099(RTCW(loc4), loc9);
	}
	loc5 = RTLNS(eif_new_type(1218, 0x01).id, 1218, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1168_10363(RTCW(loc5));
	F1210_10953(RTCW(loc4), loc5);
	tr1 = F57_1051(RTCV(RTOSCF(3291,F155_3291, (Current))));
	F1186_10677(RTCW(loc5), tr1);
	F1217_11095(RTCW(loc5), ((EIF_INTEGER_32) 10L));
	F1217_11097(RTCW(loc5), ((EIF_INTEGER_32) 5L));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc17 = F850_6655(RTCW(tr1));
	for (;;) {
		tb3 = F789_6437(loc17);
		if (tb3) break;
		tb4 = F550_5957(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb4) {
			tr1 = F645_6073(RTCW(loc5));
			F1217_11099(RTCW(loc5), tr1);
		}
		tr1 = F789_6428(loc17);
		tr1 = F361_5393(Current, tr1);
		loc18 = tr1;
		if (EIF_TEST(loc18)) {
			F1210_10953(RTCW(loc5), loc18);
		}
		F789_6443(loc17);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = RTOSCF(3457,F172_3457, (RTCW(tr1)));
	if ((EIF_BOOLEAN)(arg1 == tr1)) {
		loc7 = RTLNS(eif_new_type(1237, 0x01).id, 1237, _OBJSIZ_5_2_0_1_0_0_0_0_);
		tr1 = RTMS_EX_H("To continue, click [Next].",26,1058675758);
		F1197_10755(RTCW(loc7), tr1);
		F155_3283(Current, loc7);
		F1210_10953(RTCW(loc5), loc7);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = RTOSCF(3462,F172_3462, (RTCW(tr1)));
	if ((EIF_BOOLEAN)(arg1 == tr1)) {
		loc7 = RTLNS(eif_new_type(1237, 0x01).id, 1237, _OBJSIZ_5_2_0_1_0_0_0_0_);
		tr1 = RTMS_EX_H("Click [Finish] to generate the project.",39,1735783982);
		F1197_10755(RTCW(loc7), tr1);
		F155_3283(Current, loc7);
		F1210_10953(RTCW(loc5), loc7);
	}
	loc9 = RTLNS(eif_new_type(1221, 0x01).id, 1221, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1168_10363(RTCW(loc9));
	F1210_10953(RTCW(loc1), loc9);
	F1217_11099(RTCW(loc1), loc9);
	loc2 = RTLNS(eif_new_type(1217, 0x01).id, 1217, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1168_10363(RTCW(loc2));
	F1213_11029(RTCW(loc9), loc2);
	F1217_11095(RTCW(loc2), ((EIF_INTEGER_32) 10L));
	tr1 = F57_1051(RTCV(RTOSCF(3291,F155_3291, (Current))));
	F1186_10677(RTCW(loc2), tr1);
	tr1 = RTLNS(eif_new_type(1220, 0x01).id, 1220, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1168_10363(RTCW(tr1));
	F1210_10953(RTCW(loc2), tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		tr1 = RTMS_EX_H("< Back",6,1231889259);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1049,0xFF01,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[4] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,0,1049,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3= RTLNRF(typres0.id, (EIF_POINTER) __A300_57, (EIF_POINTER) _A300_57, (EIF_POINTER)(F360_5378),tr2, 1, 0);
		}
		F361_5395(Current, tr1, tr3, loc2);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = RTOSCF(3462,F172_3462, (RTCW(tr1)));
	if ((EIF_BOOLEAN)(arg1 == tr1)) {
		tr1 = RTMS_EX_H("Finish",6,1990836584);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1049,0xFF01,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[4] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,0,1049,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3= RTLNRF(typres0.id, (EIF_POINTER) __A300_60, (EIF_POINTER) _A300_60, (EIF_POINTER)(F360_5382),tr2, 1, 0);
		}
		F361_5395(Current, tr1, tr3, loc2);
	} else {
		tr1 = RTMS_EX_H("Next >",6,27526462);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1049,0xFF01,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[4] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,0,1049,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3= RTLNRF(typres0.id, (EIF_POINTER) __A300_58, (EIF_POINTER) _A300_58, (EIF_POINTER)(F360_5379),tr2, 1, 0);
		}
		F361_5395(Current, tr1, tr3, loc2);
	}
	loc8 = RTLNS(eif_new_type(1220, 0x01).id, 1220, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1168_10363(RTCW(loc8));
	ti4_1 = F1217_11089(RTCW(loc2));
	F1212_11012(RTCW(loc8), ti4_1);
	F1210_10953(RTCW(loc2), loc8);
	F1217_11099(RTCW(loc2), loc8);
	tr1 = RTMS_EX_H("Cancel",6,1984480108);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1049,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1123,0xFF01,0xFFF9,0,1049,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A300_59, (EIF_POINTER) _A300_59, (EIF_POINTER)(F360_5380),tr2, 1, 0);
	}
	F361_5395(Current, tr1, tr3, loc2);
	F1213_11037(RTCW(loc2));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9144[Dtype(RTCW(arg2))-1217])(arg2, loc1);
	F939_7359(RTCW(arg1));
	RTLE;
}

/* {GRAPHICAL_WIZARD_APPLICATION}.page_item_to_widget */
EIF_REFERENCE F361_5393 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLR(5,Current);
	RTLR(6,Result);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTGC;
	loc2 = arg1;
	loc2 = RTRV(eif_new_type(322, 0x01),loc2);
	if (EIF_TEST(loc2)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4939[Dtype(loc2)-323])(loc2);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		loc3 = arg1;
		loc3 = RTRV(eif_new_type(314, 0x01),loc3);
		if (EIF_TEST(loc3)) {
			loc1 = RTLNS(eif_new_type(1237, 0x01).id, 1237, _OBJSIZ_5_2_0_1_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(loc3);
			F1197_10755(RTCW(loc1), tr1);
			tb1 = *(EIF_BOOLEAN *)(loc3 + O4902[Dtype(loc3)-314]);
			if (tb1) {
				F155_3284(Current, loc1);
			} else {
				F155_3283(Current, loc1);
			}
			Result = (EIF_REFERENCE) loc1;
		} else {
			loc4 = arg1;
			loc4 = RTRV(eif_new_type(313, 0x01),loc4);
			if (EIF_TEST(loc4)) {
				loc1 = RTLNS(eif_new_type(1237, 0x01).id, 1237, _OBJSIZ_5_2_0_1_0_0_0_0_);
				tr1 = *(EIF_REFERENCE *)(loc4);
				F1197_10755(RTCW(loc1), tr1);
				F155_3287(Current, loc1);
				RTLE;
				return (EIF_REFERENCE) loc1;
			}
		}
	}
	RTLE;
	return Result;
}

/* {GRAPHICAL_WIZARD_APPLICATION}.add_button_action_to */
void F361_5395 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,arg3);
	RTLR(4,arg2);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1243, 0x01).id, 1243, _OBJSIZ_6_2_0_1_0_0_0_0_);
	F1197_10755(RTCW(loc1), arg1);
	F155_3290(Current, loc1);
	F1210_10953(RTCW(arg3), loc1);
	F1217_11099(RTCW(arg3), loc1);
	if ((EIF_BOOLEAN)(arg2 == NULL)) {
		F1211_10983(RTCW(loc1));
	} else {
		tr1 = F1159_10302(RTCW(loc1));
		F865_6724(RTCW(tr1), arg2);
	}
	RTLE;
}

/* {GRAPHICAL_WIZARD_APPLICATION}.on_generate */
void F361_5396 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F360_5381(Current);
	F1168_10366(RTCV(F291_4465(Current)));
	RTLE;
}

void EIF_Minit300 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
