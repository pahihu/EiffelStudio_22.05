/*
 * Code for class KI_TEXT_OUTPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ki306.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KI_TEXT_OUTPUT_STREAM}.put_line */
void F367_5455 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F369_5471(Current, arg1);
	F367_5456(Current);
	RTLE;
}

/* {KI_TEXT_OUTPUT_STREAM}.put_new_line */
void F367_5456 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(5468,F369_5468, (Current));
	F369_5471(Current, tr1);
	RTLE;
}

void EIF_Minit306 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
