
#ifndef _C7_en317_
#define _C7_en317_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F378_5645(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit317(void);
extern EIF_REFERENCE F377_5613(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
