/*
 * Code for class EV_STOCK_PIXMAPS_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev302.h"
#include "ev_c_util.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STOCK_PIXMAPS_IMP}.information_pixmap */
EIF_REFERENCE F363_5401 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1236, 0x00).id, 1236, _OBJSIZ_6_3_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("dialog-information",18,1358691950);
	tr1 = F363_5410(Current, tr1);
	F1237_11339(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.error_pixmap */
EIF_REFERENCE F363_5402 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1236, 0x00).id, 1236, _OBJSIZ_6_3_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("dialog-error",12,1766531442);
	tr1 = F363_5410(Current, tr1);
	F1237_11339(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.default_window_icon */
EIF_REFERENCE F363_5409 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1236, 0x01).id, 1236, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1168_10363(RTCW(Result));
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_3_);
	F1454_14743(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.pixmap_from_stock_id */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_REFERENCE F363_5410 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	RTXD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLR(4,loc3);
	RTLR(5,saved_except);
	RTLIU(6);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc2) {
		tr1 = RTLNS(eif_new_type(992, 0x01).id, 992, _OBJSIZ_0_1_0_1_0_1_0_0_);
		F993_7487(RTCW(tr1), arg1);
		loc1 = (EIF_REFERENCE) tr1;
		tr1 = RTLNS(eif_new_type(1173, 0x01).id, 1173, _OBJSIZ_3_0_0_0_0_0_0_0_);
		F1168_10363(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
		RTCT0("attached {EV_PIXEL_BUFFER_IMP} Result.implementation as pixbuf_imp", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_1_);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1284, 0x01),loc3);
		if (EIF_TEST(loc3)) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1285_11862(loc3, loc1);
		F993_7493(RTCW(loc1));
	} else {
		tr1 = RTLNS(eif_new_type(1173, 0x01).id, 1173, _OBJSIZ_3_0_0_0_0_0_0_0_);
		F1168_10363(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
	}
	RTE_E
	RTXSC;
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_STOCK_PIXMAPS_IMP}.information_pixmap_xpm */
EIF_POINTER F363_5412 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) information_pixmap_xpm();
	
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.error_pixmap_xpm */
EIF_POINTER F363_5413 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) error_pixmap_xpm();
	
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.warning_pixmap_xpm */
EIF_POINTER F363_5414 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) warning_pixmap_xpm();
	
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.question_pixmap_xpm */
EIF_POINTER F363_5415 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) question_pixmap_xpm();
	
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.no_cursor_xpm */
EIF_POINTER F363_5424 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) no_cursor_xpm();
	
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.sizenesw_cursor_xpm */
EIF_POINTER F363_5426 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) sizenesw_cursor_xpm();
	
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.sizenwse_cursor_xpm */
EIF_POINTER F363_5428 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) sizenwse_cursor_xpm();
	
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.sizewe_cursor_xpm */
EIF_POINTER F363_5429 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) sizewe_cursor_xpm();
	
	return Result;
}

/* {EV_STOCK_PIXMAPS_IMP}.uparrow_cursor_xpm */
EIF_POINTER F363_5431 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) uparrow_cursor_xpm();
	
	return Result;
}

void EIF_Minit302 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
