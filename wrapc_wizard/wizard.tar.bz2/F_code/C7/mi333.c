/*
 * Code for class MISMATCH_CORRECTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "mi333.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {MISMATCH_CORRECTOR}.correct_mismatch */
void F839_6476 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = RTMS_EX_H("Mismatch: ",10,1538098208);
	F1134_9989(RTCW(loc1), tr1);
	loc2 = RTLNS(eif_new_type(247, 0x01).id, 247, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = F1016_8520(RTCV(F1_5(Current)));
	F1134_10028(RTCW(loc1), tr1);
	F248_4328(RTCW(loc2), loc1);
	RTLE;
}

/* {MISMATCH_CORRECTOR}.mismatch_information */
static EIF_REFERENCE F839_6477_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6477);
#define Result RTOSR(6477)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(848, 0x01).id, 848, _OBJSIZ_9_3_0_7_0_0_0_0_);
	F849_6629(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6477);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F839_6477 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6477,F839_6477_body,(Current));
}

void EIF_Minit333 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
