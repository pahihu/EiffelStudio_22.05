/*
 * Code for class BASE_PROCESS_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ba320.h"
#include <unistd.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F182_3643
static void inline_F182_3643 (EIF_INTEGER_32 arg1)
{
	{
	pid_t pgid = getpgid (arg1);
	tcsetpgrp (1, pgid);
	tcsetpgrp (2, pgid);
}
	;
}
#define INLINE_F182_3643
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BASE_PROCESS_IMP}.make */
void F381_5650 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,arg1);
	RTLR(6,arg3);
	RTLIU(7);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,849,0xFF01,1128,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 849, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F850_6641(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5429[Dtype(RTCW(arg2))-394])(arg2);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5790[Dtype(loc2)-730])(loc2);
			if (tb1) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5789[Dtype(loc2)-730])(loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5613[Dtype(RTCW(loc1))-692])(loc1, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5791[Dtype(loc2)-730])(loc2);
		}
	}
	F381_5665(Current, arg1, loc1, arg3);
	F381_5666(Current, arg1, loc1, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	F357_5341(Current);
	RTLE;
}

/* {BASE_PROCESS_IMP}.make_with_command_line */
void F381_5651 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	loc2 = F357_5344(Current, arg1);
	tb1 = F550_5957(RTCW(loc2));
	if (tb1) {
		loc1 = F1129_9842(RTMS_EX_H(" ",1,32));
		loc2 = (EIF_REFERENCE) NULL;
	} else {
		ti4_1 = F850_6662(RTCW(loc2));
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
			loc1 = F850_6649(RTCW(loc2));
			loc2 = (EIF_REFERENCE) NULL;
		} else {
			loc1 = F850_6649(RTCW(loc2));
			F850_6672(RTCW(loc2));
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5632[Dtype(RTCW(loc2))-692])(loc2);
		}
	}
	F381_5650(Current, loc1, loc2, arg2);
	RTLE;
}

/* {BASE_PROCESS_IMP}.close */
void F381_5655 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_13_15_) && *(EIF_BOOLEAN *)(Current+ _CHROFF_13_14_))) {
		ti4_1 = F380_5648(Current);
		inline_F182_3643(ti4_1);
	}
	F1005_8271(RTCV(F381_5668(Current)));
	RTLE;
}

/* {BASE_PROCESS_IMP}.platform_launch */
void F381_5656 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F381_5664(Current);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_13_15_) && *(EIF_BOOLEAN *)(Current+ _CHROFF_13_14_))) {
		ti4_1 = F380_5648(Current);
		inline_F182_3643(ti4_1);
	}
	tr1 = F381_5668(Current);
	F1005_8272(RTCW(tr1), *(EIF_BOOLEAN *)(Current+ _CHROFF_13_14_), *(EIF_REFERENCE *)(Current + _REFACS_5_), *(EIF_BOOLEAN *)(Current+ _CHROFF_13_15_));
	loc1 = *(EIF_INTEGER_32 *)(RTCV(F381_5668(Current))+ _LNGOFF_15_11_0_1_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_0_) = (EIF_INTEGER_32) loc1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) -1L));
	RTLE;
}

/* {BASE_PROCESS_IMP}.initialize_after_launch */
void F381_5657 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {BASE_PROCESS_IMP}.initialize_child_process */
void F381_5664 (EIF_REFERENCE Current)
{
	GTCX
	struct eif_ex_54 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(70, 0x00).id);
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = F381_5668(Current);
		tr2 = F71_1290(RTCW(loc1), loc2);
		F1005_8266(RTCW(tr1), tr2);
	} else {
		tr1 = F381_5668(Current);
		F1005_8266(RTCW(tr1), NULL);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tr1 = F381_5668(Current);
		tr2 = F71_1290(RTCW(loc1), loc3);
		F1005_8267(RTCW(tr1), tr2);
	} else {
		tr1 = F381_5668(Current);
		F1005_8267(RTCW(tr1), NULL);
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_3_) == ((EIF_INTEGER_32) 3L))) {
		F1005_8269(RTCV(F381_5668(Current)));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tr1 = F381_5668(Current);
			tr2 = F71_1290(RTCW(loc1), loc4);
			F1005_8268(RTCW(tr1), tr2);
		} else {
			tr1 = F381_5668(Current);
			F1005_8268(RTCW(tr1), NULL);
		}
	}
	RTLE;
}

/* {BASE_PROCESS_IMP}.setup_command */
void F381_5665 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg3);
	RTLR(3,Current);
	RTLR(4,arg2);
	RTLR(5,loc2);
	RTLR(6,tr1);
	RTLIU(7);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8271[Dtype(RTCW(arg1))-1132])(arg1);
	F1132_9913(RTCW(loc1), ti4_1);
	F1134_10027(RTCW(loc1), arg1);
	F357_5340(Current, arg3);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) arg2;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5429[Dtype(RTCW(arg2))-394])(arg2);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5790[Dtype(loc2)-730])(loc2);
			if (tb1) break;
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
			F1134_10041(RTCW(loc1), tw1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5789[Dtype(loc2)-730])(loc2);
			F1134_10027(RTCW(loc1), tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5791[Dtype(loc2)-730])(loc2);
		}
	}
	tr1 = RTLNS(eif_new_type(1132, 0x00).id, 1132, _OBJSIZ_1_0_0_4_0_0_0_0_);
	F1133_9968(RTCW(tr1), loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {BASE_PROCESS_IMP}.create_child_process_manager */
void F381_5666 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1004, 1).id);
	F1005_8252(RTCW(tr1), arg1, arg2, arg3);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	tr1 = F381_5668(Current);
	F1005_8265(RTCW(tr1), (EIF_BOOLEAN) 1);
	RTLE;
}

/* {BASE_PROCESS_IMP}.child_process */
static EIF_REFERENCE F381_5668_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F381_5668 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	if (!r) {
		GTCX
		RTLD;
		RTLI(1);
		RTLR(0,Current);
		RTLIU(1);
		r = (F381_5668_body (Current));
		*(EIF_REFERENCE *)(Current + _REFACS_12_) = r;
		RTAR(Current, r);
		RTLE;
	}
	return r;
}


void EIF_Minit320 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
