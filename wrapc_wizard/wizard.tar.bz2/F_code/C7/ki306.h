
#ifndef _C7_ki306_
#define _C7_ki306_

#ifdef __cplusplus
extern "C" {
#endif

extern void F367_5455(EIF_REFERENCE, EIF_REFERENCE);
extern void F367_5456(EIF_REFERENCE);
extern void EIF_Minit306(void);
extern void F369_5471(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F369_5468(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,5468)

#ifdef __cplusplus
}
#endif

#endif
