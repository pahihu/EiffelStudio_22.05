/*
 * Code for class EV_PND_ACTION_SEQUENCE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev336.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PND_ACTION_SEQUENCE}.call */
void F874_6796 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_2_0_1_)) {
			case 1L:
				tr1 = eif_boxed_item(arg1,1);
				tr2 = RTCCL(tr1);
				if (F874_6801(Current, tr2)) {
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,849,0xFF01,1123,0xFFF9,1,1049,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
						loc1 = RTLNS(typres0.id, 849, _OBJSIZ_1_1_0_1_0_0_0_0_);
					}
					ti4_1 = F850_6662(Current);
					F850_6641(RTCW(loc1), ti4_1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5614[Dtype(RTCW(loc1))-692])(loc1, Current);
					tr1 = F872_6783(Current);
					F698_6190(RTCW(tr1), (EIF_BOOLEAN) 0);
					F850_6672(RTCW(loc1));
					for (;;) {
						tb1 = '\01';
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O6024[Dtype(loc1)-849]);
						ti4_2 = F850_6662(RTCW(loc1));
						if (!(EIF_BOOLEAN) (ti4_1 > ti4_2)) {
							tb2 = F698_6188(RTCV(F872_6783(Current)));
							tb1 = tb2;
						}
						if (tb1) break;
						tr1 = F850_6646(RTCW(loc1));
						tb2 = F1123_9739(RTCW(tr1), arg1);
						if (tb2) {
							tr1 = F850_6646(RTCW(loc1));
							F1123_9748(RTCW(tr1), arg1);
						}
						F850_6674(RTCW(loc1));
					}
					F698_6192(RTCV(F872_6783(Current)));
				}
				break;
			case 2L:
				tr1 = F872_6785(Current);
				F696_6172(RTCW(tr1), arg1);
				break;
			case 3L:
				break;
			default:
				RTEC(EN_WHEN);
		}
	}
	RTLE;
}

/* {EV_PND_ACTION_SEQUENCE}.accepts_pebble */
EIF_BOOLEAN F874_6798 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = RTCCL(arg1);
	if (F874_6801(Current, tr1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1049,0xFF01,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
		RTAR(tr1,arg1);
		loc2 = (EIF_REFERENCE) tr1;
		loc1 = F850_6652(Current);
		F850_6672(Current);
		for (;;) {
			tb1 = '\01';
			if (!Result) {
				tb1 = F669_6111(Current);
			}
			if (tb1) break;
			tr1 = F850_6646(Current);
			Result = F1123_9739(RTCW(tr1), loc2);
			F850_6674(Current);
		}
		F850_6677(Current, loc1);
	}
	RTLE;
	return Result;
}

/* {EV_PND_ACTION_SEQUENCE}.veto_pebble_function_result */
EIF_BOOLEAN F874_6801 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1049,0xFF01,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
		RTAR(tr1,arg1);
		loc1 = (EIF_REFERENCE) tr1;
		Result = '\0';
		tb1 = F1123_9739(loc2, loc1);
		if (tb1) {
			tb1 = F1126_9780(loc2, loc1);
			Result = tb1;
		}
	} else {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return Result;
}

void EIF_Minit336 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
