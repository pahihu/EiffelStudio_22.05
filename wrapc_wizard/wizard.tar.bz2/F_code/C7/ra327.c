/*
 * Code for class RANDOM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ra327.h"
#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RANDOM}.set_seed */
void F732_6293 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {RANDOM}.modulus */
static EIF_INTEGER_32 F732_6295_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (6295);
#define Result RTOSR(6295)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	RTOSE (6295);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F732_6295 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6295,F732_6295_body,(Current));
}

/* {RANDOM}.multiplier */
static EIF_INTEGER_32 F732_6296_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (6296);
#define Result RTOSR(6296)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16807L);
	RTOSE (6296);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F732_6296 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6296,F732_6296_body,(Current));
}

/* {RANDOM}.increment */
static EIF_INTEGER_32 F732_6297_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (6297);
#define Result RTOSR(6297)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTOSE (6297);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F732_6297 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6297,F732_6297_body,(Current));
}

/* {RANDOM}.has */
EIF_BOOLEAN F732_6300 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) (arg1 < RTOSCF(6295,F732_6295, (Current)))) {
		Result = (EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 0L));
	}
	RTLE;
	return Result;
}

/* {RANDOM}.i_th */
EIF_INTEGER_32 F732_6301 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_))) {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_);
	} else {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_);
	}
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == arg1)) break;
		ti4_1 = F732_6307(Current, Result);
		Result = (EIF_INTEGER_32) ti4_1;
		loc1++;
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_) = (EIF_INTEGER_32) Result;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_) = (EIF_INTEGER_32) arg1;
	RTLE;
	return Result;
}

/* {RANDOM}.new_cursor */
EIF_REFERENCE F732_6306 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(731, 0x01).id, 731, _OBJSIZ_0_1_0_4_0_0_0_0_);
	F732_6293(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_));
	F549_5947(RTCW(Result));
	RTLE;
	return Result;
}

/* {RANDOM}.randomize */
EIF_INTEGER_32 F732_6307 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_64 tr8_4;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tr8_1 = RTOSCF(6312,F732_6312, (Current));
	tr8_2 = (EIF_REAL_64) (arg1);
	tr8_3 = RTOSCF(6313,F732_6313, (Current));
	tr8_4 = RTOSCF(6311,F732_6311, (Current));
	tr8_1 = F732_6308(Current, (EIF_REAL_64) ((EIF_REAL_64) (tr8_1 * tr8_2) + tr8_3), tr8_4);
	Result = (EIF_INTEGER_32) tr8_1;
	RTLE;
	return Result;
}

/* {RANDOM}.double_mod */
EIF_REAL_64 F732_6308 (EIF_REFERENCE Current, EIF_REAL_64 arg1, EIF_REAL_64 arg2)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	
	RTGC;
	Result = (EIF_REAL_64) floor((double) (EIF_REAL_64) ((EIF_REAL_64) (arg1) /  (EIF_REAL_64) (arg2)));
	Result = (EIF_REAL_64) (EIF_REAL_64) (arg1 - (EIF_REAL_64) (Result * arg2));
	return Result;
}

/* {RANDOM}.dmod */
static EIF_REAL_64 F732_6311_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6311);
#define Result RTOSR(6311)
	Result = (EIF_REAL_64) (RTOSCF(6295,F732_6295, (Current)));
	RTOSE (6311);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F732_6311 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6311,F732_6311_body,(Current));
}

/* {RANDOM}.dmul */
static EIF_REAL_64 F732_6312_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6312);
#define Result RTOSR(6312)
	Result = (EIF_REAL_64) (RTOSCF(6296,F732_6296, (Current)));
	RTOSE (6312);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F732_6312 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6312,F732_6312_body,(Current));
}

/* {RANDOM}.dinc */
static EIF_REAL_64 F732_6313_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6313);
#define Result RTOSR(6313)
	Result = (EIF_REAL_64) (RTOSCF(6297,F732_6297, (Current)));
	RTOSE (6313);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F732_6313 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6313,F732_6313_body,(Current));
}

void EIF_Minit327 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
