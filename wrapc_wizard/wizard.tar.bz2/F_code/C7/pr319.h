
#ifndef _C7_pr319_
#define _C7_pr319_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F380_5648(EIF_REFERENCE);
extern EIF_INTEGER_32 F380_5649(EIF_REFERENCE);
extern void EIF_Minit319(void);

#ifdef __cplusplus
}
#endif

#endif
