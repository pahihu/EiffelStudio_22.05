/*
 * Code for class KL_STDOUT_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl308.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STDOUT_FILE}.make */
void F369_5466 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {KL_STDOUT_FILE}.eol */

EIF_REFERENCE F369_5468 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (5468,RTMS_EX_H("\012",1,10));
}

/* {KL_STDOUT_FILE}.put_character */
void F369_5470 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(5473,F369_5473, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6867[Dtype(RTCW(tr1))-1001])(tr1, arg1);
	RTLE;
}

/* {KL_STDOUT_FILE}.put_string */
void F369_5471 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(5438,F365_5438, (Current));
	loc1 = F900_7008(RTCW(tr1), arg1);
	tr1 = RTOSCF(5473,F369_5473, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6865[Dtype(RTCW(tr1))-1001])(tr1, loc1);
	RTLE;
}

/* {KL_STDOUT_FILE}.console */
static EIF_REFERENCE F369_5473_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (5473);
#define Result RTOSR(5473)
	RTOC_NEW(Result);
	Result = RTOSCF(1458,F85_1458, (RTCV(RTOSCF(24,F1_24, (Current)))));
	RTOSE (5473);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F369_5473 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5473,F369_5473_body,(Current));
}

void EIF_Minit308 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
