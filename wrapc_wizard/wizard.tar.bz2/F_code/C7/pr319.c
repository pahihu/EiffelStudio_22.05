/*
 * Code for class PROCESS_INFO_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr319.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F380_5649
static EIF_INTEGER_32 inline_F380_5649 (void)
{
	return (EIF_INTEGER_32) (getpid())
	;
}
#define INLINE_F380_5649
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PROCESS_INFO_IMP}.process_id */
EIF_INTEGER_32 F380_5648 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) inline_F380_5649();
}

/* {PROCESS_INFO_IMP}.c_process_id */
EIF_INTEGER_32 F380_5649 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F380_5649 ();
	return Result;
}

void EIF_Minit319 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
