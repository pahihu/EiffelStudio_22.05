
#ifndef _C7_st332_
#define _C7_st332_

#ifdef __cplusplus
extern "C" {
#endif

extern void F814_6460(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F814_6461(EIF_REFERENCE);
extern EIF_REFERENCE F814_6462(EIF_REFERENCE);
extern EIF_REFERENCE F814_6464(EIF_REFERENCE);
extern EIF_INTEGER_32 F814_6465(EIF_REFERENCE);
extern void EIF_Minit332(void);
extern EIF_INTEGER_32 F1135_10133(EIF_REFERENCE);
extern char *(*R8468[])();

#ifdef __cplusplus
}
#endif

#endif
