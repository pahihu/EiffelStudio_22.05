
#ifndef _C7_ev335_
#define _C7_ev335_

#ifdef __cplusplus
extern "C" {
#endif

extern void F871_6754(EIF_REFERENCE);
extern void F871_6755(EIF_REFERENCE, EIF_REFERENCE);
extern void F871_6756(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit335(void);
extern EIF_REFERENCE __A335_166_2();
extern void F871_6755(EIF_REFERENCE, EIF_REFERENCE);
extern void F865_6724(EIF_REFERENCE, EIF_REFERENCE);
extern void F1296_12080(EIF_REFERENCE);
extern void F871_6756(EIF_REFERENCE, EIF_REFERENCE);
extern void F869_6748(EIF_REFERENCE);
extern EIF_REFERENCE _A335_167_2();
extern EIF_REFERENCE __A335_167_2();
extern void F1296_12081(EIF_REFERENCE);
extern EIF_REFERENCE _A335_166_2();
extern EIF_TYPE_INDEX Y5627[];
extern EIF_TYPE_INDEX *Y5627_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
