
#ifndef _C7_kl304_
#define _C7_kl304_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,5438)
static EIF_REFERENCE F365_5438_body(EIF_REFERENCE);
extern EIF_REFERENCE F365_5438(EIF_REFERENCE);
extern void EIF_Minit304(void);

#ifdef __cplusplus
}
#endif

#endif
