
#ifndef _C7_ev303_
#define _C7_ev303_

#ifdef __cplusplus
extern "C" {
#endif

extern void F364_5433(EIF_REFERENCE, EIF_REFERENCE);
extern void F364_5434(EIF_REFERENCE);
extern void F364_5435(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F364_5436(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit303(void);
extern void F1298_12120(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F1274_11665(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
