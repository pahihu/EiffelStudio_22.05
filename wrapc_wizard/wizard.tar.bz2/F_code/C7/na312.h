
#ifndef _C7_na312_
#define _C7_na312_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F373_5525(EIF_REFERENCE, EIF_POINTER);
extern EIF_NATURAL_64 F373_5526(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit312(void);

#ifdef __cplusplus
}
#endif

#endif
