/*
 * Code for class KL_IMPORTED_STRING_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl304.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_IMPORTED_STRING_ROUTINES}.string_ */
static EIF_REFERENCE F365_5438_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (5438);
#define Result RTOSR(5438)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(899, 0x01).id, 899, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (5438);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_5438 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5438,F365_5438_body,(Current));
}

void EIF_Minit304 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
