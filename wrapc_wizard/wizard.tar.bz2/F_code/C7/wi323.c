/*
 * Code for class WIZARD_DATA
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi323.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_DATA}.make */
void F402_5716 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,846,0xFF01,913,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F847_6622(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {WIZARD_DATA}.page_data */
EIF_REFERENCE F402_5717 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F841_6516(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {WIZARD_DATA}.item */
EIF_REFERENCE F402_5718 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,loc3);
	RTLR(3,loc5);
	RTLR(4,Current);
	RTLR(5,tr1);
	RTLR(6,loc6);
	RTLR(7,loc4);
	RTLR(8,Result);
	RTLIU(9);
	
	RTGC;
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32)) R8236[Dtype(RTCW(arg1))-1132])(arg1, tw1, ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		loc2 = F1129_9864(RTCW(arg1), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8271[Dtype(RTCW(arg1))-1132])(arg1);
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8312[Dtype(RTCW(arg1))-1132])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), ti4_1);
		tr1 = F402_5717(Current, loc2);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			tr1 = F914_7115(loc5, loc3);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc6 = F841_6525(RTCW(tr1));
		for (;;) {
			tb1 = F783_6425(loc6);
			if (tb1) break;
			if ((EIF_BOOLEAN)(Result != NULL)) break;
			loc4 = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_1_0_3_0_0_0_0_);
			tr1 = F783_6423(loc6);
			F1134_9989(RTCW(loc4), tr1);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
			F1134_10041(RTCW(loc4), tw1);
			F1134_10027(RTCW(loc4), arg1);
			Result = F402_5718(Current, loc4);
			F783_6426(loc6);
		}
	}
	RTLE;
	return Result;
}

/* {WIZARD_DATA}.new_cursor */
EIF_REFERENCE F402_5720 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F841_6525(RTCW(tr1));
	RTLE;
	return Result;
}

/* {WIZARD_DATA}.record_page_data */
void F402_5721 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F841_6557(RTCW(tr1), arg1, arg2);
	RTLE;
}

void EIF_Minit323 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
