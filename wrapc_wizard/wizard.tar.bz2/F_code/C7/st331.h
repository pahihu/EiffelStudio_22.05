
#ifndef _C7_st331_
#define _C7_st331_

#ifdef __cplusplus
extern "C" {
#endif

extern void F813_6454(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F813_6455(EIF_REFERENCE);
extern EIF_REFERENCE F813_6456(EIF_REFERENCE);
extern EIF_REFERENCE F813_6458(EIF_REFERENCE);
extern EIF_INTEGER_32 F813_6459(EIF_REFERENCE);
extern void EIF_Minit331(void);
extern EIF_INTEGER_32 F1132_9965(EIF_REFERENCE);
extern char *(*R8388[])();

#ifdef __cplusplus
}
#endif

#endif
