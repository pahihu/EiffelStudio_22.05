
#ifndef _C7_ki305_
#define _C7_ki305_

#ifdef __cplusplus
extern "C" {
#endif

extern void F366_5441(EIF_REFERENCE, EIF_INTEGER_32);
extern void F366_5445(EIF_REFERENCE, EIF_INTEGER_64);
extern void F366_5448(EIF_REFERENCE, EIF_NATURAL_32);
extern void F366_5449(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit305(void);
extern void F369_5470(EIF_REFERENCE, EIF_CHARACTER_8);

#ifdef __cplusplus
}
#endif

#endif
