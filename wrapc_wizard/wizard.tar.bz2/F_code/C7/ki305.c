/*
 * Code for class KI_CHARACTER_OUTPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ki305.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KI_CHARACTER_OUTPUT_STREAM}.put_integer */
void F366_5441 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_64 ti8_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti8_1 = (EIF_INTEGER_64) arg1;
	F366_5445(Current, ti8_1);
	RTLE;
}

/* {KI_CHARACTER_OUTPUT_STREAM}.put_integer_64 */
void F366_5445 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	EIF_INTEGER_64 loc1 = (EIF_INTEGER_64) 0;
	EIF_INTEGER_64 loc2 = (EIF_INTEGER_64) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
		F369_5470(Current, (EIF_CHARACTER_8) '0');
	} else {
		if ((EIF_BOOLEAN) (arg1 < (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
			F369_5470(Current, (EIF_CHARACTER_8) '-');
			loc1 = (EIF_INTEGER_64) (EIF_INTEGER_64) -(EIF_INTEGER_64) (arg1 + (EIF_INTEGER_64) ((EIF_INTEGER_32) 1L));
			loc2 = (EIF_INTEGER_64) (EIF_INTEGER_64) (loc1 / (EIF_INTEGER_64) ((EIF_INTEGER_32) 10L));
			switch ((EIF_INTEGER_64) (loc1 % (EIF_INTEGER_64) ((EIF_INTEGER_32) 10L))) {
				case RTI64C(0):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F366_5445(Current, loc2);
					}
					F369_5470(Current, (EIF_CHARACTER_8) '1');
					break;
				case RTI64C(1):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F366_5445(Current, loc2);
					}
					F369_5470(Current, (EIF_CHARACTER_8) '2');
					break;
				case RTI64C(2):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F366_5445(Current, loc2);
					}
					F369_5470(Current, (EIF_CHARACTER_8) '3');
					break;
				case RTI64C(3):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F366_5445(Current, loc2);
					}
					F369_5470(Current, (EIF_CHARACTER_8) '4');
					break;
				case RTI64C(4):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F366_5445(Current, loc2);
					}
					F369_5470(Current, (EIF_CHARACTER_8) '5');
					break;
				case RTI64C(5):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F366_5445(Current, loc2);
					}
					F369_5470(Current, (EIF_CHARACTER_8) '6');
					break;
				case RTI64C(6):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F366_5445(Current, loc2);
					}
					F369_5470(Current, (EIF_CHARACTER_8) '7');
					break;
				case RTI64C(7):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F366_5445(Current, loc2);
					}
					F369_5470(Current, (EIF_CHARACTER_8) '8');
					break;
				case RTI64C(8):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F366_5445(Current, loc2);
					}
					F369_5470(Current, (EIF_CHARACTER_8) '9');
					break;
				case RTI64C(9):
					F366_5445(Current, (EIF_INTEGER_64) (loc2 + (EIF_INTEGER_64) ((EIF_INTEGER_32) 1L)));
					F369_5470(Current, (EIF_CHARACTER_8) '0');
					break;
				default:
					RTEC(EN_WHEN);
			}
		} else {
			loc1 = (EIF_INTEGER_64) arg1;
			loc2 = (EIF_INTEGER_64) (EIF_INTEGER_64) (loc1 / (EIF_INTEGER_64) ((EIF_INTEGER_32) 10L));
			if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
				F366_5445(Current, loc2);
			}
			switch ((EIF_INTEGER_64) (loc1 % (EIF_INTEGER_64) ((EIF_INTEGER_32) 10L))) {
				case RTI64C(0):
					F369_5470(Current, (EIF_CHARACTER_8) '0');
					break;
				case RTI64C(1):
					F369_5470(Current, (EIF_CHARACTER_8) '1');
					break;
				case RTI64C(2):
					F369_5470(Current, (EIF_CHARACTER_8) '2');
					break;
				case RTI64C(3):
					F369_5470(Current, (EIF_CHARACTER_8) '3');
					break;
				case RTI64C(4):
					F369_5470(Current, (EIF_CHARACTER_8) '4');
					break;
				case RTI64C(5):
					F369_5470(Current, (EIF_CHARACTER_8) '5');
					break;
				case RTI64C(6):
					F369_5470(Current, (EIF_CHARACTER_8) '6');
					break;
				case RTI64C(7):
					F369_5470(Current, (EIF_CHARACTER_8) '7');
					break;
				case RTI64C(8):
					F369_5470(Current, (EIF_CHARACTER_8) '8');
					break;
				case RTI64C(9):
					F369_5470(Current, (EIF_CHARACTER_8) '9');
					break;
				default:
					RTEC(EN_WHEN);
			}
		}
	}
	RTLE;
}

/* {KI_CHARACTER_OUTPUT_STREAM}.put_natural_32 */
void F366_5448 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_NATURAL_64 tu8_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu8_1 = (EIF_NATURAL_64) arg1;
	F366_5449(Current, tu8_1);
	RTLE;
}

/* {KI_CHARACTER_OUTPUT_STREAM}.put_natural_64 */
void F366_5449 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	EIF_NATURAL_64 loc1 = (EIF_NATURAL_64) 0;
	EIF_NATURAL_64 loc2 = (EIF_NATURAL_64) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L))) {
		F369_5470(Current, (EIF_CHARACTER_8) '0');
	} else {
		loc1 = (EIF_NATURAL_64) arg1;
		loc2 = (EIF_NATURAL_64) (EIF_NATURAL_64) (loc1 / (EIF_NATURAL_64) ((EIF_INTEGER_32) 10L));
		if ((EIF_BOOLEAN)(loc2 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L))) {
			F366_5449(Current, loc2);
		}
		switch ((EIF_NATURAL_64) (loc1 % (EIF_NATURAL_64) ((EIF_INTEGER_32) 10L))) {
			case RTU64C(0):
				F369_5470(Current, (EIF_CHARACTER_8) '0');
				break;
			case RTU64C(1):
				F369_5470(Current, (EIF_CHARACTER_8) '1');
				break;
			case RTU64C(2):
				F369_5470(Current, (EIF_CHARACTER_8) '2');
				break;
			case RTU64C(3):
				F369_5470(Current, (EIF_CHARACTER_8) '3');
				break;
			case RTU64C(4):
				F369_5470(Current, (EIF_CHARACTER_8) '4');
				break;
			case RTU64C(5):
				F369_5470(Current, (EIF_CHARACTER_8) '5');
				break;
			case RTU64C(6):
				F369_5470(Current, (EIF_CHARACTER_8) '6');
				break;
			case RTU64C(7):
				F369_5470(Current, (EIF_CHARACTER_8) '7');
				break;
			case RTU64C(8):
				F369_5470(Current, (EIF_CHARACTER_8) '8');
				break;
			case RTU64C(9):
				F369_5470(Current, (EIF_CHARACTER_8) '9');
				break;
			default:
				RTEC(EN_WHEN);
		}
	}
	RTLE;
}

void EIF_Minit305 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
