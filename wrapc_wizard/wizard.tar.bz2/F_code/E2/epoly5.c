#include "epoly5.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R28[1569])();
void R28_init () {
	R28[0] = (char *(*)()) F1_25;
	{long i; for (i = 7; i < 9; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 13; i < 19; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 20; i < 46; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 47; i < 49; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 51; i < 56; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 57; i < 60; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 62; i < 64; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 66; i < 69; i++) R28[i] = (char *(*)()) F1_25;}
	R28[81] = (char *(*)()) F1_25;
	R28[103] = (char *(*)()) F1_25;
	R28[113] = (char *(*)()) F1_25;
	R28[115] = (char *(*)()) F1_25;
	{long i; for (i = 140; i < 145; i++) R28[i] = (char *(*)()) F1_25;}
	R28[150] = (char *(*)()) F1_25;
	R28[164] = (char *(*)()) F1_25;
	R28[168] = (char *(*)()) F1_25;
	R28[170] = (char *(*)()) F1_25;
	R28[172] = (char *(*)()) F1_25;
	{long i; for (i = 175; i < 177; i++) R28[i] = (char *(*)()) F1_25;}
	R28[179] = (char *(*)()) F1_25;
	R28[188] = (char *(*)()) F1_25;
	R28[190] = (char *(*)()) F1_25;
	R28[196] = (char *(*)()) F1_25;
	{long i; for (i = 200; i < 202; i++) R28[i] = (char *(*)()) F1_25;}
	R28[203] = (char *(*)()) F1_25;
	{long i; for (i = 205; i < 207; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 208; i < 210; i++) R28[i] = (char *(*)()) F1_25;}
	R28[212] = (char *(*)()) F1_25;
	{long i; for (i = 218; i < 222; i++) R28[i] = (char *(*)()) F1_25;}
	R28[223] = (char *(*)()) F1_25;
	{long i; for (i = 225; i < 234; i++) R28[i] = (char *(*)()) F1_25;}
	R28[236] = (char *(*)()) F1_25;
	R28[238] = (char *(*)()) F1_25;
	R28[242] = (char *(*)()) F1_25;
	R28[244] = (char *(*)()) F1_25;
	{long i; for (i = 245; i < 248; i++) R28[i] = (char *(*)()) F249_4355;}
	R28[250] = (char *(*)()) F249_4355;
	{long i; for (i = 252; i < 255; i++) R28[i] = (char *(*)()) F249_4355;}
	{long i; for (i = 256; i < 259; i++) R28[i] = (char *(*)()) F249_4355;}
	{long i; for (i = 260; i < 262; i++) R28[i] = (char *(*)()) F249_4355;}
	{long i; for (i = 264; i < 266; i++) R28[i] = (char *(*)()) F249_4355;}
	{long i; for (i = 267; i < 270; i++) R28[i] = (char *(*)()) F249_4355;}
	{long i; for (i = 271; i < 275; i++) R28[i] = (char *(*)()) F249_4355;}
	{long i; for (i = 276; i < 278; i++) R28[i] = (char *(*)()) F249_4355;}
	{long i; for (i = 279; i < 285; i++) R28[i] = (char *(*)()) F249_4355;}
	{long i; for (i = 288; i < 290; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 291; i < 297; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 299; i < 301; i++) R28[i] = (char *(*)()) F1_25;}
	R28[303] = (char *(*)()) F1_25;
	R28[305] = (char *(*)()) F1_25;
	R28[308] = (char *(*)()) F1_25;
	{long i; for (i = 310; i < 313; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 320; i < 323; i++) R28[i] = (char *(*)()) F1_25;}
	R28[326] = (char *(*)()) F1_25;
	{long i; for (i = 328; i < 330; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 332; i < 334; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 348; i < 351; i++) R28[i] = (char *(*)()) F1_25;}
	R28[352] = (char *(*)()) F1_25;
	{long i; for (i = 359; i < 361; i++) R28[i] = (char *(*)()) F1_25;}
	R28[365] = (char *(*)()) F1_25;
	R28[368] = (char *(*)()) F1_25;
	{long i; for (i = 370; i < 372; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 373; i < 375; i++) R28[i] = (char *(*)()) F1_25;}
	R28[377] = (char *(*)()) F1_25;
	R28[391] = (char *(*)()) F1_25;
	R28[398] = (char *(*)()) F1_25;
	R28[413] = (char *(*)()) F1_25;
	R28[639] = (char *(*)()) F1_25;
	{long i; for (i = 689; i < 708; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 727; i < 729; i++) R28[i] = (char *(*)()) F1_25;}
	R28[733] = (char *(*)()) F1_25;
	{long i; for (i = 764; i < 785; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 797; i < 835; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 837; i < 845; i++) R28[i] = (char *(*)()) F1_25;}
	R28[845] = (char *(*)()) F849_6636;
	{long i; for (i = 846; i < 861; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 865; i < 871; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 876; i < 878; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 881; i < 883; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 885; i < 890; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 895; i < 898; i++) R28[i] = (char *(*)()) F1_25;}
	R28[908] = (char *(*)()) F912_7095;
	{long i; for (i = 909; i < 911; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 913; i < 927; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 928; i < 935; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 936; i < 938; i++) R28[i] = (char *(*)()) F1_25;}
	R28[986] = (char *(*)()) F1_25;
	{long i; for (i = 988; i < 994; i++) R28[i] = (char *(*)()) F1_25;}
	R28[996] = (char *(*)()) F1_25;
	{long i; for (i = 998; i < 1000; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1001; i < 1003; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1004] = (char *(*)()) F1_25;
	R28[1007] = (char *(*)()) F1_25;
	R28[1010] = (char *(*)()) F1014_8450;
	R28[1011] = (char *(*)()) F1015_8497;
	R28[1012] = (char *(*)()) F1016_8538;
	R28[1013] = (char *(*)()) F1017_8538;
	R28[1014] = (char *(*)()) F1018_8538;
	R28[1015] = (char *(*)()) F1019_8538;
	R28[1016] = (char *(*)()) F1020_8538;
	R28[1017] = (char *(*)()) F1021_8538;
	R28[1018] = (char *(*)()) F1022_8538;
	R28[1019] = (char *(*)()) F1023_8538;
	R28[1020] = (char *(*)()) F1024_8538;
	R28[1021] = (char *(*)()) F1025_8538;
	R28[1022] = (char *(*)()) F1026_8538;
	R28[1023] = (char *(*)()) F1027_8538;
	R28[1024] = (char *(*)()) F1028_8538;
	R28[1025] = (char *(*)()) F1029_8538;
	R28[1026] = (char *(*)()) F1030_8538;
	R28[1027] = (char *(*)()) F1031_8538;
	R28[1028] = (char *(*)()) F1032_8538;
	R28[1029] = (char *(*)()) F1033_8538;
	R28[1030] = (char *(*)()) F1034_8538;
	R28[1031] = (char *(*)()) F1035_8538;
	R28[1032] = (char *(*)()) F1036_8538;
	R28[1033] = (char *(*)()) F1037_8538;
	R28[1034] = (char *(*)()) F1038_8538;
	R28[1035] = (char *(*)()) F1039_8538;
	R28[1036] = (char *(*)()) F1040_8538;
	R28[1037] = (char *(*)()) F1041_8538;
	R28[1038] = (char *(*)()) F1042_8538;
	R28[1039] = (char *(*)()) F1043_8538;
	R28[1040] = (char *(*)()) F1044_8538;
	R28[1041] = (char *(*)()) F1045_8538;
	R28[1042] = (char *(*)()) F1046_8538;
	R28[1043] = (char *(*)()) F1047_8538;
	R28[1044] = (char *(*)()) F1048_8538;
	R28[1045] = (char *(*)()) F1049_8538;
	R28[1046] = (char *(*)()) F1_25;
	R28[1048] = (char *(*)()) F1052_8747;
	R28[1049] = (char *(*)()) F1053_8747;
	{long i; for (i = 1051; i < 1053; i++) R28[i] = (char *(*)()) F1054_8763;}
	{long i; for (i = 1054; i < 1056; i++) R28[i] = (char *(*)()) F1057_8803;}
	{long i; for (i = 1057; i < 1059; i++) R28[i] = (char *(*)()) F1060_8851;}
	{long i; for (i = 1060; i < 1062; i++) R28[i] = (char *(*)()) F1063_8927;}
	{long i; for (i = 1063; i < 1065; i++) R28[i] = (char *(*)()) F1066_9026;}
	{long i; for (i = 1066; i < 1068; i++) R28[i] = (char *(*)()) F1069_9125;}
	{long i; for (i = 1069; i < 1071; i++) R28[i] = (char *(*)()) F1072_9224;}
	{long i; for (i = 1072; i < 1074; i++) R28[i] = (char *(*)()) F1075_9320;}
	{long i; for (i = 1075; i < 1077; i++) R28[i] = (char *(*)()) F1078_9414;}
	{long i; for (i = 1078; i < 1080; i++) R28[i] = (char *(*)()) F1081_9509;}
	{long i; for (i = 1081; i < 1083; i++) R28[i] = (char *(*)()) F1084_9604;}
	R28[1084] = (char *(*)()) F1088_9697;
	R28[1085] = (char *(*)()) F1089_9697;
	{long i; for (i = 1086; i < 1117; i++) R28[i] = (char *(*)()) F1090_9716;}
	R28[1117] = (char *(*)()) F1121_9729;
	R28[1118] = (char *(*)()) F1122_9729;
	{long i; for (i = 1120; i < 1125; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1129; i < 1131; i++) R28[i] = (char *(*)()) F1132_9957;}
	{long i; for (i = 1132; i < 1134; i++) R28[i] = (char *(*)()) F1135_10125;}
	{long i; for (i = 1167; i < 1169; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1170] = (char *(*)()) F1_25;
	R28[1171] = (char *(*)()) F1175_10510;
	{long i; for (i = 1172; i < 1175; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1176] = (char *(*)()) F1180_10603;
	R28[1181] = (char *(*)()) F1_25;
	R28[1198] = (char *(*)()) F1_25;
	R28[1200] = (char *(*)()) F1_25;
	{long i; for (i = 1202; i < 1204; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1214; i < 1219; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1220; i < 1222; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1225; i < 1228; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1229] = (char *(*)()) F1_25;
	{long i; for (i = 1232; i < 1236; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1237; i < 1239; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1240] = (char *(*)()) F1_25;
	R28[1243] = (char *(*)()) F1_25;
	R28[1246] = (char *(*)()) F1_25;
	R28[1248] = (char *(*)()) F1_25;
	R28[1251] = (char *(*)()) F1_25;
	R28[1257] = (char *(*)()) F1_25;
	R28[1264] = (char *(*)()) F1_25;
	{long i; for (i = 1267; i < 1269; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1276] = (char *(*)()) F1_25;
	R28[1281] = (char *(*)()) F1_25;
	R28[1283] = (char *(*)()) F1_25;
	R28[1286] = (char *(*)()) F1_25;
	R28[1288] = (char *(*)()) F1_25;
	R28[1290] = (char *(*)()) F1_25;
	R28[1293] = (char *(*)()) F1_25;
	R28[1295] = (char *(*)()) F1_25;
	R28[1299] = (char *(*)()) F1_25;
	R28[1339] = (char *(*)()) F1_25;
	{long i; for (i = 1344; i < 1346; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1362; i < 1364; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1368; i < 1370; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1371] = (char *(*)()) F1_25;
	R28[1376] = (char *(*)()) F1_25;
	{long i; for (i = 1378; i < 1380; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1402; i < 1404; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1405; i < 1407; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1410; i < 1413; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1415] = (char *(*)()) F1_25;
	R28[1419] = (char *(*)()) F1_25;
	R28[1425] = (char *(*)()) F1_25;
	R28[1431] = (char *(*)()) F1_25;
	R28[1435] = (char *(*)()) F1_25;
	R28[1448] = (char *(*)()) F1_25;
	{long i; for (i = 1450; i < 1452; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1455; i < 1461; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1463] = (char *(*)()) F1_25;
	R28[1464] = (char *(*)()) F1468_14927;
	R28[1465] = (char *(*)()) F1_25;
	{long i; for (i = 1474; i < 1476; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1478] = (char *(*)()) F1_25;
	R28[1502] = (char *(*)()) F1_25;
	{long i; for (i = 1507; i < 1509; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1542] = (char *(*)()) F1_25;
	{long i; for (i = 1549; i < 1551; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1553; i < 1555; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1559] = (char *(*)()) F1_25;
	R28[1562] = (char *(*)()) F1_25;
	{long i; for (i = 1564; i < 1566; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1568] = (char *(*)()) F1_25;
}

char *(*R202[6])();
void R202_init () {
	R202[0] = (char *(*)()) F24_195;
	R202[1] = (char *(*)()) F25_195;
	R202[2] = (char *(*)()) F26_195;
	R202[3] = (char *(*)()) F27_195;
	R202[4] = (char *(*)()) F28_195;
	R202[5] = (char *(*)()) F29_195;
}

char *(*R207[6])();
void R207_init () {
	R207[0] = (char *(*)()) F24_200;
	R207[1] = (char *(*)()) F25_200_207_38;
	R207[2] = (char *(*)()) F26_200_207_38;
	R207[3] = (char *(*)()) F27_200_207_38;
	R207[4] = (char *(*)()) F28_200_207_38;
	R207[5] = (char *(*)()) F29_200_207_38;
}
static void F25_200_207_38 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F25_200(Current, arg1, *(EIF_NATURAL_32 *)arg2, arg3);
}
static void F26_200_207_38 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F26_200(Current, arg1, *(EIF_NATURAL_64 *)arg2, arg3);
}
static void F27_200_207_38 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F27_200(Current, arg1, *(EIF_INTEGER_32 *)arg2, arg3);
}
static void F28_200_207_38 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F28_200(Current, arg1, *(EIF_BOOLEAN *)arg2, arg3);
}
static void F29_200_207_38 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F29_200(Current, arg1, *(EIF_CHARACTER_8 *)arg2, arg3);
}

char *(*R210[6])();
void R210_init () {
	R210[0] = (char *(*)()) F24_203;
	R210[1] = (char *(*)()) F25_203;
	R210[2] = (char *(*)()) F26_203;
	R210[3] = (char *(*)()) F27_203;
	R210[4] = (char *(*)()) F28_203;
	R210[5] = (char *(*)()) F29_203;
}

static EIF_TYPE_INDEX Y1546_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1546_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1546_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1546_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1546_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1546_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1546_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1546_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1546_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1546_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1546_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1546_pgtype11[] = {0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y1546_gen_type [1469];
EIF_TYPE_INDEX Y1546 [1469];
void Y1546_init (void)
{
	egc_routines_types [1546] = Y1546;
	egc_routines_gen_types [1546] = Y1546_gen_type;
	egc_routines_offset [1546] = 85;
	Y1546_gen_type [0] = Y1546_pgtype0;
	Y1546_gen_type [1] = Y1546_pgtype1;
	Y1546_gen_type [1432] = Y1546_pgtype2;
	Y1546_gen_type [1433] = Y1546_pgtype3;
	Y1546_gen_type [1455] = Y1546_pgtype4;
	Y1546_gen_type [1456] = Y1546_pgtype5;
	Y1546_gen_type [1463] = Y1546_pgtype6;
	Y1546_gen_type [1464] = Y1546_pgtype7;
	Y1546_gen_type [1465] = Y1546_pgtype8;
	Y1546_gen_type [1466] = Y1546_pgtype9;
	Y1546_gen_type [1467] = Y1546_pgtype10;
	Y1546_gen_type [1468] = Y1546_pgtype11;
}

char *(*R3923[2])();
void R3923_init () {
	R3923[0] = (char *(*)()) F204_3938;
	R3923[1] = (char *(*)()) F205_3948;
}

char *(*R4000[2])();
void R4000_init () {
	R4000[0] = (char *(*)()) F212_4022;
	R4000[1] = (char *(*)()) F213_4023;
}

char *(*R4079[2])();
void R4079_init () {
	R4079[0] = (char *(*)()) F222_4110;
	R4079[1] = (char *(*)()) F223_4114;
}

char *(*R4081[2])();
void R4081_init () {
	R4081[0] = (char *(*)()) F222_4111;
	R4081[1] = (char *(*)()) F223_4115;
}

char *(*R4186[188])();
void R4186_init () {
	R4186[0] = (char *(*)()) F230_4239;
	R4186[1] = (char *(*)()) F231_4239_4186_1;
	R4186[2] = (char *(*)()) F232_4239_4186_1;
	R4186[3] = (char *(*)()) F233_4239_4186_1;
	R4186[4] = (char *(*)()) F234_4239_4186_1;
	R4186[5] = (char *(*)()) F230_4239;
	R4186[6] = (char *(*)()) F231_4239_4186_1;
	R4186[7] = (char *(*)()) F232_4239_4186_1;
	R4186[187] = (char *(*)()) F230_4239;
}
static EIF_REFERENCE F231_4239_4186_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F231_4239(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F232_4239_4186_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F232_4239(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F233_4239_4186_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F233_4239(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1076, 0x00).id, 1076, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F234_4239_4186_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F234_4239(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R4187[188])();
void R4187_init () {
	R4187[0] = (char *(*)()) F230_4240;
	R4187[1] = (char *(*)()) F231_4240_4187_4;
	R4187[2] = (char *(*)()) F232_4240_4187_4;
	R4187[3] = (char *(*)()) F233_4240_4187_4;
	R4187[4] = (char *(*)()) F234_4240_4187_4;
	R4187[5] = (char *(*)()) F230_4240;
	R4187[6] = (char *(*)()) F231_4240_4187_4;
	R4187[7] = (char *(*)()) F232_4240_4187_4;
	R4187[187] = (char *(*)()) F230_4240;
}
static void F231_4240_4187_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F231_4240(Current, *(EIF_BOOLEAN *)arg1);
}
static void F232_4240_4187_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F232_4240(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F233_4240_4187_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F233_4240(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F234_4240_4187_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F234_4240(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R4191[3])();
void R4191_init () {
	R4191[0] = (char *(*)()) F235_4243;
	R4191[1] = (char *(*)()) F236_4243;
	R4191[2] = (char *(*)()) F237_4243;
}

char *(*R4192[3])();
void R4192_init () {
	R4192[0] = (char *(*)()) F235_4244;
	R4192[1] = (char *(*)()) F236_4244;
	R4192[2] = (char *(*)()) F237_4244;
}

char *(*R4193[898])();
void R4193_init () {
	R4193[0] = (char *(*)()) F240_4260;
	R4193[774] = (char *(*)()) F1014_8448;
	R4193[775] = (char *(*)()) F1015_8492;
	R4193[812] = (char *(*)()) F1052_8724_4193_2;
	R4193[813] = (char *(*)()) F1053_8724_4193_2;
	{long i; for (i = 815; i < 817; i++) R4193[i] = (char *(*)()) F1054_8755;}
	{long i; for (i = 818; i < 820; i++) R4193[i] = (char *(*)()) F1057_8795;}
	R4193[824] = (char *(*)()) F1064_8929_4193_2;
	R4193[825] = (char *(*)()) F1065_8929_4193_2;
	R4193[827] = (char *(*)()) F1067_9028_4193_2;
	R4193[828] = (char *(*)()) F1068_9028_4193_2;
	R4193[830] = (char *(*)()) F1070_9127_4193_2;
	R4193[831] = (char *(*)()) F1071_9127_4193_2;
	R4193[833] = (char *(*)()) F1073_9226_4193_2;
	R4193[834] = (char *(*)()) F1074_9226_4193_2;
	R4193[836] = (char *(*)()) F1076_9321_4193_2;
	R4193[837] = (char *(*)()) F1077_9321_4193_2;
	R4193[839] = (char *(*)()) F1079_9415_4193_2;
	R4193[840] = (char *(*)()) F1080_9415_4193_2;
	R4193[842] = (char *(*)()) F1082_9510_4193_2;
	R4193[843] = (char *(*)()) F1083_9510_4193_2;
	R4193[845] = (char *(*)()) F1085_9605_4193_2;
	R4193[846] = (char *(*)()) F1086_9605_4193_2;
	R4193[848] = (char *(*)()) F1088_9674_4193_2;
	R4193[849] = (char *(*)()) F1089_9674_4193_2;
	{long i; for (i = 893; i < 895; i++) R4193[i] = (char *(*)()) F1132_9942;}
	{long i; for (i = 896; i < 898; i++) R4193[i] = (char *(*)()) F1135_10110;}
}
static EIF_BOOLEAN F1052_8724_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1052_8724(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1053_8724_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1053_8724(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1064_8929_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1064_8929(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1065_8929_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1065_8929(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1067_9028_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1067_9028(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1068_9028_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1068_9028(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1070_9127_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1070_9127(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1071_9127_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1071_9127(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1073_9226_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1073_9226(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1074_9226_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1074_9226(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1076_9321_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1076_9321(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1077_9321_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1077_9321(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1079_9415_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1079_9415(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1080_9415_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1080_9415(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1082_9510_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1082_9510(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1083_9510_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1083_9510(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1085_9605_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1085_9605(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1086_9605_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1086_9605(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1088_9674_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1088_9674(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1089_9674_4193_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1089_9674(Current, *(EIF_REAL_32 *)arg1);
}

char *(*R4284[40])();
void R4284_init () {
	R4284[0] = (char *(*)()) F249_4342;
	{long i; for (i = 1; i < 3; i++) R4284[i] = (char *(*)()) F250_4366;}
	R4284[5] = (char *(*)()) F254_4369;
	R4284[7] = (char *(*)()) F256_4371;
	R4284[8] = (char *(*)()) F257_4375;
	R4284[9] = (char *(*)()) F258_4381;
	R4284[11] = (char *(*)()) F260_4398;
	R4284[12] = (char *(*)()) F261_4400;
	R4284[13] = (char *(*)()) F262_4402;
	R4284[15] = (char *(*)()) F264_4404;
	R4284[16] = (char *(*)()) F265_4408;
	R4284[19] = (char *(*)()) F268_4410;
	R4284[20] = (char *(*)()) F269_4412;
	R4284[22] = (char *(*)()) F271_4416;
	R4284[23] = (char *(*)()) F272_4422;
	R4284[24] = (char *(*)()) F273_4424;
	R4284[26] = (char *(*)()) F275_4426;
	R4284[27] = (char *(*)()) F276_4428;
	R4284[28] = (char *(*)()) F277_4432;
	R4284[29] = (char *(*)()) F278_4436;
	R4284[31] = (char *(*)()) F280_4438;
	R4284[32] = (char *(*)()) F281_4440;
	R4284[34] = (char *(*)()) F283_4442;
	R4284[35] = (char *(*)()) F284_4444;
	R4284[36] = (char *(*)()) F285_4446;
	R4284[37] = (char *(*)()) F286_4448;
	R4284[38] = (char *(*)()) F287_4452;
	R4284[39] = (char *(*)()) F288_4454;
}

char *(*R4349[10])();
void R4349_init () {
	R4349[0] = (char *(*)()) F1406_13885;
	{long i; for (i = 8; i < 10; i++) R4349[i] = (char *(*)()) F1414_14141;}
}

char *(*R4351[10])();
void R4351_init () {
	R4351[0] = (char *(*)()) F290_4464;
	{long i; for (i = 8; i < 10; i++) R4351[i] = (char *(*)()) F1414_14147;}
}

char *(*R4630[3])();
void R4630_init () {
	R4630[0] = (char *(*)()) F296_4742;
	R4630[1] = (char *(*)()) F297_4742;
	R4630[2] = (char *(*)()) F298_4742;
}

char *(*R4645[690])();
void R4645_init () {
	R4645[0] = (char *(*)()) F303_4759;
	R4645[1] = (char *(*)()) F304_4760;
	R4645[689] = (char *(*)()) F992_7471;
}

char *(*R4912[8])();
void R4912_init () {
	R4912[0] = (char *(*)()) F330_5104;
	R4912[2] = (char *(*)()) F332_5120;
	R4912[3] = (char *(*)()) F333_5129;
	R4912[6] = (char *(*)()) F336_5135;
	R4912[7] = (char *(*)()) F322_5059;
}

char *(*R4918[8])();
void R4918_init () {
	R4918[0] = (char *(*)()) F330_5108;
	{long i; for (i = 2; i < 4; i++) R4918[i] = (char *(*)()) F332_5124;}
	R4918[6] = (char *(*)()) F336_5136;
	R4918[7] = (char *(*)()) F337_5141;
}

char *(*R4919[8])();
void R4919_init () {
	R4919[0] = (char *(*)()) F330_5110;
	{long i; for (i = 2; i < 4; i++) R4919[i] = (char *(*)()) F332_5126;}
	R4919[6] = (char *(*)()) F336_5139;
	R4919[7] = (char *(*)()) F337_5144;
}

char *(*R4935[8])();
void R4935_init () {
	R4935[0] = (char *(*)()) F330_5109;
	R4935[7] = (char *(*)()) F337_5142;
}

char *(*R4938[8])();
void R4938_init () {
	R4938[0] = (char *(*)()) F330_5111;
	R4938[7] = (char *(*)()) F337_5145;
}

char *(*R4939[10])();
void R4939_init () {
	R4939[0] = (char *(*)()) F324_5071;
	R4939[1] = (char *(*)()) F325_5085;
	R4939[2] = (char *(*)()) F326_5089;
	R4939[6] = (char *(*)()) F330_5105;
	{long i; for (i = 8; i < 10; i++) R4939[i] = (char *(*)()) F332_5121;}
}

char *(*R4988[763])();
void R4988_init () {
	R4988[0] = (char *(*)()) F345_5156;
	R4988[325] = (char *(*)()) F340_5156;
	R4988[326] = (char *(*)()) F341_5156;
	R4988[327] = (char *(*)()) F342_5156;
	R4988[328] = (char *(*)()) F343_5156;
	R4988[329] = (char *(*)()) F344_5156;
	R4988[330] = (char *(*)()) F345_5156;
	R4988[331] = (char *(*)()) F346_5156;
	R4988[332] = (char *(*)()) F347_5156;
	R4988[333] = (char *(*)()) F348_5156;
	R4988[334] = (char *(*)()) F349_5156;
	R4988[335] = (char *(*)()) F350_5156;
	R4988[336] = (char *(*)()) F351_5156;
	R4988[475] = (char *(*)()) F340_5156;
	R4988[476] = (char *(*)()) F341_5156;
	R4988[477] = (char *(*)()) F342_5156;
	R4988[478] = (char *(*)()) F343_5156;
	R4988[479] = (char *(*)()) F344_5156;
	R4988[480] = (char *(*)()) F345_5156;
	R4988[481] = (char *(*)()) F346_5156;
	R4988[482] = (char *(*)()) F347_5156;
	R4988[483] = (char *(*)()) F348_5156;
	R4988[484] = (char *(*)()) F349_5156;
	R4988[485] = (char *(*)()) F350_5156;
	R4988[486] = (char *(*)()) F351_5156;
	R4988[487] = (char *(*)()) F340_5156;
	R4988[488] = (char *(*)()) F344_5156;
	R4988[489] = (char *(*)()) F342_5156;
	R4988[494] = (char *(*)()) F340_5156;
	R4988[495] = (char *(*)()) F342_5156;
	{long i; for (i = 496; i < 500; i++) R4988[i] = (char *(*)()) F340_5156;}
	{long i; for (i = 505; i < 507; i++) R4988[i] = (char *(*)()) F340_5156;}
	{long i; for (i = 510; i < 512; i++) R4988[i] = (char *(*)()) F340_5156;}
	{long i; for (i = 514; i < 519; i++) R4988[i] = (char *(*)()) F340_5156;}
	R4988[759] = (char *(*)()) F348_5156;
	R4988[762] = (char *(*)()) F347_5156;
}

char *(*R4989[763])();
void R4989_init () {
	R4989[0] = (char *(*)()) F345_5157_4989_177;
	R4989[325] = (char *(*)()) F340_5157;
	R4989[326] = (char *(*)()) F341_5157_4989_177;
	R4989[327] = (char *(*)()) F342_5157_4989_177;
	R4989[328] = (char *(*)()) F343_5157_4989_177;
	R4989[329] = (char *(*)()) F344_5157_4989_177;
	R4989[330] = (char *(*)()) F345_5157_4989_177;
	R4989[331] = (char *(*)()) F346_5157_4989_177;
	R4989[332] = (char *(*)()) F347_5157_4989_177;
	R4989[333] = (char *(*)()) F348_5157_4989_177;
	R4989[334] = (char *(*)()) F349_5157_4989_177;
	R4989[335] = (char *(*)()) F350_5157_4989_177;
	R4989[336] = (char *(*)()) F351_5157_4989_177;
	R4989[475] = (char *(*)()) F340_5157;
	R4989[476] = (char *(*)()) F341_5157_4989_177;
	R4989[477] = (char *(*)()) F342_5157_4989_177;
	R4989[478] = (char *(*)()) F343_5157_4989_177;
	R4989[479] = (char *(*)()) F344_5157_4989_177;
	R4989[480] = (char *(*)()) F345_5157_4989_177;
	R4989[481] = (char *(*)()) F346_5157_4989_177;
	R4989[482] = (char *(*)()) F347_5157_4989_177;
	R4989[483] = (char *(*)()) F348_5157_4989_177;
	R4989[484] = (char *(*)()) F349_5157_4989_177;
	R4989[485] = (char *(*)()) F350_5157_4989_177;
	R4989[486] = (char *(*)()) F351_5157_4989_177;
	R4989[487] = (char *(*)()) F340_5157;
	R4989[488] = (char *(*)()) F344_5157_4989_177;
	R4989[489] = (char *(*)()) F342_5157_4989_177;
	R4989[494] = (char *(*)()) F340_5157;
	R4989[495] = (char *(*)()) F342_5157_4989_177;
	{long i; for (i = 496; i < 500; i++) R4989[i] = (char *(*)()) F340_5157;}
	{long i; for (i = 505; i < 507; i++) R4989[i] = (char *(*)()) F340_5157;}
	{long i; for (i = 510; i < 512; i++) R4989[i] = (char *(*)()) F340_5157;}
	{long i; for (i = 514; i < 519; i++) R4989[i] = (char *(*)()) F340_5157;}
	R4989[759] = (char *(*)()) F348_5157_4989_177;
	R4989[762] = (char *(*)()) F347_5157_4989_177;
}
static void F345_5157_4989_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F345_5157(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F341_5157_4989_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F341_5157(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F342_5157_4989_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F342_5157(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F343_5157_4989_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F343_5157(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F344_5157_4989_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F344_5157(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F346_5157_4989_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F346_5157(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F347_5157_4989_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F347_5157(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F348_5157_4989_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F348_5157(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F349_5157_4989_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F349_5157(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F350_5157_4989_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F350_5157(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F351_5157_4989_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F351_5157(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4995[763])();
void R4995_init () {
	R4995[0] = (char *(*)()) F345_5163;
	R4995[325] = (char *(*)()) F340_5163;
	R4995[326] = (char *(*)()) F341_5163;
	R4995[327] = (char *(*)()) F342_5163;
	R4995[328] = (char *(*)()) F343_5163;
	R4995[329] = (char *(*)()) F344_5163;
	R4995[330] = (char *(*)()) F345_5163;
	R4995[331] = (char *(*)()) F346_5163;
	R4995[332] = (char *(*)()) F347_5163;
	R4995[333] = (char *(*)()) F348_5163;
	R4995[334] = (char *(*)()) F349_5163;
	R4995[335] = (char *(*)()) F350_5163;
	R4995[336] = (char *(*)()) F351_5163;
	R4995[475] = (char *(*)()) F340_5163;
	R4995[476] = (char *(*)()) F341_5163;
	R4995[477] = (char *(*)()) F342_5163;
	R4995[478] = (char *(*)()) F343_5163;
	R4995[479] = (char *(*)()) F344_5163;
	R4995[480] = (char *(*)()) F345_5163;
	R4995[481] = (char *(*)()) F346_5163;
	R4995[482] = (char *(*)()) F347_5163;
	R4995[483] = (char *(*)()) F348_5163;
	R4995[484] = (char *(*)()) F349_5163;
	R4995[485] = (char *(*)()) F350_5163;
	R4995[486] = (char *(*)()) F351_5163;
	R4995[487] = (char *(*)()) F340_5163;
	R4995[488] = (char *(*)()) F344_5163;
	R4995[489] = (char *(*)()) F342_5163;
	R4995[494] = (char *(*)()) F340_5163;
	R4995[495] = (char *(*)()) F342_5163;
	{long i; for (i = 496; i < 500; i++) R4995[i] = (char *(*)()) F340_5163;}
	{long i; for (i = 505; i < 507; i++) R4995[i] = (char *(*)()) F340_5163;}
	{long i; for (i = 510; i < 512; i++) R4995[i] = (char *(*)()) F340_5163;}
	{long i; for (i = 514; i < 519; i++) R4995[i] = (char *(*)()) F340_5163;}
	R4995[759] = (char *(*)()) F348_5163;
	R4995[762] = (char *(*)()) F347_5163;
}

static EIF_TYPE_INDEX Y4996_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype12[] = {1085,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype13[] = {1085,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype32[] = {1085,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype54[] = {0xFF01,1179,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype55[] = {0xFF01,1123,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype56[] = {0xFF01,1123,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype57[] = {0xFF01,1123,0xFFF9,1,1049,0xFF01,0,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype58[] = {0xFF01,1123,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype59[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,1067,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype60[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1248,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype61[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,1067,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype62[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype63[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1254,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype64[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1186,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype65[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,1009,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype66[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1249,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype67[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,1067,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype68[] = {0xFF01,1123,0xFF01,0xFFF9,4,1049,1067,1067,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype69[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1467,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype70[] = {0xFF01,1123,0xFF01,0xFFF9,5,1049,1079,1067,1067,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype71[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1133,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype72[] = {0xFF01,1123,0xFF01,0xFFF9,2,1049,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype73[] = {0xFF01,1123,0xFF01,0xFFF9,7,1049,1067,1067,1052,1052,1052,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype74[] = {0xFF01,1123,0xFF01,0xFFF9,3,1049,1067,1067,1009,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype75[] = {0xFF01,1123,0xFF01,0xFFF9,8,1049,1067,1067,1067,1052,1052,1052,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype76[] = {0xFF01,1123,0xFF01,0xFFF9,0,1049,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype77[] = {1055,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype78[] = {1058,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype79[] = {1058,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype80[] = {1058,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype81[] = {0xFF01,1133,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype82[] = {1058,0xFFFF};
static EIF_TYPE_INDEX Y4996_pgtype83[] = {1058,0xFFFF};
EIF_TYPE_INDEX *Y4996_gen_type [1235];
EIF_TYPE_INDEX Y4996 [1235];
void Y4996_init (void)
{
	egc_routines_types [4996] = Y4996;
	egc_routines_gen_types [4996] = Y4996_gen_type;
	egc_routines_offset [4996] = 339;
	Y4996_gen_type [0] = Y4996_pgtype0;
	Y4996_gen_type [1] = Y4996_pgtype1;
	Y4996_gen_type [2] = Y4996_pgtype2;
	Y4996_gen_type [3] = Y4996_pgtype3;
	Y4996_gen_type [4] = Y4996_pgtype4;
	Y4996_gen_type [5] = Y4996_pgtype5;
	Y4996_gen_type [6] = Y4996_pgtype6;
	Y4996_gen_type [7] = Y4996_pgtype7;
	Y4996_gen_type [8] = Y4996_pgtype8;
	Y4996_gen_type [9] = Y4996_pgtype9;
	Y4996_gen_type [10] = Y4996_pgtype10;
	Y4996_gen_type [11] = Y4996_pgtype11;
	Y4996_gen_type [35] = Y4996_pgtype12;
	Y4996_gen_type [36] = Y4996_pgtype13;
	Y4996_gen_type [360] = Y4996_pgtype14;
	Y4996_gen_type [361] = Y4996_pgtype15;
	Y4996_gen_type [362] = Y4996_pgtype16;
	Y4996_gen_type [363] = Y4996_pgtype17;
	Y4996_gen_type [364] = Y4996_pgtype18;
	Y4996_gen_type [365] = Y4996_pgtype19;
	Y4996_gen_type [366] = Y4996_pgtype20;
	Y4996_gen_type [367] = Y4996_pgtype21;
	Y4996_gen_type [368] = Y4996_pgtype22;
	Y4996_gen_type [369] = Y4996_pgtype23;
	Y4996_gen_type [370] = Y4996_pgtype24;
	Y4996_gen_type [371] = Y4996_pgtype25;
	Y4996_gen_type [372] = Y4996_pgtype26;
	Y4996_gen_type [373] = Y4996_pgtype27;
	Y4996_gen_type [374] = Y4996_pgtype28;
	Y4996_gen_type [375] = Y4996_pgtype29;
	Y4996_gen_type [376] = Y4996_pgtype30;
	Y4996_gen_type [377] = Y4996_pgtype31;
	Y4996_gen_type [378] = Y4996_pgtype32;
	Y4996_gen_type [510] = Y4996_pgtype33;
	Y4996_gen_type [511] = Y4996_pgtype34;
	Y4996_gen_type [512] = Y4996_pgtype35;
	Y4996_gen_type [513] = Y4996_pgtype36;
	Y4996_gen_type [514] = Y4996_pgtype37;
	Y4996_gen_type [515] = Y4996_pgtype38;
	Y4996_gen_type [516] = Y4996_pgtype39;
	Y4996_gen_type [517] = Y4996_pgtype40;
	Y4996_gen_type [518] = Y4996_pgtype41;
	Y4996_gen_type [519] = Y4996_pgtype42;
	Y4996_gen_type [520] = Y4996_pgtype43;
	Y4996_gen_type [521] = Y4996_pgtype44;
	Y4996_gen_type [522] = Y4996_pgtype45;
	Y4996_gen_type [523] = Y4996_pgtype46;
	Y4996_gen_type [524] = Y4996_pgtype47;
	Y4996_gen_type [525] = Y4996_pgtype48;
	Y4996_gen_type [526] = Y4996_pgtype49;
	Y4996_gen_type [527] = Y4996_pgtype50;
	Y4996_gen_type [528] = Y4996_pgtype51;
	Y4996_gen_type [529] = Y4996_pgtype52;
	Y4996_gen_type [530] = Y4996_pgtype53;
	Y4996_gen_type [531] = Y4996_pgtype54;
	Y4996_gen_type [532] = Y4996_pgtype55;
	Y4996_gen_type [533] = Y4996_pgtype56;
	Y4996_gen_type [534] = Y4996_pgtype57;
	Y4996_gen_type [535] = Y4996_pgtype58;
	Y4996_gen_type [536] = Y4996_pgtype59;
	Y4996_gen_type [537] = Y4996_pgtype60;
	Y4996_gen_type [538] = Y4996_pgtype61;
	Y4996_gen_type [539] = Y4996_pgtype62;
	Y4996_gen_type [540] = Y4996_pgtype63;
	Y4996_gen_type [541] = Y4996_pgtype64;
	Y4996_gen_type [542] = Y4996_pgtype65;
	Y4996_gen_type [543] = Y4996_pgtype66;
	Y4996_gen_type [544] = Y4996_pgtype67;
	Y4996_gen_type [545] = Y4996_pgtype68;
	Y4996_gen_type [546] = Y4996_pgtype69;
	Y4996_gen_type [547] = Y4996_pgtype70;
	Y4996_gen_type [548] = Y4996_pgtype71;
	Y4996_gen_type [549] = Y4996_pgtype72;
	Y4996_gen_type [550] = Y4996_pgtype73;
	Y4996_gen_type [551] = Y4996_pgtype74;
	Y4996_gen_type [552] = Y4996_pgtype75;
	Y4996_gen_type [553] = Y4996_pgtype76;
	Y4996_gen_type [794] = Y4996_pgtype77;
	Y4996_gen_type [797] = Y4996_pgtype78;
	Y4996_gen_type [798] = Y4996_pgtype79;
	Y4996_gen_type [799] = Y4996_pgtype80;
	Y4996_gen_type [909] = Y4996_pgtype81;
	Y4996_gen_type [1233] = Y4996_pgtype82;
	Y4996_gen_type [1234] = Y4996_pgtype83;
	{long i; for (i = 35; i < 37; i++) Y4996[i] = 1085;};
	Y4996[378] = 1085;
	Y4996[531] = 1179;
	{long i; for (i = 532; i < 554; i++) Y4996[i] = 1123;};
	Y4996[794] = 1055;
	{long i; for (i = 797; i < 800; i++) Y4996[i] = 1058;};
	Y4996[909] = 1133;
	{long i; for (i = 1233; i < 1235; i++) Y4996[i] = 1058;};
}

char *(*R5172[254])();
void R5172_init () {
	R5172[0] = (char *(*)()) F1229_11249;
	R5172[253] = (char *(*)()) F1482_15146;
}

char *(*R5184[254])();
void R5184_init () {
	R5184[0] = (char *(*)()) F361_5389;
	R5184[253] = (char *(*)()) F1481_15133;
}

char *(*R5185[254])();
void R5185_init () {
	R5185[0] = (char *(*)()) F361_5391;
	R5185[253] = (char *(*)()) F1481_15134;
}

char *(*R5187[254])();
void R5187_init () {
	R5187[0] = (char *(*)()) F360_5377;
	R5187[253] = (char *(*)()) F1481_15138;
}

char *(*R5191[254])();
void R5191_init () {
	R5191[0] = (char *(*)()) F361_5396;
	R5191[253] = (char *(*)()) F360_5381;
}

char *(*R5429[1160])();
void R5429_init () {
	R5429[0] = (char *(*)()) F395_5698;
	R5429[7] = (char *(*)()) F402_5720;
	R5429[22] = (char *(*)()) F415_5764;
	R5429[248] = (char *(*)()) F621_6019;
	R5429[298] = (char *(*)()) F693_6129;
	R5429[299] = (char *(*)()) F694_6129;
	R5429[300] = (char *(*)()) F695_6129;
	{long i; for (i = 301; i < 303; i++) R5429[i] = (char *(*)()) F693_6129;}
	R5429[303] = (char *(*)()) F694_6129;
	R5429[304] = (char *(*)()) F695_6129;
	R5429[305] = (char *(*)()) F700_6211;
	R5429[306] = (char *(*)()) F701_6211;
	R5429[307] = (char *(*)()) F702_6211;
	R5429[308] = (char *(*)()) F703_6211;
	R5429[309] = (char *(*)()) F704_6211;
	R5429[310] = (char *(*)()) F705_6211;
	R5429[311] = (char *(*)()) F706_6211;
	R5429[312] = (char *(*)()) F707_6211;
	R5429[313] = (char *(*)()) F708_6211;
	R5429[314] = (char *(*)()) F709_6211;
	R5429[315] = (char *(*)()) F710_6211;
	R5429[316] = (char *(*)()) F711_6211;
	R5429[337] = (char *(*)()) F732_6306;
	R5429[342] = (char *(*)()) F737_6367;
	R5429[373] = (char *(*)()) F768_6400;
	R5429[374] = (char *(*)()) F769_6400;
	R5429[375] = (char *(*)()) F770_6400;
	R5429[376] = (char *(*)()) F771_6400;
	R5429[377] = (char *(*)()) F772_6400;
	R5429[378] = (char *(*)()) F773_6400;
	R5429[379] = (char *(*)()) F774_6400;
	R5429[380] = (char *(*)()) F775_6400;
	R5429[381] = (char *(*)()) F776_6400;
	R5429[382] = (char *(*)()) F777_6400;
	R5429[383] = (char *(*)()) F778_6400;
	R5429[384] = (char *(*)()) F779_6400;
	R5429[385] = (char *(*)()) F768_6400;
	R5429[386] = (char *(*)()) F774_6400;
	R5429[387] = (char *(*)()) F770_6400;
	R5429[388] = (char *(*)()) F768_6400;
	{long i; for (i = 389; i < 391; i++) R5429[i] = (char *(*)()) F770_6400;}
	R5429[391] = (char *(*)()) F768_6400;
	R5429[392] = (char *(*)()) F770_6400;
	R5429[393] = (char *(*)()) F775_6400;
	R5429[406] = (char *(*)()) F801_6450;
	R5429[407] = (char *(*)()) F802_6450;
	R5429[408] = (char *(*)()) F803_6450;
	R5429[409] = (char *(*)()) F804_6450;
	R5429[410] = (char *(*)()) F805_6450;
	R5429[411] = (char *(*)()) F806_6450;
	R5429[412] = (char *(*)()) F807_6450;
	R5429[413] = (char *(*)()) F808_6450;
	R5429[414] = (char *(*)()) F809_6450;
	R5429[415] = (char *(*)()) F810_6450;
	R5429[416] = (char *(*)()) F811_6450;
	R5429[417] = (char *(*)()) F812_6450;
	R5429[418] = (char *(*)()) F813_6456;
	R5429[419] = (char *(*)()) F814_6462;
	R5429[420] = (char *(*)()) F815_6468;
	R5429[421] = (char *(*)()) F816_6468;
	R5429[422] = (char *(*)()) F817_6468;
	R5429[423] = (char *(*)()) F818_6468;
	R5429[424] = (char *(*)()) F819_6468;
	R5429[425] = (char *(*)()) F820_6468;
	R5429[426] = (char *(*)()) F821_6468;
	R5429[427] = (char *(*)()) F822_6468;
	R5429[428] = (char *(*)()) F823_6468;
	R5429[429] = (char *(*)()) F824_6468;
	R5429[430] = (char *(*)()) F825_6468;
	R5429[431] = (char *(*)()) F826_6468;
	R5429[432] = (char *(*)()) F827_6474;
	R5429[433] = (char *(*)()) F828_6474;
	R5429[434] = (char *(*)()) F829_6474;
	R5429[435] = (char *(*)()) F830_6474;
	R5429[436] = (char *(*)()) F831_6474;
	R5429[437] = (char *(*)()) F832_6474;
	R5429[438] = (char *(*)()) F833_6474;
	R5429[439] = (char *(*)()) F834_6474;
	R5429[440] = (char *(*)()) F835_6474;
	R5429[441] = (char *(*)()) F836_6474;
	R5429[442] = (char *(*)()) F837_6474;
	R5429[443] = (char *(*)()) F838_6474;
	R5429[446] = (char *(*)()) F841_6525;
	R5429[447] = (char *(*)()) F842_6525;
	R5429[448] = (char *(*)()) F843_6525;
	R5429[449] = (char *(*)()) F844_6525;
	R5429[450] = (char *(*)()) F845_6525;
	R5429[451] = (char *(*)()) F846_6525;
	R5429[452] = (char *(*)()) F841_6525;
	R5429[453] = (char *(*)()) F842_6525;
	R5429[454] = (char *(*)()) F841_6525;
	R5429[455] = (char *(*)()) F850_6655;
	R5429[456] = (char *(*)()) F851_6655;
	R5429[457] = (char *(*)()) F852_6655;
	R5429[458] = (char *(*)()) F853_6655;
	R5429[459] = (char *(*)()) F854_6655;
	R5429[460] = (char *(*)()) F855_6655;
	R5429[461] = (char *(*)()) F856_6655;
	R5429[462] = (char *(*)()) F857_6655;
	R5429[463] = (char *(*)()) F858_6655;
	R5429[464] = (char *(*)()) F859_6655;
	R5429[465] = (char *(*)()) F860_6655;
	R5429[466] = (char *(*)()) F861_6655;
	R5429[467] = (char *(*)()) F850_6655;
	R5429[468] = (char *(*)()) F854_6655;
	R5429[469] = (char *(*)()) F852_6655;
	R5429[474] = (char *(*)()) F850_6655;
	R5429[475] = (char *(*)()) F852_6655;
	{long i; for (i = 476; i < 480; i++) R5429[i] = (char *(*)()) F850_6655;}
	{long i; for (i = 485; i < 487; i++) R5429[i] = (char *(*)()) F850_6655;}
	{long i; for (i = 490; i < 492; i++) R5429[i] = (char *(*)()) F850_6655;}
	{long i; for (i = 494; i < 499; i++) R5429[i] = (char *(*)()) F850_6655;}
	R5429[519] = (char *(*)()) F914_7120;
	R5429[522] = (char *(*)()) F917_7196;
	R5429[523] = (char *(*)()) F918_7196;
	R5429[524] = (char *(*)()) F919_7196;
	R5429[525] = (char *(*)()) F920_7196;
	R5429[526] = (char *(*)()) F921_7196;
	R5429[527] = (char *(*)()) F922_7196;
	R5429[528] = (char *(*)()) F923_7196;
	R5429[529] = (char *(*)()) F924_7196;
	R5429[530] = (char *(*)()) F925_7196;
	R5429[531] = (char *(*)()) F926_7196;
	R5429[532] = (char *(*)()) F927_7196;
	R5429[533] = (char *(*)()) F928_7196;
	{long i; for (i = 607; i < 609; i++) R5429[i] = (char *(*)()) F1001_7964;}
	R5429[655] = (char *(*)()) F619_6019;
	{long i; for (i = 738; i < 740; i++) R5429[i] = (char *(*)()) F1132_9932;}
	{long i; for (i = 741; i < 743; i++) R5429[i] = (char *(*)()) F1135_10100;}
	{long i; for (i = 823; i < 826; i++) R5429[i] = (char *(*)()) F619_6019;}
	{long i; for (i = 826; i < 828; i++) R5429[i] = (char *(*)()) F1213_11033;}
	{long i; for (i = 829; i < 831; i++) R5429[i] = (char *(*)()) F1213_11033;}
	{long i; for (i = 834; i < 837; i++) R5429[i] = (char *(*)()) F1213_11033;}
	R5429[838] = (char *(*)()) F1213_11033;
	R5429[866] = (char *(*)()) F619_6019;
	R5429[873] = (char *(*)()) F619_6019;
	{long i; for (i = 876; i < 878; i++) R5429[i] = (char *(*)()) F619_6019;}
	R5429[1074] = (char *(*)()) F1469_14938;
	R5429[1111] = (char *(*)()) F1488_15161;
	R5429[1116] = (char *(*)()) F1490_15161;
	R5429[1117] = (char *(*)()) F1491_15161;
	R5429[1151] = (char *(*)()) F1531_15309;
	R5429[1158] = (char *(*)()) F1533_15309;
	R5429[1159] = (char *(*)()) F1534_15309;
}


#ifdef __cplusplus
}
#endif
