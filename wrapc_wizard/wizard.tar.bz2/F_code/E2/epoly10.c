#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O3914[1254];
void O3914_init () {
	O3914[0] =  + _REFACS_2_;
	{long i; for (i = 1113; i < 1115; i++) O3914[i] =  + _REFACS_4_;}
	{long i; for (i = 1149; i < 1151; i++) O3914[i] =  + _REFACS_6_;}
	{long i; for (i = 1151; i < 1153; i++) O3914[i] =  + _REFACS_23_;}
	{long i; for (i = 1153; i < 1156; i++) O3914[i] =  + _REFACS_24_;}
	O3914[1156] =  + _REFACS_25_;
	{long i; for (i = 1157; i < 1159; i++) O3914[i] =  + _REFACS_24_;}
	O3914[1159] =  + _REFACS_25_;
	O3914[1160] =  + _REFACS_24_;
	{long i; for (i = 1161; i < 1175; i++) O3914[i] =  + _REFACS_25_;}
	{long i; for (i = 1175; i < 1177; i++) O3914[i] =  + _REFACS_29_;}
	{long i; for (i = 1177; i < 1179; i++) O3914[i] =  + _REFACS_32_;}
	{long i; for (i = 1179; i < 1181; i++) O3914[i] =  + _REFACS_29_;}
	{long i; for (i = 1181; i < 1183; i++) O3914[i] =  + _REFACS_32_;}
	O3914[1183] =  + _REFACS_23_;
	O3914[1184] =  + _REFACS_24_;
	O3914[1185] =  + _REFACS_25_;
	O3914[1186] =  + _REFACS_27_;
	O3914[1187] =  + _REFACS_24_;
	O3914[1188] =  + _REFACS_23_;
	O3914[1189] =  + _REFACS_24_;
	O3914[1190] =  + _REFACS_25_;
	O3914[1191] =  + _REFACS_24_;
	O3914[1192] =  + _REFACS_27_;
	{long i; for (i = 1193; i < 1197; i++) O3914[i] =  + _REFACS_24_;}
	O3914[1197] =  + _REFACS_25_;
	O3914[1198] =  + _REFACS_29_;
	O3914[1199] =  + _REFACS_25_;
	O3914[1200] =  + _REFACS_27_;
	O3914[1201] =  + _REFACS_23_;
	O3914[1202] =  + _REFACS_24_;
	O3914[1203] =  + _REFACS_25_;
	O3914[1204] =  + _REFACS_27_;
	O3914[1205] =  + _REFACS_24_;
	O3914[1206] =  + _REFACS_23_;
	O3914[1207] =  + _REFACS_24_;
	O3914[1208] =  + _REFACS_25_;
	O3914[1209] =  + _REFACS_24_;
	O3914[1210] =  + _REFACS_27_;
	O3914[1211] =  + _REFACS_25_;
	O3914[1212] =  + _REFACS_29_;
	O3914[1213] =  + _REFACS_25_;
	O3914[1214] =  + _REFACS_27_;
	{long i; for (i = 1215; i < 1219; i++) O3914[i] =  + _REFACS_24_;}
	{long i; for (i = 1219; i < 1221; i++) O3914[i] =  + _REFACS_9_;}
	{long i; for (i = 1221; i < 1223; i++) O3914[i] =  + _REFACS_11_;}
	{long i; for (i = 1223; i < 1227; i++) O3914[i] =  + _REFACS_13_;}
	{long i; for (i = 1227; i < 1229; i++) O3914[i] =  + _REFACS_9_;}
	{long i; for (i = 1229; i < 1233; i++) O3914[i] =  + _REFACS_10_;}
	O3914[1233] =  + _REFACS_11_;
	{long i; for (i = 1234; i < 1238; i++) O3914[i] =  + _REFACS_10_;}
	{long i; for (i = 1238; i < 1241; i++) O3914[i] =  + _REFACS_11_;}
	{long i; for (i = 1241; i < 1245; i++) O3914[i] =  + _REFACS_13_;}
	O3914[1246] =  + _REFACS_24_;
	O3914[1248] =  + _REFACS_24_;
	O3914[1251] =  + _REFACS_24_;
	O3914[1253] =  + _REFACS_24_;
}

long O3916[1254];
void O3916_init () {
	O3916[0] = + _I16OFF_3_1_2_;
	O3916[1113] = + _I16OFF_7_5_2_;
	O3916[1114] = + _I16OFF_8_6_2_;
	O3916[1149] = + _I16OFF_13_5_2_;
	O3916[1150] = + _I16OFF_16_7_2_;
	O3916[1151] = + _I16OFF_35_9_2_;
	O3916[1152] = + _I16OFF_42_12_2_;
	O3916[1153] = + _I16OFF_37_9_2_;
	O3916[1154] = + _I16OFF_46_12_2_;
	O3916[1155] = + _I16OFF_37_9_2_;
	O3916[1156] = + _I16OFF_38_9_2_;
	O3916[1157] = + _I16OFF_37_9_2_;
	O3916[1158] = + _I16OFF_47_12_2_;
	O3916[1159] = + _I16OFF_49_12_2_;
	O3916[1160] = + _I16OFF_47_12_2_;
	{long i; for (i = 1161; i < 1164; i++) O3916[i] = + _I16OFF_39_10_2_;}
	{long i; for (i = 1164; i < 1167; i++) O3916[i] = + _I16OFF_49_13_2_;}
	{long i; for (i = 1167; i < 1171; i++) O3916[i] = + _I16OFF_39_10_2_;}
	O3916[1171] = + _I16OFF_49_13_2_;
	O3916[1172] = + _I16OFF_51_13_2_;
	{long i; for (i = 1173; i < 1175; i++) O3916[i] = + _I16OFF_49_14_2_;}
	O3916[1175] = + _I16OFF_47_12_2_;
	O3916[1176] = + _I16OFF_47_14_2_;
	O3916[1177] = + _I16OFF_50_13_2_;
	O3916[1178] = + _I16OFF_53_13_2_;
	O3916[1179] = + _I16OFF_59_21_2_;
	O3916[1180] = + _I16OFF_59_23_2_;
	O3916[1181] = + _I16OFF_65_25_2_;
	O3916[1182] = + _I16OFF_68_26_2_;
	O3916[1183] = + _I16OFF_35_9_2_;
	{long i; for (i = 1184; i < 1186; i++) O3916[i] = + _I16OFF_37_9_2_;}
	O3916[1186] = + _I16OFF_43_9_2_;
	O3916[1187] = + _I16OFF_37_10_2_;
	O3916[1188] = + _I16OFF_35_9_2_;
	O3916[1189] = + _I16OFF_36_9_2_;
	O3916[1190] = + _I16OFF_37_9_2_;
	O3916[1191] = + _I16OFF_36_9_2_;
	O3916[1192] = + _I16OFF_40_12_2_;
	{long i; for (i = 1193; i < 1197; i++) O3916[i] = + _I16OFF_36_9_2_;}
	O3916[1197] = + _I16OFF_37_9_2_;
	O3916[1198] = + _I16OFF_41_9_2_;
	O3916[1199] = + _I16OFF_37_10_2_;
	O3916[1200] = + _I16OFF_39_10_2_;
	O3916[1201] = + _I16OFF_42_13_2_;
	O3916[1202] = + _I16OFF_44_13_2_;
	O3916[1203] = + _I16OFF_51_13_2_;
	O3916[1204] = + _I16OFF_58_14_2_;
	O3916[1205] = + _I16OFF_45_16_2_;
	O3916[1206] = + _I16OFF_44_13_2_;
	O3916[1207] = + _I16OFF_43_13_2_;
	O3916[1208] = + _I16OFF_46_14_2_;
	O3916[1209] = + _I16OFF_44_15_2_;
	O3916[1210] = + _I16OFF_51_18_2_;
	O3916[1211] = + _I16OFF_50_13_2_;
	O3916[1212] = + _I16OFF_59_16_2_;
	O3916[1213] = + _I16OFF_51_14_2_;
	O3916[1214] = + _I16OFF_53_14_2_;
	{long i; for (i = 1215; i < 1219; i++) O3916[i] = + _I16OFF_46_14_2_;}
	{long i; for (i = 1219; i < 1221; i++) O3916[i] = + _I16OFF_16_5_2_;}
	O3916[1221] = + _I16OFF_18_5_2_;
	O3916[1222] = + _I16OFF_23_5_2_;
	{long i; for (i = 1223; i < 1225; i++) O3916[i] = + _I16OFF_20_5_2_;}
	{long i; for (i = 1225; i < 1227; i++) O3916[i] = + _I16OFF_25_6_2_;}
	{long i; for (i = 1227; i < 1229; i++) O3916[i] = + _I16OFF_21_7_2_;}
	{long i; for (i = 1229; i < 1233; i++) O3916[i] = + _I16OFF_17_6_2_;}
	O3916[1233] = + _I16OFF_18_6_2_;
	O3916[1234] = + _I16OFF_23_8_2_;
	O3916[1235] = + _I16OFF_23_9_2_;
	O3916[1236] = + _I16OFF_24_9_2_;
	O3916[1237] = + _I16OFF_23_9_2_;
	O3916[1238] = + _I16OFF_26_8_2_;
	O3916[1239] = + _I16OFF_19_5_2_;
	O3916[1240] = + _I16OFF_22_5_2_;
	{long i; for (i = 1241; i < 1243; i++) O3916[i] = + _I16OFF_21_10_2_;}
	{long i; for (i = 1243; i < 1245; i++) O3916[i] = + _I16OFF_29_14_2_;}
	O3916[1246] = + _I16OFF_36_10_2_;
	O3916[1248] = + _I16OFF_36_9_2_;
	O3916[1251] = + _I16OFF_48_19_2_;
	O3916[1253] = + _I16OFF_48_18_2_;
}

long O3917[1254];
void O3917_init () {
	O3917[0] = + _I16OFF_3_1_3_;
	O3917[1113] = + _I16OFF_7_5_3_;
	O3917[1114] = + _I16OFF_8_6_3_;
	O3917[1149] = + _I16OFF_13_5_3_;
	O3917[1150] = + _I16OFF_16_7_3_;
	O3917[1151] = + _I16OFF_35_9_3_;
	O3917[1152] = + _I16OFF_42_12_3_;
	O3917[1153] = + _I16OFF_37_9_3_;
	O3917[1154] = + _I16OFF_46_12_3_;
	O3917[1155] = + _I16OFF_37_9_3_;
	O3917[1156] = + _I16OFF_38_9_3_;
	O3917[1157] = + _I16OFF_37_9_3_;
	O3917[1158] = + _I16OFF_47_12_3_;
	O3917[1159] = + _I16OFF_49_12_3_;
	O3917[1160] = + _I16OFF_47_12_3_;
	{long i; for (i = 1161; i < 1164; i++) O3917[i] = + _I16OFF_39_10_3_;}
	{long i; for (i = 1164; i < 1167; i++) O3917[i] = + _I16OFF_49_13_3_;}
	{long i; for (i = 1167; i < 1171; i++) O3917[i] = + _I16OFF_39_10_3_;}
	O3917[1171] = + _I16OFF_49_13_3_;
	O3917[1172] = + _I16OFF_51_13_3_;
	{long i; for (i = 1173; i < 1175; i++) O3917[i] = + _I16OFF_49_14_3_;}
	O3917[1175] = + _I16OFF_47_12_3_;
	O3917[1176] = + _I16OFF_47_14_3_;
	O3917[1177] = + _I16OFF_50_13_3_;
	O3917[1178] = + _I16OFF_53_13_3_;
	O3917[1179] = + _I16OFF_59_21_3_;
	O3917[1180] = + _I16OFF_59_23_3_;
	O3917[1181] = + _I16OFF_65_25_3_;
	O3917[1182] = + _I16OFF_68_26_3_;
	O3917[1183] = + _I16OFF_35_9_3_;
	{long i; for (i = 1184; i < 1186; i++) O3917[i] = + _I16OFF_37_9_3_;}
	O3917[1186] = + _I16OFF_43_9_3_;
	O3917[1187] = + _I16OFF_37_10_3_;
	O3917[1188] = + _I16OFF_35_9_3_;
	O3917[1189] = + _I16OFF_36_9_3_;
	O3917[1190] = + _I16OFF_37_9_3_;
	O3917[1191] = + _I16OFF_36_9_3_;
	O3917[1192] = + _I16OFF_40_12_3_;
	{long i; for (i = 1193; i < 1197; i++) O3917[i] = + _I16OFF_36_9_3_;}
	O3917[1197] = + _I16OFF_37_9_3_;
	O3917[1198] = + _I16OFF_41_9_3_;
	O3917[1199] = + _I16OFF_37_10_3_;
	O3917[1200] = + _I16OFF_39_10_3_;
	O3917[1201] = + _I16OFF_42_13_3_;
	O3917[1202] = + _I16OFF_44_13_3_;
	O3917[1203] = + _I16OFF_51_13_3_;
	O3917[1204] = + _I16OFF_58_14_3_;
	O3917[1205] = + _I16OFF_45_16_3_;
	O3917[1206] = + _I16OFF_44_13_3_;
	O3917[1207] = + _I16OFF_43_13_3_;
	O3917[1208] = + _I16OFF_46_14_3_;
	O3917[1209] = + _I16OFF_44_15_3_;
	O3917[1210] = + _I16OFF_51_18_3_;
	O3917[1211] = + _I16OFF_50_13_3_;
	O3917[1212] = + _I16OFF_59_16_3_;
	O3917[1213] = + _I16OFF_51_14_3_;
	O3917[1214] = + _I16OFF_53_14_3_;
	{long i; for (i = 1215; i < 1219; i++) O3917[i] = + _I16OFF_46_14_3_;}
	{long i; for (i = 1219; i < 1221; i++) O3917[i] = + _I16OFF_16_5_3_;}
	O3917[1221] = + _I16OFF_18_5_3_;
	O3917[1222] = + _I16OFF_23_5_3_;
	{long i; for (i = 1223; i < 1225; i++) O3917[i] = + _I16OFF_20_5_3_;}
	{long i; for (i = 1225; i < 1227; i++) O3917[i] = + _I16OFF_25_6_3_;}
	{long i; for (i = 1227; i < 1229; i++) O3917[i] = + _I16OFF_21_7_3_;}
	{long i; for (i = 1229; i < 1233; i++) O3917[i] = + _I16OFF_17_6_3_;}
	O3917[1233] = + _I16OFF_18_6_3_;
	O3917[1234] = + _I16OFF_23_8_3_;
	O3917[1235] = + _I16OFF_23_9_3_;
	O3917[1236] = + _I16OFF_24_9_3_;
	O3917[1237] = + _I16OFF_23_9_3_;
	O3917[1238] = + _I16OFF_26_8_3_;
	O3917[1239] = + _I16OFF_19_5_3_;
	O3917[1240] = + _I16OFF_22_5_3_;
	{long i; for (i = 1241; i < 1243; i++) O3917[i] = + _I16OFF_21_10_3_;}
	{long i; for (i = 1243; i < 1245; i++) O3917[i] = + _I16OFF_29_14_3_;}
	O3917[1246] = + _I16OFF_36_10_3_;
	O3917[1248] = + _I16OFF_36_9_3_;
	O3917[1251] = + _I16OFF_48_19_3_;
	O3917[1253] = + _I16OFF_48_18_3_;
}

long O4117[4];
void O4117_init () {
	O4117[0] = + _CHROFF_2_0_;
	O4117[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O4117[i] = + _CHROFF_2_0_;}
}

long O4118[4];
void O4118_init () {
	O4118[0] = + _CHROFF_2_1_;
	O4118[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O4118[i] = + _CHROFF_2_1_;}
}

long O4186[188];
void O4186_init () {
	O4186[0] = 0;
	O4186[1] = + _CHROFF_0_0_;
	O4186[2] = + _LNGOFF_0_0_0_0_;
	O4186[3] = + _I64OFF_0_0_0_0_0_0_0_;
	O4186[4] = + _LNGOFF_0_0_0_0_;
	O4186[5] = 0;
	O4186[6] = + _CHROFF_1_0_;
	O4186[7] = + _LNGOFF_1_0_0_0_;
	{long i; for (i = 186; i < 188; i++) O4186[i] = 0;}
}

long O4190[3];
void O4190_init () {
	O4190[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O4190[i] = 0;}
}

long O4902[10];
void O4902_init () {
	O4902[0] = + _CHROFF_2_0_;
	O4902[1] = + _CHROFF_3_0_;
	O4902[9] = + _CHROFF_4_0_;
}

static EIF_TYPE_INDEX Y4990_pgtype0[] = {0xFF01,916,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype1[] = {0xFF01,917,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype2[] = {0xFF01,918,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype3[] = {0xFF01,919,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype4[] = {0xFF01,920,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype5[] = {0xFF01,921,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype6[] = {0xFF01,922,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype7[] = {0xFF01,923,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype8[] = {0xFF01,924,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype9[] = {0xFF01,925,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype10[] = {0xFF01,926,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype11[] = {0xFF01,927,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype12[] = {0xFF01,921,1085,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype13[] = {0xFF01,921,1085,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype14[] = {0xFF01,916,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype15[] = {0xFF01,917,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype16[] = {0xFF01,918,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype17[] = {0xFF01,919,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype18[] = {0xFF01,920,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype19[] = {0xFF01,921,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype20[] = {0xFF01,922,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype21[] = {0xFF01,923,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype22[] = {0xFF01,924,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype23[] = {0xFF01,925,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype24[] = {0xFF01,926,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype25[] = {0xFF01,927,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype26[] = {0xFF01,916,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype27[] = {0xFF01,918,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype28[] = {0xFF01,920,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype29[] = {0xFF01,917,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype30[] = {0xFF01,919,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype31[] = {0xFF01,923,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype32[] = {0xFF01,921,1085,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype33[] = {0xFF01,916,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype34[] = {0xFF01,917,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype35[] = {0xFF01,918,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype36[] = {0xFF01,919,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype37[] = {0xFF01,920,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype38[] = {0xFF01,921,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype39[] = {0xFF01,922,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype40[] = {0xFF01,923,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype41[] = {0xFF01,924,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype42[] = {0xFF01,925,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype43[] = {0xFF01,926,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype44[] = {0xFF01,927,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype45[] = {0xFF01,916,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype46[] = {0xFF01,920,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype47[] = {0xFF01,918,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype48[] = {0xFF01,916,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype49[] = {0xFF01,918,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype50[] = {0xFF01,916,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype51[] = {0xFF01,918,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype52[] = {0xFF01,916,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype53[] = {0xFF01,918,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype54[] = {0xFF01,916,0xFF01,1179,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype55[] = {0xFF01,916,0xFF01,1123,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype56[] = {0xFF01,916,0xFF01,1123,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype57[] = {0xFF01,916,0xFF01,1123,0xFFF9,1,1049,0xFF01,0,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype58[] = {0xFF01,916,0xFF01,1123,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype59[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,1,1049,1067,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype60[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1248,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype61[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,1,1049,1067,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype62[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype63[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1254,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype64[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1186,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype65[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,1,1049,1009,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype66[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1249,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype67[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,1,1049,1067,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype68[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,4,1049,1067,1067,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype69[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1467,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype70[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,5,1049,1079,1067,1067,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype71[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1133,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype72[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,2,1049,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype73[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,7,1049,1067,1067,1052,1052,1052,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype74[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,3,1049,1067,1067,1009,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype75[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,8,1049,1067,1067,1067,1052,1052,1052,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype76[] = {0xFF01,916,0xFF01,1123,0xFF01,0xFFF9,0,1049,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype77[] = {0xFF01,924,1055,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype78[] = {0xFF01,923,1058,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype79[] = {0xFF01,923,1058,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype80[] = {0xFF01,923,1058,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype81[] = {0xFF01,916,0xFF01,1133,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype82[] = {0xFF01,923,1058,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype83[] = {0xFF01,923,1058,0xFFFF};
EIF_TYPE_INDEX *Y4990_gen_type [1235];
EIF_TYPE_INDEX Y4990 [1235];
void Y4990_init (void)
{
	egc_routines_types [4990] = Y4990;
	egc_routines_gen_types [4990] = Y4990_gen_type;
	egc_routines_offset [4990] = 339;
	Y4990_gen_type [0] = Y4990_pgtype0;
	Y4990_gen_type [1] = Y4990_pgtype1;
	Y4990_gen_type [2] = Y4990_pgtype2;
	Y4990_gen_type [3] = Y4990_pgtype3;
	Y4990_gen_type [4] = Y4990_pgtype4;
	Y4990_gen_type [5] = Y4990_pgtype5;
	Y4990_gen_type [6] = Y4990_pgtype6;
	Y4990_gen_type [7] = Y4990_pgtype7;
	Y4990_gen_type [8] = Y4990_pgtype8;
	Y4990_gen_type [9] = Y4990_pgtype9;
	Y4990_gen_type [10] = Y4990_pgtype10;
	Y4990_gen_type [11] = Y4990_pgtype11;
	Y4990_gen_type [35] = Y4990_pgtype12;
	Y4990_gen_type [36] = Y4990_pgtype13;
	Y4990_gen_type [360] = Y4990_pgtype14;
	Y4990_gen_type [361] = Y4990_pgtype15;
	Y4990_gen_type [362] = Y4990_pgtype16;
	Y4990_gen_type [363] = Y4990_pgtype17;
	Y4990_gen_type [364] = Y4990_pgtype18;
	Y4990_gen_type [365] = Y4990_pgtype19;
	Y4990_gen_type [366] = Y4990_pgtype20;
	Y4990_gen_type [367] = Y4990_pgtype21;
	Y4990_gen_type [368] = Y4990_pgtype22;
	Y4990_gen_type [369] = Y4990_pgtype23;
	Y4990_gen_type [370] = Y4990_pgtype24;
	Y4990_gen_type [371] = Y4990_pgtype25;
	Y4990_gen_type [372] = Y4990_pgtype26;
	Y4990_gen_type [373] = Y4990_pgtype27;
	Y4990_gen_type [374] = Y4990_pgtype28;
	Y4990_gen_type [375] = Y4990_pgtype29;
	Y4990_gen_type [376] = Y4990_pgtype30;
	Y4990_gen_type [377] = Y4990_pgtype31;
	Y4990_gen_type [378] = Y4990_pgtype32;
	Y4990_gen_type [510] = Y4990_pgtype33;
	Y4990_gen_type [511] = Y4990_pgtype34;
	Y4990_gen_type [512] = Y4990_pgtype35;
	Y4990_gen_type [513] = Y4990_pgtype36;
	Y4990_gen_type [514] = Y4990_pgtype37;
	Y4990_gen_type [515] = Y4990_pgtype38;
	Y4990_gen_type [516] = Y4990_pgtype39;
	Y4990_gen_type [517] = Y4990_pgtype40;
	Y4990_gen_type [518] = Y4990_pgtype41;
	Y4990_gen_type [519] = Y4990_pgtype42;
	Y4990_gen_type [520] = Y4990_pgtype43;
	Y4990_gen_type [521] = Y4990_pgtype44;
	Y4990_gen_type [522] = Y4990_pgtype45;
	Y4990_gen_type [523] = Y4990_pgtype46;
	Y4990_gen_type [524] = Y4990_pgtype47;
	Y4990_gen_type [525] = Y4990_pgtype48;
	Y4990_gen_type [526] = Y4990_pgtype49;
	Y4990_gen_type [527] = Y4990_pgtype50;
	Y4990_gen_type [528] = Y4990_pgtype51;
	Y4990_gen_type [529] = Y4990_pgtype52;
	Y4990_gen_type [530] = Y4990_pgtype53;
	Y4990_gen_type [531] = Y4990_pgtype54;
	Y4990_gen_type [532] = Y4990_pgtype55;
	Y4990_gen_type [533] = Y4990_pgtype56;
	Y4990_gen_type [534] = Y4990_pgtype57;
	Y4990_gen_type [535] = Y4990_pgtype58;
	Y4990_gen_type [536] = Y4990_pgtype59;
	Y4990_gen_type [537] = Y4990_pgtype60;
	Y4990_gen_type [538] = Y4990_pgtype61;
	Y4990_gen_type [539] = Y4990_pgtype62;
	Y4990_gen_type [540] = Y4990_pgtype63;
	Y4990_gen_type [541] = Y4990_pgtype64;
	Y4990_gen_type [542] = Y4990_pgtype65;
	Y4990_gen_type [543] = Y4990_pgtype66;
	Y4990_gen_type [544] = Y4990_pgtype67;
	Y4990_gen_type [545] = Y4990_pgtype68;
	Y4990_gen_type [546] = Y4990_pgtype69;
	Y4990_gen_type [547] = Y4990_pgtype70;
	Y4990_gen_type [548] = Y4990_pgtype71;
	Y4990_gen_type [549] = Y4990_pgtype72;
	Y4990_gen_type [550] = Y4990_pgtype73;
	Y4990_gen_type [551] = Y4990_pgtype74;
	Y4990_gen_type [552] = Y4990_pgtype75;
	Y4990_gen_type [553] = Y4990_pgtype76;
	Y4990_gen_type [794] = Y4990_pgtype77;
	Y4990_gen_type [797] = Y4990_pgtype78;
	Y4990_gen_type [798] = Y4990_pgtype79;
	Y4990_gen_type [799] = Y4990_pgtype80;
	Y4990_gen_type [909] = Y4990_pgtype81;
	Y4990_gen_type [1233] = Y4990_pgtype82;
	Y4990_gen_type [1234] = Y4990_pgtype83;
	Y4990[0] = 916;
	Y4990[1] = 917;
	Y4990[2] = 918;
	Y4990[3] = 919;
	Y4990[4] = 920;
	Y4990[5] = 921;
	Y4990[6] = 922;
	Y4990[7] = 923;
	Y4990[8] = 924;
	Y4990[9] = 925;
	Y4990[10] = 926;
	Y4990[11] = 927;
	{long i; for (i = 35; i < 37; i++) Y4990[i] = 921;};
	Y4990[360] = 916;
	Y4990[361] = 917;
	Y4990[362] = 918;
	Y4990[363] = 919;
	Y4990[364] = 920;
	Y4990[365] = 921;
	Y4990[366] = 922;
	Y4990[367] = 923;
	Y4990[368] = 924;
	Y4990[369] = 925;
	Y4990[370] = 926;
	Y4990[371] = 927;
	Y4990[372] = 916;
	Y4990[373] = 918;
	Y4990[374] = 920;
	Y4990[375] = 917;
	Y4990[376] = 919;
	Y4990[377] = 923;
	Y4990[378] = 921;
	Y4990[510] = 916;
	Y4990[511] = 917;
	Y4990[512] = 918;
	Y4990[513] = 919;
	Y4990[514] = 920;
	Y4990[515] = 921;
	Y4990[516] = 922;
	Y4990[517] = 923;
	Y4990[518] = 924;
	Y4990[519] = 925;
	Y4990[520] = 926;
	Y4990[521] = 927;
	Y4990[522] = 916;
	Y4990[523] = 920;
	Y4990[524] = 918;
	Y4990[525] = 916;
	Y4990[526] = 918;
	Y4990[527] = 916;
	Y4990[528] = 918;
	Y4990[529] = 916;
	Y4990[530] = 918;
	{long i; for (i = 531; i < 554; i++) Y4990[i] = 916;};
	Y4990[794] = 924;
	{long i; for (i = 797; i < 800; i++) Y4990[i] = 923;};
	Y4990[909] = 916;
	{long i; for (i = 1233; i < 1235; i++) Y4990[i] = 923;};
}

long O5398[923];
void O5398_init () {
	{long i; for (i = 0; i < 4; i++) O5398[i] = + _LNGOFF_0_0_0_0_;}
	O5398[4] = + _LNGOFF_13_16_0_4_;
	O5398[628] = + _LNGOFF_15_11_0_0_;
	O5398[630] = + _LNGOFF_1_0_0_0_;
	O5398[917] = + _LNGOFF_1_1_0_0_;
	O5398[922] = + _LNGOFF_49_16_0_2_;
}

long O5484[1172];
void O5484_init () {
	{long i; for (i = 0; i < 12; i++) O5484[i] = + _CHROFF_0_0_;}
	O5484[12] = + _CHROFF_1_0_;
	{long i; for (i = 13; i < 15; i++) O5484[i] = + _CHROFF_4_0_;}
	{long i; for (i = 15; i < 199; i++) O5484[i] = + _CHROFF_0_0_;}
	O5484[199] = + _CHROFF_1_0_;
	{long i; for (i = 200; i < 216; i++) O5484[i] = + _CHROFF_0_0_;}
	{long i; for (i = 228; i < 241; i++) O5484[i] = + _CHROFF_0_0_;}
	O5484[241] = + _CHROFF_1_0_;
	{long i; for (i = 242; i < 290; i++) O5484[i] = + _CHROFF_0_0_;}
	{long i; for (i = 290; i < 297; i++) O5484[i] = + _CHROFF_2_0_;}
	{long i; for (i = 297; i < 315; i++) O5484[i] = + _CHROFF_1_0_;}
	O5484[315] = + _CHROFF_2_0_;
	O5484[329] = + _CHROFF_0_0_;
	O5484[332] = + _CHROFF_2_0_;
	O5484[334] = + _CHROFF_0_0_;
	O5484[437] = + _CHROFF_1_0_;
	O5484[438] = + _CHROFF_7_0_;
	O5484[439] = + _CHROFF_5_0_;
	O5484[440] = + _CHROFF_4_0_;
	O5484[441] = + _CHROFF_6_0_;
	O5484[442] = + _CHROFF_4_0_;
	O5484[443] = + _CHROFF_5_0_;
	O5484[444] = + _CHROFF_7_0_;
	O5484[445] = + _CHROFF_5_0_;
	O5484[446] = + _CHROFF_9_0_;
	{long i; for (i = 447; i < 464; i++) O5484[i] = + _CHROFF_1_0_;}
	{long i; for (i = 464; i < 466; i++) O5484[i] = + _CHROFF_3_0_;}
	{long i; for (i = 466; i < 469; i++) O5484[i] = + _CHROFF_5_0_;}
	{long i; for (i = 469; i < 471; i++) O5484[i] = + _CHROFF_9_0_;}
	O5484[471] = + _CHROFF_10_0_;
	{long i; for (i = 472; i < 491; i++) O5484[i] = + _CHROFF_9_0_;}
	O5484[598] = + _CHROFF_3_2_;
	O5484[599] = + _CHROFF_4_2_;
	O5484[600] = + _CHROFF_5_2_;
	O5484[731] = + _CHROFF_1_0_;
	{long i; for (i = 734; i < 737; i++) O5484[i] = + _CHROFF_1_0_;}
	O5484[807] = + _CHROFF_3_0_;
	{long i; for (i = 810; i < 817; i++) O5484[i] = + _CHROFF_6_0_;}
	O5484[817] = + _CHROFF_10_0_;
	{long i; for (i = 818; i < 825; i++) O5484[i] = + _CHROFF_6_0_;}
	{long i; for (i = 825; i < 827; i++) O5484[i] = + _CHROFF_12_0_;}
	O5484[827] = + _CHROFF_6_0_;
	O5484[828] = + _CHROFF_7_0_;
	{long i; for (i = 829; i < 831; i++) O5484[i] = + _CHROFF_14_0_;}
	O5484[846] = + _CHROFF_7_0_;
	O5484[856] = + _CHROFF_3_0_;
	{long i; for (i = 857; i < 859; i++) O5484[i] = + _CHROFF_5_0_;}
	O5484[859] = + _CHROFF_3_0_;
	O5484[860] = + _CHROFF_5_0_;
	{long i; for (i = 861; i < 863; i++) O5484[i] = + _CHROFF_6_0_;}
	{long i; for (i = 863; i < 865; i++) O5484[i] = + _CHROFF_3_0_;}
	O5484[865] = + _CHROFF_6_0_;
	{long i; for (i = 866; i < 870; i++) O5484[i] = + _CHROFF_5_0_;}
	O5484[1066] = + _CHROFF_5_2_;
	{long i; for (i = 1170; i < 1172; i++) O5484[i] = + _CHROFF_1_0_;}
}

static EIF_TYPE_INDEX Y5552_pgtype0[] = {415,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5552_pgtype1[] = {416,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5552_gen_type [2];
EIF_TYPE_INDEX Y5552 [2];
void Y5552_init (void)
{
	egc_routines_types [5552] = Y5552;
	egc_routines_gen_types [5552] = Y5552_gen_type;
	egc_routines_offset [5552] = 415;
	Y5552_gen_type [0] = Y5552_pgtype0;
	Y5552_gen_type [1] = Y5552_pgtype1;
	Y5552[0] = 415;
	Y5552[1] = 416;
}

long O5868[21];
void O5868_init () {
	{long i; for (i = 0; i < 12; i++) O5868[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 12; i < 15; i++) O5868[i] = + _LNGOFF_2_1_0_0_;}
	{long i; for (i = 15; i < 21; i++) O5868[i] = + _LNGOFF_1_1_0_0_;}
}

long O5872[21];
void O5872_init () {
	{long i; for (i = 0; i < 12; i++) O5872[i] = + _CHROFF_1_0_;}
	{long i; for (i = 12; i < 15; i++) O5872[i] = + _CHROFF_2_0_;}
	{long i; for (i = 15; i < 21; i++) O5872[i] = + _CHROFF_1_0_;}
}

long O5873[21];
void O5873_init () {
	{long i; for (i = 0; i < 12; i++) O5873[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 12; i < 15; i++) O5873[i] = + _LNGOFF_2_1_0_1_;}
	{long i; for (i = 15; i < 21; i++) O5873[i] = + _LNGOFF_1_1_0_1_;}
}

long O5874[21];
void O5874_init () {
	{long i; for (i = 0; i < 12; i++) O5874[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 12; i < 15; i++) O5874[i] = + _LNGOFF_2_1_0_2_;}
	{long i; for (i = 15; i < 21; i++) O5874[i] = + _LNGOFF_1_1_0_2_;}
}

long O5875[21];
void O5875_init () {
	{long i; for (i = 0; i < 12; i++) O5875[i] = + _LNGOFF_1_1_0_3_;}
	{long i; for (i = 12; i < 15; i++) O5875[i] = + _LNGOFF_2_1_0_3_;}
	{long i; for (i = 15; i < 21; i++) O5875[i] = + _LNGOFF_1_1_0_3_;}
}

long O5876[21];
void O5876_init () {
	{long i; for (i = 0; i < 12; i++) O5876[i] = + _LNGOFF_1_1_0_4_;}
	{long i; for (i = 12; i < 15; i++) O5876[i] = + _LNGOFF_2_1_0_4_;}
	{long i; for (i = 15; i < 21; i++) O5876[i] = + _LNGOFF_1_1_0_4_;}
}

long O5879[50];
void O5879_init () {
	{long i; for (i = 0; i < 12; i++) O5879[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 12; i < 38; i++) O5879[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 38; i < 50; i++) O5879[i] = + _LNGOFF_1_0_0_0_;}
}

long O5881[50];
void O5881_init () {
	{long i; for (i = 0; i < 12; i++) O5881[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 12; i < 38; i++) O5881[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 38; i < 50; i++) O5881[i] = + _LNGOFF_1_0_0_1_;}
}

EIF_TYPE_INDEX *Y5905_gen_type [1];
EIF_TYPE_INDEX Y5905 [1];
void Y5905_init (void)
{
	egc_routines_types [5905] = Y5905;
	egc_routines_gen_types [5905] = Y5905_gen_type;
	egc_routines_offset [5905] = 839;
	Y5905[0] = 1067;
}

long O5910[9];
void O5910_init () {
	O5910[0] = 0;
	O5910[1] = + _LNGOFF_5_3_0_0_;
	O5910[2] = + _LNGOFF_4_3_0_1_;
	O5910[3] = 0;
	O5910[4] = + _LNGOFF_4_3_0_0_;
	O5910[5] = + _PTROFF_5_3_0_7_0_0_;
	O5910[6] = 0;
	O5910[7] = + _LNGOFF_5_4_0_0_;
	O5910[8] = 0;
}

long O5919[9];
void O5919_init () {
	O5919[0] = + _LNGOFF_7_3_0_0_;
	O5919[1] = + _LNGOFF_5_3_0_1_;
	O5919[2] = + _LNGOFF_4_3_0_2_;
	O5919[3] = + _LNGOFF_6_3_0_0_;
	O5919[4] = + _LNGOFF_4_3_0_1_;
	O5919[5] = + _LNGOFF_5_3_0_0_;
	O5919[6] = + _LNGOFF_7_4_0_0_;
	O5919[7] = + _LNGOFF_5_4_0_1_;
	O5919[8] = + _LNGOFF_9_3_0_0_;
}

long O5946[9];
void O5946_init () {
	O5946[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O5946[i] = 0;}
	O5946[3] =  + _REFACS_1_;
	{long i; for (i = 4; i < 6; i++) O5946[i] = 0;}
	O5946[6] =  + _REFACS_1_;
	O5946[7] = 0;
	O5946[8] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y5946_pgtype0[] = {0xFF01,916,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5946_pgtype1[] = {0xFF01,918,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5946_pgtype2[] = {0xFF01,918,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5946_pgtype3[] = {0xFF01,916,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5946_pgtype4[] = {0xFF01,918,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5946_pgtype5[] = {0xFF01,922,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5946_pgtype6[] = {0xFF01,916,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5946_pgtype7[] = {0xFF01,918,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5946_pgtype8[] = {0xFF01,916,0,0xFFFF};
EIF_TYPE_INDEX *Y5946_gen_type [9];
EIF_TYPE_INDEX Y5946 [9];
void Y5946_init (void)
{
	egc_routines_types [5946] = Y5946;
	egc_routines_gen_types [5946] = Y5946_gen_type;
	egc_routines_offset [5946] = 840;
	Y5946_gen_type [0] = Y5946_pgtype0;
	Y5946_gen_type [1] = Y5946_pgtype1;
	Y5946_gen_type [2] = Y5946_pgtype2;
	Y5946_gen_type [3] = Y5946_pgtype3;
	Y5946_gen_type [4] = Y5946_pgtype4;
	Y5946_gen_type [5] = Y5946_pgtype5;
	Y5946_gen_type [6] = Y5946_pgtype6;
	Y5946_gen_type [7] = Y5946_pgtype7;
	Y5946_gen_type [8] = Y5946_pgtype8;
	Y5946[0] = 916;
	{long i; for (i = 1; i < 3; i++) Y5946[i] = 918;};
	Y5946[3] = 916;
	Y5946[4] = 918;
	Y5946[5] = 922;
	Y5946[6] = 916;
	Y5946[7] = 918;
	Y5946[8] = 916;
}

long O5947[9];
void O5947_init () {
	O5947[0] =  + _REFACS_2_;
	{long i; for (i = 1; i < 3; i++) O5947[i] =  + _REFACS_1_;}
	O5947[3] =  + _REFACS_2_;
	{long i; for (i = 4; i < 6; i++) O5947[i] =  + _REFACS_1_;}
	O5947[6] =  + _REFACS_2_;
	O5947[7] =  + _REFACS_1_;
	O5947[8] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y5947_pgtype0[] = {0xFF01,916,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5947_pgtype1[] = {0xFF01,916,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5947_pgtype2[] = {0xFF01,917,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5947_pgtype3[] = {0xFF01,918,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5947_pgtype4[] = {0xFF01,918,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5947_pgtype5[] = {0xFF01,916,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5947_pgtype6[] = {0xFF01,916,0xFF01,1128,0xFFFF};
static EIF_TYPE_INDEX Y5947_pgtype7[] = {0xFF01,916,0xFF01,1128,0xFFFF};
static EIF_TYPE_INDEX Y5947_pgtype8[] = {0xFF01,916,0xFF01,1136,0xFFFF};
EIF_TYPE_INDEX *Y5947_gen_type [9];
EIF_TYPE_INDEX Y5947 [9];
void Y5947_init (void)
{
	egc_routines_types [5947] = Y5947;
	egc_routines_gen_types [5947] = Y5947_gen_type;
	egc_routines_offset [5947] = 840;
	Y5947_gen_type [0] = Y5947_pgtype0;
	Y5947_gen_type [1] = Y5947_pgtype1;
	Y5947_gen_type [2] = Y5947_pgtype2;
	Y5947_gen_type [3] = Y5947_pgtype3;
	Y5947_gen_type [4] = Y5947_pgtype4;
	Y5947_gen_type [5] = Y5947_pgtype5;
	Y5947_gen_type [6] = Y5947_pgtype6;
	Y5947_gen_type [7] = Y5947_pgtype7;
	Y5947_gen_type [8] = Y5947_pgtype8;
	{long i; for (i = 0; i < 2; i++) Y5947[i] = 916;};
	Y5947[2] = 917;
	{long i; for (i = 3; i < 5; i++) Y5947[i] = 918;};
	{long i; for (i = 5; i < 9; i++) Y5947[i] = 916;};
}

long O5948[9];
void O5948_init () {
	O5948[0] =  + _REFACS_3_;
	{long i; for (i = 1; i < 3; i++) O5948[i] =  + _REFACS_2_;}
	O5948[3] =  + _REFACS_3_;
	{long i; for (i = 4; i < 6; i++) O5948[i] =  + _REFACS_2_;}
	O5948[6] =  + _REFACS_3_;
	O5948[7] =  + _REFACS_2_;
	O5948[8] =  + _REFACS_3_;
}

long O5949[9];
void O5949_init () {
	O5949[0] =  + _REFACS_4_;
	{long i; for (i = 1; i < 3; i++) O5949[i] =  + _REFACS_3_;}
	O5949[3] =  + _REFACS_4_;
	{long i; for (i = 4; i < 6; i++) O5949[i] =  + _REFACS_3_;}
	O5949[6] =  + _REFACS_4_;
	O5949[7] =  + _REFACS_3_;
	O5949[8] =  + _REFACS_4_;
}

long O5950[9];
void O5950_init () {
	O5950[0] = + _LNGOFF_7_3_0_1_;
	O5950[1] = + _LNGOFF_5_3_0_2_;
	O5950[2] = + _LNGOFF_4_3_0_3_;
	O5950[3] = + _LNGOFF_6_3_0_1_;
	O5950[4] = + _LNGOFF_4_3_0_2_;
	O5950[5] = + _LNGOFF_5_3_0_1_;
	O5950[6] = + _LNGOFF_7_4_0_1_;
	O5950[7] = + _LNGOFF_5_4_0_2_;
	O5950[8] = + _LNGOFF_9_3_0_1_;
}

long O5951[9];
void O5951_init () {
	O5951[0] = + _CHROFF_7_2_;
	O5951[1] = + _CHROFF_5_2_;
	O5951[2] = + _CHROFF_4_2_;
	O5951[3] = + _CHROFF_6_2_;
	O5951[4] = + _CHROFF_4_2_;
	O5951[5] = + _CHROFF_5_2_;
	O5951[6] = + _CHROFF_7_2_;
	O5951[7] = + _CHROFF_5_2_;
	O5951[8] = + _CHROFF_9_2_;
}

long O5952[9];
void O5952_init () {
	O5952[0] = + _LNGOFF_7_3_0_2_;
	O5952[1] = + _LNGOFF_5_3_0_3_;
	O5952[2] = + _LNGOFF_4_3_0_4_;
	O5952[3] = + _LNGOFF_6_3_0_2_;
	O5952[4] = + _LNGOFF_4_3_0_3_;
	O5952[5] = + _LNGOFF_5_3_0_2_;
	O5952[6] = + _LNGOFF_7_4_0_2_;
	O5952[7] = + _LNGOFF_5_4_0_3_;
	O5952[8] = + _LNGOFF_9_3_0_2_;
}

long O5955[9];
void O5955_init () {
	O5955[0] = + _LNGOFF_7_3_0_3_;
	O5955[1] = + _LNGOFF_5_3_0_4_;
	O5955[2] = + _LNGOFF_4_3_0_5_;
	O5955[3] = + _LNGOFF_6_3_0_3_;
	O5955[4] = + _LNGOFF_4_3_0_4_;
	O5955[5] = + _LNGOFF_5_3_0_3_;
	O5955[6] = + _LNGOFF_7_4_0_3_;
	O5955[7] = + _LNGOFF_5_4_0_4_;
	O5955[8] = + _LNGOFF_9_3_0_3_;
}

long O5956[9];
void O5956_init () {
	O5956[0] = + _LNGOFF_7_3_0_4_;
	O5956[1] = + _LNGOFF_5_3_0_5_;
	O5956[2] = + _LNGOFF_4_3_0_6_;
	O5956[3] = + _LNGOFF_6_3_0_4_;
	O5956[4] = + _LNGOFF_4_3_0_5_;
	O5956[5] = + _LNGOFF_5_3_0_4_;
	O5956[6] = + _LNGOFF_7_4_0_4_;
	O5956[7] = + _LNGOFF_5_4_0_5_;
	O5956[8] = + _LNGOFF_9_3_0_4_;
}

long O5960[9];
void O5960_init () {
	O5960[0] = + _LNGOFF_7_3_0_5_;
	O5960[1] = + _LNGOFF_5_3_0_6_;
	O5960[2] = + _LNGOFF_4_3_0_7_;
	O5960[3] = + _LNGOFF_6_3_0_5_;
	O5960[4] = + _LNGOFF_4_3_0_6_;
	O5960[5] = + _LNGOFF_5_3_0_5_;
	O5960[6] = + _LNGOFF_7_4_0_5_;
	O5960[7] = + _LNGOFF_5_4_0_6_;
	O5960[8] = + _LNGOFF_9_3_0_5_;
}

long O5961[9];
void O5961_init () {
	O5961[0] =  + _REFACS_5_;
	O5961[1] = + _LNGOFF_5_3_0_7_;
	O5961[2] = + _LNGOFF_4_3_0_8_;
	O5961[3] =  + _REFACS_5_;
	O5961[4] = + _LNGOFF_4_3_0_7_;
	O5961[5] = + _PTROFF_5_3_0_7_0_1_;
	O5961[6] =  + _REFACS_5_;
	O5961[7] = + _LNGOFF_5_4_0_7_;
	O5961[8] =  + _REFACS_5_;
}

long O5962[9];
void O5962_init () {
	O5962[0] =  + _REFACS_6_;
	O5962[1] =  + _REFACS_4_;
	O5962[2] = + _LNGOFF_4_3_0_0_;
	O5962[3] = + _LNGOFF_6_3_0_6_;
	O5962[4] = + _LNGOFF_4_3_0_8_;
	O5962[5] =  + _REFACS_4_;
	O5962[6] =  + _REFACS_6_;
	O5962[7] =  + _REFACS_4_;
	O5962[8] =  + _REFACS_6_;
}

long O5996[9];
void O5996_init () {
	O5996[0] = + _LNGOFF_7_3_0_6_;
	O5996[1] = + _LNGOFF_5_3_0_8_;
	O5996[2] = + _LNGOFF_4_3_0_9_;
	O5996[3] = + _LNGOFF_6_3_0_7_;
	O5996[4] = + _LNGOFF_4_3_0_9_;
	O5996[5] = + _LNGOFF_5_3_0_6_;
	O5996[6] = + _LNGOFF_7_4_0_6_;
	O5996[7] = + _LNGOFF_5_4_0_8_;
	O5996[8] = + _LNGOFF_9_3_0_6_;
}

long O5999[2];
void O5999_init () {
	O5999[0] = + _CHROFF_7_3_;
	O5999[1] = + _CHROFF_5_3_;
}

long O6024[400];
void O6024_init () {
	{long i; for (i = 0; i < 15; i++) O6024[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 15; i < 17; i++) O6024[i] = + _LNGOFF_1_2_0_0_;}
	{long i; for (i = 17; i < 19; i++) O6024[i] = + _LNGOFF_3_2_0_0_;}
	{long i; for (i = 19; i < 22; i++) O6024[i] = + _LNGOFF_5_2_0_0_;}
	{long i; for (i = 22; i < 24; i++) O6024[i] = + _LNGOFF_9_2_0_0_;}
	O6024[24] = + _LNGOFF_10_2_0_0_;
	{long i; for (i = 25; i < 44; i++) O6024[i] = + _LNGOFF_9_2_0_0_;}
	O6024[399] = + _LNGOFF_7_2_0_0_;
}

long O6032[385];
void O6032_init () {
	{long i; for (i = 0; i < 2; i++) O6032[i] = + _CHROFF_1_1_;}
	{long i; for (i = 2; i < 4; i++) O6032[i] = + _CHROFF_3_1_;}
	{long i; for (i = 4; i < 7; i++) O6032[i] = + _CHROFF_5_1_;}
	{long i; for (i = 7; i < 9; i++) O6032[i] = + _CHROFF_9_1_;}
	O6032[9] = + _CHROFF_10_1_;
	{long i; for (i = 10; i < 29; i++) O6032[i] = + _CHROFF_9_1_;}
	O6032[384] = + _CHROFF_7_1_;
}

static EIF_TYPE_INDEX Y6035_pgtype0[] = {0xFF01,871,0xFF01,0xFFF9,1,1049,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6035_pgtype1[] = {0xFF01,871,0xFF01,0xFFF9,1,1049,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6035_pgtype2[] = {0xFF01,871,0xFF01,0xFFF9,1,1049,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6035_pgtype3[] = {0xFF01,871,0xFF01,0xFFF9,1,1049,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6035_pgtype4[] = {0xFF01,871,0xFF01,0xFFF9,1,1049,0xFF01,1179,0xFFFF};
EIF_TYPE_INDEX *Y6035_gen_type [5];
EIF_TYPE_INDEX Y6035 [5];
void Y6035_init (void)
{
	egc_routines_types [6035] = Y6035;
	egc_routines_gen_types [6035] = Y6035_gen_type;
	egc_routines_offset [6035] = 866;
	Y6035_gen_type [0] = Y6035_pgtype0;
	Y6035_gen_type [1] = Y6035_pgtype1;
	Y6035_gen_type [2] = Y6035_pgtype2;
	Y6035_gen_type [3] = Y6035_pgtype3;
	Y6035_gen_type [4] = Y6035_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y6035[i] = 871;};
}

static EIF_TYPE_INDEX Y6036_pgtype0[] = {0xFF01,871,0xFF01,0xFFF9,1,1049,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6036_pgtype1[] = {0xFF01,871,0xFF01,0xFFF9,1,1049,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6036_pgtype2[] = {0xFF01,871,0xFF01,0xFFF9,1,1049,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6036_pgtype3[] = {0xFF01,871,0xFF01,0xFFF9,1,1049,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6036_pgtype4[] = {0xFF01,871,0xFF01,0xFFF9,1,1049,0xFF01,1179,0xFFFF};
EIF_TYPE_INDEX *Y6036_gen_type [5];
EIF_TYPE_INDEX Y6036 [5];
void Y6036_init (void)
{
	egc_routines_types [6036] = Y6036;
	egc_routines_gen_types [6036] = Y6036_gen_type;
	egc_routines_offset [6036] = 866;
	Y6036_gen_type [0] = Y6036_pgtype0;
	Y6036_gen_type [1] = Y6036_pgtype1;
	Y6036_gen_type [2] = Y6036_pgtype2;
	Y6036_gen_type [3] = Y6036_pgtype3;
	Y6036_gen_type [4] = Y6036_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y6036[i] = 871;};
}

static EIF_TYPE_INDEX Y6037_pgtype0[] = {0xFF01,872,0xFF01,0xFFF9,1,1049,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6037_pgtype1[] = {0xFF01,872,0xFF01,0xFFF9,1,1049,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6037_pgtype2[] = {0xFF01,872,0xFF01,0xFFF9,1,1049,0xFF01,1179,0xFFFF};
EIF_TYPE_INDEX *Y6037_gen_type [3];
EIF_TYPE_INDEX Y6037 [3];
void Y6037_init (void)
{
	egc_routines_types [6037] = Y6037;
	egc_routines_gen_types [6037] = Y6037_gen_type;
	egc_routines_offset [6037] = 868;
	Y6037_gen_type [0] = Y6037_pgtype0;
	Y6037_gen_type [1] = Y6037_pgtype1;
	Y6037_gen_type [2] = Y6037_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y6037[i] = 872;};
}

static EIF_TYPE_INDEX Y6038_pgtype0[] = {0xFF01,872,0xFF01,0xFFF9,1,1049,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6038_pgtype1[] = {0xFF01,872,0xFF01,0xFFF9,1,1049,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6038_pgtype2[] = {0xFF01,872,0xFF01,0xFFF9,1,1049,0xFF01,1179,0xFFFF};
EIF_TYPE_INDEX *Y6038_gen_type [3];
EIF_TYPE_INDEX Y6038 [3];
void Y6038_init (void)
{
	egc_routines_types [6038] = Y6038;
	egc_routines_gen_types [6038] = Y6038_gen_type;
	egc_routines_offset [6038] = 868;
	Y6038_gen_type [0] = Y6038_pgtype0;
	Y6038_gen_type [1] = Y6038_pgtype1;
	Y6038_gen_type [2] = Y6038_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y6038[i] = 872;};
}

long O6051[22];
void O6051_init () {
	{long i; for (i = 0; i < 2; i++) O6051[i] = + _LNGOFF_9_2_0_1_;}
	O6051[2] = + _LNGOFF_10_2_0_1_;
	{long i; for (i = 3; i < 22; i++) O6051[i] = + _LNGOFF_9_2_0_1_;}
}

long O6454[10];
void O6454_init () {
	O6454[0] = + _CHROFF_8_0_;
	O6454[1] = + _CHROFF_10_0_;
	{long i; for (i = 2; i < 10; i++) O6454[i] = + _CHROFF_9_0_;}
}

long O6455[10];
void O6455_init () {
	O6455[0] = + _CHROFF_8_1_;
	O6455[1] = + _CHROFF_10_1_;
	{long i; for (i = 2; i < 10; i++) O6455[i] = + _CHROFF_9_1_;}
}

long O6835[471];
void O6835_init () {
	O6835[0] = + _CHROFF_1_0_;
	O6835[1] = + _CHROFF_2_0_;
	O6835[2] = + _CHROFF_3_0_;
	O6835[3] = + _CHROFF_4_0_;
	O6835[4] = + _CHROFF_5_0_;
	O6835[470] = + _CHROFF_5_0_;
}

long O6952[469];
void O6952_init () {
	O6952[0] = + _PTROFF_3_6_2_4_1_0_;
	O6952[1] = + _PTROFF_4_6_2_4_1_0_;
	O6952[2] = + _PTROFF_5_7_2_4_1_0_;
	O6952[468] = + _PTROFF_5_7_2_4_1_0_;
}

long O7091[469];
void O7091_init () {
	O7091[0] = + _LNGOFF_3_6_2_3_;
	O7091[1] = + _LNGOFF_4_6_2_3_;
	O7091[2] = + _LNGOFF_5_7_2_3_;
	O7091[468] = + _LNGOFF_5_7_2_3_;
}

long O7100[469];
void O7100_init () {
	O7100[0] = + _CHROFF_3_3_;
	O7100[1] = + _CHROFF_4_3_;
	O7100[2] = + _CHROFF_5_3_;
	O7100[468] = + _CHROFF_5_3_;
}


#ifdef __cplusplus
}
#endif
