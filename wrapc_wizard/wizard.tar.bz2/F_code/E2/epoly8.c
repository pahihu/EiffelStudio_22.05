#include "epoly8.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

static EIF_TYPE_INDEX Y5625_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype32[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype33[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype34[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype35[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype36[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype37[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype38[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype39[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype40[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype41[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype42[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype43[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype44[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype45[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype46[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype47[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype48[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype49[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype50[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype51[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype52[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype53[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype54[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype55[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype56[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype57[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype58[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype59[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype60[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype61[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype62[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype63[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype64[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype65[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype66[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype67[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype68[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype69[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype70[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype71[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype72[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype73[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype74[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype75[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype76[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype77[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype78[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype79[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype80[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype81[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype82[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype83[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype84[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype85[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype86[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype87[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype88[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype89[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype90[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype91[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype92[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype93[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype94[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype95[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype96[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype97[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype98[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype99[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype100[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype101[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype102[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype103[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype104[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype105[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype106[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype107[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype108[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype109[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype110[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype111[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype112[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype113[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype114[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype115[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype116[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype117[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype118[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype119[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype120[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype121[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype122[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype123[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype124[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype125[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype126[] = {0xFF01,1128,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype127[] = {0xFF01,1128,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype128[] = {0xFF01,1136,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype129[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype130[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype131[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype132[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype133[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype134[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype135[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype136[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype137[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype138[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype139[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype140[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype141[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype142[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype143[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype144[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype145[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype146[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype147[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype148[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype149[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype150[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype151[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype152[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype153[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype154[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype155[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype156[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype157[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype158[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype159[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype160[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype161[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype162[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype163[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype164[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype165[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype166[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype167[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype168[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype169[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype170[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype171[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype172[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype173[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype174[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype175[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype176[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype177[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype178[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype179[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype180[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype181[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype182[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype183[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype184[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype185[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype186[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype187[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype188[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype189[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype190[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype191[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype192[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype193[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype194[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype195[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype196[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype197[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype198[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype199[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype200[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5625_pgtype201[] = {1067,0xFFFF};
EIF_TYPE_INDEX *Y5625_gen_type [1096];
EIF_TYPE_INDEX Y5625 [1096];
void Y5625_init (void)
{
	egc_routines_types [5625] = Y5625;
	egc_routines_gen_types [5625] = Y5625_gen_type;
	egc_routines_offset [5625] = 478;
	Y5625_gen_type [0] = Y5625_pgtype0;
	Y5625_gen_type [1] = Y5625_pgtype1;
	Y5625_gen_type [2] = Y5625_pgtype2;
	Y5625_gen_type [3] = Y5625_pgtype3;
	Y5625_gen_type [4] = Y5625_pgtype4;
	Y5625_gen_type [5] = Y5625_pgtype5;
	Y5625_gen_type [6] = Y5625_pgtype6;
	Y5625_gen_type [7] = Y5625_pgtype7;
	Y5625_gen_type [8] = Y5625_pgtype8;
	Y5625_gen_type [9] = Y5625_pgtype9;
	Y5625_gen_type [10] = Y5625_pgtype10;
	Y5625_gen_type [11] = Y5625_pgtype11;
	Y5625_gen_type [12] = Y5625_pgtype12;
	Y5625_gen_type [13] = Y5625_pgtype13;
	Y5625_gen_type [14] = Y5625_pgtype14;
	Y5625_gen_type [15] = Y5625_pgtype15;
	Y5625_gen_type [16] = Y5625_pgtype16;
	Y5625_gen_type [17] = Y5625_pgtype17;
	Y5625_gen_type [18] = Y5625_pgtype18;
	Y5625_gen_type [19] = Y5625_pgtype19;
	Y5625_gen_type [20] = Y5625_pgtype20;
	Y5625_gen_type [21] = Y5625_pgtype21;
	Y5625_gen_type [22] = Y5625_pgtype22;
	Y5625_gen_type [23] = Y5625_pgtype23;
	Y5625_gen_type [24] = Y5625_pgtype24;
	Y5625_gen_type [25] = Y5625_pgtype25;
	Y5625_gen_type [26] = Y5625_pgtype26;
	Y5625_gen_type [27] = Y5625_pgtype27;
	Y5625_gen_type [28] = Y5625_pgtype28;
	Y5625_gen_type [29] = Y5625_pgtype29;
	Y5625_gen_type [30] = Y5625_pgtype30;
	Y5625_gen_type [31] = Y5625_pgtype31;
	Y5625_gen_type [152] = Y5625_pgtype32;
	Y5625_gen_type [153] = Y5625_pgtype33;
	Y5625_gen_type [154] = Y5625_pgtype34;
	Y5625_gen_type [155] = Y5625_pgtype35;
	Y5625_gen_type [156] = Y5625_pgtype36;
	Y5625_gen_type [157] = Y5625_pgtype37;
	Y5625_gen_type [158] = Y5625_pgtype38;
	Y5625_gen_type [159] = Y5625_pgtype39;
	Y5625_gen_type [160] = Y5625_pgtype40;
	Y5625_gen_type [161] = Y5625_pgtype41;
	Y5625_gen_type [162] = Y5625_pgtype42;
	Y5625_gen_type [163] = Y5625_pgtype43;
	Y5625_gen_type [164] = Y5625_pgtype44;
	Y5625_gen_type [165] = Y5625_pgtype45;
	Y5625_gen_type [166] = Y5625_pgtype46;
	Y5625_gen_type [167] = Y5625_pgtype47;
	Y5625_gen_type [168] = Y5625_pgtype48;
	Y5625_gen_type [169] = Y5625_pgtype49;
	Y5625_gen_type [170] = Y5625_pgtype50;
	Y5625_gen_type [171] = Y5625_pgtype51;
	Y5625_gen_type [172] = Y5625_pgtype52;
	Y5625_gen_type [173] = Y5625_pgtype53;
	Y5625_gen_type [174] = Y5625_pgtype54;
	Y5625_gen_type [175] = Y5625_pgtype55;
	Y5625_gen_type [176] = Y5625_pgtype56;
	Y5625_gen_type [177] = Y5625_pgtype57;
	Y5625_gen_type [178] = Y5625_pgtype58;
	Y5625_gen_type [179] = Y5625_pgtype59;
	Y5625_gen_type [180] = Y5625_pgtype60;
	Y5625_gen_type [181] = Y5625_pgtype61;
	Y5625_gen_type [182] = Y5625_pgtype62;
	Y5625_gen_type [183] = Y5625_pgtype63;
	Y5625_gen_type [184] = Y5625_pgtype64;
	Y5625_gen_type [185] = Y5625_pgtype65;
	Y5625_gen_type [186] = Y5625_pgtype66;
	Y5625_gen_type [187] = Y5625_pgtype67;
	Y5625_gen_type [188] = Y5625_pgtype68;
	Y5625_gen_type [189] = Y5625_pgtype69;
	Y5625_gen_type [190] = Y5625_pgtype70;
	Y5625_gen_type [191] = Y5625_pgtype71;
	Y5625_gen_type [192] = Y5625_pgtype72;
	Y5625_gen_type [193] = Y5625_pgtype73;
	Y5625_gen_type [194] = Y5625_pgtype74;
	Y5625_gen_type [195] = Y5625_pgtype75;
	Y5625_gen_type [196] = Y5625_pgtype76;
	Y5625_gen_type [197] = Y5625_pgtype77;
	Y5625_gen_type [198] = Y5625_pgtype78;
	Y5625_gen_type [199] = Y5625_pgtype79;
	Y5625_gen_type [200] = Y5625_pgtype80;
	Y5625_gen_type [201] = Y5625_pgtype81;
	Y5625_gen_type [202] = Y5625_pgtype82;
	Y5625_gen_type [203] = Y5625_pgtype83;
	Y5625_gen_type [204] = Y5625_pgtype84;
	Y5625_gen_type [205] = Y5625_pgtype85;
	Y5625_gen_type [206] = Y5625_pgtype86;
	Y5625_gen_type [207] = Y5625_pgtype87;
	Y5625_gen_type [208] = Y5625_pgtype88;
	Y5625_gen_type [209] = Y5625_pgtype89;
	Y5625_gen_type [210] = Y5625_pgtype90;
	Y5625_gen_type [211] = Y5625_pgtype91;
	Y5625_gen_type [212] = Y5625_pgtype92;
	Y5625_gen_type [213] = Y5625_pgtype93;
	Y5625_gen_type [214] = Y5625_pgtype94;
	Y5625_gen_type [215] = Y5625_pgtype95;
	Y5625_gen_type [216] = Y5625_pgtype96;
	Y5625_gen_type [217] = Y5625_pgtype97;
	Y5625_gen_type [218] = Y5625_pgtype98;
	Y5625_gen_type [219] = Y5625_pgtype99;
	Y5625_gen_type [220] = Y5625_pgtype100;
	Y5625_gen_type [221] = Y5625_pgtype101;
	Y5625_gen_type [222] = Y5625_pgtype102;
	Y5625_gen_type [223] = Y5625_pgtype103;
	Y5625_gen_type [224] = Y5625_pgtype104;
	Y5625_gen_type [225] = Y5625_pgtype105;
	Y5625_gen_type [226] = Y5625_pgtype106;
	Y5625_gen_type [227] = Y5625_pgtype107;
	Y5625_gen_type [228] = Y5625_pgtype108;
	Y5625_gen_type [229] = Y5625_pgtype109;
	Y5625_gen_type [230] = Y5625_pgtype110;
	Y5625_gen_type [231] = Y5625_pgtype111;
	Y5625_gen_type [232] = Y5625_pgtype112;
	Y5625_gen_type [233] = Y5625_pgtype113;
	Y5625_gen_type [234] = Y5625_pgtype114;
	Y5625_gen_type [235] = Y5625_pgtype115;
	Y5625_gen_type [236] = Y5625_pgtype116;
	Y5625_gen_type [237] = Y5625_pgtype117;
	Y5625_gen_type [238] = Y5625_pgtype118;
	Y5625_gen_type [239] = Y5625_pgtype119;
	Y5625_gen_type [362] = Y5625_pgtype120;
	Y5625_gen_type [363] = Y5625_pgtype121;
	Y5625_gen_type [364] = Y5625_pgtype122;
	Y5625_gen_type [365] = Y5625_pgtype123;
	Y5625_gen_type [366] = Y5625_pgtype124;
	Y5625_gen_type [367] = Y5625_pgtype125;
	Y5625_gen_type [368] = Y5625_pgtype126;
	Y5625_gen_type [369] = Y5625_pgtype127;
	Y5625_gen_type [370] = Y5625_pgtype128;
	Y5625_gen_type [371] = Y5625_pgtype129;
	Y5625_gen_type [372] = Y5625_pgtype130;
	Y5625_gen_type [373] = Y5625_pgtype131;
	Y5625_gen_type [374] = Y5625_pgtype132;
	Y5625_gen_type [375] = Y5625_pgtype133;
	Y5625_gen_type [376] = Y5625_pgtype134;
	Y5625_gen_type [377] = Y5625_pgtype135;
	Y5625_gen_type [378] = Y5625_pgtype136;
	Y5625_gen_type [379] = Y5625_pgtype137;
	Y5625_gen_type [380] = Y5625_pgtype138;
	Y5625_gen_type [381] = Y5625_pgtype139;
	Y5625_gen_type [382] = Y5625_pgtype140;
	Y5625_gen_type [383] = Y5625_pgtype141;
	Y5625_gen_type [384] = Y5625_pgtype142;
	Y5625_gen_type [385] = Y5625_pgtype143;
	Y5625_gen_type [386] = Y5625_pgtype144;
	Y5625_gen_type [387] = Y5625_pgtype145;
	Y5625_gen_type [388] = Y5625_pgtype146;
	Y5625_gen_type [389] = Y5625_pgtype147;
	Y5625_gen_type [390] = Y5625_pgtype148;
	Y5625_gen_type [391] = Y5625_pgtype149;
	Y5625_gen_type [392] = Y5625_pgtype150;
	Y5625_gen_type [393] = Y5625_pgtype151;
	Y5625_gen_type [394] = Y5625_pgtype152;
	Y5625_gen_type [395] = Y5625_pgtype153;
	Y5625_gen_type [396] = Y5625_pgtype154;
	Y5625_gen_type [397] = Y5625_pgtype155;
	Y5625_gen_type [398] = Y5625_pgtype156;
	Y5625_gen_type [399] = Y5625_pgtype157;
	Y5625_gen_type [400] = Y5625_pgtype158;
	Y5625_gen_type [401] = Y5625_pgtype159;
	Y5625_gen_type [402] = Y5625_pgtype160;
	Y5625_gen_type [403] = Y5625_pgtype161;
	Y5625_gen_type [404] = Y5625_pgtype162;
	Y5625_gen_type [405] = Y5625_pgtype163;
	Y5625_gen_type [406] = Y5625_pgtype164;
	Y5625_gen_type [407] = Y5625_pgtype165;
	Y5625_gen_type [408] = Y5625_pgtype166;
	Y5625_gen_type [409] = Y5625_pgtype167;
	Y5625_gen_type [410] = Y5625_pgtype168;
	Y5625_gen_type [411] = Y5625_pgtype169;
	Y5625_gen_type [412] = Y5625_pgtype170;
	Y5625_gen_type [413] = Y5625_pgtype171;
	Y5625_gen_type [414] = Y5625_pgtype172;
	Y5625_gen_type [655] = Y5625_pgtype173;
	Y5625_gen_type [658] = Y5625_pgtype174;
	Y5625_gen_type [659] = Y5625_pgtype175;
	Y5625_gen_type [660] = Y5625_pgtype176;
	Y5625_gen_type [731] = Y5625_pgtype177;
	Y5625_gen_type [735] = Y5625_pgtype178;
	Y5625_gen_type [736] = Y5625_pgtype179;
	Y5625_gen_type [737] = Y5625_pgtype180;
	Y5625_gen_type [738] = Y5625_pgtype181;
	Y5625_gen_type [739] = Y5625_pgtype182;
	Y5625_gen_type [740] = Y5625_pgtype183;
	Y5625_gen_type [741] = Y5625_pgtype184;
	Y5625_gen_type [770] = Y5625_pgtype185;
	Y5625_gen_type [780] = Y5625_pgtype186;
	Y5625_gen_type [781] = Y5625_pgtype187;
	Y5625_gen_type [782] = Y5625_pgtype188;
	Y5625_gen_type [783] = Y5625_pgtype189;
	Y5625_gen_type [784] = Y5625_pgtype190;
	Y5625_gen_type [785] = Y5625_pgtype191;
	Y5625_gen_type [786] = Y5625_pgtype192;
	Y5625_gen_type [787] = Y5625_pgtype193;
	Y5625_gen_type [788] = Y5625_pgtype194;
	Y5625_gen_type [789] = Y5625_pgtype195;
	Y5625_gen_type [790] = Y5625_pgtype196;
	Y5625_gen_type [791] = Y5625_pgtype197;
	Y5625_gen_type [792] = Y5625_pgtype198;
	Y5625_gen_type [793] = Y5625_pgtype199;
	Y5625_gen_type [1094] = Y5625_pgtype200;
	Y5625_gen_type [1095] = Y5625_pgtype201;
	{long i; for (i = 152; i < 240; i++) Y5625[i] = 1067;};
	{long i; for (i = 368; i < 370; i++) Y5625[i] = 1128;};
	Y5625[370] = 1136;
	{long i; for (i = 371; i < 415; i++) Y5625[i] = 1067;};
	Y5625[655] = 1067;
	{long i; for (i = 658; i < 661; i++) Y5625[i] = 1067;};
	Y5625[731] = 1067;
	{long i; for (i = 735; i < 742; i++) Y5625[i] = 1067;};
	Y5625[770] = 1067;
	{long i; for (i = 780; i < 794; i++) Y5625[i] = 1067;};
	{long i; for (i = 1094; i < 1096; i++) Y5625[i] = 1067;};
}

char *(*R5626[297])();
void R5626_init () {
	R5626[0] = (char *(*)()) F841_6562;
	R5626[1] = (char *(*)()) F842_6562;
	R5626[2] = (char *(*)()) F843_6562_5626_4;
	R5626[3] = (char *(*)()) F844_6562_5626_4;
	R5626[4] = (char *(*)()) F845_6562_5626_4;
	R5626[5] = (char *(*)()) F846_6562;
	R5626[6] = (char *(*)()) F841_6562;
	R5626[7] = (char *(*)()) F842_6562;
	R5626[8] = (char *(*)()) F841_6562;
	R5626[293] = (char *(*)()) F1134_10049_5626_4;
	R5626[296] = (char *(*)()) F1137_10214_5626_4;
}
static void F843_6562_5626_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F843_6562(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F844_6562_5626_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F844_6562(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F845_6562_5626_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F845_6562(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1134_10049_5626_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1134_10049(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1137_10214_5626_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1137_10214(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5627[777])();
void R5627_init () {
	R5627[0] = (char *(*)()) F693_6124;
	R5627[1] = (char *(*)()) F694_6124_5627_1;
	R5627[2] = (char *(*)()) F695_6124_5627_1;
	R5627[3] = (char *(*)()) F696_6170;
	R5627[4] = (char *(*)()) F697_6188;
	R5627[5] = (char *(*)()) F698_6188_5627_1;
	R5627[6] = (char *(*)()) F699_6188_5627_1;
	R5627[39] = (char *(*)()) F549_5939_5627_1;
	R5627[44] = (char *(*)()) F549_5939_5627_1;
	R5627[157] = (char *(*)()) F850_6646;
	R5627[158] = (char *(*)()) F851_6646_5627_1;
	R5627[159] = (char *(*)()) F852_6646_5627_1;
	R5627[160] = (char *(*)()) F853_6646_5627_1;
	R5627[161] = (char *(*)()) F854_6646_5627_1;
	R5627[162] = (char *(*)()) F855_6646_5627_1;
	R5627[163] = (char *(*)()) F856_6646_5627_1;
	R5627[164] = (char *(*)()) F857_6646_5627_1;
	R5627[165] = (char *(*)()) F858_6646_5627_1;
	R5627[166] = (char *(*)()) F859_6646_5627_1;
	R5627[167] = (char *(*)()) F860_6646_5627_1;
	R5627[168] = (char *(*)()) F861_6646_5627_1;
	R5627[169] = (char *(*)()) F850_6646;
	R5627[170] = (char *(*)()) F854_6646_5627_1;
	R5627[171] = (char *(*)()) F852_6646_5627_1;
	R5627[176] = (char *(*)()) F850_6646;
	R5627[177] = (char *(*)()) F852_6646_5627_1;
	{long i; for (i = 178; i < 182; i++) R5627[i] = (char *(*)()) F850_6646;}
	{long i; for (i = 187; i < 189; i++) R5627[i] = (char *(*)()) F850_6646;}
	{long i; for (i = 192; i < 194; i++) R5627[i] = (char *(*)()) F850_6646;}
	{long i; for (i = 196; i < 201; i++) R5627[i] = (char *(*)()) F850_6646;}
	{long i; for (i = 309; i < 311; i++) R5627[i] = (char *(*)()) F1001_7880_5627_1;}
	{long i; for (i = 525; i < 528; i++) R5627[i] = (char *(*)()) F1210_10935;}
	R5627[568] = (char *(*)()) F1210_10935;
	R5627[575] = (char *(*)()) F1210_10935;
	{long i; for (i = 578; i < 580; i++) R5627[i] = (char *(*)()) F1210_10935;}
	R5627[776] = (char *(*)()) F1001_7880_5627_1;
}
static EIF_REFERENCE F694_6124_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F694_6124(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F695_6124_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F695_6124(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F698_6188_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F698_6188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F699_6188_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F699_6188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F549_5939_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F549_5939(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_6646_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F851_6646(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1079, 0x00).id, 1079, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_6646_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F852_6646(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F853_6646_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F853_6646(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1076, 0x00).id, 1076, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F854_6646_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F854_6646(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F855_6646_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F855_6646(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F856_6646_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F856_6646(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_6646_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F857_6646(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_6646_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F858_6646(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_6646_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F859_6646(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F860_6646_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F860_6646(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F861_6646_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F861_6646(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1001_7880_5627_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1001_7880(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y5627_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype123[] = {0xFF01,1179,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype124[] = {0xFF01,1123,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype125[] = {0xFF01,1123,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype126[] = {0xFF01,1123,0xFFF9,1,1049,0xFF01,0,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype127[] = {0xFF01,1123,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype128[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,1067,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype129[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1248,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype130[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,1067,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype131[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype132[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1254,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype133[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1186,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype134[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,1009,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype135[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1249,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype136[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,1067,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype137[] = {0xFF01,1123,0xFF01,0xFFF9,4,1049,1067,1067,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype138[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1467,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype139[] = {0xFF01,1123,0xFF01,0xFFF9,5,1049,1079,1067,1067,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype140[] = {0xFF01,1123,0xFF01,0xFFF9,1,1049,0xFF01,1133,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype141[] = {0xFF01,1123,0xFF01,0xFFF9,2,1049,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype142[] = {0xFF01,1123,0xFF01,0xFFF9,7,1049,1067,1067,1052,1052,1052,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype143[] = {0xFF01,1123,0xFF01,0xFFF9,3,1049,1067,1067,1009,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype144[] = {0xFF01,1123,0xFF01,0xFFF9,8,1049,1067,1067,1067,1052,1052,1052,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype145[] = {0xFF01,1123,0xFF01,0xFFF9,0,1049,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype147[] = {0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype148[] = {0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype149[] = {0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype150[] = {0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype151[] = {0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype152[] = {0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype153[] = {0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype154[] = {0xFF01,1133,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype156[] = {0xFF01,1248,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype157[] = {0xFF01,1250,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype158[] = {0xFF01,1263,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype159[] = {0xFF01,1263,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype160[] = {0xFF01,1263,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype161[] = {0xFF01,1263,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype162[] = {0xFF01,1254,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype163[] = {0xFF01,1254,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype164[] = {0xFF01,1254,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype165[] = {0xFF01,1249,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype166[] = {0xFF01,1249,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype167[] = {0xFF01,1249,0xFFFF};
static EIF_TYPE_INDEX Y5627_pgtype168[] = {0xFF01,1249,0xFFFF};
EIF_TYPE_INDEX *Y5627_gen_type [959];
EIF_TYPE_INDEX Y5627 [959];
void Y5627_init (void)
{
	egc_routines_types [5627] = Y5627;
	egc_routines_gen_types [5627] = Y5627_gen_type;
	egc_routines_offset [5627] = 510;
	Y5627_gen_type [0] = Y5627_pgtype0;
	Y5627_gen_type [1] = Y5627_pgtype1;
	Y5627_gen_type [2] = Y5627_pgtype2;
	Y5627_gen_type [3] = Y5627_pgtype3;
	Y5627_gen_type [4] = Y5627_pgtype4;
	Y5627_gen_type [5] = Y5627_pgtype5;
	Y5627_gen_type [6] = Y5627_pgtype6;
	Y5627_gen_type [7] = Y5627_pgtype7;
	Y5627_gen_type [8] = Y5627_pgtype8;
	Y5627_gen_type [9] = Y5627_pgtype9;
	Y5627_gen_type [10] = Y5627_pgtype10;
	Y5627_gen_type [11] = Y5627_pgtype11;
	Y5627_gen_type [12] = Y5627_pgtype12;
	Y5627_gen_type [13] = Y5627_pgtype13;
	Y5627_gen_type [14] = Y5627_pgtype14;
	Y5627_gen_type [15] = Y5627_pgtype15;
	Y5627_gen_type [16] = Y5627_pgtype16;
	Y5627_gen_type [17] = Y5627_pgtype17;
	Y5627_gen_type [18] = Y5627_pgtype18;
	Y5627_gen_type [19] = Y5627_pgtype19;
	Y5627_gen_type [20] = Y5627_pgtype20;
	Y5627_gen_type [21] = Y5627_pgtype21;
	Y5627_gen_type [22] = Y5627_pgtype22;
	Y5627_gen_type [23] = Y5627_pgtype23;
	Y5627_gen_type [38] = Y5627_pgtype24;
	Y5627_gen_type [75] = Y5627_pgtype25;
	Y5627_gen_type [76] = Y5627_pgtype26;
	Y5627_gen_type [77] = Y5627_pgtype27;
	Y5627_gen_type [78] = Y5627_pgtype28;
	Y5627_gen_type [79] = Y5627_pgtype29;
	Y5627_gen_type [80] = Y5627_pgtype30;
	Y5627_gen_type [81] = Y5627_pgtype31;
	Y5627_gen_type [82] = Y5627_pgtype32;
	Y5627_gen_type [83] = Y5627_pgtype33;
	Y5627_gen_type [84] = Y5627_pgtype34;
	Y5627_gen_type [85] = Y5627_pgtype35;
	Y5627_gen_type [86] = Y5627_pgtype36;
	Y5627_gen_type [87] = Y5627_pgtype37;
	Y5627_gen_type [88] = Y5627_pgtype38;
	Y5627_gen_type [89] = Y5627_pgtype39;
	Y5627_gen_type [90] = Y5627_pgtype40;
	Y5627_gen_type [91] = Y5627_pgtype41;
	Y5627_gen_type [92] = Y5627_pgtype42;
	Y5627_gen_type [93] = Y5627_pgtype43;
	Y5627_gen_type [94] = Y5627_pgtype44;
	Y5627_gen_type [95] = Y5627_pgtype45;
	Y5627_gen_type [134] = Y5627_pgtype46;
	Y5627_gen_type [135] = Y5627_pgtype47;
	Y5627_gen_type [136] = Y5627_pgtype48;
	Y5627_gen_type [137] = Y5627_pgtype49;
	Y5627_gen_type [138] = Y5627_pgtype50;
	Y5627_gen_type [139] = Y5627_pgtype51;
	Y5627_gen_type [140] = Y5627_pgtype52;
	Y5627_gen_type [141] = Y5627_pgtype53;
	Y5627_gen_type [142] = Y5627_pgtype54;
	Y5627_gen_type [143] = Y5627_pgtype55;
	Y5627_gen_type [144] = Y5627_pgtype56;
	Y5627_gen_type [145] = Y5627_pgtype57;
	Y5627_gen_type [146] = Y5627_pgtype58;
	Y5627_gen_type [147] = Y5627_pgtype59;
	Y5627_gen_type [148] = Y5627_pgtype60;
	Y5627_gen_type [149] = Y5627_pgtype61;
	Y5627_gen_type [150] = Y5627_pgtype62;
	Y5627_gen_type [151] = Y5627_pgtype63;
	Y5627_gen_type [152] = Y5627_pgtype64;
	Y5627_gen_type [153] = Y5627_pgtype65;
	Y5627_gen_type [154] = Y5627_pgtype66;
	Y5627_gen_type [155] = Y5627_pgtype67;
	Y5627_gen_type [156] = Y5627_pgtype68;
	Y5627_gen_type [157] = Y5627_pgtype69;
	Y5627_gen_type [158] = Y5627_pgtype70;
	Y5627_gen_type [159] = Y5627_pgtype71;
	Y5627_gen_type [160] = Y5627_pgtype72;
	Y5627_gen_type [161] = Y5627_pgtype73;
	Y5627_gen_type [162] = Y5627_pgtype74;
	Y5627_gen_type [163] = Y5627_pgtype75;
	Y5627_gen_type [164] = Y5627_pgtype76;
	Y5627_gen_type [165] = Y5627_pgtype77;
	Y5627_gen_type [166] = Y5627_pgtype78;
	Y5627_gen_type [167] = Y5627_pgtype79;
	Y5627_gen_type [168] = Y5627_pgtype80;
	Y5627_gen_type [169] = Y5627_pgtype81;
	Y5627_gen_type [170] = Y5627_pgtype82;
	Y5627_gen_type [171] = Y5627_pgtype83;
	Y5627_gen_type [172] = Y5627_pgtype84;
	Y5627_gen_type [173] = Y5627_pgtype85;
	Y5627_gen_type [174] = Y5627_pgtype86;
	Y5627_gen_type [175] = Y5627_pgtype87;
	Y5627_gen_type [176] = Y5627_pgtype88;
	Y5627_gen_type [177] = Y5627_pgtype89;
	Y5627_gen_type [178] = Y5627_pgtype90;
	Y5627_gen_type [179] = Y5627_pgtype91;
	Y5627_gen_type [180] = Y5627_pgtype92;
	Y5627_gen_type [181] = Y5627_pgtype93;
	Y5627_gen_type [182] = Y5627_pgtype94;
	Y5627_gen_type [183] = Y5627_pgtype95;
	Y5627_gen_type [184] = Y5627_pgtype96;
	Y5627_gen_type [185] = Y5627_pgtype97;
	Y5627_gen_type [186] = Y5627_pgtype98;
	Y5627_gen_type [187] = Y5627_pgtype99;
	Y5627_gen_type [188] = Y5627_pgtype100;
	Y5627_gen_type [329] = Y5627_pgtype101;
	Y5627_gen_type [339] = Y5627_pgtype102;
	Y5627_gen_type [340] = Y5627_pgtype103;
	Y5627_gen_type [341] = Y5627_pgtype104;
	Y5627_gen_type [342] = Y5627_pgtype105;
	Y5627_gen_type [343] = Y5627_pgtype106;
	Y5627_gen_type [344] = Y5627_pgtype107;
	Y5627_gen_type [345] = Y5627_pgtype108;
	Y5627_gen_type [346] = Y5627_pgtype109;
	Y5627_gen_type [347] = Y5627_pgtype110;
	Y5627_gen_type [348] = Y5627_pgtype111;
	Y5627_gen_type [349] = Y5627_pgtype112;
	Y5627_gen_type [350] = Y5627_pgtype113;
	Y5627_gen_type [351] = Y5627_pgtype114;
	Y5627_gen_type [352] = Y5627_pgtype115;
	Y5627_gen_type [353] = Y5627_pgtype116;
	Y5627_gen_type [354] = Y5627_pgtype117;
	Y5627_gen_type [355] = Y5627_pgtype118;
	Y5627_gen_type [356] = Y5627_pgtype119;
	Y5627_gen_type [357] = Y5627_pgtype120;
	Y5627_gen_type [358] = Y5627_pgtype121;
	Y5627_gen_type [359] = Y5627_pgtype122;
	Y5627_gen_type [360] = Y5627_pgtype123;
	Y5627_gen_type [361] = Y5627_pgtype124;
	Y5627_gen_type [362] = Y5627_pgtype125;
	Y5627_gen_type [363] = Y5627_pgtype126;
	Y5627_gen_type [364] = Y5627_pgtype127;
	Y5627_gen_type [365] = Y5627_pgtype128;
	Y5627_gen_type [366] = Y5627_pgtype129;
	Y5627_gen_type [367] = Y5627_pgtype130;
	Y5627_gen_type [368] = Y5627_pgtype131;
	Y5627_gen_type [369] = Y5627_pgtype132;
	Y5627_gen_type [370] = Y5627_pgtype133;
	Y5627_gen_type [371] = Y5627_pgtype134;
	Y5627_gen_type [372] = Y5627_pgtype135;
	Y5627_gen_type [373] = Y5627_pgtype136;
	Y5627_gen_type [374] = Y5627_pgtype137;
	Y5627_gen_type [375] = Y5627_pgtype138;
	Y5627_gen_type [376] = Y5627_pgtype139;
	Y5627_gen_type [377] = Y5627_pgtype140;
	Y5627_gen_type [378] = Y5627_pgtype141;
	Y5627_gen_type [379] = Y5627_pgtype142;
	Y5627_gen_type [380] = Y5627_pgtype143;
	Y5627_gen_type [381] = Y5627_pgtype144;
	Y5627_gen_type [382] = Y5627_pgtype145;
	Y5627_gen_type [699] = Y5627_pgtype146;
	Y5627_gen_type [703] = Y5627_pgtype147;
	Y5627_gen_type [704] = Y5627_pgtype148;
	Y5627_gen_type [705] = Y5627_pgtype149;
	Y5627_gen_type [706] = Y5627_pgtype150;
	Y5627_gen_type [707] = Y5627_pgtype151;
	Y5627_gen_type [708] = Y5627_pgtype152;
	Y5627_gen_type [709] = Y5627_pgtype153;
	Y5627_gen_type [738] = Y5627_pgtype154;
	Y5627_gen_type [748] = Y5627_pgtype155;
	Y5627_gen_type [749] = Y5627_pgtype156;
	Y5627_gen_type [750] = Y5627_pgtype157;
	Y5627_gen_type [751] = Y5627_pgtype158;
	Y5627_gen_type [752] = Y5627_pgtype159;
	Y5627_gen_type [753] = Y5627_pgtype160;
	Y5627_gen_type [754] = Y5627_pgtype161;
	Y5627_gen_type [755] = Y5627_pgtype162;
	Y5627_gen_type [756] = Y5627_pgtype163;
	Y5627_gen_type [757] = Y5627_pgtype164;
	Y5627_gen_type [758] = Y5627_pgtype165;
	Y5627_gen_type [759] = Y5627_pgtype166;
	Y5627_gen_type [760] = Y5627_pgtype167;
	Y5627_gen_type [761] = Y5627_pgtype168;
	Y5627[221] = 1067;
	Y5627[226] = 1067;
	Y5627[360] = 1179;
	{long i; for (i = 361; i < 383; i++) Y5627[i] = 1123;};
	{long i; for (i = 490; i < 493; i++) Y5627[i] = 1058;};
	{long i; for (i = 703; i < 710; i++) Y5627[i] = 1211;};
	Y5627[738] = 1133;
	Y5627[749] = 1248;
	Y5627[750] = 1250;
	{long i; for (i = 751; i < 755; i++) Y5627[i] = 1263;};
	{long i; for (i = 755; i < 758; i++) Y5627[i] = 1254;};
	{long i; for (i = 758; i < 762; i++) Y5627[i] = 1249;};
	Y5627[958] = 1058;
}

char *(*R5631[580])();
void R5631_init () {
	R5631[0] = (char *(*)()) F693_6152;
	R5631[1] = (char *(*)()) F694_6152_5631_4;
	R5631[2] = (char *(*)()) F695_6152_5631_4;
	{long i; for (i = 3; i < 5; i++) R5631[i] = (char *(*)()) F693_6152;}
	R5631[5] = (char *(*)()) F694_6152_5631_4;
	R5631[6] = (char *(*)()) F695_6152_5631_4;
	R5631[157] = (char *(*)()) F850_6685;
	R5631[158] = (char *(*)()) F851_6685_5631_4;
	R5631[159] = (char *(*)()) F852_6685_5631_4;
	R5631[160] = (char *(*)()) F853_6685_5631_4;
	R5631[161] = (char *(*)()) F854_6685_5631_4;
	R5631[162] = (char *(*)()) F855_6685_5631_4;
	R5631[163] = (char *(*)()) F856_6685_5631_4;
	R5631[164] = (char *(*)()) F857_6685_5631_4;
	R5631[165] = (char *(*)()) F858_6685_5631_4;
	R5631[166] = (char *(*)()) F859_6685_5631_4;
	R5631[167] = (char *(*)()) F860_6685_5631_4;
	R5631[168] = (char *(*)()) F861_6685_5631_4;
	R5631[169] = (char *(*)()) F850_6685;
	R5631[170] = (char *(*)()) F854_6685_5631_4;
	R5631[171] = (char *(*)()) F852_6685_5631_4;
	R5631[176] = (char *(*)()) F865_6729;
	R5631[177] = (char *(*)()) F866_6729_5631_4;
	{long i; for (i = 178; i < 182; i++) R5631[i] = (char *(*)()) F865_6729;}
	{long i; for (i = 187; i < 189; i++) R5631[i] = (char *(*)()) F865_6729;}
	{long i; for (i = 192; i < 194; i++) R5631[i] = (char *(*)()) F865_6729;}
	{long i; for (i = 196; i < 201; i++) R5631[i] = (char *(*)()) F865_6729;}
	{long i; for (i = 525; i < 528; i++) R5631[i] = (char *(*)()) F1210_10972;}
	R5631[568] = (char *(*)()) F1210_10972;
	R5631[575] = (char *(*)()) F1210_10972;
	{long i; for (i = 578; i < 580; i++) R5631[i] = (char *(*)()) F1210_10972;}
}
static void F694_6152_5631_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F694_6152(Current, *(EIF_BOOLEAN *)arg1);
}
static void F695_6152_5631_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F695_6152(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F851_6685_5631_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F851_6685(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F852_6685_5631_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F852_6685(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F853_6685_5631_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F853_6685(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F854_6685_5631_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F854_6685(Current, *(EIF_BOOLEAN *)arg1);
}
static void F855_6685_5631_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F855_6685(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F856_6685_5631_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F856_6685(Current, *(EIF_POINTER *)arg1);
}
static void F857_6685_5631_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F857_6685(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F858_6685_5631_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F858_6685(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F859_6685_5631_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F859_6685(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F860_6685_5631_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F860_6685(Current, *(EIF_REAL_32 *)arg1);
}
static void F861_6685_5631_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F861_6685(Current, *(EIF_REAL_64 *)arg1);
}
static void F866_6729_5631_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F866_6729(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5632[580])();
void R5632_init () {
	R5632[0] = (char *(*)()) F693_6155;
	R5632[1] = (char *(*)()) F694_6155;
	R5632[2] = (char *(*)()) F695_6155;
	R5632[3] = (char *(*)()) F693_6156;
	R5632[4] = (char *(*)()) F697_6192;
	R5632[5] = (char *(*)()) F698_6192;
	R5632[6] = (char *(*)()) F699_6192;
	R5632[157] = (char *(*)()) F850_6695;
	R5632[158] = (char *(*)()) F851_6695;
	R5632[159] = (char *(*)()) F852_6695;
	R5632[160] = (char *(*)()) F853_6695;
	R5632[161] = (char *(*)()) F854_6695;
	R5632[162] = (char *(*)()) F855_6695;
	R5632[163] = (char *(*)()) F856_6695;
	R5632[164] = (char *(*)()) F857_6695;
	R5632[165] = (char *(*)()) F858_6695;
	R5632[166] = (char *(*)()) F859_6695;
	R5632[167] = (char *(*)()) F860_6695;
	R5632[168] = (char *(*)()) F861_6695;
	R5632[169] = (char *(*)()) F862_6711;
	R5632[170] = (char *(*)()) F863_6711;
	R5632[171] = (char *(*)()) F864_6711;
	R5632[176] = (char *(*)()) F865_6730;
	R5632[177] = (char *(*)()) F866_6730;
	{long i; for (i = 178; i < 182; i++) R5632[i] = (char *(*)()) F865_6730;}
	{long i; for (i = 187; i < 189; i++) R5632[i] = (char *(*)()) F865_6730;}
	{long i; for (i = 192; i < 194; i++) R5632[i] = (char *(*)()) F865_6730;}
	{long i; for (i = 196; i < 201; i++) R5632[i] = (char *(*)()) F865_6730;}
	{long i; for (i = 525; i < 528; i++) R5632[i] = (char *(*)()) F1210_10963;}
	R5632[568] = (char *(*)()) F1210_10963;
	R5632[575] = (char *(*)()) F1210_10963;
	{long i; for (i = 578; i < 580; i++) R5632[i] = (char *(*)()) F1210_10963;}
}

char *(*R5633[580])();
void R5633_init () {
	R5633[0] = (char *(*)()) F693_6128;
	R5633[1] = (char *(*)()) F694_6128;
	R5633[2] = (char *(*)()) F695_6128;
	{long i; for (i = 3; i < 5; i++) R5633[i] = (char *(*)()) F693_6128;}
	R5633[5] = (char *(*)()) F694_6128;
	R5633[6] = (char *(*)()) F695_6128;
	R5633[157] = (char *(*)()) F850_6652;
	R5633[158] = (char *(*)()) F851_6652;
	R5633[159] = (char *(*)()) F852_6652;
	R5633[160] = (char *(*)()) F853_6652;
	R5633[161] = (char *(*)()) F854_6652;
	R5633[162] = (char *(*)()) F855_6652;
	R5633[163] = (char *(*)()) F856_6652;
	R5633[164] = (char *(*)()) F857_6652;
	R5633[165] = (char *(*)()) F858_6652;
	R5633[166] = (char *(*)()) F859_6652;
	R5633[167] = (char *(*)()) F860_6652;
	R5633[168] = (char *(*)()) F861_6652;
	R5633[169] = (char *(*)()) F850_6652;
	R5633[170] = (char *(*)()) F854_6652;
	R5633[171] = (char *(*)()) F852_6652;
	R5633[176] = (char *(*)()) F850_6652;
	R5633[177] = (char *(*)()) F852_6652;
	{long i; for (i = 178; i < 182; i++) R5633[i] = (char *(*)()) F850_6652;}
	{long i; for (i = 187; i < 189; i++) R5633[i] = (char *(*)()) F850_6652;}
	{long i; for (i = 192; i < 194; i++) R5633[i] = (char *(*)()) F850_6652;}
	{long i; for (i = 196; i < 201; i++) R5633[i] = (char *(*)()) F850_6652;}
	{long i; for (i = 525; i < 528; i++) R5633[i] = (char *(*)()) F1210_10937;}
	R5633[568] = (char *(*)()) F1210_10937;
	R5633[575] = (char *(*)()) F1210_10937;
	{long i; for (i = 578; i < 580; i++) R5633[i] = (char *(*)()) F1210_10937;}
}

static EIF_TYPE_INDEX Y5633_pgtype0[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype1[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype2[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype3[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype4[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype5[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype6[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype7[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype8[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype9[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype10[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype11[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype12[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype13[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype14[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype15[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype16[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype17[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype18[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype19[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype20[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype21[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype22[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype23[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype24[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype25[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype26[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype27[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype28[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype29[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype30[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype31[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype32[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype33[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype34[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype35[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype36[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype37[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype38[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype39[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype40[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype41[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype42[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype43[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype44[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype45[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype46[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype47[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype48[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype49[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype50[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype51[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype52[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype53[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype54[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype55[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype56[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype57[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype58[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype59[] = {0xFF01,293,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype60[] = {0xFF01,295,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype61[] = {0xFF01,296,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype62[] = {0xFF01,297,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype63[] = {0xFF01,295,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype64[] = {0xFF01,295,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype65[] = {0xFF01,296,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype66[] = {0xFF01,297,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype67[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype68[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype69[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype70[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype71[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype72[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype73[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype74[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype75[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype76[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype77[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype78[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype79[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype80[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype81[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype82[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype83[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype84[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype85[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype86[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype87[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype88[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype89[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype90[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype91[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype92[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype93[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype94[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype95[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype96[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype97[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype98[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype99[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype100[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype101[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype102[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype103[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype104[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype105[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype106[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype107[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype108[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype109[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype110[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype111[] = {0xFF01,294,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype112[] = {0xFF01,294,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype113[] = {0xFF01,294,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype114[] = {0xFF01,294,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype115[] = {0xFF01,294,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype116[] = {0xFF01,294,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype117[] = {0xFF01,294,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype118[] = {0xFF01,294,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype119[] = {0xFF01,299,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype120[] = {0xFF01,294,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype121[] = {0xFF01,294,0xFF01,1248,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype122[] = {0xFF01,294,0xFF01,1250,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype123[] = {0xFF01,294,0xFF01,1263,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype124[] = {0xFF01,294,0xFF01,1263,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype125[] = {0xFF01,294,0xFF01,1263,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype126[] = {0xFF01,294,0xFF01,1263,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype127[] = {0xFF01,294,0xFF01,1254,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype128[] = {0xFF01,294,0xFF01,1254,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype129[] = {0xFF01,294,0xFF01,1254,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype130[] = {0xFF01,294,0xFF01,1249,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype131[] = {0xFF01,294,0xFF01,1249,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype132[] = {0xFF01,294,0xFF01,1249,0xFFFF};
static EIF_TYPE_INDEX Y5633_pgtype133[] = {0xFF01,294,0xFF01,1249,0xFFFF};
EIF_TYPE_INDEX *Y5633_gen_type [750];
EIF_TYPE_INDEX Y5633 [750];
void Y5633_init (void)
{
	egc_routines_types [5633] = Y5633;
	egc_routines_gen_types [5633] = Y5633_gen_type;
	egc_routines_offset [5633] = 522;
	Y5633_gen_type [0] = Y5633_pgtype0;
	Y5633_gen_type [1] = Y5633_pgtype1;
	Y5633_gen_type [2] = Y5633_pgtype2;
	Y5633_gen_type [3] = Y5633_pgtype3;
	Y5633_gen_type [4] = Y5633_pgtype4;
	Y5633_gen_type [5] = Y5633_pgtype5;
	Y5633_gen_type [6] = Y5633_pgtype6;
	Y5633_gen_type [7] = Y5633_pgtype7;
	Y5633_gen_type [8] = Y5633_pgtype8;
	Y5633_gen_type [9] = Y5633_pgtype9;
	Y5633_gen_type [10] = Y5633_pgtype10;
	Y5633_gen_type [11] = Y5633_pgtype11;
	Y5633_gen_type [122] = Y5633_pgtype12;
	Y5633_gen_type [123] = Y5633_pgtype13;
	Y5633_gen_type [124] = Y5633_pgtype14;
	Y5633_gen_type [125] = Y5633_pgtype15;
	Y5633_gen_type [126] = Y5633_pgtype16;
	Y5633_gen_type [127] = Y5633_pgtype17;
	Y5633_gen_type [128] = Y5633_pgtype18;
	Y5633_gen_type [129] = Y5633_pgtype19;
	Y5633_gen_type [130] = Y5633_pgtype20;
	Y5633_gen_type [131] = Y5633_pgtype21;
	Y5633_gen_type [132] = Y5633_pgtype22;
	Y5633_gen_type [133] = Y5633_pgtype23;
	Y5633_gen_type [134] = Y5633_pgtype24;
	Y5633_gen_type [135] = Y5633_pgtype25;
	Y5633_gen_type [136] = Y5633_pgtype26;
	Y5633_gen_type [137] = Y5633_pgtype27;
	Y5633_gen_type [138] = Y5633_pgtype28;
	Y5633_gen_type [139] = Y5633_pgtype29;
	Y5633_gen_type [140] = Y5633_pgtype30;
	Y5633_gen_type [141] = Y5633_pgtype31;
	Y5633_gen_type [142] = Y5633_pgtype32;
	Y5633_gen_type [143] = Y5633_pgtype33;
	Y5633_gen_type [144] = Y5633_pgtype34;
	Y5633_gen_type [145] = Y5633_pgtype35;
	Y5633_gen_type [146] = Y5633_pgtype36;
	Y5633_gen_type [147] = Y5633_pgtype37;
	Y5633_gen_type [148] = Y5633_pgtype38;
	Y5633_gen_type [149] = Y5633_pgtype39;
	Y5633_gen_type [150] = Y5633_pgtype40;
	Y5633_gen_type [151] = Y5633_pgtype41;
	Y5633_gen_type [152] = Y5633_pgtype42;
	Y5633_gen_type [153] = Y5633_pgtype43;
	Y5633_gen_type [154] = Y5633_pgtype44;
	Y5633_gen_type [155] = Y5633_pgtype45;
	Y5633_gen_type [156] = Y5633_pgtype46;
	Y5633_gen_type [157] = Y5633_pgtype47;
	Y5633_gen_type [158] = Y5633_pgtype48;
	Y5633_gen_type [159] = Y5633_pgtype49;
	Y5633_gen_type [160] = Y5633_pgtype50;
	Y5633_gen_type [161] = Y5633_pgtype51;
	Y5633_gen_type [162] = Y5633_pgtype52;
	Y5633_gen_type [163] = Y5633_pgtype53;
	Y5633_gen_type [164] = Y5633_pgtype54;
	Y5633_gen_type [165] = Y5633_pgtype55;
	Y5633_gen_type [166] = Y5633_pgtype56;
	Y5633_gen_type [167] = Y5633_pgtype57;
	Y5633_gen_type [168] = Y5633_pgtype58;
	Y5633_gen_type [169] = Y5633_pgtype59;
	Y5633_gen_type [170] = Y5633_pgtype60;
	Y5633_gen_type [171] = Y5633_pgtype61;
	Y5633_gen_type [172] = Y5633_pgtype62;
	Y5633_gen_type [173] = Y5633_pgtype63;
	Y5633_gen_type [174] = Y5633_pgtype64;
	Y5633_gen_type [175] = Y5633_pgtype65;
	Y5633_gen_type [176] = Y5633_pgtype66;
	Y5633_gen_type [327] = Y5633_pgtype67;
	Y5633_gen_type [328] = Y5633_pgtype68;
	Y5633_gen_type [329] = Y5633_pgtype69;
	Y5633_gen_type [330] = Y5633_pgtype70;
	Y5633_gen_type [331] = Y5633_pgtype71;
	Y5633_gen_type [332] = Y5633_pgtype72;
	Y5633_gen_type [333] = Y5633_pgtype73;
	Y5633_gen_type [334] = Y5633_pgtype74;
	Y5633_gen_type [335] = Y5633_pgtype75;
	Y5633_gen_type [336] = Y5633_pgtype76;
	Y5633_gen_type [337] = Y5633_pgtype77;
	Y5633_gen_type [338] = Y5633_pgtype78;
	Y5633_gen_type [339] = Y5633_pgtype79;
	Y5633_gen_type [340] = Y5633_pgtype80;
	Y5633_gen_type [341] = Y5633_pgtype81;
	Y5633_gen_type [342] = Y5633_pgtype82;
	Y5633_gen_type [343] = Y5633_pgtype83;
	Y5633_gen_type [344] = Y5633_pgtype84;
	Y5633_gen_type [345] = Y5633_pgtype85;
	Y5633_gen_type [346] = Y5633_pgtype86;
	Y5633_gen_type [347] = Y5633_pgtype87;
	Y5633_gen_type [348] = Y5633_pgtype88;
	Y5633_gen_type [349] = Y5633_pgtype89;
	Y5633_gen_type [350] = Y5633_pgtype90;
	Y5633_gen_type [351] = Y5633_pgtype91;
	Y5633_gen_type [352] = Y5633_pgtype92;
	Y5633_gen_type [353] = Y5633_pgtype93;
	Y5633_gen_type [354] = Y5633_pgtype94;
	Y5633_gen_type [355] = Y5633_pgtype95;
	Y5633_gen_type [356] = Y5633_pgtype96;
	Y5633_gen_type [357] = Y5633_pgtype97;
	Y5633_gen_type [358] = Y5633_pgtype98;
	Y5633_gen_type [359] = Y5633_pgtype99;
	Y5633_gen_type [360] = Y5633_pgtype100;
	Y5633_gen_type [361] = Y5633_pgtype101;
	Y5633_gen_type [362] = Y5633_pgtype102;
	Y5633_gen_type [363] = Y5633_pgtype103;
	Y5633_gen_type [364] = Y5633_pgtype104;
	Y5633_gen_type [365] = Y5633_pgtype105;
	Y5633_gen_type [366] = Y5633_pgtype106;
	Y5633_gen_type [367] = Y5633_pgtype107;
	Y5633_gen_type [368] = Y5633_pgtype108;
	Y5633_gen_type [369] = Y5633_pgtype109;
	Y5633_gen_type [370] = Y5633_pgtype110;
	Y5633_gen_type [687] = Y5633_pgtype111;
	Y5633_gen_type [691] = Y5633_pgtype112;
	Y5633_gen_type [692] = Y5633_pgtype113;
	Y5633_gen_type [693] = Y5633_pgtype114;
	Y5633_gen_type [694] = Y5633_pgtype115;
	Y5633_gen_type [695] = Y5633_pgtype116;
	Y5633_gen_type [696] = Y5633_pgtype117;
	Y5633_gen_type [697] = Y5633_pgtype118;
	Y5633_gen_type [726] = Y5633_pgtype119;
	Y5633_gen_type [736] = Y5633_pgtype120;
	Y5633_gen_type [737] = Y5633_pgtype121;
	Y5633_gen_type [738] = Y5633_pgtype122;
	Y5633_gen_type [739] = Y5633_pgtype123;
	Y5633_gen_type [740] = Y5633_pgtype124;
	Y5633_gen_type [741] = Y5633_pgtype125;
	Y5633_gen_type [742] = Y5633_pgtype126;
	Y5633_gen_type [743] = Y5633_pgtype127;
	Y5633_gen_type [744] = Y5633_pgtype128;
	Y5633_gen_type [745] = Y5633_pgtype129;
	Y5633_gen_type [746] = Y5633_pgtype130;
	Y5633_gen_type [747] = Y5633_pgtype131;
	Y5633_gen_type [748] = Y5633_pgtype132;
	Y5633_gen_type [749] = Y5633_pgtype133;
	{long i; for (i = 0; i < 12; i++) Y5633[i] = 293;};
	{long i; for (i = 122; i < 170; i++) Y5633[i] = 293;};
	Y5633[170] = 295;
	Y5633[171] = 296;
	Y5633[172] = 297;
	{long i; for (i = 173; i < 175; i++) Y5633[i] = 295;};
	Y5633[175] = 296;
	Y5633[176] = 297;
	{long i; for (i = 327; i < 371; i++) Y5633[i] = 299;};
	Y5633[687] = 294;
	{long i; for (i = 691; i < 698; i++) Y5633[i] = 294;};
	Y5633[726] = 299;
	{long i; for (i = 736; i < 750; i++) Y5633[i] = 294;};
}

char *(*R5635[580])();
void R5635_init () {
	R5635[0] = (char *(*)()) F693_6147;
	R5635[1] = (char *(*)()) F694_6147;
	R5635[2] = (char *(*)()) F695_6147;
	{long i; for (i = 3; i < 5; i++) R5635[i] = (char *(*)()) F693_6147;}
	R5635[5] = (char *(*)()) F694_6147;
	R5635[6] = (char *(*)()) F695_6147;
	R5635[157] = (char *(*)()) F850_6677;
	R5635[158] = (char *(*)()) F851_6677;
	R5635[159] = (char *(*)()) F852_6677;
	R5635[160] = (char *(*)()) F853_6677;
	R5635[161] = (char *(*)()) F854_6677;
	R5635[162] = (char *(*)()) F855_6677;
	R5635[163] = (char *(*)()) F856_6677;
	R5635[164] = (char *(*)()) F857_6677;
	R5635[165] = (char *(*)()) F858_6677;
	R5635[166] = (char *(*)()) F859_6677;
	R5635[167] = (char *(*)()) F860_6677;
	R5635[168] = (char *(*)()) F861_6677;
	R5635[169] = (char *(*)()) F850_6677;
	R5635[170] = (char *(*)()) F854_6677;
	R5635[171] = (char *(*)()) F852_6677;
	R5635[176] = (char *(*)()) F850_6677;
	R5635[177] = (char *(*)()) F852_6677;
	{long i; for (i = 178; i < 182; i++) R5635[i] = (char *(*)()) F850_6677;}
	{long i; for (i = 187; i < 189; i++) R5635[i] = (char *(*)()) F850_6677;}
	{long i; for (i = 192; i < 194; i++) R5635[i] = (char *(*)()) F850_6677;}
	{long i; for (i = 196; i < 201; i++) R5635[i] = (char *(*)()) F850_6677;}
	{long i; for (i = 525; i < 528; i++) R5635[i] = (char *(*)()) F1210_10949;}
	R5635[568] = (char *(*)()) F1210_10949;
	R5635[575] = (char *(*)()) F1210_10949;
	{long i; for (i = 578; i < 580; i++) R5635[i] = (char *(*)()) F1210_10949;}
}

char *(*R5637[6])();
void R5637_init () {
	R5637[0] = (char *(*)()) F732_6301;
	R5637[5] = (char *(*)()) F737_6366;
}

char *(*R5639[827])();
void R5639_init () {
	R5639[0] = (char *(*)()) F643_6036;
	R5639[50] = (char *(*)()) F693_6131;
	R5639[51] = (char *(*)()) F694_6131;
	R5639[52] = (char *(*)()) F695_6131;
	{long i; for (i = 53; i < 55; i++) R5639[i] = (char *(*)()) F693_6131;}
	R5639[55] = (char *(*)()) F694_6131;
	R5639[56] = (char *(*)()) F695_6131;
	R5639[57] = (char *(*)()) F700_6214;
	R5639[58] = (char *(*)()) F701_6214;
	R5639[59] = (char *(*)()) F702_6214;
	R5639[60] = (char *(*)()) F703_6214;
	R5639[61] = (char *(*)()) F704_6214;
	R5639[62] = (char *(*)()) F705_6214;
	R5639[63] = (char *(*)()) F706_6214;
	R5639[64] = (char *(*)()) F707_6214;
	R5639[65] = (char *(*)()) F708_6214;
	R5639[66] = (char *(*)()) F709_6214;
	R5639[67] = (char *(*)()) F710_6214;
	R5639[68] = (char *(*)()) F711_6214;
	R5639[198] = (char *(*)()) F841_6528;
	R5639[199] = (char *(*)()) F842_6528;
	R5639[200] = (char *(*)()) F843_6528;
	R5639[201] = (char *(*)()) F844_6528;
	R5639[202] = (char *(*)()) F845_6528;
	R5639[203] = (char *(*)()) F846_6528;
	R5639[204] = (char *(*)()) F841_6528;
	R5639[205] = (char *(*)()) F842_6528;
	R5639[206] = (char *(*)()) F841_6528;
	R5639[207] = (char *(*)()) F850_6662;
	R5639[208] = (char *(*)()) F851_6662;
	R5639[209] = (char *(*)()) F852_6662;
	R5639[210] = (char *(*)()) F853_6662;
	R5639[211] = (char *(*)()) F854_6662;
	R5639[212] = (char *(*)()) F855_6662;
	R5639[213] = (char *(*)()) F856_6662;
	R5639[214] = (char *(*)()) F857_6662;
	R5639[215] = (char *(*)()) F858_6662;
	R5639[216] = (char *(*)()) F859_6662;
	R5639[217] = (char *(*)()) F860_6662;
	R5639[218] = (char *(*)()) F861_6662;
	R5639[219] = (char *(*)()) F850_6662;
	R5639[220] = (char *(*)()) F854_6662;
	R5639[221] = (char *(*)()) F852_6662;
	R5639[226] = (char *(*)()) F850_6662;
	R5639[227] = (char *(*)()) F852_6662;
	{long i; for (i = 228; i < 232; i++) R5639[i] = (char *(*)()) F850_6662;}
	{long i; for (i = 237; i < 239; i++) R5639[i] = (char *(*)()) F850_6662;}
	{long i; for (i = 242; i < 244; i++) R5639[i] = (char *(*)()) F850_6662;}
	{long i; for (i = 246; i < 251; i++) R5639[i] = (char *(*)()) F850_6662;}
	{long i; for (i = 359; i < 361; i++) R5639[i] = (char *(*)()) F1001_7898;}
	R5639[491] = (char *(*)()) F1132_9934;
	R5639[494] = (char *(*)()) F1135_10102;
	{long i; for (i = 575; i < 578; i++) R5639[i] = (char *(*)()) F1210_10942;}
	R5639[618] = (char *(*)()) F1210_10942;
	R5639[625] = (char *(*)()) F1210_10942;
	{long i; for (i = 628; i < 630; i++) R5639[i] = (char *(*)()) F1210_10942;}
	R5639[826] = (char *(*)()) F1469_14935;
}

char *(*R5640[495])();
void R5640_init () {
	R5640[0] = (char *(*)()) F643_6035;
	R5640[57] = (char *(*)()) F700_6215;
	R5640[58] = (char *(*)()) F701_6215;
	R5640[59] = (char *(*)()) F702_6215;
	R5640[60] = (char *(*)()) F703_6215;
	R5640[61] = (char *(*)()) F704_6215;
	R5640[62] = (char *(*)()) F705_6215;
	R5640[63] = (char *(*)()) F706_6215;
	R5640[64] = (char *(*)()) F707_6215;
	R5640[65] = (char *(*)()) F708_6215;
	R5640[66] = (char *(*)()) F709_6215;
	R5640[67] = (char *(*)()) F710_6215;
	R5640[68] = (char *(*)()) F711_6215;
	R5640[207] = (char *(*)()) F850_6663;
	R5640[208] = (char *(*)()) F851_6663;
	R5640[209] = (char *(*)()) F852_6663;
	R5640[210] = (char *(*)()) F853_6663;
	R5640[211] = (char *(*)()) F854_6663;
	R5640[212] = (char *(*)()) F855_6663;
	R5640[213] = (char *(*)()) F856_6663;
	R5640[214] = (char *(*)()) F857_6663;
	R5640[215] = (char *(*)()) F858_6663;
	R5640[216] = (char *(*)()) F859_6663;
	R5640[217] = (char *(*)()) F860_6663;
	R5640[218] = (char *(*)()) F861_6663;
	R5640[219] = (char *(*)()) F850_6663;
	R5640[220] = (char *(*)()) F854_6663;
	R5640[221] = (char *(*)()) F852_6663;
	R5640[226] = (char *(*)()) F850_6663;
	R5640[227] = (char *(*)()) F852_6663;
	{long i; for (i = 228; i < 232; i++) R5640[i] = (char *(*)()) F850_6663;}
	{long i; for (i = 237; i < 239; i++) R5640[i] = (char *(*)()) F850_6663;}
	{long i; for (i = 242; i < 244; i++) R5640[i] = (char *(*)()) F850_6663;}
	{long i; for (i = 246; i < 251; i++) R5640[i] = (char *(*)()) F850_6663;}
	R5640[491] = (char *(*)()) F1132_9933;
	R5640[494] = (char *(*)()) F1135_10101;
}

char *(*R5644[495])();
void R5644_init () {
	R5644[0] = (char *(*)()) F576_5963;
	R5644[57] = (char *(*)()) F574_5963;
	R5644[58] = (char *(*)()) F575_5963;
	R5644[59] = (char *(*)()) F576_5963;
	R5644[60] = (char *(*)()) F577_5963;
	R5644[61] = (char *(*)()) F578_5963;
	R5644[62] = (char *(*)()) F579_5963;
	R5644[63] = (char *(*)()) F580_5963;
	R5644[64] = (char *(*)()) F582_5963;
	R5644[65] = (char *(*)()) F581_5963;
	R5644[66] = (char *(*)()) F583_5963;
	R5644[67] = (char *(*)()) F584_5963;
	R5644[68] = (char *(*)()) F585_5963;
	R5644[207] = (char *(*)()) F574_5963;
	R5644[208] = (char *(*)()) F575_5963;
	R5644[209] = (char *(*)()) F576_5963;
	R5644[210] = (char *(*)()) F577_5963;
	R5644[211] = (char *(*)()) F578_5963;
	R5644[212] = (char *(*)()) F579_5963;
	R5644[213] = (char *(*)()) F580_5963;
	R5644[214] = (char *(*)()) F582_5963;
	R5644[215] = (char *(*)()) F581_5963;
	R5644[216] = (char *(*)()) F583_5963;
	R5644[217] = (char *(*)()) F584_5963;
	R5644[218] = (char *(*)()) F585_5963;
	R5644[219] = (char *(*)()) F574_5963;
	R5644[220] = (char *(*)()) F578_5963;
	R5644[221] = (char *(*)()) F576_5963;
	R5644[226] = (char *(*)()) F574_5963;
	R5644[227] = (char *(*)()) F576_5963;
	{long i; for (i = 228; i < 232; i++) R5644[i] = (char *(*)()) F574_5963;}
	{long i; for (i = 237; i < 239; i++) R5644[i] = (char *(*)()) F574_5963;}
	{long i; for (i = 242; i < 244; i++) R5644[i] = (char *(*)()) F574_5963;}
	{long i; for (i = 246; i < 251; i++) R5644[i] = (char *(*)()) F574_5963;}
	R5644[491] = (char *(*)()) F581_5963;
	R5644[494] = (char *(*)()) F582_5963;
}

char *(*R5646[495])();
void R5646_init () {
	R5646[0] = (char *(*)()) F643_6046;
	R5646[57] = (char *(*)()) F700_6245;
	R5646[58] = (char *(*)()) F701_6245;
	R5646[59] = (char *(*)()) F702_6245;
	R5646[60] = (char *(*)()) F703_6245;
	R5646[61] = (char *(*)()) F704_6245;
	R5646[62] = (char *(*)()) F705_6245;
	R5646[63] = (char *(*)()) F706_6245;
	R5646[64] = (char *(*)()) F707_6245;
	R5646[65] = (char *(*)()) F708_6245;
	R5646[66] = (char *(*)()) F709_6245;
	R5646[67] = (char *(*)()) F710_6245;
	R5646[68] = (char *(*)()) F711_6245;
	R5646[207] = (char *(*)()) F850_6689;
	R5646[208] = (char *(*)()) F851_6689;
	R5646[209] = (char *(*)()) F852_6689;
	R5646[210] = (char *(*)()) F853_6689;
	R5646[211] = (char *(*)()) F854_6689;
	R5646[212] = (char *(*)()) F855_6689;
	R5646[213] = (char *(*)()) F856_6689;
	R5646[214] = (char *(*)()) F857_6689;
	R5646[215] = (char *(*)()) F858_6689;
	R5646[216] = (char *(*)()) F859_6689;
	R5646[217] = (char *(*)()) F860_6689;
	R5646[218] = (char *(*)()) F861_6689;
	R5646[219] = (char *(*)()) F850_6689;
	R5646[220] = (char *(*)()) F854_6689;
	R5646[221] = (char *(*)()) F852_6689;
	R5646[226] = (char *(*)()) F850_6689;
	R5646[227] = (char *(*)()) F852_6689;
	{long i; for (i = 228; i < 232; i++) R5646[i] = (char *(*)()) F850_6689;}
	{long i; for (i = 237; i < 239; i++) R5646[i] = (char *(*)()) F850_6689;}
	{long i; for (i = 242; i < 244; i++) R5646[i] = (char *(*)()) F850_6689;}
	{long i; for (i = 246; i < 251; i++) R5646[i] = (char *(*)()) F850_6689;}
	R5646[491] = (char *(*)()) F1134_10061;
	R5646[494] = (char *(*)()) F1137_10226;
}

char *(*R5648[777])();
void R5648_init () {
	R5648[0] = (char *(*)()) F586_5970;
	R5648[1] = (char *(*)()) F590_5970_5648_4;
	R5648[2] = (char *(*)()) F588_5970_5648_4;
	R5648[3] = (char *(*)()) F696_6173;
	R5648[4] = (char *(*)()) F697_6189;
	R5648[5] = (char *(*)()) F698_6189_5648_4;
	R5648[6] = (char *(*)()) F699_6189_5648_4;
	R5648[157] = (char *(*)()) F850_6681;
	R5648[158] = (char *(*)()) F851_6681_5648_4;
	R5648[159] = (char *(*)()) F852_6681_5648_4;
	R5648[160] = (char *(*)()) F853_6681_5648_4;
	R5648[161] = (char *(*)()) F854_6681_5648_4;
	R5648[162] = (char *(*)()) F855_6681_5648_4;
	R5648[163] = (char *(*)()) F856_6681_5648_4;
	R5648[164] = (char *(*)()) F857_6681_5648_4;
	R5648[165] = (char *(*)()) F858_6681_5648_4;
	R5648[166] = (char *(*)()) F859_6681_5648_4;
	R5648[167] = (char *(*)()) F860_6681_5648_4;
	R5648[168] = (char *(*)()) F861_6681_5648_4;
	R5648[169] = (char *(*)()) F850_6681;
	R5648[170] = (char *(*)()) F854_6681_5648_4;
	R5648[171] = (char *(*)()) F852_6681_5648_4;
	R5648[176] = (char *(*)()) F850_6681;
	R5648[177] = (char *(*)()) F852_6681_5648_4;
	{long i; for (i = 178; i < 182; i++) R5648[i] = (char *(*)()) F850_6681;}
	{long i; for (i = 187; i < 189; i++) R5648[i] = (char *(*)()) F850_6681;}
	{long i; for (i = 192; i < 194; i++) R5648[i] = (char *(*)()) F850_6681;}
	{long i; for (i = 196; i < 201; i++) R5648[i] = (char *(*)()) F850_6681;}
	{long i; for (i = 309; i < 311; i++) R5648[i] = (char *(*)()) F593_5970_5648_4;}
	{long i; for (i = 525; i < 528; i++) R5648[i] = (char *(*)()) F586_5970;}
	R5648[568] = (char *(*)()) F586_5970;
	R5648[575] = (char *(*)()) F586_5970;
	{long i; for (i = 578; i < 580; i++) R5648[i] = (char *(*)()) F586_5970;}
	R5648[776] = (char *(*)()) F593_5970_5648_4;
}
static void F590_5970_5648_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F590_5970(Current, *(EIF_BOOLEAN *)arg1);
}
static void F588_5970_5648_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F588_5970(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F698_6189_5648_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F698_6189(Current, *(EIF_BOOLEAN *)arg1);
}
static void F699_6189_5648_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F699_6189(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F851_6681_5648_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F851_6681(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F852_6681_5648_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F852_6681(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F853_6681_5648_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F853_6681(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F854_6681_5648_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F854_6681(Current, *(EIF_BOOLEAN *)arg1);
}
static void F855_6681_5648_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F855_6681(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F856_6681_5648_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F856_6681(Current, *(EIF_POINTER *)arg1);
}
static void F857_6681_5648_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F857_6681(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F858_6681_5648_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F858_6681(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F859_6681_5648_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F859_6681(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F860_6681_5648_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F860_6681(Current, *(EIF_REAL_32 *)arg1);
}
static void F861_6681_5648_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F861_6681(Current, *(EIF_REAL_64 *)arg1);
}
static void F593_5970_5648_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F593_5970(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R5662[630])();
void R5662_init () {
	R5662[0] = (char *(*)()) F643_6030_5662_26;
	R5662[50] = (char *(*)()) F645_6076;
	R5662[51] = (char *(*)()) F649_6076_5662_26;
	R5662[52] = (char *(*)()) F647_6076_5662_26;
	{long i; for (i = 53; i < 55; i++) R5662[i] = (char *(*)()) F645_6076;}
	R5662[55] = (char *(*)()) F649_6076_5662_26;
	R5662[56] = (char *(*)()) F647_6076_5662_26;
	R5662[57] = (char *(*)()) F700_6207;
	R5662[58] = (char *(*)()) F701_6207_5662_26;
	R5662[59] = (char *(*)()) F702_6207_5662_26;
	R5662[60] = (char *(*)()) F703_6207_5662_26;
	R5662[61] = (char *(*)()) F704_6207_5662_26;
	R5662[62] = (char *(*)()) F705_6207_5662_26;
	R5662[63] = (char *(*)()) F706_6207_5662_26;
	R5662[64] = (char *(*)()) F707_6207_5662_26;
	R5662[65] = (char *(*)()) F708_6207_5662_26;
	R5662[66] = (char *(*)()) F709_6207_5662_26;
	R5662[67] = (char *(*)()) F710_6207_5662_26;
	R5662[68] = (char *(*)()) F711_6207_5662_26;
	R5662[198] = (char *(*)()) F841_6526;
	R5662[199] = (char *(*)()) F842_6526_5662_26;
	R5662[200] = (char *(*)()) F843_6526_5662_26;
	R5662[201] = (char *(*)()) F844_6526;
	R5662[202] = (char *(*)()) F845_6526_5662_26;
	R5662[203] = (char *(*)()) F846_6526_5662_26;
	R5662[204] = (char *(*)()) F841_6526;
	R5662[205] = (char *(*)()) F842_6526_5662_26;
	R5662[206] = (char *(*)()) F841_6526;
	R5662[207] = (char *(*)()) F850_6647;
	R5662[208] = (char *(*)()) F851_6647_5662_26;
	R5662[209] = (char *(*)()) F852_6647_5662_26;
	R5662[210] = (char *(*)()) F853_6647_5662_26;
	R5662[211] = (char *(*)()) F854_6647_5662_26;
	R5662[212] = (char *(*)()) F855_6647_5662_26;
	R5662[213] = (char *(*)()) F856_6647_5662_26;
	R5662[214] = (char *(*)()) F857_6647_5662_26;
	R5662[215] = (char *(*)()) F858_6647_5662_26;
	R5662[216] = (char *(*)()) F859_6647_5662_26;
	R5662[217] = (char *(*)()) F860_6647_5662_26;
	R5662[218] = (char *(*)()) F861_6647_5662_26;
	R5662[219] = (char *(*)()) F850_6647;
	R5662[220] = (char *(*)()) F854_6647_5662_26;
	R5662[221] = (char *(*)()) F852_6647_5662_26;
	R5662[226] = (char *(*)()) F850_6647;
	R5662[227] = (char *(*)()) F852_6647_5662_26;
	{long i; for (i = 228; i < 232; i++) R5662[i] = (char *(*)()) F850_6647;}
	{long i; for (i = 237; i < 239; i++) R5662[i] = (char *(*)()) F850_6647;}
	{long i; for (i = 242; i < 244; i++) R5662[i] = (char *(*)()) F850_6647;}
	{long i; for (i = 246; i < 251; i++) R5662[i] = (char *(*)()) F850_6647;}
	R5662[274] = (char *(*)()) F917_7189;
	R5662[275] = (char *(*)()) F918_7189_5662_26;
	R5662[276] = (char *(*)()) F919_7189_5662_26;
	R5662[277] = (char *(*)()) F920_7189_5662_26;
	R5662[278] = (char *(*)()) F921_7189_5662_26;
	R5662[279] = (char *(*)()) F922_7189_5662_26;
	R5662[280] = (char *(*)()) F923_7189_5662_26;
	R5662[281] = (char *(*)()) F924_7189_5662_26;
	R5662[282] = (char *(*)()) F925_7189_5662_26;
	R5662[283] = (char *(*)()) F926_7189_5662_26;
	R5662[284] = (char *(*)()) F927_7189_5662_26;
	R5662[285] = (char *(*)()) F928_7189_5662_26;
	R5662[407] = (char *(*)()) F1050_8550;
	R5662[490] = (char *(*)()) F1133_9972_5662_26;
	R5662[491] = (char *(*)()) F1134_9995_5662_26;
	R5662[493] = (char *(*)()) F1136_10137_5662_26;
	R5662[494] = (char *(*)()) F1137_10159_5662_26;
	{long i; for (i = 575; i < 578; i++) R5662[i] = (char *(*)()) F1210_10938;}
	R5662[618] = (char *(*)()) F1210_10938;
	R5662[625] = (char *(*)()) F1210_10938;
	{long i; for (i = 628; i < 630; i++) R5662[i] = (char *(*)()) F1210_10938;}
}
static EIF_REFERENCE F643_6030_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F643_6030(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F649_6076_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F649_6076(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F647_6076_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F647_6076(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F701_6207_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F701_6207(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1079, 0x00).id, 1079, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F702_6207_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F702_6207(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F703_6207_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F703_6207(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1076, 0x00).id, 1076, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F704_6207_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F704_6207(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F705_6207_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F705_6207(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F706_6207_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F706_6207(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F707_6207_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F707_6207(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F708_6207_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F708_6207(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F709_6207_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F709_6207(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F710_6207_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F710_6207(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F711_6207_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F711_6207(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F842_6526_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F842_6526(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F843_6526_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F843_6526(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F845_6526_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F845_6526(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F846_6526_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F846_6526(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_6647_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F851_6647(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1079, 0x00).id, 1079, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_6647_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F852_6647(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F853_6647_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F853_6647(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1076, 0x00).id, 1076, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F854_6647_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F854_6647(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F855_6647_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F855_6647(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F856_6647_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F856_6647(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_6647_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F857_6647(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_6647_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F858_6647(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_6647_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F859_6647(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F860_6647_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F860_6647(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F861_6647_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F861_6647(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F918_7189_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F918_7189(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1079, 0x00).id, 1079, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F919_7189_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F919_7189(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F920_7189_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F920_7189(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1076, 0x00).id, 1076, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F921_7189_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F921_7189(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F922_7189_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F922_7189(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F923_7189_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F923_7189(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F924_7189_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F924_7189(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F925_7189_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F925_7189(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F926_7189_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F926_7189(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F927_7189_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F927_7189(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F928_7189_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F928_7189(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1133_9972_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1133_9972(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1134_9995_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1134_9995(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1136_10137_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1136_10137(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1137_10159_5662_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1137_10159(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R5663[630])();
void R5663_init () {
	R5663[0] = (char *(*)()) F643_6027;
	R5663[50] = (char *(*)()) F645_6079;
	R5663[51] = (char *(*)()) F649_6079;
	R5663[52] = (char *(*)()) F647_6079;
	{long i; for (i = 53; i < 55; i++) R5663[i] = (char *(*)()) F645_6079;}
	R5663[55] = (char *(*)()) F649_6079;
	R5663[56] = (char *(*)()) F647_6079;
	R5663[57] = (char *(*)()) F700_6212;
	R5663[58] = (char *(*)()) F701_6212;
	R5663[59] = (char *(*)()) F702_6212;
	R5663[60] = (char *(*)()) F703_6212;
	R5663[61] = (char *(*)()) F704_6212;
	R5663[62] = (char *(*)()) F705_6212;
	R5663[63] = (char *(*)()) F706_6212;
	R5663[64] = (char *(*)()) F707_6212;
	R5663[65] = (char *(*)()) F708_6212;
	R5663[66] = (char *(*)()) F709_6212;
	R5663[67] = (char *(*)()) F710_6212;
	R5663[68] = (char *(*)()) F711_6212;
	R5663[198] = (char *(*)()) F841_6531;
	R5663[199] = (char *(*)()) F842_6531;
	R5663[200] = (char *(*)()) F843_6531;
	R5663[201] = (char *(*)()) F844_6531;
	R5663[202] = (char *(*)()) F845_6531;
	R5663[203] = (char *(*)()) F846_6531;
	R5663[204] = (char *(*)()) F841_6531;
	R5663[205] = (char *(*)()) F842_6531;
	R5663[206] = (char *(*)()) F841_6531;
	R5663[207] = (char *(*)()) F645_6079;
	R5663[208] = (char *(*)()) F646_6079;
	R5663[209] = (char *(*)()) F647_6079;
	R5663[210] = (char *(*)()) F648_6079;
	R5663[211] = (char *(*)()) F649_6079;
	R5663[212] = (char *(*)()) F650_6079;
	R5663[213] = (char *(*)()) F651_6079;
	R5663[214] = (char *(*)()) F652_6079;
	R5663[215] = (char *(*)()) F653_6079;
	R5663[216] = (char *(*)()) F654_6079;
	R5663[217] = (char *(*)()) F655_6079;
	R5663[218] = (char *(*)()) F656_6079;
	R5663[219] = (char *(*)()) F645_6079;
	R5663[220] = (char *(*)()) F649_6079;
	R5663[221] = (char *(*)()) F647_6079;
	R5663[226] = (char *(*)()) F645_6079;
	R5663[227] = (char *(*)()) F647_6079;
	{long i; for (i = 228; i < 232; i++) R5663[i] = (char *(*)()) F645_6079;}
	{long i; for (i = 237; i < 239; i++) R5663[i] = (char *(*)()) F645_6079;}
	{long i; for (i = 242; i < 244; i++) R5663[i] = (char *(*)()) F645_6079;}
	{long i; for (i = 246; i < 251; i++) R5663[i] = (char *(*)()) F645_6079;}
	R5663[274] = (char *(*)()) F917_7197;
	R5663[275] = (char *(*)()) F918_7197;
	R5663[276] = (char *(*)()) F919_7197;
	R5663[277] = (char *(*)()) F920_7197;
	R5663[278] = (char *(*)()) F921_7197;
	R5663[279] = (char *(*)()) F922_7197;
	R5663[280] = (char *(*)()) F923_7197;
	R5663[281] = (char *(*)()) F924_7197;
	R5663[282] = (char *(*)()) F925_7197;
	R5663[283] = (char *(*)()) F926_7197;
	R5663[284] = (char *(*)()) F927_7197;
	R5663[285] = (char *(*)()) F928_7197;
	R5663[407] = (char *(*)()) F1050_8580;
	{long i; for (i = 490; i < 492; i++) R5663[i] = (char *(*)()) F1132_9936;}
	{long i; for (i = 493; i < 495; i++) R5663[i] = (char *(*)()) F1135_10104;}
	{long i; for (i = 575; i < 578; i++) R5663[i] = (char *(*)()) F645_6079;}
	R5663[618] = (char *(*)()) F645_6079;
	R5663[625] = (char *(*)()) F645_6079;
	{long i; for (i = 628; i < 630; i++) R5663[i] = (char *(*)()) F645_6079;}
}


#ifdef __cplusplus
}
#endif
