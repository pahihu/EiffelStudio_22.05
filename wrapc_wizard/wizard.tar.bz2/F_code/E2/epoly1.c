#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O2054[1286];
void O2054_init () {
	O2054[0] = 0;
	O2054[1262] = 0;
	O2054[1263] =  + _REFACS_1_;
	O2054[1264] = 0;
	O2054[1265] =  + _REFACS_3_;
	O2054[1271] =  + _REFACS_3_;
	O2054[1280] = 0;
	O2054[1281] =  + _REFACS_1_;
	O2054[1282] = 0;
	O2054[1283] =  + _REFACS_3_;
	O2054[1285] =  + _REFACS_3_;
}

long O2137[1310];
void O2137_init () {
	O2137[0] = 0;
	{long i; for (i = 1284; i < 1288; i++) O2137[i] = 0;}
	{long i; for (i = 1288; i < 1292; i++) O2137[i] =  + _REFACS_4_;}
	{long i; for (i = 1292; i < 1298; i++) O2137[i] = 0;}
	O2137[1298] =  + _REFACS_1_;
	{long i; for (i = 1299; i < 1303; i++) O2137[i] = 0;}
	O2137[1303] =  + _REFACS_1_;
	{long i; for (i = 1304; i < 1310; i++) O2137[i] =  + _REFACS_2_;}
}

long O2139[1310];
void O2139_init () {
	O2139[0] =  + _REFACS_1_;
	{long i; for (i = 1284; i < 1288; i++) O2139[i] =  + _REFACS_1_;}
	{long i; for (i = 1288; i < 1292; i++) O2139[i] =  + _REFACS_5_;}
	{long i; for (i = 1292; i < 1298; i++) O2139[i] =  + _REFACS_1_;}
	O2139[1298] =  + _REFACS_2_;
	{long i; for (i = 1299; i < 1303; i++) O2139[i] =  + _REFACS_1_;}
	O2139[1303] =  + _REFACS_2_;
	{long i; for (i = 1304; i < 1310; i++) O2139[i] =  + _REFACS_3_;}
}

long O2141[1310];
void O2141_init () {
	O2141[0] =  + _REFACS_2_;
	{long i; for (i = 1284; i < 1288; i++) O2141[i] =  + _REFACS_2_;}
	{long i; for (i = 1288; i < 1292; i++) O2141[i] =  + _REFACS_6_;}
	{long i; for (i = 1292; i < 1298; i++) O2141[i] =  + _REFACS_2_;}
	O2141[1298] =  + _REFACS_3_;
	{long i; for (i = 1299; i < 1303; i++) O2141[i] =  + _REFACS_2_;}
	O2141[1303] =  + _REFACS_3_;
	{long i; for (i = 1304; i < 1310; i++) O2141[i] =  + _REFACS_4_;}
}

long O2149[1316];
void O2149_init () {
	O2149[0] = 0;
	{long i; for (i = 1175; i < 1177; i++) O2149[i] = 0;}
	{long i; for (i = 1213; i < 1218; i++) O2149[i] = 0;}
	O2149[1218] =  + _REFACS_1_;
	{long i; for (i = 1219; i < 1221; i++) O2149[i] = 0;}
	O2149[1221] =  + _REFACS_1_;
	{long i; for (i = 1222; i < 1246; i++) O2149[i] = 0;}
	O2149[1246] =  + _REFACS_1_;
	O2149[1247] =  + _REFACS_2_;
	O2149[1248] =  + _REFACS_4_;
	{long i; for (i = 1249; i < 1251; i++) O2149[i] = 0;}
	O2149[1251] =  + _REFACS_1_;
	O2149[1252] =  + _REFACS_2_;
	O2149[1253] =  + _REFACS_1_;
	O2149[1254] =  + _REFACS_4_;
	{long i; for (i = 1255; i < 1259; i++) O2149[i] = 0;}
	O2149[1259] =  + _REFACS_2_;
	O2149[1260] =  + _REFACS_6_;
	{long i; for (i = 1261; i < 1263; i++) O2149[i] =  + _REFACS_2_;}
	O2149[1263] = 0;
	O2149[1264] =  + _REFACS_1_;
	O2149[1265] =  + _REFACS_2_;
	O2149[1266] =  + _REFACS_4_;
	{long i; for (i = 1267; i < 1269; i++) O2149[i] = 0;}
	O2149[1269] =  + _REFACS_1_;
	O2149[1270] =  + _REFACS_2_;
	O2149[1271] =  + _REFACS_1_;
	O2149[1272] =  + _REFACS_4_;
	O2149[1273] =  + _REFACS_2_;
	O2149[1274] =  + _REFACS_6_;
	{long i; for (i = 1275; i < 1277; i++) O2149[i] =  + _REFACS_2_;}
	{long i; for (i = 1277; i < 1281; i++) O2149[i] = 0;}
	{long i; for (i = 1303; i < 1307; i++) O2149[i] =  + _REFACS_5_;}
	O2149[1308] = 0;
	O2149[1310] = 0;
	O2149[1313] = 0;
	O2149[1315] = 0;
}

long O2150[1316];
void O2150_init () {
	O2150[0] =  + _REFACS_1_;
	{long i; for (i = 1175; i < 1177; i++) O2150[i] =  + _REFACS_1_;}
	{long i; for (i = 1213; i < 1218; i++) O2150[i] =  + _REFACS_1_;}
	O2150[1218] =  + _REFACS_2_;
	{long i; for (i = 1219; i < 1221; i++) O2150[i] =  + _REFACS_1_;}
	O2150[1221] =  + _REFACS_2_;
	{long i; for (i = 1222; i < 1246; i++) O2150[i] =  + _REFACS_1_;}
	O2150[1246] =  + _REFACS_2_;
	O2150[1247] =  + _REFACS_3_;
	O2150[1248] =  + _REFACS_5_;
	{long i; for (i = 1249; i < 1251; i++) O2150[i] =  + _REFACS_1_;}
	O2150[1251] =  + _REFACS_2_;
	O2150[1252] =  + _REFACS_3_;
	O2150[1253] =  + _REFACS_2_;
	O2150[1254] =  + _REFACS_5_;
	{long i; for (i = 1255; i < 1259; i++) O2150[i] =  + _REFACS_1_;}
	O2150[1259] =  + _REFACS_3_;
	O2150[1260] =  + _REFACS_7_;
	{long i; for (i = 1261; i < 1263; i++) O2150[i] =  + _REFACS_3_;}
	O2150[1263] =  + _REFACS_1_;
	O2150[1264] =  + _REFACS_2_;
	O2150[1265] =  + _REFACS_3_;
	O2150[1266] =  + _REFACS_5_;
	{long i; for (i = 1267; i < 1269; i++) O2150[i] =  + _REFACS_1_;}
	O2150[1269] =  + _REFACS_2_;
	O2150[1270] =  + _REFACS_3_;
	O2150[1271] =  + _REFACS_2_;
	O2150[1272] =  + _REFACS_5_;
	O2150[1273] =  + _REFACS_3_;
	O2150[1274] =  + _REFACS_7_;
	{long i; for (i = 1275; i < 1277; i++) O2150[i] =  + _REFACS_3_;}
	{long i; for (i = 1277; i < 1281; i++) O2150[i] =  + _REFACS_1_;}
	{long i; for (i = 1303; i < 1307; i++) O2150[i] =  + _REFACS_6_;}
	O2150[1308] =  + _REFACS_1_;
	O2150[1310] =  + _REFACS_1_;
	O2150[1313] =  + _REFACS_1_;
	O2150[1315] =  + _REFACS_1_;
}

long O2156[1298];
void O2156_init () {
	O2156[0] = 0;
	{long i; for (i = 1288; i < 1292; i++) O2156[i] =  + _REFACS_3_;}
	O2156[1292] =  + _REFACS_4_;
	{long i; for (i = 1293; i < 1297; i++) O2156[i] =  + _REFACS_3_;}
	O2156[1297] =  + _REFACS_4_;
}

long O3352[1222];
void O3352_init () {
	O3352[0] = 0;
	{long i; for (i = 1214; i < 1216; i++) O3352[i] =  + _REFACS_4_;}
	{long i; for (i = 1216; i < 1218; i++) O3352[i] =  + _REFACS_7_;}
	{long i; for (i = 1218; i < 1220; i++) O3352[i] =  + _REFACS_4_;}
	{long i; for (i = 1220; i < 1222; i++) O3352[i] =  + _REFACS_7_;}
}


#ifdef __cplusplus
}
#endif
