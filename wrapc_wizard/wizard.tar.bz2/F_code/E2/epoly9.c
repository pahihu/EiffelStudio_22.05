#include "epoly9.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

EIF_TYPE_INDEX *Y5663_gen_type [956];
EIF_TYPE_INDEX Y5663 [956];
void Y5663_init (void)
{
	egc_routines_types [5663] = Y5663;
	egc_routines_gen_types [5663] = Y5663_gen_type;
	egc_routines_offset [5663] = 618;
	{long i; for (i = 0; i < 100; i++) Y5663[i] = 1067;};
	{long i; for (i = 222; i < 275; i++) Y5663[i] = 1067;};
	{long i; for (i = 298; i < 310; i++) Y5663[i] = 1067;};
	Y5663[431] = 1067;
	{long i; for (i = 513; i < 521; i++) Y5663[i] = 1067;};
	Y5663[591] = 1067;
	{long i; for (i = 595; i < 602; i++) Y5663[i] = 1067;};
	Y5663[630] = 1067;
	{long i; for (i = 640; i < 654; i++) Y5663[i] = 1067;};
	{long i; for (i = 954; i < 956; i++) Y5663[i] = 1067;};
}

char *(*R5664[630])();
void R5664_init () {
	R5664[0] = (char *(*)()) F643_6029;
	R5664[50] = (char *(*)()) F693_6131;
	R5664[51] = (char *(*)()) F694_6131;
	R5664[52] = (char *(*)()) F695_6131;
	{long i; for (i = 53; i < 55; i++) R5664[i] = (char *(*)()) F693_6131;}
	R5664[55] = (char *(*)()) F694_6131;
	R5664[56] = (char *(*)()) F695_6131;
	R5664[57] = (char *(*)()) F700_6213;
	R5664[58] = (char *(*)()) F701_6213;
	R5664[59] = (char *(*)()) F702_6213;
	R5664[60] = (char *(*)()) F703_6213;
	R5664[61] = (char *(*)()) F704_6213;
	R5664[62] = (char *(*)()) F705_6213;
	R5664[63] = (char *(*)()) F706_6213;
	R5664[64] = (char *(*)()) F707_6213;
	R5664[65] = (char *(*)()) F708_6213;
	R5664[66] = (char *(*)()) F709_6213;
	R5664[67] = (char *(*)()) F710_6213;
	R5664[68] = (char *(*)()) F711_6213;
	R5664[198] = (char *(*)()) F841_6532;
	R5664[199] = (char *(*)()) F842_6532;
	R5664[200] = (char *(*)()) F843_6532;
	R5664[201] = (char *(*)()) F844_6532;
	R5664[202] = (char *(*)()) F845_6532;
	R5664[203] = (char *(*)()) F846_6532;
	R5664[204] = (char *(*)()) F841_6532;
	R5664[205] = (char *(*)()) F842_6532;
	R5664[206] = (char *(*)()) F841_6532;
	R5664[207] = (char *(*)()) F850_6662;
	R5664[208] = (char *(*)()) F851_6662;
	R5664[209] = (char *(*)()) F852_6662;
	R5664[210] = (char *(*)()) F853_6662;
	R5664[211] = (char *(*)()) F854_6662;
	R5664[212] = (char *(*)()) F855_6662;
	R5664[213] = (char *(*)()) F856_6662;
	R5664[214] = (char *(*)()) F857_6662;
	R5664[215] = (char *(*)()) F858_6662;
	R5664[216] = (char *(*)()) F859_6662;
	R5664[217] = (char *(*)()) F860_6662;
	R5664[218] = (char *(*)()) F861_6662;
	R5664[219] = (char *(*)()) F850_6662;
	R5664[220] = (char *(*)()) F854_6662;
	R5664[221] = (char *(*)()) F852_6662;
	R5664[226] = (char *(*)()) F850_6662;
	R5664[227] = (char *(*)()) F852_6662;
	{long i; for (i = 228; i < 232; i++) R5664[i] = (char *(*)()) F850_6662;}
	{long i; for (i = 237; i < 239; i++) R5664[i] = (char *(*)()) F850_6662;}
	{long i; for (i = 242; i < 244; i++) R5664[i] = (char *(*)()) F850_6662;}
	{long i; for (i = 246; i < 251; i++) R5664[i] = (char *(*)()) F850_6662;}
	R5664[274] = (char *(*)()) F917_7198;
	R5664[275] = (char *(*)()) F918_7198;
	R5664[276] = (char *(*)()) F919_7198;
	R5664[277] = (char *(*)()) F920_7198;
	R5664[278] = (char *(*)()) F921_7198;
	R5664[279] = (char *(*)()) F922_7198;
	R5664[280] = (char *(*)()) F923_7198;
	R5664[281] = (char *(*)()) F924_7198;
	R5664[282] = (char *(*)()) F925_7198;
	R5664[283] = (char *(*)()) F926_7198;
	R5664[284] = (char *(*)()) F927_7198;
	R5664[285] = (char *(*)()) F928_7198;
	R5664[407] = (char *(*)()) F1050_8579;
	{long i; for (i = 490; i < 492; i++) R5664[i] = (char *(*)()) F1132_9934;}
	{long i; for (i = 493; i < 495; i++) R5664[i] = (char *(*)()) F1135_10102;}
	{long i; for (i = 575; i < 578; i++) R5664[i] = (char *(*)()) F1210_10942;}
	R5664[618] = (char *(*)()) F1210_10942;
	R5664[625] = (char *(*)()) F1210_10942;
	{long i; for (i = 628; i < 630; i++) R5664[i] = (char *(*)()) F1210_10942;}
}

char *(*R5666[630])();
void R5666_init () {
	R5666[0] = (char *(*)()) F643_6033;
	R5666[50] = (char *(*)()) F645_6084;
	R5666[51] = (char *(*)()) F649_6084;
	R5666[52] = (char *(*)()) F647_6084;
	{long i; for (i = 53; i < 55; i++) R5666[i] = (char *(*)()) F645_6084;}
	R5666[55] = (char *(*)()) F649_6084;
	R5666[56] = (char *(*)()) F647_6084;
	R5666[57] = (char *(*)()) F700_6222;
	R5666[58] = (char *(*)()) F701_6222;
	R5666[59] = (char *(*)()) F702_6222;
	R5666[60] = (char *(*)()) F703_6222;
	R5666[61] = (char *(*)()) F704_6222;
	R5666[62] = (char *(*)()) F705_6222;
	R5666[63] = (char *(*)()) F706_6222;
	R5666[64] = (char *(*)()) F707_6222;
	R5666[65] = (char *(*)()) F708_6222;
	R5666[66] = (char *(*)()) F709_6222;
	R5666[67] = (char *(*)()) F710_6222;
	R5666[68] = (char *(*)()) F711_6222;
	R5666[198] = (char *(*)()) F841_6548;
	R5666[199] = (char *(*)()) F842_6548;
	R5666[200] = (char *(*)()) F843_6548;
	R5666[201] = (char *(*)()) F844_6548;
	R5666[202] = (char *(*)()) F845_6548;
	R5666[203] = (char *(*)()) F846_6548;
	R5666[204] = (char *(*)()) F841_6548;
	R5666[205] = (char *(*)()) F842_6548;
	R5666[206] = (char *(*)()) F841_6548;
	R5666[207] = (char *(*)()) F850_6668;
	R5666[208] = (char *(*)()) F851_6668;
	R5666[209] = (char *(*)()) F852_6668;
	R5666[210] = (char *(*)()) F853_6668;
	R5666[211] = (char *(*)()) F854_6668;
	R5666[212] = (char *(*)()) F855_6668;
	R5666[213] = (char *(*)()) F856_6668;
	R5666[214] = (char *(*)()) F857_6668;
	R5666[215] = (char *(*)()) F858_6668;
	R5666[216] = (char *(*)()) F859_6668;
	R5666[217] = (char *(*)()) F860_6668;
	R5666[218] = (char *(*)()) F861_6668;
	R5666[219] = (char *(*)()) F850_6668;
	R5666[220] = (char *(*)()) F854_6668;
	R5666[221] = (char *(*)()) F852_6668;
	R5666[226] = (char *(*)()) F850_6668;
	R5666[227] = (char *(*)()) F852_6668;
	{long i; for (i = 228; i < 232; i++) R5666[i] = (char *(*)()) F850_6668;}
	{long i; for (i = 237; i < 239; i++) R5666[i] = (char *(*)()) F850_6668;}
	{long i; for (i = 242; i < 244; i++) R5666[i] = (char *(*)()) F850_6668;}
	{long i; for (i = 246; i < 251; i++) R5666[i] = (char *(*)()) F850_6668;}
	R5666[274] = (char *(*)()) F917_7203;
	R5666[275] = (char *(*)()) F918_7203;
	R5666[276] = (char *(*)()) F919_7203;
	R5666[277] = (char *(*)()) F920_7203;
	R5666[278] = (char *(*)()) F921_7203;
	R5666[279] = (char *(*)()) F922_7203;
	R5666[280] = (char *(*)()) F923_7203;
	R5666[281] = (char *(*)()) F924_7203;
	R5666[282] = (char *(*)()) F925_7203;
	R5666[283] = (char *(*)()) F926_7203;
	R5666[284] = (char *(*)()) F927_7203;
	R5666[285] = (char *(*)()) F928_7203;
	R5666[407] = (char *(*)()) F1050_8577;
	{long i; for (i = 490; i < 492; i++) R5666[i] = (char *(*)()) F1129_9795;}
	{long i; for (i = 493; i < 495; i++) R5666[i] = (char *(*)()) F1129_9795;}
	{long i; for (i = 575; i < 578; i++) R5666[i] = (char *(*)()) F645_6084;}
	R5666[618] = (char *(*)()) F645_6084;
	R5666[625] = (char *(*)()) F645_6084;
	{long i; for (i = 628; i < 630; i++) R5666[i] = (char *(*)()) F645_6084;}
}

char *(*R5689[580])();
void R5689_init () {
	R5689[0] = (char *(*)()) F693_6125;
	R5689[1] = (char *(*)()) F694_6125_5689_1;
	R5689[2] = (char *(*)()) F695_6125_5689_1;
	{long i; for (i = 3; i < 5; i++) R5689[i] = (char *(*)()) F693_6125;}
	R5689[5] = (char *(*)()) F694_6125_5689_1;
	R5689[6] = (char *(*)()) F695_6125_5689_1;
	R5689[157] = (char *(*)()) F850_6649;
	R5689[158] = (char *(*)()) F851_6649_5689_1;
	R5689[159] = (char *(*)()) F852_6649_5689_1;
	R5689[160] = (char *(*)()) F853_6649_5689_1;
	R5689[161] = (char *(*)()) F854_6649_5689_1;
	R5689[162] = (char *(*)()) F855_6649_5689_1;
	R5689[163] = (char *(*)()) F856_6649_5689_1;
	R5689[164] = (char *(*)()) F857_6649_5689_1;
	R5689[165] = (char *(*)()) F858_6649_5689_1;
	R5689[166] = (char *(*)()) F859_6649_5689_1;
	R5689[167] = (char *(*)()) F860_6649_5689_1;
	R5689[168] = (char *(*)()) F861_6649_5689_1;
	R5689[169] = (char *(*)()) F850_6649;
	R5689[170] = (char *(*)()) F854_6649_5689_1;
	R5689[171] = (char *(*)()) F852_6649_5689_1;
	R5689[176] = (char *(*)()) F850_6649;
	R5689[177] = (char *(*)()) F852_6649_5689_1;
	{long i; for (i = 178; i < 182; i++) R5689[i] = (char *(*)()) F850_6649;}
	{long i; for (i = 187; i < 189; i++) R5689[i] = (char *(*)()) F850_6649;}
	{long i; for (i = 192; i < 194; i++) R5689[i] = (char *(*)()) F850_6649;}
	{long i; for (i = 196; i < 201; i++) R5689[i] = (char *(*)()) F850_6649;}
	{long i; for (i = 525; i < 528; i++) R5689[i] = (char *(*)()) F645_6072;}
	R5689[568] = (char *(*)()) F645_6072;
	R5689[575] = (char *(*)()) F645_6072;
	{long i; for (i = 578; i < 580; i++) R5689[i] = (char *(*)()) F645_6072;}
}
static EIF_REFERENCE F694_6125_5689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F694_6125(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F695_6125_5689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F695_6125(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_6649_5689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F851_6649(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1079, 0x00).id, 1079, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_6649_5689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F852_6649(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F853_6649_5689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F853_6649(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1076, 0x00).id, 1076, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F854_6649_5689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F854_6649(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F855_6649_5689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F855_6649(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F856_6649_5689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F856_6649(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_6649_5689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F857_6649(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_6649_5689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F858_6649(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_6649_5689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F859_6649(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F860_6649_5689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F860_6649(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F861_6649_5689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F861_6649(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5690[580])();
void R5690_init () {
	R5690[0] = (char *(*)()) F693_6126;
	R5690[1] = (char *(*)()) F694_6126_5690_1;
	R5690[2] = (char *(*)()) F695_6126_5690_1;
	{long i; for (i = 3; i < 5; i++) R5690[i] = (char *(*)()) F693_6126;}
	R5690[5] = (char *(*)()) F694_6126_5690_1;
	R5690[6] = (char *(*)()) F695_6126_5690_1;
	R5690[157] = (char *(*)()) F850_6650;
	R5690[158] = (char *(*)()) F851_6650_5690_1;
	R5690[159] = (char *(*)()) F852_6650_5690_1;
	R5690[160] = (char *(*)()) F853_6650_5690_1;
	R5690[161] = (char *(*)()) F854_6650_5690_1;
	R5690[162] = (char *(*)()) F855_6650_5690_1;
	R5690[163] = (char *(*)()) F856_6650_5690_1;
	R5690[164] = (char *(*)()) F857_6650_5690_1;
	R5690[165] = (char *(*)()) F858_6650_5690_1;
	R5690[166] = (char *(*)()) F859_6650_5690_1;
	R5690[167] = (char *(*)()) F860_6650_5690_1;
	R5690[168] = (char *(*)()) F861_6650_5690_1;
	R5690[169] = (char *(*)()) F850_6650;
	R5690[170] = (char *(*)()) F854_6650_5690_1;
	R5690[171] = (char *(*)()) F852_6650_5690_1;
	R5690[176] = (char *(*)()) F850_6650;
	R5690[177] = (char *(*)()) F852_6650_5690_1;
	{long i; for (i = 178; i < 182; i++) R5690[i] = (char *(*)()) F850_6650;}
	{long i; for (i = 187; i < 189; i++) R5690[i] = (char *(*)()) F850_6650;}
	{long i; for (i = 192; i < 194; i++) R5690[i] = (char *(*)()) F850_6650;}
	{long i; for (i = 196; i < 201; i++) R5690[i] = (char *(*)()) F850_6650;}
	{long i; for (i = 525; i < 528; i++) R5690[i] = (char *(*)()) F645_6073;}
	R5690[568] = (char *(*)()) F645_6073;
	R5690[575] = (char *(*)()) F645_6073;
	{long i; for (i = 578; i < 580; i++) R5690[i] = (char *(*)()) F645_6073;}
}
static EIF_REFERENCE F694_6126_5690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F694_6126(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F695_6126_5690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F695_6126(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_6650_5690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F851_6650(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1079, 0x00).id, 1079, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_6650_5690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F852_6650(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F853_6650_5690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F853_6650(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1076, 0x00).id, 1076, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F854_6650_5690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F854_6650(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F855_6650_5690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F855_6650(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F856_6650_5690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F856_6650(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_6650_5690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F857_6650(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_6650_5690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F858_6650(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_6650_5690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F859_6650(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F860_6650_5690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F860_6650(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F861_6650_5690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F861_6650(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5691[7])();
void R5691_init () {
	R5691[0] = (char *(*)()) F693_6145;
	R5691[1] = (char *(*)()) F694_6145;
	R5691[2] = (char *(*)()) F695_6145;
	{long i; for (i = 3; i < 5; i++) R5691[i] = (char *(*)()) F693_6145;}
	R5691[5] = (char *(*)()) F694_6145;
	R5691[6] = (char *(*)()) F695_6145;
}

char *(*R5692[580])();
void R5692_init () {
	R5692[0] = (char *(*)()) F693_6146;
	R5692[1] = (char *(*)()) F694_6146;
	R5692[2] = (char *(*)()) F695_6146;
	{long i; for (i = 3; i < 5; i++) R5692[i] = (char *(*)()) F693_6146;}
	R5692[5] = (char *(*)()) F694_6146;
	R5692[6] = (char *(*)()) F695_6146;
	R5692[157] = (char *(*)()) F850_6676;
	R5692[158] = (char *(*)()) F851_6676;
	R5692[159] = (char *(*)()) F852_6676;
	R5692[160] = (char *(*)()) F853_6676;
	R5692[161] = (char *(*)()) F854_6676;
	R5692[162] = (char *(*)()) F855_6676;
	R5692[163] = (char *(*)()) F856_6676;
	R5692[164] = (char *(*)()) F857_6676;
	R5692[165] = (char *(*)()) F858_6676;
	R5692[166] = (char *(*)()) F859_6676;
	R5692[167] = (char *(*)()) F860_6676;
	R5692[168] = (char *(*)()) F861_6676;
	R5692[169] = (char *(*)()) F850_6676;
	R5692[170] = (char *(*)()) F854_6676;
	R5692[171] = (char *(*)()) F852_6676;
	R5692[176] = (char *(*)()) F850_6676;
	R5692[177] = (char *(*)()) F852_6676;
	{long i; for (i = 178; i < 182; i++) R5692[i] = (char *(*)()) F850_6676;}
	{long i; for (i = 187; i < 189; i++) R5692[i] = (char *(*)()) F850_6676;}
	{long i; for (i = 192; i < 194; i++) R5692[i] = (char *(*)()) F850_6676;}
	{long i; for (i = 196; i < 201; i++) R5692[i] = (char *(*)()) F850_6676;}
	{long i; for (i = 525; i < 528; i++) R5692[i] = (char *(*)()) F1210_10948;}
	R5692[568] = (char *(*)()) F1210_10948;
	R5692[575] = (char *(*)()) F1210_10948;
	{long i; for (i = 578; i < 580; i++) R5692[i] = (char *(*)()) F1210_10948;}
}

char *(*R5693[580])();
void R5693_init () {
	R5693[0] = (char *(*)()) F693_6136;
	R5693[1] = (char *(*)()) F694_6136;
	R5693[2] = (char *(*)()) F695_6136;
	{long i; for (i = 3; i < 5; i++) R5693[i] = (char *(*)()) F693_6136;}
	R5693[5] = (char *(*)()) F694_6136;
	R5693[6] = (char *(*)()) F695_6136;
	R5693[157] = (char *(*)()) F645_6085;
	R5693[158] = (char *(*)()) F646_6085;
	R5693[159] = (char *(*)()) F647_6085;
	R5693[160] = (char *(*)()) F648_6085;
	R5693[161] = (char *(*)()) F649_6085;
	R5693[162] = (char *(*)()) F650_6085;
	R5693[163] = (char *(*)()) F651_6085;
	R5693[164] = (char *(*)()) F652_6085;
	R5693[165] = (char *(*)()) F653_6085;
	R5693[166] = (char *(*)()) F654_6085;
	R5693[167] = (char *(*)()) F655_6085;
	R5693[168] = (char *(*)()) F656_6085;
	R5693[169] = (char *(*)()) F645_6085;
	R5693[170] = (char *(*)()) F649_6085;
	R5693[171] = (char *(*)()) F647_6085;
	R5693[176] = (char *(*)()) F645_6085;
	R5693[177] = (char *(*)()) F647_6085;
	{long i; for (i = 178; i < 182; i++) R5693[i] = (char *(*)()) F645_6085;}
	{long i; for (i = 187; i < 189; i++) R5693[i] = (char *(*)()) F645_6085;}
	{long i; for (i = 192; i < 194; i++) R5693[i] = (char *(*)()) F645_6085;}
	{long i; for (i = 196; i < 201; i++) R5693[i] = (char *(*)()) F645_6085;}
	{long i; for (i = 525; i < 528; i++) R5693[i] = (char *(*)()) F645_6085;}
	R5693[568] = (char *(*)()) F645_6085;
	R5693[575] = (char *(*)()) F645_6085;
	{long i; for (i = 578; i < 580; i++) R5693[i] = (char *(*)()) F645_6085;}
}

char *(*R5694[7])();
void R5694_init () {
	R5694[0] = (char *(*)()) F693_6137;
	R5694[1] = (char *(*)()) F694_6137;
	R5694[2] = (char *(*)()) F695_6137;
	{long i; for (i = 3; i < 5; i++) R5694[i] = (char *(*)()) F693_6137;}
	R5694[5] = (char *(*)()) F694_6137;
	R5694[6] = (char *(*)()) F695_6137;
}

char *(*R5699[7])();
void R5699_init () {
	R5699[0] = (char *(*)()) F693_6148;
	R5699[1] = (char *(*)()) F694_6148_5699_4;
	R5699[2] = (char *(*)()) F695_6148_5699_4;
	{long i; for (i = 3; i < 5; i++) R5699[i] = (char *(*)()) F693_6148;}
	R5699[5] = (char *(*)()) F694_6148_5699_4;
	R5699[6] = (char *(*)()) F695_6148_5699_4;
}
static void F694_6148_5699_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F694_6148(Current, *(EIF_BOOLEAN *)arg1);
}
static void F695_6148_5699_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F695_6148(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5700[44])();
void R5700_init () {
	R5700[0] = (char *(*)()) F850_6683;
	R5700[1] = (char *(*)()) F851_6683_5700_4;
	R5700[2] = (char *(*)()) F852_6683_5700_4;
	R5700[3] = (char *(*)()) F853_6683_5700_4;
	R5700[4] = (char *(*)()) F854_6683_5700_4;
	R5700[5] = (char *(*)()) F855_6683_5700_4;
	R5700[6] = (char *(*)()) F856_6683_5700_4;
	R5700[7] = (char *(*)()) F857_6683_5700_4;
	R5700[8] = (char *(*)()) F858_6683_5700_4;
	R5700[9] = (char *(*)()) F859_6683_5700_4;
	R5700[10] = (char *(*)()) F860_6683_5700_4;
	R5700[11] = (char *(*)()) F861_6683_5700_4;
	R5700[12] = (char *(*)()) F850_6683;
	R5700[13] = (char *(*)()) F854_6683_5700_4;
	R5700[14] = (char *(*)()) F852_6683_5700_4;
	R5700[19] = (char *(*)()) F865_6726;
	R5700[20] = (char *(*)()) F866_6726_5700_4;
	{long i; for (i = 21; i < 25; i++) R5700[i] = (char *(*)()) F865_6726;}
	{long i; for (i = 30; i < 32; i++) R5700[i] = (char *(*)()) F865_6726;}
	{long i; for (i = 35; i < 37; i++) R5700[i] = (char *(*)()) F865_6726;}
	{long i; for (i = 39; i < 44; i++) R5700[i] = (char *(*)()) F865_6726;}
}
static void F851_6683_5700_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F851_6683(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F852_6683_5700_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F852_6683(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F853_6683_5700_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F853_6683(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F854_6683_5700_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F854_6683(Current, *(EIF_BOOLEAN *)arg1);
}
static void F855_6683_5700_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F855_6683(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F856_6683_5700_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F856_6683(Current, *(EIF_POINTER *)arg1);
}
static void F857_6683_5700_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F857_6683(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F858_6683_5700_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F858_6683(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F859_6683_5700_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F859_6683(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F860_6683_5700_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F860_6683(Current, *(EIF_REAL_32 *)arg1);
}
static void F861_6683_5700_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F861_6683(Current, *(EIF_REAL_64 *)arg1);
}
static void F866_6726_5700_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F866_6726(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5705[7])();
void R5705_init () {
	R5705[0] = (char *(*)()) F693_6157;
	R5705[1] = (char *(*)()) F694_6157;
	R5705[2] = (char *(*)()) F695_6157;
	{long i; for (i = 3; i < 5; i++) R5705[i] = (char *(*)()) F693_6157;}
	R5705[5] = (char *(*)()) F694_6157;
	R5705[6] = (char *(*)()) F695_6157;
}

char *(*R5710[7])();
void R5710_init () {
	R5710[0] = (char *(*)()) F693_6161;
	R5710[1] = (char *(*)()) F694_6161_5710_5;
	R5710[2] = (char *(*)()) F695_6161_5710_5;
	{long i; for (i = 3; i < 5; i++) R5710[i] = (char *(*)()) F693_6161;}
	R5710[5] = (char *(*)()) F694_6161_5710_5;
	R5710[6] = (char *(*)()) F695_6161_5710_5;
}
static EIF_REFERENCE F694_6161_5710_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F694_6161(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_REFERENCE F695_6161_5710_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F695_6161(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5711[7])();
void R5711_init () {
	R5711[0] = (char *(*)()) F693_6162;
	R5711[1] = (char *(*)()) F694_6162;
	R5711[2] = (char *(*)()) F695_6162;
	{long i; for (i = 3; i < 5; i++) R5711[i] = (char *(*)()) F693_6162;}
	R5711[5] = (char *(*)()) F694_6162;
	R5711[6] = (char *(*)()) F695_6162;
}

char *(*R5714[7])();
void R5714_init () {
	R5714[0] = (char *(*)()) F693_6165;
	R5714[1] = (char *(*)()) F694_6165;
	R5714[2] = (char *(*)()) F695_6165;
	{long i; for (i = 3; i < 5; i++) R5714[i] = (char *(*)()) F693_6165;}
	R5714[5] = (char *(*)()) F694_6165;
	R5714[6] = (char *(*)()) F695_6165;
}

char *(*R5715[7])();
void R5715_init () {
	R5715[0] = (char *(*)()) F693_6166;
	R5715[1] = (char *(*)()) F694_6166;
	R5715[2] = (char *(*)()) F695_6166;
	{long i; for (i = 3; i < 5; i++) R5715[i] = (char *(*)()) F693_6166;}
	R5715[5] = (char *(*)()) F694_6166;
	R5715[6] = (char *(*)()) F695_6166;
}

char *(*R5716[7])();
void R5716_init () {
	R5716[0] = (char *(*)()) F693_6167;
	R5716[1] = (char *(*)()) F694_6167;
	R5716[2] = (char *(*)()) F695_6167;
	{long i; for (i = 3; i < 5; i++) R5716[i] = (char *(*)()) F693_6167;}
	R5716[5] = (char *(*)()) F694_6167;
	R5716[6] = (char *(*)()) F695_6167;
}

char *(*R5726[3])();
void R5726_init () {
	R5726[0] = (char *(*)()) F693_6124;
	R5726[1] = (char *(*)()) F694_6124_5726_1;
	R5726[2] = (char *(*)()) F695_6124_5726_1;
}
static EIF_REFERENCE F694_6124_5726_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F694_6124(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F695_6124_5726_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F695_6124(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5727[3])();
void R5727_init () {
	R5727[0] = (char *(*)()) F693_6155;
	R5727[1] = (char *(*)()) F694_6155;
	R5727[2] = (char *(*)()) F695_6155;
}

char *(*R5732[12])();
void R5732_init () {
	R5732[0] = (char *(*)()) F700_6205;
	R5732[1] = (char *(*)()) F701_6205;
	R5732[2] = (char *(*)()) F702_6205;
	R5732[3] = (char *(*)()) F703_6205;
	R5732[4] = (char *(*)()) F704_6205;
	R5732[5] = (char *(*)()) F705_6205;
	R5732[6] = (char *(*)()) F706_6205;
	R5732[7] = (char *(*)()) F707_6205;
	R5732[8] = (char *(*)()) F708_6205;
	R5732[9] = (char *(*)()) F709_6205;
	R5732[10] = (char *(*)()) F710_6205;
	R5732[11] = (char *(*)()) F711_6205;
}

char *(*R5756[12])();
void R5756_init () {
	R5756[0] = (char *(*)()) F700_6247;
	R5756[1] = (char *(*)()) F701_6247_5756_41;
	R5756[2] = (char *(*)()) F702_6247_5756_41;
	R5756[3] = (char *(*)()) F703_6247_5756_41;
	R5756[4] = (char *(*)()) F704_6247_5756_41;
	R5756[5] = (char *(*)()) F705_6247_5756_41;
	R5756[6] = (char *(*)()) F706_6247_5756_41;
	R5756[7] = (char *(*)()) F707_6247_5756_41;
	R5756[8] = (char *(*)()) F708_6247_5756_41;
	R5756[9] = (char *(*)()) F709_6247_5756_41;
	R5756[10] = (char *(*)()) F710_6247_5756_41;
	R5756[11] = (char *(*)()) F711_6247_5756_41;
}
static void F701_6247_5756_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F701_6247(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F702_6247_5756_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F702_6247(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F703_6247_5756_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F703_6247(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F704_6247_5756_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F704_6247(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F705_6247_5756_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F705_6247(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F706_6247_5756_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F706_6247(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F707_6247_5756_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F707_6247(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F708_6247_5756_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F708_6247(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F709_6247_5756_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F709_6247(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F710_6247_5756_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F710_6247(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F711_6247_5756_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F711_6247(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R5763[12])();
void R5763_init () {
	R5763[0] = (char *(*)()) F700_6259;
	R5763[1] = (char *(*)()) F701_6259;
	R5763[2] = (char *(*)()) F702_6259;
	R5763[3] = (char *(*)()) F703_6259;
	R5763[4] = (char *(*)()) F704_6259;
	R5763[5] = (char *(*)()) F705_6259;
	R5763[6] = (char *(*)()) F706_6259;
	R5763[7] = (char *(*)()) F707_6259;
	R5763[8] = (char *(*)()) F708_6259;
	R5763[9] = (char *(*)()) F709_6259;
	R5763[10] = (char *(*)()) F710_6259;
	R5763[11] = (char *(*)()) F711_6259;
}

char *(*R5789[782])();
void R5789_init () {
	R5789[0] = (char *(*)()) F731_6287;
	R5789[1] = (char *(*)()) F549_5939_5789_1;
	R5789[6] = (char *(*)()) F549_5939_5789_1;
	R5789[37] = (char *(*)()) F756_6388;
	R5789[38] = (char *(*)()) F757_6388_5789_1;
	R5789[39] = (char *(*)()) F758_6388_5789_1;
	R5789[40] = (char *(*)()) F759_6388_5789_1;
	R5789[41] = (char *(*)()) F760_6388_5789_1;
	R5789[42] = (char *(*)()) F761_6388_5789_1;
	R5789[43] = (char *(*)()) F762_6388_5789_1;
	R5789[44] = (char *(*)()) F763_6388_5789_1;
	R5789[45] = (char *(*)()) F764_6388_5789_1;
	R5789[46] = (char *(*)()) F765_6388_5789_1;
	R5789[47] = (char *(*)()) F766_6388_5789_1;
	R5789[48] = (char *(*)()) F767_6388_5789_1;
	R5789[49] = (char *(*)()) F780_6416;
	R5789[50] = (char *(*)()) F781_6416_5789_1;
	R5789[51] = (char *(*)()) F782_6416_5789_1;
	R5789[52] = (char *(*)()) F783_6422;
	R5789[53] = (char *(*)()) F784_6422_5789_1;
	R5789[54] = (char *(*)()) F785_6422_5789_1;
	R5789[55] = (char *(*)()) F786_6422;
	R5789[56] = (char *(*)()) F787_6422_5789_1;
	R5789[57] = (char *(*)()) F788_6422_5789_1;
	R5789[70] = (char *(*)()) F789_6428;
	R5789[71] = (char *(*)()) F790_6428_5789_1;
	R5789[72] = (char *(*)()) F791_6428_5789_1;
	R5789[73] = (char *(*)()) F792_6428_5789_1;
	R5789[74] = (char *(*)()) F793_6428_5789_1;
	R5789[75] = (char *(*)()) F794_6428_5789_1;
	R5789[76] = (char *(*)()) F795_6428_5789_1;
	R5789[77] = (char *(*)()) F796_6428_5789_1;
	R5789[78] = (char *(*)()) F797_6428_5789_1;
	R5789[79] = (char *(*)()) F798_6428_5789_1;
	R5789[80] = (char *(*)()) F799_6428_5789_1;
	R5789[81] = (char *(*)()) F800_6428_5789_1;
	R5789[82] = (char *(*)()) F797_6428_5789_1;
	R5789[83] = (char *(*)()) F796_6428_5789_1;
	R5789[84] = (char *(*)()) F789_6428;
	R5789[85] = (char *(*)()) F790_6428_5789_1;
	R5789[86] = (char *(*)()) F791_6428_5789_1;
	R5789[87] = (char *(*)()) F792_6428_5789_1;
	R5789[88] = (char *(*)()) F793_6428_5789_1;
	R5789[89] = (char *(*)()) F794_6428_5789_1;
	R5789[90] = (char *(*)()) F795_6428_5789_1;
	R5789[91] = (char *(*)()) F796_6428_5789_1;
	R5789[92] = (char *(*)()) F797_6428_5789_1;
	R5789[93] = (char *(*)()) F798_6428_5789_1;
	R5789[94] = (char *(*)()) F799_6428_5789_1;
	R5789[95] = (char *(*)()) F800_6428_5789_1;
	R5789[96] = (char *(*)()) F789_6428;
	R5789[97] = (char *(*)()) F790_6428_5789_1;
	R5789[98] = (char *(*)()) F791_6428_5789_1;
	R5789[99] = (char *(*)()) F792_6428_5789_1;
	R5789[100] = (char *(*)()) F793_6428_5789_1;
	R5789[101] = (char *(*)()) F794_6428_5789_1;
	R5789[102] = (char *(*)()) F795_6428_5789_1;
	R5789[103] = (char *(*)()) F796_6428_5789_1;
	R5789[104] = (char *(*)()) F797_6428_5789_1;
	R5789[105] = (char *(*)()) F798_6428_5789_1;
	R5789[106] = (char *(*)()) F799_6428_5789_1;
	R5789[107] = (char *(*)()) F800_6428_5789_1;
	R5789[263] = (char *(*)()) F994_7498_5789_1;
	R5789[775] = (char *(*)()) F1483_15147;
	R5789[780] = (char *(*)()) F1485_15147_5789_1;
	R5789[781] = (char *(*)()) F1486_15147_5789_1;
}
static EIF_REFERENCE F549_5939_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F549_5939(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F757_6388_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F757_6388(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1079, 0x00).id, 1079, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F758_6388_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F758_6388(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F759_6388_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F759_6388(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1076, 0x00).id, 1076, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F760_6388_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F760_6388(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F761_6388_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F761_6388(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F762_6388_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F762_6388(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F763_6388_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F763_6388(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F764_6388_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F764_6388(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F765_6388_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F765_6388(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F766_6388_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F766_6388(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F767_6388_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F767_6388(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F781_6416_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F781_6416(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F782_6416_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F782_6416(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F784_6422_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F784_6422(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F785_6422_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F785_6422(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F787_6422_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F787_6422(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F788_6422_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F788_6422(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F790_6428_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F790_6428(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1079, 0x00).id, 1079, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F791_6428_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F791_6428(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F792_6428_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F792_6428(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1076, 0x00).id, 1076, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F793_6428_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F793_6428(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F794_6428_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F794_6428(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F795_6428_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F795_6428(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F796_6428_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F796_6428(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F797_6428_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F797_6428(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F798_6428_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F798_6428(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F799_6428_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F799_6428(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F800_6428_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F800_6428(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F994_7498_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F994_7498(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1485_15147_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1485_15147(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1076, 0x00).id, 1076, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1486_15147_5789_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1486_15147(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5790[782])();
void R5790_init () {
	R5790[0] = (char *(*)()) F731_6288;
	R5790[1] = (char *(*)()) F549_5940;
	R5790[6] = (char *(*)()) F549_5940;
	R5790[37] = (char *(*)()) F768_6406;
	R5790[38] = (char *(*)()) F769_6406;
	R5790[39] = (char *(*)()) F770_6406;
	R5790[40] = (char *(*)()) F771_6406;
	R5790[41] = (char *(*)()) F772_6406;
	R5790[42] = (char *(*)()) F773_6406;
	R5790[43] = (char *(*)()) F774_6406;
	R5790[44] = (char *(*)()) F775_6406;
	R5790[45] = (char *(*)()) F776_6406;
	R5790[46] = (char *(*)()) F777_6406;
	R5790[47] = (char *(*)()) F778_6406;
	R5790[48] = (char *(*)()) F779_6406;
	R5790[49] = (char *(*)()) F780_6417;
	R5790[50] = (char *(*)()) F781_6417;
	R5790[51] = (char *(*)()) F782_6417;
	R5790[52] = (char *(*)()) F783_6425;
	R5790[53] = (char *(*)()) F784_6425;
	R5790[54] = (char *(*)()) F785_6425;
	R5790[55] = (char *(*)()) F786_6425;
	R5790[56] = (char *(*)()) F787_6425;
	R5790[57] = (char *(*)()) F788_6425;
	R5790[70] = (char *(*)()) F789_6437;
	R5790[71] = (char *(*)()) F790_6437;
	R5790[72] = (char *(*)()) F791_6437;
	R5790[73] = (char *(*)()) F792_6437;
	R5790[74] = (char *(*)()) F793_6437;
	R5790[75] = (char *(*)()) F794_6437;
	R5790[76] = (char *(*)()) F795_6437;
	R5790[77] = (char *(*)()) F796_6437;
	R5790[78] = (char *(*)()) F797_6437;
	R5790[79] = (char *(*)()) F798_6437;
	R5790[80] = (char *(*)()) F799_6437;
	R5790[81] = (char *(*)()) F800_6437;
	R5790[82] = (char *(*)()) F797_6437;
	R5790[83] = (char *(*)()) F796_6437;
	R5790[84] = (char *(*)()) F789_6437;
	R5790[85] = (char *(*)()) F790_6437;
	R5790[86] = (char *(*)()) F791_6437;
	R5790[87] = (char *(*)()) F792_6437;
	R5790[88] = (char *(*)()) F793_6437;
	R5790[89] = (char *(*)()) F794_6437;
	R5790[90] = (char *(*)()) F795_6437;
	R5790[91] = (char *(*)()) F796_6437;
	R5790[92] = (char *(*)()) F797_6437;
	R5790[93] = (char *(*)()) F798_6437;
	R5790[94] = (char *(*)()) F799_6437;
	R5790[95] = (char *(*)()) F800_6437;
	R5790[96] = (char *(*)()) F789_6437;
	R5790[97] = (char *(*)()) F790_6437;
	R5790[98] = (char *(*)()) F791_6437;
	R5790[99] = (char *(*)()) F792_6437;
	R5790[100] = (char *(*)()) F793_6437;
	R5790[101] = (char *(*)()) F794_6437;
	R5790[102] = (char *(*)()) F795_6437;
	R5790[103] = (char *(*)()) F796_6437;
	R5790[104] = (char *(*)()) F797_6437;
	R5790[105] = (char *(*)()) F798_6437;
	R5790[106] = (char *(*)()) F799_6437;
	R5790[107] = (char *(*)()) F800_6437;
	R5790[263] = (char *(*)()) F994_7500;
	R5790[775] = (char *(*)()) F1506_15226;
	R5790[780] = (char *(*)()) F1500_15191;
	R5790[781] = (char *(*)()) F1501_15191;
}

char *(*R5791[782])();
void R5791_init () {
	R5791[0] = (char *(*)()) F731_6289;
	R5791[1] = (char *(*)()) F549_5946;
	R5791[6] = (char *(*)()) F549_5946;
	R5791[37] = (char *(*)()) F768_6414;
	R5791[38] = (char *(*)()) F769_6414;
	R5791[39] = (char *(*)()) F770_6414;
	R5791[40] = (char *(*)()) F771_6414;
	R5791[41] = (char *(*)()) F772_6414;
	R5791[42] = (char *(*)()) F773_6414;
	R5791[43] = (char *(*)()) F774_6414;
	R5791[44] = (char *(*)()) F775_6414;
	R5791[45] = (char *(*)()) F776_6414;
	R5791[46] = (char *(*)()) F777_6414;
	R5791[47] = (char *(*)()) F778_6414;
	R5791[48] = (char *(*)()) F779_6414;
	R5791[49] = (char *(*)()) F780_6419;
	R5791[50] = (char *(*)()) F781_6419;
	R5791[51] = (char *(*)()) F782_6419;
	R5791[52] = (char *(*)()) F783_6426;
	R5791[53] = (char *(*)()) F784_6426;
	R5791[54] = (char *(*)()) F785_6426;
	R5791[55] = (char *(*)()) F786_6426;
	R5791[56] = (char *(*)()) F787_6426;
	R5791[57] = (char *(*)()) F788_6426;
	R5791[70] = (char *(*)()) F789_6443;
	R5791[71] = (char *(*)()) F790_6443;
	R5791[72] = (char *(*)()) F791_6443;
	R5791[73] = (char *(*)()) F792_6443;
	R5791[74] = (char *(*)()) F793_6443;
	R5791[75] = (char *(*)()) F794_6443;
	R5791[76] = (char *(*)()) F795_6443;
	R5791[77] = (char *(*)()) F796_6443;
	R5791[78] = (char *(*)()) F797_6443;
	R5791[79] = (char *(*)()) F798_6443;
	R5791[80] = (char *(*)()) F799_6443;
	R5791[81] = (char *(*)()) F800_6443;
	R5791[82] = (char *(*)()) F797_6443;
	R5791[83] = (char *(*)()) F796_6443;
	R5791[84] = (char *(*)()) F789_6443;
	R5791[85] = (char *(*)()) F790_6443;
	R5791[86] = (char *(*)()) F791_6443;
	R5791[87] = (char *(*)()) F792_6443;
	R5791[88] = (char *(*)()) F793_6443;
	R5791[89] = (char *(*)()) F794_6443;
	R5791[90] = (char *(*)()) F795_6443;
	R5791[91] = (char *(*)()) F796_6443;
	R5791[92] = (char *(*)()) F797_6443;
	R5791[93] = (char *(*)()) F798_6443;
	R5791[94] = (char *(*)()) F799_6443;
	R5791[95] = (char *(*)()) F800_6443;
	R5791[96] = (char *(*)()) F789_6443;
	R5791[97] = (char *(*)()) F790_6443;
	R5791[98] = (char *(*)()) F791_6443;
	R5791[99] = (char *(*)()) F792_6443;
	R5791[100] = (char *(*)()) F793_6443;
	R5791[101] = (char *(*)()) F794_6443;
	R5791[102] = (char *(*)()) F795_6443;
	R5791[103] = (char *(*)()) F796_6443;
	R5791[104] = (char *(*)()) F797_6443;
	R5791[105] = (char *(*)()) F798_6443;
	R5791[106] = (char *(*)()) F799_6443;
	R5791[107] = (char *(*)()) F800_6443;
	R5791[263] = (char *(*)()) F994_7501;
	R5791[775] = (char *(*)()) F1488_15166;
	R5791[780] = (char *(*)()) F1490_15166;
	R5791[781] = (char *(*)()) F1491_15166;
}

static EIF_TYPE_INDEX Y5792_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype13[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype16[] = {0xFF01,49,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype17[] = {1055,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype18[] = {1067,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype94[] = {1055,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype95[] = {1058,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype120[] = {1058,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype129[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype130[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5792_pgtype142[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5792_gen_type [794];
EIF_TYPE_INDEX Y5792 [794];
void Y5792_init (void)
{
	egc_routines_types [5792] = Y5792;
	egc_routines_gen_types [5792] = Y5792_gen_type;
	egc_routines_offset [5792] = 718;
	Y5792_gen_type [0] = Y5792_pgtype0;
	Y5792_gen_type [1] = Y5792_pgtype1;
	Y5792_gen_type [2] = Y5792_pgtype2;
	Y5792_gen_type [3] = Y5792_pgtype3;
	Y5792_gen_type [4] = Y5792_pgtype4;
	Y5792_gen_type [5] = Y5792_pgtype5;
	Y5792_gen_type [6] = Y5792_pgtype6;
	Y5792_gen_type [7] = Y5792_pgtype7;
	Y5792_gen_type [8] = Y5792_pgtype8;
	Y5792_gen_type [9] = Y5792_pgtype9;
	Y5792_gen_type [10] = Y5792_pgtype10;
	Y5792_gen_type [11] = Y5792_pgtype11;
	Y5792_gen_type [12] = Y5792_pgtype12;
	Y5792_gen_type [13] = Y5792_pgtype13;
	Y5792_gen_type [14] = Y5792_pgtype14;
	Y5792_gen_type [15] = Y5792_pgtype15;
	Y5792_gen_type [16] = Y5792_pgtype16;
	Y5792_gen_type [17] = Y5792_pgtype17;
	Y5792_gen_type [18] = Y5792_pgtype18;
	Y5792_gen_type [19] = Y5792_pgtype19;
	Y5792_gen_type [20] = Y5792_pgtype20;
	Y5792_gen_type [21] = Y5792_pgtype21;
	Y5792_gen_type [22] = Y5792_pgtype22;
	Y5792_gen_type [23] = Y5792_pgtype23;
	Y5792_gen_type [24] = Y5792_pgtype24;
	Y5792_gen_type [25] = Y5792_pgtype25;
	Y5792_gen_type [26] = Y5792_pgtype26;
	Y5792_gen_type [27] = Y5792_pgtype27;
	Y5792_gen_type [28] = Y5792_pgtype28;
	Y5792_gen_type [29] = Y5792_pgtype29;
	Y5792_gen_type [30] = Y5792_pgtype30;
	Y5792_gen_type [31] = Y5792_pgtype31;
	Y5792_gen_type [32] = Y5792_pgtype32;
	Y5792_gen_type [33] = Y5792_pgtype33;
	Y5792_gen_type [34] = Y5792_pgtype34;
	Y5792_gen_type [35] = Y5792_pgtype35;
	Y5792_gen_type [36] = Y5792_pgtype36;
	Y5792_gen_type [37] = Y5792_pgtype37;
	Y5792_gen_type [38] = Y5792_pgtype38;
	Y5792_gen_type [39] = Y5792_pgtype39;
	Y5792_gen_type [40] = Y5792_pgtype40;
	Y5792_gen_type [41] = Y5792_pgtype41;
	Y5792_gen_type [42] = Y5792_pgtype42;
	Y5792_gen_type [43] = Y5792_pgtype43;
	Y5792_gen_type [44] = Y5792_pgtype44;
	Y5792_gen_type [45] = Y5792_pgtype45;
	Y5792_gen_type [46] = Y5792_pgtype46;
	Y5792_gen_type [47] = Y5792_pgtype47;
	Y5792_gen_type [48] = Y5792_pgtype48;
	Y5792_gen_type [49] = Y5792_pgtype49;
	Y5792_gen_type [50] = Y5792_pgtype50;
	Y5792_gen_type [51] = Y5792_pgtype51;
	Y5792_gen_type [52] = Y5792_pgtype52;
	Y5792_gen_type [53] = Y5792_pgtype53;
	Y5792_gen_type [54] = Y5792_pgtype54;
	Y5792_gen_type [55] = Y5792_pgtype55;
	Y5792_gen_type [56] = Y5792_pgtype56;
	Y5792_gen_type [57] = Y5792_pgtype57;
	Y5792_gen_type [58] = Y5792_pgtype58;
	Y5792_gen_type [59] = Y5792_pgtype59;
	Y5792_gen_type [60] = Y5792_pgtype60;
	Y5792_gen_type [61] = Y5792_pgtype61;
	Y5792_gen_type [62] = Y5792_pgtype62;
	Y5792_gen_type [63] = Y5792_pgtype63;
	Y5792_gen_type [64] = Y5792_pgtype64;
	Y5792_gen_type [65] = Y5792_pgtype65;
	Y5792_gen_type [66] = Y5792_pgtype66;
	Y5792_gen_type [67] = Y5792_pgtype67;
	Y5792_gen_type [68] = Y5792_pgtype68;
	Y5792_gen_type [69] = Y5792_pgtype69;
	Y5792_gen_type [70] = Y5792_pgtype70;
	Y5792_gen_type [71] = Y5792_pgtype71;
	Y5792_gen_type [72] = Y5792_pgtype72;
	Y5792_gen_type [73] = Y5792_pgtype73;
	Y5792_gen_type [74] = Y5792_pgtype74;
	Y5792_gen_type [75] = Y5792_pgtype75;
	Y5792_gen_type [76] = Y5792_pgtype76;
	Y5792_gen_type [77] = Y5792_pgtype77;
	Y5792_gen_type [78] = Y5792_pgtype78;
	Y5792_gen_type [79] = Y5792_pgtype79;
	Y5792_gen_type [80] = Y5792_pgtype80;
	Y5792_gen_type [81] = Y5792_pgtype81;
	Y5792_gen_type [82] = Y5792_pgtype82;
	Y5792_gen_type [83] = Y5792_pgtype83;
	Y5792_gen_type [84] = Y5792_pgtype84;
	Y5792_gen_type [85] = Y5792_pgtype85;
	Y5792_gen_type [86] = Y5792_pgtype86;
	Y5792_gen_type [87] = Y5792_pgtype87;
	Y5792_gen_type [88] = Y5792_pgtype88;
	Y5792_gen_type [89] = Y5792_pgtype89;
	Y5792_gen_type [90] = Y5792_pgtype90;
	Y5792_gen_type [91] = Y5792_pgtype91;
	Y5792_gen_type [92] = Y5792_pgtype92;
	Y5792_gen_type [93] = Y5792_pgtype93;
	Y5792_gen_type [94] = Y5792_pgtype94;
	Y5792_gen_type [95] = Y5792_pgtype95;
	Y5792_gen_type [96] = Y5792_pgtype96;
	Y5792_gen_type [97] = Y5792_pgtype97;
	Y5792_gen_type [98] = Y5792_pgtype98;
	Y5792_gen_type [99] = Y5792_pgtype99;
	Y5792_gen_type [100] = Y5792_pgtype100;
	Y5792_gen_type [101] = Y5792_pgtype101;
	Y5792_gen_type [102] = Y5792_pgtype102;
	Y5792_gen_type [103] = Y5792_pgtype103;
	Y5792_gen_type [104] = Y5792_pgtype104;
	Y5792_gen_type [105] = Y5792_pgtype105;
	Y5792_gen_type [106] = Y5792_pgtype106;
	Y5792_gen_type [107] = Y5792_pgtype107;
	Y5792_gen_type [108] = Y5792_pgtype108;
	Y5792_gen_type [109] = Y5792_pgtype109;
	Y5792_gen_type [110] = Y5792_pgtype110;
	Y5792_gen_type [111] = Y5792_pgtype111;
	Y5792_gen_type [112] = Y5792_pgtype112;
	Y5792_gen_type [113] = Y5792_pgtype113;
	Y5792_gen_type [114] = Y5792_pgtype114;
	Y5792_gen_type [115] = Y5792_pgtype115;
	Y5792_gen_type [116] = Y5792_pgtype116;
	Y5792_gen_type [117] = Y5792_pgtype117;
	Y5792_gen_type [118] = Y5792_pgtype118;
	Y5792_gen_type [119] = Y5792_pgtype119;
	Y5792_gen_type [275] = Y5792_pgtype120;
	Y5792_gen_type [769] = Y5792_pgtype121;
	Y5792_gen_type [770] = Y5792_pgtype122;
	Y5792_gen_type [771] = Y5792_pgtype123;
	Y5792_gen_type [772] = Y5792_pgtype124;
	Y5792_gen_type [773] = Y5792_pgtype125;
	Y5792_gen_type [774] = Y5792_pgtype126;
	Y5792_gen_type [775] = Y5792_pgtype127;
	Y5792_gen_type [776] = Y5792_pgtype128;
	Y5792_gen_type [777] = Y5792_pgtype129;
	Y5792_gen_type [778] = Y5792_pgtype130;
	Y5792_gen_type [779] = Y5792_pgtype131;
	Y5792_gen_type [780] = Y5792_pgtype132;
	Y5792_gen_type [781] = Y5792_pgtype133;
	Y5792_gen_type [782] = Y5792_pgtype134;
	Y5792_gen_type [786] = Y5792_pgtype135;
	Y5792_gen_type [787] = Y5792_pgtype136;
	Y5792_gen_type [788] = Y5792_pgtype137;
	Y5792_gen_type [789] = Y5792_pgtype138;
	Y5792_gen_type [790] = Y5792_pgtype139;
	Y5792_gen_type [791] = Y5792_pgtype140;
	Y5792_gen_type [792] = Y5792_pgtype141;
	Y5792_gen_type [793] = Y5792_pgtype142;
	Y5792[13] = 1067;
	Y5792[16] = 49;
	Y5792[17] = 1055;
	Y5792[18] = 1067;
	Y5792[94] = 1055;
	Y5792[95] = 1058;
	Y5792[275] = 1058;
}

char *(*R5849[6])();
void R5849_init () {
	R5849[0] = (char *(*)()) F783_6423;
	R5849[1] = (char *(*)()) F784_6423;
	R5849[2] = (char *(*)()) F785_6423_5849_1;
	R5849[3] = (char *(*)()) F786_6423_5849_1;
	R5849[4] = (char *(*)()) F787_6423_5849_1;
	R5849[5] = (char *(*)()) F788_6423;
}
static EIF_REFERENCE F785_6423_5849_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F785_6423(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1079, 0x00).id, 1079, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F786_6423_5849_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F786_6423(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F787_6423_5849_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F787_6423(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5852[71])();
void R5852_init () {
	R5852[0] = (char *(*)()) F768_6396;
	R5852[1] = (char *(*)()) F769_6396;
	R5852[2] = (char *(*)()) F770_6396;
	R5852[3] = (char *(*)()) F771_6396;
	R5852[4] = (char *(*)()) F772_6396;
	R5852[5] = (char *(*)()) F773_6396;
	R5852[6] = (char *(*)()) F774_6396;
	R5852[7] = (char *(*)()) F775_6396;
	R5852[8] = (char *(*)()) F776_6396;
	R5852[9] = (char *(*)()) F777_6396;
	R5852[10] = (char *(*)()) F778_6396;
	R5852[11] = (char *(*)()) F779_6396;
	R5852[12] = (char *(*)()) F768_6396;
	R5852[13] = (char *(*)()) F774_6396;
	R5852[14] = (char *(*)()) F770_6396;
	R5852[15] = (char *(*)()) F768_6396;
	{long i; for (i = 16; i < 18; i++) R5852[i] = (char *(*)()) F770_6396;}
	R5852[18] = (char *(*)()) F768_6396;
	R5852[19] = (char *(*)()) F770_6396;
	R5852[20] = (char *(*)()) F775_6396;
	R5852[33] = (char *(*)()) F789_6430;
	R5852[34] = (char *(*)()) F790_6430;
	R5852[35] = (char *(*)()) F791_6430;
	R5852[36] = (char *(*)()) F792_6430;
	R5852[37] = (char *(*)()) F793_6430;
	R5852[38] = (char *(*)()) F794_6430;
	R5852[39] = (char *(*)()) F795_6430;
	R5852[40] = (char *(*)()) F796_6430;
	R5852[41] = (char *(*)()) F797_6430;
	R5852[42] = (char *(*)()) F798_6430;
	R5852[43] = (char *(*)()) F799_6430;
	R5852[44] = (char *(*)()) F800_6430;
	R5852[45] = (char *(*)()) F797_6430;
	R5852[46] = (char *(*)()) F796_6430;
	R5852[47] = (char *(*)()) F789_6430;
	R5852[48] = (char *(*)()) F790_6430;
	R5852[49] = (char *(*)()) F791_6430;
	R5852[50] = (char *(*)()) F792_6430;
	R5852[51] = (char *(*)()) F793_6430;
	R5852[52] = (char *(*)()) F794_6430;
	R5852[53] = (char *(*)()) F795_6430;
	R5852[54] = (char *(*)()) F796_6430;
	R5852[55] = (char *(*)()) F797_6430;
	R5852[56] = (char *(*)()) F798_6430;
	R5852[57] = (char *(*)()) F799_6430;
	R5852[58] = (char *(*)()) F800_6430;
	R5852[59] = (char *(*)()) F789_6430;
	R5852[60] = (char *(*)()) F790_6430;
	R5852[61] = (char *(*)()) F791_6430;
	R5852[62] = (char *(*)()) F792_6430;
	R5852[63] = (char *(*)()) F793_6430;
	R5852[64] = (char *(*)()) F794_6430;
	R5852[65] = (char *(*)()) F795_6430;
	R5852[66] = (char *(*)()) F796_6430;
	R5852[67] = (char *(*)()) F797_6430;
	R5852[68] = (char *(*)()) F798_6430;
	R5852[69] = (char *(*)()) F799_6430;
	R5852[70] = (char *(*)()) F800_6430;
}

char *(*R5853[71])();
void R5853_init () {
	R5853[0] = (char *(*)()) F768_6397;
	R5853[1] = (char *(*)()) F769_6397;
	R5853[2] = (char *(*)()) F770_6397;
	R5853[3] = (char *(*)()) F771_6397;
	R5853[4] = (char *(*)()) F772_6397;
	R5853[5] = (char *(*)()) F773_6397;
	R5853[6] = (char *(*)()) F774_6397;
	R5853[7] = (char *(*)()) F775_6397;
	R5853[8] = (char *(*)()) F776_6397;
	R5853[9] = (char *(*)()) F777_6397;
	R5853[10] = (char *(*)()) F778_6397;
	R5853[11] = (char *(*)()) F779_6397;
	R5853[12] = (char *(*)()) F768_6397;
	R5853[13] = (char *(*)()) F774_6397;
	R5853[14] = (char *(*)()) F770_6397;
	R5853[15] = (char *(*)()) F768_6397;
	{long i; for (i = 16; i < 18; i++) R5853[i] = (char *(*)()) F770_6397;}
	R5853[18] = (char *(*)()) F768_6397;
	R5853[19] = (char *(*)()) F770_6397;
	R5853[20] = (char *(*)()) F775_6397;
	R5853[33] = (char *(*)()) F801_6449;
	R5853[34] = (char *(*)()) F802_6449;
	R5853[35] = (char *(*)()) F803_6449;
	R5853[36] = (char *(*)()) F804_6449;
	R5853[37] = (char *(*)()) F805_6449;
	R5853[38] = (char *(*)()) F806_6449;
	R5853[39] = (char *(*)()) F807_6449;
	R5853[40] = (char *(*)()) F808_6449;
	R5853[41] = (char *(*)()) F809_6449;
	R5853[42] = (char *(*)()) F810_6449;
	R5853[43] = (char *(*)()) F811_6449;
	R5853[44] = (char *(*)()) F812_6449;
	R5853[45] = (char *(*)()) F813_6455;
	R5853[46] = (char *(*)()) F814_6461;
	R5853[47] = (char *(*)()) F815_6467;
	R5853[48] = (char *(*)()) F816_6467;
	R5853[49] = (char *(*)()) F817_6467;
	R5853[50] = (char *(*)()) F818_6467;
	R5853[51] = (char *(*)()) F819_6467;
	R5853[52] = (char *(*)()) F820_6467;
	R5853[53] = (char *(*)()) F821_6467;
	R5853[54] = (char *(*)()) F822_6467;
	R5853[55] = (char *(*)()) F823_6467;
	R5853[56] = (char *(*)()) F824_6467;
	R5853[57] = (char *(*)()) F825_6467;
	R5853[58] = (char *(*)()) F826_6467;
	R5853[59] = (char *(*)()) F827_6473;
	R5853[60] = (char *(*)()) F828_6473;
	R5853[61] = (char *(*)()) F829_6473;
	R5853[62] = (char *(*)()) F830_6473;
	R5853[63] = (char *(*)()) F831_6473;
	R5853[64] = (char *(*)()) F832_6473;
	R5853[65] = (char *(*)()) F833_6473;
	R5853[66] = (char *(*)()) F834_6473;
	R5853[67] = (char *(*)()) F835_6473;
	R5853[68] = (char *(*)()) F836_6473;
	R5853[69] = (char *(*)()) F837_6473;
	R5853[70] = (char *(*)()) F838_6473;
}

char *(*R5861[21])();
void R5861_init () {
	R5861[0] = (char *(*)()) F768_6408;
	R5861[1] = (char *(*)()) F769_6408;
	R5861[2] = (char *(*)()) F770_6408;
	R5861[3] = (char *(*)()) F771_6408;
	R5861[4] = (char *(*)()) F772_6408;
	R5861[5] = (char *(*)()) F773_6408;
	R5861[6] = (char *(*)()) F774_6408;
	R5861[7] = (char *(*)()) F775_6408;
	R5861[8] = (char *(*)()) F776_6408;
	R5861[9] = (char *(*)()) F777_6408;
	R5861[10] = (char *(*)()) F778_6408;
	R5861[11] = (char *(*)()) F779_6408;
	R5861[12] = (char *(*)()) F768_6408;
	R5861[13] = (char *(*)()) F774_6408;
	R5861[14] = (char *(*)()) F770_6408;
	R5861[15] = (char *(*)()) F768_6408;
	{long i; for (i = 16; i < 18; i++) R5861[i] = (char *(*)()) F770_6408;}
	R5861[18] = (char *(*)()) F768_6408;
	R5861[19] = (char *(*)()) F770_6408;
	R5861[20] = (char *(*)()) F775_6408;
}

char *(*R5864[71])();
void R5864_init () {
	R5864[0] = (char *(*)()) F768_6413;
	R5864[1] = (char *(*)()) F769_6413;
	R5864[2] = (char *(*)()) F770_6413;
	R5864[3] = (char *(*)()) F771_6413;
	R5864[4] = (char *(*)()) F772_6413;
	R5864[5] = (char *(*)()) F773_6413;
	R5864[6] = (char *(*)()) F774_6413;
	R5864[7] = (char *(*)()) F775_6413;
	R5864[8] = (char *(*)()) F776_6413;
	R5864[9] = (char *(*)()) F777_6413;
	R5864[10] = (char *(*)()) F778_6413;
	R5864[11] = (char *(*)()) F779_6413;
	R5864[12] = (char *(*)()) F780_6418;
	R5864[13] = (char *(*)()) F781_6418;
	R5864[14] = (char *(*)()) F782_6418;
	R5864[15] = (char *(*)()) F768_6413;
	{long i; for (i = 16; i < 18; i++) R5864[i] = (char *(*)()) F770_6413;}
	R5864[18] = (char *(*)()) F768_6413;
	R5864[19] = (char *(*)()) F770_6413;
	R5864[20] = (char *(*)()) F775_6413;
	R5864[33] = (char *(*)()) F789_6442;
	R5864[34] = (char *(*)()) F790_6442;
	R5864[35] = (char *(*)()) F791_6442;
	R5864[36] = (char *(*)()) F792_6442;
	R5864[37] = (char *(*)()) F793_6442;
	R5864[38] = (char *(*)()) F794_6442;
	R5864[39] = (char *(*)()) F795_6442;
	R5864[40] = (char *(*)()) F796_6442;
	R5864[41] = (char *(*)()) F797_6442;
	R5864[42] = (char *(*)()) F798_6442;
	R5864[43] = (char *(*)()) F799_6442;
	R5864[44] = (char *(*)()) F800_6442;
	R5864[45] = (char *(*)()) F797_6442;
	R5864[46] = (char *(*)()) F796_6442;
	R5864[47] = (char *(*)()) F789_6442;
	R5864[48] = (char *(*)()) F790_6442;
	R5864[49] = (char *(*)()) F791_6442;
	R5864[50] = (char *(*)()) F792_6442;
	R5864[51] = (char *(*)()) F793_6442;
	R5864[52] = (char *(*)()) F794_6442;
	R5864[53] = (char *(*)()) F795_6442;
	R5864[54] = (char *(*)()) F796_6442;
	R5864[55] = (char *(*)()) F797_6442;
	R5864[56] = (char *(*)()) F798_6442;
	R5864[57] = (char *(*)()) F799_6442;
	R5864[58] = (char *(*)()) F800_6442;
	R5864[59] = (char *(*)()) F789_6442;
	R5864[60] = (char *(*)()) F790_6442;
	R5864[61] = (char *(*)()) F791_6442;
	R5864[62] = (char *(*)()) F792_6442;
	R5864[63] = (char *(*)()) F793_6442;
	R5864[64] = (char *(*)()) F794_6442;
	R5864[65] = (char *(*)()) F795_6442;
	R5864[66] = (char *(*)()) F796_6442;
	R5864[67] = (char *(*)()) F797_6442;
	R5864[68] = (char *(*)()) F798_6442;
	R5864[69] = (char *(*)()) F799_6442;
	R5864[70] = (char *(*)()) F800_6442;
}

char *(*R5865[71])();
void R5865_init () {
	R5865[0] = (char *(*)()) F768_6415;
	R5865[1] = (char *(*)()) F769_6415;
	R5865[2] = (char *(*)()) F770_6415;
	R5865[3] = (char *(*)()) F771_6415;
	R5865[4] = (char *(*)()) F772_6415;
	R5865[5] = (char *(*)()) F773_6415;
	R5865[6] = (char *(*)()) F774_6415;
	R5865[7] = (char *(*)()) F775_6415;
	R5865[8] = (char *(*)()) F776_6415;
	R5865[9] = (char *(*)()) F777_6415;
	R5865[10] = (char *(*)()) F778_6415;
	R5865[11] = (char *(*)()) F779_6415;
	R5865[12] = (char *(*)()) F780_6420;
	R5865[13] = (char *(*)()) F781_6420;
	R5865[14] = (char *(*)()) F782_6420;
	R5865[15] = (char *(*)()) F783_6427;
	R5865[16] = (char *(*)()) F784_6427;
	R5865[17] = (char *(*)()) F785_6427;
	R5865[18] = (char *(*)()) F786_6427;
	R5865[19] = (char *(*)()) F787_6427;
	R5865[20] = (char *(*)()) F788_6427;
	R5865[33] = (char *(*)()) F801_6452;
	R5865[34] = (char *(*)()) F802_6452;
	R5865[35] = (char *(*)()) F803_6452;
	R5865[36] = (char *(*)()) F804_6452;
	R5865[37] = (char *(*)()) F805_6452;
	R5865[38] = (char *(*)()) F806_6452;
	R5865[39] = (char *(*)()) F807_6452;
	R5865[40] = (char *(*)()) F808_6452;
	R5865[41] = (char *(*)()) F809_6452;
	R5865[42] = (char *(*)()) F810_6452;
	R5865[43] = (char *(*)()) F811_6452;
	R5865[44] = (char *(*)()) F812_6452;
	R5865[45] = (char *(*)()) F813_6458;
	R5865[46] = (char *(*)()) F814_6464;
	R5865[47] = (char *(*)()) F815_6470;
	R5865[48] = (char *(*)()) F816_6470;
	R5865[49] = (char *(*)()) F817_6470;
	R5865[50] = (char *(*)()) F818_6470;
	R5865[51] = (char *(*)()) F819_6470;
	R5865[52] = (char *(*)()) F820_6470;
	R5865[53] = (char *(*)()) F821_6470;
	R5865[54] = (char *(*)()) F822_6470;
	R5865[55] = (char *(*)()) F823_6470;
	R5865[56] = (char *(*)()) F824_6470;
	R5865[57] = (char *(*)()) F825_6470;
	R5865[58] = (char *(*)()) F826_6470;
	R5865[59] = (char *(*)()) F789_6444;
	R5865[60] = (char *(*)()) F790_6444;
	R5865[61] = (char *(*)()) F791_6444;
	R5865[62] = (char *(*)()) F792_6444;
	R5865[63] = (char *(*)()) F793_6444;
	R5865[64] = (char *(*)()) F794_6444;
	R5865[65] = (char *(*)()) F795_6444;
	R5865[66] = (char *(*)()) F796_6444;
	R5865[67] = (char *(*)()) F797_6444;
	R5865[68] = (char *(*)()) F798_6444;
	R5865[69] = (char *(*)()) F799_6444;
	R5865[70] = (char *(*)()) F800_6444;
}

char *(*R5867[21])();
void R5867_init () {
	R5867[0] = (char *(*)()) F768_6394;
	R5867[1] = (char *(*)()) F769_6394;
	R5867[2] = (char *(*)()) F770_6394;
	R5867[3] = (char *(*)()) F771_6394;
	R5867[4] = (char *(*)()) F772_6394;
	R5867[5] = (char *(*)()) F773_6394;
	R5867[6] = (char *(*)()) F774_6394;
	R5867[7] = (char *(*)()) F775_6394;
	R5867[8] = (char *(*)()) F776_6394;
	R5867[9] = (char *(*)()) F777_6394;
	R5867[10] = (char *(*)()) F778_6394;
	R5867[11] = (char *(*)()) F779_6394;
	R5867[12] = (char *(*)()) F768_6394;
	R5867[13] = (char *(*)()) F774_6394;
	R5867[14] = (char *(*)()) F770_6394;
	R5867[15] = (char *(*)()) F768_6394;
	{long i; for (i = 16; i < 18; i++) R5867[i] = (char *(*)()) F770_6394;}
	R5867[18] = (char *(*)()) F768_6394;
	R5867[19] = (char *(*)()) F770_6394;
	R5867[20] = (char *(*)()) F775_6394;
}

char *(*R5880[38])();
void R5880_init () {
	R5880[0] = (char *(*)()) F801_6453;
	R5880[1] = (char *(*)()) F802_6453;
	R5880[2] = (char *(*)()) F803_6453;
	R5880[3] = (char *(*)()) F804_6453;
	R5880[4] = (char *(*)()) F805_6453;
	R5880[5] = (char *(*)()) F806_6453;
	R5880[6] = (char *(*)()) F807_6453;
	R5880[7] = (char *(*)()) F808_6453;
	R5880[8] = (char *(*)()) F809_6453;
	R5880[9] = (char *(*)()) F810_6453;
	R5880[10] = (char *(*)()) F811_6453;
	R5880[11] = (char *(*)()) F812_6453;
	R5880[12] = (char *(*)()) F813_6459;
	R5880[13] = (char *(*)()) F814_6465;
	R5880[14] = (char *(*)()) F815_6471;
	R5880[15] = (char *(*)()) F816_6471;
	R5880[16] = (char *(*)()) F817_6471;
	R5880[17] = (char *(*)()) F818_6471;
	R5880[18] = (char *(*)()) F819_6471;
	R5880[19] = (char *(*)()) F820_6471;
	R5880[20] = (char *(*)()) F821_6471;
	R5880[21] = (char *(*)()) F822_6471;
	R5880[22] = (char *(*)()) F823_6471;
	R5880[23] = (char *(*)()) F824_6471;
	R5880[24] = (char *(*)()) F825_6471;
	R5880[25] = (char *(*)()) F826_6471;
	R5880[26] = (char *(*)()) F827_6475;
	R5880[27] = (char *(*)()) F828_6475;
	R5880[28] = (char *(*)()) F829_6475;
	R5880[29] = (char *(*)()) F830_6475;
	R5880[30] = (char *(*)()) F831_6475;
	R5880[31] = (char *(*)()) F832_6475;
	R5880[32] = (char *(*)()) F833_6475;
	R5880[33] = (char *(*)()) F834_6475;
	R5880[34] = (char *(*)()) F835_6475;
	R5880[35] = (char *(*)()) F836_6475;
	R5880[36] = (char *(*)()) F837_6475;
	R5880[37] = (char *(*)()) F838_6475;
}

char *(*R5882[12])();
void R5882_init () {
	R5882[0] = (char *(*)()) F801_6448;
	R5882[1] = (char *(*)()) F802_6448;
	R5882[2] = (char *(*)()) F803_6448;
	R5882[3] = (char *(*)()) F804_6448;
	R5882[4] = (char *(*)()) F805_6448;
	R5882[5] = (char *(*)()) F806_6448;
	R5882[6] = (char *(*)()) F807_6448;
	R5882[7] = (char *(*)()) F808_6448;
	R5882[8] = (char *(*)()) F809_6448;
	R5882[9] = (char *(*)()) F810_6448;
	R5882[10] = (char *(*)()) F811_6448;
	R5882[11] = (char *(*)()) F812_6448;
}

char *(*R5890[12])();
void R5890_init () {
	R5890[0] = (char *(*)()) F815_6466;
	R5890[1] = (char *(*)()) F816_6466;
	R5890[2] = (char *(*)()) F817_6466;
	R5890[3] = (char *(*)()) F818_6466;
	R5890[4] = (char *(*)()) F819_6466;
	R5890[5] = (char *(*)()) F820_6466;
	R5890[6] = (char *(*)()) F821_6466;
	R5890[7] = (char *(*)()) F822_6466;
	R5890[8] = (char *(*)()) F823_6466;
	R5890[9] = (char *(*)()) F824_6466;
	R5890[10] = (char *(*)()) F825_6466;
	R5890[11] = (char *(*)()) F826_6466;
}

char *(*R5893[12])();
void R5893_init () {
	R5893[0] = (char *(*)()) F827_6472;
	R5893[1] = (char *(*)()) F828_6472;
	R5893[2] = (char *(*)()) F829_6472;
	R5893[3] = (char *(*)()) F830_6472;
	R5893[4] = (char *(*)()) F831_6472;
	R5893[5] = (char *(*)()) F832_6472;
	R5893[6] = (char *(*)()) F833_6472;
	R5893[7] = (char *(*)()) F834_6472;
	R5893[8] = (char *(*)()) F835_6472;
	R5893[9] = (char *(*)()) F836_6472;
	R5893[10] = (char *(*)()) F837_6472;
	R5893[11] = (char *(*)()) F838_6472;
}

char *(*R5894[714])();
void R5894_init () {
	R5894[0] = (char *(*)()) F841_6569;
	R5894[1] = (char *(*)()) F842_6569;
	R5894[2] = (char *(*)()) F843_6569;
	R5894[3] = (char *(*)()) F844_6569;
	R5894[4] = (char *(*)()) F845_6569;
	R5894[5] = (char *(*)()) F846_6569;
	R5894[6] = (char *(*)()) F841_6569;
	R5894[7] = (char *(*)()) F842_6569;
	R5894[8] = (char *(*)()) F841_6569;
	R5894[9] = (char *(*)()) F850_6702;
	R5894[10] = (char *(*)()) F851_6702;
	R5894[11] = (char *(*)()) F852_6702;
	R5894[12] = (char *(*)()) F853_6702;
	R5894[13] = (char *(*)()) F854_6702;
	R5894[14] = (char *(*)()) F855_6702;
	R5894[15] = (char *(*)()) F856_6702;
	R5894[16] = (char *(*)()) F857_6702;
	R5894[17] = (char *(*)()) F858_6702;
	R5894[18] = (char *(*)()) F859_6702;
	R5894[19] = (char *(*)()) F860_6702;
	R5894[20] = (char *(*)()) F861_6702;
	R5894[21] = (char *(*)()) F850_6702;
	R5894[22] = (char *(*)()) F854_6702;
	R5894[23] = (char *(*)()) F852_6702;
	R5894[28] = (char *(*)()) F850_6702;
	R5894[29] = (char *(*)()) F852_6702;
	{long i; for (i = 30; i < 34; i++) R5894[i] = (char *(*)()) F850_6702;}
	{long i; for (i = 39; i < 41; i++) R5894[i] = (char *(*)()) F850_6702;}
	{long i; for (i = 44; i < 46; i++) R5894[i] = (char *(*)()) F850_6702;}
	{long i; for (i = 48; i < 53; i++) R5894[i] = (char *(*)()) F850_6702;}
	R5894[209] = (char *(*)()) F1050_8658;
	{long i; for (i = 283; i < 288; i++) R5894[i] = (char *(*)()) F1123_9749;}
	R5894[292] = (char *(*)()) F1133_9988;
	R5894[293] = (char *(*)()) F1134_10079;
	R5894[296] = (char *(*)()) F1137_10243;
	R5894[665] = (char *(*)()) F1506_15236;
	R5894[670] = (char *(*)()) F1500_15202;
	R5894[671] = (char *(*)()) F1501_15202;
	R5894[705] = (char *(*)()) F1546_15537;
	R5894[712] = (char *(*)()) F1551_15708;
	R5894[713] = (char *(*)()) F1552_15708;
}

char *(*R5906[9])();
void R5906_init () {
	R5906[0] = (char *(*)()) F841_6510;
	R5906[1] = (char *(*)()) F842_6510;
	R5906[2] = (char *(*)()) F843_6510;
	R5906[3] = (char *(*)()) F844_6510;
	R5906[4] = (char *(*)()) F845_6510;
	R5906[5] = (char *(*)()) F846_6510;
	R5906[6] = (char *(*)()) F841_6510;
	R5906[7] = (char *(*)()) F842_6510;
	R5906[8] = (char *(*)()) F841_6510;
}

char *(*R5909[9])();
void R5909_init () {
	R5909[0] = (char *(*)()) F841_6513;
	R5909[1] = (char *(*)()) F842_6513;
	R5909[2] = (char *(*)()) F843_6513;
	R5909[3] = (char *(*)()) F844_6513;
	R5909[4] = (char *(*)()) F845_6513;
	R5909[5] = (char *(*)()) F846_6513;
	R5909[6] = (char *(*)()) F841_6513;
	R5909[7] = (char *(*)()) F842_6513;
	R5909[8] = (char *(*)()) F841_6513;
}

char *(*R5910[9])();
void R5910_init () {
	R5910[0] = (char *(*)()) F841_6514;
	R5910[1] = (char *(*)()) F842_6514_5910_1;
	R5910[2] = (char *(*)()) F843_6514_5910_1;
	R5910[3] = (char *(*)()) F844_6514;
	R5910[4] = (char *(*)()) F845_6514_5910_1;
	R5910[5] = (char *(*)()) F846_6514_5910_1;
	R5910[6] = (char *(*)()) F841_6514;
	R5910[7] = (char *(*)()) F842_6514_5910_1;
	R5910[8] = (char *(*)()) F841_6514;
}
static EIF_REFERENCE F842_6514_5910_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F842_6514(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F843_6514_5910_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F843_6514(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F845_6514_5910_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F845_6514(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F846_6514_5910_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F846_6514(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R5911[9])();
void R5911_init () {
	R5911[0] = (char *(*)()) F841_6516;
	R5911[1] = (char *(*)()) F842_6516_5911_5;
	R5911[2] = (char *(*)()) F843_6516_5911_5;
	R5911[3] = (char *(*)()) F844_6516_5911_5;
	R5911[4] = (char *(*)()) F845_6516_5911_5;
	R5911[5] = (char *(*)()) F846_6516_5911_5;
	R5911[6] = (char *(*)()) F841_6516;
	R5911[7] = (char *(*)()) F842_6516_5911_5;
	R5911[8] = (char *(*)()) F841_6516;
}
static EIF_REFERENCE F842_6516_5911_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F842_6516(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F843_6516_5911_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F843_6516(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F844_6516_5911_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F844_6516(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F845_6516_5911_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F845_6516(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F846_6516_5911_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F846_6516(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R5913[9])();
void R5913_init () {
	R5913[0] = (char *(*)()) F841_6519;
	R5913[1] = (char *(*)()) F842_6519;
	R5913[2] = (char *(*)()) F843_6519_5913_2;
	R5913[3] = (char *(*)()) F844_6519_5913_2;
	R5913[4] = (char *(*)()) F845_6519_5913_2;
	R5913[5] = (char *(*)()) F846_6519;
	R5913[6] = (char *(*)()) F841_6519;
	R5913[7] = (char *(*)()) F842_6519;
	R5913[8] = (char *(*)()) F841_6519;
}
static EIF_BOOLEAN F843_6519_5913_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F843_6519(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F844_6519_5913_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F844_6519(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F845_6519_5913_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F845_6519(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5915[9])();
void R5915_init () {
	R5915[0] = (char *(*)()) F841_6522;
	R5915[1] = (char *(*)()) F842_6522_5915_1;
	R5915[2] = (char *(*)()) F843_6522_5915_1;
	R5915[3] = (char *(*)()) F844_6522;
	R5915[4] = (char *(*)()) F845_6522_5915_1;
	R5915[5] = (char *(*)()) F846_6522_5915_1;
	R5915[6] = (char *(*)()) F841_6522;
	R5915[7] = (char *(*)()) F842_6522_5915_1;
	R5915[8] = (char *(*)()) F841_6522;
}
static EIF_REFERENCE F842_6522_5915_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F842_6522(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F843_6522_5915_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F843_6522(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F845_6522_5915_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F845_6522(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F846_6522_5915_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F846_6522(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R5916[9])();
void R5916_init () {
	R5916[0] = (char *(*)()) F841_6523;
	R5916[1] = (char *(*)()) F842_6523;
	R5916[2] = (char *(*)()) F843_6523_5916_1;
	R5916[3] = (char *(*)()) F844_6523_5916_1;
	R5916[4] = (char *(*)()) F845_6523_5916_1;
	R5916[5] = (char *(*)()) F846_6523;
	R5916[6] = (char *(*)()) F841_6523;
	R5916[7] = (char *(*)()) F842_6523;
	R5916[8] = (char *(*)()) F841_6523;
}
static EIF_REFERENCE F843_6523_5916_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F843_6523(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1079, 0x00).id, 1079, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F844_6523_5916_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F844_6523(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F845_6523_5916_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F845_6523(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5918[9])();
void R5918_init () {
	R5918[0] = (char *(*)()) F841_6527;
	R5918[1] = (char *(*)()) F842_6527;
	R5918[2] = (char *(*)()) F843_6527_5918_104;
	R5918[3] = (char *(*)()) F844_6527_5918_104;
	R5918[4] = (char *(*)()) F845_6527_5918_104;
	R5918[5] = (char *(*)()) F846_6527;
	R5918[6] = (char *(*)()) F847_6624;
	R5918[7] = (char *(*)()) F848_6624;
	R5918[8] = (char *(*)()) F841_6527;
}
static EIF_INTEGER_32 F843_6527_5918_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F843_6527(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_INTEGER_32 F844_6527_5918_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F844_6527(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F845_6527_5918_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F845_6527(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5920[9])();
void R5920_init () {
	R5920[0] = (char *(*)()) F841_6534;
	R5920[1] = (char *(*)()) F842_6534;
	R5920[2] = (char *(*)()) F843_6534_5920_3;
	R5920[3] = (char *(*)()) F844_6534_5920_3;
	R5920[4] = (char *(*)()) F845_6534_5920_3;
	R5920[5] = (char *(*)()) F846_6534;
	R5920[6] = (char *(*)()) F847_6626;
	R5920[7] = (char *(*)()) F848_6626;
	R5920[8] = (char *(*)()) F841_6534;
}
static EIF_BOOLEAN F843_6534_5920_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F843_6534(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static EIF_BOOLEAN F844_6534_5920_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F844_6534(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F845_6534_5920_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F845_6534(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R5926[9])();
void R5926_init () {
	R5926[0] = (char *(*)()) F841_6542;
	R5926[1] = (char *(*)()) F842_6542;
	R5926[2] = (char *(*)()) F843_6542;
	R5926[3] = (char *(*)()) F844_6542;
	R5926[4] = (char *(*)()) F845_6542;
	R5926[5] = (char *(*)()) F846_6542;
	R5926[6] = (char *(*)()) F841_6542;
	R5926[7] = (char *(*)()) F842_6542;
	R5926[8] = (char *(*)()) F841_6542;
}

char *(*R5927[9])();
void R5927_init () {
	R5927[0] = (char *(*)()) F841_6543;
	R5927[1] = (char *(*)()) F842_6543;
	R5927[2] = (char *(*)()) F843_6543;
	R5927[3] = (char *(*)()) F844_6543;
	R5927[4] = (char *(*)()) F845_6543;
	R5927[5] = (char *(*)()) F846_6543;
	R5927[6] = (char *(*)()) F841_6543;
	R5927[7] = (char *(*)()) F842_6543;
	R5927[8] = (char *(*)()) F841_6543;
}

char *(*R5928[9])();
void R5928_init () {
	R5928[0] = (char *(*)()) F841_6544;
	R5928[1] = (char *(*)()) F842_6544;
	R5928[2] = (char *(*)()) F843_6544;
	R5928[3] = (char *(*)()) F844_6544;
	R5928[4] = (char *(*)()) F845_6544;
	R5928[5] = (char *(*)()) F846_6544;
	R5928[6] = (char *(*)()) F841_6544;
	R5928[7] = (char *(*)()) F842_6544;
	R5928[8] = (char *(*)()) F841_6544;
}

char *(*R5929[9])();
void R5929_init () {
	R5929[0] = (char *(*)()) F841_6545;
	R5929[1] = (char *(*)()) F842_6545;
	R5929[2] = (char *(*)()) F843_6545;
	R5929[3] = (char *(*)()) F844_6545;
	R5929[4] = (char *(*)()) F845_6545;
	R5929[5] = (char *(*)()) F846_6545;
	R5929[6] = (char *(*)()) F841_6545;
	R5929[7] = (char *(*)()) F842_6545;
	R5929[8] = (char *(*)()) F841_6545;
}

char *(*R5932[9])();
void R5932_init () {
	R5932[0] = (char *(*)()) F841_6549;
	R5932[1] = (char *(*)()) F842_6549;
	R5932[2] = (char *(*)()) F843_6549;
	R5932[3] = (char *(*)()) F844_6549;
	R5932[4] = (char *(*)()) F845_6549;
	R5932[5] = (char *(*)()) F846_6549;
	R5932[6] = (char *(*)()) F841_6549;
	R5932[7] = (char *(*)()) F842_6549;
	R5932[8] = (char *(*)()) F841_6549;
}

char *(*R5933[9])();
void R5933_init () {
	R5933[0] = (char *(*)()) F841_6550;
	R5933[1] = (char *(*)()) F842_6550;
	R5933[2] = (char *(*)()) F843_6550;
	R5933[3] = (char *(*)()) F844_6550;
	R5933[4] = (char *(*)()) F845_6550;
	R5933[5] = (char *(*)()) F846_6550;
	R5933[6] = (char *(*)()) F841_6550;
	R5933[7] = (char *(*)()) F842_6550;
	R5933[8] = (char *(*)()) F841_6550;
}

char *(*R5935[9])();
void R5935_init () {
	R5935[0] = (char *(*)()) F841_6552;
	R5935[1] = (char *(*)()) F842_6552;
	R5935[2] = (char *(*)()) F843_6552_5935_4;
	R5935[3] = (char *(*)()) F844_6552_5935_4;
	R5935[4] = (char *(*)()) F845_6552_5935_4;
	R5935[5] = (char *(*)()) F846_6552;
	R5935[6] = (char *(*)()) F841_6552;
	R5935[7] = (char *(*)()) F842_6552;
	R5935[8] = (char *(*)()) F841_6552;
}
static void F843_6552_5935_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F843_6552(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F844_6552_5935_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F844_6552(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F845_6552_5935_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F845_6552(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5937[9])();
void R5937_init () {
	R5937[0] = (char *(*)()) F841_6554;
	R5937[1] = (char *(*)()) F842_6554;
	R5937[2] = (char *(*)()) F843_6554;
	R5937[3] = (char *(*)()) F844_6554;
	R5937[4] = (char *(*)()) F845_6554;
	R5937[5] = (char *(*)()) F846_6554;
	R5937[6] = (char *(*)()) F841_6554;
	R5937[7] = (char *(*)()) F842_6554;
	R5937[8] = (char *(*)()) F841_6554;
}

char *(*R5938[9])();
void R5938_init () {
	R5938[0] = (char *(*)()) F841_6555;
	R5938[1] = (char *(*)()) F842_6555;
	R5938[2] = (char *(*)()) F843_6555;
	R5938[3] = (char *(*)()) F844_6555;
	R5938[4] = (char *(*)()) F845_6555;
	R5938[5] = (char *(*)()) F846_6555;
	R5938[6] = (char *(*)()) F841_6555;
	R5938[7] = (char *(*)()) F842_6555;
	R5938[8] = (char *(*)()) F841_6555;
}

char *(*R5944[9])();
void R5944_init () {
	R5944[0] = (char *(*)()) F841_6568;
	R5944[1] = (char *(*)()) F842_6568;
	R5944[2] = (char *(*)()) F843_6568;
	R5944[3] = (char *(*)()) F844_6568;
	R5944[4] = (char *(*)()) F845_6568;
	R5944[5] = (char *(*)()) F846_6568;
	R5944[6] = (char *(*)()) F847_6628;
	R5944[7] = (char *(*)()) F848_6628;
	R5944[8] = (char *(*)()) F841_6568;
}

char *(*R5953[9])();
void R5953_init () {
	R5953[0] = (char *(*)()) F841_6578;
	R5953[1] = (char *(*)()) F842_6578;
	R5953[2] = (char *(*)()) F843_6578;
	R5953[3] = (char *(*)()) F844_6578;
	R5953[4] = (char *(*)()) F845_6578;
	R5953[5] = (char *(*)()) F846_6578;
	R5953[6] = (char *(*)()) F841_6578;
	R5953[7] = (char *(*)()) F842_6578;
	R5953[8] = (char *(*)()) F841_6578;
}

char *(*R5954[9])();
void R5954_init () {
	R5954[0] = (char *(*)()) F841_6579;
	R5954[1] = (char *(*)()) F842_6579;
	R5954[2] = (char *(*)()) F843_6579;
	R5954[3] = (char *(*)()) F844_6579;
	R5954[4] = (char *(*)()) F845_6579;
	R5954[5] = (char *(*)()) F846_6579;
	R5954[6] = (char *(*)()) F841_6579;
	R5954[7] = (char *(*)()) F842_6579;
	R5954[8] = (char *(*)()) F841_6579;
}

char *(*R5961[9])();
void R5961_init () {
	R5961[0] = (char *(*)()) F841_6586;
	R5961[1] = (char *(*)()) F842_6586_5961_1;
	R5961[2] = (char *(*)()) F843_6586_5961_1;
	R5961[3] = (char *(*)()) F844_6586;
	R5961[4] = (char *(*)()) F845_6586_5961_1;
	R5961[5] = (char *(*)()) F846_6586_5961_1;
	R5961[6] = (char *(*)()) F841_6586;
	R5961[7] = (char *(*)()) F842_6586_5961_1;
	R5961[8] = (char *(*)()) F841_6586;
}
static EIF_REFERENCE F842_6586_5961_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F842_6586(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F843_6586_5961_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F843_6586(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F845_6586_5961_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F845_6586(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F846_6586_5961_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F846_6586(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R5962[9])();
void R5962_init () {
	R5962[0] = (char *(*)()) F841_6587;
	R5962[1] = (char *(*)()) F842_6587;
	R5962[2] = (char *(*)()) F843_6587_5962_1;
	R5962[3] = (char *(*)()) F844_6587_5962_1;
	R5962[4] = (char *(*)()) F845_6587_5962_1;
	R5962[5] = (char *(*)()) F846_6587;
	R5962[6] = (char *(*)()) F841_6587;
	R5962[7] = (char *(*)()) F842_6587;
	R5962[8] = (char *(*)()) F841_6587;
}
static EIF_REFERENCE F843_6587_5962_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F843_6587(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1079, 0x00).id, 1079, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F844_6587_5962_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F844_6587(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F845_6587_5962_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F845_6587(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5963[9])();
void R5963_init () {
	R5963[0] = (char *(*)()) F841_6588;
	R5963[1] = (char *(*)()) F842_6588;
	R5963[2] = (char *(*)()) F843_6588;
	R5963[3] = (char *(*)()) F844_6588;
	R5963[4] = (char *(*)()) F845_6588;
	R5963[5] = (char *(*)()) F846_6588;
	R5963[6] = (char *(*)()) F841_6588;
	R5963[7] = (char *(*)()) F842_6588;
	R5963[8] = (char *(*)()) F841_6588;
}

char *(*R5964[9])();
void R5964_init () {
	R5964[0] = (char *(*)()) F841_6589;
	R5964[1] = (char *(*)()) F842_6589;
	R5964[2] = (char *(*)()) F843_6589;
	R5964[3] = (char *(*)()) F844_6589;
	R5964[4] = (char *(*)()) F845_6589;
	R5964[5] = (char *(*)()) F846_6589;
	R5964[6] = (char *(*)()) F841_6589;
	R5964[7] = (char *(*)()) F842_6589;
	R5964[8] = (char *(*)()) F841_6589;
}

char *(*R5965[9])();
void R5965_init () {
	R5965[0] = (char *(*)()) F841_6590;
	R5965[1] = (char *(*)()) F842_6590;
	R5965[2] = (char *(*)()) F843_6590;
	R5965[3] = (char *(*)()) F844_6590;
	R5965[4] = (char *(*)()) F845_6590;
	R5965[5] = (char *(*)()) F846_6590;
	R5965[6] = (char *(*)()) F841_6590;
	R5965[7] = (char *(*)()) F842_6590;
	R5965[8] = (char *(*)()) F841_6590;
}

char *(*R5966[9])();
void R5966_init () {
	R5966[0] = (char *(*)()) F841_6591;
	R5966[1] = (char *(*)()) F842_6591;
	R5966[2] = (char *(*)()) F843_6591;
	R5966[3] = (char *(*)()) F844_6591;
	R5966[4] = (char *(*)()) F845_6591;
	R5966[5] = (char *(*)()) F846_6591;
	R5966[6] = (char *(*)()) F841_6591;
	R5966[7] = (char *(*)()) F842_6591;
	R5966[8] = (char *(*)()) F841_6591;
}

char *(*R5967[9])();
void R5967_init () {
	R5967[0] = (char *(*)()) F841_6592;
	R5967[1] = (char *(*)()) F842_6592;
	R5967[2] = (char *(*)()) F843_6592;
	R5967[3] = (char *(*)()) F844_6592;
	R5967[4] = (char *(*)()) F845_6592;
	R5967[5] = (char *(*)()) F846_6592;
	R5967[6] = (char *(*)()) F841_6592;
	R5967[7] = (char *(*)()) F842_6592;
	R5967[8] = (char *(*)()) F841_6592;
}

char *(*R5969[9])();
void R5969_init () {
	R5969[0] = (char *(*)()) F841_6594;
	R5969[1] = (char *(*)()) F842_6594;
	R5969[2] = (char *(*)()) F843_6594;
	R5969[3] = (char *(*)()) F844_6594;
	R5969[4] = (char *(*)()) F845_6594;
	R5969[5] = (char *(*)()) F846_6594;
	R5969[6] = (char *(*)()) F841_6594;
	R5969[7] = (char *(*)()) F842_6594;
	R5969[8] = (char *(*)()) F841_6594;
}

char *(*R5970[9])();
void R5970_init () {
	R5970[0] = (char *(*)()) F841_6595;
	R5970[1] = (char *(*)()) F842_6595;
	R5970[2] = (char *(*)()) F843_6595;
	R5970[3] = (char *(*)()) F844_6595;
	R5970[4] = (char *(*)()) F845_6595;
	R5970[5] = (char *(*)()) F846_6595;
	R5970[6] = (char *(*)()) F841_6595;
	R5970[7] = (char *(*)()) F842_6595;
	R5970[8] = (char *(*)()) F841_6595;
}

char *(*R5971[9])();
void R5971_init () {
	R5971[0] = (char *(*)()) F841_6596;
	R5971[1] = (char *(*)()) F842_6596;
	R5971[2] = (char *(*)()) F843_6596;
	R5971[3] = (char *(*)()) F844_6596;
	R5971[4] = (char *(*)()) F845_6596;
	R5971[5] = (char *(*)()) F846_6596;
	R5971[6] = (char *(*)()) F841_6596;
	R5971[7] = (char *(*)()) F842_6596;
	R5971[8] = (char *(*)()) F841_6596;
}

char *(*R5975[9])();
void R5975_init () {
	R5975[0] = (char *(*)()) F841_6600;
	R5975[1] = (char *(*)()) F842_6600;
	R5975[2] = (char *(*)()) F843_6600_5975_4;
	R5975[3] = (char *(*)()) F844_6600_5975_4;
	R5975[4] = (char *(*)()) F845_6600_5975_4;
	R5975[5] = (char *(*)()) F846_6600;
	R5975[6] = (char *(*)()) F841_6600;
	R5975[7] = (char *(*)()) F842_6600;
	R5975[8] = (char *(*)()) F841_6600;
}
static void F843_6600_5975_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F843_6600(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F844_6600_5975_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F844_6600(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F845_6600_5975_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F845_6600(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5981[9])();
void R5981_init () {
	R5981[0] = (char *(*)()) F841_6606;
	R5981[1] = (char *(*)()) F842_6606;
	R5981[2] = (char *(*)()) F843_6606;
	R5981[3] = (char *(*)()) F844_6606;
	R5981[4] = (char *(*)()) F845_6606;
	R5981[5] = (char *(*)()) F846_6606;
	R5981[6] = (char *(*)()) F841_6606;
	R5981[7] = (char *(*)()) F842_6606;
	R5981[8] = (char *(*)()) F841_6606;
}

char *(*R5994[9])();
void R5994_init () {
	R5994[0] = (char *(*)()) F841_6619;
	R5994[1] = (char *(*)()) F842_6619;
	R5994[2] = (char *(*)()) F843_6619;
	R5994[3] = (char *(*)()) F844_6619;
	R5994[4] = (char *(*)()) F845_6619;
	R5994[5] = (char *(*)()) F846_6619;
	R5994[6] = (char *(*)()) F841_6619;
	R5994[7] = (char *(*)()) F842_6619;
	R5994[8] = (char *(*)()) F841_6619;
}

char *(*R5997[2])();
void R5997_init () {
	R5997[0] = (char *(*)()) F847_6622;
	R5997[1] = (char *(*)()) F848_6622;
}

char *(*R6010[44])();
void R6010_init () {
	R6010[0] = (char *(*)()) F850_6641;
	R6010[1] = (char *(*)()) F851_6641;
	R6010[2] = (char *(*)()) F852_6641;
	R6010[3] = (char *(*)()) F853_6641;
	R6010[4] = (char *(*)()) F854_6641;
	R6010[5] = (char *(*)()) F855_6641;
	R6010[6] = (char *(*)()) F856_6641;
	R6010[7] = (char *(*)()) F857_6641;
	R6010[8] = (char *(*)()) F858_6641;
	R6010[9] = (char *(*)()) F859_6641;
	R6010[10] = (char *(*)()) F860_6641;
	R6010[11] = (char *(*)()) F861_6641;
	R6010[12] = (char *(*)()) F850_6641;
	R6010[13] = (char *(*)()) F854_6641;
	R6010[14] = (char *(*)()) F852_6641;
	R6010[19] = (char *(*)()) F850_6641;
	R6010[20] = (char *(*)()) F852_6641;
	{long i; for (i = 21; i < 25; i++) R6010[i] = (char *(*)()) F850_6641;}
	{long i; for (i = 30; i < 32; i++) R6010[i] = (char *(*)()) F850_6641;}
	{long i; for (i = 35; i < 37; i++) R6010[i] = (char *(*)()) F850_6641;}
	{long i; for (i = 39; i < 44; i++) R6010[i] = (char *(*)()) F850_6641;}
}

char *(*R6014[44])();
void R6014_init () {
	R6014[0] = (char *(*)()) F850_6645;
	R6014[1] = (char *(*)()) F851_6645;
	R6014[2] = (char *(*)()) F852_6645;
	R6014[3] = (char *(*)()) F853_6645;
	R6014[4] = (char *(*)()) F854_6645;
	R6014[5] = (char *(*)()) F855_6645;
	R6014[6] = (char *(*)()) F856_6645;
	R6014[7] = (char *(*)()) F857_6645;
	R6014[8] = (char *(*)()) F858_6645;
	R6014[9] = (char *(*)()) F859_6645;
	R6014[10] = (char *(*)()) F860_6645;
	R6014[11] = (char *(*)()) F861_6645;
	R6014[12] = (char *(*)()) F850_6645;
	R6014[13] = (char *(*)()) F854_6645;
	R6014[14] = (char *(*)()) F852_6645;
	R6014[19] = (char *(*)()) F850_6645;
	R6014[20] = (char *(*)()) F852_6645;
	{long i; for (i = 21; i < 25; i++) R6014[i] = (char *(*)()) F850_6645;}
	{long i; for (i = 30; i < 32; i++) R6014[i] = (char *(*)()) F850_6645;}
	{long i; for (i = 35; i < 37; i++) R6014[i] = (char *(*)()) F850_6645;}
	{long i; for (i = 39; i < 44; i++) R6014[i] = (char *(*)()) F850_6645;}
}

char *(*R6018[44])();
void R6018_init () {
	R6018[0] = (char *(*)()) F850_6664;
	R6018[1] = (char *(*)()) F851_6664;
	R6018[2] = (char *(*)()) F852_6664;
	R6018[3] = (char *(*)()) F853_6664;
	R6018[4] = (char *(*)()) F854_6664;
	R6018[5] = (char *(*)()) F855_6664;
	R6018[6] = (char *(*)()) F856_6664;
	R6018[7] = (char *(*)()) F857_6664;
	R6018[8] = (char *(*)()) F858_6664;
	R6018[9] = (char *(*)()) F859_6664;
	R6018[10] = (char *(*)()) F860_6664;
	R6018[11] = (char *(*)()) F861_6664;
	R6018[12] = (char *(*)()) F850_6664;
	R6018[13] = (char *(*)()) F854_6664;
	R6018[14] = (char *(*)()) F852_6664;
	R6018[19] = (char *(*)()) F850_6664;
	R6018[20] = (char *(*)()) F852_6664;
	{long i; for (i = 21; i < 25; i++) R6018[i] = (char *(*)()) F850_6664;}
	{long i; for (i = 30; i < 32; i++) R6018[i] = (char *(*)()) F850_6664;}
	{long i; for (i = 35; i < 37; i++) R6018[i] = (char *(*)()) F850_6664;}
	{long i; for (i = 39; i < 44; i++) R6018[i] = (char *(*)()) F850_6664;}
}

char *(*R6022[44])();
void R6022_init () {
	R6022[0] = (char *(*)()) F850_6705;
	R6022[1] = (char *(*)()) F851_6705_6022_177;
	R6022[2] = (char *(*)()) F852_6705_6022_177;
	R6022[3] = (char *(*)()) F853_6705_6022_177;
	R6022[4] = (char *(*)()) F854_6705_6022_177;
	R6022[5] = (char *(*)()) F855_6705_6022_177;
	R6022[6] = (char *(*)()) F856_6705_6022_177;
	R6022[7] = (char *(*)()) F857_6705_6022_177;
	R6022[8] = (char *(*)()) F858_6705_6022_177;
	R6022[9] = (char *(*)()) F859_6705_6022_177;
	R6022[10] = (char *(*)()) F860_6705_6022_177;
	R6022[11] = (char *(*)()) F861_6705_6022_177;
	R6022[12] = (char *(*)()) F850_6705;
	R6022[13] = (char *(*)()) F854_6705_6022_177;
	R6022[14] = (char *(*)()) F852_6705_6022_177;
	R6022[19] = (char *(*)()) F850_6705;
	R6022[20] = (char *(*)()) F852_6705_6022_177;
	{long i; for (i = 21; i < 25; i++) R6022[i] = (char *(*)()) F850_6705;}
	{long i; for (i = 30; i < 32; i++) R6022[i] = (char *(*)()) F850_6705;}
	{long i; for (i = 35; i < 37; i++) R6022[i] = (char *(*)()) F850_6705;}
	{long i; for (i = 39; i < 44; i++) R6022[i] = (char *(*)()) F850_6705;}
}
static void F851_6705_6022_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F851_6705(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F852_6705_6022_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F852_6705(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F853_6705_6022_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F853_6705(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F854_6705_6022_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F854_6705(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F855_6705_6022_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F855_6705(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F856_6705_6022_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F856_6705(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F857_6705_6022_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F857_6705(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F858_6705_6022_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F858_6705(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F859_6705_6022_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F859_6705(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F860_6705_6022_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F860_6705(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F861_6705_6022_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F861_6705(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R6026[3])();
void R6026_init () {
	R6026[0] = (char *(*)()) F850_6682;
	R6026[1] = (char *(*)()) F854_6682_6026_4;
	R6026[2] = (char *(*)()) F852_6682_6026_4;
}
static void F854_6682_6026_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F854_6682(Current, *(EIF_BOOLEAN *)arg1);
}
static void F852_6682_6026_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F852_6682(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6027[3])();
void R6027_init () {
	R6027[0] = (char *(*)()) F850_6695;
	R6027[1] = (char *(*)()) F854_6695;
	R6027[2] = (char *(*)()) F852_6695;
}

char *(*R6028[25])();
void R6028_init () {
	R6028[0] = (char *(*)()) F869_6750;
	R6028[1] = (char *(*)()) F870_6750_6028_177;
	R6028[2] = (char *(*)()) F869_6750;
	{long i; for (i = 3; i < 6; i++) R6028[i] = (char *(*)()) F872_6759;}
	{long i; for (i = 11; i < 13; i++) R6028[i] = (char *(*)()) F872_6759;}
	{long i; for (i = 16; i < 18; i++) R6028[i] = (char *(*)()) F872_6759;}
	{long i; for (i = 20; i < 25; i++) R6028[i] = (char *(*)()) F872_6759;}
}
static void F870_6750_6028_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F870_6750(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R6029[25])();
void R6029_init () {
	R6029[0] = (char *(*)()) F869_6751;
	R6029[1] = (char *(*)()) F870_6751_6029_177;
	R6029[2] = (char *(*)()) F869_6751;
	{long i; for (i = 3; i < 6; i++) R6029[i] = (char *(*)()) F872_6760;}
	{long i; for (i = 11; i < 13; i++) R6029[i] = (char *(*)()) F872_6760;}
	{long i; for (i = 16; i < 18; i++) R6029[i] = (char *(*)()) F872_6760;}
	{long i; for (i = 20; i < 25; i++) R6029[i] = (char *(*)()) F872_6760;}
}
static void F870_6751_6029_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F870_6751(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R6033[25])();
void R6033_init () {
	R6033[0] = (char *(*)()) F865_6739;
	R6033[1] = (char *(*)()) F866_6739_6033_177;
	{long i; for (i = 2; i < 6; i++) R6033[i] = (char *(*)()) F865_6739;}
	{long i; for (i = 11; i < 13; i++) R6033[i] = (char *(*)()) F865_6739;}
	{long i; for (i = 16; i < 18; i++) R6033[i] = (char *(*)()) F865_6739;}
	{long i; for (i = 20; i < 25; i++) R6033[i] = (char *(*)()) F865_6739;}
}
static void F866_6739_6033_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F866_6739(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R6034[25])();
void R6034_init () {
	R6034[0] = (char *(*)()) F865_6740;
	R6034[1] = (char *(*)()) F866_6740_6034_177;
	{long i; for (i = 2; i < 6; i++) R6034[i] = (char *(*)()) F865_6740;}
	{long i; for (i = 11; i < 13; i++) R6034[i] = (char *(*)()) F865_6740;}
	{long i; for (i = 16; i < 18; i++) R6034[i] = (char *(*)()) F865_6740;}
	{long i; for (i = 20; i < 25; i++) R6034[i] = (char *(*)()) F865_6740;}
}
static void F866_6740_6034_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F866_6740(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R6042[22])();
void R6042_init () {
	R6042[0] = (char *(*)()) F872_6761;
	R6042[1] = (char *(*)()) F873_6795;
	R6042[2] = (char *(*)()) F874_6796;
	{long i; for (i = 8; i < 10; i++) R6042[i] = (char *(*)()) F873_6795;}
	{long i; for (i = 13; i < 15; i++) R6042[i] = (char *(*)()) F873_6795;}
	{long i; for (i = 17; i < 22; i++) R6042[i] = (char *(*)()) F873_6795;}
}

static EIF_TYPE_INDEX Y6074_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype2[] = {0xFFF9,1,1049,0xFF01,0,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype4[] = {0xFF01,0xFFF9,1,1049,1067,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype5[] = {0xFF01,0xFFF9,1,1049,0xFF01,1248,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype6[] = {0xFF01,0xFFF9,1,1049,1067,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype7[] = {0xFF01,0xFFF9,1,1049,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype8[] = {0xFF01,0xFFF9,1,1049,0xFF01,1254,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype9[] = {0xFF01,0xFFF9,1,1049,0xFF01,1186,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype10[] = {0xFF01,0xFFF9,1,1049,1009,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype11[] = {0xFF01,0xFFF9,1,1049,0xFF01,1249,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype12[] = {0xFF01,0xFFF9,1,1049,1067,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype13[] = {0xFF01,0xFFF9,4,1049,1067,1067,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype14[] = {0xFF01,0xFFF9,1,1049,0xFF01,1467,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype15[] = {0xFF01,0xFFF9,5,1049,1079,1067,1067,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype16[] = {0xFF01,0xFFF9,1,1049,0xFF01,1133,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype17[] = {0xFF01,0xFFF9,2,1049,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype18[] = {0xFF01,0xFFF9,7,1049,1067,1067,1052,1052,1052,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype19[] = {0xFF01,0xFFF9,3,1049,1067,1067,1009,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype20[] = {0xFF01,0xFFF9,8,1049,1067,1067,1067,1052,1052,1052,1067,1067,0xFFFF};
static EIF_TYPE_INDEX Y6074_pgtype21[] = {0xFF01,0xFFF9,0,1049,0xFFFF};
EIF_TYPE_INDEX *Y6074_gen_type [22];
EIF_TYPE_INDEX Y6074 [22];
void Y6074_init (void)
{
	egc_routines_types [6074] = Y6074;
	egc_routines_gen_types [6074] = Y6074_gen_type;
	egc_routines_offset [6074] = 871;
	Y6074_gen_type [0] = Y6074_pgtype0;
	Y6074_gen_type [1] = Y6074_pgtype1;
	Y6074_gen_type [2] = Y6074_pgtype2;
	Y6074_gen_type [3] = Y6074_pgtype3;
	Y6074_gen_type [4] = Y6074_pgtype4;
	Y6074_gen_type [5] = Y6074_pgtype5;
	Y6074_gen_type [6] = Y6074_pgtype6;
	Y6074_gen_type [7] = Y6074_pgtype7;
	Y6074_gen_type [8] = Y6074_pgtype8;
	Y6074_gen_type [9] = Y6074_pgtype9;
	Y6074_gen_type [10] = Y6074_pgtype10;
	Y6074_gen_type [11] = Y6074_pgtype11;
	Y6074_gen_type [12] = Y6074_pgtype12;
	Y6074_gen_type [13] = Y6074_pgtype13;
	Y6074_gen_type [14] = Y6074_pgtype14;
	Y6074_gen_type [15] = Y6074_pgtype15;
	Y6074_gen_type [16] = Y6074_pgtype16;
	Y6074_gen_type [17] = Y6074_pgtype17;
	Y6074_gen_type [18] = Y6074_pgtype18;
	Y6074_gen_type [19] = Y6074_pgtype19;
	Y6074_gen_type [20] = Y6074_pgtype20;
	Y6074_gen_type [21] = Y6074_pgtype21;
	Y6074[2] = 1049;
	{long i; for (i = 4; i < 22; i++) Y6074[i] = 1049;};
}

char *(*R6408[12])();
void R6408_init () {
	R6408[0] = (char *(*)()) F917_7199;
	R6408[1] = (char *(*)()) F918_7199;
	R6408[2] = (char *(*)()) F919_7199;
	R6408[3] = (char *(*)()) F920_7199;
	R6408[4] = (char *(*)()) F921_7199;
	R6408[5] = (char *(*)()) F922_7199;
	R6408[6] = (char *(*)()) F923_7199;
	R6408[7] = (char *(*)()) F924_7199;
	R6408[8] = (char *(*)()) F925_7199;
	R6408[9] = (char *(*)()) F926_7199;
	R6408[10] = (char *(*)()) F927_7199;
	R6408[11] = (char *(*)()) F928_7199;
}

char *(*R6409[12])();
void R6409_init () {
	R6409[0] = (char *(*)()) F917_7200;
	R6409[1] = (char *(*)()) F918_7200;
	R6409[2] = (char *(*)()) F919_7200;
	R6409[3] = (char *(*)()) F920_7200;
	R6409[4] = (char *(*)()) F921_7200;
	R6409[5] = (char *(*)()) F922_7200;
	R6409[6] = (char *(*)()) F923_7200;
	R6409[7] = (char *(*)()) F924_7200;
	R6409[8] = (char *(*)()) F925_7200;
	R6409[9] = (char *(*)()) F926_7200;
	R6409[10] = (char *(*)()) F927_7200;
	R6409[11] = (char *(*)()) F928_7200;
}

char *(*R6411[12])();
void R6411_init () {
	R6411[0] = (char *(*)()) F917_7186;
	R6411[1] = (char *(*)()) F918_7186;
	R6411[2] = (char *(*)()) F919_7186;
	R6411[3] = (char *(*)()) F920_7186;
	R6411[4] = (char *(*)()) F921_7186;
	R6411[5] = (char *(*)()) F922_7186;
	R6411[6] = (char *(*)()) F923_7186;
	R6411[7] = (char *(*)()) F924_7186;
	R6411[8] = (char *(*)()) F925_7186;
	R6411[9] = (char *(*)()) F926_7186;
	R6411[10] = (char *(*)()) F927_7186;
	R6411[11] = (char *(*)()) F928_7186;
}

char *(*R6412[12])();
void R6412_init () {
	R6412[0] = (char *(*)()) F917_7187;
	R6412[1] = (char *(*)()) F918_7187_6412_177;
	R6412[2] = (char *(*)()) F919_7187_6412_177;
	R6412[3] = (char *(*)()) F920_7187_6412_177;
	R6412[4] = (char *(*)()) F921_7187_6412_177;
	R6412[5] = (char *(*)()) F922_7187_6412_177;
	R6412[6] = (char *(*)()) F923_7187_6412_177;
	R6412[7] = (char *(*)()) F924_7187_6412_177;
	R6412[8] = (char *(*)()) F925_7187_6412_177;
	R6412[9] = (char *(*)()) F926_7187_6412_177;
	R6412[10] = (char *(*)()) F927_7187_6412_177;
	R6412[11] = (char *(*)()) F928_7187_6412_177;
}
static void F918_7187_6412_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F918_7187(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F919_7187_6412_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F919_7187(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F920_7187_6412_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F920_7187(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F921_7187_6412_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F921_7187(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F922_7187_6412_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F922_7187(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F923_7187_6412_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F923_7187(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F924_7187_6412_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F924_7187(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F925_7187_6412_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F925_7187(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F926_7187_6412_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F926_7187(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F927_7187_6412_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F927_7187(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F928_7187_6412_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F928_7187(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R6421[12])();
void R6421_init () {
	R6421[0] = (char *(*)()) F917_7202;
	R6421[1] = (char *(*)()) F918_7202;
	R6421[2] = (char *(*)()) F919_7202;
	R6421[3] = (char *(*)()) F920_7202;
	R6421[4] = (char *(*)()) F921_7202;
	R6421[5] = (char *(*)()) F922_7202;
	R6421[6] = (char *(*)()) F923_7202;
	R6421[7] = (char *(*)()) F924_7202;
	R6421[8] = (char *(*)()) F925_7202;
	R6421[9] = (char *(*)()) F926_7202;
	R6421[10] = (char *(*)()) F927_7202;
	R6421[11] = (char *(*)()) F928_7202;
}

char *(*R6422[12])();
void R6422_init () {
	R6422[0] = (char *(*)()) F917_7204;
	R6422[1] = (char *(*)()) F918_7204_6422_177;
	R6422[2] = (char *(*)()) F919_7204_6422_177;
	R6422[3] = (char *(*)()) F920_7204_6422_177;
	R6422[4] = (char *(*)()) F921_7204_6422_177;
	R6422[5] = (char *(*)()) F922_7204_6422_177;
	R6422[6] = (char *(*)()) F923_7204_6422_177;
	R6422[7] = (char *(*)()) F924_7204_6422_177;
	R6422[8] = (char *(*)()) F925_7204_6422_177;
	R6422[9] = (char *(*)()) F926_7204_6422_177;
	R6422[10] = (char *(*)()) F927_7204_6422_177;
	R6422[11] = (char *(*)()) F928_7204_6422_177;
}
static void F918_7204_6422_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F918_7204(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F919_7204_6422_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F919_7204(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F920_7204_6422_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F920_7204(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F921_7204_6422_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F921_7204(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F922_7204_6422_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F922_7204(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F923_7204_6422_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F923_7204(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F924_7204_6422_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F924_7204(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F925_7204_6422_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F925_7204(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F926_7204_6422_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F926_7204(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F927_7204_6422_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F927_7204(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F928_7204_6422_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F928_7204(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R6423[12])();
void R6423_init () {
	R6423[0] = (char *(*)()) F917_7205;
	R6423[1] = (char *(*)()) F918_7205_6423_177;
	R6423[2] = (char *(*)()) F919_7205_6423_177;
	R6423[3] = (char *(*)()) F920_7205_6423_177;
	R6423[4] = (char *(*)()) F921_7205_6423_177;
	R6423[5] = (char *(*)()) F922_7205_6423_177;
	R6423[6] = (char *(*)()) F923_7205_6423_177;
	R6423[7] = (char *(*)()) F924_7205_6423_177;
	R6423[8] = (char *(*)()) F925_7205_6423_177;
	R6423[9] = (char *(*)()) F926_7205_6423_177;
	R6423[10] = (char *(*)()) F927_7205_6423_177;
	R6423[11] = (char *(*)()) F928_7205_6423_177;
}
static void F918_7205_6423_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F918_7205(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F919_7205_6423_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F919_7205(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F920_7205_6423_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F920_7205(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F921_7205_6423_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F921_7205(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F922_7205_6423_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F922_7205(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F923_7205_6423_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F923_7205(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F924_7205_6423_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F924_7205(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F925_7205_6423_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F925_7205(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F926_7205_6423_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F926_7205(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F927_7205_6423_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F927_7205(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F928_7205_6423_177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F928_7205(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R6424[12])();
void R6424_init () {
	R6424[0] = (char *(*)()) F917_7206;
	R6424[1] = (char *(*)()) F918_7206_6424_4;
	R6424[2] = (char *(*)()) F919_7206_6424_4;
	R6424[3] = (char *(*)()) F920_7206_6424_4;
	R6424[4] = (char *(*)()) F921_7206_6424_4;
	R6424[5] = (char *(*)()) F922_7206_6424_4;
	R6424[6] = (char *(*)()) F923_7206_6424_4;
	R6424[7] = (char *(*)()) F924_7206_6424_4;
	R6424[8] = (char *(*)()) F925_7206_6424_4;
	R6424[9] = (char *(*)()) F926_7206_6424_4;
	R6424[10] = (char *(*)()) F927_7206_6424_4;
	R6424[11] = (char *(*)()) F928_7206_6424_4;
}
static void F918_7206_6424_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F918_7206(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F919_7206_6424_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F919_7206(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F920_7206_6424_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F920_7206(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F921_7206_6424_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F921_7206(Current, *(EIF_BOOLEAN *)arg1);
}
static void F922_7206_6424_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F922_7206(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F923_7206_6424_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F923_7206(Current, *(EIF_POINTER *)arg1);
}
static void F924_7206_6424_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F924_7206(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F925_7206_6424_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F925_7206(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F926_7206_6424_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F926_7206(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F927_7206_6424_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F927_7206(Current, *(EIF_REAL_32 *)arg1);
}
static void F928_7206_6424_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F928_7206(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R6426[12])();
void R6426_init () {
	R6426[0] = (char *(*)()) F917_7208;
	R6426[1] = (char *(*)()) F918_7208_6426_41;
	R6426[2] = (char *(*)()) F919_7208_6426_41;
	R6426[3] = (char *(*)()) F920_7208_6426_41;
	R6426[4] = (char *(*)()) F921_7208_6426_41;
	R6426[5] = (char *(*)()) F922_7208_6426_41;
	R6426[6] = (char *(*)()) F923_7208_6426_41;
	R6426[7] = (char *(*)()) F924_7208_6426_41;
	R6426[8] = (char *(*)()) F925_7208_6426_41;
	R6426[9] = (char *(*)()) F926_7208_6426_41;
	R6426[10] = (char *(*)()) F927_7208_6426_41;
	R6426[11] = (char *(*)()) F928_7208_6426_41;
}
static void F918_7208_6426_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F918_7208(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F919_7208_6426_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F919_7208(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F920_7208_6426_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F920_7208(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F921_7208_6426_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F921_7208(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F922_7208_6426_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F922_7208(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F923_7208_6426_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F923_7208(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F924_7208_6426_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F924_7208(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F925_7208_6426_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F925_7208(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F926_7208_6426_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F926_7208(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F927_7208_6426_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F927_7208(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F928_7208_6426_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F928_7208(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R6429[12])();
void R6429_init () {
	R6429[0] = (char *(*)()) F917_7211;
	R6429[1] = (char *(*)()) F918_7211;
	R6429[2] = (char *(*)()) F919_7211;
	R6429[3] = (char *(*)()) F920_7211;
	R6429[4] = (char *(*)()) F921_7211;
	R6429[5] = (char *(*)()) F922_7211;
	R6429[6] = (char *(*)()) F923_7211;
	R6429[7] = (char *(*)()) F924_7211;
	R6429[8] = (char *(*)()) F925_7211;
	R6429[9] = (char *(*)()) F926_7211;
	R6429[10] = (char *(*)()) F927_7211;
	R6429[11] = (char *(*)()) F928_7211;
}

char *(*R6430[12])();
void R6430_init () {
	R6430[0] = (char *(*)()) F917_7212;
	R6430[1] = (char *(*)()) F918_7212;
	R6430[2] = (char *(*)()) F919_7212;
	R6430[3] = (char *(*)()) F920_7212;
	R6430[4] = (char *(*)()) F921_7212;
	R6430[5] = (char *(*)()) F922_7212;
	R6430[6] = (char *(*)()) F923_7212;
	R6430[7] = (char *(*)()) F924_7212;
	R6430[8] = (char *(*)()) F925_7212;
	R6430[9] = (char *(*)()) F926_7212;
	R6430[10] = (char *(*)()) F927_7212;
	R6430[11] = (char *(*)()) F928_7212;
}

char *(*R6431[12])();
void R6431_init () {
	R6431[0] = (char *(*)()) F917_7213;
	R6431[1] = (char *(*)()) F918_7213;
	R6431[2] = (char *(*)()) F919_7213;
	R6431[3] = (char *(*)()) F920_7213;
	R6431[4] = (char *(*)()) F921_7213;
	R6431[5] = (char *(*)()) F922_7213;
	R6431[6] = (char *(*)()) F923_7213;
	R6431[7] = (char *(*)()) F924_7213;
	R6431[8] = (char *(*)()) F925_7213;
	R6431[9] = (char *(*)()) F926_7213;
	R6431[10] = (char *(*)()) F927_7213;
	R6431[11] = (char *(*)()) F928_7213;
}

char *(*R6432[12])();
void R6432_init () {
	R6432[0] = (char *(*)()) F917_7214;
	R6432[1] = (char *(*)()) F918_7214;
	R6432[2] = (char *(*)()) F919_7214;
	R6432[3] = (char *(*)()) F920_7214;
	R6432[4] = (char *(*)()) F921_7214;
	R6432[5] = (char *(*)()) F922_7214;
	R6432[6] = (char *(*)()) F923_7214;
	R6432[7] = (char *(*)()) F924_7214;
	R6432[8] = (char *(*)()) F925_7214;
	R6432[9] = (char *(*)()) F926_7214;
	R6432[10] = (char *(*)()) F927_7214;
	R6432[11] = (char *(*)()) F928_7214;
}

char *(*R6433[12])();
void R6433_init () {
	R6433[0] = (char *(*)()) F917_7215;
	R6433[1] = (char *(*)()) F918_7215;
	R6433[2] = (char *(*)()) F919_7215;
	R6433[3] = (char *(*)()) F920_7215;
	R6433[4] = (char *(*)()) F921_7215;
	R6433[5] = (char *(*)()) F922_7215;
	R6433[6] = (char *(*)()) F923_7215;
	R6433[7] = (char *(*)()) F924_7215;
	R6433[8] = (char *(*)()) F925_7215;
	R6433[9] = (char *(*)()) F926_7215;
	R6433[10] = (char *(*)()) F927_7215;
	R6433[11] = (char *(*)()) F928_7215;
}

char *(*R6436[12])();
void R6436_init () {
	R6436[0] = (char *(*)()) F917_7218;
	R6436[1] = (char *(*)()) F918_7218;
	R6436[2] = (char *(*)()) F919_7218;
	R6436[3] = (char *(*)()) F920_7218;
	R6436[4] = (char *(*)()) F921_7218;
	R6436[5] = (char *(*)()) F922_7218;
	R6436[6] = (char *(*)()) F923_7218;
	R6436[7] = (char *(*)()) F924_7218;
	R6436[8] = (char *(*)()) F925_7218;
	R6436[9] = (char *(*)()) F926_7218;
	R6436[10] = (char *(*)()) F927_7218;
	R6436[11] = (char *(*)()) F928_7218;
}

char *(*R6437[12])();
void R6437_init () {
	R6437[0] = (char *(*)()) F917_7219;
	R6437[1] = (char *(*)()) F918_7219;
	R6437[2] = (char *(*)()) F919_7219;
	R6437[3] = (char *(*)()) F920_7219;
	R6437[4] = (char *(*)()) F921_7219;
	R6437[5] = (char *(*)()) F922_7219;
	R6437[6] = (char *(*)()) F923_7219;
	R6437[7] = (char *(*)()) F924_7219;
	R6437[8] = (char *(*)()) F925_7219;
	R6437[9] = (char *(*)()) F926_7219;
	R6437[10] = (char *(*)()) F927_7219;
	R6437[11] = (char *(*)()) F928_7219;
}

char *(*R6439[12])();
void R6439_init () {
	R6439[0] = (char *(*)()) F917_7221;
	R6439[1] = (char *(*)()) F918_7221;
	R6439[2] = (char *(*)()) F919_7221;
	R6439[3] = (char *(*)()) F920_7221;
	R6439[4] = (char *(*)()) F921_7221;
	R6439[5] = (char *(*)()) F922_7221;
	R6439[6] = (char *(*)()) F923_7221;
	R6439[7] = (char *(*)()) F924_7221;
	R6439[8] = (char *(*)()) F925_7221;
	R6439[9] = (char *(*)()) F926_7221;
	R6439[10] = (char *(*)()) F927_7221;
	R6439[11] = (char *(*)()) F928_7221;
}

char *(*R6440[12])();
void R6440_init () {
	R6440[0] = (char *(*)()) F917_7222;
	R6440[1] = (char *(*)()) F918_7222_6440_27;
	R6440[2] = (char *(*)()) F919_7222_6440_27;
	R6440[3] = (char *(*)()) F920_7222_6440_27;
	R6440[4] = (char *(*)()) F921_7222_6440_27;
	R6440[5] = (char *(*)()) F922_7222_6440_27;
	R6440[6] = (char *(*)()) F923_7222_6440_27;
	R6440[7] = (char *(*)()) F924_7222_6440_27;
	R6440[8] = (char *(*)()) F925_7222_6440_27;
	R6440[9] = (char *(*)()) F926_7222_6440_27;
	R6440[10] = (char *(*)()) F927_7222_6440_27;
	R6440[11] = (char *(*)()) F928_7222_6440_27;
}
static EIF_REFERENCE F918_7222_6440_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F918_7222(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F919_7222_6440_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F919_7222(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F920_7222_6440_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F920_7222(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F921_7222_6440_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F921_7222(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F922_7222_6440_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F922_7222(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F923_7222_6440_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F923_7222(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F924_7222_6440_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F924_7222(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F925_7222_6440_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F925_7222(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F926_7222_6440_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F926_7222(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F927_7222_6440_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F927_7222(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F928_7222_6440_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F928_7222(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R6442[12])();
void R6442_init () {
	R6442[0] = (char *(*)()) F917_7224;
	R6442[1] = (char *(*)()) F918_7224;
	R6442[2] = (char *(*)()) F919_7224;
	R6442[3] = (char *(*)()) F920_7224;
	R6442[4] = (char *(*)()) F921_7224;
	R6442[5] = (char *(*)()) F922_7224;
	R6442[6] = (char *(*)()) F923_7224;
	R6442[7] = (char *(*)()) F924_7224;
	R6442[8] = (char *(*)()) F925_7224;
	R6442[9] = (char *(*)()) F926_7224;
	R6442[10] = (char *(*)()) F927_7224;
	R6442[11] = (char *(*)()) F928_7224;
}

char *(*R6451[12])();
void R6451_init () {
	R6451[0] = (char *(*)()) F917_7234;
	R6451[1] = (char *(*)()) F918_7234;
	R6451[2] = (char *(*)()) F919_7234;
	R6451[3] = (char *(*)()) F920_7234;
	R6451[4] = (char *(*)()) F921_7234;
	R6451[5] = (char *(*)()) F922_7234;
	R6451[6] = (char *(*)()) F923_7234;
	R6451[7] = (char *(*)()) F924_7234;
	R6451[8] = (char *(*)()) F925_7234;
	R6451[9] = (char *(*)()) F926_7234;
	R6451[10] = (char *(*)()) F927_7234;
	R6451[11] = (char *(*)()) F928_7234;
}

char *(*R6472[10])();
void R6472_init () {
	{long i; for (i = 0; i < 2; i++) R6472[i] = (char *(*)()) F929_7256;}
	R6472[3] = (char *(*)()) F932_7293;
	R6472[4] = (char *(*)()) F933_7297;
	R6472[5] = (char *(*)()) F934_7299;
	R6472[6] = (char *(*)()) F935_7301;
	R6472[7] = (char *(*)()) F936_7303;
	R6472[8] = (char *(*)()) F937_7306;
	R6472[9] = (char *(*)()) F938_7308;
}

char *(*R6474[10])();
void R6474_init () {
	R6474[0] = (char *(*)()) F929_7258;
	R6474[1] = (char *(*)()) F930_7271;
	{long i; for (i = 3; i < 9; i++) R6474[i] = (char *(*)()) F931_7280;}
	R6474[9] = (char *(*)()) F938_7309;
}

char *(*R6475[10])();
void R6475_init () {
	{long i; for (i = 0; i < 2; i++) R6475[i] = (char *(*)()) F929_7259;}
	R6475[3] = (char *(*)()) F932_7294;
	{long i; for (i = 4; i < 10; i++) R6475[i] = (char *(*)()) F931_7283;}
}

char *(*R6490[7])();
void R6490_init () {
	{long i; for (i = 0; i < 4; i++) R6490[i] = (char *(*)()) F931_7279;}
	R6490[4] = (char *(*)()) F936_7304;
	{long i; for (i = 5; i < 7; i++) R6490[i] = (char *(*)()) F931_7279;}
}

char *(*R6547[2])();
void R6547_init () {
	R6547[0] = (char *(*)()) F940_7369;
	R6547[1] = (char *(*)()) F941_7377;
}

char *(*R6548[2])();
void R6548_init () {
	R6548[0] = (char *(*)()) F940_7370;
	R6548[1] = (char *(*)()) F941_7378;
}

char *(*R6551[2])();
void R6551_init () {
	R6551[0] = (char *(*)()) F940_7373;
	R6551[1] = (char *(*)()) F941_7381;
}

char *(*R6552[2])();
void R6552_init () {
	R6552[0] = (char *(*)()) F940_7374;
	R6552[1] = (char *(*)()) F941_7382;
}

char *(*R6554[2])();
void R6554_init () {
	R6554[0] = (char *(*)()) F940_7368;
	R6554[1] = (char *(*)()) F941_7376;
}

char *(*R6612[38])();
void R6612_init () {
	R6612[0] = (char *(*)()) F1052_8739_6612_1;
	R6612[1] = (char *(*)()) F1053_8739_6612_1;
	R6612[12] = (char *(*)()) F1064_8935_6612_1;
	R6612[13] = (char *(*)()) F1065_8935_6612_1;
	R6612[15] = (char *(*)()) F1067_9034_6612_1;
	R6612[16] = (char *(*)()) F1068_9034_6612_1;
	R6612[18] = (char *(*)()) F1070_9133_6612_1;
	R6612[19] = (char *(*)()) F1071_9133_6612_1;
	R6612[21] = (char *(*)()) F1073_9232_6612_1;
	R6612[22] = (char *(*)()) F1074_9232_6612_1;
	R6612[36] = (char *(*)()) F1088_9689_6612_1;
	R6612[37] = (char *(*)()) F1089_9689_6612_1;
}
static EIF_REFERENCE F1052_8739_6612_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1052_8739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1053_8739_6612_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1053_8739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1064_8935_6612_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1064_8935(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1064, 0x00).id, 1064, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1065_8935_6612_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1065_8935(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1064, 0x00).id, 1064, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1067_9034_6612_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1067_9034(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1068_9034_6612_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1068_9034(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1070_9133_6612_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1070_9133(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1071_9133_6612_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1071_9133(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1073_9232_6612_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1073_9232(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1073, 0x00).id, 1073, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1074_9232_6612_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1074_9232(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1073, 0x00).id, 1073, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1088_9689_6612_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1088_9689(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1089_9689_6612_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1089_9689(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}

char *(*R6852[468])();
void R6852_init () {
	{long i; for (i = 0; i < 2; i++) R6852[i] = (char *(*)()) F1001_7903;}
	R6852[467] = (char *(*)()) F1469_14934;
}


#ifdef __cplusplus
}
#endif
