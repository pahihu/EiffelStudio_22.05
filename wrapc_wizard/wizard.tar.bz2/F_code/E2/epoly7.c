#include "epoly7.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5605[580])();
void R5605_init () {
	R5605[0] = (char *(*)()) F693_6142;
	R5605[1] = (char *(*)()) F694_6142;
	R5605[2] = (char *(*)()) F695_6142;
	{long i; for (i = 3; i < 5; i++) R5605[i] = (char *(*)()) F693_6142;}
	R5605[5] = (char *(*)()) F694_6142;
	R5605[6] = (char *(*)()) F695_6142;
	R5605[157] = (char *(*)()) F850_6673;
	R5605[158] = (char *(*)()) F851_6673;
	R5605[159] = (char *(*)()) F852_6673;
	R5605[160] = (char *(*)()) F853_6673;
	R5605[161] = (char *(*)()) F854_6673;
	R5605[162] = (char *(*)()) F855_6673;
	R5605[163] = (char *(*)()) F856_6673;
	R5605[164] = (char *(*)()) F857_6673;
	R5605[165] = (char *(*)()) F858_6673;
	R5605[166] = (char *(*)()) F859_6673;
	R5605[167] = (char *(*)()) F860_6673;
	R5605[168] = (char *(*)()) F861_6673;
	R5605[169] = (char *(*)()) F850_6673;
	R5605[170] = (char *(*)()) F854_6673;
	R5605[171] = (char *(*)()) F852_6673;
	R5605[176] = (char *(*)()) F850_6673;
	R5605[177] = (char *(*)()) F852_6673;
	{long i; for (i = 178; i < 182; i++) R5605[i] = (char *(*)()) F850_6673;}
	{long i; for (i = 187; i < 189; i++) R5605[i] = (char *(*)()) F850_6673;}
	{long i; for (i = 192; i < 194; i++) R5605[i] = (char *(*)()) F850_6673;}
	{long i; for (i = 196; i < 201; i++) R5605[i] = (char *(*)()) F850_6673;}
	{long i; for (i = 525; i < 528; i++) R5605[i] = (char *(*)()) F645_6081;}
	R5605[568] = (char *(*)()) F645_6081;
	R5605[575] = (char *(*)()) F645_6081;
	{long i; for (i = 578; i < 580; i++) R5605[i] = (char *(*)()) F645_6081;}
}

char *(*R5606[777])();
void R5606_init () {
	R5606[0] = (char *(*)()) F693_6143;
	R5606[1] = (char *(*)()) F694_6143;
	R5606[2] = (char *(*)()) F695_6143;
	{long i; for (i = 3; i < 5; i++) R5606[i] = (char *(*)()) F693_6143;}
	R5606[5] = (char *(*)()) F694_6143;
	R5606[6] = (char *(*)()) F695_6143;
	R5606[39] = (char *(*)()) F549_5946;
	R5606[44] = (char *(*)()) F549_5946;
	R5606[157] = (char *(*)()) F850_6674;
	R5606[158] = (char *(*)()) F851_6674;
	R5606[159] = (char *(*)()) F852_6674;
	R5606[160] = (char *(*)()) F853_6674;
	R5606[161] = (char *(*)()) F854_6674;
	R5606[162] = (char *(*)()) F855_6674;
	R5606[163] = (char *(*)()) F856_6674;
	R5606[164] = (char *(*)()) F857_6674;
	R5606[165] = (char *(*)()) F858_6674;
	R5606[166] = (char *(*)()) F859_6674;
	R5606[167] = (char *(*)()) F860_6674;
	R5606[168] = (char *(*)()) F861_6674;
	R5606[169] = (char *(*)()) F850_6674;
	R5606[170] = (char *(*)()) F854_6674;
	R5606[171] = (char *(*)()) F852_6674;
	R5606[176] = (char *(*)()) F850_6674;
	R5606[177] = (char *(*)()) F852_6674;
	{long i; for (i = 178; i < 182; i++) R5606[i] = (char *(*)()) F850_6674;}
	{long i; for (i = 187; i < 189; i++) R5606[i] = (char *(*)()) F850_6674;}
	{long i; for (i = 192; i < 194; i++) R5606[i] = (char *(*)()) F850_6674;}
	{long i; for (i = 196; i < 201; i++) R5606[i] = (char *(*)()) F850_6674;}
	{long i; for (i = 309; i < 311; i++) R5606[i] = (char *(*)()) F1001_7958;}
	{long i; for (i = 525; i < 528; i++) R5606[i] = (char *(*)()) F1210_10947;}
	R5606[568] = (char *(*)()) F1210_10947;
	R5606[575] = (char *(*)()) F1210_10947;
	{long i; for (i = 578; i < 580; i++) R5606[i] = (char *(*)()) F1210_10947;}
	R5606[776] = (char *(*)()) F1001_7958;
}

char *(*R5607[777])();
void R5607_init () {
	R5607[0] = (char *(*)()) F693_6134;
	R5607[1] = (char *(*)()) F694_6134;
	R5607[2] = (char *(*)()) F695_6134;
	{long i; for (i = 3; i < 5; i++) R5607[i] = (char *(*)()) F693_6134;}
	R5607[5] = (char *(*)()) F694_6134;
	R5607[6] = (char *(*)()) F695_6134;
	R5607[157] = (char *(*)()) F669_6112;
	R5607[158] = (char *(*)()) F670_6112;
	R5607[159] = (char *(*)()) F671_6112;
	R5607[160] = (char *(*)()) F672_6112;
	R5607[161] = (char *(*)()) F673_6112;
	R5607[162] = (char *(*)()) F674_6112;
	R5607[163] = (char *(*)()) F675_6112;
	R5607[164] = (char *(*)()) F676_6112;
	R5607[165] = (char *(*)()) F677_6112;
	R5607[166] = (char *(*)()) F678_6112;
	R5607[167] = (char *(*)()) F679_6112;
	R5607[168] = (char *(*)()) F680_6112;
	R5607[169] = (char *(*)()) F669_6112;
	R5607[170] = (char *(*)()) F673_6112;
	R5607[171] = (char *(*)()) F671_6112;
	R5607[176] = (char *(*)()) F669_6112;
	R5607[177] = (char *(*)()) F671_6112;
	{long i; for (i = 178; i < 182; i++) R5607[i] = (char *(*)()) F669_6112;}
	{long i; for (i = 187; i < 189; i++) R5607[i] = (char *(*)()) F669_6112;}
	{long i; for (i = 192; i < 194; i++) R5607[i] = (char *(*)()) F669_6112;}
	{long i; for (i = 196; i < 201; i++) R5607[i] = (char *(*)()) F669_6112;}
	{long i; for (i = 309; i < 311; i++) R5607[i] = (char *(*)()) F1001_7900;}
	{long i; for (i = 525; i < 528; i++) R5607[i] = (char *(*)()) F669_6112;}
	R5607[568] = (char *(*)()) F669_6112;
	R5607[575] = (char *(*)()) F669_6112;
	{long i; for (i = 578; i < 580; i++) R5607[i] = (char *(*)()) F669_6112;}
	R5607[776] = (char *(*)()) F1001_7900;
}

char *(*R5608[620])();
void R5608_init () {
	R5608[0] = (char *(*)()) F850_6675;
	R5608[1] = (char *(*)()) F851_6675;
	R5608[2] = (char *(*)()) F852_6675;
	R5608[3] = (char *(*)()) F853_6675;
	R5608[4] = (char *(*)()) F854_6675;
	R5608[5] = (char *(*)()) F855_6675;
	R5608[6] = (char *(*)()) F856_6675;
	R5608[7] = (char *(*)()) F857_6675;
	R5608[8] = (char *(*)()) F858_6675;
	R5608[9] = (char *(*)()) F859_6675;
	R5608[10] = (char *(*)()) F860_6675;
	R5608[11] = (char *(*)()) F861_6675;
	R5608[12] = (char *(*)()) F850_6675;
	R5608[13] = (char *(*)()) F854_6675;
	R5608[14] = (char *(*)()) F852_6675;
	R5608[19] = (char *(*)()) F850_6675;
	R5608[20] = (char *(*)()) F852_6675;
	{long i; for (i = 21; i < 25; i++) R5608[i] = (char *(*)()) F850_6675;}
	{long i; for (i = 30; i < 32; i++) R5608[i] = (char *(*)()) F850_6675;}
	{long i; for (i = 35; i < 37; i++) R5608[i] = (char *(*)()) F850_6675;}
	{long i; for (i = 39; i < 44; i++) R5608[i] = (char *(*)()) F850_6675;}
	{long i; for (i = 152; i < 154; i++) R5608[i] = (char *(*)()) F1001_7959;}
	{long i; for (i = 368; i < 371; i++) R5608[i] = (char *(*)()) F1210_10946;}
	R5608[411] = (char *(*)()) F1210_10946;
	R5608[418] = (char *(*)()) F1210_10946;
	{long i; for (i = 421; i < 423; i++) R5608[i] = (char *(*)()) F1210_10946;}
	R5608[619] = (char *(*)()) F1469_14937;
}

char *(*R5609[580])();
void R5609_init () {
	R5609[0] = (char *(*)()) F657_6096;
	R5609[1] = (char *(*)()) F661_6096;
	R5609[2] = (char *(*)()) F659_6096;
	{long i; for (i = 3; i < 5; i++) R5609[i] = (char *(*)()) F657_6096;}
	R5609[5] = (char *(*)()) F661_6096;
	R5609[6] = (char *(*)()) F659_6096;
	R5609[157] = (char *(*)()) F657_6096;
	R5609[158] = (char *(*)()) F658_6096;
	R5609[159] = (char *(*)()) F659_6096;
	R5609[160] = (char *(*)()) F660_6096;
	R5609[161] = (char *(*)()) F661_6096;
	R5609[162] = (char *(*)()) F662_6096;
	R5609[163] = (char *(*)()) F663_6096;
	R5609[164] = (char *(*)()) F664_6096;
	R5609[165] = (char *(*)()) F665_6096;
	R5609[166] = (char *(*)()) F666_6096;
	R5609[167] = (char *(*)()) F667_6096;
	R5609[168] = (char *(*)()) F668_6096;
	R5609[169] = (char *(*)()) F657_6096;
	R5609[170] = (char *(*)()) F661_6096;
	R5609[171] = (char *(*)()) F659_6096;
	R5609[176] = (char *(*)()) F657_6096;
	R5609[177] = (char *(*)()) F659_6096;
	{long i; for (i = 178; i < 182; i++) R5609[i] = (char *(*)()) F657_6096;}
	{long i; for (i = 187; i < 189; i++) R5609[i] = (char *(*)()) F657_6096;}
	{long i; for (i = 192; i < 194; i++) R5609[i] = (char *(*)()) F657_6096;}
	{long i; for (i = 196; i < 201; i++) R5609[i] = (char *(*)()) F657_6096;}
	{long i; for (i = 525; i < 528; i++) R5609[i] = (char *(*)()) F657_6096;}
	R5609[568] = (char *(*)()) F657_6096;
	R5609[575] = (char *(*)()) F657_6096;
	{long i; for (i = 578; i < 580; i++) R5609[i] = (char *(*)()) F657_6096;}
}

char *(*R5610[580])();
void R5610_init () {
	R5610[0] = (char *(*)()) F496_5923;
	R5610[1] = (char *(*)()) F501_5923;
	R5610[2] = (char *(*)()) F499_5923;
	{long i; for (i = 3; i < 5; i++) R5610[i] = (char *(*)()) F496_5923;}
	R5610[5] = (char *(*)()) F501_5923;
	R5610[6] = (char *(*)()) F499_5923;
	R5610[148] = (char *(*)()) F495_5923;
	R5610[149] = (char *(*)()) F498_5923;
	R5610[150] = (char *(*)()) F503_5923;
	R5610[151] = (char *(*)()) F496_5923;
	R5610[152] = (char *(*)()) F499_5923;
	R5610[153] = (char *(*)()) F504_5923;
	R5610[154] = (char *(*)()) F495_5923;
	R5610[155] = (char *(*)()) F498_5923;
	R5610[156] = (char *(*)()) F495_5923;
	R5610[441] = (char *(*)()) F507_5923;
	R5610[444] = (char *(*)()) F506_5923;
	{long i; for (i = 525; i < 528; i++) R5610[i] = (char *(*)()) F496_5923;}
	{long i; for (i = 528; i < 530; i++) R5610[i] = (char *(*)()) F1221_11147;}
	{long i; for (i = 531; i < 533; i++) R5610[i] = (char *(*)()) F1221_11147;}
	{long i; for (i = 536; i < 539; i++) R5610[i] = (char *(*)()) F1221_11147;}
	R5610[540] = (char *(*)()) F1221_11147;
	R5610[568] = (char *(*)()) F496_5923;
	R5610[575] = (char *(*)()) F496_5923;
	{long i; for (i = 578; i < 580; i++) R5610[i] = (char *(*)()) F496_5923;}
}

char *(*R5612[168])();
void R5612_init () {
	R5612[0] = (char *(*)()) F697_6191;
	R5612[1] = (char *(*)()) F698_6191_5612_4;
	R5612[2] = (char *(*)()) F699_6191_5612_4;
	R5612[165] = (char *(*)()) F862_6709;
	R5612[166] = (char *(*)()) F863_6709_5612_4;
	R5612[167] = (char *(*)()) F864_6709_5612_4;
}
static void F698_6191_5612_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F698_6191(Current, *(EIF_BOOLEAN *)arg1);
}
static void F699_6191_5612_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F699_6191(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F863_6709_5612_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F863_6709(Current, *(EIF_BOOLEAN *)arg1);
}
static void F864_6709_5612_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F864_6709(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5613[777])();
void R5613_init () {
	R5613[0] = (char *(*)()) F693_6149;
	R5613[1] = (char *(*)()) F694_6149_5613_4;
	R5613[2] = (char *(*)()) F695_6149_5613_4;
	R5613[3] = (char *(*)()) F696_6172;
	R5613[4] = (char *(*)()) F697_6190;
	R5613[5] = (char *(*)()) F698_6190_5613_4;
	R5613[6] = (char *(*)()) F699_6190_5613_4;
	R5613[157] = (char *(*)()) F850_6682;
	R5613[158] = (char *(*)()) F851_6682_5613_4;
	R5613[159] = (char *(*)()) F852_6682_5613_4;
	R5613[160] = (char *(*)()) F853_6682_5613_4;
	R5613[161] = (char *(*)()) F854_6682_5613_4;
	R5613[162] = (char *(*)()) F855_6682_5613_4;
	R5613[163] = (char *(*)()) F856_6682_5613_4;
	R5613[164] = (char *(*)()) F857_6682_5613_4;
	R5613[165] = (char *(*)()) F858_6682_5613_4;
	R5613[166] = (char *(*)()) F859_6682_5613_4;
	R5613[167] = (char *(*)()) F860_6682_5613_4;
	R5613[168] = (char *(*)()) F861_6682_5613_4;
	R5613[169] = (char *(*)()) F862_6708;
	R5613[170] = (char *(*)()) F863_6708_5613_4;
	R5613[171] = (char *(*)()) F864_6708_5613_4;
	R5613[176] = (char *(*)()) F865_6724;
	R5613[177] = (char *(*)()) F866_6724_5613_4;
	{long i; for (i = 178; i < 182; i++) R5613[i] = (char *(*)()) F865_6724;}
	{long i; for (i = 187; i < 189; i++) R5613[i] = (char *(*)()) F865_6724;}
	{long i; for (i = 192; i < 194; i++) R5613[i] = (char *(*)()) F865_6724;}
	{long i; for (i = 196; i < 201; i++) R5613[i] = (char *(*)()) F865_6724;}
	{long i; for (i = 309; i < 311; i++) R5613[i] = (char *(*)()) F1001_7965_5613_4;}
	R5613[441] = (char *(*)()) F1134_10042_5613_4;
	R5613[444] = (char *(*)()) F1137_10207_5613_4;
	{long i; for (i = 525; i < 530; i++) R5613[i] = (char *(*)()) F1213_11052;}
	{long i; for (i = 531; i < 533; i++) R5613[i] = (char *(*)()) F1213_11052;}
	{long i; for (i = 536; i < 539; i++) R5613[i] = (char *(*)()) F1213_11052;}
	R5613[540] = (char *(*)()) F1213_11052;
	R5613[568] = (char *(*)()) F1210_10971;
	R5613[575] = (char *(*)()) F1210_10971;
	{long i; for (i = 578; i < 580; i++) R5613[i] = (char *(*)()) F1210_10971;}
	R5613[776] = (char *(*)()) F1001_7965_5613_4;
}
static void F694_6149_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F694_6149(Current, *(EIF_BOOLEAN *)arg1);
}
static void F695_6149_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F695_6149(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F698_6190_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F698_6190(Current, *(EIF_BOOLEAN *)arg1);
}
static void F699_6190_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F699_6190(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F851_6682_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F851_6682(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F852_6682_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F852_6682(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F853_6682_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F853_6682(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F854_6682_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F854_6682(Current, *(EIF_BOOLEAN *)arg1);
}
static void F855_6682_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F855_6682(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F856_6682_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F856_6682(Current, *(EIF_POINTER *)arg1);
}
static void F857_6682_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F857_6682(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F858_6682_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F858_6682(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F859_6682_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F859_6682(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F860_6682_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F860_6682(Current, *(EIF_REAL_32 *)arg1);
}
static void F861_6682_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F861_6682(Current, *(EIF_REAL_64 *)arg1);
}
static void F863_6708_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F863_6708(Current, *(EIF_BOOLEAN *)arg1);
}
static void F864_6708_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F864_6708(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F866_6724_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F866_6724(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1001_7965_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1001_7965(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1134_10042_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1134_10042(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1137_10207_5613_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1137_10207(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R5614[580])();
void R5614_init () {
	R5614[0] = (char *(*)()) F645_6092;
	R5614[1] = (char *(*)()) F649_6092;
	R5614[2] = (char *(*)()) F647_6092;
	R5614[4] = (char *(*)()) F604_6017;
	R5614[5] = (char *(*)()) F605_6017;
	R5614[6] = (char *(*)()) F606_6017;
	R5614[157] = (char *(*)()) F645_6092;
	R5614[158] = (char *(*)()) F646_6092;
	R5614[159] = (char *(*)()) F647_6092;
	R5614[160] = (char *(*)()) F648_6092;
	R5614[161] = (char *(*)()) F649_6092;
	R5614[162] = (char *(*)()) F650_6092;
	R5614[163] = (char *(*)()) F651_6092;
	R5614[164] = (char *(*)()) F652_6092;
	R5614[165] = (char *(*)()) F653_6092;
	R5614[166] = (char *(*)()) F654_6092;
	R5614[167] = (char *(*)()) F655_6092;
	R5614[168] = (char *(*)()) F656_6092;
	R5614[169] = (char *(*)()) F604_6017;
	R5614[170] = (char *(*)()) F605_6017;
	R5614[171] = (char *(*)()) F606_6017;
	R5614[176] = (char *(*)()) F645_6092;
	R5614[177] = (char *(*)()) F647_6092;
	{long i; for (i = 178; i < 182; i++) R5614[i] = (char *(*)()) F645_6092;}
	{long i; for (i = 187; i < 189; i++) R5614[i] = (char *(*)()) F645_6092;}
	{long i; for (i = 192; i < 194; i++) R5614[i] = (char *(*)()) F645_6092;}
	{long i; for (i = 196; i < 201; i++) R5614[i] = (char *(*)()) F645_6092;}
	{long i; for (i = 525; i < 528; i++) R5614[i] = (char *(*)()) F645_6092;}
	R5614[568] = (char *(*)()) F645_6092;
	R5614[575] = (char *(*)()) F645_6092;
	{long i; for (i = 578; i < 580; i++) R5614[i] = (char *(*)()) F645_6092;}
}

char *(*R5615[827])();
void R5615_init () {
	R5615[0] = (char *(*)()) F643_6059_5615_4;
	R5615[50] = (char *(*)()) F657_6102;
	R5615[51] = (char *(*)()) F661_6102_5615_4;
	R5615[52] = (char *(*)()) F659_6102_5615_4;
	R5615[53] = (char *(*)()) F696_6177;
	R5615[54] = (char *(*)()) F657_6102;
	R5615[55] = (char *(*)()) F661_6102_5615_4;
	R5615[56] = (char *(*)()) F659_6102_5615_4;
	R5615[57] = (char *(*)()) F700_6257;
	R5615[58] = (char *(*)()) F701_6257_5615_4;
	R5615[59] = (char *(*)()) F702_6257_5615_4;
	R5615[60] = (char *(*)()) F703_6257_5615_4;
	R5615[61] = (char *(*)()) F704_6257_5615_4;
	R5615[62] = (char *(*)()) F705_6257_5615_4;
	R5615[63] = (char *(*)()) F706_6257_5615_4;
	R5615[64] = (char *(*)()) F707_6257_5615_4;
	R5615[65] = (char *(*)()) F708_6257_5615_4;
	R5615[66] = (char *(*)()) F709_6257_5615_4;
	R5615[67] = (char *(*)()) F710_6257_5615_4;
	R5615[68] = (char *(*)()) F711_6257_5615_4;
	R5615[89] = (char *(*)()) F549_5951_5615_4;
	R5615[94] = (char *(*)()) F549_5951_5615_4;
	R5615[198] = (char *(*)()) F841_6563;
	R5615[199] = (char *(*)()) F842_6563_5615_4;
	R5615[200] = (char *(*)()) F843_6563_5615_4;
	R5615[201] = (char *(*)()) F844_6563;
	R5615[202] = (char *(*)()) F845_6563_5615_4;
	R5615[203] = (char *(*)()) F846_6563_5615_4;
	R5615[204] = (char *(*)()) F841_6563;
	R5615[205] = (char *(*)()) F842_6563_5615_4;
	R5615[206] = (char *(*)()) F841_6563;
	R5615[207] = (char *(*)()) F850_6694;
	R5615[208] = (char *(*)()) F851_6694_5615_4;
	R5615[209] = (char *(*)()) F852_6694_5615_4;
	R5615[210] = (char *(*)()) F853_6694_5615_4;
	R5615[211] = (char *(*)()) F854_6694_5615_4;
	R5615[212] = (char *(*)()) F855_6694_5615_4;
	R5615[213] = (char *(*)()) F856_6694_5615_4;
	R5615[214] = (char *(*)()) F857_6694_5615_4;
	R5615[215] = (char *(*)()) F858_6694_5615_4;
	R5615[216] = (char *(*)()) F859_6694_5615_4;
	R5615[217] = (char *(*)()) F860_6694_5615_4;
	R5615[218] = (char *(*)()) F861_6694_5615_4;
	R5615[219] = (char *(*)()) F850_6694;
	R5615[220] = (char *(*)()) F854_6694_5615_4;
	R5615[221] = (char *(*)()) F852_6694_5615_4;
	R5615[226] = (char *(*)()) F850_6694;
	R5615[227] = (char *(*)()) F852_6694_5615_4;
	R5615[228] = (char *(*)()) F850_6694;
	{long i; for (i = 229; i < 232; i++) R5615[i] = (char *(*)()) F872_6775;}
	{long i; for (i = 237; i < 239; i++) R5615[i] = (char *(*)()) F872_6775;}
	{long i; for (i = 242; i < 244; i++) R5615[i] = (char *(*)()) F872_6775;}
	{long i; for (i = 246; i < 251; i++) R5615[i] = (char *(*)()) F872_6775;}
	{long i; for (i = 359; i < 361; i++) R5615[i] = (char *(*)()) F1001_8086_5615_4;}
	R5615[491] = (char *(*)()) F1134_10053_5615_4;
	R5615[494] = (char *(*)()) F1137_10218_5615_4;
	{long i; for (i = 575; i < 580; i++) R5615[i] = (char *(*)()) F1213_11053;}
	{long i; for (i = 581; i < 583; i++) R5615[i] = (char *(*)()) F1213_11053;}
	{long i; for (i = 586; i < 589; i++) R5615[i] = (char *(*)()) F1213_11053;}
	R5615[590] = (char *(*)()) F1213_11053;
	R5615[618] = (char *(*)()) F657_6102;
	R5615[625] = (char *(*)()) F657_6102;
	{long i; for (i = 628; i < 630; i++) R5615[i] = (char *(*)()) F657_6102;}
	R5615[826] = (char *(*)()) F1001_8086_5615_4;
}
static void F643_6059_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F643_6059(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F661_6102_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_6102(Current, *(EIF_BOOLEAN *)arg1);
}
static void F659_6102_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_6102(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F701_6257_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F701_6257(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F702_6257_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F702_6257(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F703_6257_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F703_6257(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F704_6257_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F704_6257(Current, *(EIF_BOOLEAN *)arg1);
}
static void F705_6257_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F705_6257(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F706_6257_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F706_6257(Current, *(EIF_POINTER *)arg1);
}
static void F707_6257_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F707_6257(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F708_6257_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F708_6257(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F709_6257_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F709_6257(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F710_6257_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F710_6257(Current, *(EIF_REAL_32 *)arg1);
}
static void F711_6257_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F711_6257(Current, *(EIF_REAL_64 *)arg1);
}
static void F549_5951_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F549_5951(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F842_6563_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F842_6563(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F843_6563_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F843_6563(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F845_6563_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F845_6563(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F846_6563_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F846_6563(Current, *(EIF_POINTER *)arg1);
}
static void F851_6694_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F851_6694(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F852_6694_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F852_6694(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F853_6694_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F853_6694(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F854_6694_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F854_6694(Current, *(EIF_BOOLEAN *)arg1);
}
static void F855_6694_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F855_6694(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F856_6694_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F856_6694(Current, *(EIF_POINTER *)arg1);
}
static void F857_6694_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F857_6694(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F858_6694_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F858_6694(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F859_6694_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F859_6694(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F860_6694_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F860_6694(Current, *(EIF_REAL_32 *)arg1);
}
static void F861_6694_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F861_6694(Current, *(EIF_REAL_64 *)arg1);
}
static void F1001_8086_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1001_8086(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1134_10053_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1134_10053(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1137_10218_5615_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1137_10218(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R5616[630])();
void R5616_init () {
	R5616[0] = (char *(*)()) F456_5908_5616_4;
	R5616[50] = (char *(*)()) F657_6103;
	R5616[51] = (char *(*)()) F661_6103_5616_4;
	R5616[52] = (char *(*)()) F659_6103_5616_4;
	R5616[53] = (char *(*)()) F696_6178;
	R5616[54] = (char *(*)()) F454_5908;
	R5616[55] = (char *(*)()) F460_5908_5616_4;
	R5616[56] = (char *(*)()) F456_5908_5616_4;
	R5616[57] = (char *(*)()) F454_5908;
	R5616[58] = (char *(*)()) F455_5908_5616_4;
	R5616[59] = (char *(*)()) F456_5908_5616_4;
	R5616[60] = (char *(*)()) F457_5908_5616_4;
	R5616[61] = (char *(*)()) F460_5908_5616_4;
	R5616[62] = (char *(*)()) F459_5908_5616_4;
	R5616[63] = (char *(*)()) F461_5908_5616_4;
	R5616[64] = (char *(*)()) F462_5908_5616_4;
	R5616[65] = (char *(*)()) F458_5908_5616_4;
	R5616[66] = (char *(*)()) F463_5908_5616_4;
	R5616[67] = (char *(*)()) F464_5908_5616_4;
	R5616[68] = (char *(*)()) F465_5908_5616_4;
	R5616[89] = (char *(*)()) F456_5908_5616_4;
	R5616[94] = (char *(*)()) F456_5908_5616_4;
	R5616[198] = (char *(*)()) F454_5908;
	{long i; for (i = 199; i < 201; i++) R5616[i] = (char *(*)()) F456_5908_5616_4;}
	R5616[201] = (char *(*)()) F454_5908;
	R5616[202] = (char *(*)()) F456_5908_5616_4;
	R5616[203] = (char *(*)()) F461_5908_5616_4;
	R5616[204] = (char *(*)()) F454_5908;
	R5616[205] = (char *(*)()) F456_5908_5616_4;
	R5616[206] = (char *(*)()) F454_5908;
	R5616[207] = (char *(*)()) F850_6697;
	R5616[208] = (char *(*)()) F851_6697_5616_4;
	R5616[209] = (char *(*)()) F852_6697_5616_4;
	R5616[210] = (char *(*)()) F853_6697_5616_4;
	R5616[211] = (char *(*)()) F854_6697_5616_4;
	R5616[212] = (char *(*)()) F855_6697_5616_4;
	R5616[213] = (char *(*)()) F856_6697_5616_4;
	R5616[214] = (char *(*)()) F857_6697_5616_4;
	R5616[215] = (char *(*)()) F858_6697_5616_4;
	R5616[216] = (char *(*)()) F859_6697_5616_4;
	R5616[217] = (char *(*)()) F860_6697_5616_4;
	R5616[218] = (char *(*)()) F861_6697_5616_4;
	R5616[219] = (char *(*)()) F850_6697;
	R5616[220] = (char *(*)()) F854_6697_5616_4;
	R5616[221] = (char *(*)()) F852_6697_5616_4;
	R5616[226] = (char *(*)()) F865_6734;
	R5616[227] = (char *(*)()) F866_6734_5616_4;
	{long i; for (i = 228; i < 232; i++) R5616[i] = (char *(*)()) F865_6734;}
	{long i; for (i = 237; i < 239; i++) R5616[i] = (char *(*)()) F865_6734;}
	{long i; for (i = 242; i < 244; i++) R5616[i] = (char *(*)()) F865_6734;}
	{long i; for (i = 246; i < 251; i++) R5616[i] = (char *(*)()) F865_6734;}
	R5616[491] = (char *(*)()) F1134_10054_5616_4;
	{long i; for (i = 575; i < 578; i++) R5616[i] = (char *(*)()) F657_6103;}
	{long i; for (i = 578; i < 580; i++) R5616[i] = (char *(*)()) F454_5908;}
	{long i; for (i = 581; i < 583; i++) R5616[i] = (char *(*)()) F454_5908;}
	{long i; for (i = 586; i < 589; i++) R5616[i] = (char *(*)()) F454_5908;}
	R5616[590] = (char *(*)()) F454_5908;
	R5616[618] = (char *(*)()) F657_6103;
	R5616[625] = (char *(*)()) F657_6103;
	{long i; for (i = 628; i < 630; i++) R5616[i] = (char *(*)()) F657_6103;}
}
static void F456_5908_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F456_5908(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F661_6103_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_6103(Current, *(EIF_BOOLEAN *)arg1);
}
static void F659_6103_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_6103(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F460_5908_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F460_5908(Current, *(EIF_BOOLEAN *)arg1);
}
static void F455_5908_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F455_5908(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F457_5908_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F457_5908(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F459_5908_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F459_5908(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F461_5908_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F461_5908(Current, *(EIF_POINTER *)arg1);
}
static void F462_5908_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F462_5908(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F458_5908_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F458_5908(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F463_5908_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F463_5908(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F464_5908_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F464_5908(Current, *(EIF_REAL_32 *)arg1);
}
static void F465_5908_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F465_5908(Current, *(EIF_REAL_64 *)arg1);
}
static void F851_6697_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F851_6697(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F852_6697_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F852_6697(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F853_6697_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F853_6697(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F854_6697_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F854_6697(Current, *(EIF_BOOLEAN *)arg1);
}
static void F855_6697_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F855_6697(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F856_6697_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F856_6697(Current, *(EIF_POINTER *)arg1);
}
static void F857_6697_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F857_6697(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F858_6697_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F858_6697(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F859_6697_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F859_6697(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F860_6697_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F860_6697(Current, *(EIF_REAL_32 *)arg1);
}
static void F861_6697_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F861_6697(Current, *(EIF_REAL_64 *)arg1);
}
static void F866_6734_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F866_6734(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1134_10054_5616_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1134_10054(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R5617[432])();
void R5617_init () {
	R5617[0] = (char *(*)()) F841_6564;
	R5617[1] = (char *(*)()) F842_6564;
	R5617[2] = (char *(*)()) F843_6564;
	R5617[3] = (char *(*)()) F844_6564;
	R5617[4] = (char *(*)()) F845_6564;
	R5617[5] = (char *(*)()) F846_6564;
	R5617[6] = (char *(*)()) F841_6564;
	R5617[7] = (char *(*)()) F842_6564;
	R5617[8] = (char *(*)()) F841_6564;
	R5617[9] = (char *(*)()) F850_6700;
	R5617[10] = (char *(*)()) F851_6700;
	R5617[11] = (char *(*)()) F852_6700;
	R5617[12] = (char *(*)()) F853_6700;
	R5617[13] = (char *(*)()) F854_6700;
	R5617[14] = (char *(*)()) F855_6700;
	R5617[15] = (char *(*)()) F856_6700;
	R5617[16] = (char *(*)()) F857_6700;
	R5617[17] = (char *(*)()) F858_6700;
	R5617[18] = (char *(*)()) F859_6700;
	R5617[19] = (char *(*)()) F860_6700;
	R5617[20] = (char *(*)()) F861_6700;
	R5617[21] = (char *(*)()) F850_6700;
	R5617[22] = (char *(*)()) F854_6700;
	R5617[23] = (char *(*)()) F852_6700;
	R5617[28] = (char *(*)()) F865_6736;
	R5617[29] = (char *(*)()) F866_6736;
	{long i; for (i = 30; i < 34; i++) R5617[i] = (char *(*)()) F865_6736;}
	{long i; for (i = 39; i < 41; i++) R5617[i] = (char *(*)()) F865_6736;}
	{long i; for (i = 44; i < 46; i++) R5617[i] = (char *(*)()) F865_6736;}
	{long i; for (i = 48; i < 53; i++) R5617[i] = (char *(*)()) F865_6736;}
	R5617[293] = (char *(*)()) F1134_10057;
	R5617[296] = (char *(*)()) F1137_10222;
	{long i; for (i = 377; i < 380; i++) R5617[i] = (char *(*)()) F1210_10966;}
	{long i; for (i = 380; i < 382; i++) R5617[i] = (char *(*)()) F1221_11152;}
	{long i; for (i = 383; i < 385; i++) R5617[i] = (char *(*)()) F1221_11152;}
	{long i; for (i = 388; i < 391; i++) R5617[i] = (char *(*)()) F1221_11152;}
	R5617[392] = (char *(*)()) F1221_11152;
	R5617[420] = (char *(*)()) F1210_10966;
	R5617[427] = (char *(*)()) F1210_10966;
	{long i; for (i = 430; i < 432; i++) R5617[i] = (char *(*)()) F1210_10966;}
}

char *(*R5620[630])();
void R5620_init () {
	R5620[0] = (char *(*)()) F643_6030_5620_5;
	R5620[50] = (char *(*)()) F645_6076_5620_5;
	R5620[51] = (char *(*)()) F649_6076_5620_5;
	R5620[52] = (char *(*)()) F647_6076_5620_5;
	{long i; for (i = 53; i < 55; i++) R5620[i] = (char *(*)()) F645_6076_5620_5;}
	R5620[55] = (char *(*)()) F649_6076_5620_5;
	R5620[56] = (char *(*)()) F647_6076_5620_5;
	R5620[57] = (char *(*)()) F700_6207_5620_5;
	R5620[58] = (char *(*)()) F701_6207_5620_5;
	R5620[59] = (char *(*)()) F702_6207_5620_5;
	R5620[60] = (char *(*)()) F703_6207_5620_5;
	R5620[61] = (char *(*)()) F704_6207_5620_5;
	R5620[62] = (char *(*)()) F705_6207_5620_5;
	R5620[63] = (char *(*)()) F706_6207_5620_5;
	R5620[64] = (char *(*)()) F707_6207_5620_5;
	R5620[65] = (char *(*)()) F708_6207_5620_5;
	R5620[66] = (char *(*)()) F709_6207_5620_5;
	R5620[67] = (char *(*)()) F710_6207_5620_5;
	R5620[68] = (char *(*)()) F711_6207_5620_5;
	R5620[198] = (char *(*)()) F841_6515;
	R5620[199] = (char *(*)()) F842_6515_5620_5;
	R5620[200] = (char *(*)()) F843_6515_5620_5;
	R5620[201] = (char *(*)()) F844_6515_5620_5;
	R5620[202] = (char *(*)()) F845_6515_5620_5;
	R5620[203] = (char *(*)()) F846_6515_5620_5;
	R5620[204] = (char *(*)()) F841_6515;
	R5620[205] = (char *(*)()) F842_6515_5620_5;
	R5620[206] = (char *(*)()) F841_6515;
	R5620[207] = (char *(*)()) F850_6647_5620_5;
	R5620[208] = (char *(*)()) F851_6647_5620_5;
	R5620[209] = (char *(*)()) F852_6647_5620_5;
	R5620[210] = (char *(*)()) F853_6647_5620_5;
	R5620[211] = (char *(*)()) F854_6647_5620_5;
	R5620[212] = (char *(*)()) F855_6647_5620_5;
	R5620[213] = (char *(*)()) F856_6647_5620_5;
	R5620[214] = (char *(*)()) F857_6647_5620_5;
	R5620[215] = (char *(*)()) F858_6647_5620_5;
	R5620[216] = (char *(*)()) F859_6647_5620_5;
	R5620[217] = (char *(*)()) F860_6647_5620_5;
	R5620[218] = (char *(*)()) F861_6647_5620_5;
	R5620[219] = (char *(*)()) F850_6647_5620_5;
	R5620[220] = (char *(*)()) F854_6647_5620_5;
	R5620[221] = (char *(*)()) F852_6647_5620_5;
	R5620[226] = (char *(*)()) F850_6647_5620_5;
	R5620[227] = (char *(*)()) F852_6647_5620_5;
	{long i; for (i = 228; i < 232; i++) R5620[i] = (char *(*)()) F850_6647_5620_5;}
	{long i; for (i = 237; i < 239; i++) R5620[i] = (char *(*)()) F850_6647_5620_5;}
	{long i; for (i = 242; i < 244; i++) R5620[i] = (char *(*)()) F850_6647_5620_5;}
	{long i; for (i = 246; i < 251; i++) R5620[i] = (char *(*)()) F850_6647_5620_5;}
	R5620[491] = (char *(*)()) F1134_9995_5620_5;
	R5620[494] = (char *(*)()) F1137_10159_5620_5;
	{long i; for (i = 575; i < 578; i++) R5620[i] = (char *(*)()) F1210_10938_5620_5;}
	R5620[618] = (char *(*)()) F1210_10938_5620_5;
	R5620[625] = (char *(*)()) F1210_10938_5620_5;
	{long i; for (i = 628; i < 630; i++) R5620[i] = (char *(*)()) F1210_10938_5620_5;}
}
static EIF_REFERENCE F643_6030_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F643_6030(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F645_6076_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F645_6076(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F649_6076_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F649_6076(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F647_6076_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F647_6076(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F700_6207_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F700_6207(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F701_6207_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F701_6207(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1079, 0x00).id, 1079, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F702_6207_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F702_6207(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F703_6207_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F703_6207(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1076, 0x00).id, 1076, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F704_6207_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F704_6207(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F705_6207_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F705_6207(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F706_6207_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F706_6207(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F707_6207_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F707_6207(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F708_6207_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F708_6207(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F709_6207_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F709_6207(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F710_6207_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F710_6207(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F711_6207_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F711_6207(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F842_6515_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F842_6515(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F843_6515_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F843_6515(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F844_6515_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F844_6515(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F845_6515_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F845_6515(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F846_6515_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F846_6515(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F850_6647_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F850_6647(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F851_6647_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F851_6647(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1079, 0x00).id, 1079, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_6647_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F852_6647(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F853_6647_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F853_6647(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1076, 0x00).id, 1076, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F854_6647_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F854_6647(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F855_6647_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F855_6647(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F856_6647_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F856_6647(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_6647_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F857_6647(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_6647_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F858_6647(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_6647_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F859_6647(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F860_6647_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F860_6647(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F861_6647_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F861_6647(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1134_9995_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1134_9995(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1137_10159_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1137_10159(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1210_10938_5620_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1210_10938(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5621[580])();
void R5621_init () {
	R5621[0] = (char *(*)()) F645_6077_5621_5;
	R5621[1] = (char *(*)()) F649_6077_5621_5;
	R5621[2] = (char *(*)()) F647_6077_5621_5;
	{long i; for (i = 3; i < 5; i++) R5621[i] = (char *(*)()) F645_6077_5621_5;}
	R5621[5] = (char *(*)()) F649_6077_5621_5;
	R5621[6] = (char *(*)()) F647_6077_5621_5;
	R5621[7] = (char *(*)()) F700_6208_5621_5;
	R5621[8] = (char *(*)()) F701_6208_5621_5;
	R5621[9] = (char *(*)()) F702_6208_5621_5;
	R5621[10] = (char *(*)()) F703_6208_5621_5;
	R5621[11] = (char *(*)()) F704_6208_5621_5;
	R5621[12] = (char *(*)()) F705_6208_5621_5;
	R5621[13] = (char *(*)()) F706_6208_5621_5;
	R5621[14] = (char *(*)()) F707_6208_5621_5;
	R5621[15] = (char *(*)()) F708_6208_5621_5;
	R5621[16] = (char *(*)()) F709_6208_5621_5;
	R5621[17] = (char *(*)()) F710_6208_5621_5;
	R5621[18] = (char *(*)()) F711_6208_5621_5;
	R5621[148] = (char *(*)()) F841_6515;
	R5621[149] = (char *(*)()) F842_6515_5621_5;
	R5621[150] = (char *(*)()) F843_6515_5621_5;
	R5621[151] = (char *(*)()) F844_6515_5621_5;
	R5621[152] = (char *(*)()) F845_6515_5621_5;
	R5621[153] = (char *(*)()) F846_6515_5621_5;
	R5621[154] = (char *(*)()) F841_6515;
	R5621[155] = (char *(*)()) F842_6515_5621_5;
	R5621[156] = (char *(*)()) F841_6515;
	R5621[157] = (char *(*)()) F850_6648_5621_5;
	R5621[158] = (char *(*)()) F851_6648_5621_5;
	R5621[159] = (char *(*)()) F852_6648_5621_5;
	R5621[160] = (char *(*)()) F853_6648_5621_5;
	R5621[161] = (char *(*)()) F854_6648_5621_5;
	R5621[162] = (char *(*)()) F855_6648_5621_5;
	R5621[163] = (char *(*)()) F856_6648_5621_5;
	R5621[164] = (char *(*)()) F857_6648_5621_5;
	R5621[165] = (char *(*)()) F858_6648_5621_5;
	R5621[166] = (char *(*)()) F859_6648_5621_5;
	R5621[167] = (char *(*)()) F860_6648_5621_5;
	R5621[168] = (char *(*)()) F861_6648_5621_5;
	R5621[169] = (char *(*)()) F850_6648_5621_5;
	R5621[170] = (char *(*)()) F854_6648_5621_5;
	R5621[171] = (char *(*)()) F852_6648_5621_5;
	R5621[176] = (char *(*)()) F850_6648_5621_5;
	R5621[177] = (char *(*)()) F852_6648_5621_5;
	{long i; for (i = 178; i < 182; i++) R5621[i] = (char *(*)()) F850_6648_5621_5;}
	{long i; for (i = 187; i < 189; i++) R5621[i] = (char *(*)()) F850_6648_5621_5;}
	{long i; for (i = 192; i < 194; i++) R5621[i] = (char *(*)()) F850_6648_5621_5;}
	{long i; for (i = 196; i < 201; i++) R5621[i] = (char *(*)()) F850_6648_5621_5;}
	R5621[441] = (char *(*)()) F1134_9996_5621_5;
	R5621[444] = (char *(*)()) F1137_10160_5621_5;
	{long i; for (i = 525; i < 528; i++) R5621[i] = (char *(*)()) F645_6077_5621_5;}
	R5621[568] = (char *(*)()) F645_6077_5621_5;
	R5621[575] = (char *(*)()) F645_6077_5621_5;
	{long i; for (i = 578; i < 580; i++) R5621[i] = (char *(*)()) F645_6077_5621_5;}
}
static EIF_REFERENCE F645_6077_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F645_6077(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F649_6077_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F649_6077(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F647_6077_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F647_6077(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F700_6208_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F700_6208(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F701_6208_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F701_6208(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1079, 0x00).id, 1079, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F702_6208_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F702_6208(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F703_6208_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F703_6208(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1076, 0x00).id, 1076, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F704_6208_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F704_6208(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F705_6208_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F705_6208(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F706_6208_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F706_6208(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F707_6208_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F707_6208(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F708_6208_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F708_6208(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F709_6208_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F709_6208(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F710_6208_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F710_6208(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F711_6208_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F711_6208(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F842_6515_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F842_6515(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F843_6515_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F843_6515(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F844_6515_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F844_6515(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F845_6515_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F845_6515(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F846_6515_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F846_6515(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F850_6648_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F850_6648(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F851_6648_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F851_6648(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1079, 0x00).id, 1079, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_6648_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F852_6648(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F853_6648_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F853_6648(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1076, 0x00).id, 1076, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F854_6648_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F854_6648(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F855_6648_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F855_6648(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F856_6648_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F856_6648(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_6648_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F857_6648(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_6648_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F858_6648(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_6648_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F859_6648(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F860_6648_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F860_6648(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F861_6648_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F861_6648(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1134_9996_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1134_9996(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1137_10160_5621_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1137_10160(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R5622[630])();
void R5622_init () {
	R5622[0] = (char *(*)()) F643_6033_5622_2;
	R5622[50] = (char *(*)()) F645_6084_5622_2;
	R5622[51] = (char *(*)()) F649_6084_5622_2;
	R5622[52] = (char *(*)()) F647_6084_5622_2;
	{long i; for (i = 53; i < 55; i++) R5622[i] = (char *(*)()) F645_6084_5622_2;}
	R5622[55] = (char *(*)()) F649_6084_5622_2;
	R5622[56] = (char *(*)()) F647_6084_5622_2;
	R5622[57] = (char *(*)()) F700_6222_5622_2;
	R5622[58] = (char *(*)()) F701_6222_5622_2;
	R5622[59] = (char *(*)()) F702_6222_5622_2;
	R5622[60] = (char *(*)()) F703_6222_5622_2;
	R5622[61] = (char *(*)()) F704_6222_5622_2;
	R5622[62] = (char *(*)()) F705_6222_5622_2;
	R5622[63] = (char *(*)()) F706_6222_5622_2;
	R5622[64] = (char *(*)()) F707_6222_5622_2;
	R5622[65] = (char *(*)()) F708_6222_5622_2;
	R5622[66] = (char *(*)()) F709_6222_5622_2;
	R5622[67] = (char *(*)()) F710_6222_5622_2;
	R5622[68] = (char *(*)()) F711_6222_5622_2;
	R5622[198] = (char *(*)()) F841_6518;
	R5622[199] = (char *(*)()) F842_6518;
	R5622[200] = (char *(*)()) F843_6518_5622_2;
	R5622[201] = (char *(*)()) F844_6518_5622_2;
	R5622[202] = (char *(*)()) F845_6518_5622_2;
	R5622[203] = (char *(*)()) F846_6518;
	R5622[204] = (char *(*)()) F841_6518;
	R5622[205] = (char *(*)()) F842_6518;
	R5622[206] = (char *(*)()) F841_6518;
	R5622[207] = (char *(*)()) F850_6668_5622_2;
	R5622[208] = (char *(*)()) F851_6668_5622_2;
	R5622[209] = (char *(*)()) F852_6668_5622_2;
	R5622[210] = (char *(*)()) F853_6668_5622_2;
	R5622[211] = (char *(*)()) F854_6668_5622_2;
	R5622[212] = (char *(*)()) F855_6668_5622_2;
	R5622[213] = (char *(*)()) F856_6668_5622_2;
	R5622[214] = (char *(*)()) F857_6668_5622_2;
	R5622[215] = (char *(*)()) F858_6668_5622_2;
	R5622[216] = (char *(*)()) F859_6668_5622_2;
	R5622[217] = (char *(*)()) F860_6668_5622_2;
	R5622[218] = (char *(*)()) F861_6668_5622_2;
	R5622[219] = (char *(*)()) F850_6668_5622_2;
	R5622[220] = (char *(*)()) F854_6668_5622_2;
	R5622[221] = (char *(*)()) F852_6668_5622_2;
	R5622[226] = (char *(*)()) F850_6668_5622_2;
	R5622[227] = (char *(*)()) F852_6668_5622_2;
	{long i; for (i = 228; i < 232; i++) R5622[i] = (char *(*)()) F850_6668_5622_2;}
	{long i; for (i = 237; i < 239; i++) R5622[i] = (char *(*)()) F850_6668_5622_2;}
	{long i; for (i = 242; i < 244; i++) R5622[i] = (char *(*)()) F850_6668_5622_2;}
	{long i; for (i = 246; i < 251; i++) R5622[i] = (char *(*)()) F850_6668_5622_2;}
	R5622[491] = (char *(*)()) F1129_9795_5622_2;
	R5622[494] = (char *(*)()) F1129_9795_5622_2;
	{long i; for (i = 575; i < 578; i++) R5622[i] = (char *(*)()) F645_6084_5622_2;}
	R5622[618] = (char *(*)()) F645_6084_5622_2;
	R5622[625] = (char *(*)()) F645_6084_5622_2;
	{long i; for (i = 628; i < 630; i++) R5622[i] = (char *(*)()) F645_6084_5622_2;}
}
static EIF_BOOLEAN F643_6033_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F643_6033(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F645_6084_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F645_6084(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F649_6084_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F649_6084(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F647_6084_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F647_6084(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F700_6222_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F700_6222(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F701_6222_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F701_6222(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F702_6222_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F702_6222(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F703_6222_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F703_6222(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F704_6222_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F704_6222(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F705_6222_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F705_6222(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F706_6222_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F706_6222(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F707_6222_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F707_6222(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F708_6222_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F708_6222(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F709_6222_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F709_6222(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F710_6222_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F710_6222(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F711_6222_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F711_6222(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F843_6518_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F843_6518(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F844_6518_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F844_6518(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F845_6518_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F845_6518(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F850_6668_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F850_6668(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F851_6668_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F851_6668(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F852_6668_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F852_6668(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F853_6668_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F853_6668(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F854_6668_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F854_6668(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F855_6668_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F855_6668(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F856_6668_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F856_6668(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F857_6668_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F857_6668(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F858_6668_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F858_6668(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F859_6668_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F859_6668(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F860_6668_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F860_6668(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F861_6668_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F861_6668(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1129_9795_5622_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1129_9795(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5623[438])();
void R5623_init () {
	R5623[0] = (char *(*)()) F700_6226_5623_8;
	R5623[1] = (char *(*)()) F701_6226_5623_8;
	R5623[2] = (char *(*)()) F702_6226_5623_8;
	R5623[3] = (char *(*)()) F703_6226_5623_8;
	R5623[4] = (char *(*)()) F704_6226_5623_8;
	R5623[5] = (char *(*)()) F705_6226_5623_8;
	R5623[6] = (char *(*)()) F706_6226_5623_8;
	R5623[7] = (char *(*)()) F707_6226_5623_8;
	R5623[8] = (char *(*)()) F708_6226_5623_8;
	R5623[9] = (char *(*)()) F709_6226_5623_8;
	R5623[10] = (char *(*)()) F710_6226_5623_8;
	R5623[11] = (char *(*)()) F711_6226_5623_8;
	R5623[141] = (char *(*)()) F841_6556;
	R5623[142] = (char *(*)()) F842_6556_5623_8;
	R5623[143] = (char *(*)()) F843_6556_5623_8;
	R5623[144] = (char *(*)()) F844_6556_5623_8;
	R5623[145] = (char *(*)()) F845_6556_5623_8;
	R5623[146] = (char *(*)()) F846_6556_5623_8;
	R5623[147] = (char *(*)()) F841_6556;
	R5623[148] = (char *(*)()) F842_6556_5623_8;
	R5623[149] = (char *(*)()) F841_6556;
	R5623[150] = (char *(*)()) F850_6680_5623_8;
	R5623[151] = (char *(*)()) F851_6680_5623_8;
	R5623[152] = (char *(*)()) F852_6680_5623_8;
	R5623[153] = (char *(*)()) F853_6680_5623_8;
	R5623[154] = (char *(*)()) F854_6680_5623_8;
	R5623[155] = (char *(*)()) F855_6680_5623_8;
	R5623[156] = (char *(*)()) F856_6680_5623_8;
	R5623[157] = (char *(*)()) F857_6680_5623_8;
	R5623[158] = (char *(*)()) F858_6680_5623_8;
	R5623[159] = (char *(*)()) F859_6680_5623_8;
	R5623[160] = (char *(*)()) F860_6680_5623_8;
	R5623[161] = (char *(*)()) F861_6680_5623_8;
	R5623[162] = (char *(*)()) F850_6680_5623_8;
	R5623[163] = (char *(*)()) F854_6680_5623_8;
	R5623[164] = (char *(*)()) F852_6680_5623_8;
	R5623[169] = (char *(*)()) F865_6728_5623_8;
	R5623[170] = (char *(*)()) F866_6728_5623_8;
	{long i; for (i = 171; i < 175; i++) R5623[i] = (char *(*)()) F865_6728_5623_8;}
	{long i; for (i = 180; i < 182; i++) R5623[i] = (char *(*)()) F865_6728_5623_8;}
	{long i; for (i = 185; i < 187; i++) R5623[i] = (char *(*)()) F865_6728_5623_8;}
	{long i; for (i = 189; i < 194; i++) R5623[i] = (char *(*)()) F865_6728_5623_8;}
	R5623[434] = (char *(*)()) F1134_10015_5623_8;
	R5623[437] = (char *(*)()) F1137_10180_5623_8;
}
static void F700_6226_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F700_6226(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F701_6226_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F701_6226(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F702_6226_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F702_6226(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F703_6226_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F703_6226(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F704_6226_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F704_6226(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F705_6226_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F705_6226(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F706_6226_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F706_6226(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F707_6226_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F707_6226(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F708_6226_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F708_6226(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F709_6226_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F709_6226(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F710_6226_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F710_6226(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F711_6226_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F711_6226(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F842_6556_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F842_6556(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F843_6556_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F843_6556(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static void F844_6556_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F844_6556(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F845_6556_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F845_6556(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F846_6556_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F846_6556(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F850_6680_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F850_6680(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F851_6680_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F851_6680(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F852_6680_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F852_6680(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F853_6680_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F853_6680(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F854_6680_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F854_6680(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F855_6680_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F855_6680(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F856_6680_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F856_6680(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F857_6680_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F857_6680(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F858_6680_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F858_6680(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F859_6680_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F859_6680(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F860_6680_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F860_6680(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F861_6680_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F861_6680(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F865_6728_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F865_6728(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F866_6728_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F866_6728(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1134_10015_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1134_10015(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1137_10180_5623_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1137_10180(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R5624[438])();
void R5624_init () {
	R5624[0] = (char *(*)()) F700_6226_5624_8;
	R5624[1] = (char *(*)()) F701_6226_5624_8;
	R5624[2] = (char *(*)()) F702_6226_5624_8;
	R5624[3] = (char *(*)()) F703_6226_5624_8;
	R5624[4] = (char *(*)()) F704_6226_5624_8;
	R5624[5] = (char *(*)()) F705_6226_5624_8;
	R5624[6] = (char *(*)()) F706_6226_5624_8;
	R5624[7] = (char *(*)()) F707_6226_5624_8;
	R5624[8] = (char *(*)()) F708_6226_5624_8;
	R5624[9] = (char *(*)()) F709_6226_5624_8;
	R5624[10] = (char *(*)()) F710_6226_5624_8;
	R5624[11] = (char *(*)()) F711_6226_5624_8;
	R5624[141] = (char *(*)()) F841_6557;
	R5624[142] = (char *(*)()) F842_6557_5624_8;
	R5624[143] = (char *(*)()) F843_6557_5624_8;
	R5624[144] = (char *(*)()) F844_6557_5624_8;
	R5624[145] = (char *(*)()) F845_6557_5624_8;
	R5624[146] = (char *(*)()) F846_6557_5624_8;
	R5624[147] = (char *(*)()) F841_6557;
	R5624[148] = (char *(*)()) F842_6557_5624_8;
	R5624[149] = (char *(*)()) F841_6557;
	R5624[150] = (char *(*)()) F850_6680_5624_8;
	R5624[151] = (char *(*)()) F851_6680_5624_8;
	R5624[152] = (char *(*)()) F852_6680_5624_8;
	R5624[153] = (char *(*)()) F853_6680_5624_8;
	R5624[154] = (char *(*)()) F854_6680_5624_8;
	R5624[155] = (char *(*)()) F855_6680_5624_8;
	R5624[156] = (char *(*)()) F856_6680_5624_8;
	R5624[157] = (char *(*)()) F857_6680_5624_8;
	R5624[158] = (char *(*)()) F858_6680_5624_8;
	R5624[159] = (char *(*)()) F859_6680_5624_8;
	R5624[160] = (char *(*)()) F860_6680_5624_8;
	R5624[161] = (char *(*)()) F861_6680_5624_8;
	R5624[162] = (char *(*)()) F850_6680_5624_8;
	R5624[163] = (char *(*)()) F854_6680_5624_8;
	R5624[164] = (char *(*)()) F852_6680_5624_8;
	R5624[169] = (char *(*)()) F865_6728_5624_8;
	R5624[170] = (char *(*)()) F866_6728_5624_8;
	{long i; for (i = 171; i < 175; i++) R5624[i] = (char *(*)()) F865_6728_5624_8;}
	{long i; for (i = 180; i < 182; i++) R5624[i] = (char *(*)()) F865_6728_5624_8;}
	{long i; for (i = 185; i < 187; i++) R5624[i] = (char *(*)()) F865_6728_5624_8;}
	{long i; for (i = 189; i < 194; i++) R5624[i] = (char *(*)()) F865_6728_5624_8;}
	R5624[434] = (char *(*)()) F1134_10015_5624_8;
	R5624[437] = (char *(*)()) F1137_10180_5624_8;
}
static void F700_6226_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F700_6226(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F701_6226_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F701_6226(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F702_6226_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F702_6226(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F703_6226_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F703_6226(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F704_6226_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F704_6226(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F705_6226_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F705_6226(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F706_6226_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F706_6226(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F707_6226_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F707_6226(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F708_6226_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F708_6226(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F709_6226_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F709_6226(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F710_6226_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F710_6226(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F711_6226_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F711_6226(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F842_6557_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F842_6557(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F843_6557_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F843_6557(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static void F844_6557_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F844_6557(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F845_6557_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F845_6557(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F846_6557_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F846_6557(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F850_6680_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F850_6680(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F851_6680_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F851_6680(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F852_6680_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F852_6680(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F853_6680_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F853_6680(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F854_6680_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F854_6680(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F855_6680_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F855_6680(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F856_6680_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F856_6680(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F857_6680_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F857_6680(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F858_6680_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F858_6680(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F859_6680_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F859_6680(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F860_6680_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F860_6680(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F861_6680_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F861_6680(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F865_6728_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F865_6728(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F866_6728_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F866_6728(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1134_10015_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1134_10015(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1137_10180_5624_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1137_10180(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}


#ifdef __cplusplus
}
#endif
