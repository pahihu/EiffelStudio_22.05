#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O7240[449];
void O7240_init () {
	O7240[0] = + _LNGOFF_0_0_0_0_;
	O7240[1] = + _LNGOFF_1_0_0_1_;
	{long i; for (i = 2; i < 4; i++) O7240[i] = + _LNGOFF_0_0_0_0_;}
	O7240[4] = + _LNGOFF_2_0_0_0_;
	O7240[5] = + _LNGOFF_0_1_0_0_;
	O7240[185] = + _LNGOFF_2_0_0_0_;
	O7240[202] = + _LNGOFF_4_0_0_0_;
	O7240[206] = + _LNGOFF_5_2_0_0_;
	{long i; for (i = 207; i < 214; i++) O7240[i] = + _LNGOFF_6_3_0_0_;}
	O7240[214] = + _LNGOFF_10_3_0_0_;
	{long i; for (i = 215; i < 220; i++) O7240[i] = + _LNGOFF_6_3_0_0_;}
	O7240[220] = + _LNGOFF_6_4_0_0_;
	O7240[221] = + _LNGOFF_6_3_0_0_;
	{long i; for (i = 222; i < 224; i++) O7240[i] = + _LNGOFF_12_3_0_0_;}
	O7240[224] = + _LNGOFF_6_3_0_0_;
	O7240[225] = + _LNGOFF_7_4_0_0_;
	{long i; for (i = 226; i < 228; i++) O7240[i] = + _LNGOFF_14_3_0_0_;}
	{long i; for (i = 228; i < 231; i++) O7240[i] = + _LNGOFF_5_2_0_0_;}
	O7240[231] = + _LNGOFF_6_3_0_0_;
	O7240[232] = + _LNGOFF_5_2_0_0_;
	O7240[233] = + _LNGOFF_6_2_0_0_;
	{long i; for (i = 234; i < 238; i++) O7240[i] = + _LNGOFF_5_2_0_0_;}
	{long i; for (i = 238; i < 242; i++) O7240[i] = + _LNGOFF_6_2_0_0_;}
	O7240[242] = + _LNGOFF_6_0_0_0_;
	O7240[243] = + _LNGOFF_7_2_0_1_;
	{long i; for (i = 244; i < 253; i++) O7240[i] = + _LNGOFF_6_0_0_0_;}
	{long i; for (i = 254; i < 256; i++) O7240[i] = + _LNGOFF_5_3_0_0_;}
	O7240[257] = + _LNGOFF_5_3_0_0_;
	{long i; for (i = 258; i < 260; i++) O7240[i] = + _LNGOFF_6_1_0_0_;}
	O7240[262] = + _LNGOFF_6_1_0_0_;
	{long i; for (i = 263; i < 267; i++) O7240[i] = + _LNGOFF_5_3_0_0_;}
	O7240[272] = + _LNGOFF_2_4_0_0_;
	O7240[274] = + _LNGOFF_2_2_0_1_;
	O7240[293] = + _LNGOFF_49_16_0_3_;
	O7240[294] = + _LNGOFF_2_3_0_0_;
	O7240[295] = + _LNGOFF_4_3_0_0_;
	O7240[296] = + _LNGOFF_5_5_0_0_;
	O7240[297] = + _LNGOFF_10_10_0_0_;
	O7240[312] = + _LNGOFF_6_3_0_0_;
	O7240[336] = + _LNGOFF_8_5_0_0_;
	O7240[337] = + _LNGOFF_9_5_0_0_;
	O7240[341] = + _LNGOFF_11_5_0_0_;
	O7240[342] = + _LNGOFF_11_6_0_0_;
	O7240[343] = + _LNGOFF_11_5_0_0_;
	O7240[345] = + _LNGOFF_16_7_6_0_;
	O7240[347] = + _LNGOFF_42_12_10_0_;
	O7240[349] = + _LNGOFF_46_12_10_0_;
	O7240[353] = + _LNGOFF_47_12_10_0_;
	O7240[354] = + _LNGOFF_49_12_10_0_;
	O7240[355] = + _LNGOFF_47_12_10_0_;
	{long i; for (i = 359; i < 362; i++) O7240[i] = + _LNGOFF_49_13_10_0_;}
	O7240[366] = + _LNGOFF_49_13_10_0_;
	O7240[367] = + _LNGOFF_51_13_10_0_;
	{long i; for (i = 368; i < 370; i++) O7240[i] = + _LNGOFF_49_14_10_0_;}
	O7240[374] = + _LNGOFF_59_21_10_0_;
	O7240[375] = + _LNGOFF_59_23_10_0_;
	O7240[376] = + _LNGOFF_65_25_10_0_;
	O7240[377] = + _LNGOFF_68_26_10_0_;
	O7240[396] = + _LNGOFF_42_13_10_0_;
	O7240[397] = + _LNGOFF_44_13_10_0_;
	O7240[398] = + _LNGOFF_51_13_10_0_;
	O7240[399] = + _LNGOFF_58_14_10_0_;
	O7240[400] = + _LNGOFF_45_16_10_0_;
	O7240[401] = + _LNGOFF_44_13_10_0_;
	O7240[402] = + _LNGOFF_43_13_10_0_;
	O7240[403] = + _LNGOFF_46_14_10_0_;
	O7240[404] = + _LNGOFF_44_15_10_0_;
	O7240[405] = + _LNGOFF_51_18_10_0_;
	O7240[406] = + _LNGOFF_50_13_10_0_;
	O7240[407] = + _LNGOFF_59_16_10_0_;
	O7240[408] = + _LNGOFF_51_14_10_0_;
	O7240[409] = + _LNGOFF_53_14_10_0_;
	{long i; for (i = 410; i < 414; i++) O7240[i] = + _LNGOFF_46_14_10_0_;}
	{long i; for (i = 422; i < 424; i++) O7240[i] = + _LNGOFF_21_7_6_0_;}
	O7240[429] = + _LNGOFF_23_8_6_0_;
	O7240[430] = + _LNGOFF_23_9_6_0_;
	O7240[431] = + _LNGOFF_24_9_6_0_;
	O7240[432] = + _LNGOFF_23_9_6_0_;
	O7240[433] = + _LNGOFF_26_8_6_0_;
	{long i; for (i = 438; i < 440; i++) O7240[i] = + _LNGOFF_29_14_8_0_;}
	O7240[446] = + _LNGOFF_48_19_10_0_;
	O7240[448] = + _LNGOFF_48_18_10_0_;
}

long O7300[263];
void O7300_init () {
	O7300[0] =  + _REFACS_1_;
	O7300[198] =  + _REFACS_1_;
	{long i; for (i = 202; i < 218; i++) O7300[i] =  + _REFACS_1_;}
	{long i; for (i = 218; i < 220; i++) O7300[i] =  + _REFACS_7_;}
	{long i; for (i = 220; i < 239; i++) O7300[i] =  + _REFACS_1_;}
	O7300[239] =  + _REFACS_2_;
	{long i; for (i = 240; i < 249; i++) O7300[i] =  + _REFACS_1_;}
	{long i; for (i = 250; i < 252; i++) O7300[i] =  + _REFACS_1_;}
	{long i; for (i = 253; i < 256; i++) O7300[i] =  + _REFACS_1_;}
	{long i; for (i = 258; i < 263; i++) O7300[i] =  + _REFACS_1_;}
}

long O8197[6];
void O8197_init () {
	{long i; for (i = 0; i < 2; i++) O8197[i] = + _CHROFF_4_0_;}
	O8197[2] = + _CHROFF_5_0_;
	{long i; for (i = 3; i < 6; i++) O8197[i] = + _CHROFF_4_0_;}
}

long O8198[6];
void O8198_init () {
	{long i; for (i = 0; i < 2; i++) O8198[i] = + _LNGOFF_4_2_0_0_;}
	O8198[2] = + _LNGOFF_5_2_0_0_;
	O8198[3] = + _LNGOFF_4_3_0_0_;
	O8198[4] = + _LNGOFF_4_2_0_0_;
	O8198[5] = + _LNGOFF_4_3_0_0_;
}

long O8206[6];
void O8206_init () {
	{long i; for (i = 0; i < 2; i++) O8206[i] = + _PTROFF_4_2_0_3_0_0_;}
	O8206[2] = + _PTROFF_5_2_0_3_0_0_;
	O8206[3] = + _PTROFF_4_3_0_3_0_0_;
	O8206[4] = + _PTROFF_4_2_0_3_0_0_;
	O8206[5] = + _PTROFF_4_3_0_3_0_0_;
}

long O8207[6];
void O8207_init () {
	{long i; for (i = 0; i < 2; i++) O8207[i] = + _PTROFF_4_2_0_3_0_1_;}
	O8207[2] = + _PTROFF_5_2_0_3_0_1_;
	O8207[3] = + _PTROFF_4_3_0_3_0_1_;
	O8207[4] = + _PTROFF_4_2_0_3_0_1_;
	O8207[5] = + _PTROFF_4_3_0_3_0_1_;
}

long O8209[6];
void O8209_init () {
	{long i; for (i = 0; i < 2; i++) O8209[i] = + _PTROFF_4_2_0_3_0_2_;}
	O8209[2] = + _PTROFF_5_2_0_3_0_2_;
	O8209[3] = + _PTROFF_4_3_0_3_0_2_;
	O8209[4] = + _PTROFF_4_2_0_3_0_2_;
	O8209[5] = + _PTROFF_4_3_0_3_0_2_;
}

long O8210[6];
void O8210_init () {
	{long i; for (i = 0; i < 2; i++) O8210[i] = + _LNGOFF_4_2_0_1_;}
	O8210[2] = + _LNGOFF_5_2_0_1_;
	O8210[3] = + _LNGOFF_4_3_0_1_;
	O8210[4] = + _LNGOFF_4_2_0_1_;
	O8210[5] = + _LNGOFF_4_3_0_1_;
}

long O8211[6];
void O8211_init () {
	{long i; for (i = 0; i < 2; i++) O8211[i] = + _CHROFF_4_1_;}
	O8211[2] = + _CHROFF_5_1_;
	{long i; for (i = 3; i < 6; i++) O8211[i] = + _CHROFF_4_1_;}
}

long O8212[6];
void O8212_init () {
	{long i; for (i = 0; i < 2; i++) O8212[i] = + _LNGOFF_4_2_0_2_;}
	O8212[2] = + _LNGOFF_5_2_0_2_;
	O8212[3] = + _LNGOFF_4_3_0_2_;
	O8212[4] = + _LNGOFF_4_2_0_2_;
	O8212[5] = + _LNGOFF_4_3_0_2_;
}

long O8225[4];
void O8225_init () {
	O8225[0] =  + _REFACS_4_;
	O8225[1] = + _CHROFF_4_2_;
	O8225[2] = + _PTROFF_4_2_0_3_0_3_;
	O8225[3] = + _CHROFF_4_2_;
}

long O8324[446];
void O8324_init () {
	{long i; for (i = 0; i < 3; i++) O8324[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O8324[i] = + _LNGOFF_1_0_0_0_;}
	O8324[5] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 6; i < 8; i++) O8324[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 8; i < 11; i++) O8324[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 444; i < 446; i++) O8324[i] = + _LNGOFF_1_1_0_0_;}
}

long O8325[446];
void O8325_init () {
	{long i; for (i = 0; i < 3; i++) O8325[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O8325[i] = + _LNGOFF_1_0_0_1_;}
	O8325[5] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 6; i < 8; i++) O8325[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 8; i < 11; i++) O8325[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 444; i < 446; i++) O8325[i] = + _LNGOFF_1_1_0_1_;}
}

long O8390[3];
void O8390_init () {
	{long i; for (i = 0; i < 2; i++) O8390[i] = + _LNGOFF_1_0_0_2_;}
	O8390[2] = + _LNGOFF_1_1_0_2_;
}

long O8470[440];
void O8470_init () {
	{long i; for (i = 0; i < 2; i++) O8470[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 5; i++) O8470[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 438; i < 440; i++) O8470[i] = + _LNGOFF_1_1_0_2_;}
}

long O8633[106];
void O8633_init () {
	{long i; for (i = 0; i < 40; i++) O8633[i] = 0;}
	O8633[40] =  + _REFACS_2_;
	{long i; for (i = 41; i < 44; i++) O8633[i] = 0;}
	{long i; for (i = 44; i < 60; i++) O8633[i] =  + _REFACS_2_;}
	{long i; for (i = 60; i < 62; i++) O8633[i] =  + _REFACS_8_;}
	{long i; for (i = 62; i < 81; i++) O8633[i] =  + _REFACS_2_;}
	O8633[81] =  + _REFACS_3_;
	{long i; for (i = 82; i < 91; i++) O8633[i] =  + _REFACS_2_;}
	O8633[91] = 0;
	{long i; for (i = 92; i < 94; i++) O8633[i] =  + _REFACS_2_;}
	O8633[94] = 0;
	{long i; for (i = 95; i < 98; i++) O8633[i] =  + _REFACS_2_;}
	{long i; for (i = 98; i < 100; i++) O8633[i] = 0;}
	{long i; for (i = 100; i < 105; i++) O8633[i] =  + _REFACS_2_;}
	O8633[105] = 0;
}

long O8637[106];
void O8637_init () {
	{long i; for (i = 0; i < 40; i++) O8637[i] =  + _REFACS_1_;}
	O8637[40] =  + _REFACS_3_;
	{long i; for (i = 41; i < 44; i++) O8637[i] =  + _REFACS_1_;}
	{long i; for (i = 44; i < 60; i++) O8637[i] =  + _REFACS_3_;}
	{long i; for (i = 60; i < 62; i++) O8637[i] =  + _REFACS_9_;}
	{long i; for (i = 62; i < 81; i++) O8637[i] =  + _REFACS_3_;}
	O8637[81] =  + _REFACS_4_;
	{long i; for (i = 82; i < 91; i++) O8637[i] =  + _REFACS_3_;}
	O8637[91] =  + _REFACS_1_;
	{long i; for (i = 92; i < 94; i++) O8637[i] =  + _REFACS_3_;}
	O8637[94] =  + _REFACS_1_;
	{long i; for (i = 95; i < 98; i++) O8637[i] =  + _REFACS_3_;}
	{long i; for (i = 98; i < 100; i++) O8637[i] =  + _REFACS_1_;}
	{long i; for (i = 100; i < 105; i++) O8637[i] =  + _REFACS_3_;}
	O8637[105] =  + _REFACS_1_;
}

long O8828[92];
void O8828_init () {
	O8828[0] =  + _REFACS_2_;
	{long i; for (i = 28; i < 31; i++) O8828[i] =  + _REFACS_2_;}
	{long i; for (i = 31; i < 47; i++) O8828[i] =  + _REFACS_4_;}
	{long i; for (i = 47; i < 49; i++) O8828[i] =  + _REFACS_10_;}
	{long i; for (i = 49; i < 68; i++) O8828[i] =  + _REFACS_4_;}
	O8828[68] =  + _REFACS_5_;
	{long i; for (i = 69; i < 78; i++) O8828[i] =  + _REFACS_4_;}
	O8828[78] =  + _REFACS_2_;
	{long i; for (i = 79; i < 81; i++) O8828[i] =  + _REFACS_4_;}
	O8828[81] =  + _REFACS_2_;
	{long i; for (i = 82; i < 85; i++) O8828[i] =  + _REFACS_4_;}
	{long i; for (i = 85; i < 87; i++) O8828[i] =  + _REFACS_2_;}
	{long i; for (i = 87; i < 92; i++) O8828[i] =  + _REFACS_4_;}
}

long O9112[61];
void O9112_init () {
	O9112[0] = + _CHROFF_5_0_;
	{long i; for (i = 1; i < 8; i++) O9112[i] = + _CHROFF_6_1_;}
	O9112[8] = + _CHROFF_10_1_;
	{long i; for (i = 9; i < 16; i++) O9112[i] = + _CHROFF_6_1_;}
	{long i; for (i = 16; i < 18; i++) O9112[i] = + _CHROFF_12_1_;}
	O9112[18] = + _CHROFF_6_1_;
	O9112[19] = + _CHROFF_7_1_;
	{long i; for (i = 20; i < 22; i++) O9112[i] = + _CHROFF_14_1_;}
	{long i; for (i = 22; i < 25; i++) O9112[i] = + _CHROFF_5_0_;}
	O9112[25] = + _CHROFF_6_0_;
	O9112[26] = + _CHROFF_5_0_;
	O9112[27] = + _CHROFF_6_0_;
	{long i; for (i = 28; i < 32; i++) O9112[i] = + _CHROFF_5_0_;}
	{long i; for (i = 32; i < 36; i++) O9112[i] = + _CHROFF_6_0_;}
	{long i; for (i = 48; i < 50; i++) O9112[i] = + _CHROFF_5_1_;}
	O9112[51] = + _CHROFF_5_1_;
	{long i; for (i = 57; i < 61; i++) O9112[i] = + _CHROFF_5_1_;}
}

long O9113[61];
void O9113_init () {
	O9113[0] = + _CHROFF_5_1_;
	{long i; for (i = 1; i < 8; i++) O9113[i] = + _CHROFF_6_2_;}
	O9113[8] = + _CHROFF_10_2_;
	{long i; for (i = 9; i < 16; i++) O9113[i] = + _CHROFF_6_2_;}
	{long i; for (i = 16; i < 18; i++) O9113[i] = + _CHROFF_12_2_;}
	O9113[18] = + _CHROFF_6_2_;
	O9113[19] = + _CHROFF_7_2_;
	{long i; for (i = 20; i < 22; i++) O9113[i] = + _CHROFF_14_2_;}
	{long i; for (i = 22; i < 25; i++) O9113[i] = + _CHROFF_5_1_;}
	O9113[25] = + _CHROFF_6_1_;
	O9113[26] = + _CHROFF_5_1_;
	O9113[27] = + _CHROFF_6_1_;
	{long i; for (i = 28; i < 32; i++) O9113[i] = + _CHROFF_5_1_;}
	{long i; for (i = 32; i < 36; i++) O9113[i] = + _CHROFF_6_1_;}
	{long i; for (i = 48; i < 50; i++) O9113[i] = + _CHROFF_5_2_;}
	O9113[51] = + _CHROFF_5_2_;
	{long i; for (i = 57; i < 61; i++) O9113[i] = + _CHROFF_5_2_;}
}

long O9576[184];
void O9576_init () {
	{long i; for (i = 0; i < 24; i++) O9576[i] = 0;}
	O9576[24] =  + _REFACS_22_;
	O9576[25] =  + _REFACS_23_;
	{long i; for (i = 26; i < 35; i++) O9576[i] = 0;}
	O9576[35] =  + _REFACS_1_;
	O9576[36] = 0;
	O9576[37] =  + _REFACS_1_;
	{long i; for (i = 38; i < 40; i++) O9576[i] = 0;}
	{long i; for (i = 40; i < 42; i++) O9576[i] =  + _REFACS_5_;}
	O9576[42] = 0;
	{long i; for (i = 43; i < 45; i++) O9576[i] =  + _REFACS_1_;}
	{long i; for (i = 45; i < 49; i++) O9576[i] = 0;}
	{long i; for (i = 49; i < 51; i++) O9576[i] =  + _REFACS_1_;}
	{long i; for (i = 51; i < 66; i++) O9576[i] = 0;}
	{long i; for (i = 66; i < 76; i++) O9576[i] =  + _REFACS_2_;}
	{long i; for (i = 76; i < 78; i++) O9576[i] =  + _REFACS_7_;}
	{long i; for (i = 78; i < 80; i++) O9576[i] =  + _REFACS_24_;}
	{long i; for (i = 80; i < 83; i++) O9576[i] =  + _REFACS_25_;}
	O9576[83] =  + _REFACS_26_;
	{long i; for (i = 84; i < 86; i++) O9576[i] =  + _REFACS_25_;}
	O9576[86] =  + _REFACS_26_;
	O9576[87] =  + _REFACS_25_;
	{long i; for (i = 88; i < 102; i++) O9576[i] =  + _REFACS_26_;}
	{long i; for (i = 102; i < 104; i++) O9576[i] =  + _REFACS_30_;}
	{long i; for (i = 104; i < 106; i++) O9576[i] =  + _REFACS_33_;}
	{long i; for (i = 106; i < 108; i++) O9576[i] =  + _REFACS_30_;}
	{long i; for (i = 108; i < 110; i++) O9576[i] =  + _REFACS_33_;}
	O9576[110] =  + _REFACS_24_;
	O9576[111] =  + _REFACS_25_;
	O9576[112] =  + _REFACS_26_;
	O9576[113] =  + _REFACS_28_;
	O9576[114] =  + _REFACS_25_;
	O9576[115] =  + _REFACS_24_;
	O9576[116] =  + _REFACS_25_;
	O9576[117] =  + _REFACS_26_;
	O9576[118] =  + _REFACS_25_;
	O9576[119] =  + _REFACS_28_;
	{long i; for (i = 120; i < 124; i++) O9576[i] =  + _REFACS_25_;}
	O9576[124] =  + _REFACS_26_;
	O9576[125] =  + _REFACS_30_;
	O9576[126] =  + _REFACS_26_;
	O9576[127] =  + _REFACS_28_;
	O9576[128] =  + _REFACS_24_;
	O9576[129] =  + _REFACS_25_;
	O9576[130] =  + _REFACS_26_;
	O9576[131] =  + _REFACS_28_;
	O9576[132] =  + _REFACS_25_;
	O9576[133] =  + _REFACS_24_;
	O9576[134] =  + _REFACS_25_;
	O9576[135] =  + _REFACS_26_;
	O9576[136] =  + _REFACS_25_;
	O9576[137] =  + _REFACS_28_;
	O9576[138] =  + _REFACS_26_;
	O9576[139] =  + _REFACS_30_;
	O9576[140] =  + _REFACS_26_;
	O9576[141] =  + _REFACS_28_;
	{long i; for (i = 142; i < 146; i++) O9576[i] =  + _REFACS_25_;}
	{long i; for (i = 146; i < 148; i++) O9576[i] =  + _REFACS_10_;}
	{long i; for (i = 148; i < 150; i++) O9576[i] =  + _REFACS_12_;}
	{long i; for (i = 150; i < 154; i++) O9576[i] =  + _REFACS_14_;}
	{long i; for (i = 154; i < 156; i++) O9576[i] =  + _REFACS_10_;}
	{long i; for (i = 156; i < 160; i++) O9576[i] =  + _REFACS_11_;}
	O9576[160] =  + _REFACS_12_;
	{long i; for (i = 161; i < 165; i++) O9576[i] =  + _REFACS_11_;}
	{long i; for (i = 165; i < 168; i++) O9576[i] =  + _REFACS_12_;}
	{long i; for (i = 168; i < 172; i++) O9576[i] =  + _REFACS_14_;}
	O9576[172] = 0;
	O9576[173] =  + _REFACS_25_;
	O9576[174] = 0;
	O9576[175] =  + _REFACS_25_;
	{long i; for (i = 176; i < 178; i++) O9576[i] = 0;}
	O9576[178] =  + _REFACS_25_;
	O9576[179] = 0;
	O9576[180] =  + _REFACS_25_;
	{long i; for (i = 181; i < 184; i++) O9576[i] = 0;}
}

static EIF_TYPE_INDEX Y9576_pgtype0[] = {1209,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y9576_pgtype1[] = {1209,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y9576_pgtype2[] = {1258,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y9576_pgtype3[] = {1258,0xFF01,1263,0xFFFF};
static EIF_TYPE_INDEX Y9576_pgtype4[] = {1258,0xFF01,1254,0xFFFF};
static EIF_TYPE_INDEX Y9576_pgtype5[] = {1258,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y9576_gen_type [184];
EIF_TYPE_INDEX Y9576 [184];
void Y9576_init (void)
{
	egc_routines_types [9576] = Y9576;
	egc_routines_gen_types [9576] = Y9576_gen_type;
	egc_routines_offset [9576] = 1273;
	Y9576_gen_type [31] = Y9576_pgtype0;
	Y9576_gen_type [32] = Y9576_pgtype1;
	Y9576_gen_type [33] = Y9576_pgtype2;
	Y9576_gen_type [34] = Y9576_pgtype3;
	Y9576_gen_type [35] = Y9576_pgtype4;
	Y9576_gen_type [36] = Y9576_pgtype5;
	Y9576[0] = 1167;
	{long i; for (i = 1; i < 3; i++) Y9576[i] = 1169;};
	{long i; for (i = 3; i < 5; i++) Y9576[i] = 1168;};
	{long i; for (i = 5; i < 7; i++) Y9576[i] = 1170;};
	Y9576[7] = 1171;
	{long i; for (i = 8; i < 10; i++) Y9576[i] = 1172;};
	{long i; for (i = 10; i < 12; i++) Y9576[i] = 1173;};
	{long i; for (i = 12; i < 14; i++) Y9576[i] = 1174;};
	Y9576[14] = 1182;
	{long i; for (i = 15; i < 17; i++) Y9576[i] = 1175;};
	{long i; for (i = 17; i < 19; i++) Y9576[i] = 1176;};
	{long i; for (i = 19; i < 21; i++) Y9576[i] = 1177;};
	Y9576[21] = 1178;
	{long i; for (i = 22; i < 24; i++) Y9576[i] = 1179;};
	{long i; for (i = 24; i < 26; i++) Y9576[i] = 1183;};
	{long i; for (i = 26; i < 29; i++) Y9576[i] = 1167;};
	Y9576[29] = 1171;
	Y9576[30] = 1181;
	{long i; for (i = 31; i < 33; i++) Y9576[i] = 1209;};
	{long i; for (i = 33; i < 37; i++) Y9576[i] = 1258;};
	Y9576[37] = 1265;
	{long i; for (i = 38; i < 40; i++) Y9576[i] = 1185;};
	{long i; for (i = 40; i < 42; i++) Y9576[i] = 1186;};
	Y9576[42] = 1188;
	{long i; for (i = 43; i < 45; i++) Y9576[i] = 1266;};
	Y9576[45] = 1189;
	{long i; for (i = 46; i < 48; i++) Y9576[i] = 1187;};
	Y9576[48] = 1191;
	{long i; for (i = 49; i < 51; i++) Y9576[i] = 1190;};
	{long i; for (i = 51; i < 53; i++) Y9576[i] = 1210;};
	Y9576[53] = 1194;
	Y9576[54] = 1195;
	Y9576[55] = 1207;
	{long i; for (i = 56; i < 58; i++) Y9576[i] = 1193;};
	{long i; for (i = 58; i < 60; i++) Y9576[i] = 1192;};
	{long i; for (i = 60; i < 62; i++) Y9576[i] = 1198;};
	{long i; for (i = 62; i < 65; i++) Y9576[i] = 1196;};
	Y9576[65] = 1178;
	{long i; for (i = 66; i < 69; i++) Y9576[i] = 1202;};
	Y9576[69] = 1203;
	{long i; for (i = 70; i < 73; i++) Y9576[i] = 1202;};
	Y9576[73] = 1204;
	Y9576[74] = 1205;
	Y9576[75] = 1206;
	{long i; for (i = 76; i < 78; i++) Y9576[i] = 1207;};
	{long i; for (i = 78; i < 80; i++) Y9576[i] = 1211;};
	{long i; for (i = 80; i < 82; i++) Y9576[i] = 1212;};
	Y9576[82] = 1213;
	Y9576[83] = 1214;
	Y9576[84] = 1215;
	Y9576[85] = 1213;
	Y9576[86] = 1214;
	Y9576[87] = 1215;
	Y9576[88] = 1216;
	Y9576[89] = 1217;
	Y9576[90] = 1218;
	Y9576[91] = 1216;
	Y9576[92] = 1217;
	Y9576[93] = 1218;
	Y9576[94] = 1220;
	Y9576[95] = 1221;
	{long i; for (i = 96; i < 99; i++) Y9576[i] = 1220;};
	Y9576[99] = 1221;
	Y9576[100] = 1222;
	Y9576[101] = 1223;
	Y9576[102] = 1224;
	Y9576[103] = 1225;
	Y9576[104] = 1226;
	Y9576[105] = 1229;
	Y9576[106] = 1224;
	Y9576[107] = 1225;
	Y9576[108] = 1226;
	Y9576[109] = 1229;
	Y9576[110] = 1233;
	Y9576[111] = 1234;
	Y9576[112] = 1262;
	Y9576[113] = 1259;
	Y9576[114] = 1260;
	Y9576[115] = 1237;
	Y9576[116] = 1239;
	Y9576[117] = 1240;
	Y9576[118] = 1241;
	Y9576[119] = 1242;
	Y9576[120] = 1243;
	Y9576[121] = 1244;
	Y9576[122] = 1245;
	Y9576[123] = 1246;
	Y9576[124] = 1268;
	Y9576[125] = 1269;
	Y9576[126] = 1270;
	Y9576[127] = 1271;
	Y9576[128] = 1233;
	Y9576[129] = 1234;
	Y9576[130] = 1262;
	Y9576[131] = 1259;
	Y9576[132] = 1260;
	Y9576[133] = 1237;
	Y9576[134] = 1239;
	Y9576[135] = 1240;
	Y9576[136] = 1241;
	Y9576[137] = 1242;
	Y9576[138] = 1268;
	Y9576[139] = 1269;
	Y9576[140] = 1270;
	Y9576[141] = 1271;
	Y9576[142] = 1243;
	Y9576[143] = 1244;
	Y9576[144] = 1245;
	Y9576[145] = 1246;
	{long i; for (i = 146; i < 148; i++) Y9576[i] = 1247;};
	{long i; for (i = 148; i < 150; i++) Y9576[i] = 1249;};
	Y9576[150] = 1263;
	Y9576[151] = 1264;
	Y9576[152] = 1263;
	Y9576[153] = 1264;
	Y9576[154] = 1247;
	Y9576[155] = 1251;
	Y9576[156] = 1254;
	Y9576[157] = 1255;
	Y9576[158] = 1254;
	Y9576[159] = 1257;
	Y9576[160] = 1267;
	Y9576[161] = 1254;
	Y9576[162] = 1255;
	Y9576[163] = 1256;
	Y9576[164] = 1257;
	Y9576[165] = 1267;
	{long i; for (i = 166; i < 168; i++) Y9576[i] = 1248;};
	Y9576[168] = 1252;
	Y9576[169] = 1253;
	Y9576[170] = 1252;
	Y9576[171] = 1253;
	Y9576[172] = 1199;
	Y9576[173] = 1235;
	Y9576[174] = 1200;
	Y9576[175] = 1236;
	Y9576[176] = 1201;
	Y9576[177] = 1199;
	Y9576[178] = 1235;
	Y9576[179] = 1200;
	Y9576[180] = 1236;
	Y9576[181] = 1201;
	{long i; for (i = 182; i < 184; i++) Y9576[i] = 1272;};
}

long O9577[184];
void O9577_init () {
	{long i; for (i = 0; i < 4; i++) O9577[i] = + _CHROFF_1_0_;}
	O9577[4] = + _CHROFF_2_3_;
	O9577[5] = + _CHROFF_1_1_;
	O9577[6] = + _CHROFF_2_1_;
	{long i; for (i = 7; i < 10; i++) O9577[i] = + _CHROFF_1_0_;}
	O9577[10] = + _CHROFF_2_1_;
	O9577[11] = + _CHROFF_4_1_;
	O9577[12] = + _CHROFF_1_0_;
	{long i; for (i = 13; i < 15; i++) O9577[i] = + _CHROFF_2_0_;}
	{long i; for (i = 15; i < 17; i++) O9577[i] = + _CHROFF_1_0_;}
	O9577[17] = + _CHROFF_2_0_;
	O9577[18] = + _CHROFF_3_1_;
	{long i; for (i = 19; i < 22; i++) O9577[i] = + _CHROFF_1_0_;}
	O9577[22] = + _CHROFF_2_1_;
	O9577[23] = + _CHROFF_3_4_;
	O9577[24] = + _CHROFF_40_8_;
	O9577[25] = + _CHROFF_49_15_;
	O9577[26] = + _CHROFF_2_2_;
	O9577[27] = + _CHROFF_4_2_;
	O9577[28] = + _CHROFF_5_4_;
	O9577[29] = + _CHROFF_10_9_;
	{long i; for (i = 30; i < 32; i++) O9577[i] = + _CHROFF_1_0_;}
	O9577[32] = + _CHROFF_2_0_;
	{long i; for (i = 33; i < 35; i++) O9577[i] = + _CHROFF_1_0_;}
	{long i; for (i = 35; i < 37; i++) O9577[i] = + _CHROFF_2_0_;}
	O9577[37] = + _CHROFF_4_0_;
	O9577[38] = + _CHROFF_1_0_;
	O9577[39] = + _CHROFF_3_0_;
	O9577[40] = + _CHROFF_7_4_;
	O9577[41] = + _CHROFF_8_5_;
	O9577[42] = + _CHROFF_1_0_;
	O9577[43] = + _CHROFF_2_0_;
	O9577[44] = + _CHROFF_6_2_;
	{long i; for (i = 45; i < 49; i++) O9577[i] = + _CHROFF_1_0_;}
	{long i; for (i = 49; i < 51; i++) O9577[i] = + _CHROFF_3_1_;}
	{long i; for (i = 51; i < 53; i++) O9577[i] = + _CHROFF_1_1_;}
	{long i; for (i = 53; i < 59; i++) O9577[i] = + _CHROFF_1_0_;}
	O9577[59] = + _CHROFF_2_0_;
	O9577[60] = + _CHROFF_1_0_;
	O9577[61] = + _CHROFF_2_0_;
	O9577[62] = + _CHROFF_1_0_;
	O9577[63] = + _CHROFF_2_0_;
	{long i; for (i = 64; i < 66; i++) O9577[i] = + _CHROFF_1_0_;}
	{long i; for (i = 66; i < 68; i++) O9577[i] = + _CHROFF_3_0_;}
	O9577[68] = + _CHROFF_8_4_;
	O9577[69] = + _CHROFF_9_4_;
	{long i; for (i = 70; i < 73; i++) O9577[i] = + _CHROFF_4_0_;}
	O9577[73] = + _CHROFF_11_4_;
	O9577[74] = + _CHROFF_11_5_;
	O9577[75] = + _CHROFF_11_4_;
	O9577[76] = + _CHROFF_13_3_;
	O9577[77] = + _CHROFF_16_5_;
	O9577[78] = + _CHROFF_35_7_;
	O9577[79] = + _CHROFF_42_10_;
	O9577[80] = + _CHROFF_37_7_;
	O9577[81] = + _CHROFF_46_10_;
	O9577[82] = + _CHROFF_37_7_;
	O9577[83] = + _CHROFF_38_7_;
	O9577[84] = + _CHROFF_37_7_;
	O9577[85] = + _CHROFF_47_10_;
	O9577[86] = + _CHROFF_49_10_;
	O9577[87] = + _CHROFF_47_10_;
	{long i; for (i = 88; i < 91; i++) O9577[i] = + _CHROFF_39_8_;}
	{long i; for (i = 91; i < 94; i++) O9577[i] = + _CHROFF_49_11_;}
	{long i; for (i = 94; i < 98; i++) O9577[i] = + _CHROFF_39_8_;}
	O9577[98] = + _CHROFF_49_11_;
	O9577[99] = + _CHROFF_51_11_;
	{long i; for (i = 100; i < 102; i++) O9577[i] = + _CHROFF_49_12_;}
	O9577[102] = + _CHROFF_47_10_;
	O9577[103] = + _CHROFF_47_12_;
	O9577[104] = + _CHROFF_50_11_;
	O9577[105] = + _CHROFF_53_11_;
	O9577[106] = + _CHROFF_59_19_;
	O9577[107] = + _CHROFF_59_21_;
	O9577[108] = + _CHROFF_65_23_;
	O9577[109] = + _CHROFF_68_24_;
	O9577[110] = + _CHROFF_35_7_;
	{long i; for (i = 111; i < 113; i++) O9577[i] = + _CHROFF_37_7_;}
	O9577[113] = + _CHROFF_43_7_;
	O9577[114] = + _CHROFF_37_8_;
	O9577[115] = + _CHROFF_35_7_;
	O9577[116] = + _CHROFF_36_7_;
	O9577[117] = + _CHROFF_37_7_;
	O9577[118] = + _CHROFF_36_7_;
	O9577[119] = + _CHROFF_40_10_;
	{long i; for (i = 120; i < 124; i++) O9577[i] = + _CHROFF_36_7_;}
	O9577[124] = + _CHROFF_37_7_;
	O9577[125] = + _CHROFF_41_7_;
	O9577[126] = + _CHROFF_37_8_;
	O9577[127] = + _CHROFF_39_8_;
	O9577[128] = + _CHROFF_42_11_;
	O9577[129] = + _CHROFF_44_11_;
	O9577[130] = + _CHROFF_51_11_;
	O9577[131] = + _CHROFF_58_12_;
	O9577[132] = + _CHROFF_45_14_;
	O9577[133] = + _CHROFF_44_11_;
	O9577[134] = + _CHROFF_43_11_;
	O9577[135] = + _CHROFF_46_12_;
	O9577[136] = + _CHROFF_44_13_;
	O9577[137] = + _CHROFF_51_16_;
	O9577[138] = + _CHROFF_50_11_;
	O9577[139] = + _CHROFF_59_14_;
	O9577[140] = + _CHROFF_51_12_;
	O9577[141] = + _CHROFF_53_12_;
	{long i; for (i = 142; i < 146; i++) O9577[i] = + _CHROFF_46_12_;}
	{long i; for (i = 146; i < 148; i++) O9577[i] = + _CHROFF_16_3_;}
	O9577[148] = + _CHROFF_18_3_;
	O9577[149] = + _CHROFF_23_3_;
	{long i; for (i = 150; i < 152; i++) O9577[i] = + _CHROFF_20_3_;}
	{long i; for (i = 152; i < 154; i++) O9577[i] = + _CHROFF_25_4_;}
	{long i; for (i = 154; i < 156; i++) O9577[i] = + _CHROFF_21_5_;}
	{long i; for (i = 156; i < 160; i++) O9577[i] = + _CHROFF_17_4_;}
	O9577[160] = + _CHROFF_18_4_;
	O9577[161] = + _CHROFF_23_6_;
	O9577[162] = + _CHROFF_23_7_;
	O9577[163] = + _CHROFF_24_7_;
	O9577[164] = + _CHROFF_23_7_;
	O9577[165] = + _CHROFF_26_6_;
	O9577[166] = + _CHROFF_19_3_;
	O9577[167] = + _CHROFF_22_3_;
	{long i; for (i = 168; i < 170; i++) O9577[i] = + _CHROFF_21_8_;}
	{long i; for (i = 170; i < 172; i++) O9577[i] = + _CHROFF_29_12_;}
	O9577[172] = + _CHROFF_1_0_;
	O9577[173] = + _CHROFF_36_8_;
	O9577[174] = + _CHROFF_1_0_;
	O9577[175] = + _CHROFF_36_7_;
	O9577[176] = + _CHROFF_1_0_;
	O9577[177] = + _CHROFF_6_2_;
	O9577[178] = + _CHROFF_48_15_;
	O9577[179] = + _CHROFF_6_2_;
	O9577[180] = + _CHROFF_48_14_;
	O9577[181] = + _CHROFF_6_4_;
	{long i; for (i = 182; i < 184; i++) O9577[i] = + _CHROFF_3_0_;}
}

long O9750[167];
void O9750_init () {
	O9750[0] =  + _REFACS_1_;
	{long i; for (i = 64; i < 66; i++) O9750[i] =  + _REFACS_25_;}
	{long i; for (i = 66; i < 69; i++) O9750[i] =  + _REFACS_26_;}
	O9750[69] =  + _REFACS_27_;
	{long i; for (i = 70; i < 72; i++) O9750[i] =  + _REFACS_26_;}
	O9750[72] =  + _REFACS_27_;
	O9750[73] =  + _REFACS_26_;
	{long i; for (i = 74; i < 88; i++) O9750[i] =  + _REFACS_27_;}
	{long i; for (i = 88; i < 90; i++) O9750[i] =  + _REFACS_31_;}
	{long i; for (i = 90; i < 92; i++) O9750[i] =  + _REFACS_34_;}
	{long i; for (i = 92; i < 94; i++) O9750[i] =  + _REFACS_31_;}
	{long i; for (i = 94; i < 96; i++) O9750[i] =  + _REFACS_34_;}
	O9750[96] =  + _REFACS_25_;
	O9750[97] =  + _REFACS_26_;
	O9750[98] =  + _REFACS_27_;
	O9750[99] =  + _REFACS_29_;
	O9750[100] =  + _REFACS_26_;
	O9750[101] =  + _REFACS_25_;
	O9750[102] =  + _REFACS_26_;
	O9750[103] =  + _REFACS_27_;
	O9750[104] =  + _REFACS_26_;
	O9750[105] =  + _REFACS_29_;
	{long i; for (i = 106; i < 110; i++) O9750[i] =  + _REFACS_26_;}
	O9750[110] =  + _REFACS_27_;
	O9750[111] =  + _REFACS_31_;
	O9750[112] =  + _REFACS_27_;
	O9750[113] =  + _REFACS_29_;
	O9750[114] =  + _REFACS_25_;
	O9750[115] =  + _REFACS_26_;
	O9750[116] =  + _REFACS_27_;
	O9750[117] =  + _REFACS_29_;
	O9750[118] =  + _REFACS_26_;
	O9750[119] =  + _REFACS_25_;
	O9750[120] =  + _REFACS_26_;
	O9750[121] =  + _REFACS_27_;
	O9750[122] =  + _REFACS_26_;
	O9750[123] =  + _REFACS_29_;
	O9750[124] =  + _REFACS_27_;
	O9750[125] =  + _REFACS_31_;
	O9750[126] =  + _REFACS_27_;
	O9750[127] =  + _REFACS_29_;
	{long i; for (i = 128; i < 132; i++) O9750[i] =  + _REFACS_26_;}
	O9750[159] =  + _REFACS_26_;
	O9750[161] =  + _REFACS_26_;
	O9750[164] =  + _REFACS_26_;
	O9750[166] =  + _REFACS_26_;
}

long O10102[155];
void O10102_init () {
	O10102[0] = + _PTROFF_2_3_0_1_0_0_;
	O10102[1] = + _PTROFF_4_3_0_1_0_0_;
	O10102[2] = + _PTROFF_5_5_0_1_0_0_;
	O10102[3] = + _PTROFF_10_10_0_9_0_0_;
	O10102[18] = + _PTROFF_6_3_0_2_0_0_;
	O10102[42] = + _PTROFF_8_5_0_1_0_0_;
	O10102[43] = + _PTROFF_9_5_0_1_0_0_;
	O10102[47] = + _PTROFF_11_5_0_1_0_0_;
	O10102[48] = + _PTROFF_11_6_0_1_0_0_;
	O10102[49] = + _PTROFF_11_5_0_1_0_0_;
	O10102[51] = + _PTROFF_16_7_6_1_0_0_;
	O10102[53] = + _PTROFF_42_12_10_6_0_0_;
	O10102[55] = + _PTROFF_46_12_10_6_0_0_;
	O10102[59] = + _PTROFF_47_12_10_7_0_0_;
	O10102[60] = + _PTROFF_49_12_10_10_0_0_;
	O10102[61] = + _PTROFF_47_12_10_7_0_0_;
	{long i; for (i = 65; i < 68; i++) O10102[i] = + _PTROFF_49_13_10_7_0_0_;}
	O10102[72] = + _PTROFF_49_13_10_6_0_0_;
	O10102[73] = + _PTROFF_51_13_10_8_0_0_;
	O10102[74] = + _PTROFF_49_14_10_8_0_0_;
	O10102[75] = + _PTROFF_49_14_10_10_0_0_;
	O10102[80] = + _PTROFF_59_21_10_11_0_0_;
	O10102[81] = + _PTROFF_59_23_10_11_0_0_;
	O10102[82] = + _PTROFF_65_25_10_11_0_0_;
	O10102[83] = + _PTROFF_68_26_10_11_0_0_;
	O10102[102] = + _PTROFF_42_13_10_6_0_0_;
	O10102[103] = + _PTROFF_44_13_10_7_0_0_;
	O10102[104] = + _PTROFF_51_13_10_9_0_0_;
	O10102[105] = + _PTROFF_58_14_10_9_0_0_;
	O10102[106] = + _PTROFF_45_16_10_7_0_0_;
	O10102[107] = + _PTROFF_44_13_10_6_1_0_;
	O10102[108] = + _PTROFF_43_13_10_6_0_0_;
	O10102[109] = + _PTROFF_46_14_10_7_0_0_;
	O10102[110] = + _PTROFF_44_15_10_6_0_0_;
	O10102[111] = + _PTROFF_51_18_10_10_0_0_;
	O10102[112] = + _PTROFF_50_13_10_9_0_0_;
	O10102[113] = + _PTROFF_59_16_10_12_0_0_;
	O10102[114] = + _PTROFF_51_14_10_9_0_0_;
	O10102[115] = + _PTROFF_53_14_10_9_0_0_;
	{long i; for (i = 116; i < 120; i++) O10102[i] = + _PTROFF_46_14_10_6_0_0_;}
	{long i; for (i = 128; i < 130; i++) O10102[i] = + _PTROFF_21_7_6_1_0_0_;}
	O10102[135] = + _PTROFF_23_8_6_1_0_0_;
	O10102[136] = + _PTROFF_23_9_6_1_0_0_;
	O10102[137] = + _PTROFF_24_9_6_1_0_0_;
	O10102[138] = + _PTROFF_23_9_6_1_0_0_;
	O10102[139] = + _PTROFF_26_8_6_2_0_0_;
	{long i; for (i = 144; i < 146; i++) O10102[i] = + _PTROFF_29_14_8_2_0_0_;}
	O10102[152] = + _PTROFF_48_19_10_9_0_0_;
	O10102[154] = + _PTROFF_48_18_10_9_0_0_;
}

long O10103[155];
void O10103_init () {
	O10103[0] = + _CHROFF_2_0_;
	O10103[1] = + _CHROFF_4_0_;
	O10103[2] = + _CHROFF_5_0_;
	O10103[3] = + _CHROFF_10_0_;
	O10103[18] = + _CHROFF_6_0_;
	O10103[42] = + _CHROFF_8_0_;
	O10103[43] = + _CHROFF_9_0_;
	{long i; for (i = 47; i < 50; i++) O10103[i] = + _CHROFF_11_0_;}
	O10103[51] = + _CHROFF_16_1_;
	O10103[53] = + _CHROFF_42_1_;
	O10103[55] = + _CHROFF_46_1_;
	O10103[59] = + _CHROFF_47_1_;
	O10103[60] = + _CHROFF_49_1_;
	O10103[61] = + _CHROFF_47_1_;
	{long i; for (i = 65; i < 68; i++) O10103[i] = + _CHROFF_49_1_;}
	O10103[72] = + _CHROFF_49_1_;
	O10103[73] = + _CHROFF_51_1_;
	{long i; for (i = 74; i < 76; i++) O10103[i] = + _CHROFF_49_1_;}
	{long i; for (i = 80; i < 82; i++) O10103[i] = + _CHROFF_59_1_;}
	O10103[82] = + _CHROFF_65_1_;
	O10103[83] = + _CHROFF_68_1_;
	O10103[102] = + _CHROFF_42_1_;
	O10103[103] = + _CHROFF_44_1_;
	O10103[104] = + _CHROFF_51_1_;
	O10103[105] = + _CHROFF_58_1_;
	O10103[106] = + _CHROFF_45_1_;
	O10103[107] = + _CHROFF_44_1_;
	O10103[108] = + _CHROFF_43_1_;
	O10103[109] = + _CHROFF_46_1_;
	O10103[110] = + _CHROFF_44_1_;
	O10103[111] = + _CHROFF_51_1_;
	O10103[112] = + _CHROFF_50_1_;
	O10103[113] = + _CHROFF_59_1_;
	O10103[114] = + _CHROFF_51_1_;
	O10103[115] = + _CHROFF_53_1_;
	{long i; for (i = 116; i < 120; i++) O10103[i] = + _CHROFF_46_1_;}
	{long i; for (i = 128; i < 130; i++) O10103[i] = + _CHROFF_21_1_;}
	{long i; for (i = 135; i < 137; i++) O10103[i] = + _CHROFF_23_1_;}
	O10103[137] = + _CHROFF_24_1_;
	O10103[138] = + _CHROFF_23_1_;
	O10103[139] = + _CHROFF_26_1_;
	{long i; for (i = 144; i < 146; i++) O10103[i] = + _CHROFF_29_1_;}
	O10103[152] = + _CHROFF_48_1_;
	O10103[154] = + _CHROFF_48_1_;
}

long O10114[155];
void O10114_init () {
	{long i; for (i = 0; i < 4; i++) O10114[i] =  + _REFACS_1_;}
	O10114[18] =  + _REFACS_2_;
	{long i; for (i = 42; i < 44; i++) O10114[i] =  + _REFACS_3_;}
	{long i; for (i = 47; i < 50; i++) O10114[i] =  + _REFACS_3_;}
	O10114[51] =  + _REFACS_8_;
	O10114[53] =  + _REFACS_26_;
	O10114[55] =  + _REFACS_27_;
	O10114[59] =  + _REFACS_27_;
	O10114[60] =  + _REFACS_28_;
	O10114[61] =  + _REFACS_27_;
	{long i; for (i = 65; i < 68; i++) O10114[i] =  + _REFACS_28_;}
	{long i; for (i = 72; i < 76; i++) O10114[i] =  + _REFACS_28_;}
	{long i; for (i = 80; i < 82; i++) O10114[i] =  + _REFACS_32_;}
	{long i; for (i = 82; i < 84; i++) O10114[i] =  + _REFACS_35_;}
	O10114[102] =  + _REFACS_26_;
	O10114[103] =  + _REFACS_27_;
	O10114[104] =  + _REFACS_28_;
	O10114[105] =  + _REFACS_30_;
	O10114[106] =  + _REFACS_27_;
	O10114[107] =  + _REFACS_26_;
	O10114[108] =  + _REFACS_27_;
	O10114[109] =  + _REFACS_28_;
	O10114[110] =  + _REFACS_27_;
	O10114[111] =  + _REFACS_30_;
	O10114[112] =  + _REFACS_28_;
	O10114[113] =  + _REFACS_32_;
	O10114[114] =  + _REFACS_28_;
	O10114[115] =  + _REFACS_30_;
	{long i; for (i = 116; i < 120; i++) O10114[i] =  + _REFACS_27_;}
	{long i; for (i = 128; i < 130; i++) O10114[i] =  + _REFACS_11_;}
	{long i; for (i = 135; i < 139; i++) O10114[i] =  + _REFACS_12_;}
	O10114[139] =  + _REFACS_13_;
	{long i; for (i = 144; i < 146; i++) O10114[i] =  + _REFACS_15_;}
	O10114[152] =  + _REFACS_27_;
	O10114[154] =  + _REFACS_27_;
}

long O10116[155];
void O10116_init () {
	O10116[0] = + _CHROFF_2_1_;
	O10116[1] = + _CHROFF_4_1_;
	O10116[2] = + _CHROFF_5_1_;
	O10116[3] = + _CHROFF_10_1_;
	O10116[18] = + _CHROFF_6_1_;
	O10116[42] = + _CHROFF_8_1_;
	O10116[43] = + _CHROFF_9_1_;
	{long i; for (i = 47; i < 50; i++) O10116[i] = + _CHROFF_11_1_;}
	O10116[51] = + _CHROFF_16_2_;
	O10116[53] = + _CHROFF_42_2_;
	O10116[55] = + _CHROFF_46_2_;
	O10116[59] = + _CHROFF_47_2_;
	O10116[60] = + _CHROFF_49_2_;
	O10116[61] = + _CHROFF_47_2_;
	{long i; for (i = 65; i < 68; i++) O10116[i] = + _CHROFF_49_2_;}
	O10116[72] = + _CHROFF_49_2_;
	O10116[73] = + _CHROFF_51_2_;
	{long i; for (i = 74; i < 76; i++) O10116[i] = + _CHROFF_49_2_;}
	{long i; for (i = 80; i < 82; i++) O10116[i] = + _CHROFF_59_2_;}
	O10116[82] = + _CHROFF_65_2_;
	O10116[83] = + _CHROFF_68_2_;
	O10116[102] = + _CHROFF_42_2_;
	O10116[103] = + _CHROFF_44_2_;
	O10116[104] = + _CHROFF_51_2_;
	O10116[105] = + _CHROFF_58_2_;
	O10116[106] = + _CHROFF_45_2_;
	O10116[107] = + _CHROFF_44_2_;
	O10116[108] = + _CHROFF_43_2_;
	O10116[109] = + _CHROFF_46_2_;
	O10116[110] = + _CHROFF_44_2_;
	O10116[111] = + _CHROFF_51_2_;
	O10116[112] = + _CHROFF_50_2_;
	O10116[113] = + _CHROFF_59_2_;
	O10116[114] = + _CHROFF_51_2_;
	O10116[115] = + _CHROFF_53_2_;
	{long i; for (i = 116; i < 120; i++) O10116[i] = + _CHROFF_46_2_;}
	{long i; for (i = 128; i < 130; i++) O10116[i] = + _CHROFF_21_2_;}
	{long i; for (i = 135; i < 137; i++) O10116[i] = + _CHROFF_23_2_;}
	O10116[137] = + _CHROFF_24_2_;
	O10116[138] = + _CHROFF_23_2_;
	O10116[139] = + _CHROFF_26_2_;
	{long i; for (i = 144; i < 146; i++) O10116[i] = + _CHROFF_29_2_;}
	O10116[152] = + _CHROFF_48_2_;
	O10116[154] = + _CHROFF_48_2_;
}

long O10148[154];
void O10148_init () {
	{long i; for (i = 0; i < 3; i++) O10148[i] =  + _REFACS_2_;}
	{long i; for (i = 41; i < 43; i++) O10148[i] =  + _REFACS_4_;}
	{long i; for (i = 46; i < 49; i++) O10148[i] =  + _REFACS_4_;}
	O10148[50] =  + _REFACS_9_;
	O10148[52] =  + _REFACS_27_;
	O10148[54] =  + _REFACS_28_;
	O10148[58] =  + _REFACS_28_;
	O10148[59] =  + _REFACS_29_;
	O10148[60] =  + _REFACS_28_;
	{long i; for (i = 64; i < 67; i++) O10148[i] =  + _REFACS_29_;}
	{long i; for (i = 71; i < 75; i++) O10148[i] =  + _REFACS_29_;}
	{long i; for (i = 79; i < 81; i++) O10148[i] =  + _REFACS_33_;}
	{long i; for (i = 81; i < 83; i++) O10148[i] =  + _REFACS_36_;}
	O10148[101] =  + _REFACS_27_;
	O10148[102] =  + _REFACS_28_;
	O10148[103] =  + _REFACS_29_;
	O10148[104] =  + _REFACS_31_;
	O10148[105] =  + _REFACS_28_;
	O10148[106] =  + _REFACS_27_;
	O10148[107] =  + _REFACS_28_;
	O10148[108] =  + _REFACS_29_;
	O10148[109] =  + _REFACS_28_;
	O10148[110] =  + _REFACS_31_;
	O10148[111] =  + _REFACS_29_;
	O10148[112] =  + _REFACS_33_;
	O10148[113] =  + _REFACS_29_;
	O10148[114] =  + _REFACS_31_;
	{long i; for (i = 115; i < 119; i++) O10148[i] =  + _REFACS_28_;}
	{long i; for (i = 127; i < 129; i++) O10148[i] =  + _REFACS_12_;}
	{long i; for (i = 134; i < 138; i++) O10148[i] =  + _REFACS_13_;}
	O10148[138] =  + _REFACS_14_;
	{long i; for (i = 143; i < 145; i++) O10148[i] =  + _REFACS_16_;}
	O10148[151] =  + _REFACS_28_;
	O10148[153] =  + _REFACS_28_;
}

long O10149[154];
void O10149_init () {
	{long i; for (i = 0; i < 3; i++) O10149[i] =  + _REFACS_3_;}
	{long i; for (i = 41; i < 43; i++) O10149[i] =  + _REFACS_5_;}
	{long i; for (i = 46; i < 49; i++) O10149[i] =  + _REFACS_5_;}
	O10149[50] =  + _REFACS_10_;
	O10149[52] =  + _REFACS_28_;
	O10149[54] =  + _REFACS_29_;
	O10149[58] =  + _REFACS_29_;
	O10149[59] =  + _REFACS_30_;
	O10149[60] =  + _REFACS_29_;
	{long i; for (i = 64; i < 67; i++) O10149[i] =  + _REFACS_30_;}
	{long i; for (i = 71; i < 75; i++) O10149[i] =  + _REFACS_30_;}
	{long i; for (i = 79; i < 81; i++) O10149[i] =  + _REFACS_34_;}
	{long i; for (i = 81; i < 83; i++) O10149[i] =  + _REFACS_37_;}
	O10149[101] =  + _REFACS_28_;
	O10149[102] =  + _REFACS_29_;
	O10149[103] =  + _REFACS_30_;
	O10149[104] =  + _REFACS_32_;
	O10149[105] =  + _REFACS_29_;
	O10149[106] =  + _REFACS_28_;
	O10149[107] =  + _REFACS_29_;
	O10149[108] =  + _REFACS_30_;
	O10149[109] =  + _REFACS_29_;
	O10149[110] =  + _REFACS_32_;
	O10149[111] =  + _REFACS_30_;
	O10149[112] =  + _REFACS_34_;
	O10149[113] =  + _REFACS_30_;
	O10149[114] =  + _REFACS_32_;
	{long i; for (i = 115; i < 119; i++) O10149[i] =  + _REFACS_29_;}
	{long i; for (i = 127; i < 129; i++) O10149[i] =  + _REFACS_13_;}
	{long i; for (i = 134; i < 138; i++) O10149[i] =  + _REFACS_14_;}
	O10149[138] =  + _REFACS_15_;
	{long i; for (i = 143; i < 145; i++) O10149[i] =  + _REFACS_17_;}
	O10149[151] =  + _REFACS_29_;
	O10149[153] =  + _REFACS_29_;
}

long O10169[82];
void O10169_init () {
	{long i; for (i = 0; i < 2; i++) O10169[i] =  + _REFACS_4_;}
	{long i; for (i = 40; i < 42; i++) O10169[i] =  + _REFACS_6_;}
	{long i; for (i = 45; i < 48; i++) O10169[i] =  + _REFACS_6_;}
	{long i; for (i = 78; i < 80; i++) O10169[i] =  + _REFACS_35_;}
	{long i; for (i = 80; i < 82; i++) O10169[i] =  + _REFACS_38_;}
}

long O10176[82];
void O10176_init () {
	O10176[0] = + _CHROFF_5_2_;
	O10176[1] = + _CHROFF_10_2_;
	O10176[40] = + _CHROFF_8_2_;
	O10176[41] = + _CHROFF_9_2_;
	{long i; for (i = 45; i < 48; i++) O10176[i] = + _CHROFF_11_2_;}
	{long i; for (i = 78; i < 80; i++) O10176[i] = + _CHROFF_59_3_;}
	O10176[80] = + _CHROFF_65_3_;
	O10176[81] = + _CHROFF_68_3_;
}

long O10182[82];
void O10182_init () {
	O10182[0] = + _CHROFF_5_3_;
	O10182[1] = + _CHROFF_10_3_;
	O10182[40] = + _CHROFF_8_3_;
	O10182[41] = + _CHROFF_9_3_;
	{long i; for (i = 45; i < 48; i++) O10182[i] = + _CHROFF_11_3_;}
	{long i; for (i = 78; i < 80; i++) O10182[i] = + _CHROFF_59_4_;}
	O10182[80] = + _CHROFF_65_4_;
	O10182[81] = + _CHROFF_68_4_;
}

long O10232[135];
void O10232_init () {
	O10232[0] = + _LNGOFF_1_1_0_0_;
	O10232[1] = + _LNGOFF_2_1_0_0_;
	{long i; for (i = 2; i < 4; i++) O10232[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 4; i < 6; i++) O10232[i] = + _LNGOFF_2_1_0_0_;}
	O10232[6] = + _LNGOFF_4_1_0_0_;
	O10232[12] = + _LNGOFF_2_1_0_0_;
	O10232[13] = + _LNGOFF_6_3_0_1_;
	O10232[51] = + _LNGOFF_37_9_6_0_;
	O10232[52] = + _LNGOFF_38_9_6_0_;
	O10232[53] = + _LNGOFF_37_9_6_0_;
	O10232[54] = + _LNGOFF_47_12_10_1_;
	O10232[55] = + _LNGOFF_49_12_10_1_;
	O10232[56] = + _LNGOFF_47_12_10_1_;
	{long i; for (i = 57; i < 60; i++) O10232[i] = + _LNGOFF_39_10_6_0_;}
	{long i; for (i = 60; i < 63; i++) O10232[i] = + _LNGOFF_49_13_10_1_;}
	O10232[81] = + _LNGOFF_37_9_6_0_;
	O10232[82] = + _LNGOFF_43_9_6_0_;
	O10232[83] = + _LNGOFF_37_10_6_0_;
	O10232[93] = + _LNGOFF_37_9_6_0_;
	O10232[94] = + _LNGOFF_41_9_6_0_;
	O10232[95] = + _LNGOFF_37_10_6_0_;
	O10232[96] = + _LNGOFF_39_10_6_0_;
	O10232[99] = + _LNGOFF_51_13_10_1_;
	O10232[100] = + _LNGOFF_58_14_10_1_;
	O10232[101] = + _LNGOFF_45_16_10_1_;
	O10232[107] = + _LNGOFF_50_13_10_1_;
	O10232[108] = + _LNGOFF_59_16_10_1_;
	O10232[109] = + _LNGOFF_51_14_10_1_;
	O10232[110] = + _LNGOFF_53_14_10_1_;
	{long i; for (i = 119; i < 121; i++) O10232[i] = + _LNGOFF_20_5_6_0_;}
	{long i; for (i = 121; i < 123; i++) O10232[i] = + _LNGOFF_25_6_6_0_;}
	O10232[129] = + _LNGOFF_18_6_6_0_;
	O10232[134] = + _LNGOFF_26_8_6_1_;
}

long O10266[134];
void O10266_init () {
	O10266[0] =  + _REFACS_1_;
	O10266[4] =  + _REFACS_1_;
	O10266[5] =  + _REFACS_2_;
	O10266[12] =  + _REFACS_3_;
	O10266[53] =  + _REFACS_30_;
	O10266[54] =  + _REFACS_31_;
	O10266[55] =  + _REFACS_30_;
	{long i; for (i = 59; i < 62; i++) O10266[i] =  + _REFACS_31_;}
	O10266[98] =  + _REFACS_31_;
	O10266[99] =  + _REFACS_33_;
	O10266[100] =  + _REFACS_30_;
	O10266[106] =  + _REFACS_31_;
	O10266[107] =  + _REFACS_35_;
	O10266[108] =  + _REFACS_31_;
	O10266[109] =  + _REFACS_33_;
	{long i; for (i = 120; i < 122; i++) O10266[i] =  + _REFACS_15_;}
	O10266[133] =  + _REFACS_16_;
}

static EIF_TYPE_INDEX Y10266_pgtype0[] = {0xFF01,849,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype1[] = {0xFF01,849,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype2[] = {0xFF01,849,0xFF01,1254,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype3[] = {0xFF01,849,0xFF01,1254,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype4[] = {0xFF01,849,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype5[] = {0xFF01,849,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype6[] = {0xFF01,849,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype7[] = {0xFF01,849,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype8[] = {0xFF01,849,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype9[] = {0xFF01,849,0xFF01,1211,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype10[] = {0xFF01,849,0xFF01,1263,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype11[] = {0xFF01,849,0xFF01,1248,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype12[] = {0xFF01,849,0xFF01,1250,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype13[] = {0xFF01,849,0xFF01,1249,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype14[] = {0xFF01,849,0xFF01,1249,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype15[] = {0xFF01,849,0xFF01,1249,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype16[] = {0xFF01,849,0xFF01,1249,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype17[] = {0xFF01,849,0xFF01,1263,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype18[] = {0xFF01,849,0xFF01,1263,0xFFFF};
static EIF_TYPE_INDEX Y10266_pgtype19[] = {0xFF01,849,0xFF01,1254,0xFFFF};
EIF_TYPE_INDEX *Y10266_gen_type [134];
EIF_TYPE_INDEX Y10266 [134];
void Y10266_init (void)
{
	egc_routines_types [10266] = Y10266;
	egc_routines_gen_types [10266] = Y10266_gen_type;
	egc_routines_offset [10266] = 1305;
	Y10266_gen_type [0] = Y10266_pgtype0;
	Y10266_gen_type [4] = Y10266_pgtype1;
	Y10266_gen_type [5] = Y10266_pgtype2;
	Y10266_gen_type [12] = Y10266_pgtype3;
	Y10266_gen_type [53] = Y10266_pgtype4;
	Y10266_gen_type [54] = Y10266_pgtype5;
	Y10266_gen_type [55] = Y10266_pgtype6;
	Y10266_gen_type [59] = Y10266_pgtype7;
	Y10266_gen_type [60] = Y10266_pgtype8;
	Y10266_gen_type [61] = Y10266_pgtype9;
	Y10266_gen_type [98] = Y10266_pgtype10;
	Y10266_gen_type [99] = Y10266_pgtype11;
	Y10266_gen_type [100] = Y10266_pgtype12;
	Y10266_gen_type [106] = Y10266_pgtype13;
	Y10266_gen_type [107] = Y10266_pgtype14;
	Y10266_gen_type [108] = Y10266_pgtype15;
	Y10266_gen_type [109] = Y10266_pgtype16;
	Y10266_gen_type [120] = Y10266_pgtype17;
	Y10266_gen_type [121] = Y10266_pgtype18;
	Y10266_gen_type [133] = Y10266_pgtype19;
	Y10266[0] = 849;
	{long i; for (i = 4; i < 6; i++) Y10266[i] = 849;};
	Y10266[12] = 849;
	{long i; for (i = 53; i < 56; i++) Y10266[i] = 849;};
	{long i; for (i = 59; i < 62; i++) Y10266[i] = 849;};
	{long i; for (i = 98; i < 101; i++) Y10266[i] = 849;};
	{long i; for (i = 106; i < 110; i++) Y10266[i] = 849;};
	{long i; for (i = 120; i < 122; i++) Y10266[i] = 849;};
	Y10266[133] = 849;
}

long O10303[142];
void O10303_init () {
	O10303[0] =  + _REFACS_1_;
	O10303[40] =  + _REFACS_29_;
	O10303[42] =  + _REFACS_30_;
	O10303[46] =  + _REFACS_31_;
	O10303[47] =  + _REFACS_32_;
	O10303[48] =  + _REFACS_31_;
	{long i; for (i = 52; i < 55; i++) O10303[i] =  + _REFACS_32_;}
	{long i; for (i = 59; i < 63; i++) O10303[i] =  + _REFACS_31_;}
	{long i; for (i = 67; i < 69; i++) O10303[i] =  + _REFACS_36_;}
	{long i; for (i = 69; i < 71; i++) O10303[i] =  + _REFACS_39_;}
	O10303[89] =  + _REFACS_29_;
	O10303[90] =  + _REFACS_30_;
	O10303[91] =  + _REFACS_32_;
	O10303[92] =  + _REFACS_34_;
	O10303[93] =  + _REFACS_31_;
	O10303[94] =  + _REFACS_29_;
	O10303[95] =  + _REFACS_30_;
	O10303[96] =  + _REFACS_31_;
	O10303[97] =  + _REFACS_30_;
	O10303[98] =  + _REFACS_33_;
	O10303[99] =  + _REFACS_32_;
	O10303[100] =  + _REFACS_36_;
	O10303[101] =  + _REFACS_32_;
	O10303[102] =  + _REFACS_34_;
	{long i; for (i = 103; i < 107; i++) O10303[i] =  + _REFACS_30_;}
	O10303[139] =  + _REFACS_30_;
	O10303[141] =  + _REFACS_30_;
}

long O10304[142];
void O10304_init () {
	O10304[0] =  + _REFACS_2_;
	O10304[40] =  + _REFACS_30_;
	O10304[42] =  + _REFACS_31_;
	O10304[46] =  + _REFACS_32_;
	O10304[47] =  + _REFACS_33_;
	O10304[48] =  + _REFACS_32_;
	{long i; for (i = 52; i < 55; i++) O10304[i] =  + _REFACS_33_;}
	{long i; for (i = 59; i < 63; i++) O10304[i] =  + _REFACS_32_;}
	{long i; for (i = 67; i < 69; i++) O10304[i] =  + _REFACS_37_;}
	{long i; for (i = 69; i < 71; i++) O10304[i] =  + _REFACS_40_;}
	O10304[89] =  + _REFACS_30_;
	O10304[90] =  + _REFACS_31_;
	O10304[91] =  + _REFACS_33_;
	O10304[92] =  + _REFACS_35_;
	O10304[93] =  + _REFACS_32_;
	O10304[94] =  + _REFACS_30_;
	O10304[95] =  + _REFACS_31_;
	O10304[96] =  + _REFACS_32_;
	O10304[97] =  + _REFACS_31_;
	O10304[98] =  + _REFACS_34_;
	O10304[99] =  + _REFACS_33_;
	O10304[100] =  + _REFACS_37_;
	O10304[101] =  + _REFACS_33_;
	O10304[102] =  + _REFACS_35_;
	{long i; for (i = 103; i < 107; i++) O10304[i] =  + _REFACS_31_;}
	O10304[139] =  + _REFACS_31_;
	O10304[141] =  + _REFACS_31_;
}

long O10312[141];
void O10312_init () {
	{long i; for (i = 0; i < 2; i++) O10312[i] =  + _REFACS_6_;}
	O10312[38] =  + _REFACS_26_;
	O10312[39] =  + _REFACS_31_;
	O10312[40] =  + _REFACS_27_;
	O10312[41] =  + _REFACS_32_;
	O10312[42] =  + _REFACS_27_;
	O10312[43] =  + _REFACS_28_;
	O10312[44] =  + _REFACS_27_;
	O10312[45] =  + _REFACS_33_;
	O10312[46] =  + _REFACS_34_;
	O10312[47] =  + _REFACS_33_;
	{long i; for (i = 48; i < 51; i++) O10312[i] =  + _REFACS_28_;}
	{long i; for (i = 51; i < 54; i++) O10312[i] =  + _REFACS_34_;}
	{long i; for (i = 54; i < 58; i++) O10312[i] =  + _REFACS_28_;}
	{long i; for (i = 58; i < 62; i++) O10312[i] =  + _REFACS_33_;}
	{long i; for (i = 62; i < 64; i++) O10312[i] =  + _REFACS_32_;}
	{long i; for (i = 64; i < 66; i++) O10312[i] =  + _REFACS_35_;}
	{long i; for (i = 66; i < 68; i++) O10312[i] =  + _REFACS_38_;}
	{long i; for (i = 68; i < 70; i++) O10312[i] =  + _REFACS_41_;}
	O10312[70] =  + _REFACS_26_;
	O10312[71] =  + _REFACS_27_;
	O10312[72] =  + _REFACS_28_;
	O10312[73] =  + _REFACS_30_;
	O10312[74] =  + _REFACS_27_;
	O10312[75] =  + _REFACS_26_;
	O10312[76] =  + _REFACS_27_;
	O10312[77] =  + _REFACS_28_;
	O10312[78] =  + _REFACS_27_;
	O10312[79] =  + _REFACS_30_;
	{long i; for (i = 80; i < 84; i++) O10312[i] =  + _REFACS_27_;}
	O10312[84] =  + _REFACS_28_;
	O10312[85] =  + _REFACS_32_;
	O10312[86] =  + _REFACS_28_;
	O10312[87] =  + _REFACS_30_;
	O10312[88] =  + _REFACS_31_;
	O10312[89] =  + _REFACS_32_;
	O10312[90] =  + _REFACS_34_;
	O10312[91] =  + _REFACS_36_;
	O10312[92] =  + _REFACS_33_;
	O10312[93] =  + _REFACS_31_;
	O10312[94] =  + _REFACS_32_;
	O10312[95] =  + _REFACS_33_;
	O10312[96] =  + _REFACS_32_;
	O10312[97] =  + _REFACS_35_;
	O10312[98] =  + _REFACS_34_;
	O10312[99] =  + _REFACS_38_;
	O10312[100] =  + _REFACS_34_;
	O10312[101] =  + _REFACS_36_;
	{long i; for (i = 102; i < 106; i++) O10312[i] =  + _REFACS_32_;}
	{long i; for (i = 128; i < 130; i++) O10312[i] =  + _REFACS_15_;}
	{long i; for (i = 130; i < 132; i++) O10312[i] =  + _REFACS_18_;}
	O10312[133] =  + _REFACS_27_;
	O10312[135] =  + _REFACS_27_;
	O10312[138] =  + _REFACS_32_;
	O10312[140] =  + _REFACS_32_;
}

long O10313[141];
void O10313_init () {
	O10313[0] = + _CHROFF_7_1_;
	O10313[1] = + _CHROFF_8_1_;
	O10313[38] = + _CHROFF_35_1_;
	O10313[39] = + _CHROFF_42_3_;
	O10313[40] = + _CHROFF_37_1_;
	O10313[41] = + _CHROFF_46_3_;
	O10313[42] = + _CHROFF_37_1_;
	O10313[43] = + _CHROFF_38_1_;
	O10313[44] = + _CHROFF_37_1_;
	O10313[45] = + _CHROFF_47_3_;
	O10313[46] = + _CHROFF_49_3_;
	O10313[47] = + _CHROFF_47_3_;
	{long i; for (i = 48; i < 51; i++) O10313[i] = + _CHROFF_39_1_;}
	{long i; for (i = 51; i < 54; i++) O10313[i] = + _CHROFF_49_3_;}
	{long i; for (i = 54; i < 58; i++) O10313[i] = + _CHROFF_39_1_;}
	O10313[58] = + _CHROFF_49_3_;
	O10313[59] = + _CHROFF_51_3_;
	{long i; for (i = 60; i < 62; i++) O10313[i] = + _CHROFF_49_3_;}
	{long i; for (i = 62; i < 64; i++) O10313[i] = + _CHROFF_47_1_;}
	O10313[64] = + _CHROFF_50_1_;
	O10313[65] = + _CHROFF_53_1_;
	{long i; for (i = 66; i < 68; i++) O10313[i] = + _CHROFF_59_5_;}
	O10313[68] = + _CHROFF_65_5_;
	O10313[69] = + _CHROFF_68_5_;
	O10313[70] = + _CHROFF_35_1_;
	{long i; for (i = 71; i < 73; i++) O10313[i] = + _CHROFF_37_1_;}
	O10313[73] = + _CHROFF_43_1_;
	O10313[74] = + _CHROFF_37_1_;
	O10313[75] = + _CHROFF_35_1_;
	O10313[76] = + _CHROFF_36_1_;
	O10313[77] = + _CHROFF_37_1_;
	O10313[78] = + _CHROFF_36_1_;
	O10313[79] = + _CHROFF_40_1_;
	{long i; for (i = 80; i < 84; i++) O10313[i] = + _CHROFF_36_1_;}
	O10313[84] = + _CHROFF_37_1_;
	O10313[85] = + _CHROFF_41_1_;
	O10313[86] = + _CHROFF_37_1_;
	O10313[87] = + _CHROFF_39_1_;
	O10313[88] = + _CHROFF_42_3_;
	O10313[89] = + _CHROFF_44_3_;
	O10313[90] = + _CHROFF_51_3_;
	O10313[91] = + _CHROFF_58_3_;
	O10313[92] = + _CHROFF_45_3_;
	O10313[93] = + _CHROFF_44_3_;
	O10313[94] = + _CHROFF_43_3_;
	O10313[95] = + _CHROFF_46_3_;
	O10313[96] = + _CHROFF_44_3_;
	O10313[97] = + _CHROFF_51_3_;
	O10313[98] = + _CHROFF_50_3_;
	O10313[99] = + _CHROFF_59_3_;
	O10313[100] = + _CHROFF_51_3_;
	O10313[101] = + _CHROFF_53_3_;
	{long i; for (i = 102; i < 106; i++) O10313[i] = + _CHROFF_46_3_;}
	{long i; for (i = 128; i < 130; i++) O10313[i] = + _CHROFF_21_1_;}
	{long i; for (i = 130; i < 132; i++) O10313[i] = + _CHROFF_29_3_;}
	O10313[133] = + _CHROFF_36_1_;
	O10313[135] = + _CHROFF_36_1_;
	O10313[138] = + _CHROFF_48_3_;
	O10313[140] = + _CHROFF_48_3_;
}

long O10314[141];
void O10314_init () {
	O10314[0] = + _CHROFF_7_2_;
	O10314[1] = + _CHROFF_8_2_;
	O10314[38] = + _CHROFF_35_2_;
	O10314[39] = + _CHROFF_42_4_;
	O10314[40] = + _CHROFF_37_2_;
	O10314[41] = + _CHROFF_46_4_;
	O10314[42] = + _CHROFF_37_2_;
	O10314[43] = + _CHROFF_38_2_;
	O10314[44] = + _CHROFF_37_2_;
	O10314[45] = + _CHROFF_47_4_;
	O10314[46] = + _CHROFF_49_4_;
	O10314[47] = + _CHROFF_47_4_;
	{long i; for (i = 48; i < 51; i++) O10314[i] = + _CHROFF_39_2_;}
	{long i; for (i = 51; i < 54; i++) O10314[i] = + _CHROFF_49_4_;}
	{long i; for (i = 54; i < 58; i++) O10314[i] = + _CHROFF_39_2_;}
	O10314[58] = + _CHROFF_49_4_;
	O10314[59] = + _CHROFF_51_4_;
	{long i; for (i = 60; i < 62; i++) O10314[i] = + _CHROFF_49_4_;}
	{long i; for (i = 62; i < 64; i++) O10314[i] = + _CHROFF_47_2_;}
	O10314[64] = + _CHROFF_50_2_;
	O10314[65] = + _CHROFF_53_2_;
	{long i; for (i = 66; i < 68; i++) O10314[i] = + _CHROFF_59_6_;}
	O10314[68] = + _CHROFF_65_6_;
	O10314[69] = + _CHROFF_68_6_;
	O10314[70] = + _CHROFF_35_2_;
	{long i; for (i = 71; i < 73; i++) O10314[i] = + _CHROFF_37_2_;}
	O10314[73] = + _CHROFF_43_2_;
	O10314[74] = + _CHROFF_37_2_;
	O10314[75] = + _CHROFF_35_2_;
	O10314[76] = + _CHROFF_36_2_;
	O10314[77] = + _CHROFF_37_2_;
	O10314[78] = + _CHROFF_36_2_;
	O10314[79] = + _CHROFF_40_2_;
	{long i; for (i = 80; i < 84; i++) O10314[i] = + _CHROFF_36_2_;}
	O10314[84] = + _CHROFF_37_2_;
	O10314[85] = + _CHROFF_41_2_;
	O10314[86] = + _CHROFF_37_2_;
	O10314[87] = + _CHROFF_39_2_;
	O10314[88] = + _CHROFF_42_4_;
	O10314[89] = + _CHROFF_44_4_;
	O10314[90] = + _CHROFF_51_4_;
	O10314[91] = + _CHROFF_58_4_;
	O10314[92] = + _CHROFF_45_4_;
	O10314[93] = + _CHROFF_44_4_;
	O10314[94] = + _CHROFF_43_4_;
	O10314[95] = + _CHROFF_46_4_;
	O10314[96] = + _CHROFF_44_4_;
	O10314[97] = + _CHROFF_51_4_;
	O10314[98] = + _CHROFF_50_4_;
	O10314[99] = + _CHROFF_59_4_;
	O10314[100] = + _CHROFF_51_4_;
	O10314[101] = + _CHROFF_53_4_;
	{long i; for (i = 102; i < 106; i++) O10314[i] = + _CHROFF_46_4_;}
	{long i; for (i = 128; i < 130; i++) O10314[i] = + _CHROFF_21_2_;}
	{long i; for (i = 130; i < 132; i++) O10314[i] = + _CHROFF_29_4_;}
	O10314[133] = + _CHROFF_36_2_;
	O10314[135] = + _CHROFF_36_2_;
	O10314[138] = + _CHROFF_48_4_;
	O10314[140] = + _CHROFF_48_4_;
}

long O10316[141];
void O10316_init () {
	O10316[0] = + _CHROFF_7_3_;
	O10316[1] = + _CHROFF_8_3_;
	O10316[38] = + _CHROFF_35_3_;
	O10316[39] = + _CHROFF_42_5_;
	O10316[40] = + _CHROFF_37_3_;
	O10316[41] = + _CHROFF_46_5_;
	O10316[42] = + _CHROFF_37_3_;
	O10316[43] = + _CHROFF_38_3_;
	O10316[44] = + _CHROFF_37_3_;
	O10316[45] = + _CHROFF_47_5_;
	O10316[46] = + _CHROFF_49_5_;
	O10316[47] = + _CHROFF_47_5_;
	{long i; for (i = 48; i < 51; i++) O10316[i] = + _CHROFF_39_3_;}
	{long i; for (i = 51; i < 54; i++) O10316[i] = + _CHROFF_49_5_;}
	{long i; for (i = 54; i < 58; i++) O10316[i] = + _CHROFF_39_3_;}
	O10316[58] = + _CHROFF_49_5_;
	O10316[59] = + _CHROFF_51_5_;
	{long i; for (i = 60; i < 62; i++) O10316[i] = + _CHROFF_49_5_;}
	{long i; for (i = 62; i < 64; i++) O10316[i] = + _CHROFF_47_3_;}
	O10316[64] = + _CHROFF_50_3_;
	O10316[65] = + _CHROFF_53_3_;
	{long i; for (i = 66; i < 68; i++) O10316[i] = + _CHROFF_59_7_;}
	O10316[68] = + _CHROFF_65_7_;
	O10316[69] = + _CHROFF_68_7_;
	O10316[70] = + _CHROFF_35_3_;
	{long i; for (i = 71; i < 73; i++) O10316[i] = + _CHROFF_37_3_;}
	O10316[73] = + _CHROFF_43_3_;
	O10316[74] = + _CHROFF_37_3_;
	O10316[75] = + _CHROFF_35_3_;
	O10316[76] = + _CHROFF_36_3_;
	O10316[77] = + _CHROFF_37_3_;
	O10316[78] = + _CHROFF_36_3_;
	O10316[79] = + _CHROFF_40_3_;
	{long i; for (i = 80; i < 84; i++) O10316[i] = + _CHROFF_36_3_;}
	O10316[84] = + _CHROFF_37_3_;
	O10316[85] = + _CHROFF_41_3_;
	O10316[86] = + _CHROFF_37_3_;
	O10316[87] = + _CHROFF_39_3_;
	O10316[88] = + _CHROFF_42_5_;
	O10316[89] = + _CHROFF_44_5_;
	O10316[90] = + _CHROFF_51_5_;
	O10316[91] = + _CHROFF_58_5_;
	O10316[92] = + _CHROFF_45_5_;
	O10316[93] = + _CHROFF_44_5_;
	O10316[94] = + _CHROFF_43_5_;
	O10316[95] = + _CHROFF_46_5_;
	O10316[96] = + _CHROFF_44_5_;
	O10316[97] = + _CHROFF_51_5_;
	O10316[98] = + _CHROFF_50_5_;
	O10316[99] = + _CHROFF_59_5_;
	O10316[100] = + _CHROFF_51_5_;
	O10316[101] = + _CHROFF_53_5_;
	{long i; for (i = 102; i < 106; i++) O10316[i] = + _CHROFF_46_5_;}
	{long i; for (i = 128; i < 130; i++) O10316[i] = + _CHROFF_21_3_;}
	{long i; for (i = 130; i < 132; i++) O10316[i] = + _CHROFF_29_5_;}
	O10316[133] = + _CHROFF_36_3_;
	O10316[135] = + _CHROFF_36_3_;
	O10316[138] = + _CHROFF_48_5_;
	O10316[140] = + _CHROFF_48_5_;
}

long O10345[140];
void O10345_init () {
	O10345[0] = + _CHROFF_8_4_;
	O10345[38] = + _CHROFF_42_6_;
	O10345[40] = + _CHROFF_46_6_;
	O10345[44] = + _CHROFF_47_6_;
	O10345[45] = + _CHROFF_49_6_;
	O10345[46] = + _CHROFF_47_6_;
	{long i; for (i = 50; i < 53; i++) O10345[i] = + _CHROFF_49_6_;}
	O10345[57] = + _CHROFF_49_6_;
	O10345[58] = + _CHROFF_51_6_;
	{long i; for (i = 59; i < 61; i++) O10345[i] = + _CHROFF_49_6_;}
	{long i; for (i = 65; i < 67; i++) O10345[i] = + _CHROFF_59_8_;}
	O10345[67] = + _CHROFF_65_8_;
	O10345[68] = + _CHROFF_68_8_;
	O10345[87] = + _CHROFF_42_6_;
	O10345[88] = + _CHROFF_44_6_;
	O10345[89] = + _CHROFF_51_6_;
	O10345[90] = + _CHROFF_58_6_;
	O10345[91] = + _CHROFF_45_6_;
	O10345[92] = + _CHROFF_44_6_;
	O10345[93] = + _CHROFF_43_6_;
	O10345[94] = + _CHROFF_46_6_;
	O10345[95] = + _CHROFF_44_6_;
	O10345[96] = + _CHROFF_51_6_;
	O10345[97] = + _CHROFF_50_6_;
	O10345[98] = + _CHROFF_59_6_;
	O10345[99] = + _CHROFF_51_6_;
	O10345[100] = + _CHROFF_53_6_;
	{long i; for (i = 101; i < 105; i++) O10345[i] = + _CHROFF_46_6_;}
	{long i; for (i = 129; i < 131; i++) O10345[i] = + _CHROFF_29_6_;}
	O10345[137] = + _CHROFF_48_6_;
	O10345[139] = + _CHROFF_48_6_;
}

long O10346[140];
void O10346_init () {
	O10346[0] = + _I16OFF_8_6_4_;
	O10346[38] = + _I16OFF_42_12_4_;
	O10346[40] = + _I16OFF_46_12_4_;
	O10346[44] = + _I16OFF_47_12_4_;
	O10346[45] = + _I16OFF_49_12_4_;
	O10346[46] = + _I16OFF_47_12_4_;
	{long i; for (i = 50; i < 53; i++) O10346[i] = + _I16OFF_49_13_4_;}
	O10346[57] = + _I16OFF_49_13_4_;
	O10346[58] = + _I16OFF_51_13_4_;
	{long i; for (i = 59; i < 61; i++) O10346[i] = + _I16OFF_49_14_4_;}
	O10346[65] = + _I16OFF_59_21_4_;
	O10346[66] = + _I16OFF_59_23_4_;
	O10346[67] = + _I16OFF_65_25_4_;
	O10346[68] = + _I16OFF_68_26_4_;
	O10346[87] = + _I16OFF_42_13_4_;
	O10346[88] = + _I16OFF_44_13_4_;
	O10346[89] = + _I16OFF_51_13_4_;
	O10346[90] = + _I16OFF_58_14_4_;
	O10346[91] = + _I16OFF_45_16_4_;
	O10346[92] = + _I16OFF_44_13_4_;
	O10346[93] = + _I16OFF_43_13_4_;
	O10346[94] = + _I16OFF_46_14_4_;
	O10346[95] = + _I16OFF_44_15_4_;
	O10346[96] = + _I16OFF_51_18_4_;
	O10346[97] = + _I16OFF_50_13_4_;
	O10346[98] = + _I16OFF_59_16_4_;
	O10346[99] = + _I16OFF_51_14_4_;
	O10346[100] = + _I16OFF_53_14_4_;
	{long i; for (i = 101; i < 105; i++) O10346[i] = + _I16OFF_46_14_4_;}
	{long i; for (i = 129; i < 131; i++) O10346[i] = + _I16OFF_29_14_4_;}
	O10346[137] = + _I16OFF_48_19_4_;
	O10346[139] = + _I16OFF_48_18_4_;
}

long O10347[140];
void O10347_init () {
	O10347[0] = + _I16OFF_8_6_5_;
	O10347[38] = + _I16OFF_42_12_5_;
	O10347[40] = + _I16OFF_46_12_5_;
	O10347[44] = + _I16OFF_47_12_5_;
	O10347[45] = + _I16OFF_49_12_5_;
	O10347[46] = + _I16OFF_47_12_5_;
	{long i; for (i = 50; i < 53; i++) O10347[i] = + _I16OFF_49_13_5_;}
	O10347[57] = + _I16OFF_49_13_5_;
	O10347[58] = + _I16OFF_51_13_5_;
	{long i; for (i = 59; i < 61; i++) O10347[i] = + _I16OFF_49_14_5_;}
	O10347[65] = + _I16OFF_59_21_5_;
	O10347[66] = + _I16OFF_59_23_5_;
	O10347[67] = + _I16OFF_65_25_5_;
	O10347[68] = + _I16OFF_68_26_5_;
	O10347[87] = + _I16OFF_42_13_5_;
	O10347[88] = + _I16OFF_44_13_5_;
	O10347[89] = + _I16OFF_51_13_5_;
	O10347[90] = + _I16OFF_58_14_5_;
	O10347[91] = + _I16OFF_45_16_5_;
	O10347[92] = + _I16OFF_44_13_5_;
	O10347[93] = + _I16OFF_43_13_5_;
	O10347[94] = + _I16OFF_46_14_5_;
	O10347[95] = + _I16OFF_44_15_5_;
	O10347[96] = + _I16OFF_51_18_5_;
	O10347[97] = + _I16OFF_50_13_5_;
	O10347[98] = + _I16OFF_59_16_5_;
	O10347[99] = + _I16OFF_51_14_5_;
	O10347[100] = + _I16OFF_53_14_5_;
	{long i; for (i = 101; i < 105; i++) O10347[i] = + _I16OFF_46_14_5_;}
	{long i; for (i = 129; i < 131; i++) O10347[i] = + _I16OFF_29_14_5_;}
	O10347[137] = + _I16OFF_48_19_5_;
	O10347[139] = + _I16OFF_48_18_5_;
}

long O10352[140];
void O10352_init () {
	O10352[0] =  + _REFACS_7_;
	O10352[38] =  + _REFACS_32_;
	O10352[40] =  + _REFACS_33_;
	O10352[44] =  + _REFACS_34_;
	O10352[45] =  + _REFACS_35_;
	O10352[46] =  + _REFACS_34_;
	{long i; for (i = 50; i < 53; i++) O10352[i] =  + _REFACS_35_;}
	{long i; for (i = 57; i < 61; i++) O10352[i] =  + _REFACS_34_;}
	{long i; for (i = 65; i < 67; i++) O10352[i] =  + _REFACS_39_;}
	{long i; for (i = 67; i < 69; i++) O10352[i] =  + _REFACS_42_;}
	O10352[87] =  + _REFACS_32_;
	O10352[88] =  + _REFACS_33_;
	O10352[89] =  + _REFACS_35_;
	O10352[90] =  + _REFACS_37_;
	O10352[91] =  + _REFACS_34_;
	O10352[92] =  + _REFACS_32_;
	O10352[93] =  + _REFACS_33_;
	O10352[94] =  + _REFACS_34_;
	O10352[95] =  + _REFACS_33_;
	O10352[96] =  + _REFACS_36_;
	O10352[97] =  + _REFACS_35_;
	O10352[98] =  + _REFACS_39_;
	O10352[99] =  + _REFACS_35_;
	O10352[100] =  + _REFACS_37_;
	{long i; for (i = 101; i < 105; i++) O10352[i] =  + _REFACS_33_;}
	{long i; for (i = 129; i < 131; i++) O10352[i] =  + _REFACS_19_;}
	O10352[137] =  + _REFACS_33_;
	O10352[139] =  + _REFACS_33_;
}

long O10389[94];
void O10389_init () {
	O10389[0] = + _LNGOFF_1_1_0_0_;
	O10389[35] = + _LNGOFF_38_9_6_2_;
	O10389[38] = + _LNGOFF_49_12_10_3_;
	O10389[64] = + _LNGOFF_37_9_6_2_;
	O10389[65] = + _LNGOFF_43_9_6_2_;
	O10389[76] = + _LNGOFF_37_9_6_2_;
	O10389[77] = + _LNGOFF_41_9_6_2_;
	O10389[78] = + _LNGOFF_37_10_6_2_;
	O10389[79] = + _LNGOFF_39_10_6_2_;
	O10389[82] = + _LNGOFF_51_13_10_3_;
	O10389[83] = + _LNGOFF_58_14_10_3_;
	O10389[90] = + _LNGOFF_50_13_10_3_;
	O10389[91] = + _LNGOFF_59_16_10_3_;
	O10389[92] = + _LNGOFF_51_14_10_3_;
	O10389[93] = + _LNGOFF_53_14_10_3_;
}

long O10390[94];
void O10390_init () {
	O10390[0] = + _LNGOFF_1_1_0_1_;
	O10390[35] = + _LNGOFF_38_9_6_3_;
	O10390[38] = + _LNGOFF_49_12_10_4_;
	O10390[64] = + _LNGOFF_37_9_6_3_;
	O10390[65] = + _LNGOFF_43_9_6_3_;
	O10390[76] = + _LNGOFF_37_9_6_3_;
	O10390[77] = + _LNGOFF_41_9_6_3_;
	O10390[78] = + _LNGOFF_37_10_6_3_;
	O10390[79] = + _LNGOFF_39_10_6_3_;
	O10390[82] = + _LNGOFF_51_13_10_4_;
	O10390[83] = + _LNGOFF_58_14_10_4_;
	O10390[90] = + _LNGOFF_50_13_10_4_;
	O10390[91] = + _LNGOFF_59_16_10_4_;
	O10390[92] = + _LNGOFF_51_14_10_4_;
	O10390[93] = + _LNGOFF_53_14_10_4_;
}

long O10396[84];
void O10396_init () {
	{long i; for (i = 0; i < 2; i++) O10396[i] =  + _REFACS_2_;}
	{long i; for (i = 39; i < 42; i++) O10396[i] =  + _REFACS_29_;}
	{long i; for (i = 42; i < 45; i++) O10396[i] =  + _REFACS_36_;}
	{long i; for (i = 45; i < 49; i++) O10396[i] =  + _REFACS_29_;}
	{long i; for (i = 49; i < 53; i++) O10396[i] =  + _REFACS_35_;}
	{long i; for (i = 53; i < 55; i++) O10396[i] =  + _REFACS_33_;}
	{long i; for (i = 55; i < 57; i++) O10396[i] =  + _REFACS_36_;}
	{long i; for (i = 57; i < 59; i++) O10396[i] =  + _REFACS_40_;}
	{long i; for (i = 59; i < 61; i++) O10396[i] =  + _REFACS_43_;}
	O10396[65] =  + _REFACS_28_;
	O10396[83] =  + _REFACS_35_;
}

long O10397[84];
void O10397_init () {
	{long i; for (i = 0; i < 2; i++) O10397[i] = + _CHROFF_3_0_;}
	{long i; for (i = 39; i < 42; i++) O10397[i] = + _CHROFF_39_4_;}
	{long i; for (i = 42; i < 45; i++) O10397[i] = + _CHROFF_49_7_;}
	{long i; for (i = 45; i < 49; i++) O10397[i] = + _CHROFF_39_4_;}
	O10397[49] = + _CHROFF_49_7_;
	O10397[50] = + _CHROFF_51_7_;
	{long i; for (i = 51; i < 53; i++) O10397[i] = + _CHROFF_49_7_;}
	{long i; for (i = 53; i < 55; i++) O10397[i] = + _CHROFF_47_4_;}
	O10397[55] = + _CHROFF_50_4_;
	O10397[56] = + _CHROFF_53_4_;
	{long i; for (i = 57; i < 59; i++) O10397[i] = + _CHROFF_59_9_;}
	O10397[59] = + _CHROFF_65_9_;
	O10397[60] = + _CHROFF_68_9_;
	O10397[65] = + _CHROFF_37_4_;
	O10397[83] = + _CHROFF_45_7_;
}

long O10402[130];
void O10402_init () {
	{long i; for (i = 0; i < 2; i++) O10402[i] = + _CHROFF_1_0_;}
	O10402[27] = + _CHROFF_35_4_;
	O10402[28] = + _CHROFF_42_7_;
	O10402[29] = + _CHROFF_37_4_;
	O10402[30] = + _CHROFF_46_7_;
	O10402[31] = + _CHROFF_37_4_;
	O10402[32] = + _CHROFF_38_4_;
	O10402[33] = + _CHROFF_37_4_;
	O10402[34] = + _CHROFF_47_7_;
	O10402[35] = + _CHROFF_49_7_;
	O10402[36] = + _CHROFF_47_7_;
	{long i; for (i = 37; i < 40; i++) O10402[i] = + _CHROFF_39_5_;}
	{long i; for (i = 40; i < 43; i++) O10402[i] = + _CHROFF_49_8_;}
	{long i; for (i = 43; i < 47; i++) O10402[i] = + _CHROFF_39_5_;}
	O10402[47] = + _CHROFF_49_8_;
	O10402[48] = + _CHROFF_51_8_;
	{long i; for (i = 49; i < 51; i++) O10402[i] = + _CHROFF_49_8_;}
	{long i; for (i = 51; i < 53; i++) O10402[i] = + _CHROFF_47_5_;}
	O10402[53] = + _CHROFF_50_5_;
	O10402[54] = + _CHROFF_53_5_;
	{long i; for (i = 55; i < 57; i++) O10402[i] = + _CHROFF_59_10_;}
	O10402[57] = + _CHROFF_65_10_;
	O10402[58] = + _CHROFF_68_10_;
	O10402[59] = + _CHROFF_35_4_;
	{long i; for (i = 60; i < 62; i++) O10402[i] = + _CHROFF_37_4_;}
	O10402[62] = + _CHROFF_43_4_;
	O10402[63] = + _CHROFF_37_5_;
	O10402[64] = + _CHROFF_35_4_;
	O10402[65] = + _CHROFF_36_4_;
	O10402[66] = + _CHROFF_37_4_;
	O10402[67] = + _CHROFF_36_4_;
	O10402[68] = + _CHROFF_40_4_;
	{long i; for (i = 69; i < 73; i++) O10402[i] = + _CHROFF_36_4_;}
	O10402[73] = + _CHROFF_37_4_;
	O10402[74] = + _CHROFF_41_4_;
	O10402[75] = + _CHROFF_37_4_;
	O10402[76] = + _CHROFF_39_4_;
	O10402[77] = + _CHROFF_42_7_;
	O10402[78] = + _CHROFF_44_7_;
	O10402[79] = + _CHROFF_51_7_;
	O10402[80] = + _CHROFF_58_7_;
	O10402[81] = + _CHROFF_45_8_;
	O10402[82] = + _CHROFF_44_7_;
	O10402[83] = + _CHROFF_43_7_;
	O10402[84] = + _CHROFF_46_7_;
	O10402[85] = + _CHROFF_44_7_;
	O10402[86] = + _CHROFF_51_7_;
	O10402[87] = + _CHROFF_50_7_;
	O10402[88] = + _CHROFF_59_7_;
	O10402[89] = + _CHROFF_51_7_;
	O10402[90] = + _CHROFF_53_7_;
	{long i; for (i = 91; i < 95; i++) O10402[i] = + _CHROFF_46_7_;}
	{long i; for (i = 105; i < 109; i++) O10402[i] = + _CHROFF_17_1_;}
	O10402[109] = + _CHROFF_18_1_;
	{long i; for (i = 110; i < 112; i++) O10402[i] = + _CHROFF_23_3_;}
	O10402[112] = + _CHROFF_24_3_;
	O10402[113] = + _CHROFF_23_3_;
	O10402[114] = + _CHROFF_26_3_;
	{long i; for (i = 117; i < 119; i++) O10402[i] = + _CHROFF_21_4_;}
	{long i; for (i = 119; i < 121; i++) O10402[i] = + _CHROFF_29_7_;}
	O10402[122] = + _CHROFF_36_4_;
	O10402[124] = + _CHROFF_36_4_;
	O10402[127] = + _CHROFF_48_7_;
	O10402[129] = + _CHROFF_48_7_;
}

long O10429[113];
void O10429_init () {
	O10429[0] =  + _REFACS_1_;
	{long i; for (i = 83; i < 87; i++) O10429[i] =  + _REFACS_34_;}
	{long i; for (i = 95; i < 97; i++) O10429[i] =  + _REFACS_14_;}
	{long i; for (i = 102; i < 106; i++) O10429[i] =  + _REFACS_15_;}
	O10429[106] =  + _REFACS_18_;
	{long i; for (i = 111; i < 113; i++) O10429[i] =  + _REFACS_20_;}
}

long O10431[113];
void O10431_init () {
	O10431[0] = + _PTROFF_2_1_0_0_0_0_;
	{long i; for (i = 83; i < 87; i++) O10431[i] = + _PTROFF_46_14_10_6_0_1_;}
	{long i; for (i = 95; i < 97; i++) O10431[i] = + _PTROFF_21_7_6_1_0_1_;}
	O10431[102] = + _PTROFF_23_8_6_1_0_1_;
	O10431[103] = + _PTROFF_23_9_6_1_0_1_;
	O10431[104] = + _PTROFF_24_9_6_1_0_1_;
	O10431[105] = + _PTROFF_23_9_6_1_0_1_;
	O10431[106] = + _PTROFF_26_8_6_2_0_1_;
	{long i; for (i = 111; i < 113; i++) O10431[i] = + _PTROFF_29_14_8_2_0_1_;}
}

long O10436[85];
void O10436_init () {
	O10436[0] =  + _REFACS_1_;
	O10436[25] =  + _REFACS_36_;
	O10436[38] =  + _REFACS_36_;
	O10436[72] =  + _REFACS_33_;
	O10436[74] =  + _REFACS_35_;
	O10436[75] =  + _REFACS_34_;
	O10436[76] =  + _REFACS_37_;
	O10436[78] =  + _REFACS_40_;
	{long i; for (i = 81; i < 85; i++) O10436[i] =  + _REFACS_35_;}
}

long O10445[103];
void O10445_init () {
	O10445[0] = + _PTROFF_2_1_0_0_0_0_;
	O10445[70] = + _PTROFF_44_13_10_6_1_1_;
	{long i; for (i = 79; i < 83; i++) O10445[i] = + _PTROFF_46_14_10_6_0_2_;}
	O10445[98] = + _PTROFF_23_8_6_1_0_2_;
	O10445[99] = + _PTROFF_23_9_6_1_0_2_;
	O10445[100] = + _PTROFF_24_9_6_1_0_2_;
	O10445[101] = + _PTROFF_23_9_6_1_0_2_;
	O10445[102] = + _PTROFF_26_8_6_2_0_2_;
}

long O10447[103];
void O10447_init () {
	O10447[0] =  + _REFACS_1_;
	O10447[70] =  + _REFACS_34_;
	{long i; for (i = 79; i < 83; i++) O10447[i] =  + _REFACS_36_;}
	{long i; for (i = 98; i < 102; i++) O10447[i] =  + _REFACS_16_;}
	O10447[102] =  + _REFACS_19_;
}

long O10493[105];
void O10493_init () {
	O10493[0] =  + _REFACS_8_;
	O10493[1] =  + _REFACS_11_;
	O10493[2] =  + _REFACS_27_;
	O10493[3] =  + _REFACS_33_;
	O10493[4] =  + _REFACS_28_;
	O10493[5] =  + _REFACS_34_;
	O10493[6] =  + _REFACS_28_;
	O10493[7] =  + _REFACS_29_;
	O10493[8] =  + _REFACS_28_;
	O10493[9] =  + _REFACS_35_;
	O10493[10] =  + _REFACS_37_;
	O10493[11] =  + _REFACS_35_;
	{long i; for (i = 12; i < 15; i++) O10493[i] =  + _REFACS_30_;}
	{long i; for (i = 15; i < 18; i++) O10493[i] =  + _REFACS_37_;}
	{long i; for (i = 18; i < 22; i++) O10493[i] =  + _REFACS_30_;}
	O10493[22] =  + _REFACS_36_;
	O10493[23] =  + _REFACS_37_;
	{long i; for (i = 24; i < 26; i++) O10493[i] =  + _REFACS_36_;}
	{long i; for (i = 26; i < 28; i++) O10493[i] =  + _REFACS_34_;}
	{long i; for (i = 28; i < 30; i++) O10493[i] =  + _REFACS_37_;}
	{long i; for (i = 30; i < 32; i++) O10493[i] =  + _REFACS_41_;}
	{long i; for (i = 32; i < 34; i++) O10493[i] =  + _REFACS_44_;}
	O10493[34] =  + _REFACS_27_;
	O10493[35] =  + _REFACS_28_;
	O10493[36] =  + _REFACS_29_;
	O10493[37] =  + _REFACS_31_;
	O10493[38] =  + _REFACS_29_;
	O10493[39] =  + _REFACS_27_;
	O10493[40] =  + _REFACS_28_;
	O10493[41] =  + _REFACS_29_;
	O10493[42] =  + _REFACS_28_;
	O10493[43] =  + _REFACS_31_;
	{long i; for (i = 44; i < 48; i++) O10493[i] =  + _REFACS_28_;}
	O10493[48] =  + _REFACS_29_;
	O10493[49] =  + _REFACS_33_;
	O10493[50] =  + _REFACS_29_;
	O10493[51] =  + _REFACS_31_;
	O10493[52] =  + _REFACS_33_;
	O10493[53] =  + _REFACS_34_;
	O10493[54] =  + _REFACS_36_;
	O10493[55] =  + _REFACS_38_;
	O10493[56] =  + _REFACS_36_;
	O10493[57] =  + _REFACS_35_;
	O10493[58] =  + _REFACS_34_;
	O10493[59] =  + _REFACS_36_;
	O10493[60] =  + _REFACS_35_;
	O10493[61] =  + _REFACS_38_;
	O10493[62] =  + _REFACS_36_;
	O10493[63] =  + _REFACS_41_;
	O10493[64] =  + _REFACS_36_;
	O10493[65] =  + _REFACS_38_;
	{long i; for (i = 66; i < 70; i++) O10493[i] =  + _REFACS_37_;}
	{long i; for (i = 70; i < 72; i++) O10493[i] =  + _REFACS_11_;}
	{long i; for (i = 72; i < 74; i++) O10493[i] =  + _REFACS_13_;}
	{long i; for (i = 74; i < 76; i++) O10493[i] =  + _REFACS_15_;}
	{long i; for (i = 76; i < 78; i++) O10493[i] =  + _REFACS_16_;}
	{long i; for (i = 78; i < 80; i++) O10493[i] =  + _REFACS_15_;}
	{long i; for (i = 80; i < 84; i++) O10493[i] =  + _REFACS_12_;}
	O10493[84] =  + _REFACS_13_;
	{long i; for (i = 85; i < 89; i++) O10493[i] =  + _REFACS_17_;}
	O10493[89] =  + _REFACS_20_;
	{long i; for (i = 90; i < 92; i++) O10493[i] =  + _REFACS_13_;}
	{long i; for (i = 92; i < 94; i++) O10493[i] =  + _REFACS_16_;}
	{long i; for (i = 94; i < 96; i++) O10493[i] =  + _REFACS_21_;}
	O10493[97] =  + _REFACS_28_;
	O10493[99] =  + _REFACS_28_;
	O10493[102] =  + _REFACS_34_;
	O10493[104] =  + _REFACS_34_;
}

long O10494[105];
void O10494_init () {
	O10494[0] =  + _REFACS_9_;
	O10494[1] =  + _REFACS_12_;
	O10494[2] =  + _REFACS_28_;
	O10494[3] =  + _REFACS_34_;
	O10494[4] =  + _REFACS_29_;
	O10494[5] =  + _REFACS_35_;
	O10494[6] =  + _REFACS_29_;
	O10494[7] =  + _REFACS_30_;
	O10494[8] =  + _REFACS_29_;
	O10494[9] =  + _REFACS_36_;
	O10494[10] =  + _REFACS_38_;
	O10494[11] =  + _REFACS_36_;
	{long i; for (i = 12; i < 15; i++) O10494[i] =  + _REFACS_31_;}
	{long i; for (i = 15; i < 18; i++) O10494[i] =  + _REFACS_38_;}
	{long i; for (i = 18; i < 22; i++) O10494[i] =  + _REFACS_31_;}
	O10494[22] =  + _REFACS_37_;
	O10494[23] =  + _REFACS_38_;
	{long i; for (i = 24; i < 26; i++) O10494[i] =  + _REFACS_37_;}
	{long i; for (i = 26; i < 28; i++) O10494[i] =  + _REFACS_35_;}
	{long i; for (i = 28; i < 30; i++) O10494[i] =  + _REFACS_38_;}
	{long i; for (i = 30; i < 32; i++) O10494[i] =  + _REFACS_42_;}
	{long i; for (i = 32; i < 34; i++) O10494[i] =  + _REFACS_45_;}
	O10494[34] =  + _REFACS_28_;
	O10494[35] =  + _REFACS_29_;
	O10494[36] =  + _REFACS_30_;
	O10494[37] =  + _REFACS_32_;
	O10494[38] =  + _REFACS_30_;
	O10494[39] =  + _REFACS_28_;
	O10494[40] =  + _REFACS_29_;
	O10494[41] =  + _REFACS_30_;
	O10494[42] =  + _REFACS_29_;
	O10494[43] =  + _REFACS_32_;
	{long i; for (i = 44; i < 48; i++) O10494[i] =  + _REFACS_29_;}
	O10494[48] =  + _REFACS_30_;
	O10494[49] =  + _REFACS_34_;
	O10494[50] =  + _REFACS_30_;
	O10494[51] =  + _REFACS_32_;
	O10494[52] =  + _REFACS_34_;
	O10494[53] =  + _REFACS_35_;
	O10494[54] =  + _REFACS_37_;
	O10494[55] =  + _REFACS_39_;
	O10494[56] =  + _REFACS_37_;
	O10494[57] =  + _REFACS_36_;
	O10494[58] =  + _REFACS_35_;
	O10494[59] =  + _REFACS_37_;
	O10494[60] =  + _REFACS_36_;
	O10494[61] =  + _REFACS_39_;
	O10494[62] =  + _REFACS_37_;
	O10494[63] =  + _REFACS_42_;
	O10494[64] =  + _REFACS_37_;
	O10494[65] =  + _REFACS_39_;
	{long i; for (i = 66; i < 70; i++) O10494[i] =  + _REFACS_38_;}
	{long i; for (i = 70; i < 72; i++) O10494[i] =  + _REFACS_12_;}
	{long i; for (i = 72; i < 74; i++) O10494[i] =  + _REFACS_14_;}
	{long i; for (i = 74; i < 76; i++) O10494[i] =  + _REFACS_16_;}
	{long i; for (i = 76; i < 78; i++) O10494[i] =  + _REFACS_17_;}
	{long i; for (i = 78; i < 80; i++) O10494[i] =  + _REFACS_16_;}
	{long i; for (i = 80; i < 84; i++) O10494[i] =  + _REFACS_13_;}
	O10494[84] =  + _REFACS_14_;
	{long i; for (i = 85; i < 89; i++) O10494[i] =  + _REFACS_18_;}
	O10494[89] =  + _REFACS_21_;
	{long i; for (i = 90; i < 92; i++) O10494[i] =  + _REFACS_14_;}
	{long i; for (i = 92; i < 94; i++) O10494[i] =  + _REFACS_17_;}
	{long i; for (i = 94; i < 96; i++) O10494[i] =  + _REFACS_22_;}
	O10494[97] =  + _REFACS_29_;
	O10494[99] =  + _REFACS_29_;
	O10494[102] =  + _REFACS_35_;
	O10494[104] =  + _REFACS_35_;
}

long O10496[105];
void O10496_init () {
	O10496[0] =  + _REFACS_10_;
	O10496[1] =  + _REFACS_13_;
	O10496[2] =  + _REFACS_29_;
	O10496[3] =  + _REFACS_35_;
	O10496[4] =  + _REFACS_30_;
	O10496[5] =  + _REFACS_36_;
	O10496[6] =  + _REFACS_30_;
	O10496[7] =  + _REFACS_31_;
	O10496[8] =  + _REFACS_30_;
	O10496[9] =  + _REFACS_37_;
	O10496[10] =  + _REFACS_39_;
	O10496[11] =  + _REFACS_37_;
	{long i; for (i = 12; i < 15; i++) O10496[i] =  + _REFACS_32_;}
	{long i; for (i = 15; i < 18; i++) O10496[i] =  + _REFACS_39_;}
	{long i; for (i = 18; i < 22; i++) O10496[i] =  + _REFACS_32_;}
	O10496[22] =  + _REFACS_38_;
	O10496[23] =  + _REFACS_39_;
	{long i; for (i = 24; i < 26; i++) O10496[i] =  + _REFACS_38_;}
	{long i; for (i = 26; i < 28; i++) O10496[i] =  + _REFACS_36_;}
	{long i; for (i = 28; i < 30; i++) O10496[i] =  + _REFACS_39_;}
	{long i; for (i = 30; i < 32; i++) O10496[i] =  + _REFACS_43_;}
	{long i; for (i = 32; i < 34; i++) O10496[i] =  + _REFACS_46_;}
	O10496[34] =  + _REFACS_29_;
	O10496[35] =  + _REFACS_30_;
	O10496[36] =  + _REFACS_31_;
	O10496[37] =  + _REFACS_33_;
	O10496[38] =  + _REFACS_31_;
	O10496[39] =  + _REFACS_29_;
	O10496[40] =  + _REFACS_30_;
	O10496[41] =  + _REFACS_31_;
	O10496[42] =  + _REFACS_30_;
	O10496[43] =  + _REFACS_33_;
	{long i; for (i = 44; i < 48; i++) O10496[i] =  + _REFACS_30_;}
	O10496[48] =  + _REFACS_31_;
	O10496[49] =  + _REFACS_35_;
	O10496[50] =  + _REFACS_31_;
	O10496[51] =  + _REFACS_33_;
	O10496[52] =  + _REFACS_35_;
	O10496[53] =  + _REFACS_36_;
	O10496[54] =  + _REFACS_38_;
	O10496[55] =  + _REFACS_40_;
	O10496[56] =  + _REFACS_38_;
	O10496[57] =  + _REFACS_37_;
	O10496[58] =  + _REFACS_36_;
	O10496[59] =  + _REFACS_38_;
	O10496[60] =  + _REFACS_37_;
	O10496[61] =  + _REFACS_40_;
	O10496[62] =  + _REFACS_38_;
	O10496[63] =  + _REFACS_43_;
	O10496[64] =  + _REFACS_38_;
	O10496[65] =  + _REFACS_40_;
	{long i; for (i = 66; i < 70; i++) O10496[i] =  + _REFACS_39_;}
	{long i; for (i = 70; i < 72; i++) O10496[i] =  + _REFACS_13_;}
	{long i; for (i = 72; i < 74; i++) O10496[i] =  + _REFACS_15_;}
	{long i; for (i = 74; i < 76; i++) O10496[i] =  + _REFACS_17_;}
	{long i; for (i = 76; i < 78; i++) O10496[i] =  + _REFACS_18_;}
	{long i; for (i = 78; i < 80; i++) O10496[i] =  + _REFACS_17_;}
	{long i; for (i = 80; i < 84; i++) O10496[i] =  + _REFACS_14_;}
	O10496[84] =  + _REFACS_15_;
	{long i; for (i = 85; i < 89; i++) O10496[i] =  + _REFACS_19_;}
	O10496[89] =  + _REFACS_22_;
	{long i; for (i = 90; i < 92; i++) O10496[i] =  + _REFACS_15_;}
	{long i; for (i = 92; i < 94; i++) O10496[i] =  + _REFACS_18_;}
	{long i; for (i = 94; i < 96; i++) O10496[i] =  + _REFACS_23_;}
	O10496[97] =  + _REFACS_30_;
	O10496[99] =  + _REFACS_30_;
	O10496[102] =  + _REFACS_36_;
	O10496[104] =  + _REFACS_36_;
}

long O10497[105];
void O10497_init () {
	O10497[0] =  + _REFACS_11_;
	O10497[1] =  + _REFACS_14_;
	O10497[2] =  + _REFACS_30_;
	O10497[3] =  + _REFACS_36_;
	O10497[4] =  + _REFACS_31_;
	O10497[5] =  + _REFACS_37_;
	O10497[6] =  + _REFACS_31_;
	O10497[7] =  + _REFACS_32_;
	O10497[8] =  + _REFACS_31_;
	O10497[9] =  + _REFACS_38_;
	O10497[10] =  + _REFACS_40_;
	O10497[11] =  + _REFACS_38_;
	{long i; for (i = 12; i < 15; i++) O10497[i] =  + _REFACS_33_;}
	{long i; for (i = 15; i < 18; i++) O10497[i] =  + _REFACS_40_;}
	{long i; for (i = 18; i < 22; i++) O10497[i] =  + _REFACS_33_;}
	O10497[22] =  + _REFACS_39_;
	O10497[23] =  + _REFACS_40_;
	{long i; for (i = 24; i < 26; i++) O10497[i] =  + _REFACS_39_;}
	{long i; for (i = 26; i < 28; i++) O10497[i] =  + _REFACS_37_;}
	{long i; for (i = 28; i < 30; i++) O10497[i] =  + _REFACS_40_;}
	{long i; for (i = 30; i < 32; i++) O10497[i] =  + _REFACS_44_;}
	{long i; for (i = 32; i < 34; i++) O10497[i] =  + _REFACS_47_;}
	O10497[34] =  + _REFACS_30_;
	O10497[35] =  + _REFACS_31_;
	O10497[36] =  + _REFACS_32_;
	O10497[37] =  + _REFACS_34_;
	O10497[38] =  + _REFACS_32_;
	O10497[39] =  + _REFACS_30_;
	O10497[40] =  + _REFACS_31_;
	O10497[41] =  + _REFACS_32_;
	O10497[42] =  + _REFACS_31_;
	O10497[43] =  + _REFACS_34_;
	{long i; for (i = 44; i < 48; i++) O10497[i] =  + _REFACS_31_;}
	O10497[48] =  + _REFACS_32_;
	O10497[49] =  + _REFACS_36_;
	O10497[50] =  + _REFACS_32_;
	O10497[51] =  + _REFACS_34_;
	O10497[52] =  + _REFACS_36_;
	O10497[53] =  + _REFACS_37_;
	O10497[54] =  + _REFACS_39_;
	O10497[55] =  + _REFACS_41_;
	O10497[56] =  + _REFACS_39_;
	O10497[57] =  + _REFACS_38_;
	O10497[58] =  + _REFACS_37_;
	O10497[59] =  + _REFACS_39_;
	O10497[60] =  + _REFACS_38_;
	O10497[61] =  + _REFACS_41_;
	O10497[62] =  + _REFACS_39_;
	O10497[63] =  + _REFACS_44_;
	O10497[64] =  + _REFACS_39_;
	O10497[65] =  + _REFACS_41_;
	{long i; for (i = 66; i < 70; i++) O10497[i] =  + _REFACS_40_;}
	{long i; for (i = 70; i < 72; i++) O10497[i] =  + _REFACS_14_;}
	{long i; for (i = 72; i < 74; i++) O10497[i] =  + _REFACS_16_;}
	{long i; for (i = 74; i < 76; i++) O10497[i] =  + _REFACS_18_;}
	{long i; for (i = 76; i < 78; i++) O10497[i] =  + _REFACS_19_;}
	{long i; for (i = 78; i < 80; i++) O10497[i] =  + _REFACS_18_;}
	{long i; for (i = 80; i < 84; i++) O10497[i] =  + _REFACS_15_;}
	O10497[84] =  + _REFACS_16_;
	{long i; for (i = 85; i < 89; i++) O10497[i] =  + _REFACS_20_;}
	O10497[89] =  + _REFACS_23_;
	{long i; for (i = 90; i < 92; i++) O10497[i] =  + _REFACS_16_;}
	{long i; for (i = 92; i < 94; i++) O10497[i] =  + _REFACS_19_;}
	{long i; for (i = 94; i < 96; i++) O10497[i] =  + _REFACS_24_;}
	O10497[97] =  + _REFACS_31_;
	O10497[99] =  + _REFACS_31_;
	O10497[102] =  + _REFACS_37_;
	O10497[104] =  + _REFACS_37_;
}

long O10498[105];
void O10498_init () {
	O10498[0] =  + _REFACS_12_;
	O10498[1] =  + _REFACS_15_;
	O10498[2] =  + _REFACS_31_;
	O10498[3] =  + _REFACS_37_;
	O10498[4] =  + _REFACS_32_;
	O10498[5] =  + _REFACS_38_;
	O10498[6] =  + _REFACS_32_;
	O10498[7] =  + _REFACS_33_;
	O10498[8] =  + _REFACS_32_;
	O10498[9] =  + _REFACS_39_;
	O10498[10] =  + _REFACS_41_;
	O10498[11] =  + _REFACS_39_;
	{long i; for (i = 12; i < 15; i++) O10498[i] =  + _REFACS_34_;}
	{long i; for (i = 15; i < 18; i++) O10498[i] =  + _REFACS_41_;}
	{long i; for (i = 18; i < 22; i++) O10498[i] =  + _REFACS_34_;}
	O10498[22] =  + _REFACS_40_;
	O10498[23] =  + _REFACS_41_;
	{long i; for (i = 24; i < 26; i++) O10498[i] =  + _REFACS_40_;}
	{long i; for (i = 26; i < 28; i++) O10498[i] =  + _REFACS_38_;}
	{long i; for (i = 28; i < 30; i++) O10498[i] =  + _REFACS_41_;}
	{long i; for (i = 30; i < 32; i++) O10498[i] =  + _REFACS_45_;}
	{long i; for (i = 32; i < 34; i++) O10498[i] =  + _REFACS_48_;}
	O10498[34] =  + _REFACS_31_;
	O10498[35] =  + _REFACS_32_;
	O10498[36] =  + _REFACS_33_;
	O10498[37] =  + _REFACS_35_;
	O10498[38] =  + _REFACS_33_;
	O10498[39] =  + _REFACS_31_;
	O10498[40] =  + _REFACS_32_;
	O10498[41] =  + _REFACS_33_;
	O10498[42] =  + _REFACS_32_;
	O10498[43] =  + _REFACS_35_;
	{long i; for (i = 44; i < 48; i++) O10498[i] =  + _REFACS_32_;}
	O10498[48] =  + _REFACS_33_;
	O10498[49] =  + _REFACS_37_;
	O10498[50] =  + _REFACS_33_;
	O10498[51] =  + _REFACS_35_;
	O10498[52] =  + _REFACS_37_;
	O10498[53] =  + _REFACS_38_;
	O10498[54] =  + _REFACS_40_;
	O10498[55] =  + _REFACS_42_;
	O10498[56] =  + _REFACS_40_;
	O10498[57] =  + _REFACS_39_;
	O10498[58] =  + _REFACS_38_;
	O10498[59] =  + _REFACS_40_;
	O10498[60] =  + _REFACS_39_;
	O10498[61] =  + _REFACS_42_;
	O10498[62] =  + _REFACS_40_;
	O10498[63] =  + _REFACS_45_;
	O10498[64] =  + _REFACS_40_;
	O10498[65] =  + _REFACS_42_;
	{long i; for (i = 66; i < 70; i++) O10498[i] =  + _REFACS_41_;}
	{long i; for (i = 70; i < 72; i++) O10498[i] =  + _REFACS_15_;}
	{long i; for (i = 72; i < 74; i++) O10498[i] =  + _REFACS_17_;}
	{long i; for (i = 74; i < 76; i++) O10498[i] =  + _REFACS_19_;}
	{long i; for (i = 76; i < 78; i++) O10498[i] =  + _REFACS_20_;}
	{long i; for (i = 78; i < 80; i++) O10498[i] =  + _REFACS_19_;}
	{long i; for (i = 80; i < 84; i++) O10498[i] =  + _REFACS_16_;}
	O10498[84] =  + _REFACS_17_;
	{long i; for (i = 85; i < 89; i++) O10498[i] =  + _REFACS_21_;}
	O10498[89] =  + _REFACS_24_;
	{long i; for (i = 90; i < 92; i++) O10498[i] =  + _REFACS_17_;}
	{long i; for (i = 92; i < 94; i++) O10498[i] =  + _REFACS_20_;}
	{long i; for (i = 94; i < 96; i++) O10498[i] =  + _REFACS_25_;}
	O10498[97] =  + _REFACS_32_;
	O10498[99] =  + _REFACS_32_;
	O10498[102] =  + _REFACS_38_;
	O10498[104] =  + _REFACS_38_;
}

long O10518[105];
void O10518_init () {
	O10518[0] = + _CHROFF_13_1_;
	O10518[1] = + _CHROFF_16_3_;
	O10518[2] = + _CHROFF_35_5_;
	O10518[3] = + _CHROFF_42_8_;
	O10518[4] = + _CHROFF_37_5_;
	O10518[5] = + _CHROFF_46_8_;
	O10518[6] = + _CHROFF_37_5_;
	O10518[7] = + _CHROFF_38_5_;
	O10518[8] = + _CHROFF_37_5_;
	O10518[9] = + _CHROFF_47_8_;
	O10518[10] = + _CHROFF_49_8_;
	O10518[11] = + _CHROFF_47_8_;
	{long i; for (i = 12; i < 15; i++) O10518[i] = + _CHROFF_39_6_;}
	{long i; for (i = 15; i < 18; i++) O10518[i] = + _CHROFF_49_9_;}
	{long i; for (i = 18; i < 22; i++) O10518[i] = + _CHROFF_39_6_;}
	O10518[22] = + _CHROFF_49_9_;
	O10518[23] = + _CHROFF_51_9_;
	{long i; for (i = 24; i < 26; i++) O10518[i] = + _CHROFF_49_9_;}
	{long i; for (i = 26; i < 28; i++) O10518[i] = + _CHROFF_47_6_;}
	O10518[28] = + _CHROFF_50_6_;
	O10518[29] = + _CHROFF_53_6_;
	{long i; for (i = 30; i < 32; i++) O10518[i] = + _CHROFF_59_11_;}
	O10518[32] = + _CHROFF_65_11_;
	O10518[33] = + _CHROFF_68_11_;
	O10518[34] = + _CHROFF_35_5_;
	{long i; for (i = 35; i < 37; i++) O10518[i] = + _CHROFF_37_5_;}
	O10518[37] = + _CHROFF_43_5_;
	O10518[38] = + _CHROFF_37_6_;
	O10518[39] = + _CHROFF_35_5_;
	O10518[40] = + _CHROFF_36_5_;
	O10518[41] = + _CHROFF_37_5_;
	O10518[42] = + _CHROFF_36_5_;
	O10518[43] = + _CHROFF_40_5_;
	{long i; for (i = 44; i < 48; i++) O10518[i] = + _CHROFF_36_5_;}
	O10518[48] = + _CHROFF_37_5_;
	O10518[49] = + _CHROFF_41_5_;
	O10518[50] = + _CHROFF_37_5_;
	O10518[51] = + _CHROFF_39_5_;
	O10518[52] = + _CHROFF_42_8_;
	O10518[53] = + _CHROFF_44_8_;
	O10518[54] = + _CHROFF_51_8_;
	O10518[55] = + _CHROFF_58_8_;
	O10518[56] = + _CHROFF_45_9_;
	O10518[57] = + _CHROFF_44_8_;
	O10518[58] = + _CHROFF_43_8_;
	O10518[59] = + _CHROFF_46_8_;
	O10518[60] = + _CHROFF_44_8_;
	O10518[61] = + _CHROFF_51_8_;
	O10518[62] = + _CHROFF_50_8_;
	O10518[63] = + _CHROFF_59_8_;
	O10518[64] = + _CHROFF_51_8_;
	O10518[65] = + _CHROFF_53_8_;
	{long i; for (i = 66; i < 70; i++) O10518[i] = + _CHROFF_46_8_;}
	{long i; for (i = 70; i < 72; i++) O10518[i] = + _CHROFF_16_1_;}
	O10518[72] = + _CHROFF_18_1_;
	O10518[73] = + _CHROFF_23_1_;
	{long i; for (i = 74; i < 76; i++) O10518[i] = + _CHROFF_20_1_;}
	{long i; for (i = 76; i < 78; i++) O10518[i] = + _CHROFF_25_1_;}
	{long i; for (i = 78; i < 80; i++) O10518[i] = + _CHROFF_21_3_;}
	{long i; for (i = 80; i < 84; i++) O10518[i] = + _CHROFF_17_2_;}
	O10518[84] = + _CHROFF_18_2_;
	{long i; for (i = 85; i < 87; i++) O10518[i] = + _CHROFF_23_4_;}
	O10518[87] = + _CHROFF_24_4_;
	O10518[88] = + _CHROFF_23_4_;
	O10518[89] = + _CHROFF_26_4_;
	O10518[90] = + _CHROFF_19_1_;
	O10518[91] = + _CHROFF_22_1_;
	{long i; for (i = 92; i < 94; i++) O10518[i] = + _CHROFF_21_5_;}
	{long i; for (i = 94; i < 96; i++) O10518[i] = + _CHROFF_29_8_;}
	O10518[97] = + _CHROFF_36_5_;
	O10518[99] = + _CHROFF_36_5_;
	O10518[102] = + _CHROFF_48_8_;
	O10518[104] = + _CHROFF_48_8_;
}

long O10523[105];
void O10523_init () {
	O10523[0] = + _I16OFF_13_5_4_;
	O10523[1] = + _I16OFF_16_7_4_;
	O10523[2] = + _I16OFF_35_9_4_;
	O10523[3] = + _I16OFF_42_12_6_;
	O10523[4] = + _I16OFF_37_9_4_;
	O10523[5] = + _I16OFF_46_12_6_;
	O10523[6] = + _I16OFF_37_9_4_;
	O10523[7] = + _I16OFF_38_9_4_;
	O10523[8] = + _I16OFF_37_9_4_;
	O10523[9] = + _I16OFF_47_12_6_;
	O10523[10] = + _I16OFF_49_12_6_;
	O10523[11] = + _I16OFF_47_12_6_;
	{long i; for (i = 12; i < 15; i++) O10523[i] = + _I16OFF_39_10_4_;}
	{long i; for (i = 15; i < 18; i++) O10523[i] = + _I16OFF_49_13_6_;}
	{long i; for (i = 18; i < 22; i++) O10523[i] = + _I16OFF_39_10_4_;}
	O10523[22] = + _I16OFF_49_13_6_;
	O10523[23] = + _I16OFF_51_13_6_;
	{long i; for (i = 24; i < 26; i++) O10523[i] = + _I16OFF_49_14_6_;}
	O10523[26] = + _I16OFF_47_12_4_;
	O10523[27] = + _I16OFF_47_14_4_;
	O10523[28] = + _I16OFF_50_13_4_;
	O10523[29] = + _I16OFF_53_13_4_;
	O10523[30] = + _I16OFF_59_21_6_;
	O10523[31] = + _I16OFF_59_23_6_;
	O10523[32] = + _I16OFF_65_25_6_;
	O10523[33] = + _I16OFF_68_26_6_;
	O10523[34] = + _I16OFF_35_9_4_;
	{long i; for (i = 35; i < 37; i++) O10523[i] = + _I16OFF_37_9_4_;}
	O10523[37] = + _I16OFF_43_9_4_;
	O10523[38] = + _I16OFF_37_10_4_;
	O10523[39] = + _I16OFF_35_9_4_;
	O10523[40] = + _I16OFF_36_9_4_;
	O10523[41] = + _I16OFF_37_9_4_;
	O10523[42] = + _I16OFF_36_9_4_;
	O10523[43] = + _I16OFF_40_12_4_;
	{long i; for (i = 44; i < 48; i++) O10523[i] = + _I16OFF_36_9_4_;}
	O10523[48] = + _I16OFF_37_9_4_;
	O10523[49] = + _I16OFF_41_9_4_;
	O10523[50] = + _I16OFF_37_10_4_;
	O10523[51] = + _I16OFF_39_10_4_;
	O10523[52] = + _I16OFF_42_13_6_;
	O10523[53] = + _I16OFF_44_13_6_;
	O10523[54] = + _I16OFF_51_13_6_;
	O10523[55] = + _I16OFF_58_14_6_;
	O10523[56] = + _I16OFF_45_16_6_;
	O10523[57] = + _I16OFF_44_13_6_;
	O10523[58] = + _I16OFF_43_13_6_;
	O10523[59] = + _I16OFF_46_14_6_;
	O10523[60] = + _I16OFF_44_15_6_;
	O10523[61] = + _I16OFF_51_18_6_;
	O10523[62] = + _I16OFF_50_13_6_;
	O10523[63] = + _I16OFF_59_16_6_;
	O10523[64] = + _I16OFF_51_14_6_;
	O10523[65] = + _I16OFF_53_14_6_;
	{long i; for (i = 66; i < 70; i++) O10523[i] = + _I16OFF_46_14_6_;}
	{long i; for (i = 70; i < 72; i++) O10523[i] = + _I16OFF_16_5_4_;}
	O10523[72] = + _I16OFF_18_5_4_;
	O10523[73] = + _I16OFF_23_5_4_;
	{long i; for (i = 74; i < 76; i++) O10523[i] = + _I16OFF_20_5_4_;}
	{long i; for (i = 76; i < 78; i++) O10523[i] = + _I16OFF_25_6_4_;}
	{long i; for (i = 78; i < 80; i++) O10523[i] = + _I16OFF_21_7_4_;}
	{long i; for (i = 80; i < 84; i++) O10523[i] = + _I16OFF_17_6_4_;}
	O10523[84] = + _I16OFF_18_6_4_;
	O10523[85] = + _I16OFF_23_8_4_;
	O10523[86] = + _I16OFF_23_9_4_;
	O10523[87] = + _I16OFF_24_9_4_;
	O10523[88] = + _I16OFF_23_9_4_;
	O10523[89] = + _I16OFF_26_8_4_;
	O10523[90] = + _I16OFF_19_5_4_;
	O10523[91] = + _I16OFF_22_5_4_;
	{long i; for (i = 92; i < 94; i++) O10523[i] = + _I16OFF_21_10_4_;}
	{long i; for (i = 94; i < 96; i++) O10523[i] = + _I16OFF_29_14_6_;}
	O10523[97] = + _I16OFF_36_10_4_;
	O10523[99] = + _I16OFF_36_9_4_;
	O10523[102] = + _I16OFF_48_19_6_;
	O10523[104] = + _I16OFF_48_18_6_;
}

long O10524[105];
void O10524_init () {
	O10524[0] = + _I16OFF_13_5_5_;
	O10524[1] = + _I16OFF_16_7_5_;
	O10524[2] = + _I16OFF_35_9_5_;
	O10524[3] = + _I16OFF_42_12_7_;
	O10524[4] = + _I16OFF_37_9_5_;
	O10524[5] = + _I16OFF_46_12_7_;
	O10524[6] = + _I16OFF_37_9_5_;
	O10524[7] = + _I16OFF_38_9_5_;
	O10524[8] = + _I16OFF_37_9_5_;
	O10524[9] = + _I16OFF_47_12_7_;
	O10524[10] = + _I16OFF_49_12_7_;
	O10524[11] = + _I16OFF_47_12_7_;
	{long i; for (i = 12; i < 15; i++) O10524[i] = + _I16OFF_39_10_5_;}
	{long i; for (i = 15; i < 18; i++) O10524[i] = + _I16OFF_49_13_7_;}
	{long i; for (i = 18; i < 22; i++) O10524[i] = + _I16OFF_39_10_5_;}
	O10524[22] = + _I16OFF_49_13_7_;
	O10524[23] = + _I16OFF_51_13_7_;
	{long i; for (i = 24; i < 26; i++) O10524[i] = + _I16OFF_49_14_7_;}
	O10524[26] = + _I16OFF_47_12_5_;
	O10524[27] = + _I16OFF_47_14_5_;
	O10524[28] = + _I16OFF_50_13_5_;
	O10524[29] = + _I16OFF_53_13_5_;
	O10524[30] = + _I16OFF_59_21_7_;
	O10524[31] = + _I16OFF_59_23_7_;
	O10524[32] = + _I16OFF_65_25_7_;
	O10524[33] = + _I16OFF_68_26_7_;
	O10524[34] = + _I16OFF_35_9_5_;
	{long i; for (i = 35; i < 37; i++) O10524[i] = + _I16OFF_37_9_5_;}
	O10524[37] = + _I16OFF_43_9_5_;
	O10524[38] = + _I16OFF_37_10_5_;
	O10524[39] = + _I16OFF_35_9_5_;
	O10524[40] = + _I16OFF_36_9_5_;
	O10524[41] = + _I16OFF_37_9_5_;
	O10524[42] = + _I16OFF_36_9_5_;
	O10524[43] = + _I16OFF_40_12_5_;
	{long i; for (i = 44; i < 48; i++) O10524[i] = + _I16OFF_36_9_5_;}
	O10524[48] = + _I16OFF_37_9_5_;
	O10524[49] = + _I16OFF_41_9_5_;
	O10524[50] = + _I16OFF_37_10_5_;
	O10524[51] = + _I16OFF_39_10_5_;
	O10524[52] = + _I16OFF_42_13_7_;
	O10524[53] = + _I16OFF_44_13_7_;
	O10524[54] = + _I16OFF_51_13_7_;
	O10524[55] = + _I16OFF_58_14_7_;
	O10524[56] = + _I16OFF_45_16_7_;
	O10524[57] = + _I16OFF_44_13_7_;
	O10524[58] = + _I16OFF_43_13_7_;
	O10524[59] = + _I16OFF_46_14_7_;
	O10524[60] = + _I16OFF_44_15_7_;
	O10524[61] = + _I16OFF_51_18_7_;
	O10524[62] = + _I16OFF_50_13_7_;
	O10524[63] = + _I16OFF_59_16_7_;
	O10524[64] = + _I16OFF_51_14_7_;
	O10524[65] = + _I16OFF_53_14_7_;
	{long i; for (i = 66; i < 70; i++) O10524[i] = + _I16OFF_46_14_7_;}
	{long i; for (i = 70; i < 72; i++) O10524[i] = + _I16OFF_16_5_5_;}
	O10524[72] = + _I16OFF_18_5_5_;
	O10524[73] = + _I16OFF_23_5_5_;
	{long i; for (i = 74; i < 76; i++) O10524[i] = + _I16OFF_20_5_5_;}
	{long i; for (i = 76; i < 78; i++) O10524[i] = + _I16OFF_25_6_5_;}
	{long i; for (i = 78; i < 80; i++) O10524[i] = + _I16OFF_21_7_5_;}
	{long i; for (i = 80; i < 84; i++) O10524[i] = + _I16OFF_17_6_5_;}
	O10524[84] = + _I16OFF_18_6_5_;
	O10524[85] = + _I16OFF_23_8_5_;
	O10524[86] = + _I16OFF_23_9_5_;
	O10524[87] = + _I16OFF_24_9_5_;
	O10524[88] = + _I16OFF_23_9_5_;
	O10524[89] = + _I16OFF_26_8_5_;
	O10524[90] = + _I16OFF_19_5_5_;
	O10524[91] = + _I16OFF_22_5_5_;
	{long i; for (i = 92; i < 94; i++) O10524[i] = + _I16OFF_21_10_5_;}
	{long i; for (i = 94; i < 96; i++) O10524[i] = + _I16OFF_29_14_7_;}
	O10524[97] = + _I16OFF_36_10_5_;
	O10524[99] = + _I16OFF_36_9_5_;
	O10524[102] = + _I16OFF_48_19_7_;
	O10524[104] = + _I16OFF_48_18_7_;
}

long O10526[105];
void O10526_init () {
	O10526[0] = + _CHROFF_13_4_;
	O10526[1] = + _CHROFF_16_6_;
	O10526[2] = + _CHROFF_35_8_;
	O10526[3] = + _CHROFF_42_11_;
	O10526[4] = + _CHROFF_37_8_;
	O10526[5] = + _CHROFF_46_11_;
	O10526[6] = + _CHROFF_37_8_;
	O10526[7] = + _CHROFF_38_8_;
	O10526[8] = + _CHROFF_37_8_;
	O10526[9] = + _CHROFF_47_11_;
	O10526[10] = + _CHROFF_49_11_;
	O10526[11] = + _CHROFF_47_11_;
	{long i; for (i = 12; i < 15; i++) O10526[i] = + _CHROFF_39_9_;}
	{long i; for (i = 15; i < 18; i++) O10526[i] = + _CHROFF_49_12_;}
	{long i; for (i = 18; i < 22; i++) O10526[i] = + _CHROFF_39_9_;}
	O10526[22] = + _CHROFF_49_12_;
	O10526[23] = + _CHROFF_51_12_;
	{long i; for (i = 24; i < 26; i++) O10526[i] = + _CHROFF_49_13_;}
	O10526[26] = + _CHROFF_47_11_;
	O10526[27] = + _CHROFF_47_13_;
	O10526[28] = + _CHROFF_50_12_;
	O10526[29] = + _CHROFF_53_12_;
	O10526[30] = + _CHROFF_59_20_;
	O10526[31] = + _CHROFF_59_22_;
	O10526[32] = + _CHROFF_65_24_;
	O10526[33] = + _CHROFF_68_25_;
	O10526[34] = + _CHROFF_35_8_;
	{long i; for (i = 35; i < 37; i++) O10526[i] = + _CHROFF_37_8_;}
	O10526[37] = + _CHROFF_43_8_;
	O10526[38] = + _CHROFF_37_9_;
	O10526[39] = + _CHROFF_35_8_;
	O10526[40] = + _CHROFF_36_8_;
	O10526[41] = + _CHROFF_37_8_;
	O10526[42] = + _CHROFF_36_8_;
	O10526[43] = + _CHROFF_40_11_;
	{long i; for (i = 44; i < 48; i++) O10526[i] = + _CHROFF_36_8_;}
	O10526[48] = + _CHROFF_37_8_;
	O10526[49] = + _CHROFF_41_8_;
	O10526[50] = + _CHROFF_37_9_;
	O10526[51] = + _CHROFF_39_9_;
	O10526[52] = + _CHROFF_42_12_;
	O10526[53] = + _CHROFF_44_12_;
	O10526[54] = + _CHROFF_51_12_;
	O10526[55] = + _CHROFF_58_13_;
	O10526[56] = + _CHROFF_45_15_;
	O10526[57] = + _CHROFF_44_12_;
	O10526[58] = + _CHROFF_43_12_;
	O10526[59] = + _CHROFF_46_13_;
	O10526[60] = + _CHROFF_44_14_;
	O10526[61] = + _CHROFF_51_17_;
	O10526[62] = + _CHROFF_50_12_;
	O10526[63] = + _CHROFF_59_15_;
	O10526[64] = + _CHROFF_51_13_;
	O10526[65] = + _CHROFF_53_13_;
	{long i; for (i = 66; i < 70; i++) O10526[i] = + _CHROFF_46_13_;}
	{long i; for (i = 70; i < 72; i++) O10526[i] = + _CHROFF_16_4_;}
	O10526[72] = + _CHROFF_18_4_;
	O10526[73] = + _CHROFF_23_4_;
	{long i; for (i = 74; i < 76; i++) O10526[i] = + _CHROFF_20_4_;}
	{long i; for (i = 76; i < 78; i++) O10526[i] = + _CHROFF_25_5_;}
	{long i; for (i = 78; i < 80; i++) O10526[i] = + _CHROFF_21_6_;}
	{long i; for (i = 80; i < 84; i++) O10526[i] = + _CHROFF_17_5_;}
	O10526[84] = + _CHROFF_18_5_;
	O10526[85] = + _CHROFF_23_7_;
	O10526[86] = + _CHROFF_23_8_;
	O10526[87] = + _CHROFF_24_8_;
	O10526[88] = + _CHROFF_23_8_;
	O10526[89] = + _CHROFF_26_7_;
	O10526[90] = + _CHROFF_19_4_;
	O10526[91] = + _CHROFF_22_4_;
	{long i; for (i = 92; i < 94; i++) O10526[i] = + _CHROFF_21_9_;}
	{long i; for (i = 94; i < 96; i++) O10526[i] = + _CHROFF_29_13_;}
	O10526[97] = + _CHROFF_36_9_;
	O10526[99] = + _CHROFF_36_8_;
	O10526[102] = + _CHROFF_48_16_;
	O10526[104] = + _CHROFF_48_15_;
}

long O10570[103];
void O10570_init () {
	O10570[0] =  + _REFACS_32_;
	O10570[1] =  + _REFACS_38_;
	O10570[2] =  + _REFACS_33_;
	O10570[3] =  + _REFACS_39_;
	O10570[4] =  + _REFACS_33_;
	O10570[5] =  + _REFACS_34_;
	O10570[6] =  + _REFACS_33_;
	O10570[7] =  + _REFACS_40_;
	O10570[8] =  + _REFACS_42_;
	O10570[9] =  + _REFACS_40_;
	{long i; for (i = 10; i < 13; i++) O10570[i] =  + _REFACS_35_;}
	{long i; for (i = 13; i < 16; i++) O10570[i] =  + _REFACS_42_;}
	{long i; for (i = 16; i < 20; i++) O10570[i] =  + _REFACS_35_;}
	O10570[20] =  + _REFACS_41_;
	O10570[21] =  + _REFACS_42_;
	{long i; for (i = 22; i < 24; i++) O10570[i] =  + _REFACS_41_;}
	{long i; for (i = 24; i < 26; i++) O10570[i] =  + _REFACS_39_;}
	{long i; for (i = 26; i < 28; i++) O10570[i] =  + _REFACS_42_;}
	{long i; for (i = 28; i < 30; i++) O10570[i] =  + _REFACS_46_;}
	{long i; for (i = 30; i < 32; i++) O10570[i] =  + _REFACS_49_;}
	O10570[32] =  + _REFACS_32_;
	O10570[33] =  + _REFACS_33_;
	O10570[34] =  + _REFACS_34_;
	O10570[35] =  + _REFACS_36_;
	O10570[36] =  + _REFACS_34_;
	O10570[37] =  + _REFACS_32_;
	O10570[38] =  + _REFACS_33_;
	O10570[39] =  + _REFACS_34_;
	O10570[40] =  + _REFACS_33_;
	O10570[41] =  + _REFACS_36_;
	{long i; for (i = 42; i < 46; i++) O10570[i] =  + _REFACS_33_;}
	O10570[46] =  + _REFACS_34_;
	O10570[47] =  + _REFACS_38_;
	O10570[48] =  + _REFACS_34_;
	O10570[49] =  + _REFACS_36_;
	O10570[50] =  + _REFACS_38_;
	O10570[51] =  + _REFACS_39_;
	O10570[52] =  + _REFACS_41_;
	O10570[53] =  + _REFACS_43_;
	O10570[54] =  + _REFACS_41_;
	O10570[55] =  + _REFACS_40_;
	O10570[56] =  + _REFACS_39_;
	O10570[57] =  + _REFACS_41_;
	O10570[58] =  + _REFACS_40_;
	O10570[59] =  + _REFACS_43_;
	O10570[60] =  + _REFACS_41_;
	O10570[61] =  + _REFACS_46_;
	O10570[62] =  + _REFACS_41_;
	O10570[63] =  + _REFACS_43_;
	{long i; for (i = 64; i < 68; i++) O10570[i] =  + _REFACS_42_;}
	O10570[95] =  + _REFACS_33_;
	O10570[97] =  + _REFACS_33_;
	O10570[100] =  + _REFACS_39_;
	O10570[102] =  + _REFACS_39_;
}

long O10571[103];
void O10571_init () {
	O10571[0] =  + _REFACS_33_;
	O10571[1] =  + _REFACS_39_;
	O10571[2] =  + _REFACS_34_;
	O10571[3] =  + _REFACS_40_;
	O10571[4] =  + _REFACS_34_;
	O10571[5] =  + _REFACS_35_;
	O10571[6] =  + _REFACS_34_;
	O10571[7] =  + _REFACS_41_;
	O10571[8] =  + _REFACS_43_;
	O10571[9] =  + _REFACS_41_;
	{long i; for (i = 10; i < 13; i++) O10571[i] =  + _REFACS_36_;}
	{long i; for (i = 13; i < 16; i++) O10571[i] =  + _REFACS_43_;}
	{long i; for (i = 16; i < 20; i++) O10571[i] =  + _REFACS_36_;}
	O10571[20] =  + _REFACS_42_;
	O10571[21] =  + _REFACS_43_;
	{long i; for (i = 22; i < 24; i++) O10571[i] =  + _REFACS_42_;}
	{long i; for (i = 24; i < 26; i++) O10571[i] =  + _REFACS_40_;}
	{long i; for (i = 26; i < 28; i++) O10571[i] =  + _REFACS_43_;}
	{long i; for (i = 28; i < 30; i++) O10571[i] =  + _REFACS_47_;}
	{long i; for (i = 30; i < 32; i++) O10571[i] =  + _REFACS_50_;}
	O10571[32] =  + _REFACS_33_;
	O10571[33] =  + _REFACS_34_;
	O10571[34] =  + _REFACS_35_;
	O10571[35] =  + _REFACS_37_;
	O10571[36] =  + _REFACS_35_;
	O10571[37] =  + _REFACS_33_;
	O10571[38] =  + _REFACS_34_;
	O10571[39] =  + _REFACS_35_;
	O10571[40] =  + _REFACS_34_;
	O10571[41] =  + _REFACS_37_;
	{long i; for (i = 42; i < 46; i++) O10571[i] =  + _REFACS_34_;}
	O10571[46] =  + _REFACS_35_;
	O10571[47] =  + _REFACS_39_;
	O10571[48] =  + _REFACS_35_;
	O10571[49] =  + _REFACS_37_;
	O10571[50] =  + _REFACS_39_;
	O10571[51] =  + _REFACS_40_;
	O10571[52] =  + _REFACS_42_;
	O10571[53] =  + _REFACS_44_;
	O10571[54] =  + _REFACS_42_;
	O10571[55] =  + _REFACS_41_;
	O10571[56] =  + _REFACS_40_;
	O10571[57] =  + _REFACS_42_;
	O10571[58] =  + _REFACS_41_;
	O10571[59] =  + _REFACS_44_;
	O10571[60] =  + _REFACS_42_;
	O10571[61] =  + _REFACS_47_;
	O10571[62] =  + _REFACS_42_;
	O10571[63] =  + _REFACS_44_;
	{long i; for (i = 64; i < 68; i++) O10571[i] =  + _REFACS_43_;}
	O10571[95] =  + _REFACS_34_;
	O10571[97] =  + _REFACS_34_;
	O10571[100] =  + _REFACS_40_;
	O10571[102] =  + _REFACS_40_;
}

long O10572[103];
void O10572_init () {
	O10572[0] =  + _REFACS_34_;
	O10572[1] =  + _REFACS_40_;
	O10572[2] =  + _REFACS_35_;
	O10572[3] =  + _REFACS_41_;
	O10572[4] =  + _REFACS_35_;
	O10572[5] =  + _REFACS_36_;
	O10572[6] =  + _REFACS_35_;
	O10572[7] =  + _REFACS_42_;
	O10572[8] =  + _REFACS_44_;
	O10572[9] =  + _REFACS_42_;
	{long i; for (i = 10; i < 13; i++) O10572[i] =  + _REFACS_37_;}
	{long i; for (i = 13; i < 16; i++) O10572[i] =  + _REFACS_44_;}
	{long i; for (i = 16; i < 20; i++) O10572[i] =  + _REFACS_37_;}
	O10572[20] =  + _REFACS_43_;
	O10572[21] =  + _REFACS_44_;
	{long i; for (i = 22; i < 24; i++) O10572[i] =  + _REFACS_43_;}
	{long i; for (i = 24; i < 26; i++) O10572[i] =  + _REFACS_41_;}
	{long i; for (i = 26; i < 28; i++) O10572[i] =  + _REFACS_44_;}
	{long i; for (i = 28; i < 30; i++) O10572[i] =  + _REFACS_48_;}
	{long i; for (i = 30; i < 32; i++) O10572[i] =  + _REFACS_51_;}
	O10572[32] =  + _REFACS_34_;
	O10572[33] =  + _REFACS_35_;
	O10572[34] =  + _REFACS_36_;
	O10572[35] =  + _REFACS_38_;
	O10572[36] =  + _REFACS_36_;
	O10572[37] =  + _REFACS_34_;
	O10572[38] =  + _REFACS_35_;
	O10572[39] =  + _REFACS_36_;
	O10572[40] =  + _REFACS_35_;
	O10572[41] =  + _REFACS_38_;
	{long i; for (i = 42; i < 46; i++) O10572[i] =  + _REFACS_35_;}
	O10572[46] =  + _REFACS_36_;
	O10572[47] =  + _REFACS_40_;
	O10572[48] =  + _REFACS_36_;
	O10572[49] =  + _REFACS_38_;
	O10572[50] =  + _REFACS_40_;
	O10572[51] =  + _REFACS_41_;
	O10572[52] =  + _REFACS_43_;
	O10572[53] =  + _REFACS_45_;
	O10572[54] =  + _REFACS_43_;
	O10572[55] =  + _REFACS_42_;
	O10572[56] =  + _REFACS_41_;
	O10572[57] =  + _REFACS_43_;
	O10572[58] =  + _REFACS_42_;
	O10572[59] =  + _REFACS_45_;
	O10572[60] =  + _REFACS_43_;
	O10572[61] =  + _REFACS_48_;
	O10572[62] =  + _REFACS_43_;
	O10572[63] =  + _REFACS_45_;
	{long i; for (i = 64; i < 68; i++) O10572[i] =  + _REFACS_44_;}
	O10572[95] =  + _REFACS_35_;
	O10572[97] =  + _REFACS_35_;
	O10572[100] =  + _REFACS_41_;
	O10572[102] =  + _REFACS_41_;
}

long O10602[102];
void O10602_init () {
	O10602[0] = + _LNGOFF_42_12_10_2_;
	O10602[2] = + _LNGOFF_46_12_10_2_;
	O10602[6] = + _LNGOFF_47_12_10_3_;
	O10602[7] = + _LNGOFF_49_12_10_5_;
	O10602[8] = + _LNGOFF_47_12_10_3_;
	{long i; for (i = 12; i < 15; i++) O10602[i] = + _LNGOFF_49_13_10_3_;}
	O10602[19] = + _LNGOFF_49_13_10_2_;
	O10602[20] = + _LNGOFF_51_13_10_2_;
	{long i; for (i = 21; i < 23; i++) O10602[i] = + _LNGOFF_49_14_10_2_;}
	O10602[27] = + _LNGOFF_59_21_10_2_;
	O10602[28] = + _LNGOFF_59_23_10_2_;
	O10602[29] = + _LNGOFF_65_25_10_2_;
	O10602[30] = + _LNGOFF_68_26_10_2_;
	O10602[49] = + _LNGOFF_42_13_10_2_;
	O10602[50] = + _LNGOFF_44_13_10_2_;
	O10602[51] = + _LNGOFF_51_13_10_5_;
	O10602[52] = + _LNGOFF_58_14_10_5_;
	O10602[53] = + _LNGOFF_45_16_10_3_;
	O10602[54] = + _LNGOFF_44_13_10_2_;
	O10602[55] = + _LNGOFF_43_13_10_2_;
	O10602[56] = + _LNGOFF_46_14_10_2_;
	O10602[57] = + _LNGOFF_44_15_10_2_;
	O10602[58] = + _LNGOFF_51_18_10_2_;
	O10602[59] = + _LNGOFF_50_13_10_5_;
	O10602[60] = + _LNGOFF_59_16_10_5_;
	O10602[61] = + _LNGOFF_51_14_10_5_;
	O10602[62] = + _LNGOFF_53_14_10_5_;
	{long i; for (i = 63; i < 67; i++) O10602[i] = + _LNGOFF_46_14_10_2_;}
	O10602[99] = + _LNGOFF_48_19_10_2_;
	O10602[101] = + _LNGOFF_48_18_10_2_;
}

long O10603[102];
void O10603_init () {
	O10603[0] = + _LNGOFF_42_12_10_3_;
	O10603[2] = + _LNGOFF_46_12_10_3_;
	O10603[6] = + _LNGOFF_47_12_10_4_;
	O10603[7] = + _LNGOFF_49_12_10_6_;
	O10603[8] = + _LNGOFF_47_12_10_4_;
	{long i; for (i = 12; i < 15; i++) O10603[i] = + _LNGOFF_49_13_10_4_;}
	O10603[19] = + _LNGOFF_49_13_10_3_;
	O10603[20] = + _LNGOFF_51_13_10_3_;
	{long i; for (i = 21; i < 23; i++) O10603[i] = + _LNGOFF_49_14_10_3_;}
	O10603[27] = + _LNGOFF_59_21_10_3_;
	O10603[28] = + _LNGOFF_59_23_10_3_;
	O10603[29] = + _LNGOFF_65_25_10_3_;
	O10603[30] = + _LNGOFF_68_26_10_3_;
	O10603[49] = + _LNGOFF_42_13_10_3_;
	O10603[50] = + _LNGOFF_44_13_10_3_;
	O10603[51] = + _LNGOFF_51_13_10_6_;
	O10603[52] = + _LNGOFF_58_14_10_6_;
	O10603[53] = + _LNGOFF_45_16_10_4_;
	O10603[54] = + _LNGOFF_44_13_10_3_;
	O10603[55] = + _LNGOFF_43_13_10_3_;
	O10603[56] = + _LNGOFF_46_14_10_3_;
	O10603[57] = + _LNGOFF_44_15_10_3_;
	O10603[58] = + _LNGOFF_51_18_10_3_;
	O10603[59] = + _LNGOFF_50_13_10_6_;
	O10603[60] = + _LNGOFF_59_16_10_6_;
	O10603[61] = + _LNGOFF_51_14_10_6_;
	O10603[62] = + _LNGOFF_53_14_10_6_;
	{long i; for (i = 63; i < 67; i++) O10603[i] = + _LNGOFF_46_14_10_3_;}
	O10603[99] = + _LNGOFF_48_19_10_3_;
	O10603[101] = + _LNGOFF_48_18_10_3_;
}

long O10604[102];
void O10604_init () {
	O10604[0] = + _LNGOFF_42_12_10_4_;
	O10604[2] = + _LNGOFF_46_12_10_4_;
	O10604[6] = + _LNGOFF_47_12_10_5_;
	O10604[7] = + _LNGOFF_49_12_10_7_;
	O10604[8] = + _LNGOFF_47_12_10_5_;
	{long i; for (i = 12; i < 15; i++) O10604[i] = + _LNGOFF_49_13_10_5_;}
	O10604[19] = + _LNGOFF_49_13_10_4_;
	O10604[20] = + _LNGOFF_51_13_10_4_;
	{long i; for (i = 21; i < 23; i++) O10604[i] = + _LNGOFF_49_14_10_4_;}
	O10604[27] = + _LNGOFF_59_21_10_4_;
	O10604[28] = + _LNGOFF_59_23_10_4_;
	O10604[29] = + _LNGOFF_65_25_10_4_;
	O10604[30] = + _LNGOFF_68_26_10_4_;
	O10604[49] = + _LNGOFF_42_13_10_4_;
	O10604[50] = + _LNGOFF_44_13_10_4_;
	O10604[51] = + _LNGOFF_51_13_10_7_;
	O10604[52] = + _LNGOFF_58_14_10_7_;
	O10604[53] = + _LNGOFF_45_16_10_5_;
	O10604[54] = + _LNGOFF_44_13_10_4_;
	O10604[55] = + _LNGOFF_43_13_10_4_;
	O10604[56] = + _LNGOFF_46_14_10_4_;
	O10604[57] = + _LNGOFF_44_15_10_4_;
	O10604[58] = + _LNGOFF_51_18_10_4_;
	O10604[59] = + _LNGOFF_50_13_10_7_;
	O10604[60] = + _LNGOFF_59_16_10_7_;
	O10604[61] = + _LNGOFF_51_14_10_7_;
	O10604[62] = + _LNGOFF_53_14_10_7_;
	{long i; for (i = 63; i < 67; i++) O10604[i] = + _LNGOFF_46_14_10_4_;}
	O10604[99] = + _LNGOFF_48_19_10_4_;
	O10604[101] = + _LNGOFF_48_18_10_4_;
}

long O10605[102];
void O10605_init () {
	O10605[0] = + _LNGOFF_42_12_10_5_;
	O10605[2] = + _LNGOFF_46_12_10_5_;
	O10605[6] = + _LNGOFF_47_12_10_6_;
	O10605[7] = + _LNGOFF_49_12_10_8_;
	O10605[8] = + _LNGOFF_47_12_10_6_;
	{long i; for (i = 12; i < 15; i++) O10605[i] = + _LNGOFF_49_13_10_6_;}
	O10605[19] = + _LNGOFF_49_13_10_5_;
	O10605[20] = + _LNGOFF_51_13_10_5_;
	{long i; for (i = 21; i < 23; i++) O10605[i] = + _LNGOFF_49_14_10_5_;}
	O10605[27] = + _LNGOFF_59_21_10_5_;
	O10605[28] = + _LNGOFF_59_23_10_5_;
	O10605[29] = + _LNGOFF_65_25_10_5_;
	O10605[30] = + _LNGOFF_68_26_10_5_;
	O10605[49] = + _LNGOFF_42_13_10_5_;
	O10605[50] = + _LNGOFF_44_13_10_5_;
	O10605[51] = + _LNGOFF_51_13_10_8_;
	O10605[52] = + _LNGOFF_58_14_10_8_;
	O10605[53] = + _LNGOFF_45_16_10_6_;
	O10605[54] = + _LNGOFF_44_13_10_5_;
	O10605[55] = + _LNGOFF_43_13_10_5_;
	O10605[56] = + _LNGOFF_46_14_10_5_;
	O10605[57] = + _LNGOFF_44_15_10_5_;
	O10605[58] = + _LNGOFF_51_18_10_5_;
	O10605[59] = + _LNGOFF_50_13_10_8_;
	O10605[60] = + _LNGOFF_59_16_10_8_;
	O10605[61] = + _LNGOFF_51_14_10_8_;
	O10605[62] = + _LNGOFF_53_14_10_8_;
	{long i; for (i = 63; i < 67; i++) O10605[i] = + _LNGOFF_46_14_10_5_;}
	O10605[99] = + _LNGOFF_48_19_10_5_;
	O10605[101] = + _LNGOFF_48_18_10_5_;
}

long O10610[102];
void O10610_init () {
	O10610[0] =  + _REFACS_41_;
	O10610[2] =  + _REFACS_42_;
	O10610[6] =  + _REFACS_43_;
	O10610[7] =  + _REFACS_45_;
	O10610[8] =  + _REFACS_43_;
	{long i; for (i = 12; i < 15; i++) O10610[i] =  + _REFACS_45_;}
	O10610[19] =  + _REFACS_44_;
	O10610[20] =  + _REFACS_45_;
	{long i; for (i = 21; i < 23; i++) O10610[i] =  + _REFACS_44_;}
	{long i; for (i = 27; i < 29; i++) O10610[i] =  + _REFACS_49_;}
	{long i; for (i = 29; i < 31; i++) O10610[i] =  + _REFACS_52_;}
	O10610[49] =  + _REFACS_41_;
	O10610[50] =  + _REFACS_42_;
	O10610[51] =  + _REFACS_44_;
	O10610[52] =  + _REFACS_46_;
	O10610[53] =  + _REFACS_44_;
	O10610[54] =  + _REFACS_43_;
	O10610[55] =  + _REFACS_42_;
	O10610[56] =  + _REFACS_44_;
	O10610[57] =  + _REFACS_43_;
	O10610[58] =  + _REFACS_46_;
	O10610[59] =  + _REFACS_44_;
	O10610[60] =  + _REFACS_49_;
	O10610[61] =  + _REFACS_44_;
	O10610[62] =  + _REFACS_46_;
	{long i; for (i = 63; i < 67; i++) O10610[i] =  + _REFACS_45_;}
	O10610[99] =  + _REFACS_42_;
	O10610[101] =  + _REFACS_42_;
}

long O10619[102];
void O10619_init () {
	O10619[0] = + _I16OFF_42_12_8_;
	O10619[2] = + _I16OFF_46_12_8_;
	O10619[6] = + _I16OFF_47_12_8_;
	O10619[7] = + _I16OFF_49_12_8_;
	O10619[8] = + _I16OFF_47_12_8_;
	{long i; for (i = 12; i < 15; i++) O10619[i] = + _I16OFF_49_13_8_;}
	O10619[19] = + _I16OFF_49_13_8_;
	O10619[20] = + _I16OFF_51_13_8_;
	{long i; for (i = 21; i < 23; i++) O10619[i] = + _I16OFF_49_14_8_;}
	O10619[27] = + _I16OFF_59_21_8_;
	O10619[28] = + _I16OFF_59_23_8_;
	O10619[29] = + _I16OFF_65_25_8_;
	O10619[30] = + _I16OFF_68_26_8_;
	O10619[49] = + _I16OFF_42_13_8_;
	O10619[50] = + _I16OFF_44_13_8_;
	O10619[51] = + _I16OFF_51_13_8_;
	O10619[52] = + _I16OFF_58_14_8_;
	O10619[53] = + _I16OFF_45_16_8_;
	O10619[54] = + _I16OFF_44_13_8_;
	O10619[55] = + _I16OFF_43_13_8_;
	O10619[56] = + _I16OFF_46_14_8_;
	O10619[57] = + _I16OFF_44_15_8_;
	O10619[58] = + _I16OFF_51_18_8_;
	O10619[59] = + _I16OFF_50_13_8_;
	O10619[60] = + _I16OFF_59_16_8_;
	O10619[61] = + _I16OFF_51_14_8_;
	O10619[62] = + _I16OFF_53_14_8_;
	{long i; for (i = 63; i < 67; i++) O10619[i] = + _I16OFF_46_14_8_;}
	O10619[99] = + _I16OFF_48_19_8_;
	O10619[101] = + _I16OFF_48_18_8_;
}

long O10620[102];
void O10620_init () {
	O10620[0] = + _I16OFF_42_12_9_;
	O10620[2] = + _I16OFF_46_12_9_;
	O10620[6] = + _I16OFF_47_12_9_;
	O10620[7] = + _I16OFF_49_12_9_;
	O10620[8] = + _I16OFF_47_12_9_;
	{long i; for (i = 12; i < 15; i++) O10620[i] = + _I16OFF_49_13_9_;}
	O10620[19] = + _I16OFF_49_13_9_;
	O10620[20] = + _I16OFF_51_13_9_;
	{long i; for (i = 21; i < 23; i++) O10620[i] = + _I16OFF_49_14_9_;}
	O10620[27] = + _I16OFF_59_21_9_;
	O10620[28] = + _I16OFF_59_23_9_;
	O10620[29] = + _I16OFF_65_25_9_;
	O10620[30] = + _I16OFF_68_26_9_;
	O10620[49] = + _I16OFF_42_13_9_;
	O10620[50] = + _I16OFF_44_13_9_;
	O10620[51] = + _I16OFF_51_13_9_;
	O10620[52] = + _I16OFF_58_14_9_;
	O10620[53] = + _I16OFF_45_16_9_;
	O10620[54] = + _I16OFF_44_13_9_;
	O10620[55] = + _I16OFF_43_13_9_;
	O10620[56] = + _I16OFF_46_14_9_;
	O10620[57] = + _I16OFF_44_15_9_;
	O10620[58] = + _I16OFF_51_18_9_;
	O10620[59] = + _I16OFF_50_13_9_;
	O10620[60] = + _I16OFF_59_16_9_;
	O10620[61] = + _I16OFF_51_14_9_;
	O10620[62] = + _I16OFF_53_14_9_;
	{long i; for (i = 63; i < 67; i++) O10620[i] = + _I16OFF_46_14_9_;}
	O10620[99] = + _I16OFF_48_19_9_;
	O10620[101] = + _I16OFF_48_18_9_;
}

long O10648[29];
void O10648_init () {
	O10648[0] =  + _REFACS_44_;
	O10648[4] =  + _REFACS_45_;
	O10648[5] =  + _REFACS_47_;
	O10648[6] =  + _REFACS_45_;
	{long i; for (i = 10; i < 13; i++) O10648[i] =  + _REFACS_47_;}
	O10648[17] =  + _REFACS_46_;
	O10648[18] =  + _REFACS_47_;
	{long i; for (i = 19; i < 21; i++) O10648[i] =  + _REFACS_46_;}
	{long i; for (i = 25; i < 27; i++) O10648[i] =  + _REFACS_51_;}
	{long i; for (i = 27; i < 29; i++) O10648[i] =  + _REFACS_54_;}
}

long O10662[29];
void O10662_init () {
	O10662[0] =  + _REFACS_45_;
	O10662[4] =  + _REFACS_46_;
	O10662[5] =  + _REFACS_48_;
	O10662[6] =  + _REFACS_46_;
	{long i; for (i = 10; i < 13; i++) O10662[i] =  + _REFACS_48_;}
	O10662[17] =  + _REFACS_47_;
	O10662[18] =  + _REFACS_48_;
	{long i; for (i = 19; i < 21; i++) O10662[i] =  + _REFACS_47_;}
	{long i; for (i = 25; i < 27; i++) O10662[i] =  + _REFACS_52_;}
	{long i; for (i = 27; i < 29; i++) O10662[i] =  + _REFACS_55_;}
}

long O10733[12];
void O10733_init () {
	O10733[0] =  + _REFACS_48_;
	O10733[1] =  + _REFACS_49_;
	{long i; for (i = 2; i < 4; i++) O10733[i] =  + _REFACS_48_;}
	{long i; for (i = 8; i < 10; i++) O10733[i] =  + _REFACS_53_;}
	{long i; for (i = 10; i < 12; i++) O10733[i] =  + _REFACS_56_;}
}

long O10756[8];
void O10756_init () {
	{long i; for (i = 0; i < 2; i++) O10756[i] =  + _REFACS_43_;}
	{long i; for (i = 2; i < 4; i++) O10756[i] =  + _REFACS_46_;}
	{long i; for (i = 4; i < 6; i++) O10756[i] =  + _REFACS_54_;}
	{long i; for (i = 6; i < 8; i++) O10756[i] =  + _REFACS_57_;}
}

long O10757[8];
void O10757_init () {
	{long i; for (i = 0; i < 2; i++) O10757[i] =  + _REFACS_44_;}
	{long i; for (i = 2; i < 4; i++) O10757[i] =  + _REFACS_47_;}
	{long i; for (i = 4; i < 6; i++) O10757[i] =  + _REFACS_55_;}
	{long i; for (i = 6; i < 8; i++) O10757[i] =  + _REFACS_58_;}
}

long O10763[8];
void O10763_init () {
	{long i; for (i = 0; i < 2; i++) O10763[i] = + _CHROFF_47_8_;}
	O10763[2] = + _CHROFF_50_8_;
	O10763[3] = + _CHROFF_53_8_;
	{long i; for (i = 4; i < 6; i++) O10763[i] = + _CHROFF_59_13_;}
	O10763[6] = + _CHROFF_65_13_;
	O10763[7] = + _CHROFF_68_13_;
}

long O10784[8];
void O10784_init () {
	{long i; for (i = 0; i < 2; i++) O10784[i] =  + _REFACS_45_;}
	{long i; for (i = 2; i < 4; i++) O10784[i] =  + _REFACS_48_;}
	{long i; for (i = 4; i < 6; i++) O10784[i] =  + _REFACS_56_;}
	{long i; for (i = 6; i < 8; i++) O10784[i] =  + _REFACS_59_;}
}

long O10787[8];
void O10787_init () {
	{long i; for (i = 0; i < 2; i++) O10787[i] = + _CHROFF_47_9_;}
	O10787[2] = + _CHROFF_50_9_;
	O10787[3] = + _CHROFF_53_9_;
	{long i; for (i = 4; i < 6; i++) O10787[i] = + _CHROFF_59_14_;}
	O10787[6] = + _CHROFF_65_14_;
	O10787[7] = + _CHROFF_68_14_;
}

long O10788[8];
void O10788_init () {
	{long i; for (i = 0; i < 2; i++) O10788[i] =  + _REFACS_46_;}
	{long i; for (i = 2; i < 4; i++) O10788[i] =  + _REFACS_49_;}
	{long i; for (i = 4; i < 6; i++) O10788[i] =  + _REFACS_57_;}
	{long i; for (i = 6; i < 8; i++) O10788[i] =  + _REFACS_60_;}
}

long O10828[4];
void O10828_init () {
	O10828[0] = + _CHROFF_59_15_;
	O10828[1] = + _CHROFF_59_17_;
	O10828[2] = + _CHROFF_65_16_;
	O10828[3] = + _CHROFF_68_16_;
}

long O10829[4];
void O10829_init () {
	O10829[0] = + _CHROFF_59_16_;
	O10829[1] = + _CHROFF_59_18_;
	O10829[2] = + _CHROFF_65_17_;
	O10829[3] = + _CHROFF_68_17_;
}

long O10830[4];
void O10830_init () {
	O10830[0] = + _CHROFF_59_17_;
	O10830[1] = + _CHROFF_59_19_;
	O10830[2] = + _CHROFF_65_18_;
	O10830[3] = + _CHROFF_68_18_;
}

long O10832[4];
void O10832_init () {
	O10832[0] = + _CHROFF_59_18_;
	O10832[1] = + _CHROFF_59_20_;
	O10832[2] = + _CHROFF_65_19_;
	O10832[3] = + _CHROFF_68_19_;
}

long O10834[4];
void O10834_init () {
	O10834[0] = + _PTROFF_59_21_10_11_0_1_;
	O10834[1] = + _PTROFF_59_23_10_11_0_1_;
	O10834[2] = + _PTROFF_65_25_10_11_0_1_;
	O10834[3] = + _PTROFF_68_26_10_11_0_1_;
}

long O10836[4];
void O10836_init () {
	O10836[0] = + _LNGOFF_59_21_10_6_;
	O10836[1] = + _LNGOFF_59_23_10_6_;
	O10836[2] = + _LNGOFF_65_25_10_6_;
	O10836[3] = + _LNGOFF_68_26_10_6_;
}

long O10837[4];
void O10837_init () {
	O10837[0] = + _LNGOFF_59_21_10_7_;
	O10837[1] = + _LNGOFF_59_23_10_7_;
	O10837[2] = + _LNGOFF_65_25_10_7_;
	O10837[3] = + _LNGOFF_68_26_10_7_;
}

long O10842[4];
void O10842_init () {
	O10842[0] = + _LNGOFF_59_21_10_8_;
	O10842[1] = + _LNGOFF_59_23_10_8_;
	O10842[2] = + _LNGOFF_65_25_10_8_;
	O10842[3] = + _LNGOFF_68_26_10_8_;
}

long O10857[4];
void O10857_init () {
	O10857[0] = + _PTROFF_59_21_10_11_0_2_;
	O10857[1] = + _PTROFF_59_23_10_11_0_2_;
	O10857[2] = + _PTROFF_65_25_10_11_0_2_;
	O10857[3] = + _PTROFF_68_26_10_11_0_2_;
}

long O10858[4];
void O10858_init () {
	O10858[0] = + _PTROFF_59_21_10_11_0_3_;
	O10858[1] = + _PTROFF_59_23_10_11_0_3_;
	O10858[2] = + _PTROFF_65_25_10_11_0_3_;
	O10858[3] = + _PTROFF_68_26_10_11_0_3_;
}

long O10860[4];
void O10860_init () {
	O10860[0] = + _LNGOFF_59_21_10_9_;
	O10860[1] = + _LNGOFF_59_23_10_9_;
	O10860[2] = + _LNGOFF_65_25_10_9_;
	O10860[3] = + _LNGOFF_68_26_10_9_;
}

long O10861[4];
void O10861_init () {
	O10861[0] = + _LNGOFF_59_21_10_10_;
	O10861[1] = + _LNGOFF_59_23_10_10_;
	O10861[2] = + _LNGOFF_65_25_10_10_;
	O10861[3] = + _LNGOFF_68_26_10_10_;
}

long O10867[2];
void O10867_init () {
	O10867[0] = + _CHROFF_65_20_;
	O10867[1] = + _CHROFF_68_20_;
}

long O10868[2];
void O10868_init () {
	O10868[0] =  + _REFACS_62_;
	O10868[1] =  + _REFACS_65_;
}

long O10871[2];
void O10871_init () {
	O10871[0] = + _CHROFF_65_21_;
	O10871[1] = + _CHROFF_68_21_;
}

long O10872[2];
void O10872_init () {
	O10872[0] = + _CHROFF_65_22_;
	O10872[1] = + _CHROFF_68_22_;
}

long O11049[53];
void O11049_init () {
	O11049[0] = + _CHROFF_42_10_;
	O11049[1] = + _CHROFF_44_10_;
	O11049[2] = + _CHROFF_51_10_;
	O11049[3] = + _CHROFF_58_10_;
	O11049[4] = + _CHROFF_45_11_;
	O11049[5] = + _CHROFF_44_10_;
	O11049[6] = + _CHROFF_43_10_;
	O11049[7] = + _CHROFF_46_10_;
	O11049[8] = + _CHROFF_44_10_;
	O11049[9] = + _CHROFF_51_13_;
	O11049[10] = + _CHROFF_50_10_;
	O11049[11] = + _CHROFF_59_10_;
	O11049[12] = + _CHROFF_51_11_;
	O11049[13] = + _CHROFF_53_11_;
	{long i; for (i = 14; i < 18; i++) O11049[i] = + _CHROFF_46_10_;}
	O11049[50] = + _CHROFF_48_10_;
	O11049[52] = + _CHROFF_48_10_;
}

long O11171[4];
void O11171_init () {
	O11171[0] =  + _REFACS_45_;
	O11171[1] =  + _REFACS_51_;
	O11171[2] =  + _REFACS_45_;
	O11171[3] =  + _REFACS_47_;
}

long O11172[4];
void O11172_init () {
	O11172[0] =  + _REFACS_46_;
	O11172[1] =  + _REFACS_52_;
	O11172[2] =  + _REFACS_46_;
	O11172[3] =  + _REFACS_48_;
}

long O11173[4];
void O11173_init () {
	O11173[0] =  + _REFACS_47_;
	O11173[1] =  + _REFACS_53_;
	O11173[2] =  + _REFACS_47_;
	O11173[3] =  + _REFACS_49_;
}

long O11174[4];
void O11174_init () {
	O11174[0] =  + _REFACS_48_;
	O11174[1] =  + _REFACS_54_;
	O11174[2] =  + _REFACS_48_;
	O11174[3] =  + _REFACS_50_;
}

long O11175[4];
void O11175_init () {
	O11175[0] =  + _REFACS_49_;
	O11175[1] =  + _REFACS_55_;
	O11175[2] =  + _REFACS_49_;
	O11175[3] =  + _REFACS_51_;
}

long O11180[4];
void O11180_init () {
	O11180[0] = + _PTROFF_50_13_10_9_0_1_;
	O11180[1] = + _PTROFF_59_16_10_12_0_2_;
	O11180[2] = + _PTROFF_51_14_10_9_0_1_;
	O11180[3] = + _PTROFF_53_14_10_9_0_1_;
}

long O11192[2];
void O11192_init () {
	O11192[0] = + _PTROFF_51_14_10_9_0_2_;
	O11192[1] = + _PTROFF_53_14_10_9_0_2_;
}

long O11194[2];
void O11194_init () {
	O11194[0] =  + _REFACS_50_;
	O11194[1] =  + _REFACS_52_;
}

long O11195[2];
void O11195_init () {
	O11195[0] = + _PTROFF_51_14_10_9_0_3_;
	O11195[1] = + _PTROFF_53_14_10_9_0_3_;
}

long O11238[18];
void O11238_init () {
	{long i; for (i = 0; i < 2; i++) O11238[i] =  + _REFACS_20_;}
	{long i; for (i = 7; i < 11; i++) O11238[i] =  + _REFACS_22_;}
	O11238[11] =  + _REFACS_25_;
	{long i; for (i = 16; i < 18; i++) O11238[i] =  + _REFACS_26_;}
}

long O11244[5];
void O11244_init () {
	O11244[0] = + _PTROFF_23_8_6_1_0_3_;
	O11244[1] = + _PTROFF_23_9_6_1_0_3_;
	O11244[2] = + _PTROFF_24_9_6_1_0_3_;
	O11244[3] = + _PTROFF_23_9_6_1_0_3_;
	O11244[4] = + _PTROFF_26_8_6_2_0_3_;
}

long O11306[10];
void O11306_init () {
	O11306[0] = + _LNGOFF_1_1_0_0_;
	O11306[1] = + _LNGOFF_36_10_6_1_;
	O11306[2] = + _LNGOFF_1_1_0_0_;
	O11306[3] = + _LNGOFF_36_9_6_1_;
	O11306[4] = + _LNGOFF_1_1_0_0_;
	O11306[5] = + _LNGOFF_6_5_0_0_;
	O11306[6] = + _LNGOFF_48_19_10_6_;
	O11306[7] = + _LNGOFF_6_5_0_0_;
	O11306[8] = + _LNGOFF_48_18_10_6_;
	O11306[9] = + _LNGOFF_6_7_0_0_;
}

long O11382[5];
void O11382_init () {
	O11382[0] = + _PTROFF_6_5_0_3_0_0_;
	O11382[1] = + _PTROFF_48_19_10_9_0_1_;
	O11382[2] = + _PTROFF_6_5_0_3_0_0_;
	O11382[3] = + _PTROFF_48_18_10_9_0_1_;
	O11382[4] = + _PTROFF_6_7_0_5_0_0_;
}

long O11390[5];
void O11390_init () {
	O11390[0] = + _CHROFF_6_3_;
	O11390[1] = + _CHROFF_48_17_;
	O11390[2] = + _CHROFF_6_3_;
	O11390[3] = + _CHROFF_48_16_;
	O11390[4] = + _CHROFF_6_5_;
}

long O11391[5];
void O11391_init () {
	O11391[0] = + _CHROFF_6_4_;
	O11391[1] = + _CHROFF_48_18_;
	O11391[2] = + _CHROFF_6_4_;
	O11391[3] = + _CHROFF_48_17_;
	O11391[4] = + _CHROFF_6_6_;
}

long O11395[5];
void O11395_init () {
	O11395[0] = + _CHROFF_6_0_;
	O11395[1] = + _CHROFF_48_12_;
	O11395[2] = + _CHROFF_6_0_;
	O11395[3] = + _CHROFF_48_11_;
	O11395[4] = + _CHROFF_6_0_;
}

long O11396[5];
void O11396_init () {
	O11396[0] = + _R64OFF_6_5_0_3_0_1_0_0_;
	O11396[1] = + _R64OFF_48_19_10_9_0_3_0_0_;
	O11396[2] = + _R64OFF_6_5_0_3_0_2_0_0_;
	O11396[3] = + _R64OFF_48_18_10_9_0_4_0_0_;
	O11396[4] = + _R64OFF_6_7_0_5_0_5_0_0_;
}

long O11415[5];
void O11415_init () {
	O11415[0] =  + _REFACS_2_;
	O11415[1] =  + _REFACS_44_;
	O11415[2] =  + _REFACS_2_;
	O11415[3] =  + _REFACS_44_;
	O11415[4] =  + _REFACS_2_;
}

long O11416[5];
void O11416_init () {
	O11416[0] =  + _REFACS_3_;
	O11416[1] =  + _REFACS_45_;
	O11416[2] =  + _REFACS_3_;
	O11416[3] =  + _REFACS_45_;
	O11416[4] =  + _REFACS_3_;
}

long O11420[5];
void O11420_init () {
	O11420[0] =  + _REFACS_4_;
	O11420[1] =  + _REFACS_46_;
	O11420[2] =  + _REFACS_4_;
	O11420[3] =  + _REFACS_46_;
	O11420[4] =  + _REFACS_4_;
}

long O11421[5];
void O11421_init () {
	O11421[0] = + _CHROFF_6_1_;
	O11421[1] = + _CHROFF_48_13_;
	O11421[2] = + _CHROFF_6_1_;
	O11421[3] = + _CHROFF_48_12_;
	O11421[4] = + _CHROFF_6_1_;
}

long O11422[5];
void O11422_init () {
	O11422[0] =  + _REFACS_5_;
	O11422[1] =  + _REFACS_47_;
	O11422[2] =  + _REFACS_5_;
	O11422[3] =  + _REFACS_47_;
	O11422[4] =  + _REFACS_5_;
}

long O11423[5];
void O11423_init () {
	O11423[0] = + _LNGOFF_6_5_0_1_;
	O11423[1] = + _LNGOFF_48_19_10_7_;
	O11423[2] = + _LNGOFF_6_5_0_1_;
	O11423[3] = + _LNGOFF_48_18_10_7_;
	O11423[4] = + _LNGOFF_6_7_0_1_;
}

long O11424[5];
void O11424_init () {
	O11424[0] = + _LNGOFF_6_5_0_2_;
	O11424[1] = + _LNGOFF_48_19_10_8_;
	O11424[2] = + _LNGOFF_6_5_0_2_;
	O11424[3] = + _LNGOFF_48_18_10_8_;
	O11424[4] = + _LNGOFF_6_7_0_2_;
}

static EIF_TYPE_INDEX Y12024_pgtype0[] = {0xFF01,24,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y12024_pgtype1[] = {0xFF01,26,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y12024_pgtype2[] = {0xFF01,24,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y12024_pgtype3[] = {0xFF01,26,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y12024_gen_type [4];
EIF_TYPE_INDEX Y12024 [4];
void Y12024_init (void)
{
	egc_routines_types [12024] = Y12024;
	egc_routines_gen_types [12024] = Y12024_gen_type;
	egc_routines_offset [12024] = 1550;
	Y12024_gen_type [0] = Y12024_pgtype0;
	Y12024_gen_type [1] = Y12024_pgtype1;
	Y12024_gen_type [2] = Y12024_pgtype2;
	Y12024_gen_type [3] = Y12024_pgtype3;
	Y12024[0] = 24;
	Y12024[1] = 26;
	Y12024[2] = 24;
	Y12024[3] = 26;
}


#ifdef __cplusplus
}
#endif
