#include "epoly11.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R6860[470])();
void R6860_init () {
	R6860[0] = (char *(*)()) F1000_7784;
	{long i; for (i = 2; i < 4; i++) R6860[i] = (char *(*)()) F1001_7927;}
	R6860[469] = (char *(*)()) F1001_7927;
}

char *(*R6862[470])();
void R6862_init () {
	R6862[0] = (char *(*)()) F1000_7783;
	{long i; for (i = 2; i < 4; i++) R6862[i] = (char *(*)()) F1001_7955;}
	R6862[469] = (char *(*)()) F1001_7955;
}

char *(*R6863[468])();
void R6863_init () {
	{long i; for (i = 0; i < 2; i++) R6863[i] = (char *(*)()) F1001_7982;}
	R6863[467] = (char *(*)()) F1469_14965;
}

char *(*R6865[468])();
void R6865_init () {
	{long i; for (i = 0; i < 2; i++) R6865[i] = (char *(*)()) F1001_7977;}
	R6865[467] = (char *(*)()) F1469_14957;
}

char *(*R6867[468])();
void R6867_init () {
	{long i; for (i = 0; i < 2; i++) R6867[i] = (char *(*)()) F1001_7980;}
	R6867[467] = (char *(*)()) F1469_14955;
}

char *(*R6895[468])();
void R6895_init () {
	{long i; for (i = 0; i < 2; i++) R6895[i] = (char *(*)()) F1001_8010;}
	R6895[467] = (char *(*)()) F1469_14952;
}

char *(*R6908[468])();
void R6908_init () {
	{long i; for (i = 0; i < 2; i++) R6908[i] = (char *(*)()) F1001_8017;}
	R6908[467] = (char *(*)()) F1469_14946;
}

char *(*R6911[468])();
void R6911_init () {
	{long i; for (i = 0; i < 2; i++) R6911[i] = (char *(*)()) F1001_8014;}
	R6911[467] = (char *(*)()) F1469_14943;
}

char *(*R6939[468])();
void R6939_init () {
	R6939[0] = (char *(*)()) F1001_7868;
	R6939[1] = (char *(*)()) F1003_8149;
	R6939[467] = (char *(*)()) F1003_8149;
}

char *(*R6964[468])();
void R6964_init () {
	{long i; for (i = 0; i < 2; i++) R6964[i] = (char *(*)()) F1001_7902;}
	R6964[467] = (char *(*)()) F1469_14933;
}

char *(*R7033[468])();
void R7033_init () {
	R7033[0] = (char *(*)()) F1002_8143;
	R7033[1] = (char *(*)()) F1001_8026;
	R7033[467] = (char *(*)()) F1001_8026;
}

char *(*R7034[468])();
void R7034_init () {
	{long i; for (i = 0; i < 2; i++) R7034[i] = (char *(*)()) F1001_8027;}
	R7034[467] = (char *(*)()) F1469_14989;
}

char *(*R7117[467])();
void R7117_init () {
	R7117[0] = (char *(*)()) F1003_8195;
	R7117[466] = (char *(*)()) F1469_14931;
}

char *(*R7340[162])();
void R7340_init () {
	R7340[0] = (char *(*)()) F1014_8445;
	R7340[1] = (char *(*)()) F1015_8482;
	R7340[2] = (char *(*)()) F1016_8524;
	R7340[3] = (char *(*)()) F1017_8524;
	R7340[4] = (char *(*)()) F1018_8524;
	R7340[5] = (char *(*)()) F1019_8524;
	R7340[6] = (char *(*)()) F1020_8524;
	R7340[7] = (char *(*)()) F1021_8524;
	R7340[8] = (char *(*)()) F1022_8524;
	R7340[9] = (char *(*)()) F1023_8524;
	R7340[10] = (char *(*)()) F1024_8524;
	R7340[11] = (char *(*)()) F1025_8524;
	R7340[12] = (char *(*)()) F1026_8524;
	R7340[13] = (char *(*)()) F1027_8524;
	R7340[14] = (char *(*)()) F1028_8524;
	R7340[15] = (char *(*)()) F1029_8524;
	R7340[16] = (char *(*)()) F1030_8524;
	R7340[17] = (char *(*)()) F1031_8524;
	R7340[18] = (char *(*)()) F1032_8524;
	R7340[19] = (char *(*)()) F1033_8524;
	R7340[20] = (char *(*)()) F1034_8524;
	R7340[21] = (char *(*)()) F1035_8524;
	R7340[22] = (char *(*)()) F1036_8524;
	R7340[23] = (char *(*)()) F1037_8524;
	R7340[24] = (char *(*)()) F1038_8524;
	R7340[25] = (char *(*)()) F1039_8524;
	R7340[26] = (char *(*)()) F1040_8524;
	R7340[27] = (char *(*)()) F1041_8524;
	R7340[28] = (char *(*)()) F1042_8524;
	R7340[29] = (char *(*)()) F1043_8524;
	R7340[30] = (char *(*)()) F1044_8524;
	R7340[31] = (char *(*)()) F1045_8524;
	R7340[32] = (char *(*)()) F1046_8524;
	R7340[33] = (char *(*)()) F1047_8524;
	R7340[34] = (char *(*)()) F1048_8524;
	R7340[35] = (char *(*)()) F1049_8524;
	R7340[36] = (char *(*)()) F1050_8576;
	{long i; for (i = 38; i < 40; i++) R7340[i] = (char *(*)()) F1051_8683;}
	{long i; for (i = 41; i < 43; i++) R7340[i] = (char *(*)()) F1054_8750;}
	{long i; for (i = 44; i < 46; i++) R7340[i] = (char *(*)()) F1057_8791;}
	{long i; for (i = 47; i < 49; i++) R7340[i] = (char *(*)()) F1060_8839;}
	{long i; for (i = 50; i < 52; i++) R7340[i] = (char *(*)()) F1063_8860;}
	{long i; for (i = 53; i < 55; i++) R7340[i] = (char *(*)()) F1066_8958;}
	{long i; for (i = 56; i < 58; i++) R7340[i] = (char *(*)()) F1069_9057;}
	{long i; for (i = 59; i < 61; i++) R7340[i] = (char *(*)()) F1072_9156;}
	{long i; for (i = 62; i < 64; i++) R7340[i] = (char *(*)()) F1075_9255;}
	{long i; for (i = 65; i < 67; i++) R7340[i] = (char *(*)()) F1078_9349;}
	{long i; for (i = 68; i < 70; i++) R7340[i] = (char *(*)()) F1081_9443;}
	{long i; for (i = 71; i < 73; i++) R7340[i] = (char *(*)()) F1084_9538;}
	{long i; for (i = 74; i < 76; i++) R7340[i] = (char *(*)()) F1087_9633;}
	{long i; for (i = 76; i < 107; i++) R7340[i] = (char *(*)()) F1090_9699;}
	R7340[107] = (char *(*)()) F1121_9725;
	R7340[108] = (char *(*)()) F1122_9725;
	{long i; for (i = 110; i < 115; i++) R7340[i] = (char *(*)()) F1123_9733;}
	{long i; for (i = 119; i < 121; i++) R7340[i] = (char *(*)()) F1129_9792;}
	{long i; for (i = 122; i < 124; i++) R7340[i] = (char *(*)()) F1129_9792;}
	R7340[161] = (char *(*)()) F1175_10513;
}

char *(*R7424[34])();
void R7424_init () {
	R7424[0] = (char *(*)()) F1016_8520;
	R7424[1] = (char *(*)()) F1017_8520;
	R7424[2] = (char *(*)()) F1018_8520;
	R7424[3] = (char *(*)()) F1019_8520;
	R7424[4] = (char *(*)()) F1020_8520;
	R7424[5] = (char *(*)()) F1021_8520;
	R7424[6] = (char *(*)()) F1022_8520;
	R7424[7] = (char *(*)()) F1023_8520;
	R7424[8] = (char *(*)()) F1024_8520;
	R7424[9] = (char *(*)()) F1025_8520;
	R7424[10] = (char *(*)()) F1026_8520;
	R7424[11] = (char *(*)()) F1027_8520;
	R7424[12] = (char *(*)()) F1028_8520;
	R7424[13] = (char *(*)()) F1029_8520;
	R7424[14] = (char *(*)()) F1030_8520;
	R7424[15] = (char *(*)()) F1031_8520;
	R7424[16] = (char *(*)()) F1032_8520;
	R7424[17] = (char *(*)()) F1033_8520;
	R7424[18] = (char *(*)()) F1034_8520;
	R7424[19] = (char *(*)()) F1035_8520;
	R7424[20] = (char *(*)()) F1036_8520;
	R7424[21] = (char *(*)()) F1037_8520;
	R7424[22] = (char *(*)()) F1038_8520;
	R7424[23] = (char *(*)()) F1039_8520;
	R7424[24] = (char *(*)()) F1040_8520;
	R7424[25] = (char *(*)()) F1041_8520;
	R7424[26] = (char *(*)()) F1042_8520;
	R7424[27] = (char *(*)()) F1043_8520;
	R7424[28] = (char *(*)()) F1044_8520;
	R7424[29] = (char *(*)()) F1045_8520;
	R7424[30] = (char *(*)()) F1046_8520;
	R7424[31] = (char *(*)()) F1047_8520;
	R7424[32] = (char *(*)()) F1048_8520;
	R7424[33] = (char *(*)()) F1049_8520;
}

char *(*R7425[34])();
void R7425_init () {
	R7425[0] = (char *(*)()) F1016_8521;
	R7425[1] = (char *(*)()) F1017_8521;
	R7425[2] = (char *(*)()) F1018_8521;
	R7425[3] = (char *(*)()) F1019_8521;
	R7425[4] = (char *(*)()) F1020_8521;
	R7425[5] = (char *(*)()) F1021_8521;
	R7425[6] = (char *(*)()) F1022_8521;
	R7425[7] = (char *(*)()) F1023_8521;
	R7425[8] = (char *(*)()) F1024_8521;
	R7425[9] = (char *(*)()) F1025_8521;
	R7425[10] = (char *(*)()) F1026_8521;
	R7425[11] = (char *(*)()) F1027_8521;
	R7425[12] = (char *(*)()) F1028_8521;
	R7425[13] = (char *(*)()) F1029_8521;
	R7425[14] = (char *(*)()) F1030_8521;
	R7425[15] = (char *(*)()) F1031_8521;
	R7425[16] = (char *(*)()) F1032_8521;
	R7425[17] = (char *(*)()) F1033_8521;
	R7425[18] = (char *(*)()) F1034_8521;
	R7425[19] = (char *(*)()) F1035_8521;
	R7425[20] = (char *(*)()) F1036_8521;
	R7425[21] = (char *(*)()) F1037_8521;
	R7425[22] = (char *(*)()) F1038_8521;
	R7425[23] = (char *(*)()) F1039_8521;
	R7425[24] = (char *(*)()) F1040_8521;
	R7425[25] = (char *(*)()) F1041_8521;
	R7425[26] = (char *(*)()) F1042_8521;
	R7425[27] = (char *(*)()) F1043_8521;
	R7425[28] = (char *(*)()) F1044_8521;
	R7425[29] = (char *(*)()) F1045_8521;
	R7425[30] = (char *(*)()) F1046_8521;
	R7425[31] = (char *(*)()) F1047_8521;
	R7425[32] = (char *(*)()) F1048_8521;
	R7425[33] = (char *(*)()) F1049_8521;
}

char *(*R7426[34])();
void R7426_init () {
	R7426[0] = (char *(*)()) F1016_8522;
	R7426[1] = (char *(*)()) F1017_8522;
	R7426[2] = (char *(*)()) F1018_8522;
	R7426[3] = (char *(*)()) F1019_8522;
	R7426[4] = (char *(*)()) F1020_8522;
	R7426[5] = (char *(*)()) F1021_8522;
	R7426[6] = (char *(*)()) F1022_8522;
	R7426[7] = (char *(*)()) F1023_8522;
	R7426[8] = (char *(*)()) F1024_8522;
	R7426[9] = (char *(*)()) F1025_8522;
	R7426[10] = (char *(*)()) F1026_8522;
	R7426[11] = (char *(*)()) F1027_8522;
	R7426[12] = (char *(*)()) F1028_8522;
	R7426[13] = (char *(*)()) F1029_8522;
	R7426[14] = (char *(*)()) F1030_8522;
	R7426[15] = (char *(*)()) F1031_8522;
	R7426[16] = (char *(*)()) F1032_8522;
	R7426[17] = (char *(*)()) F1033_8522;
	R7426[18] = (char *(*)()) F1034_8522;
	R7426[19] = (char *(*)()) F1035_8522;
	R7426[20] = (char *(*)()) F1036_8522;
	R7426[21] = (char *(*)()) F1037_8522;
	R7426[22] = (char *(*)()) F1038_8522;
	R7426[23] = (char *(*)()) F1039_8522;
	R7426[24] = (char *(*)()) F1040_8522;
	R7426[25] = (char *(*)()) F1041_8522;
	R7426[26] = (char *(*)()) F1042_8522;
	R7426[27] = (char *(*)()) F1043_8522;
	R7426[28] = (char *(*)()) F1044_8522;
	R7426[29] = (char *(*)()) F1045_8522;
	R7426[30] = (char *(*)()) F1046_8522;
	R7426[31] = (char *(*)()) F1047_8522;
	R7426[32] = (char *(*)()) F1048_8522;
	R7426[33] = (char *(*)()) F1049_8522;
}

char *(*R7427[34])();
void R7427_init () {
	R7427[0] = (char *(*)()) F1016_8523;
	R7427[1] = (char *(*)()) F1017_8523;
	R7427[2] = (char *(*)()) F1018_8523;
	R7427[3] = (char *(*)()) F1019_8523;
	R7427[4] = (char *(*)()) F1020_8523;
	R7427[5] = (char *(*)()) F1021_8523;
	R7427[6] = (char *(*)()) F1022_8523;
	R7427[7] = (char *(*)()) F1023_8523;
	R7427[8] = (char *(*)()) F1024_8523;
	R7427[9] = (char *(*)()) F1025_8523;
	R7427[10] = (char *(*)()) F1026_8523;
	R7427[11] = (char *(*)()) F1027_8523;
	R7427[12] = (char *(*)()) F1028_8523;
	R7427[13] = (char *(*)()) F1029_8523;
	R7427[14] = (char *(*)()) F1030_8523;
	R7427[15] = (char *(*)()) F1031_8523;
	R7427[16] = (char *(*)()) F1032_8523;
	R7427[17] = (char *(*)()) F1033_8523;
	R7427[18] = (char *(*)()) F1034_8523;
	R7427[19] = (char *(*)()) F1035_8523;
	R7427[20] = (char *(*)()) F1036_8523;
	R7427[21] = (char *(*)()) F1037_8523;
	R7427[22] = (char *(*)()) F1038_8523;
	R7427[23] = (char *(*)()) F1039_8523;
	R7427[24] = (char *(*)()) F1040_8523;
	R7427[25] = (char *(*)()) F1041_8523;
	R7427[26] = (char *(*)()) F1042_8523;
	R7427[27] = (char *(*)()) F1043_8523;
	R7427[28] = (char *(*)()) F1044_8523;
	R7427[29] = (char *(*)()) F1045_8523;
	R7427[30] = (char *(*)()) F1046_8523;
	R7427[31] = (char *(*)()) F1047_8523;
	R7427[32] = (char *(*)()) F1048_8523;
	R7427[33] = (char *(*)()) F1049_8523;
}

char *(*R7432[34])();
void R7432_init () {
	R7432[0] = (char *(*)()) F1016_8529;
	R7432[1] = (char *(*)()) F1017_8529;
	R7432[2] = (char *(*)()) F1018_8529;
	R7432[3] = (char *(*)()) F1019_8529;
	R7432[4] = (char *(*)()) F1020_8529;
	R7432[5] = (char *(*)()) F1021_8529;
	R7432[6] = (char *(*)()) F1022_8529;
	R7432[7] = (char *(*)()) F1023_8529;
	R7432[8] = (char *(*)()) F1024_8529;
	R7432[9] = (char *(*)()) F1025_8529;
	R7432[10] = (char *(*)()) F1026_8529;
	R7432[11] = (char *(*)()) F1027_8529;
	R7432[12] = (char *(*)()) F1028_8529;
	R7432[13] = (char *(*)()) F1029_8529;
	R7432[14] = (char *(*)()) F1030_8529;
	R7432[15] = (char *(*)()) F1031_8529;
	R7432[16] = (char *(*)()) F1032_8529;
	R7432[17] = (char *(*)()) F1033_8529;
	R7432[18] = (char *(*)()) F1034_8529;
	R7432[19] = (char *(*)()) F1035_8529;
	R7432[20] = (char *(*)()) F1036_8529;
	R7432[21] = (char *(*)()) F1037_8529;
	R7432[22] = (char *(*)()) F1038_8529;
	R7432[23] = (char *(*)()) F1039_8529;
	R7432[24] = (char *(*)()) F1040_8529;
	R7432[25] = (char *(*)()) F1041_8529;
	R7432[26] = (char *(*)()) F1042_8529;
	R7432[27] = (char *(*)()) F1043_8529;
	R7432[28] = (char *(*)()) F1044_8529;
	R7432[29] = (char *(*)()) F1045_8529;
	R7432[30] = (char *(*)()) F1046_8529;
	R7432[31] = (char *(*)()) F1047_8529;
	R7432[32] = (char *(*)()) F1048_8529;
	R7432[33] = (char *(*)()) F1049_8529;
}

char *(*R7437[34])();
void R7437_init () {
	R7437[0] = (char *(*)()) F1016_8537;
	R7437[1] = (char *(*)()) F1017_8537_7437_1;
	R7437[2] = (char *(*)()) F1018_8537_7437_1;
	R7437[3] = (char *(*)()) F1019_8537_7437_1;
	R7437[4] = (char *(*)()) F1020_8537_7437_1;
	R7437[5] = (char *(*)()) F1021_8537_7437_1;
	R7437[6] = (char *(*)()) F1022_8537_7437_1;
	R7437[7] = (char *(*)()) F1023_8537_7437_1;
	R7437[8] = (char *(*)()) F1024_8537_7437_1;
	R7437[9] = (char *(*)()) F1025_8537_7437_1;
	R7437[10] = (char *(*)()) F1026_8537_7437_1;
	R7437[11] = (char *(*)()) F1027_8537_7437_1;
	R7437[12] = (char *(*)()) F1028_8537_7437_1;
	R7437[13] = (char *(*)()) F1029_8537_7437_1;
	R7437[14] = (char *(*)()) F1030_8537_7437_1;
	R7437[15] = (char *(*)()) F1031_8537_7437_1;
	R7437[16] = (char *(*)()) F1032_8537;
	R7437[17] = (char *(*)()) F1033_8537;
	R7437[18] = (char *(*)()) F1034_8537;
	R7437[19] = (char *(*)()) F1035_8537;
	R7437[20] = (char *(*)()) F1036_8537_7437_1;
	R7437[21] = (char *(*)()) F1037_8537_7437_1;
	R7437[22] = (char *(*)()) F1038_8537_7437_1;
	R7437[23] = (char *(*)()) F1039_8537_7437_1;
	R7437[24] = (char *(*)()) F1040_8537_7437_1;
	R7437[25] = (char *(*)()) F1041_8537_7437_1;
	R7437[26] = (char *(*)()) F1042_8537_7437_1;
	R7437[27] = (char *(*)()) F1043_8537_7437_1;
	R7437[28] = (char *(*)()) F1044_8537_7437_1;
	R7437[29] = (char *(*)()) F1045_8537_7437_1;
	R7437[30] = (char *(*)()) F1046_8537_7437_1;
	R7437[31] = (char *(*)()) F1047_8537_7437_1;
	R7437[32] = (char *(*)()) F1048_8537_7437_1;
	R7437[33] = (char *(*)()) F1049_8537_7437_1;
}
static EIF_REFERENCE F1017_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1017_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1018_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F1018_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1091,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1091, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1019_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1019_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1020_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1020_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1088, 0x00).id, 1088, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1021_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1021_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1022_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1022_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1023_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1023_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1079, 0x00).id, 1079, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1024_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1024_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1076, 0x00).id, 1076, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1025_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1025_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1073, 0x00).id, 1073, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1026_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1026_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1027_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1027_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1067, 0x00).id, 1067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1028_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1028_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1064, 0x00).id, 1064, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1029_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1029_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1030_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1030_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1031_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1031_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1036_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F1036_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1093,1121,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1093, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1037_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F1037_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1095,1082,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1095, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1038_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F1038_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1097,1088,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1097, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1039_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F1039_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1099,1055,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1099, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1040_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F1040_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1101,1058,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1101, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1041_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F1041_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1103,1067,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1103, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1042_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F1042_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1105,1070,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1105, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1043_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F1043_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1107,1073,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1107, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1044_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F1044_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1109,1076,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1109, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1045_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F1045_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1111,1085,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1111, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1046_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F1046_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1113,1052,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1113, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1047_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F1047_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1115,1061,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1115, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1048_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F1048_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1117,1079,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1117, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1049_8537_7437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F1049_8537(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1119,1064,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1119, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}

char *(*R7447[34])();
void R7447_init () {
	R7447[0] = (char *(*)()) F1016_8549;
	R7447[1] = (char *(*)()) F1017_8549;
	R7447[2] = (char *(*)()) F1018_8549;
	R7447[3] = (char *(*)()) F1019_8549;
	R7447[4] = (char *(*)()) F1020_8549;
	R7447[5] = (char *(*)()) F1021_8549;
	R7447[6] = (char *(*)()) F1022_8549;
	R7447[7] = (char *(*)()) F1023_8549;
	R7447[8] = (char *(*)()) F1024_8549;
	R7447[9] = (char *(*)()) F1025_8549;
	R7447[10] = (char *(*)()) F1026_8549;
	R7447[11] = (char *(*)()) F1027_8549;
	R7447[12] = (char *(*)()) F1028_8549;
	R7447[13] = (char *(*)()) F1029_8549;
	R7447[14] = (char *(*)()) F1030_8549;
	R7447[15] = (char *(*)()) F1031_8549;
	R7447[16] = (char *(*)()) F1032_8549;
	R7447[17] = (char *(*)()) F1033_8549;
	R7447[18] = (char *(*)()) F1034_8549;
	R7447[19] = (char *(*)()) F1035_8549;
	R7447[20] = (char *(*)()) F1036_8549;
	R7447[21] = (char *(*)()) F1037_8549;
	R7447[22] = (char *(*)()) F1038_8549;
	R7447[23] = (char *(*)()) F1039_8549;
	R7447[24] = (char *(*)()) F1040_8549;
	R7447[25] = (char *(*)()) F1041_8549;
	R7447[26] = (char *(*)()) F1042_8549;
	R7447[27] = (char *(*)()) F1043_8549;
	R7447[28] = (char *(*)()) F1044_8549;
	R7447[29] = (char *(*)()) F1045_8549;
	R7447[30] = (char *(*)()) F1046_8549;
	R7447[31] = (char *(*)()) F1047_8549;
	R7447[32] = (char *(*)()) F1048_8549;
	R7447[33] = (char *(*)()) F1049_8549;
}

char *(*R7589[2])();
void R7589_init () {
	R7589[0] = (char *(*)()) F1052_8728;
	R7589[1] = (char *(*)()) F1053_8728;
}

char *(*R7596[2])();
void R7596_init () {
	R7596[0] = (char *(*)()) F1052_8732;
	R7596[1] = (char *(*)()) F1053_8732;
}

char *(*R7610[2])();
void R7610_init () {
	R7610[0] = (char *(*)()) F1055_8786;
	R7610[1] = (char *(*)()) F1056_8786;
}

char *(*R7715[2])();
void R7715_init () {
	R7715[0] = (char *(*)()) F1064_8941;
	R7715[1] = (char *(*)()) F1065_8941;
}

char *(*R7716[2])();
void R7716_init () {
	R7716[0] = (char *(*)()) F1064_8942;
	R7716[1] = (char *(*)()) F1065_8942;
}

char *(*R7719[2])();
void R7719_init () {
	R7719[0] = (char *(*)()) F1064_8945;
	R7719[1] = (char *(*)()) F1065_8945;
}

char *(*R7771[2])();
void R7771_init () {
	R7771[0] = (char *(*)()) F1067_9040;
	R7771[1] = (char *(*)()) F1068_9040;
}

char *(*R7772[2])();
void R7772_init () {
	R7772[0] = (char *(*)()) F1067_9041;
	R7772[1] = (char *(*)()) F1068_9041;
}

char *(*R7774[2])();
void R7774_init () {
	R7774[0] = (char *(*)()) F1067_9043;
	R7774[1] = (char *(*)()) F1068_9043;
}

char *(*R7776[2])();
void R7776_init () {
	R7776[0] = (char *(*)()) F1067_9045;
	R7776[1] = (char *(*)()) F1068_9045;
}

char *(*R7828[2])();
void R7828_init () {
	R7828[0] = (char *(*)()) F1070_9140;
	R7828[1] = (char *(*)()) F1071_9140;
}

char *(*R7831[2])();
void R7831_init () {
	R7831[0] = (char *(*)()) F1070_9143;
	R7831[1] = (char *(*)()) F1071_9143;
}

char *(*R7881[2])();
void R7881_init () {
	R7881[0] = (char *(*)()) F1073_9236;
	R7881[1] = (char *(*)()) F1074_9236;
}

char *(*R7884[2])();
void R7884_init () {
	R7884[0] = (char *(*)()) F1073_9239;
	R7884[1] = (char *(*)()) F1074_9239;
}

char *(*R7887[2])();
void R7887_init () {
	R7887[0] = (char *(*)()) F1073_9242;
	R7887[1] = (char *(*)()) F1074_9242;
}

char *(*R7941[2])();
void R7941_init () {
	R7941[0] = (char *(*)()) F1076_9336;
	R7941[1] = (char *(*)()) F1077_9336;
}

char *(*R7987[2])();
void R7987_init () {
	R7987[0] = (char *(*)()) F1079_9424;
	R7987[1] = (char *(*)()) F1080_9424;
}

char *(*R7988[2])();
void R7988_init () {
	R7988[0] = (char *(*)()) F1079_9425;
	R7988[1] = (char *(*)()) F1080_9425;
}

char *(*R7990[2])();
void R7990_init () {
	R7990[0] = (char *(*)()) F1079_9427;
	R7990[1] = (char *(*)()) F1080_9427;
}

char *(*R7993[2])();
void R7993_init () {
	R7993[0] = (char *(*)()) F1079_9430;
	R7993[1] = (char *(*)()) F1080_9430;
}

char *(*R7994[2])();
void R7994_init () {
	R7994[0] = (char *(*)()) F1079_9431;
	R7994[1] = (char *(*)()) F1080_9431;
}

char *(*R8042[2])();
void R8042_init () {
	R8042[0] = (char *(*)()) F1082_9521;
	R8042[1] = (char *(*)()) F1083_9521;
}

char *(*R8043[2])();
void R8043_init () {
	R8043[0] = (char *(*)()) F1082_9522;
	R8043[1] = (char *(*)()) F1083_9522;
}

char *(*R8046[2])();
void R8046_init () {
	R8046[0] = (char *(*)()) F1082_9525;
	R8046[1] = (char *(*)()) F1083_9525;
}

char *(*R8094[2])();
void R8094_init () {
	R8094[0] = (char *(*)()) F1085_9615;
	R8094[1] = (char *(*)()) F1086_9615;
}

char *(*R8095[2])();
void R8095_init () {
	R8095[0] = (char *(*)()) F1085_9616;
	R8095[1] = (char *(*)()) F1086_9616;
}

char *(*R8096[2])();
void R8096_init () {
	R8096[0] = (char *(*)()) F1085_9617;
	R8096[1] = (char *(*)()) F1086_9617;
}

char *(*R8097[2])();
void R8097_init () {
	R8097[0] = (char *(*)()) F1085_9618;
	R8097[1] = (char *(*)()) F1086_9618;
}

char *(*R8099[2])();
void R8099_init () {
	R8099[0] = (char *(*)()) F1085_9620;
	R8099[1] = (char *(*)()) F1086_9620;
}

char *(*R8145[2])();
void R8145_init () {
	R8145[0] = (char *(*)()) F1088_9678;
	R8145[1] = (char *(*)()) F1089_9678;
}

char *(*R8152[2])();
void R8152_init () {
	R8152[0] = (char *(*)()) F1088_9682;
	R8152[1] = (char *(*)()) F1089_9682;
}

char *(*R8201[5])();
void R8201_init () {
	R8201[0] = (char *(*)()) F1124_9770;
	R8201[1] = (char *(*)()) F1125_9773;
	R8201[2] = (char *(*)()) F1126_9773;
	R8201[3] = (char *(*)()) F1127_9773;
	R8201[4] = (char *(*)()) F1126_9773;
}

char *(*R8225[4])();
void R8225_init () {
	R8225[0] = (char *(*)()) F1125_9772;
	R8225[1] = (char *(*)()) F1126_9772_8225_1;
	R8225[2] = (char *(*)()) F1127_9772_8225_1;
	R8225[3] = (char *(*)()) F1126_9772_8225_1;
}
static EIF_REFERENCE F1126_9772_8225_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1126_9772(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1127_9772_8225_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1127_9772(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R8226[4])();
void R8226_init () {
	R8226[0] = (char *(*)()) F1125_9774;
	R8226[1] = (char *(*)()) F1126_9774_8226_5;
	R8226[2] = (char *(*)()) F1127_9774_8226_5;
	R8226[3] = (char *(*)()) F1126_9774_8226_5;
}
static EIF_REFERENCE F1126_9774_8226_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1126_9774(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1127_9774_8226_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1127_9774(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R8230[4])();
void R8230_init () {
	R8230[0] = (char *(*)()) F1125_9781;
	R8230[1] = (char *(*)()) F1126_9781_8230_643;
	R8230[2] = (char *(*)()) F1127_9781_8230_643;
	R8230[3] = (char *(*)()) F1126_9781_8230_643;
}
static EIF_REFERENCE F1126_9781_8230_643 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1126_9781(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1127_9781_8230_643 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1127_9781(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y8231_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y8231_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y8231_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y8231_pgtype3[] = {1061,0xFFFF};
EIF_TYPE_INDEX *Y8231_gen_type [4];
EIF_TYPE_INDEX Y8231 [4];
void Y8231_init (void)
{
	egc_routines_types [8231] = Y8231;
	egc_routines_gen_types [8231] = Y8231_gen_type;
	egc_routines_offset [8231] = 1124;
	Y8231_gen_type [0] = Y8231_pgtype0;
	Y8231_gen_type [1] = Y8231_pgtype1;
	Y8231_gen_type [2] = Y8231_pgtype2;
	Y8231_gen_type [3] = Y8231_pgtype3;
	Y8231[3] = 1061;
}

char *(*R8232[5])();
void R8232_init () {
	{long i; for (i = 0; i < 2; i++) R8232[i] = (char *(*)()) F1132_9913;}
	{long i; for (i = 3; i < 5; i++) R8232[i] = (char *(*)()) F1135_10080;}
}

char *(*R8234[5])();
void R8234_init () {
	R8234[0] = (char *(*)()) F1133_9974;
	R8234[1] = (char *(*)()) F1134_9997;
	R8234[3] = (char *(*)()) F1136_10140;
	R8234[4] = (char *(*)()) F1137_10162;
}

char *(*R8235[5])();
void R8235_init () {
	R8235[0] = (char *(*)()) F1133_9972;
	R8235[1] = (char *(*)()) F1134_9995;
	R8235[3] = (char *(*)()) F1136_10139;
	R8235[4] = (char *(*)()) F1137_10161;
}

char *(*R8236[5])();
void R8236_init () {
	{long i; for (i = 0; i < 2; i++) R8236[i] = (char *(*)()) F1132_9925;}
	{long i; for (i = 3; i < 5; i++) R8236[i] = (char *(*)()) F1129_9786;}
}

char *(*R8246[5])();
void R8246_init () {
	{long i; for (i = 0; i < 2; i++) R8246[i] = (char *(*)()) F1132_9943;}
	{long i; for (i = 3; i < 5; i++) R8246[i] = (char *(*)()) F1135_10111;}
}

char *(*R8248[5])();
void R8248_init () {
	{long i; for (i = 0; i < 2; i++) R8248[i] = (char *(*)()) F1132_9945;}
	{long i; for (i = 3; i < 5; i++) R8248[i] = (char *(*)()) F1135_10113;}
}

char *(*R8249[5])();
void R8249_init () {
	R8249[0] = (char *(*)()) F1133_9984;
	R8249[1] = (char *(*)()) F554_5957;
	R8249[3] = (char *(*)()) F1136_10149;
	R8249[4] = (char *(*)()) F558_5957;
}

char *(*R8251[5])();
void R8251_init () {
	{long i; for (i = 0; i < 2; i++) R8251[i] = (char *(*)()) F1132_9946;}
	{long i; for (i = 3; i < 5; i++) R8251[i] = (char *(*)()) F1135_10114;}
}

char *(*R8252[5])();
void R8252_init () {
	{long i; for (i = 0; i < 2; i++) R8252[i] = (char *(*)()) F1132_9947;}
	{long i; for (i = 3; i < 5; i++) R8252[i] = (char *(*)()) F1129_9803;}
}

char *(*R8271[5])();
void R8271_init () {
	{long i; for (i = 0; i < 2; i++) R8271[i] = (char *(*)()) F1132_9934;}
	{long i; for (i = 3; i < 5; i++) R8271[i] = (char *(*)()) F1135_10102;}
}

char *(*R8272[5])();
void R8272_init () {
	{long i; for (i = 0; i < 2; i++) R8272[i] = (char *(*)()) F1132_9933;}
	{long i; for (i = 3; i < 5; i++) R8272[i] = (char *(*)()) F1135_10101;}
}

char *(*R8282[5])();
void R8282_init () {
	{long i; for (i = 0; i < 2; i++) R8282[i] = (char *(*)()) F1132_9930;}
	{long i; for (i = 3; i < 5; i++) R8282[i] = (char *(*)()) F1135_10098;}
}

char *(*R8293[5])();
void R8293_init () {
	R8293[0] = (char *(*)()) F1133_9979;
	R8293[1] = (char *(*)()) F1134_10063;
	R8293[4] = (char *(*)()) F1137_10228;
}

char *(*R8312[5])();
void R8312_init () {
	R8312[0] = (char *(*)()) F1133_9981;
	R8312[1] = (char *(*)()) F1134_10075;
	R8312[3] = (char *(*)()) F1136_10147;
	R8312[4] = (char *(*)()) F1137_10240;
}

char *(*R8316[5])();
void R8316_init () {
	R8316[0] = (char *(*)()) F1133_9985;
	R8316[1] = (char *(*)()) F1134_10078;
	R8316[3] = (char *(*)()) F1136_10151;
	R8316[4] = (char *(*)()) F1137_10244;
}

char *(*R8327[4])();
void R8327_init () {
	R8327[0] = (char *(*)()) F1134_10077;
	R8327[3] = (char *(*)()) F1137_10242;
}

char *(*R8330[4])();
void R8330_init () {
	R8330[0] = (char *(*)()) F1134_10016;
	R8330[3] = (char *(*)()) F1137_10181;
}

char *(*R8342[4])();
void R8342_init () {
	R8342[0] = (char *(*)()) F1134_10027;
	R8342[3] = (char *(*)()) F1137_10192;
}

char *(*R8352[4])();
void R8352_init () {
	R8352[0] = (char *(*)()) F1134_10012;
	R8352[3] = (char *(*)()) F1137_10177;
}

char *(*R8353[4])();
void R8353_init () {
	R8353[0] = (char *(*)()) F1134_10013;
	R8353[3] = (char *(*)()) F1137_10178;
}

char *(*R8360[4])();
void R8360_init () {
	R8360[0] = (char *(*)()) F1134_10060;
	R8360[3] = (char *(*)()) F1137_10225;
}

char *(*R8388[2])();
void R8388_init () {
	R8388[0] = (char *(*)()) F1133_9987;
	R8388[1] = (char *(*)()) F1132_9964;
}

char *(*R8460[2])();
void R8460_init () {
	R8460[0] = (char *(*)()) F1136_10142;
	R8460[1] = (char *(*)()) F1137_10212;
}

char *(*R8468[2])();
void R8468_init () {
	R8468[0] = (char *(*)()) F1136_10153;
	R8468[1] = (char *(*)()) F1135_10132;
}

char *(*R8553[2])();
void R8553_init () {
	R8553[0] = (char *(*)()) F1241_11405;
	R8553[1] = (char *(*)()) F1242_11426;
}

char *(*R8567[44])();
void R8567_init () {
	R8567[0] = (char *(*)()) F1218_11102;
	{long i; for (i = 1; i < 3; i++) R8567[i] = (char *(*)()) F1219_11104;}
	R8567[3] = (char *(*)()) F1221_11154;
	R8567[4] = (char *(*)()) F1222_11162;
	R8567[6] = (char *(*)()) F1224_11186;
	R8567[7] = (char *(*)()) F1225_11219;
	R8567[11] = (char *(*)()) F1227_11245;
	{long i; for (i = 12; i < 14; i++) R8567[i] = (char *(*)()) F1230_11264;}
	R8567[15] = (char *(*)()) F1230_11264;
	R8567[43] = (char *(*)()) F1261_11580;
}

char *(*R8569[14])();
void R8569_init () {
	R8569[0] = (char *(*)()) F1255_11520;
	R8569[13] = (char *(*)()) F1268_11619;
}

char *(*R8571[4])();
void R8571_init () {
	R8571[0] = (char *(*)()) F1244_11467;
	R8571[3] = (char *(*)()) F1247_11475;
}

char *(*R8573[55])();
void R8573_init () {
	R8573[0] = (char *(*)()) F1218_11102;
	{long i; for (i = 1; i < 3; i++) R8573[i] = (char *(*)()) F1219_11104;}
	R8573[3] = (char *(*)()) F1221_11154;
	R8573[4] = (char *(*)()) F1222_11162;
	R8573[6] = (char *(*)()) F1224_11186;
	R8573[7] = (char *(*)()) F1225_11219;
	R8573[11] = (char *(*)()) F1227_11245;
	{long i; for (i = 12; i < 14; i++) R8573[i] = (char *(*)()) F1230_11264;}
	R8573[15] = (char *(*)()) F1230_11264;
	R8573[18] = (char *(*)()) F1236_11335;
	R8573[19] = (char *(*)()) F1237_11358;
	{long i; for (i = 20; i < 22; i++) R8573[i] = (char *(*)()) F1238_11365;}
	R8573[23] = (char *(*)()) F1241_11405;
	R8573[24] = (char *(*)()) F1242_11426;
	R8573[26] = (char *(*)()) F1244_11467;
	R8573[29] = (char *(*)()) F1247_11475;
	R8573[32] = (char *(*)()) F1250_11496;
	R8573[34] = (char *(*)()) F1252_11499;
	R8573[37] = (char *(*)()) F1255_11520;
	R8573[43] = (char *(*)()) F1261_11580;
	R8573[50] = (char *(*)()) F1268_11619;
	R8573[53] = (char *(*)()) F1271_11644;
	R8573[54] = (char *(*)()) F1272_11650;
}

char *(*R8589[9])();
void R8589_init () {
	R8589[0] = (char *(*)()) F1225_11219;
	R8589[4] = (char *(*)()) F1227_11245;
	{long i; for (i = 5; i < 7; i++) R8589[i] = (char *(*)()) F1230_11264;}
	R8589[8] = (char *(*)()) F1230_11264;
}

char *(*R8594[55])();
void R8594_init () {
	R8594[0] = (char *(*)()) F1218_11102;
	{long i; for (i = 1; i < 3; i++) R8594[i] = (char *(*)()) F1219_11104;}
	R8594[3] = (char *(*)()) F1221_11154;
	R8594[4] = (char *(*)()) F1222_11162;
	R8594[6] = (char *(*)()) F1224_11186;
	R8594[7] = (char *(*)()) F1225_11219;
	R8594[11] = (char *(*)()) F1227_11245;
	{long i; for (i = 12; i < 14; i++) R8594[i] = (char *(*)()) F1230_11264;}
	R8594[15] = (char *(*)()) F1230_11264;
	R8594[18] = (char *(*)()) F1236_11335;
	R8594[19] = (char *(*)()) F1237_11358;
	{long i; for (i = 20; i < 22; i++) R8594[i] = (char *(*)()) F1238_11365;}
	R8594[23] = (char *(*)()) F1241_11405;
	R8594[24] = (char *(*)()) F1242_11426;
	R8594[26] = (char *(*)()) F1244_11467;
	R8594[29] = (char *(*)()) F1247_11475;
	R8594[43] = (char *(*)()) F1261_11580;
	R8594[53] = (char *(*)()) F1271_11644;
	R8594[54] = (char *(*)()) F1272_11650;
}

char *(*R8637[102])();
void R8637_init () {
	R8637[0] = (char *(*)()) F1171_10431;
	R8637[1] = (char *(*)()) F1172_10437;
	R8637[3] = (char *(*)()) F1174_10477;
	R8637[4] = (char *(*)()) F1175_10518;
	R8637[5] = (char *(*)()) F1176_10534;
	R8637[6] = (char *(*)()) F1177_10563;
	R8637[7] = (char *(*)()) F1178_10576;
	R8637[9] = (char *(*)()) F1180_10604;
	R8637[14] = (char *(*)()) F1184_10667;
	R8637[31] = (char *(*)()) F1202_10857;
	R8637[33] = (char *(*)()) F1204_10876;
	R8637[35] = (char *(*)()) F1206_10901;
	R8637[36] = (char *(*)()) F1207_10904;
	R8637[47] = (char *(*)()) F1218_11102;
	{long i; for (i = 48; i < 50; i++) R8637[i] = (char *(*)()) F1219_11104;}
	R8637[50] = (char *(*)()) F1221_11154;
	R8637[51] = (char *(*)()) F1222_11162;
	R8637[53] = (char *(*)()) F1224_11186;
	R8637[54] = (char *(*)()) F1225_11219;
	R8637[58] = (char *(*)()) F1227_11245;
	{long i; for (i = 59; i < 61; i++) R8637[i] = (char *(*)()) F1230_11264;}
	R8637[62] = (char *(*)()) F1230_11264;
	R8637[65] = (char *(*)()) F1236_11335;
	R8637[66] = (char *(*)()) F1237_11358;
	{long i; for (i = 67; i < 69; i++) R8637[i] = (char *(*)()) F1238_11365;}
	R8637[70] = (char *(*)()) F1241_11405;
	R8637[71] = (char *(*)()) F1242_11426;
	R8637[73] = (char *(*)()) F1244_11467;
	R8637[76] = (char *(*)()) F1247_11475;
	R8637[79] = (char *(*)()) F1250_11496;
	R8637[81] = (char *(*)()) F1252_11499;
	R8637[84] = (char *(*)()) F1255_11520;
	R8637[90] = (char *(*)()) F1261_11580;
	R8637[97] = (char *(*)()) F1268_11619;
	R8637[100] = (char *(*)()) F1271_11644;
	R8637[101] = (char *(*)()) F1272_11650;
}

char *(*R8639[102])();
void R8639_init () {
	R8639[0] = (char *(*)()) F1171_10433;
	R8639[1] = (char *(*)()) F1172_10438;
	R8639[3] = (char *(*)()) F1174_10476;
	R8639[4] = (char *(*)()) F1175_10520;
	R8639[5] = (char *(*)()) F1176_10533;
	R8639[6] = (char *(*)()) F1177_10565;
	R8639[7] = (char *(*)()) F1178_10579;
	R8639[9] = (char *(*)()) F1180_10606;
	R8639[14] = (char *(*)()) F1184_10669;
	R8639[31] = (char *(*)()) F1202_10859;
	R8639[33] = (char *(*)()) F1204_10877;
	R8639[35] = (char *(*)()) F1206_10902;
	R8639[36] = (char *(*)()) F1207_10905;
	R8639[47] = (char *(*)()) F1218_11103;
	{long i; for (i = 48; i < 50; i++) R8639[i] = (char *(*)()) F1219_11105;}
	R8639[50] = (char *(*)()) F1221_11155;
	R8639[51] = (char *(*)()) F1222_11163;
	R8639[53] = (char *(*)()) F1224_11187;
	R8639[54] = (char *(*)()) F1225_11223;
	R8639[58] = (char *(*)()) F1227_11246;
	{long i; for (i = 59; i < 61; i++) R8639[i] = (char *(*)()) F1230_11265;}
	R8639[62] = (char *(*)()) F1230_11265;
	R8639[65] = (char *(*)()) F1236_11336;
	R8639[66] = (char *(*)()) F1237_11359;
	{long i; for (i = 67; i < 69; i++) R8639[i] = (char *(*)()) F1238_11366;}
	R8639[70] = (char *(*)()) F1241_11406;
	R8639[71] = (char *(*)()) F1242_11427;
	R8639[73] = (char *(*)()) F1244_11468;
	R8639[76] = (char *(*)()) F1247_11476;
	R8639[79] = (char *(*)()) F1250_11497;
	R8639[81] = (char *(*)()) F1252_11500;
	R8639[84] = (char *(*)()) F1255_11521;
	R8639[90] = (char *(*)()) F1261_11570;
	R8639[97] = (char *(*)()) F1268_11620;
	R8639[100] = (char *(*)()) F1271_11645;
	R8639[101] = (char *(*)()) F1272_11651;
}

char *(*R8640[102])();
void R8640_init () {
	R8640[0] = (char *(*)()) F1171_10432;
	R8640[1] = (char *(*)()) F1172_10439;
	R8640[3] = (char *(*)()) F1174_10475;
	R8640[4] = (char *(*)()) F1175_10519;
	R8640[5] = (char *(*)()) F1176_10532;
	R8640[6] = (char *(*)()) F1177_10564;
	R8640[7] = (char *(*)()) F1178_10578;
	R8640[9] = (char *(*)()) F1180_10605;
	R8640[14] = (char *(*)()) F1184_10668;
	R8640[31] = (char *(*)()) F1202_10858;
	R8640[33] = (char *(*)()) F1203_10868;
	{long i; for (i = 35; i < 37; i++) R8640[i] = (char *(*)()) F1203_10868;}
	{long i; for (i = 47; i < 52; i++) R8640[i] = (char *(*)()) F1010_8398;}
	{long i; for (i = 53; i < 55; i++) R8640[i] = (char *(*)()) F1010_8398;}
	R8640[58] = (char *(*)()) F1228_11247;
	{long i; for (i = 59; i < 61; i++) R8640[i] = (char *(*)()) F1010_8398;}
	R8640[62] = (char *(*)()) F1232_11274;
	{long i; for (i = 65; i < 68; i++) R8640[i] = (char *(*)()) F1010_8398;}
	R8640[68] = (char *(*)()) F1239_11367;
	{long i; for (i = 70; i < 72; i++) R8640[i] = (char *(*)()) F1010_8398;}
	R8640[73] = (char *(*)()) F1010_8398;
	R8640[76] = (char *(*)()) F1010_8398;
	R8640[79] = (char *(*)()) F1010_8398;
	R8640[81] = (char *(*)()) F1010_8398;
	R8640[84] = (char *(*)()) F1010_8398;
	R8640[90] = (char *(*)()) F1010_8398;
	R8640[97] = (char *(*)()) F1010_8398;
	{long i; for (i = 100; i < 102; i++) R8640[i] = (char *(*)()) F1010_8398;}
}

char *(*R8641[102])();
void R8641_init () {
	{long i; for (i = 0; i < 2; i++) R8641[i] = (char *(*)()) F1168_10372;}
	{long i; for (i = 3; i < 8; i++) R8641[i] = (char *(*)()) F1168_10372;}
	R8641[9] = (char *(*)()) F1168_10372;
	R8641[14] = (char *(*)()) F1184_10630;
	R8641[31] = (char *(*)()) F1168_10372;
	R8641[33] = (char *(*)()) F1168_10372;
	{long i; for (i = 35; i < 37; i++) R8641[i] = (char *(*)()) F1168_10372;}
	{long i; for (i = 47; i < 52; i++) R8641[i] = (char *(*)()) F1168_10372;}
	R8641[53] = (char *(*)()) F1168_10372;
	R8641[54] = (char *(*)()) F1225_11189;
	R8641[58] = (char *(*)()) F1228_11248;
	{long i; for (i = 59; i < 61; i++) R8641[i] = (char *(*)()) F1230_11251;}
	R8641[62] = (char *(*)()) F1233_11306;
	{long i; for (i = 65; i < 68; i++) R8641[i] = (char *(*)()) F1168_10372;}
	R8641[68] = (char *(*)()) F1239_11368;
	{long i; for (i = 70; i < 72; i++) R8641[i] = (char *(*)()) F1168_10372;}
	R8641[73] = (char *(*)()) F1168_10372;
	R8641[76] = (char *(*)()) F1168_10372;
	R8641[79] = (char *(*)()) F1168_10372;
	R8641[81] = (char *(*)()) F1168_10372;
	R8641[84] = (char *(*)()) F1168_10372;
	R8641[90] = (char *(*)()) F1168_10372;
	R8641[97] = (char *(*)()) F1168_10372;
	{long i; for (i = 100; i < 102; i++) R8641[i] = (char *(*)()) F1168_10372;}
}

char *(*R8820[55])();
void R8820_init () {
	{long i; for (i = 0; i < 5; i++) R8820[i] = (char *(*)()) F1212_10988;}
	{long i; for (i = 6; i < 8; i++) R8820[i] = (char *(*)()) F1212_10988;}
	{long i; for (i = 11; i < 14; i++) R8820[i] = (char *(*)()) F1212_10988;}
	R8820[15] = (char *(*)()) F1212_10988;
	{long i; for (i = 18; i < 22; i++) R8820[i] = (char *(*)()) F1212_10988;}
	{long i; for (i = 23; i < 25; i++) R8820[i] = (char *(*)()) F1212_10988;}
	R8820[26] = (char *(*)()) F1212_10988;
	R8820[29] = (char *(*)()) F1212_10988;
	R8820[32] = (char *(*)()) F1248_11477;
	R8820[34] = (char *(*)()) F1251_11498;
	R8820[37] = (char *(*)()) F1248_11477;
	R8820[43] = (char *(*)()) F1212_10988;
	R8820[50] = (char *(*)()) F1268_11614;
	{long i; for (i = 53; i < 55; i++) R8820[i] = (char *(*)()) F1212_10988;}
}

char *(*R8822[55])();
void R8822_init () {
	{long i; for (i = 0; i < 4; i++) R8822[i] = (char *(*)()) F1181_10610;}
	R8822[4] = (char *(*)()) F1222_11157;
	{long i; for (i = 6; i < 8; i++) R8822[i] = (char *(*)()) F1181_10610;}
	{long i; for (i = 11; i < 14; i++) R8822[i] = (char *(*)()) F1181_10610;}
	R8822[15] = (char *(*)()) F1232_11280;
	{long i; for (i = 18; i < 22; i++) R8822[i] = (char *(*)()) F1181_10610;}
	{long i; for (i = 23; i < 25; i++) R8822[i] = (char *(*)()) F1181_10610;}
	R8822[26] = (char *(*)()) F1244_11462;
	R8822[29] = (char *(*)()) F1244_11462;
	R8822[32] = (char *(*)()) F1250_11491;
	R8822[34] = (char *(*)()) F1181_10610;
	R8822[37] = (char *(*)()) F1255_11515;
	R8822[43] = (char *(*)()) F1181_10610;
	R8822[50] = (char *(*)()) F1255_11515;
	{long i; for (i = 53; i < 55; i++) R8822[i] = (char *(*)()) F1181_10610;}
}

char *(*R8879[71])();
void R8879_init () {
	R8879[0] = (char *(*)()) F1186_10674;
	{long i; for (i = 16; i < 21; i++) R8879[i] = (char *(*)()) F1186_10674;}
	{long i; for (i = 22; i < 24; i++) R8879[i] = (char *(*)()) F1186_10674;}
	{long i; for (i = 27; i < 30; i++) R8879[i] = (char *(*)()) F1186_10674;}
	R8879[31] = (char *(*)()) F1232_11278;
	{long i; for (i = 34; i < 38; i++) R8879[i] = (char *(*)()) F1186_10674;}
	{long i; for (i = 39; i < 41; i++) R8879[i] = (char *(*)()) F1186_10674;}
	R8879[42] = (char *(*)()) F1186_10674;
	R8879[45] = (char *(*)()) F1186_10674;
	R8879[59] = (char *(*)()) F1186_10674;
	{long i; for (i = 69; i < 71; i++) R8879[i] = (char *(*)()) F1186_10674;}
}

char *(*R8880[71])();
void R8880_init () {
	R8880[0] = (char *(*)()) F1186_10675;
	{long i; for (i = 16; i < 21; i++) R8880[i] = (char *(*)()) F1186_10675;}
	{long i; for (i = 22; i < 24; i++) R8880[i] = (char *(*)()) F1186_10675;}
	{long i; for (i = 27; i < 30; i++) R8880[i] = (char *(*)()) F1186_10675;}
	R8880[31] = (char *(*)()) F1232_11279;
	{long i; for (i = 34; i < 38; i++) R8880[i] = (char *(*)()) F1186_10675;}
	{long i; for (i = 39; i < 41; i++) R8880[i] = (char *(*)()) F1186_10675;}
	R8880[42] = (char *(*)()) F1186_10675;
	R8880[45] = (char *(*)()) F1186_10675;
	R8880[59] = (char *(*)()) F1186_10675;
	{long i; for (i = 69; i < 71; i++) R8880[i] = (char *(*)()) F1186_10675;}
}

char *(*R8881[71])();
void R8881_init () {
	R8881[0] = (char *(*)()) F1186_10676;
	{long i; for (i = 16; i < 21; i++) R8881[i] = (char *(*)()) F1186_10676;}
	{long i; for (i = 22; i < 24; i++) R8881[i] = (char *(*)()) F1186_10676;}
	{long i; for (i = 27; i < 30; i++) R8881[i] = (char *(*)()) F1186_10676;}
	R8881[31] = (char *(*)()) F1232_11282;
	{long i; for (i = 34; i < 38; i++) R8881[i] = (char *(*)()) F1186_10676;}
	{long i; for (i = 39; i < 41; i++) R8881[i] = (char *(*)()) F1186_10676;}
	R8881[42] = (char *(*)()) F1186_10676;
	R8881[45] = (char *(*)()) F1186_10676;
	R8881[59] = (char *(*)()) F1186_10676;
	{long i; for (i = 69; i < 71; i++) R8881[i] = (char *(*)()) F1186_10676;}
}

char *(*R8882[71])();
void R8882_init () {
	R8882[0] = (char *(*)()) F1186_10677;
	{long i; for (i = 16; i < 21; i++) R8882[i] = (char *(*)()) F1186_10677;}
	{long i; for (i = 22; i < 24; i++) R8882[i] = (char *(*)()) F1186_10677;}
	{long i; for (i = 27; i < 30; i++) R8882[i] = (char *(*)()) F1186_10677;}
	R8882[31] = (char *(*)()) F1232_11281;
	{long i; for (i = 34; i < 38; i++) R8882[i] = (char *(*)()) F1186_10677;}
	{long i; for (i = 39; i < 41; i++) R8882[i] = (char *(*)()) F1186_10677;}
	R8882[42] = (char *(*)()) F1186_10677;
	R8882[45] = (char *(*)()) F1186_10677;
	R8882[59] = (char *(*)()) F1186_10677;
	{long i; for (i = 69; i < 71; i++) R8882[i] = (char *(*)()) F1186_10677;}
}

char *(*R9144[16])();
void R9144_init () {
	{long i; for (i = 0; i < 3; i++) R9144[i] = (char *(*)()) F1210_10953;}
	{long i; for (i = 3; i < 5; i++) R9144[i] = (char *(*)()) F1213_11029;}
	{long i; for (i = 6; i < 8; i++) R9144[i] = (char *(*)()) F1213_11029;}
	{long i; for (i = 11; i < 14; i++) R9144[i] = (char *(*)()) F1213_11029;}
	R9144[15] = (char *(*)()) F1213_11029;
}

char *(*R9147[16])();
void R9147_init () {
	{long i; for (i = 0; i < 3; i++) R9147[i] = (char *(*)()) F1210_10962;}
	{long i; for (i = 3; i < 5; i++) R9147[i] = (char *(*)()) F1221_11151;}
	{long i; for (i = 6; i < 8; i++) R9147[i] = (char *(*)()) F1221_11151;}
	{long i; for (i = 11; i < 14; i++) R9147[i] = (char *(*)()) F1221_11151;}
	R9147[15] = (char *(*)()) F1221_11151;
}

char *(*R9573[176])();
void R9573_init () {
	R9573[0] = (char *(*)()) F1280_11793;
	R9573[5] = (char *(*)()) F1285_11869;
	R9573[7] = (char *(*)()) F1287_11925;
	R9573[10] = (char *(*)()) F1290_11952;
	R9573[12] = (char *(*)()) F1292_12047;
	R9573[14] = (char *(*)()) F1293_12065;
	R9573[17] = (char *(*)()) F1297_12112;
	R9573[19] = (char *(*)()) F1299_12317;
	R9573[23] = (char *(*)()) F1300_12369;
	R9573[63] = (char *(*)()) F1300_12369;
	{long i; for (i = 68; i < 70; i++) R9573[i] = (char *(*)()) F1300_12369;}
	{long i; for (i = 86; i < 88; i++) R9573[i] = (char *(*)()) F1355_13105;}
	{long i; for (i = 92; i < 94; i++) R9573[i] = (char *(*)()) F1355_13105;}
	R9573[95] = (char *(*)()) F1355_13105;
	R9573[100] = (char *(*)()) F1380_13438;
	{long i; for (i = 102; i < 104; i++) R9573[i] = (char *(*)()) F1380_13438;}
	{long i; for (i = 126; i < 128; i++) R9573[i] = (char *(*)()) F1353_13046;}
	{long i; for (i = 129; i < 131; i++) R9573[i] = (char *(*)()) F1353_13046;}
	{long i; for (i = 134; i < 137; i++) R9573[i] = (char *(*)()) F1353_13046;}
	R9573[139] = (char *(*)()) F1353_13046;
	R9573[143] = (char *(*)()) F1423_14242;
	R9573[149] = (char *(*)()) F1428_14324;
	R9573[155] = (char *(*)()) F1428_14324;
	R9573[159] = (char *(*)()) F1439_14397;
	R9573[172] = (char *(*)()) F1452_14682;
	R9573[174] = (char *(*)()) F1454_14765;
	R9573[175] = (char *(*)()) F1455_14851;
}

char *(*R10115[152])();
void R10115_init () {
	R10115[0] = (char *(*)()) F1300_12378;
	R10115[40] = (char *(*)()) F1300_12378;
	{long i; for (i = 45; i < 47; i++) R10115[i] = (char *(*)()) F1300_12378;}
	{long i; for (i = 63; i < 65; i++) R10115[i] = (char *(*)()) F1365_13217;}
	R10115[69] = (char *(*)()) F1300_12378;
	R10115[70] = (char *(*)()) F1373_13261;
	R10115[72] = (char *(*)()) F1375_13305;
	R10115[77] = (char *(*)()) F1300_12378;
	{long i; for (i = 79; i < 81; i++) R10115[i] = (char *(*)()) F1300_12378;}
	R10115[103] = (char *(*)()) F1406_13873;
	R10115[104] = (char *(*)()) F1407_13900;
	R10115[106] = (char *(*)()) F1409_13911;
	R10115[107] = (char *(*)()) F1300_12378;
	{long i; for (i = 111; i < 113; i++) R10115[i] = (char *(*)()) F1414_14130;}
	R10115[113] = (char *(*)()) F1416_14166;
	R10115[116] = (char *(*)()) F1416_14166;
	R10115[126] = (char *(*)()) F1429_14329;
	R10115[132] = (char *(*)()) F1435_14345;
	R10115[136] = (char *(*)()) F1435_14345;
	R10115[149] = (char *(*)()) F1300_12378;
	R10115[151] = (char *(*)()) F1300_12378;
}

char *(*R10117[152])();
void R10117_init () {
	R10117[0] = (char *(*)()) F1300_12381;
	R10117[40] = (char *(*)()) F1300_12381;
	{long i; for (i = 45; i < 47; i++) R10117[i] = (char *(*)()) F1300_12381;}
	{long i; for (i = 63; i < 65; i++) R10117[i] = (char *(*)()) F1300_12381;}
	{long i; for (i = 69; i < 71; i++) R10117[i] = (char *(*)()) F1300_12381;}
	R10117[72] = (char *(*)()) F1300_12381;
	R10117[77] = (char *(*)()) F1300_12381;
	{long i; for (i = 79; i < 81; i++) R10117[i] = (char *(*)()) F1300_12381;}
	{long i; for (i = 103; i < 105; i++) R10117[i] = (char *(*)()) F1300_12381;}
	R10117[106] = (char *(*)()) F1300_12381;
	R10117[107] = (char *(*)()) F1410_13992;
	{long i; for (i = 111; i < 114; i++) R10117[i] = (char *(*)()) F1300_12381;}
	R10117[116] = (char *(*)()) F1300_12381;
	R10117[126] = (char *(*)()) F1300_12381;
	R10117[132] = (char *(*)()) F1300_12381;
	R10117[136] = (char *(*)()) F1300_12381;
	R10117[149] = (char *(*)()) F1452_14683;
	R10117[151] = (char *(*)()) F1454_14766;
}

char *(*R10118[152])();
void R10118_init () {
	R10118[0] = (char *(*)()) F1300_12382;
	R10118[40] = (char *(*)()) F1300_12382;
	{long i; for (i = 45; i < 47; i++) R10118[i] = (char *(*)()) F1300_12382;}
	{long i; for (i = 63; i < 65; i++) R10118[i] = (char *(*)()) F1300_12382;}
	{long i; for (i = 69; i < 71; i++) R10118[i] = (char *(*)()) F1300_12382;}
	R10118[72] = (char *(*)()) F1300_12382;
	R10118[77] = (char *(*)()) F1300_12382;
	{long i; for (i = 79; i < 81; i++) R10118[i] = (char *(*)()) F1300_12382;}
	{long i; for (i = 103; i < 105; i++) R10118[i] = (char *(*)()) F1300_12382;}
	{long i; for (i = 106; i < 108; i++) R10118[i] = (char *(*)()) F1300_12382;}
	{long i; for (i = 111; i < 114; i++) R10118[i] = (char *(*)()) F1300_12382;}
	R10118[116] = (char *(*)()) F1300_12382;
	R10118[126] = (char *(*)()) F1300_12382;
	R10118[132] = (char *(*)()) F1300_12382;
	R10118[136] = (char *(*)()) F1300_12382;
	R10118[149] = (char *(*)()) F1452_14696;
	R10118[151] = (char *(*)()) F1454_14750;
}

char *(*R10120[152])();
void R10120_init () {
	R10120[0] = (char *(*)()) F1300_12384;
	R10120[40] = (char *(*)()) F1300_12384;
	{long i; for (i = 45; i < 47; i++) R10120[i] = (char *(*)()) F1300_12384;}
	{long i; for (i = 63; i < 65; i++) R10120[i] = (char *(*)()) F1300_12384;}
	{long i; for (i = 69; i < 71; i++) R10120[i] = (char *(*)()) F1300_12384;}
	R10120[72] = (char *(*)()) F1300_12384;
	R10120[77] = (char *(*)()) F1300_12384;
	{long i; for (i = 79; i < 81; i++) R10120[i] = (char *(*)()) F1300_12384;}
	{long i; for (i = 103; i < 105; i++) R10120[i] = (char *(*)()) F1300_12384;}
	{long i; for (i = 106; i < 108; i++) R10120[i] = (char *(*)()) F1300_12384;}
	{long i; for (i = 111; i < 114; i++) R10120[i] = (char *(*)()) F1300_12384;}
	R10120[116] = (char *(*)()) F1300_12384;
	R10120[126] = (char *(*)()) F1300_12384;
	R10120[132] = (char *(*)()) F1300_12384;
	R10120[136] = (char *(*)()) F1300_12384;
	R10120[149] = (char *(*)()) F1452_14697;
	R10120[151] = (char *(*)()) F1300_12384;
}

char *(*R10123[152])();
void R10123_init () {
	R10123[0] = (char *(*)()) F1300_12387;
	R10123[40] = (char *(*)()) F1300_12387;
	{long i; for (i = 45; i < 47; i++) R10123[i] = (char *(*)()) F1300_12387;}
	{long i; for (i = 63; i < 65; i++) R10123[i] = (char *(*)()) F1300_12387;}
	{long i; for (i = 69; i < 71; i++) R10123[i] = (char *(*)()) F1300_12387;}
	R10123[72] = (char *(*)()) F1300_12387;
	R10123[77] = (char *(*)()) F1300_12387;
	{long i; for (i = 79; i < 81; i++) R10123[i] = (char *(*)()) F1300_12387;}
	{long i; for (i = 103; i < 105; i++) R10123[i] = (char *(*)()) F1300_12387;}
	{long i; for (i = 106; i < 108; i++) R10123[i] = (char *(*)()) F1300_12387;}
	{long i; for (i = 111; i < 114; i++) R10123[i] = (char *(*)()) F1300_12387;}
	R10123[116] = (char *(*)()) F1300_12387;
	R10123[126] = (char *(*)()) F1300_12387;
	R10123[132] = (char *(*)()) F1300_12387;
	R10123[136] = (char *(*)()) F1300_12387;
	R10123[149] = (char *(*)()) F1452_14698;
	R10123[151] = (char *(*)()) F1300_12387;
}

char *(*R10125[152])();
void R10125_init () {
	R10125[0] = (char *(*)()) F1300_12389;
	R10125[40] = (char *(*)()) F1300_12389;
	{long i; for (i = 45; i < 47; i++) R10125[i] = (char *(*)()) F1300_12389;}
	{long i; for (i = 63; i < 65; i++) R10125[i] = (char *(*)()) F1300_12389;}
	{long i; for (i = 69; i < 71; i++) R10125[i] = (char *(*)()) F1300_12389;}
	R10125[72] = (char *(*)()) F1300_12389;
	R10125[77] = (char *(*)()) F1300_12389;
	{long i; for (i = 79; i < 81; i++) R10125[i] = (char *(*)()) F1300_12389;}
	{long i; for (i = 103; i < 105; i++) R10125[i] = (char *(*)()) F1300_12389;}
	{long i; for (i = 106; i < 108; i++) R10125[i] = (char *(*)()) F1300_12389;}
	{long i; for (i = 111; i < 114; i++) R10125[i] = (char *(*)()) F1300_12389;}
	R10125[116] = (char *(*)()) F1300_12389;
	R10125[126] = (char *(*)()) F1300_12389;
	R10125[132] = (char *(*)()) F1300_12389;
	R10125[136] = (char *(*)()) F1300_12389;
	R10125[149] = (char *(*)()) F1452_14699;
	R10125[151] = (char *(*)()) F1300_12389;
}

char *(*R10126[152])();
void R10126_init () {
	R10126[0] = (char *(*)()) F1300_12390;
	R10126[40] = (char *(*)()) F1300_12390;
	{long i; for (i = 45; i < 47; i++) R10126[i] = (char *(*)()) F1300_12390;}
	{long i; for (i = 63; i < 65; i++) R10126[i] = (char *(*)()) F1300_12390;}
	{long i; for (i = 69; i < 71; i++) R10126[i] = (char *(*)()) F1300_12390;}
	R10126[72] = (char *(*)()) F1374_13296;
	R10126[77] = (char *(*)()) F1300_12390;
	{long i; for (i = 79; i < 81; i++) R10126[i] = (char *(*)()) F1300_12390;}
	{long i; for (i = 103; i < 105; i++) R10126[i] = (char *(*)()) F1300_12390;}
	R10126[106] = (char *(*)()) F1409_13951;
	R10126[107] = (char *(*)()) F1410_13991;
	{long i; for (i = 111; i < 113; i++) R10126[i] = (char *(*)()) F1414_14144;}
	R10126[113] = (char *(*)()) F1300_12390;
	R10126[116] = (char *(*)()) F1300_12390;
	R10126[126] = (char *(*)()) F1300_12390;
	R10126[132] = (char *(*)()) F1300_12390;
	R10126[136] = (char *(*)()) F1300_12390;
	R10126[149] = (char *(*)()) F1300_12390;
	R10126[151] = (char *(*)()) F1300_12390;
}

char *(*R10136[152])();
void R10136_init () {
	R10136[0] = (char *(*)()) F1301_12401;
	R10136[40] = (char *(*)()) F1301_12401;
	{long i; for (i = 45; i < 47; i++) R10136[i] = (char *(*)()) F1301_12401;}
	{long i; for (i = 63; i < 65; i++) R10136[i] = (char *(*)()) F1353_13031;}
	{long i; for (i = 69; i < 71; i++) R10136[i] = (char *(*)()) F1353_13031;}
	R10136[72] = (char *(*)()) F1353_13031;
	R10136[77] = (char *(*)()) F1301_12401;
	{long i; for (i = 79; i < 81; i++) R10136[i] = (char *(*)()) F1301_12401;}
	{long i; for (i = 103; i < 105; i++) R10136[i] = (char *(*)()) F1353_13031;}
	{long i; for (i = 106; i < 108; i++) R10136[i] = (char *(*)()) F1353_13031;}
	{long i; for (i = 111; i < 114; i++) R10136[i] = (char *(*)()) F1353_13031;}
	R10136[116] = (char *(*)()) F1353_13031;
	R10136[126] = (char *(*)()) F1301_12401;
	R10136[132] = (char *(*)()) F1301_12401;
	R10136[136] = (char *(*)()) F1301_12401;
	R10136[149] = (char *(*)()) F1353_13031;
	R10136[151] = (char *(*)()) F1353_13031;
}

char *(*R10137[152])();
void R10137_init () {
	R10137[0] = (char *(*)()) F1301_12402;
	R10137[40] = (char *(*)()) F1301_12402;
	{long i; for (i = 45; i < 47; i++) R10137[i] = (char *(*)()) F1301_12402;}
	{long i; for (i = 63; i < 65; i++) R10137[i] = (char *(*)()) F1353_13032;}
	{long i; for (i = 69; i < 71; i++) R10137[i] = (char *(*)()) F1353_13032;}
	R10137[72] = (char *(*)()) F1353_13032;
	R10137[77] = (char *(*)()) F1301_12402;
	{long i; for (i = 79; i < 81; i++) R10137[i] = (char *(*)()) F1301_12402;}
	{long i; for (i = 103; i < 105; i++) R10137[i] = (char *(*)()) F1353_13032;}
	{long i; for (i = 106; i < 108; i++) R10137[i] = (char *(*)()) F1353_13032;}
	{long i; for (i = 111; i < 114; i++) R10137[i] = (char *(*)()) F1353_13032;}
	R10137[116] = (char *(*)()) F1353_13032;
	R10137[126] = (char *(*)()) F1301_12402;
	R10137[132] = (char *(*)()) F1301_12402;
	R10137[136] = (char *(*)()) F1301_12402;
	R10137[149] = (char *(*)()) F1353_13032;
	R10137[151] = (char *(*)()) F1353_13032;
}

char *(*R10145[152])();
void R10145_init () {
	R10145[0] = (char *(*)()) F1301_12410;
	R10145[40] = (char *(*)()) F1301_12410;
	{long i; for (i = 45; i < 47; i++) R10145[i] = (char *(*)()) F1301_12410;}
	{long i; for (i = 63; i < 65; i++) R10145[i] = (char *(*)()) F1301_12410;}
	{long i; for (i = 69; i < 71; i++) R10145[i] = (char *(*)()) F1301_12410;}
	R10145[72] = (char *(*)()) F1301_12410;
	R10145[77] = (char *(*)()) F1301_12410;
	{long i; for (i = 79; i < 81; i++) R10145[i] = (char *(*)()) F1301_12410;}
	{long i; for (i = 103; i < 105; i++) R10145[i] = (char *(*)()) F1301_12410;}
	{long i; for (i = 106; i < 108; i++) R10145[i] = (char *(*)()) F1301_12410;}
	{long i; for (i = 111; i < 113; i++) R10145[i] = (char *(*)()) F1301_12410;}
	R10145[113] = (char *(*)()) F1416_14165;
	R10145[116] = (char *(*)()) F1416_14165;
	R10145[126] = (char *(*)()) F1301_12410;
	R10145[132] = (char *(*)()) F1301_12410;
	R10145[136] = (char *(*)()) F1301_12410;
	R10145[149] = (char *(*)()) F1301_12410;
	R10145[151] = (char *(*)()) F1301_12410;
}

char *(*R10151[152])();
void R10151_init () {
	R10151[0] = (char *(*)()) F1301_12416;
	R10151[40] = (char *(*)()) F1301_12416;
	{long i; for (i = 45; i < 47; i++) R10151[i] = (char *(*)()) F1301_12416;}
	{long i; for (i = 63; i < 65; i++) R10151[i] = (char *(*)()) F1301_12416;}
	{long i; for (i = 69; i < 71; i++) R10151[i] = (char *(*)()) F1301_12416;}
	R10151[72] = (char *(*)()) F1301_12416;
	R10151[77] = (char *(*)()) F1301_12416;
	{long i; for (i = 79; i < 81; i++) R10151[i] = (char *(*)()) F1301_12416;}
	{long i; for (i = 103; i < 105; i++) R10151[i] = (char *(*)()) F1301_12416;}
	{long i; for (i = 106; i < 108; i++) R10151[i] = (char *(*)()) F1301_12416;}
	{long i; for (i = 111; i < 114; i++) R10151[i] = (char *(*)()) F1301_12416;}
	R10151[116] = (char *(*)()) F1301_12416;
	R10151[126] = (char *(*)()) F1301_12416;
	R10151[132] = (char *(*)()) F1301_12416;
	R10151[136] = (char *(*)()) F1301_12416;
	R10151[149] = (char *(*)()) F1452_14708;
	R10151[151] = (char *(*)()) F1301_12416;
}

char *(*R10152[152])();
void R10152_init () {
	R10152[0] = (char *(*)()) F1301_12417;
	R10152[40] = (char *(*)()) F1301_12417;
	{long i; for (i = 45; i < 47; i++) R10152[i] = (char *(*)()) F1301_12417;}
	{long i; for (i = 63; i < 65; i++) R10152[i] = (char *(*)()) F1301_12417;}
	{long i; for (i = 69; i < 71; i++) R10152[i] = (char *(*)()) F1301_12417;}
	R10152[72] = (char *(*)()) F1301_12417;
	R10152[77] = (char *(*)()) F1380_13414;
	{long i; for (i = 79; i < 81; i++) R10152[i] = (char *(*)()) F1380_13414;}
	{long i; for (i = 103; i < 105; i++) R10152[i] = (char *(*)()) F1301_12417;}
	{long i; for (i = 106; i < 108; i++) R10152[i] = (char *(*)()) F1301_12417;}
	{long i; for (i = 111; i < 114; i++) R10152[i] = (char *(*)()) F1301_12417;}
	R10152[116] = (char *(*)()) F1301_12417;
	R10152[126] = (char *(*)()) F1301_12417;
	R10152[132] = (char *(*)()) F1301_12417;
	R10152[136] = (char *(*)()) F1301_12417;
	R10152[149] = (char *(*)()) F1301_12417;
	R10152[151] = (char *(*)()) F1301_12417;
}

char *(*R10156[152])();
void R10156_init () {
	R10156[0] = (char *(*)()) F1302_12451;
	R10156[40] = (char *(*)()) F1302_12451;
	{long i; for (i = 45; i < 47; i++) R10156[i] = (char *(*)()) F1302_12451;}
	{long i; for (i = 63; i < 65; i++) R10156[i] = (char *(*)()) F1301_12421;}
	{long i; for (i = 69; i < 71; i++) R10156[i] = (char *(*)()) F1301_12421;}
	R10156[72] = (char *(*)()) F1301_12421;
	R10156[77] = (char *(*)()) F1380_13427;
	{long i; for (i = 79; i < 81; i++) R10156[i] = (char *(*)()) F1380_13427;}
	{long i; for (i = 103; i < 105; i++) R10156[i] = (char *(*)()) F1301_12421;}
	{long i; for (i = 106; i < 108; i++) R10156[i] = (char *(*)()) F1301_12421;}
	{long i; for (i = 111; i < 114; i++) R10156[i] = (char *(*)()) F1301_12421;}
	R10156[116] = (char *(*)()) F1301_12421;
	R10156[126] = (char *(*)()) F1301_12421;
	R10156[132] = (char *(*)()) F1301_12421;
	R10156[149] = (char *(*)()) F1301_12421;
	R10156[151] = (char *(*)()) F1301_12421;
}

char *(*R10158[152])();
void R10158_init () {
	R10158[0] = (char *(*)()) F1301_12423;
	R10158[40] = (char *(*)()) F1301_12423;
	{long i; for (i = 45; i < 47; i++) R10158[i] = (char *(*)()) F1301_12423;}
	{long i; for (i = 63; i < 65; i++) R10158[i] = (char *(*)()) F1301_12423;}
	{long i; for (i = 69; i < 71; i++) R10158[i] = (char *(*)()) F1301_12423;}
	R10158[72] = (char *(*)()) F1301_12423;
	R10158[77] = (char *(*)()) F1301_12423;
	{long i; for (i = 79; i < 81; i++) R10158[i] = (char *(*)()) F1382_13502;}
	{long i; for (i = 103; i < 105; i++) R10158[i] = (char *(*)()) F1301_12423;}
	{long i; for (i = 106; i < 108; i++) R10158[i] = (char *(*)()) F1301_12423;}
	{long i; for (i = 111; i < 114; i++) R10158[i] = (char *(*)()) F1301_12423;}
	R10158[116] = (char *(*)()) F1301_12423;
	R10158[126] = (char *(*)()) F1301_12423;
	R10158[132] = (char *(*)()) F1301_12423;
	R10158[136] = (char *(*)()) F1301_12423;
	R10158[149] = (char *(*)()) F1301_12423;
	R10158[151] = (char *(*)()) F1301_12423;
}

char *(*R10168[81])();
void R10168_init () {
	R10168[0] = (char *(*)()) F1302_12433;
	R10168[40] = (char *(*)()) F1302_12433;
	{long i; for (i = 45; i < 47; i++) R10168[i] = (char *(*)()) F1302_12433;}
	R10168[77] = (char *(*)()) F1302_12433;
	R10168[79] = (char *(*)()) F1302_12433;
	R10168[80] = (char *(*)()) F1383_13520;
}


#ifdef __cplusplus
}
#endif
