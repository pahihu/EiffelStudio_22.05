#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O3354[1222];
void O3354_init () {
	O3354[0] =  + _REFACS_1_;
	{long i; for (i = 1214; i < 1216; i++) O3354[i] =  + _REFACS_5_;}
	{long i; for (i = 1216; i < 1218; i++) O3354[i] =  + _REFACS_8_;}
	{long i; for (i = 1218; i < 1220; i++) O3354[i] =  + _REFACS_5_;}
	{long i; for (i = 1220; i < 1222; i++) O3354[i] =  + _REFACS_8_;}
}

long O3356[1222];
void O3356_init () {
	O3356[0] =  + _REFACS_2_;
	{long i; for (i = 1214; i < 1216; i++) O3356[i] =  + _REFACS_6_;}
	{long i; for (i = 1216; i < 1218; i++) O3356[i] =  + _REFACS_9_;}
	{long i; for (i = 1218; i < 1220; i++) O3356[i] =  + _REFACS_6_;}
	{long i; for (i = 1220; i < 1222; i++) O3356[i] =  + _REFACS_9_;}
}

long O3358[1222];
void O3358_init () {
	O3358[0] =  + _REFACS_3_;
	{long i; for (i = 1214; i < 1216; i++) O3358[i] =  + _REFACS_7_;}
	{long i; for (i = 1216; i < 1218; i++) O3358[i] =  + _REFACS_10_;}
	{long i; for (i = 1218; i < 1220; i++) O3358[i] =  + _REFACS_7_;}
	{long i; for (i = 1220; i < 1222; i++) O3358[i] =  + _REFACS_10_;}
}

long O3362[1291];
void O3362_init () {
	O3362[0] = 0;
	{long i; for (i = 1186; i < 1188; i++) O3362[i] = 0;}
	{long i; for (i = 1188; i < 1190; i++) O3362[i] =  + _REFACS_2_;}
	{long i; for (i = 1190; i < 1193; i++) O3362[i] =  + _REFACS_3_;}
	O3362[1193] =  + _REFACS_4_;
	{long i; for (i = 1194; i < 1196; i++) O3362[i] =  + _REFACS_3_;}
	O3362[1196] =  + _REFACS_4_;
	O3362[1197] =  + _REFACS_3_;
	{long i; for (i = 1198; i < 1212; i++) O3362[i] =  + _REFACS_4_;}
	{long i; for (i = 1212; i < 1214; i++) O3362[i] =  + _REFACS_8_;}
	{long i; for (i = 1214; i < 1216; i++) O3362[i] =  + _REFACS_11_;}
	{long i; for (i = 1216; i < 1218; i++) O3362[i] =  + _REFACS_8_;}
	{long i; for (i = 1218; i < 1220; i++) O3362[i] =  + _REFACS_11_;}
	O3362[1220] =  + _REFACS_2_;
	O3362[1221] =  + _REFACS_3_;
	O3362[1222] =  + _REFACS_4_;
	O3362[1223] =  + _REFACS_6_;
	O3362[1224] =  + _REFACS_3_;
	O3362[1225] =  + _REFACS_2_;
	O3362[1226] =  + _REFACS_3_;
	O3362[1227] =  + _REFACS_4_;
	O3362[1228] =  + _REFACS_3_;
	O3362[1229] =  + _REFACS_6_;
	{long i; for (i = 1230; i < 1234; i++) O3362[i] =  + _REFACS_3_;}
	O3362[1234] =  + _REFACS_4_;
	O3362[1235] =  + _REFACS_8_;
	O3362[1236] =  + _REFACS_4_;
	O3362[1237] =  + _REFACS_6_;
	O3362[1238] =  + _REFACS_2_;
	O3362[1239] =  + _REFACS_3_;
	O3362[1240] =  + _REFACS_4_;
	O3362[1241] =  + _REFACS_6_;
	O3362[1242] =  + _REFACS_3_;
	O3362[1243] =  + _REFACS_2_;
	O3362[1244] =  + _REFACS_3_;
	O3362[1245] =  + _REFACS_4_;
	O3362[1246] =  + _REFACS_3_;
	O3362[1247] =  + _REFACS_6_;
	O3362[1248] =  + _REFACS_4_;
	O3362[1249] =  + _REFACS_8_;
	O3362[1250] =  + _REFACS_4_;
	O3362[1251] =  + _REFACS_6_;
	{long i; for (i = 1252; i < 1258; i++) O3362[i] =  + _REFACS_3_;}
	{long i; for (i = 1258; i < 1260; i++) O3362[i] =  + _REFACS_5_;}
	{long i; for (i = 1260; i < 1264; i++) O3362[i] =  + _REFACS_7_;}
	{long i; for (i = 1264; i < 1266; i++) O3362[i] =  + _REFACS_3_;}
	{long i; for (i = 1266; i < 1270; i++) O3362[i] =  + _REFACS_4_;}
	O3362[1270] =  + _REFACS_5_;
	{long i; for (i = 1271; i < 1275; i++) O3362[i] =  + _REFACS_4_;}
	{long i; for (i = 1275; i < 1278; i++) O3362[i] =  + _REFACS_5_;}
	{long i; for (i = 1278; i < 1282; i++) O3362[i] =  + _REFACS_7_;}
	O3362[1283] =  + _REFACS_2_;
	O3362[1285] =  + _REFACS_2_;
	O3362[1288] =  + _REFACS_2_;
	O3362[1290] =  + _REFACS_2_;
}

long O3364[1291];
void O3364_init () {
	O3364[0] =  + _REFACS_1_;
	{long i; for (i = 1186; i < 1188; i++) O3364[i] =  + _REFACS_1_;}
	{long i; for (i = 1188; i < 1190; i++) O3364[i] =  + _REFACS_3_;}
	{long i; for (i = 1190; i < 1193; i++) O3364[i] =  + _REFACS_4_;}
	O3364[1193] =  + _REFACS_5_;
	{long i; for (i = 1194; i < 1196; i++) O3364[i] =  + _REFACS_4_;}
	O3364[1196] =  + _REFACS_5_;
	O3364[1197] =  + _REFACS_4_;
	{long i; for (i = 1198; i < 1212; i++) O3364[i] =  + _REFACS_5_;}
	{long i; for (i = 1212; i < 1214; i++) O3364[i] =  + _REFACS_9_;}
	{long i; for (i = 1214; i < 1216; i++) O3364[i] =  + _REFACS_12_;}
	{long i; for (i = 1216; i < 1218; i++) O3364[i] =  + _REFACS_9_;}
	{long i; for (i = 1218; i < 1220; i++) O3364[i] =  + _REFACS_12_;}
	O3364[1220] =  + _REFACS_3_;
	O3364[1221] =  + _REFACS_4_;
	O3364[1222] =  + _REFACS_5_;
	O3364[1223] =  + _REFACS_7_;
	O3364[1224] =  + _REFACS_4_;
	O3364[1225] =  + _REFACS_3_;
	O3364[1226] =  + _REFACS_4_;
	O3364[1227] =  + _REFACS_5_;
	O3364[1228] =  + _REFACS_4_;
	O3364[1229] =  + _REFACS_7_;
	{long i; for (i = 1230; i < 1234; i++) O3364[i] =  + _REFACS_4_;}
	O3364[1234] =  + _REFACS_5_;
	O3364[1235] =  + _REFACS_9_;
	O3364[1236] =  + _REFACS_5_;
	O3364[1237] =  + _REFACS_7_;
	O3364[1238] =  + _REFACS_3_;
	O3364[1239] =  + _REFACS_4_;
	O3364[1240] =  + _REFACS_5_;
	O3364[1241] =  + _REFACS_7_;
	O3364[1242] =  + _REFACS_4_;
	O3364[1243] =  + _REFACS_3_;
	O3364[1244] =  + _REFACS_4_;
	O3364[1245] =  + _REFACS_5_;
	O3364[1246] =  + _REFACS_4_;
	O3364[1247] =  + _REFACS_7_;
	O3364[1248] =  + _REFACS_5_;
	O3364[1249] =  + _REFACS_9_;
	O3364[1250] =  + _REFACS_5_;
	O3364[1251] =  + _REFACS_7_;
	{long i; for (i = 1252; i < 1258; i++) O3364[i] =  + _REFACS_4_;}
	{long i; for (i = 1258; i < 1260; i++) O3364[i] =  + _REFACS_6_;}
	{long i; for (i = 1260; i < 1264; i++) O3364[i] =  + _REFACS_8_;}
	{long i; for (i = 1264; i < 1266; i++) O3364[i] =  + _REFACS_4_;}
	{long i; for (i = 1266; i < 1270; i++) O3364[i] =  + _REFACS_5_;}
	O3364[1270] =  + _REFACS_6_;
	{long i; for (i = 1271; i < 1275; i++) O3364[i] =  + _REFACS_5_;}
	{long i; for (i = 1275; i < 1278; i++) O3364[i] =  + _REFACS_6_;}
	{long i; for (i = 1278; i < 1282; i++) O3364[i] =  + _REFACS_8_;}
	O3364[1283] =  + _REFACS_3_;
	O3364[1285] =  + _REFACS_3_;
	O3364[1288] =  + _REFACS_3_;
	O3364[1290] =  + _REFACS_3_;
}

long O3368[1291];
void O3368_init () {
	O3368[0] =  + _REFACS_3_;
	{long i; for (i = 1186; i < 1188; i++) O3368[i] =  + _REFACS_3_;}
	{long i; for (i = 1188; i < 1190; i++) O3368[i] =  + _REFACS_5_;}
	{long i; for (i = 1190; i < 1193; i++) O3368[i] =  + _REFACS_6_;}
	O3368[1193] =  + _REFACS_7_;
	{long i; for (i = 1194; i < 1196; i++) O3368[i] =  + _REFACS_6_;}
	O3368[1196] =  + _REFACS_7_;
	O3368[1197] =  + _REFACS_6_;
	{long i; for (i = 1198; i < 1212; i++) O3368[i] =  + _REFACS_7_;}
	{long i; for (i = 1212; i < 1214; i++) O3368[i] =  + _REFACS_11_;}
	{long i; for (i = 1214; i < 1216; i++) O3368[i] =  + _REFACS_14_;}
	{long i; for (i = 1216; i < 1218; i++) O3368[i] =  + _REFACS_11_;}
	{long i; for (i = 1218; i < 1220; i++) O3368[i] =  + _REFACS_14_;}
	O3368[1220] =  + _REFACS_5_;
	O3368[1221] =  + _REFACS_6_;
	O3368[1222] =  + _REFACS_7_;
	O3368[1223] =  + _REFACS_9_;
	O3368[1224] =  + _REFACS_6_;
	O3368[1225] =  + _REFACS_5_;
	O3368[1226] =  + _REFACS_6_;
	O3368[1227] =  + _REFACS_7_;
	O3368[1228] =  + _REFACS_6_;
	O3368[1229] =  + _REFACS_9_;
	{long i; for (i = 1230; i < 1234; i++) O3368[i] =  + _REFACS_6_;}
	O3368[1234] =  + _REFACS_7_;
	O3368[1235] =  + _REFACS_11_;
	O3368[1236] =  + _REFACS_7_;
	O3368[1237] =  + _REFACS_9_;
	O3368[1238] =  + _REFACS_5_;
	O3368[1239] =  + _REFACS_6_;
	O3368[1240] =  + _REFACS_7_;
	O3368[1241] =  + _REFACS_9_;
	O3368[1242] =  + _REFACS_6_;
	O3368[1243] =  + _REFACS_5_;
	O3368[1244] =  + _REFACS_6_;
	O3368[1245] =  + _REFACS_7_;
	O3368[1246] =  + _REFACS_6_;
	O3368[1247] =  + _REFACS_9_;
	O3368[1248] =  + _REFACS_7_;
	O3368[1249] =  + _REFACS_11_;
	O3368[1250] =  + _REFACS_7_;
	O3368[1251] =  + _REFACS_9_;
	{long i; for (i = 1252; i < 1258; i++) O3368[i] =  + _REFACS_6_;}
	{long i; for (i = 1258; i < 1260; i++) O3368[i] =  + _REFACS_8_;}
	{long i; for (i = 1260; i < 1264; i++) O3368[i] =  + _REFACS_10_;}
	{long i; for (i = 1264; i < 1266; i++) O3368[i] =  + _REFACS_6_;}
	{long i; for (i = 1266; i < 1270; i++) O3368[i] =  + _REFACS_7_;}
	O3368[1270] =  + _REFACS_8_;
	{long i; for (i = 1271; i < 1275; i++) O3368[i] =  + _REFACS_7_;}
	{long i; for (i = 1275; i < 1278; i++) O3368[i] =  + _REFACS_8_;}
	{long i; for (i = 1278; i < 1282; i++) O3368[i] =  + _REFACS_10_;}
	O3368[1283] =  + _REFACS_5_;
	O3368[1285] =  + _REFACS_5_;
	O3368[1288] =  + _REFACS_5_;
	O3368[1290] =  + _REFACS_5_;
}

long O3850[1257];
void O3850_init () {
	O3850[0] = 0;
	{long i; for (i = 1154; i < 1156; i++) O3850[i] =  + _REFACS_6_;}
	{long i; for (i = 1156; i < 1159; i++) O3850[i] =  + _REFACS_7_;}
	O3850[1159] =  + _REFACS_8_;
	{long i; for (i = 1160; i < 1162; i++) O3850[i] =  + _REFACS_7_;}
	O3850[1162] =  + _REFACS_8_;
	O3850[1163] =  + _REFACS_7_;
	{long i; for (i = 1164; i < 1178; i++) O3850[i] =  + _REFACS_8_;}
	{long i; for (i = 1178; i < 1180; i++) O3850[i] =  + _REFACS_12_;}
	{long i; for (i = 1180; i < 1182; i++) O3850[i] =  + _REFACS_15_;}
	{long i; for (i = 1182; i < 1184; i++) O3850[i] =  + _REFACS_12_;}
	{long i; for (i = 1184; i < 1186; i++) O3850[i] =  + _REFACS_15_;}
	O3850[1186] =  + _REFACS_6_;
	O3850[1187] =  + _REFACS_7_;
	O3850[1188] =  + _REFACS_8_;
	O3850[1189] =  + _REFACS_10_;
	O3850[1190] =  + _REFACS_7_;
	O3850[1191] =  + _REFACS_6_;
	O3850[1192] =  + _REFACS_7_;
	O3850[1193] =  + _REFACS_8_;
	O3850[1194] =  + _REFACS_7_;
	O3850[1195] =  + _REFACS_10_;
	{long i; for (i = 1196; i < 1200; i++) O3850[i] =  + _REFACS_7_;}
	O3850[1200] =  + _REFACS_8_;
	O3850[1201] =  + _REFACS_12_;
	O3850[1202] =  + _REFACS_8_;
	O3850[1203] =  + _REFACS_10_;
	O3850[1204] =  + _REFACS_6_;
	O3850[1205] =  + _REFACS_7_;
	O3850[1206] =  + _REFACS_8_;
	O3850[1207] =  + _REFACS_10_;
	O3850[1208] =  + _REFACS_7_;
	O3850[1209] =  + _REFACS_6_;
	O3850[1210] =  + _REFACS_7_;
	O3850[1211] =  + _REFACS_8_;
	O3850[1212] =  + _REFACS_7_;
	O3850[1213] =  + _REFACS_10_;
	O3850[1214] =  + _REFACS_8_;
	O3850[1215] =  + _REFACS_12_;
	O3850[1216] =  + _REFACS_8_;
	O3850[1217] =  + _REFACS_10_;
	{long i; for (i = 1218; i < 1222; i++) O3850[i] =  + _REFACS_7_;}
	O3850[1249] =  + _REFACS_7_;
	O3850[1251] =  + _REFACS_7_;
	O3850[1254] =  + _REFACS_7_;
	O3850[1256] =  + _REFACS_7_;
}

long O3853[1257];
void O3853_init () {
	O3853[0] =  + _REFACS_1_;
	{long i; for (i = 1154; i < 1156; i++) O3853[i] =  + _REFACS_7_;}
	{long i; for (i = 1156; i < 1159; i++) O3853[i] =  + _REFACS_8_;}
	O3853[1159] =  + _REFACS_9_;
	{long i; for (i = 1160; i < 1162; i++) O3853[i] =  + _REFACS_8_;}
	O3853[1162] =  + _REFACS_9_;
	O3853[1163] =  + _REFACS_8_;
	{long i; for (i = 1164; i < 1178; i++) O3853[i] =  + _REFACS_9_;}
	{long i; for (i = 1178; i < 1180; i++) O3853[i] =  + _REFACS_13_;}
	{long i; for (i = 1180; i < 1182; i++) O3853[i] =  + _REFACS_16_;}
	{long i; for (i = 1182; i < 1184; i++) O3853[i] =  + _REFACS_13_;}
	{long i; for (i = 1184; i < 1186; i++) O3853[i] =  + _REFACS_16_;}
	O3853[1186] =  + _REFACS_7_;
	O3853[1187] =  + _REFACS_8_;
	O3853[1188] =  + _REFACS_9_;
	O3853[1189] =  + _REFACS_11_;
	O3853[1190] =  + _REFACS_8_;
	O3853[1191] =  + _REFACS_7_;
	O3853[1192] =  + _REFACS_8_;
	O3853[1193] =  + _REFACS_9_;
	O3853[1194] =  + _REFACS_8_;
	O3853[1195] =  + _REFACS_11_;
	{long i; for (i = 1196; i < 1200; i++) O3853[i] =  + _REFACS_8_;}
	O3853[1200] =  + _REFACS_9_;
	O3853[1201] =  + _REFACS_13_;
	O3853[1202] =  + _REFACS_9_;
	O3853[1203] =  + _REFACS_11_;
	O3853[1204] =  + _REFACS_7_;
	O3853[1205] =  + _REFACS_8_;
	O3853[1206] =  + _REFACS_9_;
	O3853[1207] =  + _REFACS_11_;
	O3853[1208] =  + _REFACS_8_;
	O3853[1209] =  + _REFACS_7_;
	O3853[1210] =  + _REFACS_8_;
	O3853[1211] =  + _REFACS_9_;
	O3853[1212] =  + _REFACS_8_;
	O3853[1213] =  + _REFACS_11_;
	O3853[1214] =  + _REFACS_9_;
	O3853[1215] =  + _REFACS_13_;
	O3853[1216] =  + _REFACS_9_;
	O3853[1217] =  + _REFACS_11_;
	{long i; for (i = 1218; i < 1222; i++) O3853[i] =  + _REFACS_8_;}
	O3853[1249] =  + _REFACS_8_;
	O3853[1251] =  + _REFACS_8_;
	O3853[1254] =  + _REFACS_8_;
	O3853[1256] =  + _REFACS_8_;
}


#ifdef __cplusplus
}
#endif
