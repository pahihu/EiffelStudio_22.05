
#ifndef _C21_re1044_
#define _C21_re1044_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F624_6019(EIF_REFERENCE);
extern void EIF_Minit1044(void);
extern void F773_6394(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5864[])();
extern EIF_TYPE_INDEX Y5430[];
extern EIF_TYPE_INDEX *Y5430_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
