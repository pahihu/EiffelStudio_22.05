
#ifndef _C21_co1006_
#define _C21_co1006_

#ifdef __cplusplus
extern "C" {
#endif

extern void F457_5908(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit1006(void);
extern char *(*R5615[])();
extern char *(*R5481[])();

#ifdef __cplusplus
}
#endif

#endif
