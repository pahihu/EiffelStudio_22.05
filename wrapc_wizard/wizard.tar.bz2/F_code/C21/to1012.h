
#ifndef _C21_to1012_
#define _C21_to1012_

#ifdef __cplusplus
extern "C" {
#endif

extern void F343_5156(EIF_REFERENCE, EIF_INTEGER_32);
extern void F343_5157(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern void F343_5163(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1012(void);
extern void F920_7187(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4990[];
extern EIF_TYPE_INDEX *Y4990_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
