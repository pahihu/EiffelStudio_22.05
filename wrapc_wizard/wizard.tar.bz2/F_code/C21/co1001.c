/*
 * Code for class CONTAINER [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1001.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F406_5728 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O5484[Dtype(Current)-402]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {CONTAINER}.compare_references */
void F406_5729 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O5484[Dtype(Current)-402]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

void EIF_Minit1001 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
