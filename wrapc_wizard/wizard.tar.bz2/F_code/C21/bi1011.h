
#ifndef _C21_bi1011_
#define _C21_bi1011_

#ifdef __cplusplus
extern "C" {
#endif

extern void F445_5900(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit1011(void);
extern EIF_BOOLEAN F553_5957(EIF_REFERENCE);
extern void F433_5883(EIF_REFERENCE, EIF_NATURAL_64);
extern void F853_6674(EIF_REFERENCE);
extern EIF_BOOLEAN F672_6112(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
