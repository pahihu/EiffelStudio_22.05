
#ifndef _C21_dy1020_
#define _C21_dy1020_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F500_5923(EIF_REFERENCE);
extern void EIF_Minit1020(void);

#ifdef __cplusplus
}
#endif

#endif
