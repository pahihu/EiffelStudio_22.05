
#ifndef _C21_fi1048_
#define _C21_fi1048_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F555_5957(EIF_REFERENCE);
extern void EIF_Minit1048(void);
extern char *(*R5639[])();

#ifdef __cplusplus
}
#endif

#endif
