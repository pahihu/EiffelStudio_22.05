
#ifndef _C21_co1036_
#define _C21_co1036_

#ifdef __cplusplus
extern "C" {
#endif

extern void F458_5908(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit1036(void);
extern char *(*R5615[])();
extern char *(*R5481[])();

#ifdef __cplusplus
}
#endif

#endif
