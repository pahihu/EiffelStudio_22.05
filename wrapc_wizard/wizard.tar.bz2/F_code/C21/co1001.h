
#ifndef _C21_co1001_
#define _C21_co1001_

#ifdef __cplusplus
extern "C" {
#endif

extern void F406_5728(EIF_REFERENCE);
extern void F406_5729(EIF_REFERENCE);
extern void EIF_Minit1001(void);
extern long O5484[];

#ifdef __cplusplus
}
#endif

#endif
