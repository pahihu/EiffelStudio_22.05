
#ifndef _C21_fi1032_
#define _C21_fi1032_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F554_5957(EIF_REFERENCE);
extern void EIF_Minit1032(void);
extern char *(*R5639[])();

#ifdef __cplusplus
}
#endif

#endif
