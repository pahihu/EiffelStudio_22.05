
#ifndef _C21_ar1009_
#define _C21_ar1009_

#ifdef __cplusplus
extern "C" {
#endif

extern void F804_6448(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F804_6449(EIF_REFERENCE);
extern EIF_REFERENCE F804_6450(EIF_REFERENCE);
extern EIF_REFERENCE F804_6452(EIF_REFERENCE);
extern EIF_INTEGER_32 F804_6453(EIF_REFERENCE);
extern void EIF_Minit1009(void);
extern EIF_INTEGER_32 F853_6664(EIF_REFERENCE);
extern EIF_REFERENCE F853_6645(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5792[];
extern EIF_TYPE_INDEX *Y5792_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
