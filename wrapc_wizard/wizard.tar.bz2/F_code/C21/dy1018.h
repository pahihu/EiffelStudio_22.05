
#ifndef _C21_dy1018_
#define _C21_dy1018_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F660_6096(EIF_REFERENCE);
extern void F660_6102(EIF_REFERENCE, EIF_NATURAL_64);
extern void F660_6103(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit1018(void);
extern EIF_BOOLEAN F433_5887(EIF_REFERENCE);
extern void F853_6695(EIF_REFERENCE);
extern void F853_6678(EIF_REFERENCE, EIF_NATURAL_64);
extern void F853_6672(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
