/*
 * Code for class DYNAMIC_CHAIN [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dy1018.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DYNAMIC_CHAIN}.extendible */
EIF_BOOLEAN F660_6096 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {DYNAMIC_CHAIN}.prune */
void F660_6102 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F853_6678(Current, arg1);
	if ((EIF_BOOLEAN) !F433_5887(Current)) {
		F853_6695(Current);
	}
	RTLE;
}

/* {DYNAMIC_CHAIN}.prune_all */
void F660_6103 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F853_6672(Current);
	F853_6678(Current, arg1);
	for (;;) {
		if (F433_5887(Current)) break;
		F853_6695(Current);
		F853_6678(Current, arg1);
	}
	RTLE;
}

void EIF_Minit1018 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
