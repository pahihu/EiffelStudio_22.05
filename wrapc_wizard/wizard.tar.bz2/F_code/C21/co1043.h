
#ifndef _C21_co1043_
#define _C21_co1043_

#ifdef __cplusplus
extern "C" {
#endif

extern void F408_5728(EIF_REFERENCE);
extern void F408_5729(EIF_REFERENCE);
extern void EIF_Minit1043(void);
extern long O5484[];

#ifdef __cplusplus
}
#endif

#endif
