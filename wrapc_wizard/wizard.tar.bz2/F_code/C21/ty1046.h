
#ifndef _C21_ty1046_
#define _C21_ty1046_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F761_6388(EIF_REFERENCE);
extern void EIF_Minit1046(void);
extern char *(*R5852[])();
extern char *(*R5662[])();
extern char *(*R5865[])();

#ifdef __cplusplus
}
#endif

#endif
