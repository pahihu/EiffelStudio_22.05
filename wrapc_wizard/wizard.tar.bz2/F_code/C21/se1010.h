
#ifndef _C21_se1010_
#define _C21_se1010_

#ifdef __cplusplus
extern "C" {
#endif

extern void F589_5970(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit1010(void);
extern void F853_6682(EIF_REFERENCE, EIF_NATURAL_64);

#ifdef __cplusplus
}
#endif

#endif
