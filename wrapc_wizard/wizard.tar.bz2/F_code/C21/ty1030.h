
#ifndef _C21_ty1030_
#define _C21_ty1030_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F760_6388(EIF_REFERENCE);
extern void EIF_Minit1030(void);
extern char *(*R5852[])();
extern char *(*R5662[])();
extern char *(*R5865[])();

#ifdef __cplusplus
}
#endif

#endif
