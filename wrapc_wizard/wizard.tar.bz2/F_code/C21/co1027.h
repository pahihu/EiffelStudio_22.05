
#ifndef _C21_co1027_
#define _C21_co1027_

#ifdef __cplusplus
extern "C" {
#endif

extern void F407_5728(EIF_REFERENCE);
extern void F407_5729(EIF_REFERENCE);
extern void EIF_Minit1027(void);
extern long O5484[];

#ifdef __cplusplus
}
#endif

#endif
