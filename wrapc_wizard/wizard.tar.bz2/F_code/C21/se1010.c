/*
 * Code for class SEQUENCE [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "se1010.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SEQUENCE}.force */
void F589_5970 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	
	
	F853_6682(Current, arg1);
}

void EIF_Minit1010 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
