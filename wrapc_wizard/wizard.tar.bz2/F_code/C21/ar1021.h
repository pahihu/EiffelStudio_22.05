
#ifndef _C21_ar1021_
#define _C21_ar1021_

#ifdef __cplusplus
extern "C" {
#endif

extern void F818_6466(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F818_6467(EIF_REFERENCE);
extern EIF_REFERENCE F818_6468(EIF_REFERENCE);
extern EIF_REFERENCE F818_6470(EIF_REFERENCE);
extern EIF_INTEGER_32 F818_6471(EIF_REFERENCE);
extern void EIF_Minit1021(void);
extern EIF_TYPE_INDEX Y5792[];
extern EIF_TYPE_INDEX *Y5792_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
