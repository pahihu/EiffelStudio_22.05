
#ifndef _C1_gt28_
#define _C1_gt28_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F28_739(EIF_REFERENCE);
extern EIF_NATURAL_8 F28_740(EIF_REFERENCE);
extern void EIF_Minit28(void);

#ifdef __cplusplus
}
#endif

#endif
