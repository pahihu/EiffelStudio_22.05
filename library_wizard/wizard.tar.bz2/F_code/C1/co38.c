/*
 * Code for class CODE_PAGE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co38.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CODE_PAGE_CONSTANTS}.utf7 */

EIF_REFERENCE F38_959 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (959,RTMS_EX_H("UTF-7",5,1414538039));
}

/* {CODE_PAGE_CONSTANTS}.utf8 */

EIF_REFERENCE F38_960 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (960,RTMS_EX_H("UTF-8",5,1414538040));
}

/* {CODE_PAGE_CONSTANTS}.utf16 */

EIF_REFERENCE F38_961 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (961,RTMS_EX_H("UTF-16",6,1345128758));
}

/* {CODE_PAGE_CONSTANTS}.utf32 */

EIF_REFERENCE F38_962 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (962,RTMS_EX_H("UTF-32",6,1345129266));
}

/* {CODE_PAGE_CONSTANTS}.utf16_le */

EIF_REFERENCE F38_963 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (963,RTMS_EX_H("UTF-16LE",8,312185413));
}

/* {CODE_PAGE_CONSTANTS}.utf32_le */

EIF_REFERENCE F38_964 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (964,RTMS_EX_H("UTF-32LE",8,345477701));
}

/* {CODE_PAGE_CONSTANTS}.utf16_be */

EIF_REFERENCE F38_965 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (965,RTMS_EX_H("UTF-16BE",8,312182853));
}

/* {CODE_PAGE_CONSTANTS}.utf32_be */

EIF_REFERENCE F38_966 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (966,RTMS_EX_H("UTF-32BE",8,345475141));
}

void EIF_Minit38 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
