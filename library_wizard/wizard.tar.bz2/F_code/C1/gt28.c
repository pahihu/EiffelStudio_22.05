/*
 * Code for class GTK_ORIENTATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt28.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F28_739
static EIF_NATURAL_8 inline_F28_739 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F28_739
#endif
#ifndef INLINE_F28_740
static EIF_NATURAL_8 inline_F28_740 (void)
{
	return GTK_ORIENTATION_VERTICAL
	;
}
#define INLINE_F28_740
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_ORIENTATION}.gtk_orientation_horizontal */
EIF_NATURAL_8 F28_739 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	
	
	Result = inline_F28_739 ();
	return Result;
}

/* {GTK_ORIENTATION}.gtk_orientation_vertical */
EIF_NATURAL_8 F28_740 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	
	
	Result = inline_F28_740 ();
	return Result;
}

void EIF_Minit28 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
