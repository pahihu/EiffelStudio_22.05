/*
 * Code for class EV_STOCK_PIXMAPS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev41.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STOCK_PIXMAPS}.information_pixmap */
static EIF_REFERENCE F42_1006_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1006);
#define Result RTOSR(1006)
	RTOC_NEW(Result);
	Result = F313_4904(RTCV(RTOSCF(1026,F42_1026, (Current))));
	RTOSE (1006);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F42_1006 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1006,F42_1006_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.error_pixmap */
static EIF_REFERENCE F42_1007_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1007);
#define Result RTOSR(1007)
	RTOC_NEW(Result);
	Result = F313_4905(RTCV(RTOSCF(1026,F42_1026, (Current))));
	RTOSE (1007);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F42_1007 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1007,F42_1007_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.default_window_icon */
static EIF_REFERENCE F42_1010_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1010);
#define Result RTOSR(1010)
	RTOC_NEW(Result);
	Result = F313_4912(RTCV(RTOSCF(1026,F42_1026, (Current))));
	RTOSE (1010);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F42_1010 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1010,F42_1010_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.standard_cursor */
static EIF_REFERENCE F42_1012_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1012);
#define Result RTOSR(1012)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1091, 0x01).id, 1091, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1092_9751(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1012);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F42_1012 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1012,F42_1012_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.help_cursor */
static EIF_REFERENCE F42_1014_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1014);
#define Result RTOSR(1014)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1091, 0x01).id, 1091, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1092_9751(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1014);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F42_1014 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1014,F42_1014_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.ibeam_cursor */
static EIF_REFERENCE F42_1015_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1015);
#define Result RTOSR(1015)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1091, 0x01).id, 1091, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1092_9751(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1015);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F42_1015 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1015,F42_1015_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.no_cursor */
static EIF_REFERENCE F42_1016_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1016);
#define Result RTOSR(1016)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1091, 0x01).id, 1091, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1092_9751(RTCW(tr1), ((EIF_INTEGER_32) 6L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1016);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F42_1016 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1016,F42_1016_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.sizeall_cursor */
static EIF_REFERENCE F42_1017_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1017);
#define Result RTOSR(1017)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1091, 0x01).id, 1091, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1092_9751(RTCW(tr1), ((EIF_INTEGER_32) 7L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1017);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F42_1017 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1017,F42_1017_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.implementation */
static EIF_REFERENCE F42_1026_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1026);
#define Result RTOSR(1026)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(312, 0x01).id, 312, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1026);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F42_1026 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1026,F42_1026_body,(Current));
}

void EIF_Minit41 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
