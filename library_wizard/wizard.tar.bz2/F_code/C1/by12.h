
#ifndef _C1_by12_
#define _C1_by12_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F13_234(EIF_REFERENCE);
extern void EIF_Minit12(void);

#ifdef __cplusplus
}
#endif

#endif
