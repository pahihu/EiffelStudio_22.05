
#ifndef _C1_by13_
#define _C1_by13_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F12_234(EIF_REFERENCE);
extern void EIF_Minit13(void);

#ifdef __cplusplus
}
#endif

#endif
