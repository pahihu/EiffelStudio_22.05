
#ifndef _C1_fi43_
#define _C1_fi43_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F43_1032(EIF_REFERENCE, EIF_REFERENCE);
extern void F43_1037(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit43(void);
extern void F914_6739(EIF_REFERENCE);
extern EIF_BOOLEAN F914_6759(EIF_REFERENCE);
extern void F914_6736(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F932_7670(EIF_REFERENCE);
extern void F914_6734(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
