
#ifndef _C1_gd15_
#define _C1_gd15_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F15_421(EIF_REFERENCE);
extern void EIF_Minit15(void);

#ifdef __cplusplus
}
#endif

#endif
