/*
 * Code for class GDK_CAIRO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gd19.h"
#include "ev_gtk.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GDK_CAIRO}.set_source_pixbuf */
void F19_554 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	
	gdk_cairo_set_source_pixbuf((cairo_t*) arg1, (GdkPixbuf*) arg2, (double) arg3, (double) arg4);
	
}

void EIF_Minit19 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
