
#ifndef _C1_ev30_
#define _C1_ev30_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F30_797(EIF_REFERENCE);
extern EIF_REFERENCE F30_800(EIF_REFERENCE);
extern EIF_REFERENCE F30_804(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit30(void);
extern void F1090_9680(EIF_REFERENCE, EIF_REAL_32, EIF_REAL_32, EIF_REAL_32);
extern void F911_6701(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
