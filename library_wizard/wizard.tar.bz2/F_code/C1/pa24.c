/*
 * Code for class PANGO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pa24.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F24_690
static EIF_POINTER inline_F24_690 (void)
{
	return pango_attr_list_new();
	;
}
#define INLINE_F24_690
#endif
#ifndef INLINE_F24_693
static EIF_POINTER inline_F24_693 (EIF_POINTER arg1)
{
	return pango_attr_font_desc_new ((const PangoFontDescription *)arg1);
	;
}
#define INLINE_F24_693
#endif
#ifndef INLINE_F24_694
static void inline_F24_694 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	pango_attr_list_insert ((PangoAttrList *)arg1, (PangoAttribute *)arg2);
	;
}
#define INLINE_F24_694
#endif
#ifndef INLINE_F24_695
static void inline_F24_695 (EIF_POINTER arg1)
{
	pango_attr_list_unref ((PangoAttrList *)arg1);
	;
}
#define INLINE_F24_695
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PANGO}.scale */
EIF_INTEGER_32 F24_638 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) PANGO_SCALE;
	return Result;
}

/* {PANGO}.font_description_new */
EIF_POINTER F24_641 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) pango_font_description_new();
	
	return Result;
}

/* {PANGO}.font_description_free */
void F24_642 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	pango_font_description_free((PangoFontDescription*) arg1);
	
}

/* {PANGO}.font_description_set_family */
void F24_645 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	pango_font_description_set_family((PangoFontDescription*) arg1, (char*) arg2);
	
}

/* {PANGO}.font_description_set_style */
void F24_647 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	pango_font_description_set_style((PangoFontDescription*) arg1, (PangoStyle) arg2);
	
}

/* {PANGO}.font_description_set_weight */
void F24_649 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	pango_font_description_set_weight((PangoFontDescription*) arg1, (PangoWeight) arg2);
	
}

/* {PANGO}.font_description_set_size */
void F24_651 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	pango_font_description_set_size((PangoFontDescription*) arg1, (gint) arg2);
	
}

/* {PANGO}.layout_set_font_description */
void F24_654 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	pango_layout_set_font_description((PangoLayout*) arg1, (PangoFontDescription*) arg2);
	
}

/* {PANGO}.layout_get_pixel_size */
void F24_656 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	
	pango_layout_get_pixel_size((PangoLayout*) arg1, (gint*) arg2, (gint*) arg3);
	
}

/* {PANGO}.layout_get_iter */
EIF_POINTER F24_657 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) pango_layout_get_iter((PangoLayout*) arg1);
	
	return Result;
}

/* {PANGO}.layout_set_text */
void F24_658 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	pango_layout_set_text((PangoLayout*) arg1, (char*) arg2, (int) arg3);
	
}

/* {PANGO}.layout_iter_get_baseline */
EIF_INTEGER_32 F24_659 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) pango_layout_iter_get_baseline((PangoLayoutIter*) arg1);
	
	return Result;
}

/* {PANGO}.layout_iter_free */
void F24_660 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	pango_layout_iter_free((PangoLayoutIter*) arg1);
	
}

/* {PANGO}.layout_get_pixel_extents */
void F24_662 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	
	pango_layout_get_pixel_extents((PangoLayout*) arg1, (PangoRectangle*) arg2, (PangoRectangle*) arg3);
	
}

/* {PANGO}.new_rectangle_struct */
EIF_POINTER F24_674 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) calloc (sizeof(PangoRectangle), 1);
	return Result;
}

/* {PANGO}.rectangle_struct_x */
EIF_INTEGER_32 F24_675 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->x);
	
	return Result;
}

/* {PANGO}.rectangle_struct_y */
EIF_INTEGER_32 F24_676 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->y);
	
	return Result;
}

/* {PANGO}.rectangle_struct_width */
EIF_INTEGER_32 F24_677 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->width);
	
	return Result;
}

/* {PANGO}.rectangle_struct_height */
EIF_INTEGER_32 F24_678 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->height);
	
	return Result;
}

/* {PANGO}.pango_attr_list_new */
EIF_POINTER F24_690 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F24_690 ();
	return Result;
}

/* {PANGO}.pango_attr_font_desc_new */
EIF_POINTER F24_693 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F24_693 ((EIF_POINTER) arg1);
	return Result;
}

/* {PANGO}.pango_attr_list_insert */
void F24_694 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F24_694 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {PANGO}.pango_attr_list_unref */
void F24_695 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F24_695 ((EIF_POINTER) arg1);
}

void EIF_Minit24 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
