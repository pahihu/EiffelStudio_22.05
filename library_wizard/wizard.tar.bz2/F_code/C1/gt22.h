
#ifndef _C1_gt22_
#define _C1_gt22_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F22_599(EIF_REFERENCE);
extern EIF_INTEGER_32 F22_601(EIF_REFERENCE);
extern void EIF_Minit22(void);

#ifdef __cplusplus
}
#endif

#endif
