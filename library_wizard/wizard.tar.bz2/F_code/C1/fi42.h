
#ifndef _C1_fi42_
#define _C1_fi42_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F44_1032(EIF_REFERENCE, EIF_REFERENCE);
extern void F44_1037(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit42(void);
extern void F914_6739(EIF_REFERENCE);
extern EIF_BOOLEAN F914_6759(EIF_REFERENCE);
extern void F914_6736(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F932_7670(EIF_REFERENCE);
extern void F914_6734(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
