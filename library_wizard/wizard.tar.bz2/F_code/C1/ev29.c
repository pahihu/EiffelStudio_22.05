/*
 * Code for class EV_GTK_EVENT_STRINGS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev29.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_EVENT_STRINGS}.set_focus_event_name */

EIF_REFERENCE F29_748 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (748,RTMS_EX_H("set-focus",9,577130099));
}

/* {EV_GTK_EVENT_STRINGS}.configure_event_name */

EIF_REFERENCE F29_749 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (749,RTMS_EX_H("configure-event",15,1205453684));
}

/* {EV_GTK_EVENT_STRINGS}.map_event_name */

EIF_REFERENCE F29_752 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (752,RTMS_EX_H("map-event",9,474090100));
}

/* {EV_GTK_EVENT_STRINGS}.unmap_event_name */

EIF_REFERENCE F29_753 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (753,RTMS_EX_H("unmap-event",11,77806708));
}

/* {EV_GTK_EVENT_STRINGS}.hide_signal_name */

EIF_REFERENCE F29_754 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (754,RTMS_EX_H("hide",4,1751737445));
}

/* {EV_GTK_EVENT_STRINGS}.size_allocate_event_name */

EIF_REFERENCE F29_758 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (758,RTMS_EX_H("size-allocate",13,769151077));
}

/* {EV_GTK_EVENT_STRINGS}.clicked_event_name */

EIF_REFERENCE F29_761 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (761,RTMS_EX_H("clicked",7,169941860));
}

/* {EV_GTK_EVENT_STRINGS}.draw_event_name */

EIF_REFERENCE F29_763 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (763,RTMS_EX_H("draw",4,1685217655));
}

/* {EV_GTK_EVENT_STRINGS}.commit_event_name */

EIF_REFERENCE F29_764 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (764,RTMS_EX_H("commit",6,2031381364));
}

/* {EV_GTK_EVENT_STRINGS}.changed_event_name */

EIF_REFERENCE F29_765 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (765,RTMS_EX_H("changed",7,346303332));
}

/* {EV_GTK_EVENT_STRINGS}.response_event_name */

EIF_REFERENCE F29_769 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (769,RTMS_EX_H("response",8,1418183525));
}

/* {EV_GTK_EVENT_STRINGS}.scroll_event_name */

EIF_REFERENCE F29_775 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (775,RTMS_EX_H("scroll-event",12,2102824820));
}

/* {EV_GTK_EVENT_STRINGS}.commit_event_string */
static EIF_REFERENCE F29_794_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (794);
#define Result RTOSR(794)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(910, 0x00).id, 910, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr2 = RTOSCF(764,F29_764, (Current));
	F911_6701(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (794);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F29_794 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(794,F29_794_body,(Current));
}

void EIF_Minit29 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
