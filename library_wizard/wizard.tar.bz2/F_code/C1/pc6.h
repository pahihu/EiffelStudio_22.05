
#ifndef _C1_pc6_
#define _C1_pc6_

#ifdef __cplusplus
extern "C" {
#endif

extern void F6_53(EIF_REFERENCE);
extern void F6_54(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F6_56(EIF_REFERENCE, EIF_INTEGER_32);
extern void F6_57(EIF_REFERENCE, EIF_REFERENCE);
extern void F6_58(EIF_REFERENCE, EIF_INTEGER_32);
extern void F6_59(EIF_REFERENCE, EIF_REFERENCE);
extern void F6_60(EIF_REFERENCE, EIF_REFERENCE);
extern void F6_61(EIF_REFERENCE);
extern void EIF_Minit6(void);
extern EIF_INTEGER_32 F1054_9365(EIF_REFERENCE, EIF_INTEGER_32);
extern void F842_6401(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
