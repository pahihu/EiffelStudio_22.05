/*
 * Code for class GTK_PROPERTIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt34.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F34_873
static EIF_POINTER inline_F34_873 (void)
{
	static char *v = "justify";
return (EIF_POINTER) v;
	;
}
#define INLINE_F34_873
#endif
#ifndef INLINE_F34_880
static EIF_POINTER inline_F34_880 (void)
{
	static char *v = "gtk-menu-bar-accel";
return (EIF_POINTER) v;
	;
}
#define INLINE_F34_880
#endif
#ifndef INLINE_F34_881
static EIF_POINTER inline_F34_881 (void)
{
	static char *v = "gtk-menu-images";
return (EIF_POINTER) v;
	;
}
#define INLINE_F34_881
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_PROPERTIES}.justify */
EIF_POINTER F34_873 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F34_873 ();
	return Result;
}

/* {GTK_PROPERTIES}.gtk_menu_bar_accel */
EIF_POINTER F34_880 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F34_880 ();
	return Result;
}

/* {GTK_PROPERTIES}.gtk_menu_icons */
EIF_POINTER F34_881 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F34_881 ();
	return Result;
}

void EIF_Minit34 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
