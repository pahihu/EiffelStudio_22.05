
#ifndef _C1_is47_
#define _C1_is47_

#ifdef __cplusplus
extern "C" {
#endif

extern void F48_1187(EIF_REFERENCE);
extern EIF_NATURAL_16 F48_1189(EIF_REFERENCE, EIF_POINTER);
extern void F48_1190(EIF_REFERENCE, EIF_NATURAL_16);
extern void EIF_Minit47(void);

#ifdef __cplusplus
}
#endif

#endif
