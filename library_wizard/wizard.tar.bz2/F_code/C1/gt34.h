
#ifndef _C1_gt34_
#define _C1_gt34_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F34_873(EIF_REFERENCE);
extern EIF_POINTER F34_880(EIF_REFERENCE);
extern EIF_POINTER F34_881(EIF_REFERENCE);
extern void EIF_Minit34(void);

#ifdef __cplusplus
}
#endif

#endif
