
#ifndef _C1_ca7_
#define _C1_ca7_

#ifdef __cplusplus
extern "C" {
#endif

extern void F7_63(EIF_REFERENCE);
extern void F7_64(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F7_65(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F7_67(EIF_REFERENCE, EIF_INTEGER_32);
extern void F7_68(EIF_REFERENCE);
extern void F7_69(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit7(void);
extern EIF_CHARACTER_8 F1054_9361(EIF_REFERENCE, EIF_INTEGER_32);
extern void F836_6401(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
