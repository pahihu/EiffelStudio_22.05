/*
 * Code for class EV_STOCK_COLORS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev40.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STOCK_COLORS}.white */
static EIF_REFERENCE F40_974_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (974);
#define Result RTOSR(974)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1089, 0x01).id, 1089, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	tr4_2 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	tr4_3 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	F1090_9680(RTCW(tr1), tr4_1, tr4_2, tr4_3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (974);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F40_974 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(974,F40_974_body,(Current));
}

/* {EV_STOCK_COLORS}.black */
static EIF_REFERENCE F40_975_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (975);
#define Result RTOSR(975)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1089, 0x01).id, 1089, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	tr4_2 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	tr4_3 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	F1090_9680(RTCW(tr1), tr4_1, tr4_2, tr4_3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (975);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F40_975 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(975,F40_975_body,(Current));
}

/* {EV_STOCK_COLORS}.gray */
static EIF_REFERENCE F40_977_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (977);
#define Result RTOSR(977)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1089, 0x01).id, 1089, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1090_9680(RTCW(tr1), (EIF_REAL_32) 0.7, (EIF_REAL_32) 0.7, (EIF_REAL_32) 0.7);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (977);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F40_977 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(977,F40_977_body,(Current));
}

/* {EV_STOCK_COLORS}.dark_gray */
static EIF_REFERENCE F40_979_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (979);
#define Result RTOSR(979)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1089, 0x01).id, 1089, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1090_9680(RTCW(tr1), (EIF_REAL_32) 0.5, (EIF_REAL_32) 0.5, (EIF_REAL_32) 0.5);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (979);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F40_979 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(979,F40_979_body,(Current));
}

/* {EV_STOCK_COLORS}.red */
static EIF_REFERENCE F40_988_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (988);
#define Result RTOSR(988)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1089, 0x01).id, 1089, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	tr4_2 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	tr4_3 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	F1090_9680(RTCW(tr1), tr4_1, tr4_2, tr4_3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (988);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F40_988 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(988,F40_988_body,(Current));
}

/* {EV_STOCK_COLORS}.default_background_color */
EIF_REFERENCE F40_998 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F30_797(RTCV(RTOSCF(1001,F40_1001, (Current))));
	RTLE;
	return Result;
}

/* {EV_STOCK_COLORS}.default_foreground_color */
EIF_REFERENCE F40_999 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F30_800(RTCV(RTOSCF(1001,F40_1001, (Current))));
	RTLE;
	return Result;
}

/* {EV_STOCK_COLORS}.implementation */
static EIF_REFERENCE F40_1001_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1001);
#define Result RTOSR(1001)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(29, 0x01).id, 29, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1001);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F40_1001 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1001,F40_1001_body,(Current));
}

void EIF_Minit40 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
