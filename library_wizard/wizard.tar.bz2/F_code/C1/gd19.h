
#ifndef _C1_gd19_
#define _C1_gd19_

#ifdef __cplusplus
extern "C" {
#endif

extern void F19_554(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_REAL_64, EIF_REAL_64);
extern void EIF_Minit19(void);

#ifdef __cplusplus
}
#endif

#endif
