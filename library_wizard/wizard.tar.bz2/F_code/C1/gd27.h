
#ifndef _C1_gd27_
#define _C1_gd27_

#ifdef __cplusplus
extern "C" {
#endif

extern void F27_733(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32*, EIF_INTEGER_32*);
extern EIF_POINTER F27_736(EIF_REFERENCE);
extern EIF_INTEGER_32 F27_738(EIF_REFERENCE);
extern void EIF_Minit27(void);

#ifdef __cplusplus
}
#endif

#endif
