/*
 * Code for class EV_COLORIZABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev462.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_COLORIZABLE}.foreground_color */
EIF_REFERENCE F1101_9873 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	Result = F1226_11769(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_COLORIZABLE}.background_color */
EIF_REFERENCE F1101_9874 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	Result = F1226_11770(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_COLORIZABLE}.set_foreground_color */
void F1101_9875 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9533[Dtype(RTCW(tr1))-1279])(tr1, arg1);
	RTLE;
}

/* {EV_COLORIZABLE}.set_background_color */
void F1101_9876 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9534[Dtype(RTCW(tr1))-1279])(tr1, arg1);
	RTLE;
}

void EIF_Minit462 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
