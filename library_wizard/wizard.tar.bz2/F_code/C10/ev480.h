
#ifndef _C10_ev480_
#define _C10_ev480_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1119_10070(EIF_REFERENCE);
extern void F1119_10074(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1119_10075(EIF_REFERENCE);
extern void F1119_10076(EIF_REFERENCE);
extern void EIF_Minit480(void);
extern void F1257_12037(EIF_REFERENCE);
extern EIF_REFERENCE F1257_12038(EIF_REFERENCE);
extern void F1257_12040(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
