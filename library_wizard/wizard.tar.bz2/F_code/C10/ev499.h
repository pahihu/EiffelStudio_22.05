
#ifndef _C10_ev499_
#define _C10_ev499_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1139_10380(EIF_REFERENCE);
extern void F1139_10382(EIF_REFERENCE);
extern void F1139_10383(EIF_REFERENCE);
extern EIF_REFERENCE F1139_10385(EIF_REFERENCE);
extern void F1139_10386(EIF_REFERENCE);
extern void EIF_Minit499(void);
extern void F1289_12512(EIF_REFERENCE);
extern void F1289_12511(EIF_REFERENCE);
extern void F1289_12497(EIF_REFERENCE);
extern void F1289_12509(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
