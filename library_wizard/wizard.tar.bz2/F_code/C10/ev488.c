/*
 * Code for class EV_CONTAINER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev488.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CONTAINER}.item */
EIF_REFERENCE F1128_10219 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9867[Dtype(RTCW(tr1))-1279])(tr1);
	RTLE;
	return Result;
}

/* {EV_CONTAINER}.extend */
void F1128_10228 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9874[Dtype(RTCW(tr1))-1279])(tr1, arg1);
	RTLE;
}

/* {EV_CONTAINER}.put */
void F1128_10229 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9875[Dtype(RTCW(tr1))-1279])(tr1, arg1);
	RTLE;
}

/* {EV_CONTAINER}.replace */
void F1128_10230 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9875[Dtype(RTCW(tr1))-1279])(tr1, arg1);
	RTLE;
}

/* {EV_CONTAINER}.new_cursor */
EIF_REFERENCE F1128_10232 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4814[Dtype(Current)-349])(Current);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4755[Dtype(RTCW(tr1))-327])(tr1);
	RTLE;
	return Result;
}

/* {EV_CONTAINER}.client_width */
EIF_INTEGER_32 F1128_10233 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9871[Dtype(RTCW(tr1))-1279])(tr1);
	RTLE;
	return Result;
}

/* {EV_CONTAINER}.client_height */
EIF_INTEGER_32 F1128_10234 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9872[Dtype(RTCW(tr1))-1279])(tr1);
	RTLE;
	return Result;
}

/* {EV_CONTAINER}.propagate_foreground_color */
void F1128_10235 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	F1269_12296(RTCW(tr1));
	RTLE;
}

/* {EV_CONTAINER}.propagate_background_color */
void F1128_10236 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	F1269_12297(RTCW(tr1));
	RTLE;
}

/* {EV_CONTAINER}.cl_extend */
void F1128_10251 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8394[Dtype(Current)-1132])(Current, arg1);
}

/* {EV_CONTAINER}.cl_prune */
void F1128_10252 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8397[Dtype(Current)-1132])(Current, arg1);
}

void EIF_Minit488 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
