/*
 * Code for class EV_DOCKABLE_SOURCE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev463.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DOCKABLE_SOURCE}.real_source */
EIF_REFERENCE F1102_9882 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + O9558[Dtype(tr1)-1227]);
	RTLE;
	return Result;
}

void EIF_Minit463 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
