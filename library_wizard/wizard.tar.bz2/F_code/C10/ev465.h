
#ifndef _C10_ev465_
#define _C10_ev465_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1104_9906(EIF_REFERENCE);
extern EIF_INTEGER_32 F1104_9907(EIF_REFERENCE);
extern EIF_INTEGER_32 F1104_9908(EIF_REFERENCE);
extern EIF_INTEGER_32 F1104_9909(EIF_REFERENCE);
extern EIF_INTEGER_32 F1104_9910(EIF_REFERENCE);
extern void EIF_Minit465(void);
extern EIF_INTEGER_32 F1215_11592(EIF_REFERENCE);
extern char *(*R9609[])();
extern char *(*R9610[])();
extern char *(*R9611[])();
extern char *(*R9612[])();
extern long O7887[];

#ifdef __cplusplus
}
#endif

#endif
