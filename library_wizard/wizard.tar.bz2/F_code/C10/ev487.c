/*
 * Code for class EV_WIDGET
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev487.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WIDGET}.parent */
EIF_REFERENCE F1127_10187 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	Result = F1267_12216(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_WIDGET}.pointer_style */
EIF_REFERENCE F1127_10189 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	Result = F1266_12174(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_WIDGET}.real_target */
EIF_REFERENCE F1127_10191 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + O9817[Dtype(tr1)-1265]);
	RTLE;
	return Result;
}

/* {EV_WIDGET}.is_show_requested */
EIF_BOOLEAN F1127_10195 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	Result = F1215_11615(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_WIDGET}.is_displayed */
EIF_BOOLEAN F1127_10196 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9820[Dtype(RTCW(tr1))-1279])(tr1);
	RTLE;
	return Result;
}

/* {EV_WIDGET}.has_focus */
EIF_BOOLEAN F1127_10197 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9821[Dtype(RTCW(tr1))-1279])(tr1);
	RTLE;
	return Result;
}

/* {EV_WIDGET}.show */
void F1127_10200 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R9824[Dtype(RTCW(tr1))-1279])(tr1);
	RTLE;
}

/* {EV_WIDGET}.set_focus */
void F1127_10201 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (F1127_10196(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
		F1215_11608(RTCW(tr1));
	}
	RTLE;
}

/* {EV_WIDGET}.enable_capture */
void F1127_10202 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	F1265_12146(RTCW(tr1));
	RTLE;
}

/* {EV_WIDGET}.disable_capture */
void F1127_10203 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	F1265_12147(RTCW(tr1));
	RTLE;
}

/* {EV_WIDGET}.set_pointer_style */
void F1127_10210 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	F1215_11604(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_WIDGET}.set_minimum_width */
void F1127_10211 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[dtype-1082]);
	F1267_12226(RTCW(tr1), arg1);
	*(EIF_BOOLEAN *)(Current + O8362[dtype-1126]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {EV_WIDGET}.set_minimum_height */
void F1127_10212 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[dtype-1082]);
	F1267_12227(RTCW(tr1), arg1);
	*(EIF_BOOLEAN *)(Current + O8363[dtype-1126]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {EV_WIDGET}.set_minimum_size */
void F1127_10213 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[dtype-1082]);
	F1267_12228(RTCW(tr1), arg1, arg2);
	*(EIF_BOOLEAN *)(Current + O8363[dtype-1126]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O8362[dtype-1126]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

void EIF_Minit487 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
