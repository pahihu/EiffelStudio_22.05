
#ifndef _C10_ev486_
#define _C10_ev486_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1126_10179(EIF_REFERENCE);
extern void F1126_10182(EIF_REFERENCE);
extern void EIF_Minit486(void);
extern void F1239_11923(EIF_REFERENCE);
extern EIF_BOOLEAN F1239_11920(EIF_REFERENCE);
extern long O7887[];

#ifdef __cplusplus
}
#endif

#endif
