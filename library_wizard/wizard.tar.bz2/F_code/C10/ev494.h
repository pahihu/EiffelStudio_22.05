
#ifndef _C10_ev494_
#define _C10_ev494_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1134_10303(EIF_REFERENCE);
extern void F1134_10304(EIF_REFERENCE);
extern void EIF_Minit494(void);
extern void F1280_12415(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
