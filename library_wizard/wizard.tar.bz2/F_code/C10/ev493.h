
#ifndef _C10_ev493_
#define _C10_ev493_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1133_10301(EIF_REFERENCE);
extern void F1133_10302(EIF_REFERENCE);
extern void EIF_Minit493(void);
extern void F1281_12418(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
