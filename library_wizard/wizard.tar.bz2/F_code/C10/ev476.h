
#ifndef _C10_ev476_
#define _C10_ev476_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1115_9971(EIF_REFERENCE);
extern void F1115_9979(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1115_9987(EIF_REFERENCE);
extern void F1115_9989(EIF_REFERENCE);
extern void F1115_9990(EIF_REFERENCE);
extern void F1115_9991(EIF_REFERENCE);
extern void F1115_9993(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1115_9999(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1115_10006(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1115_10009(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1115_10010(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1115_10015(EIF_REFERENCE);
extern void EIF_Minit476(void);
extern void F1363_13813(EIF_REFERENCE);
extern char *(*R10566[])();
extern char *(*R10569[])();
extern char *(*R10570[])();
extern char *(*R10535[])();
extern char *(*R10536[])();
extern char *(*R10542[])();
extern char *(*R10548[])();
extern char *(*R10549[])();
extern char *(*R10553[])();
extern char *(*R10559[])();
extern long O7887[];
extern long O10665[];

#ifdef __cplusplus
}
#endif

#endif
