
#ifndef _C10_ev488_
#define _C10_ev488_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1128_10219(EIF_REFERENCE);
extern void F1128_10228(EIF_REFERENCE, EIF_REFERENCE);
extern void F1128_10229(EIF_REFERENCE, EIF_REFERENCE);
extern void F1128_10230(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1128_10232(EIF_REFERENCE);
extern EIF_INTEGER_32 F1128_10233(EIF_REFERENCE);
extern EIF_INTEGER_32 F1128_10234(EIF_REFERENCE);
extern void F1128_10235(EIF_REFERENCE);
extern void F1128_10236(EIF_REFERENCE);
extern void F1128_10251(EIF_REFERENCE, EIF_REFERENCE);
extern void F1128_10252(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit488(void);
extern void F1269_12297(EIF_REFERENCE);
extern void F1269_12296(EIF_REFERENCE);
extern char *(*R9867[])();
extern char *(*R8394[])();
extern char *(*R4755[])();
extern char *(*R9871[])();
extern char *(*R9872[])();
extern char *(*R9874[])();
extern char *(*R9875[])();
extern char *(*R4814[])();
extern char *(*R8397[])();
extern long O7887[];

#ifdef __cplusplus
}
#endif

#endif
