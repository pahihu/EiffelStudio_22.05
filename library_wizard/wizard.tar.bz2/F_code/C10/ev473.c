/*
 * Code for class EV_TEXTABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev473.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TEXTABLE}.make_with_text */
void F1112_9954 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1083_9562(Current);
	F1112_9956(Current, arg1);
	RTLE;
}

/* {EV_TEXTABLE}.text */
EIF_REFERENCE F1112_9955 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9683[Dtype(RTCW(tr1))-1286])(tr1);
	RTLE;
	return Result;
}

/* {EV_TEXTABLE}.set_text */
void F1112_9956 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = arg1;
	if ((EIF_TRUE)) {
		tr1 = *(EIF_REFERENCE *)(Current + O7887[dtype-1082]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9684[Dtype(RTCW(tr1))-1286])(tr1, loc1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O7887[dtype-1082]);
		tr2 = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1049_9123(RTCW(tr2), arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9684[Dtype(RTCW(tr1))-1286])(tr1, tr2);
	}
	RTLE;
}

void EIF_Minit473 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
