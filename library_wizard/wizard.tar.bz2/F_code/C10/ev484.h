
#ifndef _C10_ev484_
#define _C10_ev484_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1123_10112(EIF_REFERENCE);
extern void EIF_Minit484(void);
extern long O7887[];
extern long O9742[];

#ifdef __cplusplus
}
#endif

#endif
