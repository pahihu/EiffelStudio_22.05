
#ifndef _C10_ev466_
#define _C10_ev466_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1105_9914(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1105_9915(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1105_9919(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit466(void);
extern void F1216_11633(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1216_11630(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1216_11634(EIF_REFERENCE, EIF_INTEGER_32);
extern long O7887[];

#ifdef __cplusplus
}
#endif

#endif
