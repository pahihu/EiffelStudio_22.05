/*
 * Code for class EV_FRAME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev497.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FRAME}.default_identifier_name */
EIF_REFERENCE F1137_10356 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	tb1 = F491_5229(RTCV(F1112_9955(Current)));
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) F1096_9809(Current);
	} else {
		Result = F1_14(F1112_9955(Current));
		F1051_9271(RTCW(Result));
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
		F1051_9256(RTCW(Result), tw1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
		F1051_9256(RTCW(Result), tw1);
	}
	RTLE;
	return Result;
}

/* {EV_FRAME}.implementation */
EIF_REFERENCE F1137_10361 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_FRAME}.create_implementation */
void F1137_10362 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1286, 0x01).id, 1286, _OBJSIZ_51_13_10_8_0_1_0_0_);
	F1287_12456(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit497 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
