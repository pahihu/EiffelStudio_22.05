
#ifndef _C10_ev474_
#define _C10_ev474_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1113_9964(EIF_REFERENCE);
extern void F1113_9966(EIF_REFERENCE);
extern void EIF_Minit474(void);
extern char *(*R9696[])();
extern char *(*R9697[])();
extern long O7887[];

#ifdef __cplusplus
}
#endif

#endif
