
#ifndef _C10_ev473_
#define _C10_ev473_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1112_9954(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1112_9955(EIF_REFERENCE);
extern void F1112_9956(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit473(void);
extern void F1049_9123(EIF_REFERENCE, EIF_REFERENCE);
extern void F1083_9562(EIF_REFERENCE);
extern char *(*R9683[])();
extern char *(*R9684[])();
extern long O7887[];

#ifdef __cplusplus
}
#endif

#endif
