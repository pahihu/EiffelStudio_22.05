
#ifndef _C10_ev479_
#define _C10_ev479_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1118_10065(EIF_REFERENCE, EIF_REFERENCE);
extern void F1118_10066(EIF_REFERENCE, EIF_REFERENCE);
extern void F1118_10067(EIF_REFERENCE);
extern void EIF_Minit479(void);
extern void F1256_12024(EIF_REFERENCE, EIF_REFERENCE);
extern void F1256_12023(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
