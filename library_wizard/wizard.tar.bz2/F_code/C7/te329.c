/*
 * Code for class TEMPLATE_STRUCTURE_ACTION_GENERIC
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "te329.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TEMPLATE_STRUCTURE_ACTION_GENERIC}.reset_type */
void F853_6517 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ACTION_GENERIC}.update_type */
void F853_6518 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F853_6517(Current);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = RTOSCF(3317,F145_3317, (Current));
		tb1 = F1046_9027(loc1, tr1);
		if (tb1) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_9_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			tr1 = RTOSCF(3318,F145_3318, (Current));
			tb1 = F1046_9027(loc1, tr1);
			if (tb1) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_9_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tr1 = RTOSCF(3319,F145_3319, (Current));
				tb1 = F1046_9027(loc1, tr1);
				if (tb1) {
					*(EIF_BOOLEAN *)(Current+ _CHROFF_9_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					*(EIF_BOOLEAN *)(Current+ _CHROFF_9_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			}
		}
	} else {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_9_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ACTION_GENERIC}.process */
void F853_6519 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (TEMPLATE_STRUCTURE_ITEM.process) */
		/* END INLINED CODE */
	}
	;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_9_2_)) {
		F853_6522(Current, (EIF_BOOLEAN) 1);
	} else {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_9_3_)) {
			F853_6522(Current, (EIF_BOOLEAN) 0);
		} else {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_9_4_)) {
				F853_6521(Current);
			} else {
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_9_5_)) {
				}
			}
		}
	}
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ACTION_GENERIC}.set_action_name */
void F853_6520 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F849_6497(Current, arg1);
	F853_6518(Current);
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ACTION_GENERIC}.process_include */
void F853_6521 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLR(4,loc9);
	RTLR(5,loc7);
	RTLR(6,loc10);
	RTLR(7,loc2);
	RTLR(8,loc3);
	RTLR(9,loc6);
	RTLIU(10);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(3329,F145_3329, (Current));
	tb1 = F648_5596(RTCW(tr1), tr2);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = RTOSCF(3329,F145_3329, (Current));
		loc1 = F648_5594(RTCW(tr1), tr2);
	}
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(3328,F145_3328, (Current));
	tb2 = F648_5596(RTCW(tr1), tr2);
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = RTOSCF(3328,F145_3328, (Current));
		tr1 = F648_5594(RTCW(tr1), tr2);
		loc9 = tr1;
		tb1 = EIF_TEST(loc9);
	}
	if (tb1) {
		tr1 = RTMS_EX_H("true",4,1953658213);
		loc5 = F1052_9308(loc9, tr1);
	} else {
		loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		loc7 = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F932_7662(RTCW(loc7), loc1);
		tb1 = F932_7672(RTCW(loc7));
		if (tb1) {
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(3463,F160_3463, (Current))) + _REFACS_2_);
			loc10 = tr1;
			if (EIF_TEST(loc10)) {
				tr1 = F932_7690(loc10, loc7);
				loc7 = (EIF_REFERENCE) tr1;
			}
		}
	}
	if ((EIF_BOOLEAN)(loc7 != NULL)) {
		loc2 = RTLNS(eif_new_type(920, 0x01).id, 920, _OBJSIZ_5_7_2_4_1_1_2_1_);
		F921_7364(RTCW(loc2), loc7);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6114[Dtype(RTCW(loc2))-919])(loc2);
		if (tb1) {
			loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4965[Dtype(RTCW(loc2))-575])(loc2);
			loc3 = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1052_9282(RTCW(loc3), loc4);
			F919_7152(RTCW(loc2));
			for (;;) {
				if (loc8) break;
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6170[Dtype(RTCW(loc2))-919])(loc2, ((EIF_INTEGER_32) 1024L));
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
				F1054_9395(RTCW(loc3), tr1);
				loc8 = '\01';
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
				if (!(EIF_BOOLEAN) (ti4_1 < ((EIF_INTEGER_32) 1024L))) {
					tb1 = F369_5159(RTCW(loc2));
					loc8 = tb1;
				}
			}
			F919_7169(RTCW(loc2));
		} else {
			tr1 = RTMS_EX_H("{!! Missing include file ",25,467258912);
			tr2 = F932_7700(RTCW(loc7));
			tr1 = F1054_9414(tr1, tr2);
			tr2 = RTMS_EX_H(" !!}",4,539042173);
			tr1 = F1054_9414(RTCW(tr1), tr2);
			F847_6483(Current, tr1);
		}
	} else {
		tr1 = RTMS_EX_H("{!! Invalid use of action include !!}",37,439749757);
		F847_6483(Current, tr1);
	}
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		tr1 = RTMS_EX_H("\012",1,10);
		tb1 = F1052_9319(RTCW(loc3), tr1);
		if (tb1) {
			F1054_9419(RTCW(loc3), ((EIF_INTEGER_32) 1L));
		}
		if (loc5) {
			F847_6482(Current, loc3);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tb1 = F483_5229(RTCW(tr1));
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = F849_6499(Current);
				F1054_9393(RTCW(loc3), tr1);
			}
			loc6 = RTLNS(eif_new_type(162, 0x01).id, 162, _OBJSIZ_6_0_0_0_0_0_0_0_);
			F163_3479(RTCW(loc6), loc3);
			tr1 = F25_703(RTCV(RTOSCF(3463,F160_3463, (Current))));
			tr1 = F1_14(tr1);
			F163_3484(RTCW(loc6), tr1);
			F25_706(RTCV(RTOSCF(3463,F160_3463, (Current))));
			tr1 = RTOSCF(3463,F160_3463, (Current));
			F25_710(RTCW(tr1), loc6);
			F163_3495(RTCW(loc6));
			F163_3500(RTCW(loc6));
			loc3 = *(EIF_REFERENCE *)(RTCW(loc6) + _REFACS_4_);
			F25_707(RTCV(RTOSCF(3463,F160_3463, (Current))));
			F847_6482(Current, loc3);
		}
	}
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ACTION_GENERIC}.process_if_unless */
void F853_6522 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc14 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLR(4,loc9);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLR(7,loc4);
	RTLR(8,loc10);
	RTLR(9,loc11);
	RTLR(10,loc12);
	RTLR(11,loc13);
	RTLR(12,loc8);
	RTLIU(13);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(3325,F145_3325, (Current));
	tb1 = F648_5596(RTCW(tr1), tr2);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = RTOSCF(3325,F145_3325, (Current));
		loc1 = F648_5594(RTCW(tr1), tr2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(3326,F145_3326, (Current));
	tb1 = F648_5596(RTCW(tr1), tr2);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = RTOSCF(3326,F145_3326, (Current));
		loc1 = F648_5594(RTCW(tr1), tr2);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(3327,F145_3327, (Current));
	tb1 = F648_5596(RTCW(tr1), tr2);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = RTOSCF(3327,F145_3327, (Current));
		loc1 = F648_5594(RTCW(tr1), tr2);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tb2 = F489_5229(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tb1 = F1052_9317(RTCW(loc1), (EIF_CHARACTER_8) '=');
		if (tb1) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
			loc9 = F1046_9063(RTCW(loc1), tw1);
			ti4_1 = ((EIF_INTEGER_32) 1L);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4947[Dtype(RTCW(loc9))-577])(loc9, (EIF_REFERENCE) &ti4_1);
			loc5 = F847_6464(Current, tr1);
			ti4_1 = ((EIF_INTEGER_32) 2L);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4947[Dtype(RTCW(loc9))-577])(loc9, (EIF_REFERENCE) &ti4_1);
			loc6 = F847_6464(Current, tr1);
			loc4 = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_BOOLEAN *)loc4 = RTCEQ(loc5, loc6);
		} else {
			tb1 = F1052_9317(RTCW(loc1), (EIF_CHARACTER_8) '~');
			if (tb1) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '~';
				loc9 = F1046_9063(RTCW(loc1), tw1);
				ti4_1 = ((EIF_INTEGER_32) 1L);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4947[Dtype(RTCW(loc9))-577])(loc9, (EIF_REFERENCE) &ti4_1);
				loc5 = F847_6464(Current, tr1);
				ti4_1 = ((EIF_INTEGER_32) 2L);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4947[Dtype(RTCW(loc9))-577])(loc9, (EIF_REFERENCE) &ti4_1);
				loc6 = F847_6464(Current, tr1);
				loc10 = RTCCL(loc5);
				loc10 = RTRV(eif_new_type(1045, 0x01),loc10);
				loc11 = RTCCL(loc6);
				loc11 = RTRV(eif_new_type(1045, 0x01),loc11);
				if ((EIF_BOOLEAN) (EIF_TEST(loc10) && EIF_TEST(loc11))) {
					tb1 = F1046_9030(loc10, loc11);
					loc4 = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
					*(EIF_BOOLEAN *)loc4 = tb1;
				} else {
					loc4 = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
					*(EIF_BOOLEAN *)loc4 = RTEQ(loc5, loc6);
				}
			} else {
				loc4 = F847_6464(Current, loc1);
			}
		}
		if ((EIF_BOOLEAN)(loc4 == NULL)) {
			if (loc3) {
				loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
		} else {
			if (loc2) {
				loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				if (loc3) {
					loc12 = RTCCL(loc4);
					loc12 = RTRV(eif_new_type(1045, 0x01),loc12);
					if (EIF_TEST(loc12)) {
						loc7 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7502[Dtype(loc12)-1049])(loc12);
					} else {
						loc13 = RTCCL(loc4);
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFF01,314,0,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							loc13 = RTRV(typres0,loc13);
						}
						if (EIF_TEST(loc13)) {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4755[Dtype(loc13)-327])(loc13);
							loc7 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5445[Dtype(RTCW(tr1))-720])(tr1);
						} else {
							loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
					}
				} else {
					tr1 = RTCCL(loc4);
					RTOB(*(EIF_BOOLEAN *), eif_new_type(978, 0x00), tr1, loc14, tb1);
					if (tb1) {
						loc7 = loc14;
					} else {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R28[Dtype(RTCW(loc4))-5])(loc4);
						tr2 = RTMS_EX_H("true",4,1953658213);
						tb1 = F1046_9027(RTCW(tr1), tr2);
						if (tb1) {
							loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						}
					}
				}
			}
		}
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 && loc7) || (EIF_BOOLEAN) ((EIF_BOOLEAN) !arg1 && (EIF_BOOLEAN) !loc7))) {
		tr1 = F849_6499(Current);
		loc8 = F849_6500(Current, tr1, (EIF_BOOLEAN) 0);
		F847_6482(Current, loc8);
	} else {
		tr1 = RTMS_EX_H("",0,0);
		F847_6482(Current, tr1);
	}
	RTLE;
}

void EIF_Minit329 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
