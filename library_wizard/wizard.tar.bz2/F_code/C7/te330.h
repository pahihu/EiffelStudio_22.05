
#ifndef _C7_te330_
#define _C7_te330_

#ifdef __cplusplus
extern "C" {
#endif

extern void F854_6523(EIF_REFERENCE);
extern void F854_6524(EIF_REFERENCE);
extern void EIF_Minit330(void);
extern EIF_REFERENCE F849_6500(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_REFERENCE F849_6499(EIF_REFERENCE);
extern void F847_6482(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F160_3464(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F160_3465(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R28[])();

#ifdef __cplusplus
}
#endif

#endif
