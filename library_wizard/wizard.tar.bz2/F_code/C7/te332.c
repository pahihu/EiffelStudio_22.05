/*
 * Code for class TEMPLATE_STRUCTURE_ACTION_NL2BR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "te332.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TEMPLATE_STRUCTURE_ACTION_NL2BR}.process */
void F856_6527 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (TEMPLATE_STRUCTURE_ITEM.process) */
		/* END INLINED CODE */
	}
	;
	F856_6528(Current);
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ACTION_NL2BR}.process_nl2br */
void F856_6528 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = F849_6499(Current);
	loc1 = F849_6500(Current, tr1, (EIF_BOOLEAN) 0);
	tr1 = RTMS_EX_H("\015\012",2,3338);
	tr2 = RTMS_EX_H("<br/>\012",6,2034416138);
	F1054_9372(RTCW(loc1), tr1, tr2);
	tr1 = RTMS_EX_H("\012",1,10);
	tr2 = RTMS_EX_H("<br/>\012",6,2034416138);
	F1054_9372(RTCW(loc1), tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(3331,F145_3331, (Current));
	tb1 = F648_5596(RTCW(tr1), tr2);
	if (tb1) {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = RTOSCF(3331,F145_3331, (Current));
		tr1 = F648_5594(RTCW(tr1), tr2);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = RTOSCF(3337,F145_3337, (Current));
			tb2 = F1052_9308(loc2, tr1);
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = RTMS_EX_H("\011",1,9);
			tr2 = RTMS_EX_H("&nbsp;&nbsp;&nbsp;&nbsp;",24,1681196603);
			F1054_9372(RTCW(loc1), tr1, tr2);
		}
	}
	F847_6482(Current, loc1);
	RTLE;
}

void EIF_Minit332 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
