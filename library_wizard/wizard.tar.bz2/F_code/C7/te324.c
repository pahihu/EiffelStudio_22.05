/*
 * Code for class TEMPLATE_STRUCTURE_VARIABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "te324.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TEMPLATE_STRUCTURE_VARIABLE}.get_output */
void F848_6485 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	F847_6472(Current);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4948[Dtype(RTCW(tr1))-575])(tr1, loc1);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5131[Dtype(RTCW(tr1))-647])(tr1, loc1);
				tr2 = RTCCL(tr1);
				tr1 = F162_3473(Current, tr2);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(3463,F160_3463, (Current))));
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4948[Dtype(RTCW(tr1))-575])(tr1, loc1);
				if (tb1) {
					tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(3463,F160_3463, (Current))));
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5131[Dtype(RTCW(tr1))-647])(tr1, loc1);
					tr2 = RTCCL(tr1);
					tr1 = F162_3473(Current, tr2);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
				} else {
					tr1 = F25_703(RTCV(RTOSCF(3463,F160_3463, (Current))));
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4948[Dtype(RTCW(tr1))-575])(tr1, loc1);
					if (tb1) {
						tr1 = F25_703(RTCV(RTOSCF(3463,F160_3463, (Current))));
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5131[Dtype(RTCW(tr1))-647])(tr1, loc1);
						tr2 = RTCCL(tr1);
						tr1 = F162_3473(Current, tr2);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
					} else {
						tb1 = *(EIF_BOOLEAN *)(RTCV(RTOSCF(3463,F160_3463, (Current)))+ _CHROFF_6_0_);
						if (tb1) {
							tr1 = RTMS_EX_H("{!! Error = No value for ",25,390670880);
							tr1 = F1054_9414(tr1, loc1);
							tr2 = RTMS_EX_H(" variable !!}",13,710289533);
							tr1 = F1054_9414(RTCW(tr1), tr2);
							RTAR(Current, tr1);
							*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
						} else {
							tr1 = RTMS_EX_H("",0,0);
							RTAR(Current, tr1);
							*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
						}
					}
				}
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				tr1 = F847_6464(Current, loc2);
				tr2 = RTCCL(tr1);
				tr1 = F162_3473(Current, tr2);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
			}
		}
	}
	RTLE;
}

/* {TEMPLATE_STRUCTURE_VARIABLE}.set_variable_name */
void F848_6489 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {TEMPLATE_STRUCTURE_VARIABLE}.set_variable_expression */
void F848_6490 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTLE;
}

void EIF_Minit324 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
