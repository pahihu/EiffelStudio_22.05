
#ifndef _C7_st315_
#define _C7_st315_

#ifdef __cplusplus
extern "C" {
#endif

extern void F803_6247(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F803_6248(EIF_REFERENCE);
extern EIF_REFERENCE F803_6249(EIF_REFERENCE);
extern EIF_REFERENCE F803_6251(EIF_REFERENCE);
extern EIF_INTEGER_32 F803_6252(EIF_REFERENCE);
extern void EIF_Minit315(void);
extern EIF_INTEGER_32 F1049_9167(EIF_REFERENCE);
extern char *(*R7641[])();

#ifdef __cplusplus
}
#endif

#endif
