/*
 * Code for class TEMPLATE_STRUCTURE_ACTION_ASSIGN
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "te326.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TEMPLATE_STRUCTURE_ACTION_ASSIGN}.process */
void F850_6501 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (TEMPLATE_STRUCTURE_ITEM.process) */
		/* END INLINED CODE */
	}
	;
	F850_6502(Current);
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ACTION_ASSIGN}.process_assign */
void F850_6502 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(3330,F145_3330, (Current));
	tb1 = F648_5596(RTCW(tr1), tr2);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = RTOSCF(3330,F145_3330, (Current));
		loc2 = F648_5594(RTCW(tr1), tr2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(3332,F145_3332, (Current));
	tb1 = F648_5596(RTCW(tr1), tr2);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = RTOSCF(3332,F145_3332, (Current));
		loc1 = F648_5594(RTCW(tr1), tr2);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = RTOSCF(3333,F145_3333, (Current));
		tb1 = F648_5596(RTCW(tr1), tr2);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			tr2 = RTOSCF(3333,F145_3333, (Current));
			loc3 = F648_5594(RTCW(tr1), tr2);
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(loc3 == NULL)) {
				tb2 = F489_5229(RTCW(loc3));
				tb1 = tb2;
			}
			if (tb1) {
				loc1 = (EIF_REFERENCE) NULL;
			} else {
				loc1 = F847_6465(Current, loc3);
				if ((EIF_BOOLEAN)(loc1 == NULL)) {
				}
			}
		}
	}
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tr1 = RTOSCF(3463,F160_3463, (Current));
			tr2 = RTCCL(loc1);
			F25_713(RTCW(tr1), tr2, loc2);
		}
	}
	RTLE;
}

void EIF_Minit326 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
