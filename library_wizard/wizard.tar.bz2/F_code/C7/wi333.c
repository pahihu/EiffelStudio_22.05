/*
 * Code for class WIZARD_PAGE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi333.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_PAGE}.make */
void F857_6529 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,656,0xFF01,266,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F657_5719(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(831, 1).id);
	F832_6327(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,653,0xFF01,273,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F654_5700(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1052, 1).id);
	F1052_9284(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,678,0xFF01,0xFFF9,0,966,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F679_5836(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {WIZARD_PAGE}.field_value */
EIF_REFERENCE F857_6539 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	Result = F832_6329(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {WIZARD_PAGE}.has_header */
EIF_BOOLEAN F857_6541 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\01';
	if (!(EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL) || (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) != NULL))) {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tb2 = F483_5229(loc1);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {WIZARD_PAGE}.has_error */
EIF_BOOLEAN F857_6543 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		loc2 = F657_5733(loc1);
		tb1 = EIF_FALSE;
		for (;;) {
			if (tb1) break;
			tb2 = F779_6230(loc2);
			if (tb2) break;
			tr1 = F779_6221(loc2);
			ti4_1 = eif_integer_32_item(RTCW(tr1),2);
			tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 3L));
			F779_6236(loc2);
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {WIZARD_PAGE}.set_data */
void F857_6546 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
	F857_6572(Current);
	RTLE;
}

/* {WIZARD_PAGE}.set_title */
void F857_6547 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	} else {
		tr1 = RTLNSMART(eif_new_type(1049, 0).id);
		F1050_9168(RTCW(tr1), arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {WIZARD_PAGE}.set_subtitle */
void F857_6548 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	} else {
		tr1 = RTLNSMART(eif_new_type(1049, 0).id);
		F1050_9168(RTCW(tr1), arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {WIZARD_PAGE}.set_previous_page */
void F857_6549 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {WIZARD_PAGE}.set_validation */
void F857_6550 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

/* {WIZARD_PAGE}.extend */
void F857_6551 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4939[Dtype(RTCW(tr1))-638])(tr1, arg1);
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(273, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr2 = *(EIF_REFERENCE *)(loc1);
		F648_5635(RTCW(tr1), loc1, tr2);
	}
	RTLE;
}

/* {WIZARD_PAGE}.add_section_text */
void F857_6552 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F857_6561(Current, arg1);
	F857_6551(Current, tr1);
	RTLE;
}

/* {WIZARD_PAGE}.add_text */
void F857_6553 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F857_6562(Current, arg1);
	F857_6551(Current, tr1);
	RTLE;
}

/* {WIZARD_PAGE}.new_section_item */
EIF_REFERENCE F857_6561 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(267, 0x01).id, 267, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F268_4614(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {WIZARD_PAGE}.new_text_item */
EIF_REFERENCE F857_6562 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(268, 0x01).id, 268, _OBJSIZ_2_1_0_0_0_0_0_0_);
	F269_4619(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {WIZARD_PAGE}.new_fixed_size_text_item */
EIF_REFERENCE F857_6563 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(268, 0x01).id, 268, _OBJSIZ_2_1_0_0_0_0_0_0_);
	F269_4619(RTCW(Result), arg1);
	F269_4624(RTCW(Result), (EIF_BOOLEAN) 1);
	RTLE;
	return Result;
}

/* {WIZARD_PAGE}.validate */
void F857_6570 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	F857_6573(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc2 = F648_5603(RTCW(tr1));
	for (;;) {
		tb1 = F773_6218(loc2);
		if (tb1) break;
		loc1 = F773_6215(loc2);
		F274_4646(RTCW(loc1), Current);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4513[Dtype(RTCW(loc1))-283])(loc1);
		tr3 = *(EIF_REFERENCE *)(RTCW(loc1));
		F832_6338(RTCW(tr1), tr2, tr3);
		F773_6219(loc2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc3+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(loc3+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(loc3 + _REFACS_1_), Current);
	}
	RTLE;
}

/* {WIZARD_PAGE}.apply_data */
void F857_6572 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5262[Dtype(RTCW(tr1))-678])(tr1, NULL);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc2 = F648_5603(RTCW(tr1));
	for (;;) {
		tb1 = F773_6218(loc2);
		if (tb1) break;
		loc1 = F773_6215(loc2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = *(EIF_REFERENCE *)(RTCW(loc1));
		tr1 = F832_6329(RTCW(tr1), tr2);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4514[Dtype(RTCW(loc1))-283])(loc1, loc3);
		}
		F773_6219(loc2);
	}
	RTLE;
}

/* {WIZARD_PAGE}.reset_reports */
void F857_6573 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) NULL;
}

/* {WIZARD_PAGE}.report */
void F857_6575 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,arg1);
	RTLR(4,loc2);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {656,0xFF01,0xFFF9,2,966,0xFF01,1049,984,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F657_5719(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) loc1;
	}
	loc3 = arg1;
	loc3 = RTRV(eif_new_type(1049, 0x01),loc3);
	if (EIF_TEST(loc3)) {
		loc2 = (EIF_REFERENCE) loc3;
	} else {
		loc2 = RTLNS(eif_new_type(1049, 0x01).id, 1049, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1050_9168(RTCW(loc2), arg1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,1049,984,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = loc2;
	RTAR(tr1,loc2);
	((EIF_TYPED_VALUE *)tr1+2)->it_i4 = arg2;
	F657_5759(RTCW(loc1), tr1);
	RTLE;
}

/* {WIZARD_PAGE}.report_error */
void F857_6578 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F857_6575(Current, arg1, ((EIF_INTEGER_32) 3L));
}

void EIF_Minit333 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
