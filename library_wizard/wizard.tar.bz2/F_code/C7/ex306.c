/*
 * Code for class EXECUTION_ENVIRONMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ex306.h"
#include "eif_path_name.h"
#include <stdlib.h>
#include "eif_dir.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F704_6042
static EIF_POINTER inline_F704_6042 (EIF_POINTER arg1)
{
	#ifdef EIF_WINDOWS
	return _wgetenv ((EIF_NATIVE_CHAR *) arg1);
#else
	return getenv ((EIF_NATIVE_CHAR *) arg1);
#endif
	;
}
#define INLINE_F704_6042
#endif
#ifndef INLINE_F704_6043
static EIF_INTEGER_32 inline_F704_6043 (EIF_POINTER arg1)
{
	#ifdef EIF_WINDOWS
	return _wputenv ((EIF_NATIVE_CHAR *) arg1);
#else
	return putenv ((EIF_NATIVE_CHAR *) arg1);
#endif
	;
}
#define INLINE_F704_6043
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EXECUTION_ENVIRONMENT}.arguments */
static EIF_REFERENCE F704_6014_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6014);
#define Result RTOSR(6014)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(327, 0x01).id, 327, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6014);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F704_6014 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6014,F704_6014_body,(Current));
}

/* {EXECUTION_ENVIRONMENT}.current_working_path */
EIF_REFERENCE F704_6016 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 50L);
	loc3 = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_0_1_0_1_0_1_1_0_);
	F915_6793(RTCW(loc3), loc1);
	tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	loc2 = (EIF_INTEGER_32) eif_dir_current((EIF_FILENAME) tp1, (EIF_INTEGER) loc1);
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) -1L))) {
		Result = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
		tr1 = RTMS_EX_H(".",1,46);
		F932_7662(RTCW(Result), tr1);
	} else {
		if ((EIF_BOOLEAN) (loc2 > loc1)) {
			loc1 = (EIF_INTEGER_32) loc2;
			F915_6883(RTCW(loc3), loc1);
			tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
			loc2 = (EIF_INTEGER_32) eif_dir_current((EIF_FILENAME) tp1, (EIF_INTEGER) loc1);
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc2 <= loc1))) {
			Result = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
			tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
			F932_7666(RTCW(Result), tp1);
		} else {
			Result = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
			tr1 = RTMS_EX_H(".",1,46);
			F932_7662(RTCW(Result), tr1);
		}
	}
	RTLE;
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.item */
EIF_REFERENCE F704_6020 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(700, 0x01).id, 700, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F701_5934(RTCW(loc1), arg1);
	tp1 = F701_5941(RTCW(loc1));
	loc2 = inline_F704_6042(tp1);
	tb1 = !loc2;
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTLNS(eif_new_type(700, 0x01).id, 700, _OBJSIZ_1_0_0_1_0_0_0_0_);
		F701_5936(RTCW(tr1), loc2);
		Result = F701_5939(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.home_directory_path */
static EIF_REFERENCE F704_6021_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,loc3);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (6021);
#define Result RTOSR(6021)
	RTOC_NEW(Result);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 50L);
	loc3 = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_0_1_0_1_0_1_1_0_);
	F915_6793(RTCW(loc3), loc1);
	tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	loc2 = (EIF_INTEGER_32) eif_home_directory_name_ptr((EIF_FILENAME) tp1, (EIF_INTEGER) loc1);
	if ((EIF_BOOLEAN) (loc2 > loc1)) {
		loc1 = (EIF_INTEGER_32) loc2;
		F915_6883(RTCW(loc3), loc1);
		tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
		loc2 = (EIF_INTEGER_32) eif_home_directory_name_ptr((EIF_FILENAME) tp1, (EIF_INTEGER) loc1);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc2 <= loc1))) {
		tr1 = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
		tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
		F932_7666(RTCW(tr1), tp1);
		Result = (EIF_REFERENCE) tr1;
	}
	RTOSE (6021);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F704_6021 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6021,F704_6021_body,(Current));
}

/* {EXECUTION_ENVIRONMENT}.user_directory_path */
static EIF_REFERENCE F704_6022_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	

	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc4);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (6022);
#define Result RTOSR(6022)
	RTOC_NEW(Result);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 50L);
	loc3 = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_0_1_0_1_0_1_1_0_);
	F915_6793(RTCW(loc3), ((EIF_INTEGER_32) 50L));
	tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	loc2 = (EIF_INTEGER_32) eif_user_directory_name_ptr((EIF_FILENAME) tp1, (EIF_INTEGER) loc1);
	if ((EIF_BOOLEAN) (loc2 > loc1)) {
		loc1 = (EIF_INTEGER_32) loc2;
		F915_6883(RTCW(loc3), loc1);
		tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
		loc2 = (EIF_INTEGER_32) eif_user_directory_name_ptr((EIF_FILENAME) tp1, (EIF_INTEGER) loc1);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc2 <= loc1))) {
		tr1 = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
		tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
		F932_7666(RTCW(tr1), tp1);
		Result = (EIF_REFERENCE) tr1;
	}
	tb1 = '\0';
	if ((EIF_BOOLEAN)(Result != NULL)) {
		tb2 = F932_7670(RTCW(Result));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
	} else {
		tb1 = '\0';
		tb2 = (EIF_BOOLEAN) EIF_TEST(eif_home_dir_supported());
		if (tb2) {
			tr1 = RTOSCF(6021,F704_6021, (Current));
			loc4 = tr1;
			tb1 = EIF_TEST(loc4);
		}
		if (tb1) {
			Result = (EIF_REFERENCE) loc4;
		} else {
			Result = (EIF_REFERENCE) NULL;
		}
	}
	RTOSE (6022);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F704_6022 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6022,F704_6022_body,(Current));
}

/* {EXECUTION_ENVIRONMENT}.put */
void F704_6033 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLR(5,tr1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7524[Dtype(RTCW(arg1))-1049])(arg1);
	ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7524[Dtype(RTCW(arg2))-1049])(arg2);
	F1049_9115(RTCW(loc1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + ((EIF_INTEGER_32) 1L)));
	F1051_9229(RTCW(loc1), arg2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
	F1051_9243(RTCW(loc1), tw1);
	F1051_9229(RTCW(loc1), arg1);
	loc2 = RTLNS(eif_new_type(700, 0x01).id, 700, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F701_5934(RTCW(loc2), loc1);
	tr1 = RTOSCF(6037,F704_6037, (Current));
	tr2 = RTLNS(eif_new_type(1049, 0x01).id, 1049, _OBJSIZ_1_0_0_4_0_0_0_0_);
	F1050_9168(RTCW(tr2), arg2);
	F648_5635(RTCW(tr1), loc2, tr2);
	tp1 = F701_5941(RTCW(loc2));
	ti4_1 = inline_F704_6043(tp1);
	*(EIF_INTEGER_32 *)(Current + O5413[Dtype(Current)-703]) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {EXECUTION_ENVIRONMENT}.sleep */
void F704_6036 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	
	
	eif_sleep(arg1);
}

/* {EXECUTION_ENVIRONMENT}.environ */
static EIF_REFERENCE F704_6037_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (6037);
#define Result RTOSR(6037)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,647,0xFF01,700,0xFF01,1049,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 647, _OBJSIZ_7_3_0_7_0_0_0_0_);
	}
	F648_5588(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6037);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F704_6037 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6037,F704_6037_body,(Current));
}

/* {EXECUTION_ENVIRONMENT}.eif_dir_current */
EIF_INTEGER_32 F704_6041 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_dir_current((EIF_FILENAME) arg1, (EIF_INTEGER) arg2);
	
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.eif_getenv */
EIF_POINTER F704_6042 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F704_6042 ((EIF_POINTER) arg1);
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.eif_putenv */
EIF_INTEGER_32 F704_6043 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F704_6043 ((EIF_POINTER) arg1);
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.eif_home_directory_name_ptr */
EIF_INTEGER_32 F704_6047 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_home_directory_name_ptr((EIF_FILENAME) arg1, (EIF_INTEGER) arg2);
	
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.eif_user_directory_name_ptr */
EIF_INTEGER_32 F704_6048 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_user_directory_name_ptr((EIF_FILENAME) arg1, (EIF_INTEGER) arg2);
	
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.eif_sleep */
void F704_6050 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	
	
	EIF_ENTER_C;eif_sleep(arg1);
	
	EIF_EXIT_C;
	RTGC;
}

void EIF_Minit306 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
