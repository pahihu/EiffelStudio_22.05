/*
 * Code for class TEMPLATE_STRUCTURE_ACTION_HTMLENTITIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "te331.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TEMPLATE_STRUCTURE_ACTION_HTMLENTITIES}.process */
void F855_6525 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (TEMPLATE_STRUCTURE_ITEM.process) */
		/* END INLINED CODE */
	}
	;
	F855_6526(Current);
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ACTION_HTMLENTITIES}.process_htmlentities */
void F855_6526 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	struct eif_ex_49 sloc2;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) sloc2.data;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	memset (&sloc2.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc2.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc2.overhead, eif_new_type(51, 0x00).id);
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = F849_6499(Current);
	tr1 = F849_6500(Current, tr1, (EIF_BOOLEAN) 0);
	loc3 = F52_1226(RTCW(loc2), tr1);
	tr1 = RTLNS(eif_new_type(252, 0x01).id, 252, _OBJSIZ_0_1_0_0_0_0_0_0_);
	loc1 = F253_4305(RTCW(tr1), loc3);
	F847_6482(Current, loc1);
	RTLE;
}

void EIF_Minit331 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
