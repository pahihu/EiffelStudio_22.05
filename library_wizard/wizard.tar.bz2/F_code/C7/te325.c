/*
 * Code for class TEMPLATE_STRUCTURE_ACTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "te325.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TEMPLATE_STRUCTURE_ACTION}.make */
void F849_6492 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F847_6449(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,653,0xFF01,1053,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F648_5588(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ACTION}.is_literal_action */
EIF_BOOLEAN F849_6493 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {TEMPLATE_STRUCTURE_ACTION}.get_output */
void F849_6494 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F847_6472(Current);
}

/* {TEMPLATE_STRUCTURE_ACTION}.set_action_name */
void F849_6497 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {TEMPLATE_STRUCTURE_ACTION}.add_parameter */
void F849_6498 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	F648_5634(RTCW(tr1), arg1, arg2);
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ACTION}.inside_text */
EIF_REFERENCE F849_6499 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F25_702(RTCV(RTOSCF(3463,F160_3463, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = F847_6456(Current);
		ti4_2 = F847_6457(Current);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7565[Dtype(loc1)-1049])(loc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (ti4_2 - ((EIF_INTEGER_32) 1L)));
		Result = F1046_9038(RTCW(tr1));
	} else {
		Result = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1046_8985(RTCW(Result));
	}
	RTLE;
	return Result;
}

/* {TEMPLATE_STRUCTURE_ACTION}.foreach_iteration_string */
EIF_REFERENCE F849_6500 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc6);
	RTLR(2,arg1);
	RTLR(3,loc7);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc8);
	RTLIU(8);
	
	RTGC;
	if ((EIF_BOOLEAN) !arg2) {
		loc5 = F847_6456(Current);
		loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 0L) - loc5);
	}
	loc6 = F1_14(arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc7 = F657_5733(RTCW(tr1));
	for (;;) {
		tb1 = F779_6230(loc7);
		if (tb1) break;
		loc3 = F779_6221(loc7);
		loc1 = F847_6455(RTCW(loc3));
		loc2 = F847_6456(RTCW(loc3));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5734[Dtype(RTCW(loc3))-846])(loc3);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5736[Dtype(RTCW(loc3))-846])(loc3);
		loc4 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_7_);
		if ((EIF_BOOLEAN)(loc4 == NULL)) {
			loc4 = RTMS_EX_H("",0,0);
		}
		loc8 = loc3;
		loc8 = RTRV(eif_new_type(848, 0x01),loc8);
		if (EIF_TEST(loc8)) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(loc3) + O5717[Dtype(loc3)-846]);
			if (tb2) {
				loc2 = F847_6458(RTCW(loc3));
			}
			F1054_9371(RTCW(loc6), loc4, (EIF_INTEGER_32) (loc5 + loc1), (EIF_INTEGER_32) (loc5 + loc2));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4) + O7723[Dtype(loc4)-1051]);
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + ti4_1) - ((EIF_INTEGER_32) 1L)) - (EIF_INTEGER_32) (loc2 - loc1));
		} else {
			F1054_9371(RTCW(loc6), loc4, (EIF_INTEGER_32) (loc5 + loc1), (EIF_INTEGER_32) (loc5 + loc2));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4) + O7723[Dtype(loc4)-1051]);
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + ti4_1) - ((EIF_INTEGER_32) 1L)) - (EIF_INTEGER_32) (loc2 - loc1));
			tb2 = *(EIF_BOOLEAN *)(RTCW(loc3) + O5717[Dtype(loc3)-846]);
			if (tb2) {
				loc1 = F847_6457(RTCW(loc3));
				loc2 = F847_6458(RTCW(loc3));
				tr1 = RTMS_EX_H("",0,0);
				F1054_9371(RTCW(loc6), tr1, (EIF_INTEGER_32) (loc5 + loc1), (EIF_INTEGER_32) (loc5 + loc2));
				loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 - ((EIF_INTEGER_32) 1L)) - (EIF_INTEGER_32) (loc2 - loc1));
			}
		}
		F779_6236(loc7);
	}
	RTLE;
	return (EIF_REFERENCE) loc6;
}

void EIF_Minit325 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
