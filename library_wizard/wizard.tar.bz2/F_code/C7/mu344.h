
#ifndef _C7_mu344_
#define _C7_mu344_

#ifdef __cplusplus
extern "C" {
#endif

extern void F913_6718(EIF_REFERENCE);
extern EIF_BOOLEAN F913_6720(EIF_REFERENCE);
extern void F913_6721(EIF_REFERENCE);
extern EIF_BOOLEAN F913_6722(EIF_REFERENCE);
extern void F913_6723(EIF_REFERENCE);
extern void F913_6724(EIF_REFERENCE);
extern void F913_6727(EIF_REFERENCE);
extern EIF_POINTER F913_6729(EIF_REFERENCE);
extern void F913_6730(EIF_REFERENCE, EIF_POINTER);
extern void F913_6731(EIF_REFERENCE, EIF_POINTER);
extern EIF_BOOLEAN F913_6732(EIF_REFERENCE, EIF_POINTER);
extern void F913_6733(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit344(void);

#ifdef __cplusplus
}
#endif

#endif
