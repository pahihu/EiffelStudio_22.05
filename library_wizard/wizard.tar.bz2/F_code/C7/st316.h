
#ifndef _C7_st316_
#define _C7_st316_

#ifdef __cplusplus
extern "C" {
#endif

extern void F804_6253(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F804_6254(EIF_REFERENCE);
extern EIF_REFERENCE F804_6255(EIF_REFERENCE);
extern EIF_REFERENCE F804_6257(EIF_REFERENCE);
extern EIF_INTEGER_32 F804_6258(EIF_REFERENCE);
extern void EIF_Minit316(void);
extern EIF_INTEGER_32 F1052_9335(EIF_REFERENCE);
extern char *(*R7721[])();

#ifdef __cplusplus
}
#endif

#endif
