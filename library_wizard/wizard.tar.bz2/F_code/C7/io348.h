
#ifndef _C7_io348_
#define _C7_io348_

#ifdef __cplusplus
extern "C" {
#endif

extern void F917_6933(EIF_REFERENCE);
extern void EIF_Minit348(void);
extern EIF_BOOLEAN F919_7141(EIF_REFERENCE);
extern void F919_7169(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
