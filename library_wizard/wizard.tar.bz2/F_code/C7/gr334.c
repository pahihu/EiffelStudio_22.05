/*
 * Code for class GRAPHICAL_WIZARD_PAGE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gr334.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GRAPHICAL_WIZARD_PAGE}.reuse */
void F858_6582 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = F657_5733(RTCW(tr1));
	for (;;) {
		tb1 = F779_6230(loc1);
		if (tb1) break;
		tr1 = F779_6221(loc1);
		F858_6589(Current, tr1);
		F779_6236(loc1);
	}
	RTLE;
}

/* {GRAPHICAL_WIZARD_PAGE}.new_string_question */
EIF_REFERENCE F858_6583 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(283, 0x01).id, 283, _OBJSIZ_8_0_0_0_0_0_0_0_);
	F281_4677(RTCW(tr1), arg2, arg1, arg3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {GRAPHICAL_WIZARD_PAGE}.new_directory_question */
EIF_REFERENCE F858_6584 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(284, 0x01).id, 284, _OBJSIZ_7_0_0_0_0_0_0_0_);
	F281_4677(RTCW(tr1), arg2, arg1, arg3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {GRAPHICAL_WIZARD_PAGE}.unparent */
void F858_6589 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(270, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4495[Dtype(loc1)-272])(loc1);
		tr1 = F1127_10187(RTCW(tr1));
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4495[Dtype(loc1)-272])(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8397[Dtype(loc2)-1132])(loc2, tr1);
	}
	RTLE;
}

void EIF_Minit334 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
