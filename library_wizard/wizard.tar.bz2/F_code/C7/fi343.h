
#ifndef _C7_fi343_
#define _C7_fi343_

#ifdef __cplusplus
extern "C" {
#endif

extern void F912_6709(EIF_REFERENCE);
extern void F912_6710(EIF_REFERENCE, EIF_REFERENCE);
extern void F912_6711(EIF_REFERENCE);
extern EIF_CHARACTER_8 F912_6712(EIF_REFERENCE);
extern EIF_BOOLEAN F912_6714(EIF_REFERENCE);
extern void F912_6715(EIF_REFERENCE);
extern void F912_6716(EIF_REFERENCE);
extern void EIF_Minit343(void);

#ifdef __cplusplus
}
#endif

#endif
