
#ifndef _C7_te327_
#define _C7_te327_

#ifdef __cplusplus
extern "C" {
#endif

extern void F851_6503(EIF_REFERENCE);
extern EIF_BOOLEAN F851_6504(EIF_REFERENCE);
extern void F851_6505(EIF_REFERENCE);
extern void EIF_Minit327(void);
extern EIF_REFERENCE F849_6499(EIF_REFERENCE);
extern void F847_6482(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
