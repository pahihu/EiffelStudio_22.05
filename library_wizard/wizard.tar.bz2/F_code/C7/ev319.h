
#ifndef _C7_ev319_
#define _C7_ev319_

#ifdef __cplusplus
extern "C" {
#endif

extern void F831_6311(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F831_6316(EIF_REFERENCE);
extern EIF_INTEGER_32 F831_6318(EIF_REFERENCE);
extern void EIF_Minit319(void);

#ifdef __cplusplus
}
#endif

#endif
