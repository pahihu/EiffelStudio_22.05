/*
 * Code for class RANDOM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ra311.h"
#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RANDOM}.set_seed */
void F722_6086 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {RANDOM}.modulus */
static EIF_INTEGER_32 F722_6088_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (6088);
#define Result RTOSR(6088)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	RTOSE (6088);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F722_6088 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6088,F722_6088_body,(Current));
}

/* {RANDOM}.multiplier */
static EIF_INTEGER_32 F722_6089_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (6089);
#define Result RTOSR(6089)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16807L);
	RTOSE (6089);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F722_6089 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6089,F722_6089_body,(Current));
}

/* {RANDOM}.increment */
static EIF_INTEGER_32 F722_6090_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (6090);
#define Result RTOSR(6090)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTOSE (6090);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F722_6090 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6090,F722_6090_body,(Current));
}

/* {RANDOM}.has */
EIF_BOOLEAN F722_6093 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) (arg1 < RTOSCF(6088,F722_6088, (Current)))) {
		Result = (EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 0L));
	}
	RTLE;
	return Result;
}

/* {RANDOM}.i_th */
EIF_INTEGER_32 F722_6094 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_))) {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_);
	} else {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_);
	}
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == arg1)) break;
		ti4_1 = F722_6100(Current, Result);
		Result = (EIF_INTEGER_32) ti4_1;
		loc1++;
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_) = (EIF_INTEGER_32) Result;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_) = (EIF_INTEGER_32) arg1;
	RTLE;
	return Result;
}

/* {RANDOM}.new_cursor */
EIF_REFERENCE F722_6099 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(721, 0x01).id, 721, _OBJSIZ_0_1_0_4_0_0_0_0_);
	F722_6086(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_));
	F482_5219(RTCW(Result));
	RTLE;
	return Result;
}

/* {RANDOM}.randomize */
EIF_INTEGER_32 F722_6100 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_64 tr8_4;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tr8_1 = RTOSCF(6105,F722_6105, (Current));
	tr8_2 = (EIF_REAL_64) (arg1);
	tr8_3 = RTOSCF(6106,F722_6106, (Current));
	tr8_4 = RTOSCF(6104,F722_6104, (Current));
	tr8_1 = F722_6101(Current, (EIF_REAL_64) ((EIF_REAL_64) (tr8_1 * tr8_2) + tr8_3), tr8_4);
	Result = (EIF_INTEGER_32) tr8_1;
	RTLE;
	return Result;
}

/* {RANDOM}.double_mod */
EIF_REAL_64 F722_6101 (EIF_REFERENCE Current, EIF_REAL_64 arg1, EIF_REAL_64 arg2)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	
	RTGC;
	Result = (EIF_REAL_64) floor((double) (EIF_REAL_64) ((EIF_REAL_64) (arg1) /  (EIF_REAL_64) (arg2)));
	Result = (EIF_REAL_64) (EIF_REAL_64) (arg1 - (EIF_REAL_64) (Result * arg2));
	return Result;
}

/* {RANDOM}.dmod */
static EIF_REAL_64 F722_6104_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6104);
#define Result RTOSR(6104)
	Result = (EIF_REAL_64) (RTOSCF(6088,F722_6088, (Current)));
	RTOSE (6104);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F722_6104 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6104,F722_6104_body,(Current));
}

/* {RANDOM}.dmul */
static EIF_REAL_64 F722_6105_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6105);
#define Result RTOSR(6105)
	Result = (EIF_REAL_64) (RTOSCF(6089,F722_6089, (Current)));
	RTOSE (6105);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F722_6105 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6105,F722_6105_body,(Current));
}

/* {RANDOM}.dinc */
static EIF_REAL_64 F722_6106_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6106);
#define Result RTOSR(6106)
	Result = (EIF_REAL_64) (RTOSCF(6090,F722_6090, (Current)));
	RTOSE (6106);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F722_6106 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6106,F722_6106_body,(Current));
}

void EIF_Minit311 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
