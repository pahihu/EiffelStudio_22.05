/*
 * Code for class TEMPLATE_STRUCTURE_ACTION_FOREACH
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "te328.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TEMPLATE_STRUCTURE_ACTION_FOREACH}.process */
void F852_6506 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (TEMPLATE_STRUCTURE_ITEM.process) */
		/* END INLINED CODE */
	}
	;
	F852_6510(Current);
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ACTION_FOREACH}.get_output */
void F852_6507 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F849_6494(Current);
}

/* {TEMPLATE_STRUCTURE_ACTION_FOREACH}.process_foreach */
void F852_6510 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc3);
	RTLR(4,loc2);
	RTLR(5,loc1);
	RTLR(6,loc4);
	RTLR(7,loc6);
	RTLR(8,loc5);
	RTLR(9,loc8);
	RTLR(10,loc9);
	RTLR(11,loc7);
	RTLIU(12);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(3336,F145_3336, (Current));
	tb1 = F648_5596(RTCW(tr1), tr2);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = RTOSCF(3336,F145_3336, (Current));
		loc3 = F648_5594(RTCW(tr1), tr2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(3335,F145_3335, (Current));
	tb1 = F648_5596(RTCW(tr1), tr2);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = RTOSCF(3335,F145_3335, (Current));
		loc2 = F648_5594(RTCW(tr1), tr2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(3334,F145_3334, (Current));
	tb1 = F648_5596(RTCW(tr1), tr2);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = RTOSCF(3334,F145_3334, (Current));
		loc1 = F648_5594(RTCW(tr1), tr2);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = RTOSCF(3333,F145_3333, (Current));
		tb1 = F648_5596(RTCW(tr1), tr2);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			tr2 = RTOSCF(3333,F145_3333, (Current));
			loc1 = F648_5594(RTCW(tr1), tr2);
		}
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		loc4 = F847_6464(Current, loc1);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			loc6 = (EIF_REFERENCE) NULL;
			loc5 = (EIF_REFERENCE) NULL;
			loc8 = RTCCL(loc4);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,328,0,0xFF01,929,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc8 = RTRV(typres0,loc8);
			}
			if (EIF_TEST(loc8)) {
				loc6 = (EIF_REFERENCE) loc8;
			} else {
				loc9 = RTCCL(loc4);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,314,0,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					loc9 = RTRV(typres0,loc9);
				}
				if (EIF_TEST(loc9)) {
					loc5 = (EIF_REFERENCE) loc9;
				}
			}
		}
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc6 != NULL) && (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 != NULL) || (EIF_BOOLEAN)(loc2 != NULL)))) {
		loc7 = F852_6511(Current, loc6, loc3, loc2);
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 != NULL) && (EIF_BOOLEAN)(loc2 != NULL))) {
			loc7 = F852_6512(Current, loc5, loc3, loc2);
		}
	}
	if ((EIF_BOOLEAN)(loc7 != NULL)) {
		F847_6482(Current, loc7);
	}
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ACTION_FOREACH}.foreach_hash_any_hashable_output */
EIF_REFERENCE F852_6511 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(11);
	RTLR(0,Result);
	RTLR(1,loc4);
	RTLR(2,arg1);
	RTLR(3,arg3);
	RTLR(4,loc2);
	RTLR(5,Current);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,arg2);
	RTLR(9,loc3);
	RTLR(10,loc1);
	RTLIU(11);
	
	RTGC;
	Result = RTMS_EX_H("",0,0);
	loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4755[Dtype(RTCW(arg1))-327])(arg1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5445[Dtype(loc4)-720])(loc4);
		if (tb1) break;
		if ((EIF_BOOLEAN)(arg3 != NULL)) {
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5444[Dtype(loc4)-720])(loc4);
			tr1 = RTOSCF(3463,F160_3463, (Current));
			tr2 = RTCCL(loc2);
			F25_711(RTCW(tr1), tr2, arg3);
		}
		if ((EIF_BOOLEAN)(arg2 != NULL)) {
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5504[Dtype(loc4)-772])(loc4);
			tr1 = RTOSCF(3463,F160_3463, (Current));
			tr2 = RTCCL(loc3);
			F25_711(RTCW(tr1), tr2, arg2);
		}
		tr1 = F849_6499(Current);
		loc1 = F849_6500(Current, tr1, (EIF_BOOLEAN) 0);
		F1054_9397(RTCW(Result), loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5446[Dtype(loc4)-720])(loc4);
	}
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		tr1 = RTOSCF(3463,F160_3463, (Current));
		F25_712(RTCW(tr1), arg3);
	}
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tr1 = RTOSCF(3463,F160_3463, (Current));
		F25_712(RTCW(tr1), arg2);
	}
	RTLE;
	return Result;
}

/* {TEMPLATE_STRUCTURE_ACTION_FOREACH}.foreach_list_any_output */
EIF_REFERENCE F852_6512 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(10);
	RTLR(0,Result);
	RTLR(1,loc4);
	RTLR(2,arg1);
	RTLR(3,arg3);
	RTLR(4,loc2);
	RTLR(5,Current);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,arg2);
	RTLR(9,loc1);
	RTLIU(10);
	
	RTGC;
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	Result = RTMS_EX_H("",0,0);
	loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4755[Dtype(RTCW(arg1))-327])(arg1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5445[Dtype(loc4)-720])(loc4);
		if (tb1) break;
		loc3++;
		if ((EIF_BOOLEAN)(arg3 != NULL)) {
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5444[Dtype(loc4)-720])(loc4);
			tr1 = RTOSCF(3463,F160_3463, (Current));
			tr2 = RTCCL(loc2);
			F25_711(RTCW(tr1), tr2, arg3);
		}
		if ((EIF_BOOLEAN)(arg2 != NULL)) {
			tr1 = RTOSCF(3463,F160_3463, (Current));
			tr2 = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_INTEGER_32 *)tr2 = loc3;
			F25_711(RTCW(tr1), tr2, arg2);
		}
		tr1 = F849_6499(Current);
		loc1 = F849_6500(Current, tr1, (EIF_BOOLEAN) 0);
		F1054_9397(RTCW(Result), loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5446[Dtype(loc4)-720])(loc4);
	}
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		tr1 = RTOSCF(3463,F160_3463, (Current));
		F25_712(RTCW(tr1), arg3);
	}
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tr1 = RTOSCF(3463,F160_3463, (Current));
		F25_712(RTCW(tr1), arg2);
	}
	RTLE;
	return Result;
}

void EIF_Minit328 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
