
#ifndef _C7_na302_
#define _C7_na302_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F700_5932(EIF_REFERENCE, EIF_POINTER);
extern EIF_NATURAL_64 F700_5933(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit302(void);

#ifdef __cplusplus
}
#endif

#endif
