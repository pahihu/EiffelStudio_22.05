/*
 * Code for class TEMPLATE_STRUCTURE_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "te323.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TEMPLATE_STRUCTURE_ITEM}.make */
void F847_6449 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,656,0xFF01,846,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F657_5719(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,653,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F648_5588(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,656,0xFF01,575,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F657_5719(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ITEM}.start_index */
EIF_INTEGER_32 F847_6455 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F657_5727(RTCW(tr1));
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_1_0_1_);
	RTLE;
	return Result;
}

/* {TEMPLATE_STRUCTURE_ITEM}.end_index */
EIF_INTEGER_32 F847_6456 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F657_5727(RTCW(tr1));
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_1_0_0_);
	RTLE;
	return Result;
}

/* {TEMPLATE_STRUCTURE_ITEM}.closing_start_index */
EIF_INTEGER_32 F847_6457 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F657_5728(RTCW(tr1));
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_1_0_1_);
	RTLE;
	return Result;
}

/* {TEMPLATE_STRUCTURE_ITEM}.closing_end_index */
EIF_INTEGER_32 F847_6458 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F657_5728(RTCW(tr1));
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_1_0_0_);
	RTLE;
	return Result;
}

/* {TEMPLATE_STRUCTURE_ITEM}.resolved_expression */
EIF_REFERENCE F847_6464 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,Current);
	RTLR(6,tr2);
	RTLR(7,loc4);
	RTLR(8,Result);
	RTLIU(9);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1052_9284(RTCW(loc1), arg1);
	F1054_9379(RTCW(loc1));
	F1054_9380(RTCW(loc1));
	tb1 = F489_5229(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
		tb1 = F1052_9317(RTCW(loc1), (EIF_CHARACTER_8) '.');
		if (tb1) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
			loc2 = F1046_9063(RTCW(loc1), tw1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R4919[Dtype(RTCW(loc2))-638])(loc2);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4953[Dtype(RTCW(loc2))-638])(loc2);
			loc3 = F847_6468(Current, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R4932[Dtype(RTCW(loc2))-638])(loc2);
			for (;;) {
				tb1 = '\01';
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4930[Dtype(RTCW(loc2))-638])(loc2);
				if (!tb2) {
					tb1 = (EIF_BOOLEAN)(loc3 == NULL);
				}
				if (tb1) break;
				tb2 = '\0';
				tb3 = '\0';
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4953[Dtype(RTCW(loc2))-638])(loc2);
				tr2 = RTMS_EX_H("$",1,36);
				tb4 = F1052_9318(RTCW(tr1), tr2);
				if (tb4) {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4953[Dtype(RTCW(loc2))-638])(loc2);
					tr1 = F847_6468(Current, tr1);
					loc4 = RTCCL(tr1);
					loc4 = RTRV(eif_new_type(1045, 0x01),loc4);
					tb3 = EIF_TEST(loc4);
				}
				if (tb3) {
					tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7501[Dtype(loc4)-1049])(loc4);
					tb2 = tb3;
				}
				if (tb2) {
					tr1 = RTCCL(loc3);
					tr2 = F1046_9038(loc4);
					tr1 = F162_3476(Current, tr1, tr2);
					loc3 = (EIF_REFERENCE) RTCCL(tr1);
				} else {
					tr1 = RTCCL(loc3);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4953[Dtype(RTCW(loc2))-638])(loc2);
					tr1 = F162_3476(Current, tr1, tr2);
					loc3 = (EIF_REFERENCE) RTCCL(tr1);
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R4932[Dtype(RTCW(loc2))-638])(loc2);
			}
			RTLE;
			return (EIF_REFERENCE) loc3;
		} else {
			tb2 = '\0';
			tc1 = F1054_9361(RTCW(loc1), ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\'')) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				tc1 = F1054_9361(RTCW(loc1), ti4_1);
				tb2 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\'');
			}
			if (tb2) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				Result = F1054_9442(RTCW(loc1), ((EIF_INTEGER_32) 2L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
			} else {
				Result = F847_6468(Current, loc1);
				RTLE;
				return (EIF_REFERENCE) Result;
			}
		}
	}
	RTLE;
	return Result;
}

/* {TEMPLATE_STRUCTURE_ITEM}.resolved_composed_expression */
EIF_REFERENCE F847_6465 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tb1 = F1052_9317(RTCW(arg1), (EIF_CHARACTER_8) ':');
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) F847_6467(Current, arg1);
	} else {
		RTLE;
		return (EIF_REFERENCE) F847_6464(Current, arg1);
	}/* NOTREACHED */
	
}

/* {TEMPLATE_STRUCTURE_ITEM}.resolved_arguments */
EIF_REFERENCE F847_6466 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,656,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 656, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4965[Dtype(RTCW(arg1))-575])(arg1);
	F657_5719(RTCW(Result), ti4_1);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4755[Dtype(RTCW(arg1))-327])(arg1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5445[Dtype(loc2)-720])(loc2);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5444[Dtype(loc2)-720])(loc2);
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7502[Dtype(RTCW(tr1))-1049])(tr1);
		if (tb2) {
			loc1 = RTMS_EX_H("",0,0);
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5444[Dtype(loc2)-720])(loc2);
			loc1 = F847_6464(Current, tr1);
		}
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5444[Dtype(loc2)-720])(loc2);
		}
		tr1 = RTCCL(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4939[Dtype(RTCW(Result))-638])(Result, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5446[Dtype(loc2)-720])(loc2);
	}
	RTLE;
	return Result;
}

/* {TEMPLATE_STRUCTURE_ITEM}.resolved_concatenation_expression */
EIF_REFERENCE F847_6467 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(11);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,Result);
	RTLR(5,loc5);
	RTLR(6,loc3);
	RTLR(7,loc2);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,loc4);
	RTLIU(11);
	
	RTGC;
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	tr1 = F1046_9063(RTCW(arg1), tw1);
	loc1 = F847_6466(Current, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4919[Dtype(RTCW(loc1))-638])(loc1);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5075[Dtype(RTCW(loc1))-638])(loc1);
	loc5 = RTCCL(Result);
	loc5 = RTRV(eif_new_type(1051, 0x01),loc5);
	if (EIF_TEST(loc5)) {
		loc3 = F1052_9298(loc5);
	} else {
		if ((EIF_BOOLEAN)(Result != NULL)) {
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R28[Dtype(RTCW(Result))-5])(Result);
		}
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4932[Dtype(RTCW(loc1))-638])(loc1);
	for (;;) {
		tb1 = '\01';
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4930[Dtype(RTCW(loc1))-638])(loc1);
		if (!tb2) {
			tb1 = (EIF_BOOLEAN)(Result == NULL);
		}
		if (tb1) break;
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4953[Dtype(RTCW(loc1))-638])(loc1);
		loc6 = RTCCL(Result);
		loc6 = RTRV(eif_new_type(1051, 0x01),loc6);
		if (EIF_TEST(loc6)) {
			loc3 = F1052_9298(loc6);
		} else {
			if ((EIF_BOOLEAN)(Result != NULL)) {
				loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R28[Dtype(RTCW(Result))-5])(Result);
			} else {
				loc3 = (EIF_REFERENCE) NULL;
			}
		}
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			loc7 = RTCCL(loc2);
			loc7 = RTRV(eif_new_type(1051, 0x01),loc7);
			if (EIF_TEST(loc7)) {
				loc4 = (EIF_REFERENCE) loc7;
			} else {
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R28[Dtype(RTCW(loc2))-5])(loc2);
				}
			}
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7713[Dtype(RTCW(loc3))-1052])(loc3, loc4);
			} else {
				Result = (EIF_REFERENCE) NULL;
			}
		} else {
			Result = (EIF_REFERENCE) NULL;
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4932[Dtype(RTCW(loc1))-638])(loc1);
	}
	RTLE;
	return Result;
}

/* {TEMPLATE_STRUCTURE_ITEM}.resolved_variable */
EIF_REFERENCE F847_6468 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1052_9284(RTCW(loc1), arg1);
	F1054_9379(RTCW(loc1));
	F1054_9380(RTCW(loc1));
	RTLE;
	return (EIF_REFERENCE) F847_6469(Current, loc1);
}

/* {TEMPLATE_STRUCTURE_ITEM}.resolved_formatted_variable */
EIF_REFERENCE F847_6469 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	Result = F162_3475(Current, arg1);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		loc1 = F162_3474(Current, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4948[Dtype(RTCW(tr1))-575])(tr1, loc1);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5131[Dtype(RTCW(tr1))-647])(tr1, loc1);
		}
	}
	RTLE;
	return Result;
}

/* {TEMPLATE_STRUCTURE_ITEM}.process */
void F847_6470 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {TEMPLATE_STRUCTURE_ITEM}.get_output */
void F847_6472 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc2;
		}
	}
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ITEM}.set_name */
void F847_6473 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {TEMPLATE_STRUCTURE_ITEM}.set_parent */
void F847_6474 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {TEMPLATE_STRUCTURE_ITEM}.add_indexes */
void F847_6475 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr2 = arg1;
	tr2 = F983_8186(RTCW(tr2), arg2);
	F657_5759(RTCW(tr1), tr2);
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ITEM}.set_is_closed */
void F847_6477 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O5716[Dtype(Current)-846]) = (EIF_BOOLEAN) arg1;
}

/* {TEMPLATE_STRUCTURE_ITEM}.set_closing_indexes */
void F847_6478 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F847_6475(Current, arg1, arg2);
	*(EIF_BOOLEAN *)(Current + O5717[Dtype(Current)-846]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ITEM}.put_item_last */
void F847_6481 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F657_5759(RTCW(tr1), arg1);
	F847_6474(RTCW(arg1), Current);
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ITEM}.set_forced_output */
void F847_6482 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	} else {
		tr1 = F1_14(arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ITEM}.set_error_output */
void F847_6483 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) NULL;
	} else {
		tr1 = F1_14(arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

void EIF_Minit323 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
