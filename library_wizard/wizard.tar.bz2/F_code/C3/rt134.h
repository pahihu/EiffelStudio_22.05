
#ifndef _C3_rt134_
#define _C3_rt134_

#ifdef __cplusplus
extern "C" {
#endif

extern void F149_3359(EIF_REFERENCE);
extern void F149_3360(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F149_3361(EIF_REFERENCE);
extern void EIF_Minit134(void);

#ifdef __cplusplus
}
#endif

#endif
