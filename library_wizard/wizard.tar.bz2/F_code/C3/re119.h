
#ifndef _C3_re119_
#define _C3_re119_

#ifdef __cplusplus
extern "C" {
#endif

extern void F134_3118(EIF_REFERENCE, EIF_REFERENCE);
extern void F134_3119(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit119(void);

#ifdef __cplusplus
}
#endif

#endif
