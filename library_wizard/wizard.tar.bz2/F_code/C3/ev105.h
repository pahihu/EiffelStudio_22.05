
#ifndef _C3_ev105_
#define _C3_ev105_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F120_2966(EIF_REFERENCE);
extern void EIF_Minit105(void);
extern void F679_5836(EIF_REFERENCE);
extern long O2964[];

#ifdef __cplusplus
}
#endif

#endif
