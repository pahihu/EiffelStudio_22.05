/*
 * Code for class EV_SIMPLE_HELP_ENGINE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev141.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SIMPLE_HELP_ENGINE}.help_title */

EIF_REFERENCE F156_3449 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (3449,RTMS_EX_H("Contextual Help",15,712875120));
}

/* {EV_SIMPLE_HELP_ENGINE}.show */
void F156_3450 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1147, 0x01).id, 1147, _OBJSIZ_14_3_0_3_0_0_0_0_);
	F1147_10471(RTCW(loc1), arg1);
	{
		static EIF_TYPE_INDEX typarr0[] = {834,0xFF01,1053,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 1L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F155_3434(Current);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F835_6409)(tr2);
	F1147_10486(RTCW(loc1), tr1);
	tr1 = F155_3434(Current);
	tr1 = F1147_10489(RTCW(loc1), tr1);
	F1145_10456(RTCW(loc1), tr1);
	tr1 = RTOSCF(3449,F156_3449, (Current));
	F1140_10409(RTCW(loc1), tr1);
	F1140_10403(RTCW(loc1));
	F1140_10415(RTCW(loc1));
	RTLE;
}

void EIF_Minit141 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
