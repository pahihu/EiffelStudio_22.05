/*
 * Code for class EV_SHARED_TRANSPORT_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev138.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SHARED_TRANSPORT_I}.default_accept_cursor */
static EIF_REFERENCE F153_3409_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3409);
#define Result RTOSR(3409)
	RTOC_NEW(Result);
	Result = RTOSCF(1012,F42_1012, (RTCV(RTOSCF(3413,F153_3413, (Current)))));
	RTOSE (3409);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F153_3409 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3409,F153_3409_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.default_deny_cursor */
static EIF_REFERENCE F153_3410_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3410);
#define Result RTOSR(3410)
	RTOC_NEW(Result);
	Result = RTOSCF(1016,F42_1016, (RTCV(RTOSCF(3413,F153_3413, (Current)))));
	RTOSE (3410);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F153_3410 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3410,F153_3410_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.default_pixmaps */
static EIF_REFERENCE F153_3413_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3413);
#define Result RTOSR(3413)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(41, 0x01).id, 41, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3413);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F153_3413 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3413,F153_3413_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.insert_label */
static EIF_REFERENCE F153_3419_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (3419);
#define Result RTOSR(3419)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1135, 0x01).id, 1135, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1083_9562(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F1127_10213(RTCW(Result), ((EIF_INTEGER_32) 10L), ((EIF_INTEGER_32) 10L));
	loc1 = RTLNS(eif_new_type(1151, 0x01).id, 1151, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1083_9562(RTCW(loc1));
	F1152_10550(RTCW(loc1), ((EIF_INTEGER_32) 2L), ((EIF_INTEGER_32) 2L));
	tr1 = RTLNS(eif_new_type(39, 0x01).id, 39, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = F40_998(RTCW(tr1));
	F1101_9875(RTCW(loc1), tr1);
	F1115_9993(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	F1115_9993(RTCW(loc1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	tr1 = RTLNS(eif_new_type(39, 0x01).id, 39, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(975,F40_975, (RTCW(tr1)));
	F1101_9875(RTCW(loc1), tr1);
	F1115_9993(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L));
	F1115_9993(RTCW(loc1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 0L));
	F1108_9933(RTCW(Result), loc1);
	RTOSE (3419);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F153_3419 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3419,F153_3419_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.insert_label_imp */
static EIF_REFERENCE F153_3420_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (3420);
#define Result RTOSR(3420)
	RTOC_NEW(Result);
	tr1 = RTOSCF(3419,F153_3419, (Current));
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + O7887[Dtype(tr1)-1082]);
	RTOSE (3420);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F153_3420 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3420,F153_3420_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.remove_insert_label */
void F153_3421 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = F1127_10187(RTCV(RTOSCF(3419,F153_3419, (Current))));
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		loc1 = F1127_10187(RTCV(RTOSCF(3419,F153_3419, (Current))));
		loc1 = RTRV(eif_new_type(1135, 0x00), loc1);
		tr1 = RTOSCF(3419,F153_3419, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8397[Dtype(loc5)-1132])(loc5, tr1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tr1 = RTOSCF(3419,F153_3419, (Current));
			tb2 = (EIF_BOOLEAN) eif_builtin_ANY_same_type__o_b (loc1, tr1);
			tb1 = tb2;
		}
		if (tb1) {
			loc2 = F1127_10187(RTCW(loc1));
			loc2 = RTRV(eif_new_type(1131, 0x00), loc2);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				loc3 = F1125_10138(RTCW(loc2), loc1, ((EIF_INTEGER_32) 1L));
				loc4 = F1132_10291(RTCW(loc2), loc1);
				F1125_10161(RTCW(loc2), loc1);
				F1125_10147(RTCW(loc2), loc3);
				F1125_10156(RTCW(loc2), loc1);
				if ((EIF_BOOLEAN) !loc4) {
					F1132_10298(RTCW(loc2), loc1);
				}
			}
		}
	}
	RTLE;
}

/* {EV_SHARED_TRANSPORT_I}.insert_sep */
static EIF_REFERENCE F153_3422_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3422);
#define Result RTOSR(3422)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1166, 0x01).id, 1166, _OBJSIZ_6_0_0_1_0_0_0_0_);
	F1083_9562(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3422);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F153_3422 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3422,F153_3422_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.remove_insert_sep */
void F153_3424 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1166_10697(RTCV(RTOSCF(3422,F153_3422, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = RTOSCF(3422,F153_3422, (Current));
		F1125_10161(loc1, tr1);
	}
	RTLE;
}

/* {EV_SHARED_TRANSPORT_I}.internal_screen */
static EIF_REFERENCE F153_3426_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3426);
#define Result RTOSR(3426)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1116, 0x01).id, 1116, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1083_9562(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3426);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F153_3426 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3426,F153_3426_body,(Current));
}

void EIF_Minit138 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
