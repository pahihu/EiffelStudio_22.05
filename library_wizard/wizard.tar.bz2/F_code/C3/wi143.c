/*
 * Code for class WIZARD_FAILED_RESPONSE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi143.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_FAILED_RESPONSE}.send */
void F158_3452 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTMS_EX_H("Success=\"no\"\012",13,689235722);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6127[Dtype(RTCW(arg1))-919])(arg1, tr1);
	RTLE;
}

void EIF_Minit143 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
