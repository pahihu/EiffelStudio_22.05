/*
 * Code for class LIBRARY_WIZARD_GENERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li146.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LIBRARY_WIZARD_GENERATOR}.execute */
void F161_3467 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc5);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc3);
	RTLR(9,loc1);
	RTLIU(10);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	tb1 = '\0';
	tr1 = RTMS_EX_H("library:name",12,482663525);
	tr1 = F335_4990(RTCW(arg1), tr1);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tr1 = RTMS_EX_H("library:location",16,695149422);
		tr1 = F335_4990(RTCW(arg1), tr1);
		loc5 = tr1;
		tb1 = EIF_TEST(loc5);
	}
	if (tb1) {
		loc2 = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F932_7662(RTCW(loc2), loc5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7546[Dtype(loc4)-1049])(loc4);
		tr3 = RTMS_EX_H("LIB_NAME",8,1695850053);
		F648_5635(RTCW(tr1), tr2, tr3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = F1046_9044(RTCV(F124_2996(Current)));
		tr3 = RTMS_EX_H("UUID",4,1431652676);
		F648_5635(RTCW(tr1), tr2, tr3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = F1046_9044(RTMS_EX_H("none",4,1852796517));
		tr3 = RTMS_EX_H("CONCURRENCY",11,802402649);
		F648_5635(RTCW(tr1), tr2, tr3);
		loc3 = (EIF_REFERENCE) loc2;
		loc1 = RTLNS(eif_new_type(913, 0x01).id, 913, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F914_6736(RTCW(loc1), loc3);
		tb1 = F914_6759(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			F914_6739(RTCW(loc1));
		}
		tr1 = *(EIF_REFERENCE *)(RTCV(F124_2992(Current)) + _REFACS_2_);
		tr1 = F306_4750(RTCW(tr1));
		F124_3001(Current, tr1, loc3);
		tr1 = RTLNS(eif_new_type(158, 0x01).id, 158, _OBJSIZ_2_2_0_0_0_0_0_0_);
		tr2 = F932_7689(RTCW(loc3), loc4);
		tr3 = RTMS_EX_H("ecf",3,6644582);
		tr2 = F932_7692(RTCW(tr2), tr3);
		tr3 = F914_6740(RTCW(loc1));
		F159_3453(RTCW(tr1), tr2, tr3);
		F124_2995(Current, tr1);
	} else {
		tr1 = RTLNS(eif_new_type(157, 0x01).id, 157, _OBJSIZ_0_0_0_0_0_0_0_0_);
		F124_2995(Current, tr1);
	}
	RTLE;
}

/* {LIBRARY_WIZARD_GENERATOR}.smarty_template_extensions */
static EIF_REFERENCE F161_3468_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (3468);
#define Result RTOSR(3468)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {834,0xFF01,1048,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 2L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1046_9044(RTMS_EX_H("e",1,101));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1046_9044(RTMS_EX_H("ecf",3,6644582));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F835_6409)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3468);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F161_3468 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3468,F161_3468_body,(Current));
}

/* {LIBRARY_WIZARD_GENERATOR}.is_smarty_template_file */
EIF_BOOLEAN F161_3469 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	tr1 = F932_7679(RTCW(arg1));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		loc2 = F578_5354(RTCV(RTOSCF(3468,F161_3468, (Current))));
		tb1 = EIF_FALSE;
		for (;;) {
			if (tb1) break;
			tb2 = F779_6230(loc2);
			if (tb2) break;
			tr1 = F779_6221(loc2);
			tb3 = F1046_9027(RTCW(tr1), loc1);
			tb1 = tb3;
			F779_6236(loc2);
		}
		Result = (EIF_BOOLEAN) tb1;
	}
	RTLE;
	return Result;
}

/* {LIBRARY_WIZARD_GENERATOR}.is_template_file */
EIF_BOOLEAN F161_3470 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F161_3469(Current, arg1);
}

/* {LIBRARY_WIZARD_GENERATOR}.copy_template */
void F161_3471 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	if (F161_3469(Current, arg1)) {
		F161_3472(Current, arg1, arg2);
	} else {
		F124_3002(Current, arg1, arg2);
	}
	RTLE;
}

/* {LIBRARY_WIZARD_GENERATOR}.copy_smarty_template */
void F161_3472 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(13);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc5);
	RTLR(5,Current);
	RTLR(6,loc6);
	RTLR(7,tr2);
	RTLR(8,loc4);
	RTLR(9,loc7);
	RTLR(10,loc8);
	RTLR(11,loc3);
	RTLR(12,arg2);
	RTLIU(13);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(920, 0x01).id, 920, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F921_7364(RTCW(loc2), arg1);
	tb1 = '\0';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6114[Dtype(RTCW(loc2))-919])(loc2);
	if (tb2) {
		tb2 = F919_7120(RTCW(loc2));
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = RTLNS(eif_new_type(163, 0x01).id, 163, _OBJSIZ_5_0_0_0_0_0_0_0_);
		tr1 = F919_7092(RTCW(loc2));
		tr1 = F932_7701(RTCW(tr1));
		F164_3512(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			tr1 = RTMS_EX_H("WIZ",3,5720410);
			F164_3516(RTCW(loc1), loc5, tr1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc6 = F648_5603(RTCW(tr1));
		for (;;) {
			tb1 = F773_6218(loc6);
			if (tb1) break;
			tr1 = F773_6215(loc6);
			tr2 = F773_6216(loc6);
			F164_3516(RTCW(loc1), tr1, tr2);
			F773_6219(loc6);
		}
		tr1 = RTOSCF(3463,F160_3463, (Current));
		tr2 = *(EIF_REFERENCE *)(RTCV(F124_2992(Current)) + _REFACS_2_);
		tr2 = F306_4752(RTCW(tr2));
		F25_709(RTCW(tr1), tr2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,656,0xFF01,164,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc4 = RTLNS(typres0.id, 656, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F657_5719(RTCW(loc4), ((EIF_INTEGER_32) 2L));
		tr1 = RTLNS(eif_new_type(166, 0x01).id, 166, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr2 = RTLNTY2(eif_new_type(334, 0x00), 0x00);
		tr2 = F933_7723(tr2);
		F165_3529(RTCW(tr1), tr2);
		F657_5759(RTCW(loc4), tr1);
		tr1 = RTLNS(eif_new_type(165, 0x01).id, 165, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr2 = RTLNTY2(eif_new_type(831, 0x00), 0x00);
		tr2 = F933_7723(tr2);
		F165_3529(RTCW(tr1), tr2);
		F657_5759(RTCW(loc4), tr1);
		F164_3520(RTCW(loc1));
		F164_3528(RTCW(loc1));
		loc7 = F657_5733(RTCW(loc4));
		for (;;) {
			tb2 = F779_6230(loc7);
			if (tb2) break;
			tr1 = F779_6221(loc7);
			F165_3531(RTCW(tr1));
			F779_6236(loc7);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
		loc8 = tr1;
		if (EIF_TEST(loc8)) {
			loc3 = RTLNS(eif_new_type(920, 0x01).id, 920, _OBJSIZ_5_7_2_4_1_1_2_1_);
			F921_7364(RTCW(loc3), arg2);
			tb3 = '\01';
			tb4 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6114[Dtype(RTCW(loc3))-919])(loc3);
			if (!(EIF_BOOLEAN) !tb4) {
				tb4 = F919_7121(RTCW(loc3));
				tb3 = tb4;
			}
			if (tb3) {
				F919_7156(RTCW(loc3));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6127[Dtype(RTCW(loc3))-919])(loc3, loc8);
				F919_7169(RTCW(loc3));
			}
		} else {
			F124_2997(Current, arg1, arg2);
		}
	}
	RTLE;
}

void EIF_Minit146 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
