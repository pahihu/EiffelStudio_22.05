
#ifndef _C3_wi144_
#define _C3_wi144_

#ifdef __cplusplus
extern "C" {
#endif

extern void F159_3453(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F159_3462(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit144(void);
extern EIF_REFERENCE F1054_9414(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F932_7700(EIF_REFERENCE);
extern char *(*R6127[])();

#ifdef __cplusplus
}
#endif

#endif
