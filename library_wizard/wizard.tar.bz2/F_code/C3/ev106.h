
#ifndef _C3_ev106_
#define _C3_ev106_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F121_2980(EIF_REFERENCE);
extern void EIF_Minit106(void);
extern void F679_5836(EIF_REFERENCE);
extern long O2978[];

#ifdef __cplusplus
}
#endif

#endif
