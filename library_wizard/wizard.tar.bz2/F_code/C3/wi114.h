
#ifndef _C3_wi114_
#define _C3_wi114_

#ifdef __cplusplus
extern "C" {
#endif

extern void F129_3062(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F129_3066(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,3068)
static EIF_REFERENCE F129_3068_body(EIF_REFERENCE);
extern EIF_REFERENCE F129_3068(EIF_REFERENCE);
extern EIF_REFERENCE F129_3075(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit114(void);
extern void F1051_9230(EIF_REFERENCE, EIF_REFERENCE);
extern void F1051_9243(EIF_REFERENCE, EIF_CHARACTER_32);
extern void F1051_9191(EIF_REFERENCE, EIF_REFERENCE);
extern void F857_6547(EIF_REFERENCE, EIF_REFERENCE);
extern void F1051_9229(EIF_REFERENCE, EIF_REFERENCE);
extern void F1046_8985(EIF_REFERENCE);
extern void F857_6548(EIF_REFERENCE, EIF_REFERENCE);
extern void F1049_9116(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern char *(*R5444[])();
extern char *(*R5445[])();
extern char *(*R5446[])();
extern char *(*R4755[])();
extern char *(*R4695[])();
extern char *(*R7524[])();

#ifdef __cplusplus
}
#endif

#endif
