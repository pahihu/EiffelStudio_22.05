/*
 * Code for class TEMPLATE_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "te149.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TEMPLATE_FILE}.make_from_file */
void F164_3512 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
	F932_7662(RTCW(loc1), arg1);
	tb1 = F932_7672(RTCW(loc1));
	if (tb1) {
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(3463,F160_3463, (Current))) + _REFACS_2_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = F932_7690(loc2, loc1);
			loc1 = (EIF_REFERENCE) tr1;
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
		} else {
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
		}
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,653,0,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F648_5588(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {TEMPLATE_FILE}.add_value */
void F164_3516 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4950[Dtype(RTCW(tr1))-577])(tr1, tr2, arg2);
	RTLE;
}

/* {TEMPLATE_FILE}.analyze */
void F164_3520 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F164_3525(Current);
}

/* {TEMPLATE_FILE}.has_text */
EIF_BOOLEAN F164_3523 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) != NULL);
}

/* {TEMPLATE_FILE}.get_text */
void F164_3524 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(920, 0x01).id, 920, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F921_7364(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4965[Dtype(RTCW(loc2))-575])(loc2);
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6114[Dtype(RTCW(loc2))-919])(loc2);
		tb2 = tb3;
	}
	if (tb2) {
		tb2 = F919_7136(RTCW(loc2));
		tb1 = tb2;
	}
	if (tb1) {
		F919_7152(RTCW(loc2));
		loc3 = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1052_9282(RTCW(loc3), loc1);
		for (;;) {
			if (loc4) break;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6170[Dtype(RTCW(loc2))-919])(loc2, ((EIF_INTEGER_32) 1024L));
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
			F1054_9395(RTCW(loc3), tr1);
			loc4 = '\01';
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
			if (!(EIF_BOOLEAN) (ti4_1 < ((EIF_INTEGER_32) 1024L))) {
				tb1 = F369_5159(RTCW(loc2));
				loc4 = tb1;
			}
		}
		F919_7169(RTCW(loc2));
	} else {
		loc3 = RTMS_EX_H("",0,0);
	}
	RTAR(Current, loc3);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc3;
	RTLE;
}

/* {TEMPLATE_FILE}.get_structure */
void F164_3525 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc1);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTGC;
	tb1 = '\0';
	tb2 = '\0';
	tr1 = RTOSCF(726,F25_726, (RTCV(RTOSCF(3463,F160_3463, (Current)))));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = F932_7701(RTCW(tr2));
	tb3 = F648_5596(RTCW(tr1), tr2);
	if (tb3) {
		tr1 = RTOSCF(726,F25_726, (RTCV(RTOSCF(3463,F160_3463, (Current)))));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = F932_7701(RTCW(tr2));
		tr1 = F648_5594(RTCW(tr1), tr2);
		loc2 = tr1;
		tb2 = EIF_TEST(loc2);
	}
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_3_);
		loc3 = tr1;
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		loc1 = F1_14(loc3);
		F163_3481(RTCW(loc1));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc1;
	} else {
		if ((EIF_BOOLEAN) !F164_3523(Current)) {
			F164_3524(Current);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			loc1 = RTLNSMART(eif_new_type(162, 0).id);
			F163_3479(RTCW(loc1), loc4);
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc1;
			F163_3495(RTCW(loc1));
		}
	}
	RTLE;
}

/* {TEMPLATE_FILE}.print_structure */
void F164_3526 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F163_3498(loc1, arg1, ((EIF_INTEGER_32) 0L));
	}
	RTLE;
}

/* {TEMPLATE_FILE}.get_output */
void F164_3528 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F163_3484(loc1, *(EIF_REFERENCE *)(Current));
		F163_3500(loc1);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_4_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	} else {
	}
	RTLE;
}

void EIF_Minit149 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
