/*
 * Code for class EIFFEL_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei117.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_CONSTANTS}.ise_projects_env */

EIF_REFERENCE F132_3093 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (3093,RTMS_EX_H("ISE_PROJECTS",12,53375059));
}

/* {EIFFEL_CONSTANTS}.ise_user_files_env */

EIF_REFERENCE F132_3094 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (3094,RTMS_EX_H("ISE_USER_FILES",14,1880819283));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_major_version */
static EIF_REFERENCE F132_3102_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3102);
#define Result RTOSR(3102)
	RTOC_NEW(Result);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 22U);
	Result = F132_3104(Current, ti4_1);
	RTOSE (3102);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F132_3102 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3102,F132_3102_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_minor_version */
static EIF_REFERENCE F132_3103_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3103);
#define Result RTOSR(3103)
	RTOC_NEW(Result);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 5U);
	Result = F132_3104(Current, ti4_1);
	RTOSE (3103);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F132_3103 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3103,F132_3103_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_string */
EIF_REFERENCE F132_3104 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1052_9282(RTCW(Result), ((EIF_INTEGER_32) 2L));
	if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 10L))) {
		F1054_9408(RTCW(Result), (EIF_CHARACTER_8) '0');
	}
	F1054_9398(RTCW(Result), arg1);
	RTLE;
	return Result;
}

void EIF_Minit117 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
