
#ifndef _C3_id108_
#define _C3_id108_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F123_2984(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F123_2985(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F123_2986(EIF_REFERENCE);
extern void F123_2988(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit108(void);

#ifdef __cplusplus
}
#endif

#endif
