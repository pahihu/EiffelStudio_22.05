
#ifndef _C3_wi143_
#define _C3_wi143_

#ifdef __cplusplus
extern "C" {
#endif

extern void F158_3452(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit143(void);
extern char *(*R6127[])();

#ifdef __cplusplus
}
#endif

#endif
