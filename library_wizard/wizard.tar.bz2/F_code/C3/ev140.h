
#ifndef _C3_ev140_
#define _C3_ev140_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F155_3434(EIF_REFERENCE);
extern EIF_REFERENCE F155_3446(EIF_REFERENCE);
extern void EIF_Minit140(void);

#ifdef __cplusplus
}
#endif

#endif
