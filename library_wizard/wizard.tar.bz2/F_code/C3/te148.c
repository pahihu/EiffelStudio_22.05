/*
 * Code for class TEMPLATE_TEXT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "te148.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TEMPLATE_TEXT}.make_from_text */
void F163_3479 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	F163_3480(Current);
	RTLE;
}

/* {TEMPLATE_TEXT}.init_values */
void F163_3480 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,653,0,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F648_5588(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {TEMPLATE_TEXT}.clear_values */
void F163_3481 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4943[Dtype(RTCW(tr1))-647])(tr1);
	RTLE;
}

/* {TEMPLATE_TEXT}.set_values */
void F163_3484 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {TEMPLATE_TEXT}.get_structure */
void F163_3495 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc14 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc16 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc17 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc18 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(20);
	RTLR(0,loc20);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc10);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,loc5);
	RTLR(7,loc4);
	RTLR(8,loc3);
	RTLR(9,loc15);
	RTLR(10,loc11);
	RTLR(11,loc7);
	RTLR(12,tr2);
	RTLR(13,loc19);
	RTLR(14,loc6);
	RTLR(15,loc21);
	RTLR(16,loc22);
	RTLR(17,loc12);
	RTLR(18,loc13);
	RTLR(19,loc23);
	RTLIU(20);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc20 = tr1;
	if (EIF_TEST(loc20)) {
		loc10 = RTLNS(eif_new_type(846, 0x01).id, 846, _OBJSIZ_8_2_0_0_0_0_0_0_);
		F847_6449(RTCW(loc10));
		RTAR(Current, loc10);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc10;
		loc1 = RTOSCF(3505,F163_3505, (Current));
		loc2 = RTOSCF(3506,F163_3506, (Current));
		loc5 = RTOSCF(3507,F163_3507, (Current));
		loc4 = RTOSCF(3508,F163_3508, (Current));
		loc3 = RTOSCF(3509,F163_3509, (Current));
		tb1 = '\0';
		tb2 = '\0';
		tb3 = '\0';
		tb4 = '\0';
		tb5 = F1385_14421(RTCW(loc1));
		if (tb5) {
			tb5 = F1385_14421(RTCW(loc2));
			tb4 = tb5;
		}
		if (tb4) {
			tb4 = F1385_14421(RTCW(loc5));
			tb3 = tb4;
		}
		if (tb3) {
			tb3 = F1385_14421(RTCW(loc4));
			tb2 = tb3;
		}
		if (tb2) {
			tb2 = F1385_14421(RTCW(loc3));
			tb1 = tb2;
		}
		if (tb1) {
			loc16 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F89_1675(RTCW(loc1), loc20);
			for (;;) {
				tb1 = F89_1661(RTCW(loc1));
				if ((EIF_BOOLEAN) !tb1) break;
				loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				loc15 = (EIF_REFERENCE) NULL;
				loc11 = (EIF_REFERENCE) NULL;
				loc7 = (EIF_REFERENCE) NULL;
				tr1 = F89_1673(RTCW(loc1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L));
				tr2 = RTMS_EX_H("/",1,47);
				loc17 = F1052_9310(RTCW(tr1), tr2);
				tu4_1 = *(EIF_NATURAL_32 *)(RTCW(loc1)+ _LNGOFF_11_16_0_2_);
				tr1 = F89_1673(RTCW(loc1), (EIF_NATURAL_32) (tu4_1 - (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)));
				tr2 = RTMS_EX_H("/",1,47);
				loc18 = F1052_9310(RTCW(tr1), tr2);
				if (loc17) {
					loc8 = F1386_14505(RTCW(loc1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L));
					loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
				} else {
					tu4_1 = F1386_14504(RTCW(loc1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L));
					loc8 = (EIF_INTEGER_32) tu4_1;
				}
				if (loc18) {
					tu4_1 = *(EIF_NATURAL_32 *)(RTCW(loc1)+ _LNGOFF_11_16_0_2_);
					tu4_1 = F1386_14504(RTCW(loc1), (EIF_NATURAL_32) (tu4_1 - (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)));
					loc9 = (EIF_INTEGER_32) tu4_1;
					loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 - ((EIF_INTEGER_32) 1L));
				} else {
					loc9 = F1386_14505(RTCW(loc1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
					loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 - ((EIF_INTEGER_32) 1L));
				}
				loc19 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7565[Dtype(loc20)-1049])(loc20, loc8, loc9);
				tu4_1 = F1386_14504(RTCW(loc1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
				loc8 = (EIF_INTEGER_32) tu4_1;
				loc9 = F1386_14505(RTCW(loc1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
				if (loc17) {
					loc6 = (EIF_REFERENCE) loc19;
					F89_1675(RTCW(loc2), loc6);
					tb2 = F89_1661(RTCW(loc2));
					if (tb2) {
						loc7 = F89_1673(RTCW(loc2), (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L));
						tr1 = *(EIF_REFERENCE *)(RTCW(loc10));
						loc21 = tr1;
						if (EIF_TEST(loc21)) {
							tb2 = F1052_9310(loc21, loc7);
							if (tb2) {
								F847_6477(RTCW(loc10), (EIF_BOOLEAN) 1);
								F847_6478(RTCW(loc10), loc8, loc9);
								tr1 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_1_);
								loc22 = tr1;
								if (EIF_TEST(loc22)) {
									loc10 = (EIF_REFERENCE) loc22;
								} else {
									loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									tr1 = RTMS_EX_H("Missing parent data for [",25,1086317403);
									tr1 = F1054_9414(tr1, loc21);
									tr2 = RTMS_EX_H("]",1,93);
									loc15 = F1054_9414(RTCW(tr1), tr2);
								}
							} else {
								loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								tr1 = RTMS_EX_H("Closing tag [",13,1302906459);
								tr1 = F1054_9414(tr1, loc7);
								tr2 = RTMS_EX_H("] does not match tag [",22,1973220187);
								tr1 = F1054_9414(RTCW(tr1), tr2);
								tr1 = F1054_9414(RTCW(tr1), loc21);
								tr2 = RTMS_EX_H("]",1,93);
								loc15 = F1054_9414(RTCW(tr1), tr2);
							}
						} else {
							loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							tr1 = RTMS_EX_H("Closing tag [",13,1302906459);
							tr1 = F1054_9414(tr1, loc7);
							tr2 = RTMS_EX_H("] without starting tag",22,60300647);
							loc15 = F1054_9414(RTCW(tr1), tr2);
						}
					} else {
						loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						tr1 = RTMS_EX_H("Closing tag [",13,1302906459);
						tr1 = F1054_9414(tr1, loc6);
						tr2 = RTMS_EX_H(" is not valid",13,1957752164);
						loc15 = F1054_9414(RTCW(tr1), tr2);
					}
					tb2 = '\0';
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc14 && (EIF_BOOLEAN)(loc7 != NULL))) {
						tr1 = RTOSCF(3322,F145_3322, (Current));
						tb3 = F1052_9310(RTCW(loc7), tr1);
						tb2 = tb3;
					}
					if (tb2) {
						loc16 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				} else {
					if (loc16) {
						loc12 = (EIF_REFERENCE) NULL;
						loc6 = (EIF_REFERENCE) loc19;
						if (loc18) {
							F89_1675(RTCW(loc5), loc6);
							tb2 = F89_1661(RTCW(loc5));
							if (tb2) {
								loc13 = RTLNS(eif_new_type(847, 0x01).id, 847, _OBJSIZ_10_2_0_0_0_0_0_0_);
								F847_6449(RTCW(loc13));
								loc7 = F89_1673(RTCW(loc5), (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L));
								F848_6489(RTCW(loc13), loc7);
								loc11 = (EIF_REFERENCE) loc13;
							} else {
								F89_1675(RTCW(loc4), loc6);
								tb2 = F89_1661(RTCW(loc4));
								if (tb2) {
									loc13 = RTLNS(eif_new_type(847, 0x01).id, 847, _OBJSIZ_10_2_0_0_0_0_0_0_);
									F847_6449(RTCW(loc13));
									loc7 = (EIF_REFERENCE) loc6;
									F848_6490(RTCW(loc13), loc7);
									loc11 = (EIF_REFERENCE) loc13;
								} else {
									loc12 = F163_3497(Current, loc6);
									if ((EIF_BOOLEAN)(loc12 != NULL)) {
										loc11 = (EIF_REFERENCE) loc12;
									} else {
										loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
										tr1 = RTMS_EX_H("Action tag [",12,2085943899);
										tr1 = F1054_9414(tr1, loc6);
										tr2 = RTMS_EX_H("] is not yet available",22,630281061);
										loc15 = F1054_9414(RTCW(tr1), tr2);
									}
								}
							}
							if ((EIF_BOOLEAN)(loc11 != NULL)) {
								F847_6481(RTCW(loc10), loc11);
							}
						} else {
							F89_1675(RTCW(loc3), loc6);
							tb2 = F89_1661(RTCW(loc3));
							if (tb2) {
								tb2 = '\0';
								tb3 = '\0';
								tr1 = *(EIF_REFERENCE *)(RTCW(loc10));
								loc23 = tr1;
								if (EIF_TEST(loc23)) {
									tr1 = RTOSCF(3317,F145_3317, (Current));
									tb4 = F1052_9310(loc23, tr1);
									tb3 = tb4;
								}
								if (tb3) {
									tr1 = RTMS_EX_H("else",4,1701606245);
									tb3 = F1052_9310(RTCW(loc6), tr1);
									tb2 = tb3;
								}
								if (tb2) {
									F847_6475(RTCW(loc10), loc8, loc9);
									loc11 = (EIF_REFERENCE) NULL;
								} else {
									loc12 = F163_3497(Current, loc6);
									if ((EIF_BOOLEAN)(loc12 != NULL)) {
										loc11 = (EIF_REFERENCE) loc12;
									} else {
										loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
										tr1 = RTMS_EX_H("Action tag [",12,2085943899);
										tr1 = F1054_9414(tr1, loc6);
										tr2 = RTMS_EX_H("] is not yet available",22,630281061);
										loc15 = F1054_9414(RTCW(tr1), tr2);
									}
								}
							} else {
								loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								tr1 = RTMS_EX_H("Invalid tag: [",14,946530395);
								tr1 = F1054_9414(tr1, loc6);
								tr2 = RTMS_EX_H("]",1,93);
								loc15 = F1054_9414(RTCW(tr1), tr2);
							}
							if ((EIF_BOOLEAN)(loc11 != NULL)) {
								F847_6481(RTCW(loc10), loc11);
								loc10 = (EIF_REFERENCE) loc11;
							}
						}
						tb2 = '\0';
						if ((EIF_BOOLEAN)(loc12 != NULL)) {
							tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5752[Dtype(RTCW(loc12))-849])(loc12);
							tb2 = tb3;
						}
						if (tb2) {
							loc16 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
						if ((EIF_BOOLEAN)(loc11 != NULL)) {
							tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4988[Dtype(loc20)-575])(loc20, loc8));
							if ((EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '{')) {
								tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4988[Dtype(loc20)-575])(loc20, (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L))));
								if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '{')) {
									loc8++;
								}
							}
							F847_6475(RTCW(loc11), loc8, loc9);
						}
					}
				}
				if ((EIF_BOOLEAN) (loc14 && (EIF_BOOLEAN)(loc15 != NULL))) {
					loc11 = RTLNS(eif_new_type(846, 0x01).id, 846, _OBJSIZ_8_2_0_0_0_0_0_0_);
					F847_6449(RTCW(loc11));
					F847_6475(RTCW(loc11), loc8, loc9);
					tr1 = RTMS_EX_H("!error!",7,1548961313);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5737[Dtype(RTCW(loc11))-846])(loc11, tr1);
					tr1 = RTMS_EX_H("{!! ",4,2065768736);
					tr1 = F1054_9414(tr1, loc15);
					tr2 = RTMS_EX_H("!!}",3,2171261);
					tr1 = F1054_9414(RTCW(tr1), tr2);
					F847_6483(RTCW(loc11), tr1);
					F847_6481(RTCW(loc10), loc11);
				}
				F1386_14509(RTCW(loc1));
			}
		}
	}
	RTLE;
}

/* {TEMPLATE_TEXT}.tpl_action_factory */
static EIF_REFERENCE F163_3496_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3496);
#define Result RTOSR(3496)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(145, 0x01).id, 145, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3496);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F163_3496 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3496,F163_3496_body,(Current));
}

/* {TEMPLATE_TEXT}.action_item_from_string */
EIF_REFERENCE F163_3497 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,Result);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLIU(9);
	
	RTGC;
	loc1 = RTOSCF(3510,F163_3510, (Current));
	F89_1675(RTCW(loc1), arg1);
	tb1 = F89_1661(RTCW(loc1));
	if (tb1) {
		loc2 = F89_1673(RTCW(loc1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L));
		tr1 = RTOSCF(3496,F163_3496, (Current));
		Result = F146_3339(RTCW(tr1), loc2);
		ti4_1 = F1386_14505(RTCW(loc1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L));
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7723[Dtype(arg1)-1051]);
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7565[Dtype(RTCW(arg1))-1049])(arg1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), ti4_2);
		loc1 = RTOSCF(3511,F163_3511, (Current));
		F89_1675(RTCW(loc1), loc3);
		for (;;) {
			tb1 = F89_1661(RTCW(loc1));
			if ((EIF_BOOLEAN) !tb1) break;
			loc4 = F89_1673(RTCW(loc1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L));
			loc5 = F89_1673(RTCW(loc1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L));
			F849_6498(RTCW(Result), loc4, loc5);
			F1386_14509(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

/* {TEMPLATE_TEXT}.print_structure */
void F163_3498 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,Current);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTGC;
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc2 = RTMS_EX_H("",0,0);
	for (;;) {
		if ((EIF_BOOLEAN)(loc3 == arg2)) break;
		tr1 = RTMS_EX_H(" ",1,32);
		F1054_9397(RTCW(loc2), tr1);
		loc3++;
	}
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = RTMS_EX_H("Name = ",7,344727584);
		tr1 = F1054_9414(RTCW(loc2), tr1);
		tr1 = F1054_9414(RTCW(tr1), loc1);
		tr2 = RTMS_EX_H(" [",2,8283);
		tr1 = F1054_9414(RTCW(tr1), tr2);
		ti4_1 = F847_6455(RTCW(arg1));
		tr2 = eif_out__i4_s1(ti4_1);
		tr1 = F1054_9414(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H("-",1,45);
		tr1 = F1054_9414(RTCW(tr1), tr2);
		ti4_1 = F847_6456(RTCW(arg1));
		tr2 = eif_out__i4_s1(ti4_1);
		tr1 = F1054_9414(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H("] \012",3,6103050);
		tr1 = F1054_9414(RTCW(tr1), tr2);
		F1_27(Current, tr1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc4 = F657_5733(RTCW(tr1));
	for (;;) {
		tb1 = F779_6230(loc4);
		if (tb1) break;
		tr1 = F779_6221(loc4);
		F163_3498(Current, tr1, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
		F779_6236(loc4);
	}
	RTLE;
}

/* {TEMPLATE_TEXT}.get_output */
void F163_3500 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	F25_699(RTCV(RTOSCF(3463,F160_3463, (Current))));
	tr1 = RTOSCF(3463,F160_3463, (Current));
	F25_710(RTCW(tr1), Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F163_3501(Current, loc1);
	} else {
	}
	RTLE;
}

/* {TEMPLATE_TEXT}.process_structure */
void F163_3501 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,loc8);
	RTLR(5,arg1);
	RTLR(6,loc1);
	RTLR(7,loc2);
	RTLR(8,loc9);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		loc6 = RTLNSMART(eif_new_type(1053, 0).id);
		F1052_9284(RTCW(loc6), loc7);
		loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		RTAR(Current, loc6);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) loc6;
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		loc8 = F657_5733(RTCW(tr1));
		for (;;) {
			tb1 = F779_6230(loc8);
			if (tb1) break;
			loc1 = F779_6221(loc8);
			loc3 = F847_6455(RTCW(loc1));
			loc4 = F847_6456(RTCW(loc1));
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5734[Dtype(RTCW(loc1))-846])(loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5736[Dtype(RTCW(loc1))-846])(loc1);
			loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_7_);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				loc2 = RTMS_EX_H("",0,0);
			}
			loc9 = loc1;
			loc9 = RTRV(eif_new_type(848, 0x01),loc9);
			if (EIF_TEST(loc9)) {
				tb2 = *(EIF_BOOLEAN *)(RTCW(loc1) + O5717[Dtype(loc1)-846]);
				if (tb2) {
					loc4 = F847_6458(RTCW(loc1));
				}
				F1054_9371(RTCW(loc6), loc2, (EIF_INTEGER_32) (loc5 + loc3), (EIF_INTEGER_32) (loc5 + loc4));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O7723[Dtype(loc2)-1051]);
				loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + ti4_1) - ((EIF_INTEGER_32) 1L)) - (EIF_INTEGER_32) (loc4 - loc3));
			} else {
				F1054_9371(RTCW(loc6), loc2, (EIF_INTEGER_32) (loc5 + loc3), (EIF_INTEGER_32) (loc5 + loc4));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O7723[Dtype(loc2)-1051]);
				loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + ti4_1) - ((EIF_INTEGER_32) 1L)) - (EIF_INTEGER_32) (loc4 - loc3));
				tb2 = *(EIF_BOOLEAN *)(RTCW(loc1) + O5717[Dtype(loc1)-846]);
				if (tb2) {
					loc3 = F847_6457(RTCW(loc1));
					loc4 = F847_6458(RTCW(loc1));
					tr1 = RTMS_EX_H("",0,0);
					F1054_9371(RTCW(loc6), tr1, (EIF_INTEGER_32) (loc5 + loc3), (EIF_INTEGER_32) (loc5 + loc4));
					loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 - ((EIF_INTEGER_32) 1L)) - (EIF_INTEGER_32) (loc4 - loc3));
				}
			}
			F779_6236(loc8);
		}
	}
	RTLE;
}

/* {TEMPLATE_TEXT}.compiled_regexp */
EIF_REFERENCE F163_3504 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1385, 0x01).id, 1385, _OBJSIZ_11_16_0_25_0_0_0_0_);
	F1386_14500(RTCW(Result));
	F1385_14437(RTCW(Result), arg2);
	F1386_14503(RTCW(Result), arg1);
	RTLE;
	return Result;
}

/* {TEMPLATE_TEXT}.tag_regexp_tag */
static EIF_REFERENCE F163_3505_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	

	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (3505);
#define Result RTOSR(3505)
	RTOC_NEW(Result);
	loc1 = RTMS_EX_H("\\{(\\/)\?\\s*((\"[^\"]*\"|[^/^}])+)\\s*(\\/)\?\\}",39,2043821181);
	Result = F163_3504(Current, loc1, (EIF_BOOLEAN) 1);
	RTOSE (3505);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F163_3505 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3505,F163_3505_body,(Current));
}

/* {TEMPLATE_TEXT}.tag_regexp_sub_closing_tag */
static EIF_REFERENCE F163_3506_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (3506);
#define Result RTOSR(3506)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("\\s*([a-zA-Z0-9_]+)\\s*",21,302442794);
	Result = F163_3504(Current, tr1, (EIF_BOOLEAN) 1);
	RTOSE (3506);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F163_3506 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3506,F163_3506_body,(Current));
}

/* {TEMPLATE_TEXT}.tag_regexp_sub_var */
static EIF_REFERENCE F163_3507_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (3507);
#define Result RTOSR(3507)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("^\\s*\\$([a-zA-Z0-9_]+)\\s*$",25,1709316900);
	Result = F163_3504(Current, tr1, (EIF_BOOLEAN) 1);
	RTOSE (3507);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F163_3507 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3507,F163_3507_body,(Current));
}

/* {TEMPLATE_TEXT}.tag_regexp_sub_expression */
static EIF_REFERENCE F163_3508_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (3508);
#define Result RTOSR(3508)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("^\\s*\\$([a-zA-Z0-9_]+)(\\.\\$\?[\\.a-zA-Z0-9_]+)\\s*$",47,183867684);
	Result = F163_3504(Current, tr1, (EIF_BOOLEAN) 1);
	RTOSE (3508);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F163_3508 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3508,F163_3508_body,(Current));
}

/* {TEMPLATE_TEXT}.tag_regexp_sub_action */
static EIF_REFERENCE F163_3509_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (3509);
#define Result RTOSR(3509)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("^\\s*([a-zA-Z]+)\\s*",18,329890858);
	Result = F163_3504(Current, tr1, (EIF_BOOLEAN) 1);
	RTOSE (3509);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F163_3509 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3509,F163_3509_body,(Current));
}

/* {TEMPLATE_TEXT}.tag_regexp_sub_action_name */
static EIF_REFERENCE F163_3510_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (3510);
#define Result RTOSR(3510)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("^\\s*([a-z0-9_]+)(\\s|$)",22,107920937);
	Result = F163_3504(Current, tr1, (EIF_BOOLEAN) 1);
	RTOSE (3510);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F163_3510 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3510,F163_3510_body,(Current));
}

/* {TEMPLATE_TEXT}.tag_regexp_sub_action_op_val */
static EIF_REFERENCE F163_3511_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (3511);
#define Result RTOSR(3511)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("\\s*([a-z0-9_]+)=\"([^\"]*)\"",25,1531884578);
	Result = F163_3504(Current, tr1, (EIF_BOOLEAN) 1);
	RTOSE (3511);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F163_3511 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3511,F163_3511_body,(Current));
}

void EIF_Minit148 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
