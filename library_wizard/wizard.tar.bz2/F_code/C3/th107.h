
#ifndef _C3_th107_
#define _C3_th107_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F122_2982(EIF_REFERENCE);
extern void EIF_Minit107(void);

#ifdef __cplusplus
}
#endif

#endif
