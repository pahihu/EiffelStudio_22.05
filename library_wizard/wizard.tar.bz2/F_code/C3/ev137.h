
#ifndef _C3_ev137_
#define _C3_ev137_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F152_3376(EIF_REFERENCE);
extern EIF_REFERENCE F152_3379(EIF_REFERENCE);
static EIF_REFERENCE F152_3380_body(EIF_REFERENCE);
extern EIF_REFERENCE F152_3380(EIF_REFERENCE);
extern EIF_REFERENCE F152_3381(EIF_REFERENCE);
extern EIF_REFERENCE F152_3393(EIF_REFERENCE);
extern void EIF_Minit137(void);
extern void F1267_12208(EIF_REFERENCE, EIF_REFERENCE);
extern void F679_5836(EIF_REFERENCE);
extern long O3354[];
extern long O3357[];
extern long O3359[];
extern long O3371[];

#ifdef __cplusplus
}
#endif

#endif
