/*
 * Code for class TEMPLATE_STRUCTURE_ACTION_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "te131.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TEMPLATE_STRUCTURE_ACTION_FACTORY}.new_action */
EIF_REFERENCE F146_3339 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = F1054_9430(RTCW(arg1));
	tr1 = RTOSCF(3323,F145_3323, (Current));
	tb1 = F1052_9307(RTCW(loc1), tr1);
	if (tb1) {
		Result = RTLNS(eif_new_type(851, 0x01).id, 851, _OBJSIZ_9_2_0_0_0_0_0_0_);
		F849_6492(RTCW(Result));
	} else {
		tr1 = RTOSCF(3324,F145_3324, (Current));
		tb1 = F1052_9307(RTCW(loc1), tr1);
		if (tb1) {
			Result = RTLNS(eif_new_type(849, 0x01).id, 849, _OBJSIZ_9_2_0_0_0_0_0_0_);
			F849_6492(RTCW(Result));
		} else {
			tr1 = RTOSCF(3322,F145_3322, (Current));
			tb1 = F1052_9307(RTCW(loc1), tr1);
			if (tb1) {
				Result = RTLNS(eif_new_type(850, 0x01).id, 850, _OBJSIZ_9_2_0_0_0_0_0_0_);
				F849_6492(RTCW(Result));
			} else {
				tr1 = RTOSCF(3320,F145_3320, (Current));
				tb1 = F1052_9307(RTCW(loc1), tr1);
				if (tb1) {
					Result = RTLNS(eif_new_type(855, 0x01).id, 855, _OBJSIZ_9_2_0_0_0_0_0_0_);
					F849_6492(RTCW(Result));
				} else {
					tr1 = RTOSCF(3321,F145_3321, (Current));
					tb1 = F1052_9307(RTCW(loc1), tr1);
					if (tb1) {
						Result = RTLNS(eif_new_type(854, 0x01).id, 854, _OBJSIZ_9_2_0_0_0_0_0_0_);
						F849_6492(RTCW(Result));
					} else {
						tb1 = '\01';
						tb2 = '\01';
						tr1 = RTOSCF(3317,F145_3317, (Current));
						tb3 = F1052_9307(RTCW(loc1), tr1);
						if (!tb3) {
							tr1 = RTOSCF(3318,F145_3318, (Current));
							tb3 = F1052_9307(RTCW(loc1), tr1);
							tb2 = tb3;
						}
						if (!tb2) {
							tr1 = RTOSCF(3319,F145_3319, (Current));
							tb2 = F1052_9307(RTCW(loc1), tr1);
							tb1 = tb2;
						}
						if (tb1) {
							Result = RTLNS(eif_new_type(852, 0x01).id, 852, _OBJSIZ_9_6_0_0_0_0_0_0_);
							F849_6492(RTCW(Result));
						} else {
							Result = RTLNS(eif_new_type(853, 0x01).id, 853, _OBJSIZ_9_2_0_0_0_0_0_0_);
							F849_6492(RTCW(Result));
						}
					}
				}
			}
		}
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5737[Dtype(RTCW(Result))-846])(Result, arg1);
	RTLE;
	return Result;
}

void EIF_Minit131 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
