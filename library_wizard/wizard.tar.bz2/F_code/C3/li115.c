/*
 * Code for class LIBRARY_WIZARD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li115.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LIBRARY_WIZARD}.title */

EIF_REFERENCE F130_3076 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (3076,RTMS32_EX_H("E\000\000\000i\000\000\000f\000\000\000f\000\000\000e\000\000\000l\000\000\000 \000\000\000L\000\000\000i\000\000\000b\000\000\000r\000\000\000a\000\000\000r\000\000\000y\000\000\000 \000\000\000W\000\000\000i\000\000\000z\000\000\000a\000\000\000r\000\000\000d\000\000\000",21,909667684));
}

/* {LIBRARY_WIZARD}.default_library_name */

EIF_REFERENCE F130_3077 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (3077,RTMS32_EX_H("n\000\000\000e\000\000\000w\000\000\000_\000\000\000l\000\000\000i\000\000\000b\000\000\000r\000\000\000a\000\000\000r\000\000\000y\000\000\000",11,199349881));
}

/* {LIBRARY_WIZARD}.wizard_generator */
EIF_REFERENCE F130_3078 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(160, 0x01).id, 160, _OBJSIZ_3_0_0_0_0_0_0_0_);
	F124_2989(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {LIBRARY_WIZARD}.first_page */
static EIF_REFERENCE F130_3079_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (3079);
#define Result RTOSR(3079)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("first",5,1769891700);
	Result = F129_3066(Current, tr1);
	tr1 = RTMS_EX_H("Eiffel Library Wizard",21,909667684);
	F857_6547(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Create a reusable Eiffel Library.",33,1397561646);
	F857_6552(RTCW(Result), tr1);
	RTOSE (3079);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F130_3079 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3079,F130_3079_body,(Current));
}

/* {LIBRARY_WIZARD}.library_page */
static EIF_REFERENCE F130_3080_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(8);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc2);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLIU(8);
	
	RTEV;
	RTGC;
	RTOSP (3080);
#define Result RTOSR(3080)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("library",7,649884793);
	Result = F129_3066(Current, tr1);
	tr1 = RTMS_EX_H("Library Name and Project Location",33,1451097966);
	F857_6547(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("You can choose the name of the project and\012the directory where the project will be generated.",93,1036771374);
	F857_6548(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Please fill in:\012\011The name of the project (without space).\012\011The directory where you want the eiffel classes to be generated.",123,1372568622);
	F857_6553(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Project name:",13,853875770);
	tr2 = RTMS_EX_H("name",4,1851878757);
	tr3 = RTMS_EX_H("ASCII name, without space",25,481648485);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5809[Dtype(RTCW(Result))-857])(Result, tr1, tr2, tr3);
	F857_6551(RTCW(Result), loc1);
	tr1 = RTMS_EX_H("Project location:",17,271127098);
	tr2 = RTMS_EX_H("location",8,59511406);
	tr3 = RTMS_EX_H("Valid directory path, it will be created if missing",51,1461816167);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5810[Dtype(RTCW(Result))-857])(Result, tr1, tr2, tr3);
	F857_6551(RTCW(Result), loc2);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,966,0xFF01,0,0xFF01,279,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = loc2;
	RTAR(tr2,loc2);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,278,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A115_49_2, (EIF_POINTER) _A115_49_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	F672_5802(RTCW(tr1), tr5);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
	tr2 = RTOSCF(3077,F130_3077, (Current));
	tr3 = RTMS_EX_H("name",4,1851878757);
	F832_6338(RTCW(tr1), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
	tr2 = *(EIF_REFERENCE *)(Current);
	tr3 = RTOSCF(3077,F130_3077, (Current));
	tr4 = *(EIF_REFERENCE *)(Current);
	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + _REFACS_2_);
	tr4 = F306_4756(RTCW(tr4));
	tr5 = RTMS_EX_H("demo",4,1684368751);
	tr4 = F932_7689(RTCW(tr4), tr5);
	tr2 = F310_4870(RTCW(tr2), tr3, tr4);
	tr2 = F932_7701(RTCW(tr2));
	tr3 = RTMS_EX_H("location",8,59511406);
	F832_6338(RTCW(tr1), tr2, tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,966,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,856,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A115_50_2, (EIF_POINTER) _A115_50_2, (EIF_POINTER)(0),tr1, 1, 1);
	}
	F857_6550(RTCW(Result), tr4);
	RTOSE (3080);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F130_3080 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3080,F130_3080_body,(Current));
}

/* {LIBRARY_WIZARD}.final_page */
static EIF_REFERENCE F130_3081_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(6);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTEV;
	RTGC;
	RTOSP (3081);
#define Result RTOSR(3081)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("final",5,1769624940);
	Result = F129_3066(Current, tr1);
	tr1 = RTMS_EX_H("Completing the New Eiffel Library Wizard",40,612768868);
	F857_6547(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("You have specified the following settings:\012\012",44,412579594);
	F857_6553(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("...",3,3026478);
	loc1 = F857_6563(RTCW(Result), tr1);
	F857_6551(RTCW(Result), loc1);
	tr1 = RTMS_EX_H("...",3,3026478);
	loc2 = F857_6563(RTCW(Result), tr1);
	F857_6551(RTCW(Result), loc2);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_5_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,966,0xFF01,0,0xFF01,856,0xFF01,268,0xFF01,268,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 5, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = Result;
	RTAR(tr2,Result);
	((EIF_TYPED_VALUE *)tr2+3)->it_r = loc1;
	RTAR(tr2,loc1);
	((EIF_TYPED_VALUE *)tr2+4)->it_r = loc2;
	RTAR(tr2,loc2);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A115_48, (EIF_POINTER) _A115_48, (EIF_POINTER)(0),tr2, 1, 0);
	}
	F672_5802(RTCW(tr1), tr3);
	RTOSE (3081);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F130_3081 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3081,F130_3081_body,(Current));
}

/* {LIBRARY_WIZARD}.next_page */
EIF_REFERENCE F130_3082 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	Result = RTOSCF(3068,F129_3068, (Current));
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		Result = RTOSCF(3079,F130_3079, (Current));
		RTLE;
		return (EIF_REFERENCE) Result;
	} else {
		if ((EIF_BOOLEAN)(arg1 == RTOSCF(3079,F130_3079, (Current)))) {
			Result = RTOSCF(3080,F130_3080, (Current));
		} else {
			if ((EIF_BOOLEAN)(arg1 == RTOSCF(3080,F130_3080, (Current)))) {
				Result = RTOSCF(3081,F130_3081, (Current));
				RTLE;
				return (EIF_REFERENCE) Result;
			}
		}
	}
	RTLE;
	return Result;
}

/* {LIBRARY_WIZARD}.inline-agent#1 of final_page */
void F130_14733 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLR(6,arg2);
	RTLIU(7);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,656,0xFF01,0xFFF9,2,966,0xFF01,1045,0xFF01,1045,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 656, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F657_5719(RTCW(loc1), ((EIF_INTEGER_32) 10L));
	tr1 = RTOSCF(3080,F130_3080, (Current));
	tr2 = RTMS_EX_H("name",4,1851878757);
	tr1 = F857_6539(RTCW(tr1), tr2);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,1053,0xFF01,1048,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = RTMS_EX_H("Project name",12,1823660133);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = loc2;
		RTAR(tr1,loc2);
		F657_5759(RTCW(loc1), tr1);
	}
	tr1 = RTOSCF(3080,F130_3080, (Current));
	tr2 = RTMS_EX_H("location",8,59511406);
	tr1 = F857_6539(RTCW(tr1), tr2);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,1053,0xFF01,1048,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = RTMS_EX_H("Location",8,52138606);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = loc3;
		RTAR(tr1,loc3);
		F657_5759(RTCW(loc1), tr1);
	}
	tr1 = F129_3075(Current, loc1);
	F269_4623(RTCW(arg2), tr1);
	RTLE;
}

/* {LIBRARY_WIZARD}.inline-agent#1 of library_page */
void F130_14734 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,loc1);
	RTLR(7,Current);
	RTLIU(8);
	
	RTGC;
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4529[Dtype(RTCW(arg1))-283])(arg1);
	loc3 = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4513[Dtype(RTCW(arg2))-283])(arg2);
	F932_7662(RTCW(loc3), tr1);
	tb1 = '\01';
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4513[Dtype(RTCW(arg2))-283])(arg2);
	tr2 = RTMS_EX_H("/",1,47);
	tb2 = F1046_9033(RTCW(tr1), tr2);
	if (!tb2) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4513[Dtype(RTCW(arg2))-283])(arg2);
		tr2 = RTMS_EX_H("\\",1,92);
		tb2 = F1046_9033(RTCW(tr1), tr2);
		tb1 = tb2;
	}
	if (tb1) {
	} else {
		tr1 = F932_7677(RTCW(loc3));
		loc3 = (EIF_REFERENCE) tr1;
	}
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTOSCF(3077,F130_3077, (Current));
		tr1 = F310_4870(RTCW(tr1), tr2, loc3);
		loc1 = F932_7701(RTCW(tr1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4514[Dtype(RTCW(arg2))-283])(arg2, loc1);
	} else {
		tb1 = F1046_9003(RTCW(loc2));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = F310_4870(RTCW(tr1), loc2, loc3);
			loc1 = F932_7701(RTCW(tr1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4514[Dtype(RTCW(arg2))-283])(arg2, loc1);
		}
	}
	RTLE;
}

/* {LIBRARY_WIZARD}.inline-agent#2 of library_page */
void F130_14735 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	tr2 = RTMS_EX_H("name",4,1851878757);
	tr1 = F832_6329(RTCW(tr1), tr2);
	loc1 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc1))) {
		tb2 = F1046_9003(loc1);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = RTMS_EX_H("Invalid value for `name\'!",25,1415550497);
		F857_6578(RTCW(arg1), tr1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	tr2 = RTMS_EX_H("location",8,59511406);
	tb1 = F832_6335(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTMS_EX_H("Missing value for `location\'!",29,57775393);
		F857_6578(RTCW(arg1), tr1);
	}
	RTLE;
}

void EIF_Minit115 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
