
#ifndef _C21_ar1010_
#define _C21_ar1010_

#ifdef __cplusplus
extern "C" {
#endif

extern void F810_6259(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F810_6260(EIF_REFERENCE);
extern EIF_REFERENCE F810_6261(EIF_REFERENCE);
extern EIF_REFERENCE F810_6263(EIF_REFERENCE);
extern EIF_INTEGER_32 F810_6264(EIF_REFERENCE);
extern void EIF_Minit1010(void);
extern EIF_TYPE_INDEX Y5447[];
extern EIF_TYPE_INDEX *Y5447_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
