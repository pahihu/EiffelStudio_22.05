/*
 * Code for class DYNAMIC_CHAIN [NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dy1003.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DYNAMIC_CHAIN}.extendible */
EIF_BOOLEAN F608_5449 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {DYNAMIC_CHAIN}.prune */
void F608_5455 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F662_5756(Current, arg1);
	if ((EIF_BOOLEAN) !F368_5159(Current)) {
		F662_5773(Current);
	}
	RTLE;
}

/* {DYNAMIC_CHAIN}.prune_all */
void F608_5456 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F662_5750(Current);
	F662_5756(Current, arg1);
	for (;;) {
		if (F368_5159(Current)) break;
		F662_5773(Current);
		F662_5756(Current, arg1);
	}
	RTLE;
}

void EIF_Minit1003 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
