
#ifndef _C21_co1034_
#define _C21_co1034_

#ifdef __cplusplus
extern "C" {
#endif

extern void F342_5000(EIF_REFERENCE);
extern void F342_5001(EIF_REFERENCE);
extern void EIF_Minit1034(void);
extern long O4810[];

#ifdef __cplusplus
}
#endif

#endif
