
#ifndef _C21_ty1027_
#define _C21_ty1027_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F752_6181(EIF_REFERENCE);
extern void EIF_Minit1027(void);
extern char *(*R5520[])();
extern char *(*R5507[])();
extern char *(*R4988[])();

#ifdef __cplusplus
}
#endif

#endif
