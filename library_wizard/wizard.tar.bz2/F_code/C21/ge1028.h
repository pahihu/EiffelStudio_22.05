
#ifndef _C21_ge1028_
#define _C21_ge1028_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F785_6221(EIF_REFERENCE);
extern EIF_INTEGER_32 F785_6223(EIF_REFERENCE);
extern EIF_BOOLEAN F785_6230(EIF_REFERENCE);
extern void F785_6235(EIF_REFERENCE);
extern void F785_6236(EIF_REFERENCE);
extern EIF_REFERENCE F785_6237(EIF_REFERENCE);
extern void EIF_Minit1028(void);
extern char *(*R5535[])();
extern char *(*R5508[])();
extern long O5534[];
extern long O5536[];

#ifdef __cplusplus
}
#endif

#endif
