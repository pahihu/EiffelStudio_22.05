
#ifndef _C21_dy1048_
#define _C21_dy1048_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F437_5195(EIF_REFERENCE);
extern void EIF_Minit1048(void);

#ifdef __cplusplus
}
#endif

#endif
