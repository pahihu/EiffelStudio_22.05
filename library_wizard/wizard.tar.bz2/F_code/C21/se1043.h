
#ifndef _C21_se1043_
#define _C21_se1043_

#ifdef __cplusplus
extern "C" {
#endif

extern void F525_5242(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit1043(void);
extern char *(*R4939[])();

#ifdef __cplusplus
}
#endif

#endif
