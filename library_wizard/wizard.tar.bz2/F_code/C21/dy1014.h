
#ifndef _C21_dy1014_
#define _C21_dy1014_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F436_5195(EIF_REFERENCE);
extern void EIF_Minit1014(void);

#ifdef __cplusplus
}
#endif

#endif
