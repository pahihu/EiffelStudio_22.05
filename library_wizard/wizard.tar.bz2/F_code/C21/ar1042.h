
#ifndef _C21_ar1042_
#define _C21_ar1042_

#ifdef __cplusplus
extern "C" {
#endif

extern void F797_6241(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F797_6242(EIF_REFERENCE);
extern EIF_REFERENCE F797_6243(EIF_REFERENCE);
extern EIF_REFERENCE F797_6245(EIF_REFERENCE);
extern EIF_INTEGER_32 F797_6246(EIF_REFERENCE);
extern void EIF_Minit1042(void);
extern EIF_INTEGER_32 F663_5742(EIF_REFERENCE);
extern EIF_REFERENCE F663_5723(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5447[];
extern EIF_TYPE_INDEX *Y5447_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
