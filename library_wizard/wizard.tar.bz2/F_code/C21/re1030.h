
#ifndef _C21_re1030_
#define _C21_re1030_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F513_5235(EIF_REFERENCE);
extern void F513_5237(EIF_REFERENCE);
extern void EIF_Minit1030(void);
extern char *(*R4966[])();
extern char *(*R4972[])();

#ifdef __cplusplus
}
#endif

#endif
