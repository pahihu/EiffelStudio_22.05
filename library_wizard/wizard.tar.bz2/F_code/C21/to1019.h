
#ifndef _C21_to1019_
#define _C21_to1019_

#ifdef __cplusplus
extern "C" {
#endif

extern void F299_4739(EIF_REFERENCE, EIF_INTEGER_32);
extern void F299_4740(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern void F299_4746(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1019(void);
extern void F841_6401(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4560[];
extern EIF_TYPE_INDEX *Y4560_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
