/*
 * Code for class DYNAMIC_CHAIN [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dy1046.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DYNAMIC_CHAIN}.extendible */
EIF_BOOLEAN F609_5449 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {DYNAMIC_CHAIN}.prune */
void F609_5455 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F663_5756(Current, arg1);
	if ((EIF_BOOLEAN) !F369_5159(Current)) {
		F663_5773(Current);
	}
	RTLE;
}

/* {DYNAMIC_CHAIN}.prune_all */
void F609_5456 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F663_5750(Current);
	F663_5756(Current, arg1);
	for (;;) {
		if (F369_5159(Current)) break;
		F663_5773(Current);
		F663_5756(Current, arg1);
	}
	RTLE;
}

void EIF_Minit1046 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
