
#ifndef _C21_fi1035_
#define _C21_fi1035_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F489_5229(EIF_REFERENCE);
extern void EIF_Minit1035(void);
extern char *(*R4965[])();

#ifdef __cplusplus
}
#endif

#endif
