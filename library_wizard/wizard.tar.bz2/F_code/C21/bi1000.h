
#ifndef _C21_bi1000_
#define _C21_bi1000_

#ifdef __cplusplus
extern "C" {
#endif

extern void F380_5172(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit1000(void);
extern EIF_BOOLEAN F620_5465(EIF_REFERENCE);
extern EIF_BOOLEAN F488_5229(EIF_REFERENCE);
extern void F368_5155(EIF_REFERENCE, EIF_NATURAL_32);
extern void F662_5752(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
