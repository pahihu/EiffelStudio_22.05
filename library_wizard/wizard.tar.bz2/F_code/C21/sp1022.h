
#ifndef _C21_sp1022_
#define _C21_sp1022_

#ifdef __cplusplus
extern "C" {
#endif

extern void F823_6265(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F823_6266(EIF_REFERENCE);
extern EIF_REFERENCE F823_6267(EIF_REFERENCE);
extern EIF_INTEGER_32 F823_6268(EIF_REFERENCE);
extern void EIF_Minit1022(void);
extern EIF_INTEGER_32 F841_6412(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5447[];
extern EIF_TYPE_INDEX *Y5447_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
