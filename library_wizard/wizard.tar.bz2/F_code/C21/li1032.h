
#ifndef _C21_li1032_
#define _C21_li1032_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F369_5153(EIF_REFERENCE, EIF_CHARACTER_8);
extern void F369_5155(EIF_REFERENCE, EIF_CHARACTER_8);
extern EIF_BOOLEAN F369_5159(EIF_REFERENCE);
extern EIF_BOOLEAN F369_5161(EIF_REFERENCE);
extern EIF_REFERENCE F369_5168(EIF_REFERENCE);
extern void EIF_Minit1032(void);
extern char *(*R4917[])();
extern char *(*R4918[])();
extern char *(*R4919[])();
extern char *(*R4808[])();
extern char *(*R4925[])();
extern char *(*R4930[])();
extern char *(*R4932[])();
extern long O4810[];

#ifdef __cplusplus
}
#endif

#endif
