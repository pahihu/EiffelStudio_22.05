
#ifndef _C21_to1001_
#define _C21_to1001_

#ifdef __cplusplus
extern "C" {
#endif

extern void F298_4739(EIF_REFERENCE, EIF_INTEGER_32);
extern void F298_4740(EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32);
extern void F298_4746(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1001(void);
extern void F840_6401(EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4560[];
extern EIF_TYPE_INDEX *Y4560_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
