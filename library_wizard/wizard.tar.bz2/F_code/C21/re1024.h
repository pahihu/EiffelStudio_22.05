
#ifndef _C21_re1024_
#define _C21_re1024_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F558_5291(EIF_REFERENCE);
extern void EIF_Minit1024(void);
extern void F764_6187(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5519[])();
extern EIF_TYPE_INDEX Y4756[];
extern EIF_TYPE_INDEX *Y4756_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
