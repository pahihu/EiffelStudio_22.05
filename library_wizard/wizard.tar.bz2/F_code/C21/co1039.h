
#ifndef _C21_co1039_
#define _C21_co1039_

#ifdef __cplusplus
extern "C" {
#endif

extern void F393_5180(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit1039(void);
extern char *(*R4941[])();
extern char *(*R4807[])();

#ifdef __cplusplus
}
#endif

#endif
