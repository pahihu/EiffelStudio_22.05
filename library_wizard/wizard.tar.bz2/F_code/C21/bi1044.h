
#ifndef _C21_bi1044_
#define _C21_bi1044_

#ifdef __cplusplus
extern "C" {
#endif

extern void F381_5172(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit1044(void);
extern void F369_5155(EIF_REFERENCE, EIF_CHARACTER_8);
extern char *(*R4808[])();
extern char *(*R4932[])();
extern char *(*R4933[])();

#ifdef __cplusplus
}
#endif

#endif
