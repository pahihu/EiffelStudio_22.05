
#ifndef _C21_dy1003_
#define _C21_dy1003_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F608_5449(EIF_REFERENCE);
extern void F608_5455(EIF_REFERENCE, EIF_NATURAL_32);
extern void F608_5456(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit1003(void);
extern void F662_5750(EIF_REFERENCE);
extern void F662_5773(EIF_REFERENCE);
extern void F662_5756(EIF_REFERENCE, EIF_NATURAL_32);
extern EIF_BOOLEAN F368_5159(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
