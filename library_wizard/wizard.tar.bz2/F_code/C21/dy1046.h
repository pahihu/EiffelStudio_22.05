
#ifndef _C21_dy1046_
#define _C21_dy1046_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F609_5449(EIF_REFERENCE);
extern void F609_5455(EIF_REFERENCE, EIF_CHARACTER_8);
extern void F609_5456(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit1046(void);
extern void F663_5750(EIF_REFERENCE);
extern void F663_5756(EIF_REFERENCE, EIF_CHARACTER_8);
extern void F663_5773(EIF_REFERENCE);
extern EIF_BOOLEAN F369_5159(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
