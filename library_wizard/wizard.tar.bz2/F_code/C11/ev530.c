/*
 * Code for class EV_MENU_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev530.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MENU_ITEM}.make_with_text_and_action */
void F1170_10713 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	F1083_9562(Current);
	F1112_9956(Current, arg1);
	tr1 = F1075_9505(Current);
	F672_5802(RTCW(tr1), arg2);
	RTLE;
}

/* {EV_MENU_ITEM}.default_identifier_name */
EIF_REFERENCE F1170_10714 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	tb1 = F491_5229(RTCV(F1112_9955(Current)));
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) F1096_9809(Current);
	} else {
		Result = F1_14(F1112_9955(Current));
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
		F1051_9256(RTCW(Result), tw1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
		F1051_9256(RTCW(Result), tw1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\011';
		loc1 = F1049_9127(RTCW(Result), tw1, ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
			F1051_9212(RTCW(Result), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
		}
		F1051_9271(RTCW(Result));
	}
	RTLE;
	return Result;
}

/* {EV_MENU_ITEM}.implementation */
EIF_REFERENCE F1170_10719 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_MENU_ITEM}.create_implementation */
void F1170_10720 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1346, 0x01).id, 1346, _OBJSIZ_23_8_6_1_0_4_0_0_);
	F1347_13523(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit530 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
