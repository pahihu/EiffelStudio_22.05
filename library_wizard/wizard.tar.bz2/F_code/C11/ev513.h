
#ifndef _C11_ev513_
#define _C11_ev513_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1153_10561(EIF_REFERENCE);
extern void F1153_10562(EIF_REFERENCE);
extern EIF_REFERENCE F1153_10564(EIF_REFERENCE);
extern void F1153_10565(EIF_REFERENCE);
extern void EIF_Minit513(void);
extern void F1320_13081(EIF_REFERENCE);
extern void F1320_13084(EIF_REFERENCE);
extern void F1320_13085(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
