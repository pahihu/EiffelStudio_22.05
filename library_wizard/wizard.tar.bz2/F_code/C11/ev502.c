/*
 * Code for class EV_TITLED_WINDOW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev502.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TITLED_WINDOW}.initialize */
void F1142_10431 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(1010,F42_1010, (RTCV(RTOSCF(7614,F928_7614, (Current)))));
	F1142_10443(Current, tr1);
	F1140_10388(Current);
	RTLE;
}

/* {EV_TITLED_WINDOW}.raise */
void F1142_10436 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	F1296_12696(RTCW(tr1));
	RTLE;
}

/* {EV_TITLED_WINDOW}.set_icon_pixmap */
void F1142_10443 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	F1296_12702(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_TITLED_WINDOW}.implementation */
EIF_REFERENCE F1142_10444 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
}


/* {EV_TITLED_WINDOW}.create_implementation */
void F1142_10445 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1295, 0x01).id, 1295, _OBJSIZ_65_25_10_11_0_4_0_0_);
	F1294_12606(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit502 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
