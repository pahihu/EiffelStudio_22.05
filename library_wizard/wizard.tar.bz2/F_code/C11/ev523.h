
#ifndef _C11_ev523_
#define _C11_ev523_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1163_10676(EIF_REFERENCE);
extern void EIF_Minit523(void);
extern char *(*R10443[])();

#ifdef __cplusplus
}
#endif

#endif
