
#ifndef _C11_ev517_
#define _C11_ev517_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1157_10615(EIF_REFERENCE);
extern EIF_REFERENCE F1157_10625(EIF_REFERENCE);
extern void F1157_10626(EIF_REFERENCE);
extern void EIF_Minit517(void);
extern void F1326_13257(EIF_REFERENCE);
extern void F1326_13221(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
