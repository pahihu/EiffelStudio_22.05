
#ifndef _C11_gr503_
#define _C11_gr503_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1143_10446(EIF_REFERENCE);
extern void F1143_10447(EIF_REFERENCE);
extern void EIF_Minit503(void);
extern void F311_4887(EIF_REFERENCE);
extern void F1142_10431(EIF_REFERENCE);
extern void F311_4888(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
