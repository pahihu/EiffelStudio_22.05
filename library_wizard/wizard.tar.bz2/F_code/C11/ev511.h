
#ifndef _C11_ev511_
#define _C11_ev511_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1151_10534(EIF_REFERENCE);
extern void F1151_10535(EIF_REFERENCE);
extern void EIF_Minit511(void);
extern void F1364_13861(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
