
#ifndef _C11_ev535_
#define _C11_ev535_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1176_10769(EIF_REFERENCE);
extern EIF_REFERENCE F1176_10779(EIF_REFERENCE);
extern void EIF_Minit535(void);
extern void F1319_13063(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
