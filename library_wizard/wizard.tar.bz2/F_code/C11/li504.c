/*
 * Code for class LIBRARY_WIZARD_WINDOW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li504.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LIBRARY_WIZARD_WINDOW}.new_wizard */
EIF_REFERENCE F1144_10448 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(129, 0x01).id, 129, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F129_3062(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {LIBRARY_WIZARD_WINDOW}.side_bar_items */
EIF_REFERENCE F1144_10449 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	Result = F311_4893(Current, arg1);
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	tr2 = RTMS_EX_H("first",5,1769891700);
	tb2 = F1046_9027(RTCW(tr1), tr2);
	if (!tb2) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		tr2 = RTMS_EX_H("final",5,1769624940);
		tb2 = F1046_9027(RTCW(tr1), tr2);
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = RTLNS(eif_new_type(1152, 0x01).id, 1152, _OBJSIZ_5_2_0_1_0_0_0_0_);
		tr1 = RTMS_EX_H("Eiffel Library",14,952337273);
		F1112_9954(RTCW(loc1), tr1);
		tr1 = RTOSCF(974,F40_974, (RTCV(RTOSCF(2899,F111_2899, (Current)))));
		F1101_9875(RTCW(loc1), tr1);
		tr1 = RTLNS(eif_new_type(272, 0x01).id, 272, _OBJSIZ_2_0_0_0_0_0_0_0_);
		F273_4637(RTCW(tr1), loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4939[Dtype(RTCW(Result))-638])(Result, tr1);
	}
	RTLE;
	return Result;
}

void EIF_Minit504 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
