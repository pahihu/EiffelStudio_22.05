
#ifndef _C11_ev516_
#define _C11_ev516_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1156_10604(EIF_REFERENCE);
extern void F1156_10605(EIF_REFERENCE);
extern void EIF_Minit516(void);
extern void F1324_13156(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
