/*
 * Code for class EV_MESSAGE_DIALOG
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev507.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MESSAGE_DIALOG}.make_with_text */
void F1147_10471 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1083_9562(Current);
	F1147_10484(Current, arg1);
	RTLE;
}

/* {EV_MESSAGE_DIALOG}.create_interface_objects */
void F1147_10473 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,647,0xFF01,1158,0xFF01,1050,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F648_5588(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1132, 1).id);
	F1083_9562(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1135, 1).id);
	F1083_9562(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1138, 1).id);
	F1083_9562(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1152, 1).id);
	F1083_9562(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	loc1 = RTLNS(eif_new_type(39, 0x01).id, 39, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = F40_999(RTCW(loc1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	tr1 = F40_998(RTCW(loc1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {EV_MESSAGE_DIALOG}.initialize */
void F1147_10474 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,tr4);
	RTLR(10,tr5);
	RTLIU(11);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1226_11769(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1226_11770(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	loc1 = RTLNS(eif_new_type(1132, 0x01).id, 1132, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1083_9562(RTCW(loc1));
	loc2 = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1083_9562(RTCW(loc2));
	loc3 = RTLNS(eif_new_type(1132, 0x01).id, 1132, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1083_9562(RTCW(loc3));
	loc4 = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1083_9562(RTCW(loc4));
	F1145_10450(Current);
	loc5 = RTLNS(eif_new_type(1116, 0x01).id, 1116, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1083_9562(RTCW(loc5));
	ti4_1 = F1117_10051(RTCW(loc5));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_1_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 200L));
	ti4_1 = F1117_10052(RTCW(loc5));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 200L));
	F1125_10152(RTCW(loc4), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	F1132_10298(RTCW(loc4), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	tr1 = RTLNS(eif_new_type(1135, 0x01).id, 1135, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1083_9562(RTCW(tr1));
	F1125_10152(RTCW(loc4), tr1);
	F1125_10152(RTCW(loc1), loc4);
	F1125_10152(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
	F1132_10296(RTCW(loc1), ((EIF_INTEGER_32) 10L));
	tr1 = RTLNS(eif_new_type(1135, 0x01).id, 1135, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1083_9562(RTCW(tr1));
	F1125_10152(RTCW(loc3), tr1);
	F1125_10152(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	F1132_10298(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	tr1 = RTLNS(eif_new_type(1135, 0x01).id, 1135, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1083_9562(RTCW(tr1));
	F1125_10152(RTCW(loc3), tr1);
	F1125_10152(RTCW(loc2), loc1);
	F1125_10152(RTCW(loc2), loc3);
	F1132_10298(RTCW(loc2), loc3);
	F1132_10296(RTCW(loc2), ((EIF_INTEGER_32) 14L));
	F1132_10294(RTCW(loc2), ((EIF_INTEGER_32) 10L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	F1113_9966(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1132_10296(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	F1128_10228(Current, loc2);
	tr1 = RTMS_EX_H("Use `set_text\' to modify this message.",38,1665955374);
	F1147_10484(Current, tr1);
	tr1 = F1080_9532(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,966,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1371,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A507_356_2, (EIF_POINTER) _A507_356_2, (EIF_POINTER)(F1147_10503),tr2, 1, 1);
	}
	F672_5802(RTCW(tr1), tr5);
	F1140_10403(Current);
	RTLE;
}

/* {EV_MESSAGE_DIALOG}.pixmap */
EIF_REFERENCE F1147_10475 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tb1 = F1136_10348(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		Result = F1128_10219(RTCW(tr1));
		Result = RTRV(eif_new_type(1151, 0x00), Result);
	}
	RTLE;
	return Result;
}

/* {EV_MESSAGE_DIALOG}.foreground_color */
EIF_REFERENCE F1147_10477 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_13_);
}


/* {EV_MESSAGE_DIALOG}.background_color */
EIF_REFERENCE F1147_10478 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_12_);
}


/* {EV_MESSAGE_DIALOG}.default_identifier_name */
EIF_REFERENCE F1147_10479 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	tb1 = F491_5229(RTCV(F1140_10393(Current)));
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) F1096_9809(Current);
	} else {
		Result = F1051_9265(RTCV(F1140_10393(Current)));
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
		F1051_9256(RTCW(Result), tw1);
	}
	RTLE;
	return Result;
}

/* {EV_MESSAGE_DIALOG}.set_background_color */
void F1147_10480 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = F1128_10219(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8132[Dtype(RTCW(tr1))-1116])(tr1, arg1);
	loc1 = F1128_10219(Current);
	loc1 = RTRV(eif_new_type(1127, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1128_10236(RTCW(loc1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	F1090_9711(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_MESSAGE_DIALOG}.set_foreground_color */
void F1147_10481 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = F1128_10219(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8131[Dtype(RTCW(tr1))-1116])(tr1, arg1);
	loc1 = F1128_10219(Current);
	loc1 = RTRV(eif_new_type(1127, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1128_10235(RTCW(loc1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	F1090_9711(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_MESSAGE_DIALOG}.set_pixmap */
void F1147_10482 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(F1147_10475(Current) != NULL)) {
		F1147_10483(Current);
	}
	loc1 = RTLNS(eif_new_type(1151, 0x01).id, 1151, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1083_9562(RTCW(loc1));
	F1152_10556(RTCW(loc1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1128_10228(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	ti4_1 = F1104_9908(RTCW(loc1));
	ti4_2 = F1104_9909(RTCW(loc1));
	F1127_10213(RTCW(tr1), ti4_1, ti4_2);
	RTLE;
}

/* {EV_MESSAGE_DIALOG}.remove_pixmap */
void F1147_10483 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1136_10351(RTCW(tr1));
	RTLE;
}

/* {EV_MESSAGE_DIALOG}.set_text */
void F1147_10484 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,loc6);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = F1127_10187(RTCW(tr1));
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8397[Dtype(loc5)-1132])(loc5, *(EIF_REFERENCE *)(Current + _REFACS_8_));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1136_10350(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
		loc4 = (EIF_REFERENCE) loc5;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		tr1 = F1127_10187(RTCW(tr1));
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8397[Dtype(loc6)-1132])(loc6, *(EIF_REFERENCE *)(Current + _REFACS_9_));
			loc4 = (EIF_REFERENCE) loc6;
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	F1112_9956(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = F1104_9908(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = F1104_9909(RTCW(tr1));
	if ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_1_))) {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1139_10380(RTCW(tr1));
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_1_);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1139_10383(RTCW(tr1));
	}
	if ((EIF_BOOLEAN) (loc2 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_2_))) {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1139_10382(RTCW(tr1));
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_2_);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1139_10383(RTCW(tr1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	F1127_10211(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	F1127_10212(RTCW(tr1), loc2);
	if (loc3) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1128_10228(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8394[Dtype(RTCW(loc4))-1132])(loc4, *(EIF_REFERENCE *)(Current + _REFACS_8_));
		}
	} else {
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8394[Dtype(RTCW(loc4))-1132])(loc4, *(EIF_REFERENCE *)(Current + _REFACS_9_));
		}
	}
	RTLE;
}

/* {EV_MESSAGE_DIALOG}.set_buttons */
void F1147_10486 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1147_10499(Current);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		ti4_1 = F578_5357(RTCW(arg1));
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		tr1 = F578_5351(RTCW(arg1), loc1);
		F1147_10500(Current, tr1);
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1132_10292(RTCW(tr1));
	RTLE;
}

/* {EV_MESSAGE_DIALOG}.button */
EIF_REFERENCE F1147_10489 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = F1046_9044(RTCW(arg1));
	loc1 = F648_5594(RTCW(tr1), tr2);
	RTCT0("l_result /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_MESSAGE_DIALOG}.clean_buttons */
void F1147_10499 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(F1145_10451(Current) != NULL)) {
		F1145_10457(Current);
	}
	if ((EIF_BOOLEAN)(F1145_10452(Current) != NULL)) {
		F1145_10459(Current);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1125_10165(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	F648_5642(RTCW(tr1));
	RTLE;
}

/* {EV_MESSAGE_DIALOG}.add_button */
void F1147_10500 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1158, 0x01).id, 1158, _OBJSIZ_6_2_0_1_0_0_0_0_);
	F1112_9954(RTCW(loc1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = F1046_9044(RTCW(arg1));
	F648_5634(RTCW(tr1), loc1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc2 = F483_5229(RTCW(tr1));
	tr1 = F1077_9513(RTCW(loc1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,966,0xFF01,0,0xFF01,1045,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = arg1;
	RTAR(tr2,arg1);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A507_355, (EIF_POINTER) _A507_355, (EIF_POINTER)(F1147_10502),tr2, 1, 0);
	}
	F672_5802(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1125_10152(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1132_10298(RTCW(tr1), loc1);
	ti4_1 = F1104_9910(RTCW(loc1));
	ti4_1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 75L));
	F1127_10211(RTCW(loc1), ti4_1);
	F1113_9964(RTCW(loc1));
	if (loc2) {
		F1145_10456(Current, loc1);
	}
	RTLE;
}

/* {EV_MESSAGE_DIALOG}.on_button_press */
void F1147_10502 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1046_9044(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN) !F1083_9566(Current)) {
		F1140_10400(Current);
	}
	RTLE;
}

/* {EV_MESSAGE_DIALOG}.on_key_press */
void F1147_10503 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 60L))) {
		F1147_10504(Current, ((EIF_INTEGER_32) -1L));
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 61L))) {
			F1147_10504(Current, ((EIF_INTEGER_32) 1L));
		}
	}
	RTLE;
}

/* {EV_MESSAGE_DIALOG}.move_to_next_button */
void F1147_10504 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	ti4_1 = F1125_10141(RTCW(loc1));
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
		loc2 = F1125_10136(RTCW(loc1));
		F1125_10144(RTCW(loc1));
		for (;;) {
			tb1 = '\01';
			tb2 = F615_5464(RTCW(loc1));
			if (!tb2) {
				tb1 = loc4;
			}
			if (tb1) break;
			loc3 = F1125_10134(RTCW(loc1));
			loc4 = F1127_10197(RTCW(loc3));
			if ((EIF_BOOLEAN) !loc4) {
				F1125_10146(RTCW(loc1));
			}
		}
		if (loc4) {
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) -1L))) {
					tr1 = F591_5425(RTCW(loc1));
					if ((EIF_BOOLEAN)(tr1 == loc3)) {
						tr1 = F591_5426(RTCW(loc1));
						F1127_10201(RTCW(tr1));
					} else {
						F1125_10145(RTCW(loc1));
						tr1 = F1125_10134(RTCW(loc1));
						F1127_10201(RTCW(tr1));
					}
				} else {
					tr1 = F591_5426(RTCW(loc1));
					if ((EIF_BOOLEAN)(tr1 == loc3)) {
						tr1 = F591_5425(RTCW(loc1));
						F1127_10201(RTCW(tr1));
					} else {
						F1125_10146(RTCW(loc1));
						tr1 = F1125_10134(RTCW(loc1));
						F1127_10201(RTCW(tr1));
					}
				}
			}
		} else {
			tr1 = F591_5425(RTCW(loc1));
			F1127_10201(RTCW(tr1));
		}
		F1125_10148(RTCW(loc1), loc2);
	}
	RTLE;
}

void EIF_Minit507 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
