
#ifndef _C11_ev547_
#define _C11_ev547_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1188_10853(EIF_REFERENCE, EIF_REFERENCE);
extern void F1188_10856(EIF_REFERENCE);
extern EIF_BOOLEAN F1188_10858(EIF_REFERENCE);
extern EIF_REFERENCE F1188_10859(EIF_REFERENCE);
extern void F1188_10868(EIF_REFERENCE, EIF_INTEGER_8, EIF_BOOLEAN);
extern EIF_BOOLEAN F1188_10869(EIF_REFERENCE, EIF_INTEGER_8);
extern EIF_BOOLEAN F1188_10872(EIF_REFERENCE);
extern void F1188_10873(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1188_10874(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1188_10875(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit547(void);
extern char *(*R8819[])();
extern long O8822[];
extern long O8823[];

#ifdef __cplusplus
}
#endif

#endif
