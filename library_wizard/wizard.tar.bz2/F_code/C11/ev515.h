
#ifndef _C11_ev515_
#define _C11_ev515_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1155_10582(EIF_REFERENCE);
extern void EIF_Minit515(void);
extern char *(*R10209[])();

#ifdef __cplusplus
}
#endif

#endif
