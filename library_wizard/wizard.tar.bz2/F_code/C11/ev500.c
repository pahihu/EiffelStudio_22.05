/*
 * Code for class EV_WINDOW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev500.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WINDOW}.initialize */
void F1140_10388 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLIU(6);
	
	RTGC;
	F1083_9571(Current);
	tr1 = *(EIF_REFERENCE *)(RTCV(F1140_10396(Current)) + _REFACS_3_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,966,0xFF01,1289,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	tr3 = *(EIF_REFERENCE *)(Current + O7887[dtype-1082]);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1094,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A645_263_2, (EIF_POINTER) _A645_263_2, (EIF_POINTER)(F1294_12629),tr2, 1, 1);
	}
	F672_5802(RTCW(tr1), tr5);
	tr1 = *(EIF_REFERENCE *)(RTCV(F1140_10396(Current)) + _REFACS_4_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,966,0xFF01,1289,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	tr3 = *(EIF_REFERENCE *)(Current + O7887[dtype-1082]);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1094,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A645_264_2, (EIF_POINTER) _A645_264_2, (EIF_POINTER)(F1294_12630),tr2, 1, 1);
	}
	F672_5802(RTCW(tr1), tr5);
	RTLE;
}

/* {EV_WINDOW}.title */
EIF_REFERENCE F1140_10393 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	Result = F1294_12610(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_WINDOW}.accelerators */
EIF_REFERENCE F1140_10396 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	Result = F1290_12539(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_WINDOW}.has */
EIF_BOOLEAN F1140_10397 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	Result = F1290_12536(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {EV_WINDOW}.destroy */
void F1140_10400 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1083_9565(Current);
	tr1 = F1093_9765(RTCV(RTOSCF(3970,F242_3970, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1099_9864(loc1, Current);
	}
	RTLE;
}

/* {EV_WINDOW}.disable_user_resize */
void F1140_10403 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	F1294_12617(RTCW(tr1));
	RTLE;
}

/* {EV_WINDOW}.set_title */
void F1140_10409 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = arg1;
	if ((EIF_TRUE)) {
		tr1 = *(EIF_REFERENCE *)(Current + O7887[dtype-1082]);
		F1294_12626(RTCW(tr1), loc1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O7887[dtype-1082]);
		tr2 = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1049_9123(RTCW(tr2), arg1);
		F1294_12626(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {EV_WINDOW}.unlock_update */
void F1140_10414 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
	F1290_12553(RTCW(tr1));
	RTLE;
}

/* {EV_WINDOW}.show */
void F1140_10415 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1127_10200(Current);
	tr1 = F1093_9765(RTCV(RTOSCF(3970,F242_3970, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1099_9863(loc1, Current);
	}
	RTLE;
}

/* {EV_WINDOW}.implementation */
EIF_REFERENCE F1140_10418 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]);
}


/* {EV_WINDOW}.create_implementation */
void F1140_10422 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1293, 0x01).id, 1293, _OBJSIZ_59_21_10_11_0_4_0_0_);
	F1294_12606(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O7887[Dtype(Current)-1082]) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit500 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
