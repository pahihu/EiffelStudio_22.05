
#ifndef _C11_ev506_
#define _C11_ev506_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1146_10468(EIF_REFERENCE, EIF_REFERENCE);
extern void F1146_10469(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1146_10470(EIF_REFERENCE);
extern void EIF_Minit506(void);

#ifdef __cplusplus
}
#endif

#endif
