#include "epoly6.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4812[1024])();
void R4812_init () {
	R4812[0] = (char *(*)()) F336_5000;
	R4812[226] = (char *(*)()) F337_5000;
	R4812[228] = (char *(*)()) F336_5000;
	R4812[229] = (char *(*)()) F337_5000;
	R4812[230] = (char *(*)()) F338_5000;
	R4812[231] = (char *(*)()) F339_5000;
	R4812[232] = (char *(*)()) F340_5000;
	R4812[233] = (char *(*)()) F341_5000;
	R4812[234] = (char *(*)()) F342_5000;
	R4812[235] = (char *(*)()) F343_5000;
	R4812[236] = (char *(*)()) F344_5000;
	R4812[237] = (char *(*)()) F345_5000;
	R4812[238] = (char *(*)()) F346_5000;
	R4812[239] = (char *(*)()) F347_5000;
	R4812[289] = (char *(*)()) F336_5000;
	R4812[290] = (char *(*)()) F337_5000;
	R4812[291] = (char *(*)()) F343_5000;
	R4812[292] = (char *(*)()) F336_5000;
	R4812[293] = (char *(*)()) F343_5000;
	R4812[294] = (char *(*)()) F337_5000;
	R4812[295] = (char *(*)()) F336_5000;
	R4812[298] = (char *(*)()) F336_5000;
	R4812[299] = (char *(*)()) F337_5000;
	R4812[300] = (char *(*)()) F336_5000;
	{long i; for (i = 301; i < 303; i++) R4812[i] = (char *(*)()) F337_5000;}
	R4812[303] = (char *(*)()) F346_5000;
	R4812[304] = (char *(*)()) F336_5000;
	R4812[305] = (char *(*)()) F337_5000;
	{long i; for (i = 306; i < 308; i++) R4812[i] = (char *(*)()) F336_5000;}
	R4812[308] = (char *(*)()) F337_5000;
	R4812[309] = (char *(*)()) F338_5000;
	R4812[310] = (char *(*)()) F339_5000;
	R4812[311] = (char *(*)()) F340_5000;
	R4812[312] = (char *(*)()) F341_5000;
	R4812[313] = (char *(*)()) F342_5000;
	R4812[314] = (char *(*)()) F343_5000;
	R4812[315] = (char *(*)()) F344_5000;
	R4812[316] = (char *(*)()) F345_5000;
	R4812[317] = (char *(*)()) F346_5000;
	R4812[318] = (char *(*)()) F347_5000;
	R4812[319] = (char *(*)()) F336_5000;
	R4812[320] = (char *(*)()) F337_5000;
	R4812[321] = (char *(*)()) F343_5000;
	R4812[326] = (char *(*)()) F336_5000;
	R4812[327] = (char *(*)()) F337_5000;
	{long i; for (i = 328; i < 332; i++) R4812[i] = (char *(*)()) F336_5000;}
	R4812[336] = (char *(*)()) F336_5000;
	R4812[338] = (char *(*)()) F336_5000;
	R4812[342] = (char *(*)()) F336_5000;
	{long i; for (i = 344; i < 346; i++) R4812[i] = (char *(*)()) F336_5000;}
	{long i; for (i = 347; i < 350; i++) R4812[i] = (char *(*)()) F336_5000;}
	R4812[372] = (char *(*)()) F337_5000;
	R4812[377] = (char *(*)()) F337_5000;
	{long i; for (i = 570; i < 572; i++) R4812[i] = (char *(*)()) F342_5000;}
	R4812[701] = (char *(*)()) F344_5000;
	R4812[704] = (char *(*)()) F342_5000;
	{long i; for (i = 783; i < 788; i++) R4812[i] = (char *(*)()) F336_5000;}
	{long i; for (i = 789; i < 791; i++) R4812[i] = (char *(*)()) F336_5000;}
	{long i; for (i = 794; i < 797; i++) R4812[i] = (char *(*)()) F336_5000;}
	R4812[798] = (char *(*)()) F336_5000;
	R4812[826] = (char *(*)()) F336_5000;
	R4812[836] = (char *(*)()) F336_5000;
	R4812[1023] = (char *(*)()) F342_5000;
}

char *(*R4814[1024])();
void R4814_init () {
	R4814[0] = (char *(*)()) F348_5055;
	R4814[226] = (char *(*)()) F576_5323;
	R4814[228] = (char *(*)()) F578_5397;
	R4814[229] = (char *(*)()) F579_5397;
	R4814[230] = (char *(*)()) F580_5397;
	R4814[231] = (char *(*)()) F581_5397;
	R4814[232] = (char *(*)()) F582_5397;
	R4814[233] = (char *(*)()) F583_5397;
	R4814[234] = (char *(*)()) F584_5397;
	R4814[235] = (char *(*)()) F585_5397;
	R4814[236] = (char *(*)()) F586_5397;
	R4814[237] = (char *(*)()) F587_5397;
	R4814[238] = (char *(*)()) F588_5397;
	R4814[239] = (char *(*)()) F589_5397;
	R4814[289] = (char *(*)()) F363_5168;
	R4814[290] = (char *(*)()) F364_5168;
	R4814[291] = (char *(*)()) F370_5168;
	R4814[292] = (char *(*)()) F642_5527;
	R4814[293] = (char *(*)()) F643_5527;
	R4814[294] = (char *(*)()) F644_5527;
	R4814[295] = (char *(*)()) F645_5541;
	R4814[298] = (char *(*)()) F648_5644;
	R4814[299] = (char *(*)()) F649_5644;
	R4814[300] = (char *(*)()) F650_5644;
	R4814[301] = (char *(*)()) F651_5644;
	R4814[302] = (char *(*)()) F652_5644;
	R4814[303] = (char *(*)()) F653_5644;
	R4814[304] = (char *(*)()) F648_5644;
	R4814[305] = (char *(*)()) F649_5644;
	R4814[306] = (char *(*)()) F648_5644;
	R4814[307] = (char *(*)()) F363_5168;
	R4814[308] = (char *(*)()) F364_5168;
	R4814[309] = (char *(*)()) F365_5168;
	R4814[310] = (char *(*)()) F366_5168;
	R4814[311] = (char *(*)()) F367_5168;
	R4814[312] = (char *(*)()) F368_5168;
	R4814[313] = (char *(*)()) F369_5168;
	R4814[314] = (char *(*)()) F370_5168;
	R4814[315] = (char *(*)()) F371_5168;
	R4814[316] = (char *(*)()) F372_5168;
	R4814[317] = (char *(*)()) F373_5168;
	R4814[318] = (char *(*)()) F374_5168;
	R4814[319] = (char *(*)()) F669_5790;
	R4814[320] = (char *(*)()) F670_5790;
	R4814[321] = (char *(*)()) F671_5790;
	R4814[326] = (char *(*)()) F363_5168;
	R4814[327] = (char *(*)()) F364_5168;
	{long i; for (i = 328; i < 332; i++) R4814[i] = (char *(*)()) F363_5168;}
	R4814[336] = (char *(*)()) F363_5168;
	R4814[338] = (char *(*)()) F363_5168;
	R4814[342] = (char *(*)()) F363_5168;
	{long i; for (i = 344; i < 346; i++) R4814[i] = (char *(*)()) F363_5168;}
	{long i; for (i = 347; i < 350; i++) R4814[i] = (char *(*)()) F363_5168;}
	R4814[372] = (char *(*)()) F482_5222;
	R4814[377] = (char *(*)()) F482_5222;
	{long i; for (i = 570; i < 572; i++) R4814[i] = (char *(*)()) F369_5168;}
	R4814[701] = (char *(*)()) F1051_9273;
	R4814[704] = (char *(*)()) F1054_9438;
	{long i; for (i = 783; i < 786; i++) R4814[i] = (char *(*)()) F363_5168;}
	{long i; for (i = 786; i < 788; i++) R4814[i] = (char *(*)()) F1136_10352;}
	{long i; for (i = 789; i < 791; i++) R4814[i] = (char *(*)()) F1136_10352;}
	{long i; for (i = 794; i < 797; i++) R4814[i] = (char *(*)()) F1136_10352;}
	R4814[798] = (char *(*)()) F1136_10352;
	R4814[826] = (char *(*)()) F363_5168;
	R4814[836] = (char *(*)()) F363_5168;
	R4814[1023] = (char *(*)()) F369_5168;
}

EIF_TYPE_INDEX *Y4821_gen_type [3];
EIF_TYPE_INDEX Y4821 [3];
void Y4821_init (void)
{
	egc_routines_types [4821] = Y4821;
	egc_routines_gen_types [4821] = Y4821_gen_type;
	egc_routines_offset [4821] = 347;
	{long i; for (i = 0; i < 3; i++) Y4821[i] = 984;};
}

char *(*R4917[735])();
void R4917_init () {
	R4917[0] = (char *(*)()) F639_5477;
	R4917[1] = (char *(*)()) F640_5477_4917_1;
	R4917[2] = (char *(*)()) F641_5477_4917_1;
	R4917[3] = (char *(*)()) F639_5477;
	R4917[4] = (char *(*)()) F641_5477_4917_1;
	R4917[5] = (char *(*)()) F640_5477_4917_1;
	R4917[6] = (char *(*)()) F639_5477;
	R4917[18] = (char *(*)()) F657_5724;
	R4917[19] = (char *(*)()) F658_5724_4917_1;
	R4917[20] = (char *(*)()) F659_5724_4917_1;
	R4917[21] = (char *(*)()) F660_5724_4917_1;
	R4917[22] = (char *(*)()) F661_5724_4917_1;
	R4917[23] = (char *(*)()) F662_5724_4917_1;
	R4917[24] = (char *(*)()) F663_5724_4917_1;
	R4917[25] = (char *(*)()) F664_5724_4917_1;
	R4917[26] = (char *(*)()) F665_5724_4917_1;
	R4917[27] = (char *(*)()) F666_5724_4917_1;
	R4917[28] = (char *(*)()) F667_5724_4917_1;
	R4917[29] = (char *(*)()) F668_5724_4917_1;
	R4917[30] = (char *(*)()) F657_5724;
	R4917[31] = (char *(*)()) F658_5724_4917_1;
	R4917[32] = (char *(*)()) F664_5724_4917_1;
	R4917[37] = (char *(*)()) F657_5724;
	R4917[38] = (char *(*)()) F658_5724_4917_1;
	{long i; for (i = 39; i < 43; i++) R4917[i] = (char *(*)()) F657_5724;}
	R4917[47] = (char *(*)()) F657_5724;
	R4917[49] = (char *(*)()) F657_5724;
	R4917[53] = (char *(*)()) F657_5724;
	{long i; for (i = 55; i < 57; i++) R4917[i] = (char *(*)()) F657_5724;}
	{long i; for (i = 58; i < 61; i++) R4917[i] = (char *(*)()) F657_5724;}
	R4917[83] = (char *(*)()) F482_5211_4917_1;
	R4917[88] = (char *(*)()) F482_5211_4917_1;
	{long i; for (i = 281; i < 283; i++) R4917[i] = (char *(*)()) F919_7094_4917_1;}
	{long i; for (i = 494; i < 497; i++) R4917[i] = (char *(*)()) F1125_10134;}
	R4917[537] = (char *(*)()) F1125_10134;
	R4917[547] = (char *(*)()) F1125_10134;
	R4917[734] = (char *(*)()) F919_7094_4917_1;
}
static EIF_REFERENCE F640_5477_4917_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F640_5477(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_5477_4917_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F641_5477(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_5724_4917_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5724_4917_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F659_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5724_4917_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F660_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_5724_4917_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F661_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_5724_4917_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F662_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_5724_4917_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F663_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5724_4917_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F664_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5724_4917_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F665_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5724_4917_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F666_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5724_4917_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F667_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5724_4917_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F668_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F482_5211_4917_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F482_5211(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F919_7094_4917_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F919_7094(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4918[735])();
void R4918_init () {
	R4918[0] = (char *(*)()) F639_5488;
	R4918[1] = (char *(*)()) F640_5488;
	R4918[2] = (char *(*)()) F641_5488;
	R4918[3] = (char *(*)()) F639_5488;
	R4918[4] = (char *(*)()) F641_5488;
	R4918[5] = (char *(*)()) F640_5488;
	R4918[6] = (char *(*)()) F639_5488;
	R4918[18] = (char *(*)()) F591_5440;
	R4918[19] = (char *(*)()) F592_5440;
	R4918[20] = (char *(*)()) F593_5440;
	R4918[21] = (char *(*)()) F594_5440;
	R4918[22] = (char *(*)()) F595_5440;
	R4918[23] = (char *(*)()) F596_5440;
	R4918[24] = (char *(*)()) F597_5440;
	R4918[25] = (char *(*)()) F598_5440;
	R4918[26] = (char *(*)()) F599_5440;
	R4918[27] = (char *(*)()) F600_5440;
	R4918[28] = (char *(*)()) F601_5440;
	R4918[29] = (char *(*)()) F602_5440;
	R4918[30] = (char *(*)()) F591_5440;
	R4918[31] = (char *(*)()) F592_5440;
	R4918[32] = (char *(*)()) F598_5440;
	R4918[37] = (char *(*)()) F591_5440;
	R4918[38] = (char *(*)()) F592_5440;
	{long i; for (i = 39; i < 43; i++) R4918[i] = (char *(*)()) F591_5440;}
	R4918[47] = (char *(*)()) F591_5440;
	R4918[49] = (char *(*)()) F591_5440;
	R4918[53] = (char *(*)()) F591_5440;
	{long i; for (i = 55; i < 57; i++) R4918[i] = (char *(*)()) F591_5440;}
	{long i; for (i = 58; i < 61; i++) R4918[i] = (char *(*)()) F591_5440;}
	R4918[83] = (char *(*)()) F364_5161;
	R4918[88] = (char *(*)()) F364_5161;
	{long i; for (i = 281; i < 283; i++) R4918[i] = (char *(*)()) F919_7115;}
	{long i; for (i = 494; i < 497; i++) R4918[i] = (char *(*)()) F591_5440;}
	R4918[537] = (char *(*)()) F591_5440;
	R4918[547] = (char *(*)()) F591_5440;
	R4918[734] = (char *(*)()) F919_7115;
}

char *(*R4919[735])();
void R4919_init () {
	R4919[0] = (char *(*)()) F639_5494;
	R4919[1] = (char *(*)()) F640_5494;
	R4919[2] = (char *(*)()) F641_5494;
	R4919[3] = (char *(*)()) F639_5494;
	R4919[4] = (char *(*)()) F641_5494;
	R4919[5] = (char *(*)()) F640_5494;
	R4919[6] = (char *(*)()) F639_5494;
	R4919[18] = (char *(*)()) F657_5750;
	R4919[19] = (char *(*)()) F658_5750;
	R4919[20] = (char *(*)()) F659_5750;
	R4919[21] = (char *(*)()) F660_5750;
	R4919[22] = (char *(*)()) F661_5750;
	R4919[23] = (char *(*)()) F662_5750;
	R4919[24] = (char *(*)()) F663_5750;
	R4919[25] = (char *(*)()) F664_5750;
	R4919[26] = (char *(*)()) F665_5750;
	R4919[27] = (char *(*)()) F666_5750;
	R4919[28] = (char *(*)()) F667_5750;
	R4919[29] = (char *(*)()) F668_5750;
	R4919[30] = (char *(*)()) F657_5750;
	R4919[31] = (char *(*)()) F658_5750;
	R4919[32] = (char *(*)()) F664_5750;
	R4919[37] = (char *(*)()) F657_5750;
	R4919[38] = (char *(*)()) F658_5750;
	{long i; for (i = 39; i < 43; i++) R4919[i] = (char *(*)()) F657_5750;}
	R4919[47] = (char *(*)()) F657_5750;
	R4919[49] = (char *(*)()) F657_5750;
	R4919[53] = (char *(*)()) F657_5750;
	{long i; for (i = 55; i < 57; i++) R4919[i] = (char *(*)()) F657_5750;}
	{long i; for (i = 58; i < 61; i++) R4919[i] = (char *(*)()) F657_5750;}
	R4919[83] = (char *(*)()) F482_5219;
	R4919[88] = (char *(*)()) F482_5219;
	{long i; for (i = 281; i < 283; i++) R4919[i] = (char *(*)()) F919_7170;}
	{long i; for (i = 494; i < 497; i++) R4919[i] = (char *(*)()) F1125_10144;}
	R4919[537] = (char *(*)()) F1125_10144;
	R4919[547] = (char *(*)()) F1125_10144;
	R4919[734] = (char *(*)()) F919_7170;
}

char *(*R4925[735])();
void R4925_init () {
	R4925[0] = (char *(*)()) F375_5172;
	R4925[1] = (char *(*)()) F376_5172_4925_4;
	R4925[2] = (char *(*)()) F382_5172_4925_4;
	R4925[3] = (char *(*)()) F375_5172;
	R4925[4] = (char *(*)()) F382_5172_4925_4;
	R4925[5] = (char *(*)()) F376_5172_4925_4;
	R4925[6] = (char *(*)()) F375_5172;
	R4925[18] = (char *(*)()) F657_5756;
	R4925[19] = (char *(*)()) F658_5756_4925_4;
	R4925[20] = (char *(*)()) F659_5756_4925_4;
	R4925[21] = (char *(*)()) F660_5756_4925_4;
	R4925[22] = (char *(*)()) F661_5756_4925_4;
	R4925[23] = (char *(*)()) F662_5756_4925_4;
	R4925[24] = (char *(*)()) F663_5756_4925_4;
	R4925[25] = (char *(*)()) F664_5756_4925_4;
	R4925[26] = (char *(*)()) F665_5756_4925_4;
	R4925[27] = (char *(*)()) F666_5756_4925_4;
	R4925[28] = (char *(*)()) F667_5756_4925_4;
	R4925[29] = (char *(*)()) F668_5756_4925_4;
	R4925[30] = (char *(*)()) F657_5756;
	R4925[31] = (char *(*)()) F658_5756_4925_4;
	R4925[32] = (char *(*)()) F664_5756_4925_4;
	R4925[37] = (char *(*)()) F657_5756;
	R4925[38] = (char *(*)()) F658_5756_4925_4;
	{long i; for (i = 39; i < 43; i++) R4925[i] = (char *(*)()) F657_5756;}
	R4925[47] = (char *(*)()) F657_5756;
	R4925[49] = (char *(*)()) F657_5756;
	R4925[53] = (char *(*)()) F657_5756;
	{long i; for (i = 55; i < 57; i++) R4925[i] = (char *(*)()) F657_5756;}
	{long i; for (i = 58; i < 61; i++) R4925[i] = (char *(*)()) F657_5756;}
	R4925[83] = (char *(*)()) F364_5155_4925_4;
	R4925[88] = (char *(*)()) F364_5155_4925_4;
	{long i; for (i = 281; i < 283; i++) R4925[i] = (char *(*)()) F381_5172_4925_4;}
	{long i; for (i = 494; i < 497; i++) R4925[i] = (char *(*)()) F375_5172;}
	R4925[537] = (char *(*)()) F375_5172;
	R4925[547] = (char *(*)()) F375_5172;
	R4925[734] = (char *(*)()) F381_5172_4925_4;
}
static void F376_5172_4925_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F376_5172(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F382_5172_4925_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F382_5172(Current, *(EIF_BOOLEAN *)arg1);
}
static void F658_5756_4925_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5756(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F659_5756_4925_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5756(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F660_5756_4925_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F660_5756(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F661_5756_4925_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_5756(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F662_5756_4925_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F662_5756(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F663_5756_4925_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_5756(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F664_5756_4925_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5756(Current, *(EIF_BOOLEAN *)arg1);
}
static void F665_5756_4925_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5756(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F666_5756_4925_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5756(Current, *(EIF_REAL_32 *)arg1);
}
static void F667_5756_4925_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5756(Current, *(EIF_POINTER *)arg1);
}
static void F668_5756_4925_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5756(Current, *(EIF_REAL_64 *)arg1);
}
static void F364_5155_4925_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F364_5155(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F381_5172_4925_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F381_5172(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4926[735])();
void R4926_init () {
	R4926[0] = (char *(*)()) F639_5480;
	R4926[1] = (char *(*)()) F640_5480;
	R4926[2] = (char *(*)()) F641_5480;
	R4926[3] = (char *(*)()) F639_5480;
	R4926[4] = (char *(*)()) F641_5480;
	R4926[5] = (char *(*)()) F640_5480;
	R4926[6] = (char *(*)()) F639_5480;
	R4926[18] = (char *(*)()) F657_5729;
	R4926[19] = (char *(*)()) F658_5729;
	R4926[20] = (char *(*)()) F659_5729;
	R4926[21] = (char *(*)()) F660_5729;
	R4926[22] = (char *(*)()) F661_5729;
	R4926[23] = (char *(*)()) F662_5729;
	R4926[24] = (char *(*)()) F663_5729;
	R4926[25] = (char *(*)()) F664_5729;
	R4926[26] = (char *(*)()) F665_5729;
	R4926[27] = (char *(*)()) F666_5729;
	R4926[28] = (char *(*)()) F667_5729;
	R4926[29] = (char *(*)()) F668_5729;
	R4926[30] = (char *(*)()) F657_5729;
	R4926[31] = (char *(*)()) F658_5729;
	R4926[32] = (char *(*)()) F664_5729;
	R4926[37] = (char *(*)()) F657_5729;
	R4926[38] = (char *(*)()) F658_5729;
	{long i; for (i = 39; i < 43; i++) R4926[i] = (char *(*)()) F657_5729;}
	R4926[47] = (char *(*)()) F657_5729;
	R4926[49] = (char *(*)()) F657_5729;
	R4926[53] = (char *(*)()) F657_5729;
	{long i; for (i = 55; i < 57; i++) R4926[i] = (char *(*)()) F657_5729;}
	{long i; for (i = 58; i < 61; i++) R4926[i] = (char *(*)()) F657_5729;}
	R4926[83] = (char *(*)()) F482_5210;
	R4926[88] = (char *(*)()) F482_5210;
	{long i; for (i = 281; i < 283; i++) R4926[i] = (char *(*)()) F919_7095;}
	{long i; for (i = 494; i < 497; i++) R4926[i] = (char *(*)()) F1125_10135;}
	R4926[537] = (char *(*)()) F1125_10135;
	R4926[547] = (char *(*)()) F1125_10135;
	R4926[734] = (char *(*)()) F919_7095;
}

char *(*R4929[735])();
void R4929_init () {
	R4929[0] = (char *(*)()) F363_5159;
	R4929[1] = (char *(*)()) F364_5159;
	R4929[2] = (char *(*)()) F370_5159;
	R4929[3] = (char *(*)()) F363_5159;
	R4929[4] = (char *(*)()) F370_5159;
	R4929[5] = (char *(*)()) F364_5159;
	R4929[6] = (char *(*)()) F363_5159;
	R4929[18] = (char *(*)()) F363_5159;
	R4929[19] = (char *(*)()) F364_5159;
	R4929[20] = (char *(*)()) F365_5159;
	R4929[21] = (char *(*)()) F366_5159;
	R4929[22] = (char *(*)()) F367_5159;
	R4929[23] = (char *(*)()) F368_5159;
	R4929[24] = (char *(*)()) F369_5159;
	R4929[25] = (char *(*)()) F370_5159;
	R4929[26] = (char *(*)()) F371_5159;
	R4929[27] = (char *(*)()) F372_5159;
	R4929[28] = (char *(*)()) F373_5159;
	R4929[29] = (char *(*)()) F374_5159;
	R4929[30] = (char *(*)()) F363_5159;
	R4929[31] = (char *(*)()) F364_5159;
	R4929[32] = (char *(*)()) F370_5159;
	R4929[37] = (char *(*)()) F363_5159;
	R4929[38] = (char *(*)()) F364_5159;
	{long i; for (i = 39; i < 43; i++) R4929[i] = (char *(*)()) F363_5159;}
	R4929[47] = (char *(*)()) F363_5159;
	R4929[49] = (char *(*)()) F363_5159;
	R4929[53] = (char *(*)()) F363_5159;
	{long i; for (i = 55; i < 57; i++) R4929[i] = (char *(*)()) F363_5159;}
	{long i; for (i = 58; i < 61; i++) R4929[i] = (char *(*)()) F363_5159;}
	R4929[83] = (char *(*)()) F364_5159;
	R4929[88] = (char *(*)()) F364_5159;
	{long i; for (i = 281; i < 283; i++) R4929[i] = (char *(*)()) F369_5159;}
	{long i; for (i = 494; i < 497; i++) R4929[i] = (char *(*)()) F363_5159;}
	R4929[537] = (char *(*)()) F363_5159;
	R4929[547] = (char *(*)()) F363_5159;
	R4929[734] = (char *(*)()) F369_5159;
}

char *(*R4930[735])();
void R4930_init () {
	R4930[0] = (char *(*)()) F639_5486;
	R4930[1] = (char *(*)()) F640_5486;
	R4930[2] = (char *(*)()) F641_5486;
	R4930[3] = (char *(*)()) F639_5486;
	R4930[4] = (char *(*)()) F641_5486;
	R4930[5] = (char *(*)()) F640_5486;
	R4930[6] = (char *(*)()) F639_5486;
	R4930[18] = (char *(*)()) F615_5464;
	R4930[19] = (char *(*)()) F616_5464;
	R4930[20] = (char *(*)()) F617_5464;
	R4930[21] = (char *(*)()) F618_5464;
	R4930[22] = (char *(*)()) F619_5464;
	R4930[23] = (char *(*)()) F620_5464;
	R4930[24] = (char *(*)()) F621_5464;
	R4930[25] = (char *(*)()) F622_5464;
	R4930[26] = (char *(*)()) F623_5464;
	R4930[27] = (char *(*)()) F624_5464;
	R4930[28] = (char *(*)()) F625_5464;
	R4930[29] = (char *(*)()) F626_5464;
	R4930[30] = (char *(*)()) F615_5464;
	R4930[31] = (char *(*)()) F616_5464;
	R4930[32] = (char *(*)()) F622_5464;
	R4930[37] = (char *(*)()) F615_5464;
	R4930[38] = (char *(*)()) F616_5464;
	{long i; for (i = 39; i < 43; i++) R4930[i] = (char *(*)()) F615_5464;}
	R4930[47] = (char *(*)()) F615_5464;
	R4930[49] = (char *(*)()) F615_5464;
	R4930[53] = (char *(*)()) F615_5464;
	{long i; for (i = 55; i < 57; i++) R4930[i] = (char *(*)()) F615_5464;}
	{long i; for (i = 58; i < 61; i++) R4930[i] = (char *(*)()) F615_5464;}
	R4930[83] = (char *(*)()) F482_5212;
	R4930[88] = (char *(*)()) F482_5212;
	{long i; for (i = 281; i < 283; i++) R4930[i] = (char *(*)()) F919_7113;}
	{long i; for (i = 494; i < 497; i++) R4930[i] = (char *(*)()) F615_5464;}
	R4930[537] = (char *(*)()) F615_5464;
	R4930[547] = (char *(*)()) F615_5464;
	R4930[734] = (char *(*)()) F919_7113;
}

char *(*R4931[548])();
void R4931_init () {
	R4931[0] = (char *(*)()) F639_5495;
	R4931[1] = (char *(*)()) F640_5495;
	R4931[2] = (char *(*)()) F641_5495;
	R4931[3] = (char *(*)()) F639_5495;
	R4931[4] = (char *(*)()) F641_5495;
	R4931[5] = (char *(*)()) F640_5495;
	R4931[6] = (char *(*)()) F639_5495;
	R4931[18] = (char *(*)()) F657_5751;
	R4931[19] = (char *(*)()) F658_5751;
	R4931[20] = (char *(*)()) F659_5751;
	R4931[21] = (char *(*)()) F660_5751;
	R4931[22] = (char *(*)()) F661_5751;
	R4931[23] = (char *(*)()) F662_5751;
	R4931[24] = (char *(*)()) F663_5751;
	R4931[25] = (char *(*)()) F664_5751;
	R4931[26] = (char *(*)()) F665_5751;
	R4931[27] = (char *(*)()) F666_5751;
	R4931[28] = (char *(*)()) F667_5751;
	R4931[29] = (char *(*)()) F668_5751;
	R4931[30] = (char *(*)()) F657_5751;
	R4931[31] = (char *(*)()) F658_5751;
	R4931[32] = (char *(*)()) F664_5751;
	R4931[37] = (char *(*)()) F657_5751;
	R4931[38] = (char *(*)()) F658_5751;
	{long i; for (i = 39; i < 43; i++) R4931[i] = (char *(*)()) F657_5751;}
	R4931[47] = (char *(*)()) F657_5751;
	R4931[49] = (char *(*)()) F657_5751;
	R4931[53] = (char *(*)()) F657_5751;
	{long i; for (i = 55; i < 57; i++) R4931[i] = (char *(*)()) F657_5751;}
	{long i; for (i = 58; i < 61; i++) R4931[i] = (char *(*)()) F657_5751;}
	{long i; for (i = 494; i < 497; i++) R4931[i] = (char *(*)()) F591_5434;}
	R4931[537] = (char *(*)()) F591_5434;
	R4931[547] = (char *(*)()) F591_5434;
}

char *(*R4932[735])();
void R4932_init () {
	R4932[0] = (char *(*)()) F639_5496;
	R4932[1] = (char *(*)()) F640_5496;
	R4932[2] = (char *(*)()) F641_5496;
	R4932[3] = (char *(*)()) F639_5496;
	R4932[4] = (char *(*)()) F641_5496;
	R4932[5] = (char *(*)()) F640_5496;
	R4932[6] = (char *(*)()) F639_5496;
	R4932[18] = (char *(*)()) F657_5752;
	R4932[19] = (char *(*)()) F658_5752;
	R4932[20] = (char *(*)()) F659_5752;
	R4932[21] = (char *(*)()) F660_5752;
	R4932[22] = (char *(*)()) F661_5752;
	R4932[23] = (char *(*)()) F662_5752;
	R4932[24] = (char *(*)()) F663_5752;
	R4932[25] = (char *(*)()) F664_5752;
	R4932[26] = (char *(*)()) F665_5752;
	R4932[27] = (char *(*)()) F666_5752;
	R4932[28] = (char *(*)()) F667_5752;
	R4932[29] = (char *(*)()) F668_5752;
	R4932[30] = (char *(*)()) F657_5752;
	R4932[31] = (char *(*)()) F658_5752;
	R4932[32] = (char *(*)()) F664_5752;
	R4932[37] = (char *(*)()) F657_5752;
	R4932[38] = (char *(*)()) F658_5752;
	{long i; for (i = 39; i < 43; i++) R4932[i] = (char *(*)()) F657_5752;}
	R4932[47] = (char *(*)()) F657_5752;
	R4932[49] = (char *(*)()) F657_5752;
	R4932[53] = (char *(*)()) F657_5752;
	{long i; for (i = 55; i < 57; i++) R4932[i] = (char *(*)()) F657_5752;}
	{long i; for (i = 58; i < 61; i++) R4932[i] = (char *(*)()) F657_5752;}
	R4932[83] = (char *(*)()) F482_5218;
	R4932[88] = (char *(*)()) F482_5218;
	{long i; for (i = 281; i < 283; i++) R4932[i] = (char *(*)()) F919_7172;}
	{long i; for (i = 494; i < 497; i++) R4932[i] = (char *(*)()) F1125_10146;}
	R4932[537] = (char *(*)()) F1125_10146;
	R4932[547] = (char *(*)()) F1125_10146;
	R4932[734] = (char *(*)()) F919_7172;
}

char *(*R4933[735])();
void R4933_init () {
	R4933[0] = (char *(*)()) F639_5487;
	R4933[1] = (char *(*)()) F640_5487;
	R4933[2] = (char *(*)()) F641_5487;
	R4933[3] = (char *(*)()) F639_5487;
	R4933[4] = (char *(*)()) F641_5487;
	R4933[5] = (char *(*)()) F640_5487;
	R4933[6] = (char *(*)()) F639_5487;
	R4933[18] = (char *(*)()) F615_5465;
	R4933[19] = (char *(*)()) F616_5465;
	R4933[20] = (char *(*)()) F617_5465;
	R4933[21] = (char *(*)()) F618_5465;
	R4933[22] = (char *(*)()) F619_5465;
	R4933[23] = (char *(*)()) F620_5465;
	R4933[24] = (char *(*)()) F621_5465;
	R4933[25] = (char *(*)()) F622_5465;
	R4933[26] = (char *(*)()) F623_5465;
	R4933[27] = (char *(*)()) F624_5465;
	R4933[28] = (char *(*)()) F625_5465;
	R4933[29] = (char *(*)()) F626_5465;
	R4933[30] = (char *(*)()) F615_5465;
	R4933[31] = (char *(*)()) F616_5465;
	R4933[32] = (char *(*)()) F622_5465;
	R4933[37] = (char *(*)()) F615_5465;
	R4933[38] = (char *(*)()) F616_5465;
	{long i; for (i = 39; i < 43; i++) R4933[i] = (char *(*)()) F615_5465;}
	R4933[47] = (char *(*)()) F615_5465;
	R4933[49] = (char *(*)()) F615_5465;
	R4933[53] = (char *(*)()) F615_5465;
	{long i; for (i = 55; i < 57; i++) R4933[i] = (char *(*)()) F615_5465;}
	{long i; for (i = 58; i < 61; i++) R4933[i] = (char *(*)()) F615_5465;}
	{long i; for (i = 281; i < 283; i++) R4933[i] = (char *(*)()) F919_7114;}
	{long i; for (i = 494; i < 497; i++) R4933[i] = (char *(*)()) F615_5465;}
	R4933[537] = (char *(*)()) F615_5465;
	R4933[547] = (char *(*)()) F615_5465;
	R4933[734] = (char *(*)()) F919_7114;
}

char *(*R4934[717])();
void R4934_init () {
	R4934[0] = (char *(*)()) F657_5753;
	R4934[1] = (char *(*)()) F658_5753;
	R4934[2] = (char *(*)()) F659_5753;
	R4934[3] = (char *(*)()) F660_5753;
	R4934[4] = (char *(*)()) F661_5753;
	R4934[5] = (char *(*)()) F662_5753;
	R4934[6] = (char *(*)()) F663_5753;
	R4934[7] = (char *(*)()) F664_5753;
	R4934[8] = (char *(*)()) F665_5753;
	R4934[9] = (char *(*)()) F666_5753;
	R4934[10] = (char *(*)()) F667_5753;
	R4934[11] = (char *(*)()) F668_5753;
	R4934[12] = (char *(*)()) F657_5753;
	R4934[13] = (char *(*)()) F658_5753;
	R4934[14] = (char *(*)()) F664_5753;
	R4934[19] = (char *(*)()) F657_5753;
	R4934[20] = (char *(*)()) F658_5753;
	{long i; for (i = 21; i < 25; i++) R4934[i] = (char *(*)()) F657_5753;}
	R4934[29] = (char *(*)()) F657_5753;
	R4934[31] = (char *(*)()) F657_5753;
	R4934[35] = (char *(*)()) F657_5753;
	{long i; for (i = 37; i < 39; i++) R4934[i] = (char *(*)()) F657_5753;}
	{long i; for (i = 40; i < 43; i++) R4934[i] = (char *(*)()) F657_5753;}
	{long i; for (i = 263; i < 265; i++) R4934[i] = (char *(*)()) F919_7173;}
	{long i; for (i = 476; i < 479; i++) R4934[i] = (char *(*)()) F1125_10145;}
	R4934[519] = (char *(*)()) F1125_10145;
	R4934[529] = (char *(*)()) F1125_10145;
	R4934[716] = (char *(*)()) F1373_14087;
}

char *(*R4935[548])();
void R4935_init () {
	R4935[0] = (char *(*)()) F603_5449;
	R4935[1] = (char *(*)()) F604_5449;
	R4935[2] = (char *(*)()) F610_5449;
	R4935[3] = (char *(*)()) F603_5449;
	R4935[4] = (char *(*)()) F610_5449;
	R4935[5] = (char *(*)()) F604_5449;
	R4935[6] = (char *(*)()) F603_5449;
	R4935[18] = (char *(*)()) F603_5449;
	R4935[19] = (char *(*)()) F604_5449;
	R4935[20] = (char *(*)()) F605_5449;
	R4935[21] = (char *(*)()) F606_5449;
	R4935[22] = (char *(*)()) F607_5449;
	R4935[23] = (char *(*)()) F608_5449;
	R4935[24] = (char *(*)()) F609_5449;
	R4935[25] = (char *(*)()) F610_5449;
	R4935[26] = (char *(*)()) F611_5449;
	R4935[27] = (char *(*)()) F612_5449;
	R4935[28] = (char *(*)()) F613_5449;
	R4935[29] = (char *(*)()) F614_5449;
	R4935[30] = (char *(*)()) F603_5449;
	R4935[31] = (char *(*)()) F604_5449;
	R4935[32] = (char *(*)()) F610_5449;
	R4935[37] = (char *(*)()) F603_5449;
	R4935[38] = (char *(*)()) F604_5449;
	{long i; for (i = 39; i < 43; i++) R4935[i] = (char *(*)()) F603_5449;}
	R4935[47] = (char *(*)()) F603_5449;
	R4935[49] = (char *(*)()) F603_5449;
	R4935[53] = (char *(*)()) F603_5449;
	{long i; for (i = 55; i < 57; i++) R4935[i] = (char *(*)()) F603_5449;}
	{long i; for (i = 58; i < 61; i++) R4935[i] = (char *(*)()) F603_5449;}
	{long i; for (i = 494; i < 497; i++) R4935[i] = (char *(*)()) F603_5449;}
	R4935[537] = (char *(*)()) F603_5449;
	R4935[547] = (char *(*)()) F603_5449;
}


#ifdef __cplusplus
}
#endif
