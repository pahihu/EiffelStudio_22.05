#include "epoly5.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R28[1383])();
void R28_init () {
	{long i; for (i = 0; i < 5; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 6; i < 11; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 12; i < 25; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 26; i < 29; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 31; i < 33; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 34; i < 39; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 41; i < 43; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 45; i < 48; i++) R28[i] = (char *(*)()) F1_25;}
	R28[60] = (char *(*)()) F1_25;
	{long i; for (i = 97; i < 102; i++) R28[i] = (char *(*)()) F1_25;}
	R28[104] = (char *(*)()) F1_25;
	R28[120] = (char *(*)()) F1_25;
	R28[124] = (char *(*)()) F1_25;
	R28[126] = (char *(*)()) F1_25;
	R28[128] = (char *(*)()) F1_25;
	{long i; for (i = 131; i < 133; i++) R28[i] = (char *(*)()) F1_25;}
	R28[140] = (char *(*)()) F1_25;
	R28[142] = (char *(*)()) F1_25;
	R28[150] = (char *(*)()) F1_25;
	{long i; for (i = 152; i < 154; i++) R28[i] = (char *(*)()) F1_25;}
	R28[155] = (char *(*)()) F1_25;
	{long i; for (i = 157; i < 159; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 160; i < 162; i++) R28[i] = (char *(*)()) F1_25;}
	R28[164] = (char *(*)()) F1_25;
	{long i; for (i = 170; i < 174; i++) R28[i] = (char *(*)()) F1_25;}
	R28[175] = (char *(*)()) F1_25;
	{long i; for (i = 177; i < 186; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 188; i < 190; i++) R28[i] = (char *(*)()) F1_25;}
	R28[192] = (char *(*)()) F1_25;
	R28[194] = (char *(*)()) F1_25;
	{long i; for (i = 195; i < 198; i++) R28[i] = (char *(*)()) F201_3863;}
	R28[200] = (char *(*)()) F201_3863;
	{long i; for (i = 202; i < 205; i++) R28[i] = (char *(*)()) F201_3863;}
	{long i; for (i = 206; i < 209; i++) R28[i] = (char *(*)()) F201_3863;}
	{long i; for (i = 210; i < 212; i++) R28[i] = (char *(*)()) F201_3863;}
	{long i; for (i = 214; i < 216; i++) R28[i] = (char *(*)()) F201_3863;}
	{long i; for (i = 217; i < 220; i++) R28[i] = (char *(*)()) F201_3863;}
	{long i; for (i = 221; i < 225; i++) R28[i] = (char *(*)()) F201_3863;}
	{long i; for (i = 226; i < 228; i++) R28[i] = (char *(*)()) F201_3863;}
	{long i; for (i = 229; i < 235; i++) R28[i] = (char *(*)()) F201_3863;}
	{long i; for (i = 237; i < 239; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 240; i < 248; i++) R28[i] = (char *(*)()) F1_25;}
	R28[250] = (char *(*)()) F1_25;
	R28[252] = (char *(*)()) F1_25;
	R28[255] = (char *(*)()) F1_25;
	R28[257] = (char *(*)()) F1_25;
	R28[260] = (char *(*)()) F1_25;
	{long i; for (i = 262; i < 264; i++) R28[i] = (char *(*)()) F1_25;}
	R28[267] = (char *(*)()) F1_25;
	{long i; for (i = 278; i < 280; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 285; i < 287; i++) R28[i] = (char *(*)()) F1_25;}
	R28[300] = (char *(*)()) F1_25;
	{long i; for (i = 307; i < 309; i++) R28[i] = (char *(*)()) F1_25;}
	R28[322] = (char *(*)()) F1_25;
	R28[329] = (char *(*)()) F1_25;
	R28[344] = (char *(*)()) F1_25;
	R28[570] = (char *(*)()) F1_25;
	{long i; for (i = 572; i < 584; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 633; i < 640; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 642; i < 650; i++) R28[i] = (char *(*)()) F1_25;}
	R28[650] = (char *(*)()) F656_5714;
	{long i; for (i = 651; i < 666; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 670; i < 676; i++) R28[i] = (char *(*)()) F1_25;}
	R28[680] = (char *(*)()) F1_25;
	R28[682] = (char *(*)()) F1_25;
	R28[686] = (char *(*)()) F1_25;
	{long i; for (i = 688; i < 690; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 691; i < 694; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 695; i < 697; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 698; i < 700; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 715; i < 717; i++) R28[i] = (char *(*)()) F1_25;}
	R28[721] = (char *(*)()) F1_25;
	{long i; for (i = 752; i < 773; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 785; i < 823; i++) R28[i] = (char *(*)()) F1_25;}
	R28[824] = (char *(*)()) F830_6309;
	{long i; for (i = 825; i < 827; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 829; i < 843; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 844; i < 851; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 852; i < 854; i++) R28[i] = (char *(*)()) F1_25;}
	R28[902] = (char *(*)()) F1_25;
	{long i; for (i = 904; i < 910; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 914; i < 916; i++) R28[i] = (char *(*)()) F1_25;}
	R28[918] = (char *(*)()) F1_25;
	R28[920] = (char *(*)()) F1_25;
	R28[923] = (char *(*)()) F1_25;
	R28[925] = (char *(*)()) F931_7652;
	R28[926] = (char *(*)()) F932_7699;
	R28[927] = (char *(*)()) F933_7740;
	R28[928] = (char *(*)()) F934_7740;
	R28[929] = (char *(*)()) F935_7740;
	R28[930] = (char *(*)()) F936_7740;
	R28[931] = (char *(*)()) F937_7740;
	R28[932] = (char *(*)()) F938_7740;
	R28[933] = (char *(*)()) F939_7740;
	R28[934] = (char *(*)()) F940_7740;
	R28[935] = (char *(*)()) F941_7740;
	R28[936] = (char *(*)()) F942_7740;
	R28[937] = (char *(*)()) F943_7740;
	R28[938] = (char *(*)()) F944_7740;
	R28[939] = (char *(*)()) F945_7740;
	R28[940] = (char *(*)()) F946_7740;
	R28[941] = (char *(*)()) F947_7740;
	R28[942] = (char *(*)()) F948_7740;
	R28[943] = (char *(*)()) F949_7740;
	R28[944] = (char *(*)()) F950_7740;
	R28[945] = (char *(*)()) F951_7740;
	R28[946] = (char *(*)()) F952_7740;
	R28[947] = (char *(*)()) F953_7740;
	R28[948] = (char *(*)()) F954_7740;
	R28[949] = (char *(*)()) F955_7740;
	R28[950] = (char *(*)()) F956_7740;
	R28[951] = (char *(*)()) F957_7740;
	R28[952] = (char *(*)()) F958_7740;
	R28[953] = (char *(*)()) F959_7740;
	R28[954] = (char *(*)()) F960_7740;
	R28[955] = (char *(*)()) F961_7740;
	R28[956] = (char *(*)()) F962_7740;
	R28[957] = (char *(*)()) F963_7740;
	R28[958] = (char *(*)()) F964_7740;
	R28[959] = (char *(*)()) F965_7740;
	R28[960] = (char *(*)()) F966_7740;
	R28[961] = (char *(*)()) F1_25;
	R28[963] = (char *(*)()) F969_7949;
	R28[964] = (char *(*)()) F970_7949;
	{long i; for (i = 966; i < 968; i++) R28[i] = (char *(*)()) F971_7965;}
	{long i; for (i = 969; i < 971; i++) R28[i] = (char *(*)()) F974_8005;}
	{long i; for (i = 972; i < 974; i++) R28[i] = (char *(*)()) F977_8053;}
	{long i; for (i = 975; i < 977; i++) R28[i] = (char *(*)()) F980_8129;}
	{long i; for (i = 978; i < 980; i++) R28[i] = (char *(*)()) F983_8228;}
	{long i; for (i = 981; i < 983; i++) R28[i] = (char *(*)()) F986_8327;}
	{long i; for (i = 984; i < 986; i++) R28[i] = (char *(*)()) F989_8426;}
	{long i; for (i = 987; i < 989; i++) R28[i] = (char *(*)()) F992_8522;}
	{long i; for (i = 990; i < 992; i++) R28[i] = (char *(*)()) F995_8616;}
	{long i; for (i = 993; i < 995; i++) R28[i] = (char *(*)()) F998_8711;}
	{long i; for (i = 996; i < 998; i++) R28[i] = (char *(*)()) F1001_8806;}
	R28[999] = (char *(*)()) F1005_8899;
	R28[1000] = (char *(*)()) F1006_8899;
	{long i; for (i = 1001; i < 1032; i++) R28[i] = (char *(*)()) F1007_8918;}
	R28[1032] = (char *(*)()) F1038_8931;
	R28[1033] = (char *(*)()) F1039_8931;
	{long i; for (i = 1035; i < 1040; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1044; i < 1046; i++) R28[i] = (char *(*)()) F1049_9159;}
	{long i; for (i = 1047; i < 1049; i++) R28[i] = (char *(*)()) F1052_9327;}
	{long i; for (i = 1080; i < 1082; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1083] = (char *(*)()) F1_25;
	R28[1084] = (char *(*)()) F1090_9709;
	{long i; for (i = 1085; i < 1088; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1089] = (char *(*)()) F1095_9802;
	R28[1094] = (char *(*)()) F1_25;
	R28[1111] = (char *(*)()) F1_25;
	R28[1113] = (char *(*)()) F1_25;
	{long i; for (i = 1127; i < 1132; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1133; i < 1135; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1138; i < 1141; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1142] = (char *(*)()) F1_25;
	{long i; for (i = 1145; i < 1148; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1150; i < 1152; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1153] = (char *(*)()) F1_25;
	R28[1161] = (char *(*)()) F1_25;
	R28[1164] = (char *(*)()) F1_25;
	R28[1170] = (char *(*)()) F1_25;
	R28[1180] = (char *(*)()) F1_25;
	R28[1188] = (char *(*)()) F1_25;
	R28[1193] = (char *(*)()) F1_25;
	R28[1195] = (char *(*)()) F1_25;
	R28[1198] = (char *(*)()) F1_25;
	R28[1200] = (char *(*)()) F1_25;
	R28[1202] = (char *(*)()) F1_25;
	R28[1205] = (char *(*)()) F1_25;
	R28[1207] = (char *(*)()) F1_25;
	R28[1211] = (char *(*)()) F1_25;
	R28[1251] = (char *(*)()) F1_25;
	{long i; for (i = 1274; i < 1276; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1280; i < 1282; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1283] = (char *(*)()) F1_25;
	R28[1288] = (char *(*)()) F1_25;
	{long i; for (i = 1290; i < 1292; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1313; i < 1315; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1318] = (char *(*)()) F1_25;
	R28[1320] = (char *(*)()) F1_25;
	R28[1322] = (char *(*)()) F1_25;
	R28[1335] = (char *(*)()) F1_25;
	R28[1341] = (char *(*)()) F1_25;
	R28[1345] = (char *(*)()) F1_25;
	R28[1358] = (char *(*)()) F1_25;
	{long i; for (i = 1360; i < 1362; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1366] = (char *(*)()) F1372_14077;
	R28[1367] = (char *(*)()) F1_25;
	{long i; for (i = 1369; i < 1371; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1373] = (char *(*)()) F1_25;
	R28[1375] = (char *(*)()) F1_25;
	R28[1380] = (char *(*)()) F1_25;
	R28[1382] = (char *(*)()) F1_25;
}

char *(*R3427[2])();
void R3427_init () {
	R3427[0] = (char *(*)()) F158_3452;
	R3427[1] = (char *(*)()) F159_3462;
}

char *(*R3503[2])();
void R3503_init () {
	R3503[0] = (char *(*)()) F166_3535;
	R3503[1] = (char *(*)()) F167_3536;
}

char *(*R3582[2])();
void R3582_init () {
	R3582[0] = (char *(*)()) F176_3623;
	R3582[1] = (char *(*)()) F177_3627;
}

char *(*R3584[2])();
void R3584_init () {
	R3584[0] = (char *(*)()) F176_3624;
	R3584[1] = (char *(*)()) F177_3628;
}

char *(*R3689[167])();
void R3689_init () {
	R3689[0] = (char *(*)()) F184_3752;
	R3689[1] = (char *(*)()) F185_3752_3689_1;
	R3689[2] = (char *(*)()) F186_3752_3689_1;
	R3689[3] = (char *(*)()) F187_3752_3689_1;
	R3689[4] = (char *(*)()) F188_3752_3689_1;
	R3689[5] = (char *(*)()) F184_3752;
	R3689[6] = (char *(*)()) F185_3752_3689_1;
	R3689[7] = (char *(*)()) F188_3752_3689_1;
	R3689[166] = (char *(*)()) F184_3752;
}
static EIF_REFERENCE F185_3752_3689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F185_3752(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F186_3752_3689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F186_3752(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F187_3752_3689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F187_3752(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F188_3752_3689_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F188_3752(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R3690[167])();
void R3690_init () {
	R3690[0] = (char *(*)()) F184_3753;
	R3690[1] = (char *(*)()) F185_3753_3690_4;
	R3690[2] = (char *(*)()) F186_3753_3690_4;
	R3690[3] = (char *(*)()) F187_3753_3690_4;
	R3690[4] = (char *(*)()) F188_3753_3690_4;
	R3690[5] = (char *(*)()) F184_3753;
	R3690[6] = (char *(*)()) F185_3753_3690_4;
	R3690[7] = (char *(*)()) F188_3753_3690_4;
	R3690[166] = (char *(*)()) F184_3753;
}
static void F185_3753_3690_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F185_3753(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F186_3753_3690_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F186_3753(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F187_3753_3690_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F187_3753(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F188_3753_3690_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F188_3753(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R3694[3])();
void R3694_init () {
	R3694[0] = (char *(*)()) F189_3756;
	R3694[1] = (char *(*)()) F190_3756;
	R3694[2] = (char *(*)()) F191_3756;
}

char *(*R3695[3])();
void R3695_init () {
	R3695[0] = (char *(*)()) F189_3757;
	R3695[1] = (char *(*)()) F190_3757;
	R3695[2] = (char *(*)()) F191_3757;
}

char *(*R3696[861])();
void R3696_init () {
	R3696[0] = (char *(*)()) F194_3773;
	R3696[737] = (char *(*)()) F931_7650;
	R3696[738] = (char *(*)()) F932_7694;
	R3696[775] = (char *(*)()) F969_7926_3696_2;
	R3696[776] = (char *(*)()) F970_7926_3696_2;
	{long i; for (i = 778; i < 780; i++) R3696[i] = (char *(*)()) F971_7957;}
	{long i; for (i = 781; i < 783; i++) R3696[i] = (char *(*)()) F974_7997;}
	R3696[787] = (char *(*)()) F981_8131_3696_2;
	R3696[788] = (char *(*)()) F982_8131_3696_2;
	R3696[790] = (char *(*)()) F984_8230_3696_2;
	R3696[791] = (char *(*)()) F985_8230_3696_2;
	R3696[793] = (char *(*)()) F987_8329_3696_2;
	R3696[794] = (char *(*)()) F988_8329_3696_2;
	R3696[796] = (char *(*)()) F990_8428_3696_2;
	R3696[797] = (char *(*)()) F991_8428_3696_2;
	R3696[799] = (char *(*)()) F993_8523_3696_2;
	R3696[800] = (char *(*)()) F994_8523_3696_2;
	R3696[802] = (char *(*)()) F996_8617_3696_2;
	R3696[803] = (char *(*)()) F997_8617_3696_2;
	R3696[805] = (char *(*)()) F999_8712_3696_2;
	R3696[806] = (char *(*)()) F1000_8712_3696_2;
	R3696[808] = (char *(*)()) F1002_8807_3696_2;
	R3696[809] = (char *(*)()) F1003_8807_3696_2;
	R3696[811] = (char *(*)()) F1005_8876_3696_2;
	R3696[812] = (char *(*)()) F1006_8876_3696_2;
	{long i; for (i = 856; i < 858; i++) R3696[i] = (char *(*)()) F1049_9144;}
	{long i; for (i = 859; i < 861; i++) R3696[i] = (char *(*)()) F1052_9312;}
}
static EIF_BOOLEAN F969_7926_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F969_7926(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F970_7926_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F970_7926(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F981_8131_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F981_8131(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F982_8131_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F982_8131(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F984_8230_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F984_8230(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F985_8230_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F985_8230(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F987_8329_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F987_8329(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F988_8329_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F988_8329(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F990_8428_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F990_8428(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F991_8428_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F991_8428(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F993_8523_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F993_8523(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F994_8523_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F994_8523(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F996_8617_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F996_8617(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F997_8617_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F997_8617(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F999_8712_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F999_8712(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1000_8712_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1000_8712(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1002_8807_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1002_8807(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1003_8807_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1003_8807(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1005_8876_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1005_8876(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1006_8876_3696_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1006_8876(Current, *(EIF_REAL_32 *)arg1);
}

char *(*R3782[40])();
void R3782_init () {
	R3782[0] = (char *(*)()) F201_3850;
	{long i; for (i = 1; i < 3; i++) R3782[i] = (char *(*)()) F202_3874;}
	R3782[5] = (char *(*)()) F206_3877;
	R3782[7] = (char *(*)()) F208_3879;
	R3782[8] = (char *(*)()) F209_3883;
	R3782[9] = (char *(*)()) F210_3889;
	R3782[11] = (char *(*)()) F212_3906;
	R3782[12] = (char *(*)()) F213_3908;
	R3782[13] = (char *(*)()) F214_3910;
	R3782[15] = (char *(*)()) F216_3912;
	R3782[16] = (char *(*)()) F217_3916;
	R3782[19] = (char *(*)()) F220_3918;
	R3782[20] = (char *(*)()) F221_3920;
	R3782[22] = (char *(*)()) F223_3924;
	R3782[23] = (char *(*)()) F224_3930;
	R3782[24] = (char *(*)()) F225_3932;
	R3782[26] = (char *(*)()) F227_3934;
	R3782[27] = (char *(*)()) F228_3936;
	R3782[28] = (char *(*)()) F229_3940;
	R3782[29] = (char *(*)()) F230_3944;
	R3782[31] = (char *(*)()) F232_3946;
	R3782[32] = (char *(*)()) F233_3948;
	R3782[34] = (char *(*)()) F235_3950;
	R3782[35] = (char *(*)()) F236_3952;
	R3782[36] = (char *(*)()) F237_3954;
	R3782[37] = (char *(*)()) F238_3956;
	R3782[38] = (char *(*)()) F239_3960;
	R3782[39] = (char *(*)()) F240_3962;
}

char *(*R4122[3])();
void R4122_init () {
	R4122[0] = (char *(*)()) F247_4244;
	R4122[1] = (char *(*)()) F248_4244;
	R4122[2] = (char *(*)()) F249_4244;
}

char *(*R4195[655])();
void R4195_init () {
	R4195[0] = (char *(*)()) F256_4323;
	R4195[654] = (char *(*)()) F910_6685;
}

char *(*R4495[13])();
void R4495_init () {
	R4495[0] = (char *(*)()) F273_4640;
	R4495[11] = (char *(*)()) F284_4696;
	R4495[12] = (char *(*)()) F285_4704;
}

char *(*R4507[9])();
void R4507_init () {
	R4507[0] = (char *(*)()) F284_4695;
	R4507[1] = (char *(*)()) F285_4703;
	R4507[7] = (char *(*)()) F291_4728;
	R4507[8] = (char *(*)()) F279_4670;
}

char *(*R4513[9])();
void R4513_init () {
	R4513[0] = (char *(*)()) F284_4699;
	R4513[1] = (char *(*)()) F285_4707;
	R4513[7] = (char *(*)()) F291_4729;
	R4513[8] = (char *(*)()) F292_4734;
}

char *(*R4514[9])();
void R4514_init () {
	R4514[0] = (char *(*)()) F284_4701;
	R4514[1] = (char *(*)()) F285_4709;
	R4514[7] = (char *(*)()) F291_4732;
	R4514[8] = (char *(*)()) F292_4737;
}

char *(*R4529[9])();
void R4529_init () {
	R4529[0] = (char *(*)()) F284_4700;
	R4529[8] = (char *(*)()) F292_4735;
}

char *(*R4532[9])();
void R4532_init () {
	R4532[0] = (char *(*)()) F284_4702;
	R4532[8] = (char *(*)()) F292_4738;
}

char *(*R4558[477])();
void R4558_init () {
	R4558[0] = (char *(*)()) F293_4739;
	R4558[1] = (char *(*)()) F294_4739;
	R4558[2] = (char *(*)()) F295_4739;
	R4558[3] = (char *(*)()) F296_4739;
	R4558[4] = (char *(*)()) F297_4739;
	R4558[5] = (char *(*)()) F298_4739;
	R4558[6] = (char *(*)()) F299_4739;
	R4558[7] = (char *(*)()) F300_4739;
	R4558[8] = (char *(*)()) F301_4739;
	R4558[9] = (char *(*)()) F302_4739;
	R4558[10] = (char *(*)()) F303_4739;
	R4558[11] = (char *(*)()) F304_4739;
	R4558[79] = (char *(*)()) F293_4739;
	R4558[80] = (char *(*)()) F294_4739;
	R4558[81] = (char *(*)()) F295_4739;
	R4558[82] = (char *(*)()) F296_4739;
	R4558[83] = (char *(*)()) F297_4739;
	R4558[84] = (char *(*)()) F298_4739;
	R4558[85] = (char *(*)()) F299_4739;
	R4558[86] = (char *(*)()) F300_4739;
	R4558[87] = (char *(*)()) F301_4739;
	R4558[88] = (char *(*)()) F302_4739;
	R4558[89] = (char *(*)()) F303_4739;
	R4558[90] = (char *(*)()) F304_4739;
	R4558[91] = (char *(*)()) F293_4739;
	R4558[92] = (char *(*)()) F294_4739;
	R4558[93] = (char *(*)()) F300_4739;
	R4558[98] = (char *(*)()) F293_4739;
	R4558[99] = (char *(*)()) F294_4739;
	{long i; for (i = 100; i < 104; i++) R4558[i] = (char *(*)()) F293_4739;}
	R4558[108] = (char *(*)()) F293_4739;
	R4558[110] = (char *(*)()) F293_4739;
	R4558[114] = (char *(*)()) F293_4739;
	{long i; for (i = 116; i < 118; i++) R4558[i] = (char *(*)()) F293_4739;}
	{long i; for (i = 119; i < 122; i++) R4558[i] = (char *(*)()) F293_4739;}
	R4558[124] = (char *(*)()) F295_4739;
	R4558[473] = (char *(*)()) F301_4739;
	R4558[476] = (char *(*)()) F299_4739;
}

char *(*R4559[477])();
void R4559_init () {
	R4559[0] = (char *(*)()) F293_4740;
	R4559[1] = (char *(*)()) F294_4740_4559_250;
	R4559[2] = (char *(*)()) F295_4740_4559_250;
	R4559[3] = (char *(*)()) F296_4740_4559_250;
	R4559[4] = (char *(*)()) F297_4740_4559_250;
	R4559[5] = (char *(*)()) F298_4740_4559_250;
	R4559[6] = (char *(*)()) F299_4740_4559_250;
	R4559[7] = (char *(*)()) F300_4740_4559_250;
	R4559[8] = (char *(*)()) F301_4740_4559_250;
	R4559[9] = (char *(*)()) F302_4740_4559_250;
	R4559[10] = (char *(*)()) F303_4740_4559_250;
	R4559[11] = (char *(*)()) F304_4740_4559_250;
	R4559[79] = (char *(*)()) F293_4740;
	R4559[80] = (char *(*)()) F294_4740_4559_250;
	R4559[81] = (char *(*)()) F295_4740_4559_250;
	R4559[82] = (char *(*)()) F296_4740_4559_250;
	R4559[83] = (char *(*)()) F297_4740_4559_250;
	R4559[84] = (char *(*)()) F298_4740_4559_250;
	R4559[85] = (char *(*)()) F299_4740_4559_250;
	R4559[86] = (char *(*)()) F300_4740_4559_250;
	R4559[87] = (char *(*)()) F301_4740_4559_250;
	R4559[88] = (char *(*)()) F302_4740_4559_250;
	R4559[89] = (char *(*)()) F303_4740_4559_250;
	R4559[90] = (char *(*)()) F304_4740_4559_250;
	R4559[91] = (char *(*)()) F293_4740;
	R4559[92] = (char *(*)()) F294_4740_4559_250;
	R4559[93] = (char *(*)()) F300_4740_4559_250;
	R4559[98] = (char *(*)()) F293_4740;
	R4559[99] = (char *(*)()) F294_4740_4559_250;
	{long i; for (i = 100; i < 104; i++) R4559[i] = (char *(*)()) F293_4740;}
	R4559[108] = (char *(*)()) F293_4740;
	R4559[110] = (char *(*)()) F293_4740;
	R4559[114] = (char *(*)()) F293_4740;
	{long i; for (i = 116; i < 118; i++) R4559[i] = (char *(*)()) F293_4740;}
	{long i; for (i = 119; i < 122; i++) R4559[i] = (char *(*)()) F293_4740;}
	R4559[124] = (char *(*)()) F295_4740_4559_250;
	R4559[473] = (char *(*)()) F301_4740_4559_250;
	R4559[476] = (char *(*)()) F299_4740_4559_250;
}
static void F294_4740_4559_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F294_4740(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F295_4740_4559_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F295_4740(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F296_4740_4559_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F296_4740(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F297_4740_4559_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F297_4740(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F298_4740_4559_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F298_4740(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F299_4740_4559_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F299_4740(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F300_4740_4559_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F300_4740(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F301_4740_4559_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F301_4740(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F302_4740_4559_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F302_4740(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F303_4740_4559_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F303_4740(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F304_4740_4559_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F304_4740(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4565[477])();
void R4565_init () {
	R4565[0] = (char *(*)()) F293_4746;
	R4565[1] = (char *(*)()) F294_4746;
	R4565[2] = (char *(*)()) F295_4746;
	R4565[3] = (char *(*)()) F296_4746;
	R4565[4] = (char *(*)()) F297_4746;
	R4565[5] = (char *(*)()) F298_4746;
	R4565[6] = (char *(*)()) F299_4746;
	R4565[7] = (char *(*)()) F300_4746;
	R4565[8] = (char *(*)()) F301_4746;
	R4565[9] = (char *(*)()) F302_4746;
	R4565[10] = (char *(*)()) F303_4746;
	R4565[11] = (char *(*)()) F304_4746;
	R4565[79] = (char *(*)()) F293_4746;
	R4565[80] = (char *(*)()) F294_4746;
	R4565[81] = (char *(*)()) F295_4746;
	R4565[82] = (char *(*)()) F296_4746;
	R4565[83] = (char *(*)()) F297_4746;
	R4565[84] = (char *(*)()) F298_4746;
	R4565[85] = (char *(*)()) F299_4746;
	R4565[86] = (char *(*)()) F300_4746;
	R4565[87] = (char *(*)()) F301_4746;
	R4565[88] = (char *(*)()) F302_4746;
	R4565[89] = (char *(*)()) F303_4746;
	R4565[90] = (char *(*)()) F304_4746;
	R4565[91] = (char *(*)()) F293_4746;
	R4565[92] = (char *(*)()) F294_4746;
	R4565[93] = (char *(*)()) F300_4746;
	R4565[98] = (char *(*)()) F293_4746;
	R4565[99] = (char *(*)()) F294_4746;
	{long i; for (i = 100; i < 104; i++) R4565[i] = (char *(*)()) F293_4746;}
	R4565[108] = (char *(*)()) F293_4746;
	R4565[110] = (char *(*)()) F293_4746;
	R4565[114] = (char *(*)()) F293_4746;
	{long i; for (i = 116; i < 118; i++) R4565[i] = (char *(*)()) F293_4746;}
	{long i; for (i = 119; i < 122; i++) R4565[i] = (char *(*)()) F293_4746;}
	R4565[124] = (char *(*)()) F295_4746;
	R4565[473] = (char *(*)()) F301_4746;
	R4565[476] = (char *(*)()) F299_4746;
}

static EIF_TYPE_INDEX Y4566_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype24[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype46[] = {0xFF01,1094,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype47[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype48[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype49[] = {0xFF01,1040,0xFFF9,1,966,0xFF01,0,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype50[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype51[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype52[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype53[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype54[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype55[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype56[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1101,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype57[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,927,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype58[] = {0xFF01,1040,0xFF01,0xFFF9,5,966,996,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype59[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1050,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype60[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1371,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype61[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype62[] = {0xFF01,1040,0xFF01,0xFFF9,4,966,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype63[] = {0xFF01,1040,0xFF01,0xFFF9,7,966,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype64[] = {0xFF01,1040,0xFF01,0xFFF9,2,966,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype65[] = {0xFF01,1040,0xFF01,0xFFF9,3,966,984,984,927,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype66[] = {0xFF01,1040,0xFF01,0xFFF9,8,966,984,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype67[] = {0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype68[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype69[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype70[] = {972,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype71[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype72[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4566_pgtype73[] = {0xFF01,1050,0xFFFF};
EIF_TYPE_INDEX *Y4566_gen_type [873];
EIF_TYPE_INDEX Y4566 [873];
void Y4566_init (void)
{
	egc_routines_types [4566] = Y4566;
	egc_routines_gen_types [4566] = Y4566_gen_type;
	egc_routines_offset [4566] = 292;
	Y4566_gen_type [0] = Y4566_pgtype0;
	Y4566_gen_type [1] = Y4566_pgtype1;
	Y4566_gen_type [2] = Y4566_pgtype2;
	Y4566_gen_type [3] = Y4566_pgtype3;
	Y4566_gen_type [4] = Y4566_pgtype4;
	Y4566_gen_type [5] = Y4566_pgtype5;
	Y4566_gen_type [6] = Y4566_pgtype6;
	Y4566_gen_type [7] = Y4566_pgtype7;
	Y4566_gen_type [8] = Y4566_pgtype8;
	Y4566_gen_type [9] = Y4566_pgtype9;
	Y4566_gen_type [10] = Y4566_pgtype10;
	Y4566_gen_type [11] = Y4566_pgtype11;
	Y4566_gen_type [285] = Y4566_pgtype12;
	Y4566_gen_type [286] = Y4566_pgtype13;
	Y4566_gen_type [287] = Y4566_pgtype14;
	Y4566_gen_type [288] = Y4566_pgtype15;
	Y4566_gen_type [289] = Y4566_pgtype16;
	Y4566_gen_type [290] = Y4566_pgtype17;
	Y4566_gen_type [291] = Y4566_pgtype18;
	Y4566_gen_type [292] = Y4566_pgtype19;
	Y4566_gen_type [293] = Y4566_pgtype20;
	Y4566_gen_type [294] = Y4566_pgtype21;
	Y4566_gen_type [295] = Y4566_pgtype22;
	Y4566_gen_type [296] = Y4566_pgtype23;
	Y4566_gen_type [297] = Y4566_pgtype24;
	Y4566_gen_type [364] = Y4566_pgtype25;
	Y4566_gen_type [365] = Y4566_pgtype26;
	Y4566_gen_type [366] = Y4566_pgtype27;
	Y4566_gen_type [367] = Y4566_pgtype28;
	Y4566_gen_type [368] = Y4566_pgtype29;
	Y4566_gen_type [369] = Y4566_pgtype30;
	Y4566_gen_type [370] = Y4566_pgtype31;
	Y4566_gen_type [371] = Y4566_pgtype32;
	Y4566_gen_type [372] = Y4566_pgtype33;
	Y4566_gen_type [373] = Y4566_pgtype34;
	Y4566_gen_type [374] = Y4566_pgtype35;
	Y4566_gen_type [375] = Y4566_pgtype36;
	Y4566_gen_type [376] = Y4566_pgtype37;
	Y4566_gen_type [377] = Y4566_pgtype38;
	Y4566_gen_type [378] = Y4566_pgtype39;
	Y4566_gen_type [379] = Y4566_pgtype40;
	Y4566_gen_type [380] = Y4566_pgtype41;
	Y4566_gen_type [381] = Y4566_pgtype42;
	Y4566_gen_type [382] = Y4566_pgtype43;
	Y4566_gen_type [383] = Y4566_pgtype44;
	Y4566_gen_type [384] = Y4566_pgtype45;
	Y4566_gen_type [385] = Y4566_pgtype46;
	Y4566_gen_type [386] = Y4566_pgtype47;
	Y4566_gen_type [387] = Y4566_pgtype48;
	Y4566_gen_type [388] = Y4566_pgtype49;
	Y4566_gen_type [389] = Y4566_pgtype50;
	Y4566_gen_type [390] = Y4566_pgtype51;
	Y4566_gen_type [391] = Y4566_pgtype52;
	Y4566_gen_type [392] = Y4566_pgtype53;
	Y4566_gen_type [393] = Y4566_pgtype54;
	Y4566_gen_type [394] = Y4566_pgtype55;
	Y4566_gen_type [395] = Y4566_pgtype56;
	Y4566_gen_type [396] = Y4566_pgtype57;
	Y4566_gen_type [397] = Y4566_pgtype58;
	Y4566_gen_type [398] = Y4566_pgtype59;
	Y4566_gen_type [399] = Y4566_pgtype60;
	Y4566_gen_type [400] = Y4566_pgtype61;
	Y4566_gen_type [401] = Y4566_pgtype62;
	Y4566_gen_type [402] = Y4566_pgtype63;
	Y4566_gen_type [403] = Y4566_pgtype64;
	Y4566_gen_type [404] = Y4566_pgtype65;
	Y4566_gen_type [405] = Y4566_pgtype66;
	Y4566_gen_type [406] = Y4566_pgtype67;
	Y4566_gen_type [409] = Y4566_pgtype68;
	Y4566_gen_type [410] = Y4566_pgtype69;
	Y4566_gen_type [758] = Y4566_pgtype70;
	Y4566_gen_type [761] = Y4566_pgtype71;
	Y4566_gen_type [762] = Y4566_pgtype72;
	Y4566_gen_type [872] = Y4566_pgtype73;
	Y4566[297] = 1002;
	Y4566[385] = 1094;
	{long i; for (i = 386; i < 407; i++) Y4566[i] = 1040;};
	{long i; for (i = 409; i < 411; i++) Y4566[i] = 1002;};
	Y4566[758] = 972;
	{long i; for (i = 761; i < 763; i++) Y4566[i] = 975;};
	Y4566[872] = 1050;
}

char *(*R4683[236])();
void R4683_init () {
	R4683[0] = (char *(*)()) F1144_10448;
	R4683[235] = (char *(*)()) F1379_14204;
}

char *(*R4695[236])();
void R4695_init () {
	R4695[0] = (char *(*)()) F311_4892;
	R4695[235] = (char *(*)()) F1378_14191;
}

char *(*R4696[236])();
void R4696_init () {
	R4696[0] = (char *(*)()) F311_4894;
	R4696[235] = (char *(*)()) F1378_14192;
}

char *(*R4698[236])();
void R4698_init () {
	R4698[0] = (char *(*)()) F310_4880;
	R4698[235] = (char *(*)()) F1378_14196;
}

char *(*R4702[236])();
void R4702_init () {
	R4702[0] = (char *(*)()) F311_4899;
	R4702[235] = (char *(*)()) F310_4884;
}

char *(*R4755[1046])();
void R4755_init () {
	R4755[0] = (char *(*)()) F328_4970;
	R4755[7] = (char *(*)()) F335_4992;
	R4755[22] = (char *(*)()) F348_5036;
	R4755[248] = (char *(*)()) F553_5291;
	R4755[250] = (char *(*)()) F578_5354;
	R4755[251] = (char *(*)()) F579_5354;
	R4755[252] = (char *(*)()) F580_5354;
	R4755[253] = (char *(*)()) F581_5354;
	R4755[254] = (char *(*)()) F582_5354;
	R4755[255] = (char *(*)()) F583_5354;
	R4755[256] = (char *(*)()) F584_5354;
	R4755[257] = (char *(*)()) F585_5354;
	R4755[258] = (char *(*)()) F586_5354;
	R4755[259] = (char *(*)()) F587_5354;
	R4755[260] = (char *(*)()) F588_5354;
	R4755[261] = (char *(*)()) F589_5354;
	R4755[311] = (char *(*)()) F639_5482;
	R4755[312] = (char *(*)()) F640_5482;
	R4755[313] = (char *(*)()) F641_5482;
	R4755[314] = (char *(*)()) F639_5482;
	R4755[315] = (char *(*)()) F641_5482;
	R4755[316] = (char *(*)()) F640_5482;
	R4755[317] = (char *(*)()) F639_5482;
	R4755[320] = (char *(*)()) F648_5603;
	R4755[321] = (char *(*)()) F649_5603;
	R4755[322] = (char *(*)()) F650_5603;
	R4755[323] = (char *(*)()) F651_5603;
	R4755[324] = (char *(*)()) F652_5603;
	R4755[325] = (char *(*)()) F653_5603;
	R4755[326] = (char *(*)()) F648_5603;
	R4755[327] = (char *(*)()) F649_5603;
	R4755[328] = (char *(*)()) F648_5603;
	R4755[329] = (char *(*)()) F657_5733;
	R4755[330] = (char *(*)()) F658_5733;
	R4755[331] = (char *(*)()) F659_5733;
	R4755[332] = (char *(*)()) F660_5733;
	R4755[333] = (char *(*)()) F661_5733;
	R4755[334] = (char *(*)()) F662_5733;
	R4755[335] = (char *(*)()) F663_5733;
	R4755[336] = (char *(*)()) F664_5733;
	R4755[337] = (char *(*)()) F665_5733;
	R4755[338] = (char *(*)()) F666_5733;
	R4755[339] = (char *(*)()) F667_5733;
	R4755[340] = (char *(*)()) F668_5733;
	R4755[341] = (char *(*)()) F657_5733;
	R4755[342] = (char *(*)()) F658_5733;
	R4755[343] = (char *(*)()) F664_5733;
	R4755[348] = (char *(*)()) F657_5733;
	R4755[349] = (char *(*)()) F658_5733;
	{long i; for (i = 350; i < 354; i++) R4755[i] = (char *(*)()) F657_5733;}
	R4755[358] = (char *(*)()) F657_5733;
	R4755[360] = (char *(*)()) F657_5733;
	R4755[364] = (char *(*)()) F657_5733;
	{long i; for (i = 366; i < 368; i++) R4755[i] = (char *(*)()) F657_5733;}
	{long i; for (i = 369; i < 372; i++) R4755[i] = (char *(*)()) F657_5733;}
	R4755[394] = (char *(*)()) F722_6099;
	R4755[399] = (char *(*)()) F727_6160;
	R4755[430] = (char *(*)()) F758_6193;
	R4755[431] = (char *(*)()) F759_6193;
	R4755[432] = (char *(*)()) F760_6193;
	R4755[433] = (char *(*)()) F761_6193;
	R4755[434] = (char *(*)()) F762_6193;
	R4755[435] = (char *(*)()) F763_6193;
	R4755[436] = (char *(*)()) F764_6193;
	R4755[437] = (char *(*)()) F765_6193;
	R4755[438] = (char *(*)()) F766_6193;
	R4755[439] = (char *(*)()) F767_6193;
	R4755[440] = (char *(*)()) F768_6193;
	R4755[441] = (char *(*)()) F769_6193;
	R4755[442] = (char *(*)()) F758_6193;
	R4755[443] = (char *(*)()) F759_6193;
	R4755[444] = (char *(*)()) F765_6193;
	R4755[445] = (char *(*)()) F758_6193;
	R4755[446] = (char *(*)()) F759_6193;
	R4755[447] = (char *(*)()) F758_6193;
	{long i; for (i = 448; i < 450; i++) R4755[i] = (char *(*)()) F759_6193;}
	R4755[450] = (char *(*)()) F768_6193;
	R4755[463] = (char *(*)()) F791_6243;
	R4755[464] = (char *(*)()) F792_6243;
	R4755[465] = (char *(*)()) F793_6243;
	R4755[466] = (char *(*)()) F794_6243;
	R4755[467] = (char *(*)()) F795_6243;
	R4755[468] = (char *(*)()) F796_6243;
	R4755[469] = (char *(*)()) F797_6243;
	R4755[470] = (char *(*)()) F798_6243;
	R4755[471] = (char *(*)()) F799_6243;
	R4755[472] = (char *(*)()) F800_6243;
	R4755[473] = (char *(*)()) F801_6243;
	R4755[474] = (char *(*)()) F802_6243;
	R4755[475] = (char *(*)()) F803_6249;
	R4755[476] = (char *(*)()) F804_6255;
	R4755[477] = (char *(*)()) F805_6261;
	R4755[478] = (char *(*)()) F806_6261;
	R4755[479] = (char *(*)()) F807_6261;
	R4755[480] = (char *(*)()) F808_6261;
	R4755[481] = (char *(*)()) F809_6261;
	R4755[482] = (char *(*)()) F810_6261;
	R4755[483] = (char *(*)()) F811_6261;
	R4755[484] = (char *(*)()) F812_6261;
	R4755[485] = (char *(*)()) F813_6261;
	R4755[486] = (char *(*)()) F814_6261;
	R4755[487] = (char *(*)()) F815_6261;
	R4755[488] = (char *(*)()) F816_6261;
	R4755[489] = (char *(*)()) F817_6267;
	R4755[490] = (char *(*)()) F818_6267;
	R4755[491] = (char *(*)()) F819_6267;
	R4755[492] = (char *(*)()) F820_6267;
	R4755[493] = (char *(*)()) F821_6267;
	R4755[494] = (char *(*)()) F822_6267;
	R4755[495] = (char *(*)()) F823_6267;
	R4755[496] = (char *(*)()) F824_6267;
	R4755[497] = (char *(*)()) F825_6267;
	R4755[498] = (char *(*)()) F826_6267;
	R4755[499] = (char *(*)()) F827_6267;
	R4755[500] = (char *(*)()) F828_6267;
	R4755[504] = (char *(*)()) F832_6334;
	R4755[507] = (char *(*)()) F835_6410;
	R4755[508] = (char *(*)()) F836_6410;
	R4755[509] = (char *(*)()) F837_6410;
	R4755[510] = (char *(*)()) F838_6410;
	R4755[511] = (char *(*)()) F839_6410;
	R4755[512] = (char *(*)()) F840_6410;
	R4755[513] = (char *(*)()) F841_6410;
	R4755[514] = (char *(*)()) F842_6410;
	R4755[515] = (char *(*)()) F843_6410;
	R4755[516] = (char *(*)()) F844_6410;
	R4755[517] = (char *(*)()) F845_6410;
	R4755[518] = (char *(*)()) F846_6410;
	{long i; for (i = 592; i < 594; i++) R4755[i] = (char *(*)()) F919_7178;}
	R4755[639] = (char *(*)()) F552_5291;
	{long i; for (i = 722; i < 724; i++) R4755[i] = (char *(*)()) F1049_9134;}
	{long i; for (i = 725; i < 727; i++) R4755[i] = (char *(*)()) F1052_9302;}
	{long i; for (i = 805; i < 808; i++) R4755[i] = (char *(*)()) F552_5291;}
	{long i; for (i = 808; i < 810; i++) R4755[i] = (char *(*)()) F1128_10232;}
	{long i; for (i = 811; i < 813; i++) R4755[i] = (char *(*)()) F1128_10232;}
	{long i; for (i = 816; i < 819; i++) R4755[i] = (char *(*)()) F1128_10232;}
	R4755[820] = (char *(*)()) F1128_10232;
	R4755[848] = (char *(*)()) F552_5291;
	R4755[858] = (char *(*)()) F552_5291;
	R4755[1045] = (char *(*)()) F1373_14088;
}

static EIF_TYPE_INDEX Y4756_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype12[] = {0xFF01,1053,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype13[] = {0xFF01,1049,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype20[] = {0xFF01,831,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype256[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype261[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype262[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype264[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype275[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype319[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype320[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype321[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype340[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype358[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype362[] = {0xFF01,1094,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype363[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype364[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype365[] = {0xFF01,1040,0xFFF9,1,966,0xFF01,0,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype366[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype367[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype368[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype369[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype370[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype371[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype372[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1101,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype373[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,927,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype374[] = {0xFF01,1040,0xFF01,0xFFF9,5,966,996,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype375[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1050,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype376[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1371,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype377[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype378[] = {0xFF01,1040,0xFF01,0xFFF9,4,966,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype379[] = {0xFF01,1040,0xFF01,0xFFF9,7,966,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype380[] = {0xFF01,1040,0xFF01,0xFFF9,2,966,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype381[] = {0xFF01,1040,0xFF01,0xFFF9,3,966,984,984,927,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype382[] = {0xFF01,1040,0xFF01,0xFFF9,8,966,984,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype383[] = {0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype384[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype385[] = {0xFF01,30,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype386[] = {972,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype387[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype447[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype448[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype449[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype450[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype451[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype452[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype453[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype454[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype455[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype456[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype457[] = {972,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype458[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype459[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype460[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype461[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype462[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype463[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype464[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype465[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype466[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype467[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype468[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype469[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype470[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype471[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype472[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype473[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype474[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype475[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype476[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype477[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype478[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype479[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype480[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype481[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype482[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype483[] = {0xFF01,1048,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype484[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype485[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype486[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype487[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype488[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype489[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype490[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype491[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype492[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype493[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype494[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype495[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype496[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype497[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype498[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype499[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype500[] = {972,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype501[] = {972,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype502[] = {972,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype503[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype504[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype505[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype506[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype507[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype508[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype509[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype510[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype511[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype512[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype513[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype514[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype515[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype516[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype517[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype518[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype519[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype520[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype521[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype522[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype523[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype524[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype525[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype526[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype527[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype528[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype529[] = {0xFF01,1050,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype530[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype531[] = {0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype532[] = {0xFF01,1165,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype533[] = {0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype534[] = {0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype535[] = {0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype536[] = {0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype537[] = {0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype538[] = {0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype539[] = {0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype540[] = {0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype541[] = {0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype542[] = {0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4756_pgtype543[] = {975,0xFFFF};
EIF_TYPE_INDEX *Y4756_gen_type [1059];
EIF_TYPE_INDEX Y4756 [1059];
void Y4756_init (void)
{
	egc_routines_types [4756] = Y4756;
	egc_routines_gen_types [4756] = Y4756_gen_type;
	egc_routines_offset [4756] = 314;
	Y4756_gen_type [0] = Y4756_pgtype0;
	Y4756_gen_type [1] = Y4756_pgtype1;
	Y4756_gen_type [2] = Y4756_pgtype2;
	Y4756_gen_type [3] = Y4756_pgtype3;
	Y4756_gen_type [4] = Y4756_pgtype4;
	Y4756_gen_type [5] = Y4756_pgtype5;
	Y4756_gen_type [6] = Y4756_pgtype6;
	Y4756_gen_type [7] = Y4756_pgtype7;
	Y4756_gen_type [8] = Y4756_pgtype8;
	Y4756_gen_type [9] = Y4756_pgtype9;
	Y4756_gen_type [10] = Y4756_pgtype10;
	Y4756_gen_type [11] = Y4756_pgtype11;
	Y4756_gen_type [12] = Y4756_pgtype12;
	Y4756_gen_type [13] = Y4756_pgtype13;
	Y4756_gen_type [14] = Y4756_pgtype14;
	Y4756_gen_type [15] = Y4756_pgtype15;
	Y4756_gen_type [16] = Y4756_pgtype16;
	Y4756_gen_type [17] = Y4756_pgtype17;
	Y4756_gen_type [18] = Y4756_pgtype18;
	Y4756_gen_type [19] = Y4756_pgtype19;
	Y4756_gen_type [20] = Y4756_pgtype20;
	Y4756_gen_type [21] = Y4756_pgtype21;
	Y4756_gen_type [22] = Y4756_pgtype22;
	Y4756_gen_type [23] = Y4756_pgtype23;
	Y4756_gen_type [24] = Y4756_pgtype24;
	Y4756_gen_type [25] = Y4756_pgtype25;
	Y4756_gen_type [26] = Y4756_pgtype26;
	Y4756_gen_type [27] = Y4756_pgtype27;
	Y4756_gen_type [28] = Y4756_pgtype28;
	Y4756_gen_type [29] = Y4756_pgtype29;
	Y4756_gen_type [30] = Y4756_pgtype30;
	Y4756_gen_type [31] = Y4756_pgtype31;
	Y4756_gen_type [32] = Y4756_pgtype32;
	Y4756_gen_type [33] = Y4756_pgtype33;
	Y4756_gen_type [34] = Y4756_pgtype34;
	Y4756_gen_type [35] = Y4756_pgtype35;
	Y4756_gen_type [36] = Y4756_pgtype36;
	Y4756_gen_type [37] = Y4756_pgtype37;
	Y4756_gen_type [38] = Y4756_pgtype38;
	Y4756_gen_type [39] = Y4756_pgtype39;
	Y4756_gen_type [40] = Y4756_pgtype40;
	Y4756_gen_type [41] = Y4756_pgtype41;
	Y4756_gen_type [42] = Y4756_pgtype42;
	Y4756_gen_type [43] = Y4756_pgtype43;
	Y4756_gen_type [44] = Y4756_pgtype44;
	Y4756_gen_type [45] = Y4756_pgtype45;
	Y4756_gen_type [46] = Y4756_pgtype46;
	Y4756_gen_type [47] = Y4756_pgtype47;
	Y4756_gen_type [48] = Y4756_pgtype48;
	Y4756_gen_type [49] = Y4756_pgtype49;
	Y4756_gen_type [50] = Y4756_pgtype50;
	Y4756_gen_type [51] = Y4756_pgtype51;
	Y4756_gen_type [52] = Y4756_pgtype52;
	Y4756_gen_type [53] = Y4756_pgtype53;
	Y4756_gen_type [54] = Y4756_pgtype54;
	Y4756_gen_type [55] = Y4756_pgtype55;
	Y4756_gen_type [56] = Y4756_pgtype56;
	Y4756_gen_type [57] = Y4756_pgtype57;
	Y4756_gen_type [58] = Y4756_pgtype58;
	Y4756_gen_type [59] = Y4756_pgtype59;
	Y4756_gen_type [60] = Y4756_pgtype60;
	Y4756_gen_type [61] = Y4756_pgtype61;
	Y4756_gen_type [62] = Y4756_pgtype62;
	Y4756_gen_type [63] = Y4756_pgtype63;
	Y4756_gen_type [64] = Y4756_pgtype64;
	Y4756_gen_type [65] = Y4756_pgtype65;
	Y4756_gen_type [66] = Y4756_pgtype66;
	Y4756_gen_type [67] = Y4756_pgtype67;
	Y4756_gen_type [68] = Y4756_pgtype68;
	Y4756_gen_type [69] = Y4756_pgtype69;
	Y4756_gen_type [70] = Y4756_pgtype70;
	Y4756_gen_type [71] = Y4756_pgtype71;
	Y4756_gen_type [72] = Y4756_pgtype72;
	Y4756_gen_type [73] = Y4756_pgtype73;
	Y4756_gen_type [74] = Y4756_pgtype74;
	Y4756_gen_type [75] = Y4756_pgtype75;
	Y4756_gen_type [76] = Y4756_pgtype76;
	Y4756_gen_type [77] = Y4756_pgtype77;
	Y4756_gen_type [78] = Y4756_pgtype78;
	Y4756_gen_type [79] = Y4756_pgtype79;
	Y4756_gen_type [80] = Y4756_pgtype80;
	Y4756_gen_type [81] = Y4756_pgtype81;
	Y4756_gen_type [82] = Y4756_pgtype82;
	Y4756_gen_type [83] = Y4756_pgtype83;
	Y4756_gen_type [84] = Y4756_pgtype84;
	Y4756_gen_type [85] = Y4756_pgtype85;
	Y4756_gen_type [86] = Y4756_pgtype86;
	Y4756_gen_type [87] = Y4756_pgtype87;
	Y4756_gen_type [88] = Y4756_pgtype88;
	Y4756_gen_type [89] = Y4756_pgtype89;
	Y4756_gen_type [90] = Y4756_pgtype90;
	Y4756_gen_type [91] = Y4756_pgtype91;
	Y4756_gen_type [92] = Y4756_pgtype92;
	Y4756_gen_type [93] = Y4756_pgtype93;
	Y4756_gen_type [94] = Y4756_pgtype94;
	Y4756_gen_type [95] = Y4756_pgtype95;
	Y4756_gen_type [96] = Y4756_pgtype96;
	Y4756_gen_type [97] = Y4756_pgtype97;
	Y4756_gen_type [98] = Y4756_pgtype98;
	Y4756_gen_type [99] = Y4756_pgtype99;
	Y4756_gen_type [100] = Y4756_pgtype100;
	Y4756_gen_type [101] = Y4756_pgtype101;
	Y4756_gen_type [102] = Y4756_pgtype102;
	Y4756_gen_type [103] = Y4756_pgtype103;
	Y4756_gen_type [104] = Y4756_pgtype104;
	Y4756_gen_type [105] = Y4756_pgtype105;
	Y4756_gen_type [106] = Y4756_pgtype106;
	Y4756_gen_type [107] = Y4756_pgtype107;
	Y4756_gen_type [108] = Y4756_pgtype108;
	Y4756_gen_type [109] = Y4756_pgtype109;
	Y4756_gen_type [110] = Y4756_pgtype110;
	Y4756_gen_type [111] = Y4756_pgtype111;
	Y4756_gen_type [112] = Y4756_pgtype112;
	Y4756_gen_type [113] = Y4756_pgtype113;
	Y4756_gen_type [114] = Y4756_pgtype114;
	Y4756_gen_type [115] = Y4756_pgtype115;
	Y4756_gen_type [116] = Y4756_pgtype116;
	Y4756_gen_type [117] = Y4756_pgtype117;
	Y4756_gen_type [118] = Y4756_pgtype118;
	Y4756_gen_type [119] = Y4756_pgtype119;
	Y4756_gen_type [120] = Y4756_pgtype120;
	Y4756_gen_type [121] = Y4756_pgtype121;
	Y4756_gen_type [122] = Y4756_pgtype122;
	Y4756_gen_type [123] = Y4756_pgtype123;
	Y4756_gen_type [124] = Y4756_pgtype124;
	Y4756_gen_type [125] = Y4756_pgtype125;
	Y4756_gen_type [126] = Y4756_pgtype126;
	Y4756_gen_type [127] = Y4756_pgtype127;
	Y4756_gen_type [128] = Y4756_pgtype128;
	Y4756_gen_type [129] = Y4756_pgtype129;
	Y4756_gen_type [130] = Y4756_pgtype130;
	Y4756_gen_type [131] = Y4756_pgtype131;
	Y4756_gen_type [132] = Y4756_pgtype132;
	Y4756_gen_type [133] = Y4756_pgtype133;
	Y4756_gen_type [134] = Y4756_pgtype134;
	Y4756_gen_type [135] = Y4756_pgtype135;
	Y4756_gen_type [136] = Y4756_pgtype136;
	Y4756_gen_type [137] = Y4756_pgtype137;
	Y4756_gen_type [138] = Y4756_pgtype138;
	Y4756_gen_type [139] = Y4756_pgtype139;
	Y4756_gen_type [140] = Y4756_pgtype140;
	Y4756_gen_type [141] = Y4756_pgtype141;
	Y4756_gen_type [142] = Y4756_pgtype142;
	Y4756_gen_type [143] = Y4756_pgtype143;
	Y4756_gen_type [144] = Y4756_pgtype144;
	Y4756_gen_type [145] = Y4756_pgtype145;
	Y4756_gen_type [146] = Y4756_pgtype146;
	Y4756_gen_type [147] = Y4756_pgtype147;
	Y4756_gen_type [148] = Y4756_pgtype148;
	Y4756_gen_type [149] = Y4756_pgtype149;
	Y4756_gen_type [150] = Y4756_pgtype150;
	Y4756_gen_type [151] = Y4756_pgtype151;
	Y4756_gen_type [152] = Y4756_pgtype152;
	Y4756_gen_type [153] = Y4756_pgtype153;
	Y4756_gen_type [154] = Y4756_pgtype154;
	Y4756_gen_type [155] = Y4756_pgtype155;
	Y4756_gen_type [156] = Y4756_pgtype156;
	Y4756_gen_type [157] = Y4756_pgtype157;
	Y4756_gen_type [158] = Y4756_pgtype158;
	Y4756_gen_type [159] = Y4756_pgtype159;
	Y4756_gen_type [160] = Y4756_pgtype160;
	Y4756_gen_type [161] = Y4756_pgtype161;
	Y4756_gen_type [162] = Y4756_pgtype162;
	Y4756_gen_type [163] = Y4756_pgtype163;
	Y4756_gen_type [164] = Y4756_pgtype164;
	Y4756_gen_type [165] = Y4756_pgtype165;
	Y4756_gen_type [166] = Y4756_pgtype166;
	Y4756_gen_type [167] = Y4756_pgtype167;
	Y4756_gen_type [168] = Y4756_pgtype168;
	Y4756_gen_type [169] = Y4756_pgtype169;
	Y4756_gen_type [170] = Y4756_pgtype170;
	Y4756_gen_type [171] = Y4756_pgtype171;
	Y4756_gen_type [172] = Y4756_pgtype172;
	Y4756_gen_type [173] = Y4756_pgtype173;
	Y4756_gen_type [174] = Y4756_pgtype174;
	Y4756_gen_type [175] = Y4756_pgtype175;
	Y4756_gen_type [176] = Y4756_pgtype176;
	Y4756_gen_type [177] = Y4756_pgtype177;
	Y4756_gen_type [178] = Y4756_pgtype178;
	Y4756_gen_type [179] = Y4756_pgtype179;
	Y4756_gen_type [180] = Y4756_pgtype180;
	Y4756_gen_type [181] = Y4756_pgtype181;
	Y4756_gen_type [182] = Y4756_pgtype182;
	Y4756_gen_type [183] = Y4756_pgtype183;
	Y4756_gen_type [184] = Y4756_pgtype184;
	Y4756_gen_type [185] = Y4756_pgtype185;
	Y4756_gen_type [186] = Y4756_pgtype186;
	Y4756_gen_type [187] = Y4756_pgtype187;
	Y4756_gen_type [188] = Y4756_pgtype188;
	Y4756_gen_type [189] = Y4756_pgtype189;
	Y4756_gen_type [190] = Y4756_pgtype190;
	Y4756_gen_type [191] = Y4756_pgtype191;
	Y4756_gen_type [192] = Y4756_pgtype192;
	Y4756_gen_type [193] = Y4756_pgtype193;
	Y4756_gen_type [194] = Y4756_pgtype194;
	Y4756_gen_type [195] = Y4756_pgtype195;
	Y4756_gen_type [196] = Y4756_pgtype196;
	Y4756_gen_type [197] = Y4756_pgtype197;
	Y4756_gen_type [198] = Y4756_pgtype198;
	Y4756_gen_type [199] = Y4756_pgtype199;
	Y4756_gen_type [200] = Y4756_pgtype200;
	Y4756_gen_type [201] = Y4756_pgtype201;
	Y4756_gen_type [202] = Y4756_pgtype202;
	Y4756_gen_type [203] = Y4756_pgtype203;
	Y4756_gen_type [204] = Y4756_pgtype204;
	Y4756_gen_type [205] = Y4756_pgtype205;
	Y4756_gen_type [206] = Y4756_pgtype206;
	Y4756_gen_type [207] = Y4756_pgtype207;
	Y4756_gen_type [208] = Y4756_pgtype208;
	Y4756_gen_type [209] = Y4756_pgtype209;
	Y4756_gen_type [210] = Y4756_pgtype210;
	Y4756_gen_type [211] = Y4756_pgtype211;
	Y4756_gen_type [212] = Y4756_pgtype212;
	Y4756_gen_type [213] = Y4756_pgtype213;
	Y4756_gen_type [214] = Y4756_pgtype214;
	Y4756_gen_type [215] = Y4756_pgtype215;
	Y4756_gen_type [216] = Y4756_pgtype216;
	Y4756_gen_type [217] = Y4756_pgtype217;
	Y4756_gen_type [218] = Y4756_pgtype218;
	Y4756_gen_type [219] = Y4756_pgtype219;
	Y4756_gen_type [220] = Y4756_pgtype220;
	Y4756_gen_type [221] = Y4756_pgtype221;
	Y4756_gen_type [222] = Y4756_pgtype222;
	Y4756_gen_type [223] = Y4756_pgtype223;
	Y4756_gen_type [224] = Y4756_pgtype224;
	Y4756_gen_type [225] = Y4756_pgtype225;
	Y4756_gen_type [226] = Y4756_pgtype226;
	Y4756_gen_type [227] = Y4756_pgtype227;
	Y4756_gen_type [228] = Y4756_pgtype228;
	Y4756_gen_type [229] = Y4756_pgtype229;
	Y4756_gen_type [230] = Y4756_pgtype230;
	Y4756_gen_type [231] = Y4756_pgtype231;
	Y4756_gen_type [232] = Y4756_pgtype232;
	Y4756_gen_type [233] = Y4756_pgtype233;
	Y4756_gen_type [234] = Y4756_pgtype234;
	Y4756_gen_type [235] = Y4756_pgtype235;
	Y4756_gen_type [236] = Y4756_pgtype236;
	Y4756_gen_type [237] = Y4756_pgtype237;
	Y4756_gen_type [238] = Y4756_pgtype238;
	Y4756_gen_type [239] = Y4756_pgtype239;
	Y4756_gen_type [240] = Y4756_pgtype240;
	Y4756_gen_type [241] = Y4756_pgtype241;
	Y4756_gen_type [242] = Y4756_pgtype242;
	Y4756_gen_type [243] = Y4756_pgtype243;
	Y4756_gen_type [244] = Y4756_pgtype244;
	Y4756_gen_type [245] = Y4756_pgtype245;
	Y4756_gen_type [246] = Y4756_pgtype246;
	Y4756_gen_type [247] = Y4756_pgtype247;
	Y4756_gen_type [248] = Y4756_pgtype248;
	Y4756_gen_type [249] = Y4756_pgtype249;
	Y4756_gen_type [250] = Y4756_pgtype250;
	Y4756_gen_type [251] = Y4756_pgtype251;
	Y4756_gen_type [252] = Y4756_pgtype252;
	Y4756_gen_type [253] = Y4756_pgtype253;
	Y4756_gen_type [254] = Y4756_pgtype254;
	Y4756_gen_type [255] = Y4756_pgtype255;
	Y4756_gen_type [256] = Y4756_pgtype256;
	Y4756_gen_type [257] = Y4756_pgtype257;
	Y4756_gen_type [258] = Y4756_pgtype258;
	Y4756_gen_type [259] = Y4756_pgtype259;
	Y4756_gen_type [260] = Y4756_pgtype260;
	Y4756_gen_type [261] = Y4756_pgtype261;
	Y4756_gen_type [262] = Y4756_pgtype262;
	Y4756_gen_type [263] = Y4756_pgtype263;
	Y4756_gen_type [264] = Y4756_pgtype264;
	Y4756_gen_type [265] = Y4756_pgtype265;
	Y4756_gen_type [266] = Y4756_pgtype266;
	Y4756_gen_type [267] = Y4756_pgtype267;
	Y4756_gen_type [268] = Y4756_pgtype268;
	Y4756_gen_type [269] = Y4756_pgtype269;
	Y4756_gen_type [270] = Y4756_pgtype270;
	Y4756_gen_type [271] = Y4756_pgtype271;
	Y4756_gen_type [272] = Y4756_pgtype272;
	Y4756_gen_type [273] = Y4756_pgtype273;
	Y4756_gen_type [274] = Y4756_pgtype274;
	Y4756_gen_type [275] = Y4756_pgtype275;
	Y4756_gen_type [276] = Y4756_pgtype276;
	Y4756_gen_type [277] = Y4756_pgtype277;
	Y4756_gen_type [278] = Y4756_pgtype278;
	Y4756_gen_type [279] = Y4756_pgtype279;
	Y4756_gen_type [280] = Y4756_pgtype280;
	Y4756_gen_type [281] = Y4756_pgtype281;
	Y4756_gen_type [282] = Y4756_pgtype282;
	Y4756_gen_type [283] = Y4756_pgtype283;
	Y4756_gen_type [284] = Y4756_pgtype284;
	Y4756_gen_type [285] = Y4756_pgtype285;
	Y4756_gen_type [286] = Y4756_pgtype286;
	Y4756_gen_type [287] = Y4756_pgtype287;
	Y4756_gen_type [288] = Y4756_pgtype288;
	Y4756_gen_type [289] = Y4756_pgtype289;
	Y4756_gen_type [290] = Y4756_pgtype290;
	Y4756_gen_type [291] = Y4756_pgtype291;
	Y4756_gen_type [292] = Y4756_pgtype292;
	Y4756_gen_type [293] = Y4756_pgtype293;
	Y4756_gen_type [294] = Y4756_pgtype294;
	Y4756_gen_type [295] = Y4756_pgtype295;
	Y4756_gen_type [296] = Y4756_pgtype296;
	Y4756_gen_type [297] = Y4756_pgtype297;
	Y4756_gen_type [298] = Y4756_pgtype298;
	Y4756_gen_type [299] = Y4756_pgtype299;
	Y4756_gen_type [300] = Y4756_pgtype300;
	Y4756_gen_type [301] = Y4756_pgtype301;
	Y4756_gen_type [302] = Y4756_pgtype302;
	Y4756_gen_type [303] = Y4756_pgtype303;
	Y4756_gen_type [304] = Y4756_pgtype304;
	Y4756_gen_type [305] = Y4756_pgtype305;
	Y4756_gen_type [306] = Y4756_pgtype306;
	Y4756_gen_type [307] = Y4756_pgtype307;
	Y4756_gen_type [308] = Y4756_pgtype308;
	Y4756_gen_type [309] = Y4756_pgtype309;
	Y4756_gen_type [310] = Y4756_pgtype310;
	Y4756_gen_type [311] = Y4756_pgtype311;
	Y4756_gen_type [312] = Y4756_pgtype312;
	Y4756_gen_type [313] = Y4756_pgtype313;
	Y4756_gen_type [314] = Y4756_pgtype314;
	Y4756_gen_type [315] = Y4756_pgtype315;
	Y4756_gen_type [316] = Y4756_pgtype316;
	Y4756_gen_type [317] = Y4756_pgtype317;
	Y4756_gen_type [318] = Y4756_pgtype318;
	Y4756_gen_type [319] = Y4756_pgtype319;
	Y4756_gen_type [320] = Y4756_pgtype320;
	Y4756_gen_type [321] = Y4756_pgtype321;
	Y4756_gen_type [322] = Y4756_pgtype322;
	Y4756_gen_type [323] = Y4756_pgtype323;
	Y4756_gen_type [324] = Y4756_pgtype324;
	Y4756_gen_type [325] = Y4756_pgtype325;
	Y4756_gen_type [326] = Y4756_pgtype326;
	Y4756_gen_type [327] = Y4756_pgtype327;
	Y4756_gen_type [328] = Y4756_pgtype328;
	Y4756_gen_type [329] = Y4756_pgtype329;
	Y4756_gen_type [330] = Y4756_pgtype330;
	Y4756_gen_type [332] = Y4756_pgtype331;
	Y4756_gen_type [333] = Y4756_pgtype332;
	Y4756_gen_type [334] = Y4756_pgtype333;
	Y4756_gen_type [335] = Y4756_pgtype334;
	Y4756_gen_type [336] = Y4756_pgtype335;
	Y4756_gen_type [337] = Y4756_pgtype336;
	Y4756_gen_type [338] = Y4756_pgtype337;
	Y4756_gen_type [339] = Y4756_pgtype338;
	Y4756_gen_type [340] = Y4756_pgtype339;
	Y4756_gen_type [341] = Y4756_pgtype340;
	Y4756_gen_type [342] = Y4756_pgtype341;
	Y4756_gen_type [343] = Y4756_pgtype342;
	Y4756_gen_type [344] = Y4756_pgtype343;
	Y4756_gen_type [345] = Y4756_pgtype344;
	Y4756_gen_type [346] = Y4756_pgtype345;
	Y4756_gen_type [347] = Y4756_pgtype346;
	Y4756_gen_type [348] = Y4756_pgtype347;
	Y4756_gen_type [349] = Y4756_pgtype348;
	Y4756_gen_type [350] = Y4756_pgtype349;
	Y4756_gen_type [351] = Y4756_pgtype350;
	Y4756_gen_type [352] = Y4756_pgtype351;
	Y4756_gen_type [353] = Y4756_pgtype352;
	Y4756_gen_type [354] = Y4756_pgtype353;
	Y4756_gen_type [355] = Y4756_pgtype354;
	Y4756_gen_type [356] = Y4756_pgtype355;
	Y4756_gen_type [357] = Y4756_pgtype356;
	Y4756_gen_type [358] = Y4756_pgtype357;
	Y4756_gen_type [359] = Y4756_pgtype358;
	Y4756_gen_type [360] = Y4756_pgtype359;
	Y4756_gen_type [361] = Y4756_pgtype360;
	Y4756_gen_type [362] = Y4756_pgtype361;
	Y4756_gen_type [363] = Y4756_pgtype362;
	Y4756_gen_type [364] = Y4756_pgtype363;
	Y4756_gen_type [365] = Y4756_pgtype364;
	Y4756_gen_type [366] = Y4756_pgtype365;
	Y4756_gen_type [367] = Y4756_pgtype366;
	Y4756_gen_type [368] = Y4756_pgtype367;
	Y4756_gen_type [369] = Y4756_pgtype368;
	Y4756_gen_type [370] = Y4756_pgtype369;
	Y4756_gen_type [371] = Y4756_pgtype370;
	Y4756_gen_type [372] = Y4756_pgtype371;
	Y4756_gen_type [373] = Y4756_pgtype372;
	Y4756_gen_type [374] = Y4756_pgtype373;
	Y4756_gen_type [375] = Y4756_pgtype374;
	Y4756_gen_type [376] = Y4756_pgtype375;
	Y4756_gen_type [377] = Y4756_pgtype376;
	Y4756_gen_type [378] = Y4756_pgtype377;
	Y4756_gen_type [379] = Y4756_pgtype378;
	Y4756_gen_type [380] = Y4756_pgtype379;
	Y4756_gen_type [381] = Y4756_pgtype380;
	Y4756_gen_type [382] = Y4756_pgtype381;
	Y4756_gen_type [383] = Y4756_pgtype382;
	Y4756_gen_type [384] = Y4756_pgtype383;
	Y4756_gen_type [407] = Y4756_pgtype384;
	Y4756_gen_type [410] = Y4756_pgtype385;
	Y4756_gen_type [411] = Y4756_pgtype386;
	Y4756_gen_type [412] = Y4756_pgtype387;
	Y4756_gen_type [419] = Y4756_pgtype388;
	Y4756_gen_type [420] = Y4756_pgtype389;
	Y4756_gen_type [421] = Y4756_pgtype390;
	Y4756_gen_type [422] = Y4756_pgtype391;
	Y4756_gen_type [423] = Y4756_pgtype392;
	Y4756_gen_type [424] = Y4756_pgtype393;
	Y4756_gen_type [425] = Y4756_pgtype394;
	Y4756_gen_type [426] = Y4756_pgtype395;
	Y4756_gen_type [427] = Y4756_pgtype396;
	Y4756_gen_type [428] = Y4756_pgtype397;
	Y4756_gen_type [429] = Y4756_pgtype398;
	Y4756_gen_type [430] = Y4756_pgtype399;
	Y4756_gen_type [431] = Y4756_pgtype400;
	Y4756_gen_type [432] = Y4756_pgtype401;
	Y4756_gen_type [433] = Y4756_pgtype402;
	Y4756_gen_type [434] = Y4756_pgtype403;
	Y4756_gen_type [435] = Y4756_pgtype404;
	Y4756_gen_type [436] = Y4756_pgtype405;
	Y4756_gen_type [437] = Y4756_pgtype406;
	Y4756_gen_type [438] = Y4756_pgtype407;
	Y4756_gen_type [439] = Y4756_pgtype408;
	Y4756_gen_type [440] = Y4756_pgtype409;
	Y4756_gen_type [441] = Y4756_pgtype410;
	Y4756_gen_type [442] = Y4756_pgtype411;
	Y4756_gen_type [443] = Y4756_pgtype412;
	Y4756_gen_type [444] = Y4756_pgtype413;
	Y4756_gen_type [445] = Y4756_pgtype414;
	Y4756_gen_type [446] = Y4756_pgtype415;
	Y4756_gen_type [447] = Y4756_pgtype416;
	Y4756_gen_type [448] = Y4756_pgtype417;
	Y4756_gen_type [449] = Y4756_pgtype418;
	Y4756_gen_type [450] = Y4756_pgtype419;
	Y4756_gen_type [451] = Y4756_pgtype420;
	Y4756_gen_type [452] = Y4756_pgtype421;
	Y4756_gen_type [453] = Y4756_pgtype422;
	Y4756_gen_type [454] = Y4756_pgtype423;
	Y4756_gen_type [455] = Y4756_pgtype424;
	Y4756_gen_type [456] = Y4756_pgtype425;
	Y4756_gen_type [457] = Y4756_pgtype426;
	Y4756_gen_type [458] = Y4756_pgtype427;
	Y4756_gen_type [459] = Y4756_pgtype428;
	Y4756_gen_type [460] = Y4756_pgtype429;
	Y4756_gen_type [461] = Y4756_pgtype430;
	Y4756_gen_type [462] = Y4756_pgtype431;
	Y4756_gen_type [463] = Y4756_pgtype432;
	Y4756_gen_type [464] = Y4756_pgtype433;
	Y4756_gen_type [465] = Y4756_pgtype434;
	Y4756_gen_type [466] = Y4756_pgtype435;
	Y4756_gen_type [467] = Y4756_pgtype436;
	Y4756_gen_type [468] = Y4756_pgtype437;
	Y4756_gen_type [469] = Y4756_pgtype438;
	Y4756_gen_type [470] = Y4756_pgtype439;
	Y4756_gen_type [471] = Y4756_pgtype440;
	Y4756_gen_type [472] = Y4756_pgtype441;
	Y4756_gen_type [473] = Y4756_pgtype442;
	Y4756_gen_type [474] = Y4756_pgtype443;
	Y4756_gen_type [475] = Y4756_pgtype444;
	Y4756_gen_type [476] = Y4756_pgtype445;
	Y4756_gen_type [477] = Y4756_pgtype446;
	Y4756_gen_type [478] = Y4756_pgtype447;
	Y4756_gen_type [479] = Y4756_pgtype448;
	Y4756_gen_type [480] = Y4756_pgtype449;
	Y4756_gen_type [481] = Y4756_pgtype450;
	Y4756_gen_type [482] = Y4756_pgtype451;
	Y4756_gen_type [483] = Y4756_pgtype452;
	Y4756_gen_type [484] = Y4756_pgtype453;
	Y4756_gen_type [485] = Y4756_pgtype454;
	Y4756_gen_type [486] = Y4756_pgtype455;
	Y4756_gen_type [487] = Y4756_pgtype456;
	Y4756_gen_type [488] = Y4756_pgtype457;
	Y4756_gen_type [489] = Y4756_pgtype458;
	Y4756_gen_type [490] = Y4756_pgtype459;
	Y4756_gen_type [491] = Y4756_pgtype460;
	Y4756_gen_type [492] = Y4756_pgtype461;
	Y4756_gen_type [493] = Y4756_pgtype462;
	Y4756_gen_type [494] = Y4756_pgtype463;
	Y4756_gen_type [495] = Y4756_pgtype464;
	Y4756_gen_type [496] = Y4756_pgtype465;
	Y4756_gen_type [497] = Y4756_pgtype466;
	Y4756_gen_type [498] = Y4756_pgtype467;
	Y4756_gen_type [499] = Y4756_pgtype468;
	Y4756_gen_type [500] = Y4756_pgtype469;
	Y4756_gen_type [501] = Y4756_pgtype470;
	Y4756_gen_type [502] = Y4756_pgtype471;
	Y4756_gen_type [503] = Y4756_pgtype472;
	Y4756_gen_type [504] = Y4756_pgtype473;
	Y4756_gen_type [505] = Y4756_pgtype474;
	Y4756_gen_type [506] = Y4756_pgtype475;
	Y4756_gen_type [507] = Y4756_pgtype476;
	Y4756_gen_type [508] = Y4756_pgtype477;
	Y4756_gen_type [509] = Y4756_pgtype478;
	Y4756_gen_type [510] = Y4756_pgtype479;
	Y4756_gen_type [511] = Y4756_pgtype480;
	Y4756_gen_type [512] = Y4756_pgtype481;
	Y4756_gen_type [513] = Y4756_pgtype482;
	Y4756_gen_type [517] = Y4756_pgtype483;
	Y4756_gen_type [520] = Y4756_pgtype484;
	Y4756_gen_type [521] = Y4756_pgtype485;
	Y4756_gen_type [522] = Y4756_pgtype486;
	Y4756_gen_type [523] = Y4756_pgtype487;
	Y4756_gen_type [524] = Y4756_pgtype488;
	Y4756_gen_type [525] = Y4756_pgtype489;
	Y4756_gen_type [526] = Y4756_pgtype490;
	Y4756_gen_type [527] = Y4756_pgtype491;
	Y4756_gen_type [528] = Y4756_pgtype492;
	Y4756_gen_type [529] = Y4756_pgtype493;
	Y4756_gen_type [530] = Y4756_pgtype494;
	Y4756_gen_type [531] = Y4756_pgtype495;
	Y4756_gen_type [604] = Y4756_pgtype496;
	Y4756_gen_type [605] = Y4756_pgtype497;
	Y4756_gen_type [606] = Y4756_pgtype498;
	Y4756_gen_type [652] = Y4756_pgtype499;
	Y4756_gen_type [734] = Y4756_pgtype500;
	Y4756_gen_type [735] = Y4756_pgtype501;
	Y4756_gen_type [736] = Y4756_pgtype502;
	Y4756_gen_type [737] = Y4756_pgtype503;
	Y4756_gen_type [738] = Y4756_pgtype504;
	Y4756_gen_type [739] = Y4756_pgtype505;
	Y4756_gen_type [740] = Y4756_pgtype506;
	Y4756_gen_type [810] = Y4756_pgtype507;
	Y4756_gen_type [813] = Y4756_pgtype508;
	Y4756_gen_type [814] = Y4756_pgtype509;
	Y4756_gen_type [815] = Y4756_pgtype510;
	Y4756_gen_type [816] = Y4756_pgtype511;
	Y4756_gen_type [817] = Y4756_pgtype512;
	Y4756_gen_type [818] = Y4756_pgtype513;
	Y4756_gen_type [819] = Y4756_pgtype514;
	Y4756_gen_type [820] = Y4756_pgtype515;
	Y4756_gen_type [821] = Y4756_pgtype516;
	Y4756_gen_type [822] = Y4756_pgtype517;
	Y4756_gen_type [823] = Y4756_pgtype518;
	Y4756_gen_type [824] = Y4756_pgtype519;
	Y4756_gen_type [825] = Y4756_pgtype520;
	Y4756_gen_type [826] = Y4756_pgtype521;
	Y4756_gen_type [827] = Y4756_pgtype522;
	Y4756_gen_type [828] = Y4756_pgtype523;
	Y4756_gen_type [829] = Y4756_pgtype524;
	Y4756_gen_type [830] = Y4756_pgtype525;
	Y4756_gen_type [831] = Y4756_pgtype526;
	Y4756_gen_type [832] = Y4756_pgtype527;
	Y4756_gen_type [833] = Y4756_pgtype528;
	Y4756_gen_type [850] = Y4756_pgtype529;
	Y4756_gen_type [859] = Y4756_pgtype530;
	Y4756_gen_type [860] = Y4756_pgtype531;
	Y4756_gen_type [861] = Y4756_pgtype532;
	Y4756_gen_type [862] = Y4756_pgtype533;
	Y4756_gen_type [863] = Y4756_pgtype534;
	Y4756_gen_type [864] = Y4756_pgtype535;
	Y4756_gen_type [865] = Y4756_pgtype536;
	Y4756_gen_type [866] = Y4756_pgtype537;
	Y4756_gen_type [867] = Y4756_pgtype538;
	Y4756_gen_type [868] = Y4756_pgtype539;
	Y4756_gen_type [869] = Y4756_pgtype540;
	Y4756_gen_type [870] = Y4756_pgtype541;
	Y4756_gen_type [871] = Y4756_pgtype542;
	Y4756_gen_type [1058] = Y4756_pgtype543;
	Y4756[12] = 1053;
	Y4756[13] = 1049;
	Y4756[20] = 831;
	{long i; for (i = 261; i < 263; i++) Y4756[i] = 984;};
	Y4756[275] = 1002;
	Y4756[341] = 0;
	Y4756[363] = 1094;
	{long i; for (i = 364; i < 385; i++) Y4756[i] = 1040;};
	Y4756[407] = 984;
	Y4756[410] = 30;
	Y4756[411] = 972;
	Y4756[412] = 984;
	Y4756[488] = 972;
	Y4756[489] = 975;
	Y4756[517] = 1048;
	{long i; for (i = 604; i < 607; i++) Y4756[i] = 975;};
	Y4756[652] = 0;
	{long i; for (i = 734; i < 737; i++) Y4756[i] = 972;};
	{long i; for (i = 737; i < 741; i++) Y4756[i] = 975;};
	{long i; for (i = 813; i < 834; i++) Y4756[i] = 1126;};
	Y4756[850] = 1050;
	Y4756[860] = 1164;
	Y4756[861] = 1165;
	{long i; for (i = 862; i < 865; i++) Y4756[i] = 1163;};
	{long i; for (i = 865; i < 869; i++) Y4756[i] = 1181;};
	{long i; for (i = 869; i < 872; i++) Y4756[i] = 1169;};
	Y4756[1058] = 975;
}

char *(*R4807[798])();
void R4807_init () {
	R4807[0] = (char *(*)()) F576_5304_4807_2;
	R4807[2] = (char *(*)()) F578_5353;
	R4807[3] = (char *(*)()) F579_5353_4807_2;
	R4807[4] = (char *(*)()) F580_5353_4807_2;
	R4807[5] = (char *(*)()) F581_5353_4807_2;
	R4807[6] = (char *(*)()) F582_5353_4807_2;
	R4807[7] = (char *(*)()) F583_5353_4807_2;
	R4807[8] = (char *(*)()) F584_5353_4807_2;
	R4807[9] = (char *(*)()) F585_5353_4807_2;
	R4807[10] = (char *(*)()) F586_5353_4807_2;
	R4807[11] = (char *(*)()) F587_5353_4807_2;
	R4807[12] = (char *(*)()) F588_5353_4807_2;
	R4807[13] = (char *(*)()) F589_5353_4807_2;
	R4807[63] = (char *(*)()) F591_5427;
	R4807[64] = (char *(*)()) F592_5427_4807_2;
	R4807[65] = (char *(*)()) F598_5427_4807_2;
	R4807[66] = (char *(*)()) F591_5427;
	R4807[67] = (char *(*)()) F598_5427_4807_2;
	R4807[68] = (char *(*)()) F592_5427_4807_2;
	R4807[69] = (char *(*)()) F591_5427;
	R4807[72] = (char *(*)()) F648_5598;
	R4807[73] = (char *(*)()) F649_5598_4807_2;
	R4807[74] = (char *(*)()) F650_5598;
	R4807[75] = (char *(*)()) F651_5598_4807_2;
	R4807[76] = (char *(*)()) F652_5598_4807_2;
	R4807[77] = (char *(*)()) F653_5598_4807_2;
	R4807[78] = (char *(*)()) F648_5598;
	R4807[79] = (char *(*)()) F649_5598_4807_2;
	R4807[80] = (char *(*)()) F648_5598;
	R4807[81] = (char *(*)()) F657_5731;
	R4807[82] = (char *(*)()) F658_5731_4807_2;
	R4807[83] = (char *(*)()) F659_5731_4807_2;
	R4807[84] = (char *(*)()) F660_5731_4807_2;
	R4807[85] = (char *(*)()) F661_5731_4807_2;
	R4807[86] = (char *(*)()) F662_5731_4807_2;
	R4807[87] = (char *(*)()) F663_5731_4807_2;
	R4807[88] = (char *(*)()) F664_5731_4807_2;
	R4807[89] = (char *(*)()) F665_5731_4807_2;
	R4807[90] = (char *(*)()) F666_5731_4807_2;
	R4807[91] = (char *(*)()) F667_5731_4807_2;
	R4807[92] = (char *(*)()) F668_5731_4807_2;
	R4807[93] = (char *(*)()) F657_5731;
	R4807[94] = (char *(*)()) F658_5731_4807_2;
	R4807[95] = (char *(*)()) F664_5731_4807_2;
	R4807[100] = (char *(*)()) F657_5731;
	R4807[101] = (char *(*)()) F658_5731_4807_2;
	{long i; for (i = 102; i < 106; i++) R4807[i] = (char *(*)()) F657_5731;}
	R4807[110] = (char *(*)()) F657_5731;
	R4807[112] = (char *(*)()) F657_5731;
	R4807[116] = (char *(*)()) F657_5731;
	{long i; for (i = 118; i < 120; i++) R4807[i] = (char *(*)()) F657_5731;}
	{long i; for (i = 121; i < 124; i++) R4807[i] = (char *(*)()) F657_5731;}
	R4807[146] = (char *(*)()) F722_6093_4807_2;
	R4807[151] = (char *(*)()) F727_6158_4807_2;
	{long i; for (i = 344; i < 346; i++) R4807[i] = (char *(*)()) F369_5153_4807_2;}
	R4807[475] = (char *(*)()) F1049_9149_4807_2;
	R4807[478] = (char *(*)()) F1052_9317_4807_2;
	{long i; for (i = 557; i < 560; i++) R4807[i] = (char *(*)()) F591_5427;}
	{long i; for (i = 560; i < 562; i++) R4807[i] = (char *(*)()) F1136_10342;}
	R4807[563] = (char *(*)()) F1136_10342;
	R4807[564] = (char *(*)()) F1140_10397;
	{long i; for (i = 568; i < 571; i++) R4807[i] = (char *(*)()) F1140_10397;}
	R4807[572] = (char *(*)()) F1140_10397;
	R4807[600] = (char *(*)()) F591_5427;
	R4807[610] = (char *(*)()) F591_5427;
	R4807[797] = (char *(*)()) F369_5153_4807_2;
}
static EIF_BOOLEAN F576_5304_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F576_5304(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F579_5353_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F579_5353(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F580_5353_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F580_5353(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F581_5353_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F581_5353(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F582_5353_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F582_5353(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F583_5353_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F583_5353(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F584_5353_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F584_5353(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F585_5353_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F585_5353(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F586_5353_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F586_5353(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F587_5353_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F587_5353(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F588_5353_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F588_5353(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F589_5353_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F589_5353(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F592_5427_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F592_5427(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F598_5427_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F598_5427(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F649_5598_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F649_5598(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F651_5598_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F651_5598(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F652_5598_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F652_5598(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F653_5598_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F653_5598(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F658_5731_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F658_5731(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F659_5731_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F659_5731(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F660_5731_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F660_5731(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F661_5731_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F661_5731(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F662_5731_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F662_5731(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F663_5731_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F663_5731(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F664_5731_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F664_5731(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F665_5731_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F665_5731(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F666_5731_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F666_5731(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F667_5731_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F667_5731(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F668_5731_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F668_5731(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F722_6093_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F722_6093(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F727_6158_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F727_6158(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F369_5153_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F369_5153(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1049_9149_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1049_9149(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F1052_9317_4807_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1052_9317(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4808[1024])();
void R4808_init () {
	R4808[0] = (char *(*)()) F348_5028;
	R4808[226] = (char *(*)()) F484_5229;
	R4808[228] = (char *(*)()) F483_5229;
	R4808[229] = (char *(*)()) F484_5229;
	R4808[230] = (char *(*)()) F485_5229;
	R4808[231] = (char *(*)()) F486_5229;
	R4808[232] = (char *(*)()) F487_5229;
	R4808[233] = (char *(*)()) F488_5229;
	R4808[234] = (char *(*)()) F489_5229;
	R4808[235] = (char *(*)()) F490_5229;
	R4808[236] = (char *(*)()) F491_5229;
	R4808[237] = (char *(*)()) F492_5229;
	R4808[238] = (char *(*)()) F493_5229;
	R4808[239] = (char *(*)()) F494_5229;
	R4808[289] = (char *(*)()) F483_5229;
	R4808[290] = (char *(*)()) F484_5229;
	R4808[291] = (char *(*)()) F490_5229;
	R4808[292] = (char *(*)()) F483_5229;
	R4808[293] = (char *(*)()) F490_5229;
	R4808[294] = (char *(*)()) F484_5229;
	R4808[295] = (char *(*)()) F483_5229;
	R4808[298] = (char *(*)()) F483_5229;
	R4808[299] = (char *(*)()) F484_5229;
	R4808[300] = (char *(*)()) F483_5229;
	{long i; for (i = 301; i < 303; i++) R4808[i] = (char *(*)()) F484_5229;}
	R4808[303] = (char *(*)()) F493_5229;
	R4808[304] = (char *(*)()) F483_5229;
	R4808[305] = (char *(*)()) F484_5229;
	{long i; for (i = 306; i < 308; i++) R4808[i] = (char *(*)()) F483_5229;}
	R4808[308] = (char *(*)()) F484_5229;
	R4808[309] = (char *(*)()) F485_5229;
	R4808[310] = (char *(*)()) F486_5229;
	R4808[311] = (char *(*)()) F487_5229;
	R4808[312] = (char *(*)()) F488_5229;
	R4808[313] = (char *(*)()) F489_5229;
	R4808[314] = (char *(*)()) F490_5229;
	R4808[315] = (char *(*)()) F491_5229;
	R4808[316] = (char *(*)()) F492_5229;
	R4808[317] = (char *(*)()) F493_5229;
	R4808[318] = (char *(*)()) F494_5229;
	R4808[319] = (char *(*)()) F483_5229;
	R4808[320] = (char *(*)()) F484_5229;
	R4808[321] = (char *(*)()) F490_5229;
	R4808[326] = (char *(*)()) F483_5229;
	R4808[327] = (char *(*)()) F484_5229;
	{long i; for (i = 328; i < 332; i++) R4808[i] = (char *(*)()) F483_5229;}
	R4808[336] = (char *(*)()) F483_5229;
	R4808[338] = (char *(*)()) F483_5229;
	R4808[342] = (char *(*)()) F483_5229;
	{long i; for (i = 344; i < 346; i++) R4808[i] = (char *(*)()) F483_5229;}
	{long i; for (i = 347; i < 350; i++) R4808[i] = (char *(*)()) F483_5229;}
	R4808[372] = (char *(*)()) F480_5207;
	R4808[377] = (char *(*)()) F480_5207;
	{long i; for (i = 570; i < 572; i++) R4808[i] = (char *(*)()) F489_5229;}
	R4808[701] = (char *(*)()) F491_5229;
	R4808[704] = (char *(*)()) F489_5229;
	{long i; for (i = 783; i < 786; i++) R4808[i] = (char *(*)()) F483_5229;}
	{long i; for (i = 786; i < 788; i++) R4808[i] = (char *(*)()) F1136_10343;}
	{long i; for (i = 789; i < 791; i++) R4808[i] = (char *(*)()) F1136_10343;}
	{long i; for (i = 794; i < 797; i++) R4808[i] = (char *(*)()) F1136_10343;}
	R4808[798] = (char *(*)()) F1136_10343;
	R4808[826] = (char *(*)()) F483_5229;
	R4808[836] = (char *(*)()) F483_5229;
	R4808[1023] = (char *(*)()) F1373_14117;
}


#ifdef __cplusplus
}
#endif
