#include "epoly7.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4936[548])();
void R4936_init () {
	R4936[0] = (char *(*)()) F429_5195;
	R4936[1] = (char *(*)()) F431_5195;
	R4936[2] = (char *(*)()) F438_5195;
	R4936[3] = (char *(*)()) F429_5195;
	R4936[4] = (char *(*)()) F438_5195;
	R4936[5] = (char *(*)()) F431_5195;
	R4936[6] = (char *(*)()) F429_5195;
	R4936[9] = (char *(*)()) F428_5195;
	R4936[10] = (char *(*)()) F430_5195;
	R4936[11] = (char *(*)()) F429_5195;
	R4936[12] = (char *(*)()) F431_5195;
	R4936[13] = (char *(*)()) F436_5195;
	R4936[14] = (char *(*)()) F441_5195;
	R4936[15] = (char *(*)()) F428_5195;
	R4936[16] = (char *(*)()) F430_5195;
	R4936[17] = (char *(*)()) F428_5195;
	R4936[412] = (char *(*)()) F439_5195;
	R4936[415] = (char *(*)()) F437_5195;
	{long i; for (i = 494; i < 497; i++) R4936[i] = (char *(*)()) F429_5195;}
	{long i; for (i = 497; i < 499; i++) R4936[i] = (char *(*)()) F1136_10346;}
	{long i; for (i = 500; i < 502; i++) R4936[i] = (char *(*)()) F1136_10346;}
	{long i; for (i = 505; i < 508; i++) R4936[i] = (char *(*)()) F1136_10346;}
	R4936[509] = (char *(*)()) F1136_10346;
	R4936[537] = (char *(*)()) F429_5195;
	R4936[547] = (char *(*)()) F429_5195;
}

char *(*R4938[30])();
void R4938_init () {
	R4938[0] = (char *(*)()) F642_5525;
	R4938[1] = (char *(*)()) F643_5525_4938_4;
	R4938[2] = (char *(*)()) F644_5525_4938_4;
	R4938[27] = (char *(*)()) F669_5787;
	R4938[28] = (char *(*)()) F670_5787_4938_4;
	R4938[29] = (char *(*)()) F671_5787_4938_4;
}
static void F643_5525_4938_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F643_5525(Current, *(EIF_BOOLEAN *)arg1);
}
static void F644_5525_4938_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F644_5525(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F670_5787_4938_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F670_5787(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F671_5787_4938_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F671_5787(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R4939[735])();
void R4939_init () {
	R4939[0] = (char *(*)()) F639_5502;
	R4939[1] = (char *(*)()) F640_5502_4939_4;
	R4939[2] = (char *(*)()) F641_5502_4939_4;
	R4939[3] = (char *(*)()) F642_5524;
	R4939[4] = (char *(*)()) F643_5524_4939_4;
	R4939[5] = (char *(*)()) F644_5524_4939_4;
	R4939[6] = (char *(*)()) F645_5539;
	R4939[18] = (char *(*)()) F657_5760;
	R4939[19] = (char *(*)()) F658_5760_4939_4;
	R4939[20] = (char *(*)()) F659_5760_4939_4;
	R4939[21] = (char *(*)()) F660_5760_4939_4;
	R4939[22] = (char *(*)()) F661_5760_4939_4;
	R4939[23] = (char *(*)()) F662_5760_4939_4;
	R4939[24] = (char *(*)()) F663_5760_4939_4;
	R4939[25] = (char *(*)()) F664_5760_4939_4;
	R4939[26] = (char *(*)()) F665_5760_4939_4;
	R4939[27] = (char *(*)()) F666_5760_4939_4;
	R4939[28] = (char *(*)()) F667_5760_4939_4;
	R4939[29] = (char *(*)()) F668_5760_4939_4;
	R4939[30] = (char *(*)()) F669_5786;
	R4939[31] = (char *(*)()) F670_5786_4939_4;
	R4939[32] = (char *(*)()) F671_5786_4939_4;
	R4939[37] = (char *(*)()) F672_5802;
	R4939[38] = (char *(*)()) F673_5802_4939_4;
	{long i; for (i = 39; i < 43; i++) R4939[i] = (char *(*)()) F672_5802;}
	R4939[47] = (char *(*)()) F672_5802;
	R4939[49] = (char *(*)()) F672_5802;
	R4939[53] = (char *(*)()) F672_5802;
	{long i; for (i = 55; i < 57; i++) R4939[i] = (char *(*)()) F672_5802;}
	{long i; for (i = 58; i < 61; i++) R4939[i] = (char *(*)()) F672_5802;}
	{long i; for (i = 281; i < 283; i++) R4939[i] = (char *(*)()) F919_7179_4939_4;}
	R4939[412] = (char *(*)()) F1051_9244_4939_4;
	R4939[415] = (char *(*)()) F1054_9409_4939_4;
	{long i; for (i = 494; i < 499; i++) R4939[i] = (char *(*)()) F1128_10251;}
	{long i; for (i = 500; i < 502; i++) R4939[i] = (char *(*)()) F1128_10251;}
	{long i; for (i = 505; i < 508; i++) R4939[i] = (char *(*)()) F1128_10251;}
	R4939[509] = (char *(*)()) F1128_10251;
	R4939[537] = (char *(*)()) F1125_10170;
	R4939[547] = (char *(*)()) F1125_10170;
	R4939[734] = (char *(*)()) F919_7179_4939_4;
}
static void F640_5502_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F640_5502(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F641_5502_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F641_5502(Current, *(EIF_BOOLEAN *)arg1);
}
static void F643_5524_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F643_5524(Current, *(EIF_BOOLEAN *)arg1);
}
static void F644_5524_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F644_5524(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F658_5760_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5760(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F659_5760_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5760(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F660_5760_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F660_5760(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F661_5760_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_5760(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F662_5760_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F662_5760(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F663_5760_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_5760(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F664_5760_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5760(Current, *(EIF_BOOLEAN *)arg1);
}
static void F665_5760_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5760(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F666_5760_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5760(Current, *(EIF_REAL_32 *)arg1);
}
static void F667_5760_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5760(Current, *(EIF_POINTER *)arg1);
}
static void F668_5760_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5760(Current, *(EIF_REAL_64 *)arg1);
}
static void F670_5786_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F670_5786(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F671_5786_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F671_5786(Current, *(EIF_BOOLEAN *)arg1);
}
static void F673_5802_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F673_5802(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F919_7179_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F919_7179(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1051_9244_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1051_9244(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1054_9409_4939_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1054_9409(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4940[548])();
void R4940_init () {
	R4940[0] = (char *(*)()) F591_5445;
	R4940[1] = (char *(*)()) F592_5445;
	R4940[2] = (char *(*)()) F598_5445;
	R4940[3] = (char *(*)()) F536_5288;
	R4940[4] = (char *(*)()) F538_5288;
	R4940[5] = (char *(*)()) F537_5288;
	R4940[18] = (char *(*)()) F591_5445;
	R4940[19] = (char *(*)()) F592_5445;
	R4940[20] = (char *(*)()) F593_5445;
	R4940[21] = (char *(*)()) F594_5445;
	R4940[22] = (char *(*)()) F595_5445;
	R4940[23] = (char *(*)()) F596_5445;
	R4940[24] = (char *(*)()) F597_5445;
	R4940[25] = (char *(*)()) F598_5445;
	R4940[26] = (char *(*)()) F599_5445;
	R4940[27] = (char *(*)()) F600_5445;
	R4940[28] = (char *(*)()) F601_5445;
	R4940[29] = (char *(*)()) F602_5445;
	R4940[30] = (char *(*)()) F536_5288;
	R4940[31] = (char *(*)()) F537_5288;
	R4940[32] = (char *(*)()) F538_5288;
	R4940[37] = (char *(*)()) F591_5445;
	R4940[38] = (char *(*)()) F592_5445;
	{long i; for (i = 39; i < 43; i++) R4940[i] = (char *(*)()) F591_5445;}
	R4940[47] = (char *(*)()) F591_5445;
	R4940[49] = (char *(*)()) F591_5445;
	R4940[53] = (char *(*)()) F591_5445;
	{long i; for (i = 55; i < 57; i++) R4940[i] = (char *(*)()) F591_5445;}
	{long i; for (i = 58; i < 61; i++) R4940[i] = (char *(*)()) F591_5445;}
	{long i; for (i = 494; i < 497; i++) R4940[i] = (char *(*)()) F591_5445;}
	R4940[537] = (char *(*)()) F591_5445;
	R4940[547] = (char *(*)()) F591_5445;
}

char *(*R4941[798])();
void R4941_init () {
	R4941[0] = (char *(*)()) F576_5331_4941_4;
	R4941[2] = (char *(*)()) F578_5400;
	R4941[3] = (char *(*)()) F579_5400_4941_4;
	R4941[4] = (char *(*)()) F580_5400_4941_4;
	R4941[5] = (char *(*)()) F581_5400_4941_4;
	R4941[6] = (char *(*)()) F582_5400_4941_4;
	R4941[7] = (char *(*)()) F583_5400_4941_4;
	R4941[8] = (char *(*)()) F584_5400_4941_4;
	R4941[9] = (char *(*)()) F585_5400_4941_4;
	R4941[10] = (char *(*)()) F586_5400_4941_4;
	R4941[11] = (char *(*)()) F587_5400_4941_4;
	R4941[12] = (char *(*)()) F588_5400_4941_4;
	R4941[13] = (char *(*)()) F589_5400_4941_4;
	R4941[63] = (char *(*)()) F603_5455;
	R4941[64] = (char *(*)()) F604_5455_4941_4;
	R4941[65] = (char *(*)()) F610_5455_4941_4;
	R4941[66] = (char *(*)()) F603_5455;
	R4941[67] = (char *(*)()) F610_5455_4941_4;
	R4941[68] = (char *(*)()) F604_5455_4941_4;
	R4941[69] = (char *(*)()) F645_5544;
	R4941[72] = (char *(*)()) F648_5641;
	R4941[73] = (char *(*)()) F649_5641_4941_4;
	R4941[74] = (char *(*)()) F650_5641;
	R4941[75] = (char *(*)()) F651_5641_4941_4;
	R4941[76] = (char *(*)()) F652_5641_4941_4;
	R4941[77] = (char *(*)()) F653_5641_4941_4;
	R4941[78] = (char *(*)()) F648_5641;
	R4941[79] = (char *(*)()) F649_5641_4941_4;
	R4941[80] = (char *(*)()) F648_5641;
	R4941[81] = (char *(*)()) F657_5772;
	R4941[82] = (char *(*)()) F658_5772_4941_4;
	R4941[83] = (char *(*)()) F659_5772_4941_4;
	R4941[84] = (char *(*)()) F660_5772_4941_4;
	R4941[85] = (char *(*)()) F661_5772_4941_4;
	R4941[86] = (char *(*)()) F662_5772_4941_4;
	R4941[87] = (char *(*)()) F663_5772_4941_4;
	R4941[88] = (char *(*)()) F664_5772_4941_4;
	R4941[89] = (char *(*)()) F665_5772_4941_4;
	R4941[90] = (char *(*)()) F666_5772_4941_4;
	R4941[91] = (char *(*)()) F667_5772_4941_4;
	R4941[92] = (char *(*)()) F668_5772_4941_4;
	R4941[93] = (char *(*)()) F657_5772;
	R4941[94] = (char *(*)()) F658_5772_4941_4;
	R4941[95] = (char *(*)()) F664_5772_4941_4;
	R4941[100] = (char *(*)()) F657_5772;
	R4941[101] = (char *(*)()) F658_5772_4941_4;
	R4941[102] = (char *(*)()) F657_5772;
	{long i; for (i = 103; i < 106; i++) R4941[i] = (char *(*)()) F679_5853;}
	R4941[110] = (char *(*)()) F679_5853;
	R4941[112] = (char *(*)()) F679_5853;
	R4941[116] = (char *(*)()) F679_5853;
	{long i; for (i = 118; i < 120; i++) R4941[i] = (char *(*)()) F679_5853;}
	{long i; for (i = 121; i < 124; i++) R4941[i] = (char *(*)()) F679_5853;}
	R4941[146] = (char *(*)()) F482_5223_4941_4;
	R4941[151] = (char *(*)()) F482_5223_4941_4;
	{long i; for (i = 344; i < 346; i++) R4941[i] = (char *(*)()) F919_7300_4941_4;}
	R4941[475] = (char *(*)()) F1051_9255_4941_4;
	R4941[478] = (char *(*)()) F1054_9420_4941_4;
	{long i; for (i = 557; i < 562; i++) R4941[i] = (char *(*)()) F1128_10252;}
	{long i; for (i = 563; i < 565; i++) R4941[i] = (char *(*)()) F1128_10252;}
	{long i; for (i = 568; i < 571; i++) R4941[i] = (char *(*)()) F1128_10252;}
	R4941[572] = (char *(*)()) F1128_10252;
	R4941[600] = (char *(*)()) F603_5455;
	R4941[610] = (char *(*)()) F603_5455;
	R4941[797] = (char *(*)()) F919_7300_4941_4;
}
static void F576_5331_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F576_5331(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F579_5400_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F579_5400(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F580_5400_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F580_5400(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F581_5400_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F581_5400(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F582_5400_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F582_5400(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F583_5400_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F583_5400(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F584_5400_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F584_5400(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F585_5400_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F585_5400(Current, *(EIF_BOOLEAN *)arg1);
}
static void F586_5400_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F586_5400(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F587_5400_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F587_5400(Current, *(EIF_REAL_32 *)arg1);
}
static void F588_5400_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F588_5400(Current, *(EIF_POINTER *)arg1);
}
static void F589_5400_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F589_5400(Current, *(EIF_REAL_64 *)arg1);
}
static void F604_5455_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F604_5455(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F610_5455_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F610_5455(Current, *(EIF_BOOLEAN *)arg1);
}
static void F649_5641_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F649_5641(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F651_5641_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F651_5641(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F652_5641_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F652_5641(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F653_5641_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F653_5641(Current, *(EIF_POINTER *)arg1);
}
static void F658_5772_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5772(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F659_5772_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5772(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F660_5772_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F660_5772(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F661_5772_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_5772(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F662_5772_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F662_5772(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F663_5772_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_5772(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F664_5772_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5772(Current, *(EIF_BOOLEAN *)arg1);
}
static void F665_5772_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5772(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F666_5772_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5772(Current, *(EIF_REAL_32 *)arg1);
}
static void F667_5772_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5772(Current, *(EIF_POINTER *)arg1);
}
static void F668_5772_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5772(Current, *(EIF_REAL_64 *)arg1);
}
static void F482_5223_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F482_5223(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F919_7300_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F919_7300(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1051_9255_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1051_9255(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1054_9420_4941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1054_9420(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4942[611])();
void R4942_init () {
	R4942[0] = (char *(*)()) F388_5180_4942_4;
	R4942[2] = (char *(*)()) F387_5180;
	R4942[3] = (char *(*)()) F388_5180_4942_4;
	R4942[4] = (char *(*)()) F389_5180_4942_4;
	R4942[5] = (char *(*)()) F390_5180_4942_4;
	R4942[6] = (char *(*)()) F391_5180_4942_4;
	R4942[7] = (char *(*)()) F392_5180_4942_4;
	R4942[8] = (char *(*)()) F393_5180_4942_4;
	R4942[9] = (char *(*)()) F394_5180_4942_4;
	R4942[10] = (char *(*)()) F395_5180_4942_4;
	R4942[11] = (char *(*)()) F396_5180_4942_4;
	R4942[12] = (char *(*)()) F397_5180_4942_4;
	R4942[13] = (char *(*)()) F398_5180_4942_4;
	R4942[63] = (char *(*)()) F603_5456;
	R4942[64] = (char *(*)()) F604_5456_4942_4;
	R4942[65] = (char *(*)()) F610_5456_4942_4;
	R4942[66] = (char *(*)()) F387_5180;
	R4942[67] = (char *(*)()) F394_5180_4942_4;
	R4942[68] = (char *(*)()) F388_5180_4942_4;
	R4942[69] = (char *(*)()) F645_5545;
	R4942[72] = (char *(*)()) F387_5180;
	R4942[73] = (char *(*)()) F388_5180_4942_4;
	R4942[74] = (char *(*)()) F387_5180;
	{long i; for (i = 75; i < 77; i++) R4942[i] = (char *(*)()) F388_5180_4942_4;}
	R4942[77] = (char *(*)()) F397_5180_4942_4;
	R4942[78] = (char *(*)()) F387_5180;
	R4942[79] = (char *(*)()) F388_5180_4942_4;
	R4942[80] = (char *(*)()) F387_5180;
	R4942[100] = (char *(*)()) F672_5812;
	R4942[101] = (char *(*)()) F673_5812_4942_4;
	{long i; for (i = 102; i < 106; i++) R4942[i] = (char *(*)()) F672_5812;}
	R4942[110] = (char *(*)()) F672_5812;
	R4942[112] = (char *(*)()) F672_5812;
	R4942[116] = (char *(*)()) F672_5812;
	{long i; for (i = 118; i < 120; i++) R4942[i] = (char *(*)()) F672_5812;}
	{long i; for (i = 121; i < 124; i++) R4942[i] = (char *(*)()) F672_5812;}
	R4942[146] = (char *(*)()) F388_5180_4942_4;
	R4942[151] = (char *(*)()) F388_5180_4942_4;
	R4942[475] = (char *(*)()) F1051_9256_4942_4;
	{long i; for (i = 557; i < 560; i++) R4942[i] = (char *(*)()) F603_5456;}
	{long i; for (i = 560; i < 562; i++) R4942[i] = (char *(*)()) F387_5180;}
	{long i; for (i = 563; i < 565; i++) R4942[i] = (char *(*)()) F387_5180;}
	{long i; for (i = 568; i < 571; i++) R4942[i] = (char *(*)()) F387_5180;}
	R4942[572] = (char *(*)()) F387_5180;
	R4942[600] = (char *(*)()) F603_5456;
	R4942[610] = (char *(*)()) F603_5456;
}
static void F388_5180_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F388_5180(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F389_5180_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F389_5180(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F390_5180_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F390_5180(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F391_5180_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F391_5180(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F392_5180_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F392_5180(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F393_5180_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F393_5180(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F394_5180_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F394_5180(Current, *(EIF_BOOLEAN *)arg1);
}
static void F395_5180_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F395_5180(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F396_5180_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F396_5180(Current, *(EIF_REAL_32 *)arg1);
}
static void F397_5180_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F397_5180(Current, *(EIF_POINTER *)arg1);
}
static void F398_5180_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F398_5180(Current, *(EIF_REAL_64 *)arg1);
}
static void F604_5456_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F604_5456(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F610_5456_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F610_5456(Current, *(EIF_BOOLEAN *)arg1);
}
static void F673_5812_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F673_5812(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1051_9256_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1051_9256(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R4943[539])();
void R4943_init () {
	R4943[0] = (char *(*)()) F648_5642;
	R4943[1] = (char *(*)()) F649_5642;
	R4943[2] = (char *(*)()) F650_5642;
	R4943[3] = (char *(*)()) F651_5642;
	R4943[4] = (char *(*)()) F652_5642;
	R4943[5] = (char *(*)()) F653_5642;
	R4943[6] = (char *(*)()) F648_5642;
	R4943[7] = (char *(*)()) F649_5642;
	R4943[8] = (char *(*)()) F648_5642;
	R4943[9] = (char *(*)()) F657_5778;
	R4943[10] = (char *(*)()) F658_5778;
	R4943[11] = (char *(*)()) F659_5778;
	R4943[12] = (char *(*)()) F660_5778;
	R4943[13] = (char *(*)()) F661_5778;
	R4943[14] = (char *(*)()) F662_5778;
	R4943[15] = (char *(*)()) F663_5778;
	R4943[16] = (char *(*)()) F664_5778;
	R4943[17] = (char *(*)()) F665_5778;
	R4943[18] = (char *(*)()) F666_5778;
	R4943[19] = (char *(*)()) F667_5778;
	R4943[20] = (char *(*)()) F668_5778;
	R4943[21] = (char *(*)()) F657_5778;
	R4943[22] = (char *(*)()) F658_5778;
	R4943[23] = (char *(*)()) F664_5778;
	R4943[28] = (char *(*)()) F672_5814;
	R4943[29] = (char *(*)()) F673_5814;
	{long i; for (i = 30; i < 34; i++) R4943[i] = (char *(*)()) F672_5814;}
	R4943[38] = (char *(*)()) F672_5814;
	R4943[40] = (char *(*)()) F672_5814;
	R4943[44] = (char *(*)()) F672_5814;
	{long i; for (i = 46; i < 48; i++) R4943[i] = (char *(*)()) F672_5814;}
	{long i; for (i = 49; i < 52; i++) R4943[i] = (char *(*)()) F672_5814;}
	R4943[403] = (char *(*)()) F1051_9259;
	R4943[406] = (char *(*)()) F1054_9424;
	{long i; for (i = 485; i < 488; i++) R4943[i] = (char *(*)()) F1125_10165;}
	{long i; for (i = 488; i < 490; i++) R4943[i] = (char *(*)()) F1136_10351;}
	{long i; for (i = 491; i < 493; i++) R4943[i] = (char *(*)()) F1136_10351;}
	{long i; for (i = 496; i < 499; i++) R4943[i] = (char *(*)()) F1136_10351;}
	R4943[500] = (char *(*)()) F1136_10351;
	R4943[528] = (char *(*)()) F1125_10165;
	R4943[538] = (char *(*)()) F1125_10165;
}

char *(*R4946[611])();
void R4946_init () {
	R4946[0] = (char *(*)()) F576_5302_4946_5;
	R4946[2] = (char *(*)()) F578_5350_4946_5;
	R4946[3] = (char *(*)()) F579_5350_4946_5;
	R4946[4] = (char *(*)()) F580_5350_4946_5;
	R4946[5] = (char *(*)()) F581_5350_4946_5;
	R4946[6] = (char *(*)()) F582_5350_4946_5;
	R4946[7] = (char *(*)()) F583_5350_4946_5;
	R4946[8] = (char *(*)()) F584_5350_4946_5;
	R4946[9] = (char *(*)()) F585_5350_4946_5;
	R4946[10] = (char *(*)()) F586_5350_4946_5;
	R4946[11] = (char *(*)()) F587_5350_4946_5;
	R4946[12] = (char *(*)()) F588_5350_4946_5;
	R4946[13] = (char *(*)()) F589_5350_4946_5;
	R4946[63] = (char *(*)()) F591_5429_4946_5;
	R4946[64] = (char *(*)()) F592_5429_4946_5;
	R4946[65] = (char *(*)()) F598_5429_4946_5;
	R4946[66] = (char *(*)()) F591_5429_4946_5;
	R4946[67] = (char *(*)()) F598_5429_4946_5;
	R4946[68] = (char *(*)()) F592_5429_4946_5;
	R4946[69] = (char *(*)()) F591_5429_4946_5;
	R4946[72] = (char *(*)()) F648_5593;
	R4946[73] = (char *(*)()) F649_5593_4946_5;
	R4946[74] = (char *(*)()) F650_5593_4946_5;
	R4946[75] = (char *(*)()) F651_5593_4946_5;
	R4946[76] = (char *(*)()) F652_5593_4946_5;
	R4946[77] = (char *(*)()) F653_5593_4946_5;
	R4946[78] = (char *(*)()) F648_5593;
	R4946[79] = (char *(*)()) F649_5593_4946_5;
	R4946[80] = (char *(*)()) F648_5593;
	R4946[81] = (char *(*)()) F657_5725_4946_5;
	R4946[82] = (char *(*)()) F658_5725_4946_5;
	R4946[83] = (char *(*)()) F659_5725_4946_5;
	R4946[84] = (char *(*)()) F660_5725_4946_5;
	R4946[85] = (char *(*)()) F661_5725_4946_5;
	R4946[86] = (char *(*)()) F662_5725_4946_5;
	R4946[87] = (char *(*)()) F663_5725_4946_5;
	R4946[88] = (char *(*)()) F664_5725_4946_5;
	R4946[89] = (char *(*)()) F665_5725_4946_5;
	R4946[90] = (char *(*)()) F666_5725_4946_5;
	R4946[91] = (char *(*)()) F667_5725_4946_5;
	R4946[92] = (char *(*)()) F668_5725_4946_5;
	R4946[93] = (char *(*)()) F657_5725_4946_5;
	R4946[94] = (char *(*)()) F658_5725_4946_5;
	R4946[95] = (char *(*)()) F664_5725_4946_5;
	R4946[100] = (char *(*)()) F657_5725_4946_5;
	R4946[101] = (char *(*)()) F658_5725_4946_5;
	{long i; for (i = 102; i < 106; i++) R4946[i] = (char *(*)()) F657_5725_4946_5;}
	R4946[110] = (char *(*)()) F657_5725_4946_5;
	R4946[112] = (char *(*)()) F657_5725_4946_5;
	R4946[116] = (char *(*)()) F657_5725_4946_5;
	{long i; for (i = 118; i < 120; i++) R4946[i] = (char *(*)()) F657_5725_4946_5;}
	{long i; for (i = 121; i < 124; i++) R4946[i] = (char *(*)()) F657_5725_4946_5;}
	R4946[475] = (char *(*)()) F1051_9197_4946_5;
	R4946[478] = (char *(*)()) F1054_9361_4946_5;
	{long i; for (i = 557; i < 560; i++) R4946[i] = (char *(*)()) F1125_10137_4946_5;}
	R4946[600] = (char *(*)()) F1125_10137_4946_5;
	R4946[610] = (char *(*)()) F1125_10137_4946_5;
}
static EIF_REFERENCE F576_5302_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F576_5302(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F578_5350_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F578_5350(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F579_5350_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F579_5350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_5350_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F580_5350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F581_5350_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F581_5350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F582_5350_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F582_5350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F583_5350_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F583_5350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F584_5350_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F584_5350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F585_5350_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F585_5350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F586_5350_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F586_5350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_5350_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F587_5350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_5350_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F588_5350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_5350_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F589_5350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F591_5429_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F591_5429(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F592_5429_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F592_5429(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F598_5429_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F598_5429(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F649_5593_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F649_5593(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F650_5593_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F650_5593(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F651_5593_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5593(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5593_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F652_5593(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F653_5593_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F653_5593(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F657_5725_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F657_5725(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F658_5725_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5725(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5725_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F659_5725(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5725_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F660_5725(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_5725_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F661_5725(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_5725_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F662_5725(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_5725_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F663_5725(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5725_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F664_5725(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5725_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F665_5725(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5725_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F666_5725(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5725_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F667_5725(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5725_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F668_5725(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1051_9197_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1051_9197(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1054_9361_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1054_9361(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1125_10137_4946_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1125_10137(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4947[609])();
void R4947_init () {
	R4947[0] = (char *(*)()) F578_5351_4947_5;
	R4947[1] = (char *(*)()) F579_5351_4947_5;
	R4947[2] = (char *(*)()) F580_5351_4947_5;
	R4947[3] = (char *(*)()) F581_5351_4947_5;
	R4947[4] = (char *(*)()) F582_5351_4947_5;
	R4947[5] = (char *(*)()) F583_5351_4947_5;
	R4947[6] = (char *(*)()) F584_5351_4947_5;
	R4947[7] = (char *(*)()) F585_5351_4947_5;
	R4947[8] = (char *(*)()) F586_5351_4947_5;
	R4947[9] = (char *(*)()) F587_5351_4947_5;
	R4947[10] = (char *(*)()) F588_5351_4947_5;
	R4947[11] = (char *(*)()) F589_5351_4947_5;
	R4947[61] = (char *(*)()) F591_5430_4947_5;
	R4947[62] = (char *(*)()) F592_5430_4947_5;
	R4947[63] = (char *(*)()) F598_5430_4947_5;
	R4947[64] = (char *(*)()) F591_5430_4947_5;
	R4947[65] = (char *(*)()) F598_5430_4947_5;
	R4947[66] = (char *(*)()) F592_5430_4947_5;
	R4947[67] = (char *(*)()) F591_5430_4947_5;
	R4947[70] = (char *(*)()) F648_5593;
	R4947[71] = (char *(*)()) F649_5593_4947_5;
	R4947[72] = (char *(*)()) F650_5593_4947_5;
	R4947[73] = (char *(*)()) F651_5593_4947_5;
	R4947[74] = (char *(*)()) F652_5593_4947_5;
	R4947[75] = (char *(*)()) F653_5593_4947_5;
	R4947[76] = (char *(*)()) F648_5593;
	R4947[77] = (char *(*)()) F649_5593_4947_5;
	R4947[78] = (char *(*)()) F648_5593;
	R4947[79] = (char *(*)()) F657_5726_4947_5;
	R4947[80] = (char *(*)()) F658_5726_4947_5;
	R4947[81] = (char *(*)()) F659_5726_4947_5;
	R4947[82] = (char *(*)()) F660_5726_4947_5;
	R4947[83] = (char *(*)()) F661_5726_4947_5;
	R4947[84] = (char *(*)()) F662_5726_4947_5;
	R4947[85] = (char *(*)()) F663_5726_4947_5;
	R4947[86] = (char *(*)()) F664_5726_4947_5;
	R4947[87] = (char *(*)()) F665_5726_4947_5;
	R4947[88] = (char *(*)()) F666_5726_4947_5;
	R4947[89] = (char *(*)()) F667_5726_4947_5;
	R4947[90] = (char *(*)()) F668_5726_4947_5;
	R4947[91] = (char *(*)()) F657_5726_4947_5;
	R4947[92] = (char *(*)()) F658_5726_4947_5;
	R4947[93] = (char *(*)()) F664_5726_4947_5;
	R4947[98] = (char *(*)()) F657_5726_4947_5;
	R4947[99] = (char *(*)()) F658_5726_4947_5;
	{long i; for (i = 100; i < 104; i++) R4947[i] = (char *(*)()) F657_5726_4947_5;}
	R4947[108] = (char *(*)()) F657_5726_4947_5;
	R4947[110] = (char *(*)()) F657_5726_4947_5;
	R4947[114] = (char *(*)()) F657_5726_4947_5;
	{long i; for (i = 116; i < 118; i++) R4947[i] = (char *(*)()) F657_5726_4947_5;}
	{long i; for (i = 119; i < 122; i++) R4947[i] = (char *(*)()) F657_5726_4947_5;}
	R4947[473] = (char *(*)()) F1051_9198_4947_5;
	{long i; for (i = 555; i < 558; i++) R4947[i] = (char *(*)()) F591_5430_4947_5;}
	R4947[598] = (char *(*)()) F591_5430_4947_5;
	R4947[608] = (char *(*)()) F591_5430_4947_5;
}
static EIF_REFERENCE F578_5351_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F578_5351(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F579_5351_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F579_5351(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_5351_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F580_5351(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F581_5351_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F581_5351(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F582_5351_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F582_5351(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F583_5351_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F583_5351(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F584_5351_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F584_5351(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F585_5351_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F585_5351(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F586_5351_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F586_5351(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_5351_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F587_5351(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_5351_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F588_5351(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_5351_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F589_5351(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F591_5430_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F591_5430(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F592_5430_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F592_5430(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F598_5430_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F598_5430(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F649_5593_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F649_5593(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F650_5593_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F650_5593(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F651_5593_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5593(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5593_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F652_5593(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F653_5593_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F653_5593(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F657_5726_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F657_5726(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F658_5726_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5726(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5726_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F659_5726(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5726_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F660_5726(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_5726_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F661_5726(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_5726_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F662_5726(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_5726_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F663_5726(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5726_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F664_5726(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5726_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F665_5726(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5726_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F666_5726(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5726_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F667_5726(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5726_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F668_5726(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1051_9198_4947_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1051_9198(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R4948[611])();
void R4948_init () {
	R4948[0] = (char *(*)()) F576_5305_4948_2;
	R4948[2] = (char *(*)()) F578_5365_4948_2;
	R4948[3] = (char *(*)()) F579_5365_4948_2;
	R4948[4] = (char *(*)()) F580_5365_4948_2;
	R4948[5] = (char *(*)()) F581_5365_4948_2;
	R4948[6] = (char *(*)()) F582_5365_4948_2;
	R4948[7] = (char *(*)()) F583_5365_4948_2;
	R4948[8] = (char *(*)()) F584_5365_4948_2;
	R4948[9] = (char *(*)()) F585_5365_4948_2;
	R4948[10] = (char *(*)()) F586_5365_4948_2;
	R4948[11] = (char *(*)()) F587_5365_4948_2;
	R4948[12] = (char *(*)()) F588_5365_4948_2;
	R4948[13] = (char *(*)()) F589_5365_4948_2;
	R4948[63] = (char *(*)()) F591_5437_4948_2;
	R4948[64] = (char *(*)()) F592_5437_4948_2;
	R4948[65] = (char *(*)()) F598_5437_4948_2;
	R4948[66] = (char *(*)()) F591_5437_4948_2;
	R4948[67] = (char *(*)()) F598_5437_4948_2;
	R4948[68] = (char *(*)()) F592_5437_4948_2;
	R4948[69] = (char *(*)()) F591_5437_4948_2;
	R4948[72] = (char *(*)()) F648_5596;
	R4948[73] = (char *(*)()) F649_5596;
	R4948[74] = (char *(*)()) F650_5596_4948_2;
	R4948[75] = (char *(*)()) F651_5596_4948_2;
	R4948[76] = (char *(*)()) F652_5596_4948_2;
	R4948[77] = (char *(*)()) F653_5596;
	R4948[78] = (char *(*)()) F648_5596;
	R4948[79] = (char *(*)()) F649_5596;
	R4948[80] = (char *(*)()) F648_5596;
	R4948[81] = (char *(*)()) F657_5746_4948_2;
	R4948[82] = (char *(*)()) F658_5746_4948_2;
	R4948[83] = (char *(*)()) F659_5746_4948_2;
	R4948[84] = (char *(*)()) F660_5746_4948_2;
	R4948[85] = (char *(*)()) F661_5746_4948_2;
	R4948[86] = (char *(*)()) F662_5746_4948_2;
	R4948[87] = (char *(*)()) F663_5746_4948_2;
	R4948[88] = (char *(*)()) F664_5746_4948_2;
	R4948[89] = (char *(*)()) F665_5746_4948_2;
	R4948[90] = (char *(*)()) F666_5746_4948_2;
	R4948[91] = (char *(*)()) F667_5746_4948_2;
	R4948[92] = (char *(*)()) F668_5746_4948_2;
	R4948[93] = (char *(*)()) F657_5746_4948_2;
	R4948[94] = (char *(*)()) F658_5746_4948_2;
	R4948[95] = (char *(*)()) F664_5746_4948_2;
	R4948[100] = (char *(*)()) F657_5746_4948_2;
	R4948[101] = (char *(*)()) F658_5746_4948_2;
	{long i; for (i = 102; i < 106; i++) R4948[i] = (char *(*)()) F657_5746_4948_2;}
	R4948[110] = (char *(*)()) F657_5746_4948_2;
	R4948[112] = (char *(*)()) F657_5746_4948_2;
	R4948[116] = (char *(*)()) F657_5746_4948_2;
	{long i; for (i = 118; i < 120; i++) R4948[i] = (char *(*)()) F657_5746_4948_2;}
	{long i; for (i = 121; i < 124; i++) R4948[i] = (char *(*)()) F657_5746_4948_2;}
	R4948[475] = (char *(*)()) F1046_8997_4948_2;
	R4948[478] = (char *(*)()) F1046_8997_4948_2;
	{long i; for (i = 557; i < 560; i++) R4948[i] = (char *(*)()) F591_5437_4948_2;}
	R4948[600] = (char *(*)()) F591_5437_4948_2;
	R4948[610] = (char *(*)()) F591_5437_4948_2;
}
static EIF_BOOLEAN F576_5305_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F576_5305(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F578_5365_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F578_5365(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F579_5365_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F579_5365(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F580_5365_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F580_5365(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F581_5365_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F581_5365(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F582_5365_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F582_5365(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F583_5365_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F583_5365(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F584_5365_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F584_5365(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F585_5365_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F585_5365(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F586_5365_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F586_5365(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F587_5365_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F587_5365(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F588_5365_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F588_5365(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F589_5365_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F589_5365(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F591_5437_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F591_5437(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F592_5437_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F592_5437(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F598_5437_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F598_5437(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F650_5596_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F650_5596(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F651_5596_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F651_5596(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F652_5596_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F652_5596(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F657_5746_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F657_5746(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F658_5746_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F658_5746(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F659_5746_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F659_5746(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F660_5746_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F660_5746(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F661_5746_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F661_5746(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F662_5746_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F662_5746(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F663_5746_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F663_5746(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F664_5746_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F664_5746(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F665_5746_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F665_5746(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F666_5746_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F666_5746(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F667_5746_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F667_5746(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F668_5746_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F668_5746(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1046_8997_4948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1046_8997(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4949[477])();
void R4949_init () {
	R4949[0] = (char *(*)()) F578_5369_4949_14;
	R4949[1] = (char *(*)()) F579_5369_4949_14;
	R4949[2] = (char *(*)()) F580_5369_4949_14;
	R4949[3] = (char *(*)()) F581_5369_4949_14;
	R4949[4] = (char *(*)()) F582_5369_4949_14;
	R4949[5] = (char *(*)()) F583_5369_4949_14;
	R4949[6] = (char *(*)()) F584_5369_4949_14;
	R4949[7] = (char *(*)()) F585_5369_4949_14;
	R4949[8] = (char *(*)()) F586_5369_4949_14;
	R4949[9] = (char *(*)()) F587_5369_4949_14;
	R4949[10] = (char *(*)()) F588_5369_4949_14;
	R4949[11] = (char *(*)()) F589_5369_4949_14;
	R4949[70] = (char *(*)()) F648_5634;
	R4949[71] = (char *(*)()) F649_5634_4949_14;
	R4949[72] = (char *(*)()) F650_5634_4949_14;
	R4949[73] = (char *(*)()) F651_5634_4949_14;
	R4949[74] = (char *(*)()) F652_5634_4949_14;
	R4949[75] = (char *(*)()) F653_5634_4949_14;
	R4949[76] = (char *(*)()) F648_5634;
	R4949[77] = (char *(*)()) F649_5634_4949_14;
	R4949[78] = (char *(*)()) F648_5634;
	R4949[79] = (char *(*)()) F657_5758_4949_14;
	R4949[80] = (char *(*)()) F658_5758_4949_14;
	R4949[81] = (char *(*)()) F659_5758_4949_14;
	R4949[82] = (char *(*)()) F660_5758_4949_14;
	R4949[83] = (char *(*)()) F661_5758_4949_14;
	R4949[84] = (char *(*)()) F662_5758_4949_14;
	R4949[85] = (char *(*)()) F663_5758_4949_14;
	R4949[86] = (char *(*)()) F664_5758_4949_14;
	R4949[87] = (char *(*)()) F665_5758_4949_14;
	R4949[88] = (char *(*)()) F666_5758_4949_14;
	R4949[89] = (char *(*)()) F667_5758_4949_14;
	R4949[90] = (char *(*)()) F668_5758_4949_14;
	R4949[91] = (char *(*)()) F657_5758_4949_14;
	R4949[92] = (char *(*)()) F658_5758_4949_14;
	R4949[93] = (char *(*)()) F664_5758_4949_14;
	R4949[98] = (char *(*)()) F672_5806_4949_14;
	R4949[99] = (char *(*)()) F673_5806_4949_14;
	{long i; for (i = 100; i < 104; i++) R4949[i] = (char *(*)()) F672_5806_4949_14;}
	R4949[108] = (char *(*)()) F672_5806_4949_14;
	R4949[110] = (char *(*)()) F672_5806_4949_14;
	R4949[114] = (char *(*)()) F672_5806_4949_14;
	{long i; for (i = 116; i < 118; i++) R4949[i] = (char *(*)()) F672_5806_4949_14;}
	{long i; for (i = 119; i < 122; i++) R4949[i] = (char *(*)()) F672_5806_4949_14;}
	R4949[473] = (char *(*)()) F1051_9217_4949_14;
	R4949[476] = (char *(*)()) F1054_9382_4949_14;
}
static void F578_5369_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F578_5369(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F579_5369_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F579_5369(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F580_5369_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F580_5369(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F581_5369_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F581_5369(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F582_5369_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F582_5369(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F583_5369_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F583_5369(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F584_5369_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F584_5369(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F585_5369_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F585_5369(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F586_5369_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F586_5369(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F587_5369_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F587_5369(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F588_5369_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F588_5369(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F589_5369_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F589_5369(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F649_5634_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F649_5634(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F650_5634_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F650_5634(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F651_5634_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F651_5634(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F652_5634_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F652_5634(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static void F653_5634_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F653_5634(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F657_5758_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F657_5758(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F658_5758_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F658_5758(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F659_5758_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F659_5758(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F660_5758_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F660_5758(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F661_5758_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F661_5758(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F662_5758_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F662_5758(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F663_5758_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F663_5758(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F664_5758_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F664_5758(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F665_5758_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F665_5758(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F666_5758_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F666_5758(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F667_5758_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F667_5758(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F668_5758_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F668_5758(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F672_5806_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F672_5806(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F673_5806_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F673_5806(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1051_9217_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1051_9217(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1054_9382_4949_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1054_9382(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R4950[477])();
void R4950_init () {
	R4950[0] = (char *(*)()) F578_5369_4950_14;
	R4950[1] = (char *(*)()) F579_5369_4950_14;
	R4950[2] = (char *(*)()) F580_5369_4950_14;
	R4950[3] = (char *(*)()) F581_5369_4950_14;
	R4950[4] = (char *(*)()) F582_5369_4950_14;
	R4950[5] = (char *(*)()) F583_5369_4950_14;
	R4950[6] = (char *(*)()) F584_5369_4950_14;
	R4950[7] = (char *(*)()) F585_5369_4950_14;
	R4950[8] = (char *(*)()) F586_5369_4950_14;
	R4950[9] = (char *(*)()) F587_5369_4950_14;
	R4950[10] = (char *(*)()) F588_5369_4950_14;
	R4950[11] = (char *(*)()) F589_5369_4950_14;
	R4950[70] = (char *(*)()) F648_5635;
	R4950[71] = (char *(*)()) F649_5635_4950_14;
	R4950[72] = (char *(*)()) F650_5635_4950_14;
	R4950[73] = (char *(*)()) F651_5635_4950_14;
	R4950[74] = (char *(*)()) F652_5635_4950_14;
	R4950[75] = (char *(*)()) F653_5635_4950_14;
	R4950[76] = (char *(*)()) F648_5635;
	R4950[77] = (char *(*)()) F649_5635_4950_14;
	R4950[78] = (char *(*)()) F648_5635;
	R4950[79] = (char *(*)()) F657_5758_4950_14;
	R4950[80] = (char *(*)()) F658_5758_4950_14;
	R4950[81] = (char *(*)()) F659_5758_4950_14;
	R4950[82] = (char *(*)()) F660_5758_4950_14;
	R4950[83] = (char *(*)()) F661_5758_4950_14;
	R4950[84] = (char *(*)()) F662_5758_4950_14;
	R4950[85] = (char *(*)()) F663_5758_4950_14;
	R4950[86] = (char *(*)()) F664_5758_4950_14;
	R4950[87] = (char *(*)()) F665_5758_4950_14;
	R4950[88] = (char *(*)()) F666_5758_4950_14;
	R4950[89] = (char *(*)()) F667_5758_4950_14;
	R4950[90] = (char *(*)()) F668_5758_4950_14;
	R4950[91] = (char *(*)()) F657_5758_4950_14;
	R4950[92] = (char *(*)()) F658_5758_4950_14;
	R4950[93] = (char *(*)()) F664_5758_4950_14;
	R4950[98] = (char *(*)()) F672_5806_4950_14;
	R4950[99] = (char *(*)()) F673_5806_4950_14;
	{long i; for (i = 100; i < 104; i++) R4950[i] = (char *(*)()) F672_5806_4950_14;}
	R4950[108] = (char *(*)()) F672_5806_4950_14;
	R4950[110] = (char *(*)()) F672_5806_4950_14;
	R4950[114] = (char *(*)()) F672_5806_4950_14;
	{long i; for (i = 116; i < 118; i++) R4950[i] = (char *(*)()) F672_5806_4950_14;}
	{long i; for (i = 119; i < 122; i++) R4950[i] = (char *(*)()) F672_5806_4950_14;}
	R4950[473] = (char *(*)()) F1051_9217_4950_14;
	R4950[476] = (char *(*)()) F1054_9382_4950_14;
}
static void F578_5369_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F578_5369(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F579_5369_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F579_5369(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F580_5369_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F580_5369(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F581_5369_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F581_5369(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F582_5369_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F582_5369(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F583_5369_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F583_5369(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F584_5369_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F584_5369(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F585_5369_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F585_5369(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F586_5369_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F586_5369(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F587_5369_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F587_5369(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F588_5369_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F588_5369(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F589_5369_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F589_5369(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F649_5635_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F649_5635(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F650_5635_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F650_5635(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F651_5635_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F651_5635(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F652_5635_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F652_5635(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static void F653_5635_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F653_5635(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F657_5758_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F657_5758(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F658_5758_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F658_5758(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F659_5758_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F659_5758(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F660_5758_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F660_5758(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F661_5758_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F661_5758(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F662_5758_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F662_5758(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F663_5758_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F663_5758(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F664_5758_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F664_5758(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F665_5758_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F665_5758(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F666_5758_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F666_5758(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F667_5758_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F667_5758(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F668_5758_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F668_5758(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F672_5806_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F672_5806(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F673_5806_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F673_5806(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1051_9217_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1051_9217(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1054_9382_4950_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1054_9382(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y4951_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype32[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype33[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype34[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype35[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype36[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype37[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype38[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype39[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype40[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype41[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype42[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype43[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype44[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype45[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype46[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype47[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype48[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype49[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype50[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype51[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype52[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype53[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype54[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype55[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype56[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype57[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype58[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype59[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype60[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype61[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype62[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype63[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype64[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype65[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype66[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype67[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype68[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype69[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype70[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype71[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype72[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype73[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype74[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype75[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype76[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype77[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype78[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype79[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype80[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype81[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype82[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype83[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype84[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype85[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype86[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype87[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype88[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype89[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype90[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype91[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype92[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype93[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype94[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype95[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype96[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype97[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype98[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype99[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype100[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype101[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype102[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype103[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype104[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype105[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype106[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype107[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype108[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype109[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype110[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype111[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype112[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype113[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype114[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype115[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype116[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype117[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype118[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype119[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype120[] = {0xFF01,1045,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype121[] = {0xFF01,1045,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype122[] = {0xFF01,1053,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype123[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype124[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype125[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype126[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype127[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype128[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype129[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype130[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype131[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype132[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype133[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype134[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype135[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype136[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype137[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype138[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype139[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype140[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype141[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype142[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype143[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype144[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype145[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype146[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype147[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype148[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype149[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype150[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype151[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype152[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype153[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype154[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype155[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype156[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype157[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype158[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype159[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype160[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype161[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype162[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype163[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype164[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype165[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype166[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype167[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype168[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype169[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype170[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype171[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype172[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype173[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype174[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype175[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype176[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype177[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype178[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype179[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype180[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype181[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype182[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype183[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype184[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype185[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype186[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype187[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype188[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype189[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4951_pgtype190[] = {984,0xFFFF};
EIF_TYPE_INDEX *Y4951_gen_type [775];
EIF_TYPE_INDEX Y4951 [775];
void Y4951_init (void)
{
	egc_routines_types [4951] = Y4951;
	egc_routines_gen_types [4951] = Y4951_gen_type;
	egc_routines_offset [4951] = 411;
	Y4951_gen_type [0] = Y4951_pgtype0;
	Y4951_gen_type [1] = Y4951_pgtype1;
	Y4951_gen_type [2] = Y4951_pgtype2;
	Y4951_gen_type [3] = Y4951_pgtype3;
	Y4951_gen_type [4] = Y4951_pgtype4;
	Y4951_gen_type [5] = Y4951_pgtype5;
	Y4951_gen_type [6] = Y4951_pgtype6;
	Y4951_gen_type [7] = Y4951_pgtype7;
	Y4951_gen_type [8] = Y4951_pgtype8;
	Y4951_gen_type [9] = Y4951_pgtype9;
	Y4951_gen_type [10] = Y4951_pgtype10;
	Y4951_gen_type [11] = Y4951_pgtype11;
	Y4951_gen_type [12] = Y4951_pgtype12;
	Y4951_gen_type [13] = Y4951_pgtype13;
	Y4951_gen_type [14] = Y4951_pgtype14;
	Y4951_gen_type [15] = Y4951_pgtype15;
	Y4951_gen_type [16] = Y4951_pgtype16;
	Y4951_gen_type [17] = Y4951_pgtype17;
	Y4951_gen_type [18] = Y4951_pgtype18;
	Y4951_gen_type [19] = Y4951_pgtype19;
	Y4951_gen_type [20] = Y4951_pgtype20;
	Y4951_gen_type [21] = Y4951_pgtype21;
	Y4951_gen_type [22] = Y4951_pgtype22;
	Y4951_gen_type [23] = Y4951_pgtype23;
	Y4951_gen_type [24] = Y4951_pgtype24;
	Y4951_gen_type [25] = Y4951_pgtype25;
	Y4951_gen_type [26] = Y4951_pgtype26;
	Y4951_gen_type [27] = Y4951_pgtype27;
	Y4951_gen_type [28] = Y4951_pgtype28;
	Y4951_gen_type [29] = Y4951_pgtype29;
	Y4951_gen_type [30] = Y4951_pgtype30;
	Y4951_gen_type [31] = Y4951_pgtype31;
	Y4951_gen_type [152] = Y4951_pgtype32;
	Y4951_gen_type [153] = Y4951_pgtype33;
	Y4951_gen_type [154] = Y4951_pgtype34;
	Y4951_gen_type [155] = Y4951_pgtype35;
	Y4951_gen_type [156] = Y4951_pgtype36;
	Y4951_gen_type [157] = Y4951_pgtype37;
	Y4951_gen_type [158] = Y4951_pgtype38;
	Y4951_gen_type [159] = Y4951_pgtype39;
	Y4951_gen_type [160] = Y4951_pgtype40;
	Y4951_gen_type [161] = Y4951_pgtype41;
	Y4951_gen_type [162] = Y4951_pgtype42;
	Y4951_gen_type [163] = Y4951_pgtype43;
	Y4951_gen_type [164] = Y4951_pgtype44;
	Y4951_gen_type [165] = Y4951_pgtype45;
	Y4951_gen_type [166] = Y4951_pgtype46;
	Y4951_gen_type [167] = Y4951_pgtype47;
	Y4951_gen_type [168] = Y4951_pgtype48;
	Y4951_gen_type [169] = Y4951_pgtype49;
	Y4951_gen_type [170] = Y4951_pgtype50;
	Y4951_gen_type [171] = Y4951_pgtype51;
	Y4951_gen_type [172] = Y4951_pgtype52;
	Y4951_gen_type [173] = Y4951_pgtype53;
	Y4951_gen_type [174] = Y4951_pgtype54;
	Y4951_gen_type [175] = Y4951_pgtype55;
	Y4951_gen_type [176] = Y4951_pgtype56;
	Y4951_gen_type [177] = Y4951_pgtype57;
	Y4951_gen_type [178] = Y4951_pgtype58;
	Y4951_gen_type [179] = Y4951_pgtype59;
	Y4951_gen_type [180] = Y4951_pgtype60;
	Y4951_gen_type [181] = Y4951_pgtype61;
	Y4951_gen_type [182] = Y4951_pgtype62;
	Y4951_gen_type [183] = Y4951_pgtype63;
	Y4951_gen_type [184] = Y4951_pgtype64;
	Y4951_gen_type [185] = Y4951_pgtype65;
	Y4951_gen_type [186] = Y4951_pgtype66;
	Y4951_gen_type [187] = Y4951_pgtype67;
	Y4951_gen_type [188] = Y4951_pgtype68;
	Y4951_gen_type [189] = Y4951_pgtype69;
	Y4951_gen_type [190] = Y4951_pgtype70;
	Y4951_gen_type [191] = Y4951_pgtype71;
	Y4951_gen_type [192] = Y4951_pgtype72;
	Y4951_gen_type [193] = Y4951_pgtype73;
	Y4951_gen_type [194] = Y4951_pgtype74;
	Y4951_gen_type [195] = Y4951_pgtype75;
	Y4951_gen_type [196] = Y4951_pgtype76;
	Y4951_gen_type [197] = Y4951_pgtype77;
	Y4951_gen_type [198] = Y4951_pgtype78;
	Y4951_gen_type [199] = Y4951_pgtype79;
	Y4951_gen_type [200] = Y4951_pgtype80;
	Y4951_gen_type [201] = Y4951_pgtype81;
	Y4951_gen_type [202] = Y4951_pgtype82;
	Y4951_gen_type [203] = Y4951_pgtype83;
	Y4951_gen_type [204] = Y4951_pgtype84;
	Y4951_gen_type [205] = Y4951_pgtype85;
	Y4951_gen_type [206] = Y4951_pgtype86;
	Y4951_gen_type [207] = Y4951_pgtype87;
	Y4951_gen_type [208] = Y4951_pgtype88;
	Y4951_gen_type [209] = Y4951_pgtype89;
	Y4951_gen_type [210] = Y4951_pgtype90;
	Y4951_gen_type [211] = Y4951_pgtype91;
	Y4951_gen_type [212] = Y4951_pgtype92;
	Y4951_gen_type [213] = Y4951_pgtype93;
	Y4951_gen_type [214] = Y4951_pgtype94;
	Y4951_gen_type [215] = Y4951_pgtype95;
	Y4951_gen_type [216] = Y4951_pgtype96;
	Y4951_gen_type [217] = Y4951_pgtype97;
	Y4951_gen_type [218] = Y4951_pgtype98;
	Y4951_gen_type [219] = Y4951_pgtype99;
	Y4951_gen_type [220] = Y4951_pgtype100;
	Y4951_gen_type [221] = Y4951_pgtype101;
	Y4951_gen_type [222] = Y4951_pgtype102;
	Y4951_gen_type [223] = Y4951_pgtype103;
	Y4951_gen_type [224] = Y4951_pgtype104;
	Y4951_gen_type [225] = Y4951_pgtype105;
	Y4951_gen_type [226] = Y4951_pgtype106;
	Y4951_gen_type [227] = Y4951_pgtype107;
	Y4951_gen_type [228] = Y4951_pgtype108;
	Y4951_gen_type [229] = Y4951_pgtype109;
	Y4951_gen_type [230] = Y4951_pgtype110;
	Y4951_gen_type [231] = Y4951_pgtype111;
	Y4951_gen_type [232] = Y4951_pgtype112;
	Y4951_gen_type [233] = Y4951_pgtype113;
	Y4951_gen_type [236] = Y4951_pgtype114;
	Y4951_gen_type [237] = Y4951_pgtype115;
	Y4951_gen_type [238] = Y4951_pgtype116;
	Y4951_gen_type [239] = Y4951_pgtype117;
	Y4951_gen_type [240] = Y4951_pgtype118;
	Y4951_gen_type [241] = Y4951_pgtype119;
	Y4951_gen_type [242] = Y4951_pgtype120;
	Y4951_gen_type [243] = Y4951_pgtype121;
	Y4951_gen_type [244] = Y4951_pgtype122;
	Y4951_gen_type [245] = Y4951_pgtype123;
	Y4951_gen_type [246] = Y4951_pgtype124;
	Y4951_gen_type [247] = Y4951_pgtype125;
	Y4951_gen_type [248] = Y4951_pgtype126;
	Y4951_gen_type [249] = Y4951_pgtype127;
	Y4951_gen_type [250] = Y4951_pgtype128;
	Y4951_gen_type [251] = Y4951_pgtype129;
	Y4951_gen_type [252] = Y4951_pgtype130;
	Y4951_gen_type [253] = Y4951_pgtype131;
	Y4951_gen_type [254] = Y4951_pgtype132;
	Y4951_gen_type [255] = Y4951_pgtype133;
	Y4951_gen_type [256] = Y4951_pgtype134;
	Y4951_gen_type [257] = Y4951_pgtype135;
	Y4951_gen_type [258] = Y4951_pgtype136;
	Y4951_gen_type [259] = Y4951_pgtype137;
	Y4951_gen_type [260] = Y4951_pgtype138;
	Y4951_gen_type [261] = Y4951_pgtype139;
	Y4951_gen_type [262] = Y4951_pgtype140;
	Y4951_gen_type [263] = Y4951_pgtype141;
	Y4951_gen_type [264] = Y4951_pgtype142;
	Y4951_gen_type [265] = Y4951_pgtype143;
	Y4951_gen_type [266] = Y4951_pgtype144;
	Y4951_gen_type [267] = Y4951_pgtype145;
	Y4951_gen_type [268] = Y4951_pgtype146;
	Y4951_gen_type [269] = Y4951_pgtype147;
	Y4951_gen_type [270] = Y4951_pgtype148;
	Y4951_gen_type [271] = Y4951_pgtype149;
	Y4951_gen_type [272] = Y4951_pgtype150;
	Y4951_gen_type [273] = Y4951_pgtype151;
	Y4951_gen_type [274] = Y4951_pgtype152;
	Y4951_gen_type [275] = Y4951_pgtype153;
	Y4951_gen_type [276] = Y4951_pgtype154;
	Y4951_gen_type [277] = Y4951_pgtype155;
	Y4951_gen_type [278] = Y4951_pgtype156;
	Y4951_gen_type [279] = Y4951_pgtype157;
	Y4951_gen_type [280] = Y4951_pgtype158;
	Y4951_gen_type [281] = Y4951_pgtype159;
	Y4951_gen_type [282] = Y4951_pgtype160;
	Y4951_gen_type [283] = Y4951_pgtype161;
	Y4951_gen_type [284] = Y4951_pgtype162;
	Y4951_gen_type [285] = Y4951_pgtype163;
	Y4951_gen_type [286] = Y4951_pgtype164;
	Y4951_gen_type [287] = Y4951_pgtype165;
	Y4951_gen_type [639] = Y4951_pgtype166;
	Y4951_gen_type [642] = Y4951_pgtype167;
	Y4951_gen_type [643] = Y4951_pgtype168;
	Y4951_gen_type [713] = Y4951_pgtype169;
	Y4951_gen_type [717] = Y4951_pgtype170;
	Y4951_gen_type [718] = Y4951_pgtype171;
	Y4951_gen_type [719] = Y4951_pgtype172;
	Y4951_gen_type [720] = Y4951_pgtype173;
	Y4951_gen_type [721] = Y4951_pgtype174;
	Y4951_gen_type [722] = Y4951_pgtype175;
	Y4951_gen_type [723] = Y4951_pgtype176;
	Y4951_gen_type [753] = Y4951_pgtype177;
	Y4951_gen_type [762] = Y4951_pgtype178;
	Y4951_gen_type [763] = Y4951_pgtype179;
	Y4951_gen_type [764] = Y4951_pgtype180;
	Y4951_gen_type [765] = Y4951_pgtype181;
	Y4951_gen_type [766] = Y4951_pgtype182;
	Y4951_gen_type [767] = Y4951_pgtype183;
	Y4951_gen_type [768] = Y4951_pgtype184;
	Y4951_gen_type [769] = Y4951_pgtype185;
	Y4951_gen_type [770] = Y4951_pgtype186;
	Y4951_gen_type [771] = Y4951_pgtype187;
	Y4951_gen_type [772] = Y4951_pgtype188;
	Y4951_gen_type [773] = Y4951_pgtype189;
	Y4951_gen_type [774] = Y4951_pgtype190;
	{long i; for (i = 152; i < 234; i++) Y4951[i] = 984;};
	{long i; for (i = 242; i < 244; i++) Y4951[i] = 1045;};
	Y4951[244] = 1053;
	{long i; for (i = 245; i < 288; i++) Y4951[i] = 984;};
	Y4951[639] = 984;
	{long i; for (i = 642; i < 644; i++) Y4951[i] = 984;};
	Y4951[713] = 984;
	{long i; for (i = 717; i < 724; i++) Y4951[i] = 984;};
	Y4951[753] = 984;
	{long i; for (i = 762; i < 775; i++) Y4951[i] = 984;};
}

char *(*R4952[407])();
void R4952_init () {
	R4952[0] = (char *(*)()) F648_5640;
	R4952[1] = (char *(*)()) F649_5640;
	R4952[2] = (char *(*)()) F650_5640_4952_4;
	R4952[3] = (char *(*)()) F651_5640_4952_4;
	R4952[4] = (char *(*)()) F652_5640_4952_4;
	R4952[5] = (char *(*)()) F653_5640;
	R4952[6] = (char *(*)()) F648_5640;
	R4952[7] = (char *(*)()) F649_5640;
	R4952[8] = (char *(*)()) F648_5640;
	R4952[403] = (char *(*)()) F1051_9251_4952_4;
	R4952[406] = (char *(*)()) F1054_9416_4952_4;
}
static void F650_5640_4952_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F650_5640(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F651_5640_4952_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F651_5640(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F652_5640_4952_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F652_5640(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1051_9251_4952_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1051_9251(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1054_9416_4952_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1054_9416(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4953[735])();
void R4953_init () {
	R4953[0] = (char *(*)()) F639_5477;
	R4953[1] = (char *(*)()) F640_5477_4953_1;
	R4953[2] = (char *(*)()) F641_5477_4953_1;
	R4953[3] = (char *(*)()) F642_5522;
	R4953[4] = (char *(*)()) F643_5522_4953_1;
	R4953[5] = (char *(*)()) F644_5522_4953_1;
	R4953[6] = (char *(*)()) F645_5537;
	R4953[18] = (char *(*)()) F657_5724;
	R4953[19] = (char *(*)()) F658_5724_4953_1;
	R4953[20] = (char *(*)()) F659_5724_4953_1;
	R4953[21] = (char *(*)()) F660_5724_4953_1;
	R4953[22] = (char *(*)()) F661_5724_4953_1;
	R4953[23] = (char *(*)()) F662_5724_4953_1;
	R4953[24] = (char *(*)()) F663_5724_4953_1;
	R4953[25] = (char *(*)()) F664_5724_4953_1;
	R4953[26] = (char *(*)()) F665_5724_4953_1;
	R4953[27] = (char *(*)()) F666_5724_4953_1;
	R4953[28] = (char *(*)()) F667_5724_4953_1;
	R4953[29] = (char *(*)()) F668_5724_4953_1;
	R4953[30] = (char *(*)()) F657_5724;
	R4953[31] = (char *(*)()) F658_5724_4953_1;
	R4953[32] = (char *(*)()) F664_5724_4953_1;
	R4953[37] = (char *(*)()) F657_5724;
	R4953[38] = (char *(*)()) F658_5724_4953_1;
	{long i; for (i = 39; i < 43; i++) R4953[i] = (char *(*)()) F657_5724;}
	R4953[47] = (char *(*)()) F657_5724;
	R4953[49] = (char *(*)()) F657_5724;
	R4953[53] = (char *(*)()) F657_5724;
	{long i; for (i = 55; i < 57; i++) R4953[i] = (char *(*)()) F657_5724;}
	{long i; for (i = 58; i < 61; i++) R4953[i] = (char *(*)()) F657_5724;}
	R4953[83] = (char *(*)()) F482_5211_4953_1;
	R4953[88] = (char *(*)()) F482_5211_4953_1;
	{long i; for (i = 281; i < 283; i++) R4953[i] = (char *(*)()) F919_7094_4953_1;}
	{long i; for (i = 494; i < 497; i++) R4953[i] = (char *(*)()) F1125_10134;}
	R4953[537] = (char *(*)()) F1125_10134;
	R4953[547] = (char *(*)()) F1125_10134;
	R4953[734] = (char *(*)()) F919_7094_4953_1;
}
static EIF_REFERENCE F640_5477_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F640_5477(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_5477_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F641_5477(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F643_5522_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F643_5522(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F644_5522_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F644_5522(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_5724_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5724_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F659_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5724_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F660_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_5724_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F661_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_5724_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F662_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_5724_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F663_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5724_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F664_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5724_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F665_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5724_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F666_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5724_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F667_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5724_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F668_5724(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F482_5211_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F482_5211(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F919_7094_4953_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F919_7094(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y4953_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype123[] = {0xFF01,1094,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype124[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype125[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype126[] = {0xFF01,1040,0xFFF9,1,966,0xFF01,0,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype127[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype128[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype129[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype130[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype131[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype132[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype133[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1101,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype134[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,927,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype135[] = {0xFF01,1040,0xFF01,0xFFF9,5,966,996,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype136[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1050,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype137[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1371,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype138[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype139[] = {0xFF01,1040,0xFF01,0xFFF9,4,966,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype140[] = {0xFF01,1040,0xFF01,0xFFF9,7,966,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype141[] = {0xFF01,1040,0xFF01,0xFFF9,2,966,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype142[] = {0xFF01,1040,0xFF01,0xFFF9,3,966,984,984,927,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype143[] = {0xFF01,1040,0xFF01,0xFFF9,8,966,984,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype144[] = {0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype146[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype147[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype148[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype149[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype150[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype151[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype152[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype153[] = {0xFF01,1050,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype155[] = {0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype156[] = {0xFF01,1165,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype157[] = {0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype158[] = {0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype159[] = {0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype160[] = {0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype161[] = {0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype162[] = {0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype163[] = {0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype164[] = {0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype165[] = {0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4953_pgtype166[] = {0xFF01,1169,0xFFFF};
EIF_TYPE_INDEX *Y4953_gen_type [930];
EIF_TYPE_INDEX Y4953 [930];
void Y4953_init (void)
{
	egc_routines_types [4953] = Y4953;
	egc_routines_gen_types [4953] = Y4953_gen_type;
	egc_routines_offset [4953] = 443;
	Y4953_gen_type [0] = Y4953_pgtype0;
	Y4953_gen_type [1] = Y4953_pgtype1;
	Y4953_gen_type [2] = Y4953_pgtype2;
	Y4953_gen_type [3] = Y4953_pgtype3;
	Y4953_gen_type [4] = Y4953_pgtype4;
	Y4953_gen_type [5] = Y4953_pgtype5;
	Y4953_gen_type [6] = Y4953_pgtype6;
	Y4953_gen_type [7] = Y4953_pgtype7;
	Y4953_gen_type [8] = Y4953_pgtype8;
	Y4953_gen_type [9] = Y4953_pgtype9;
	Y4953_gen_type [10] = Y4953_pgtype10;
	Y4953_gen_type [11] = Y4953_pgtype11;
	Y4953_gen_type [12] = Y4953_pgtype12;
	Y4953_gen_type [13] = Y4953_pgtype13;
	Y4953_gen_type [14] = Y4953_pgtype14;
	Y4953_gen_type [15] = Y4953_pgtype15;
	Y4953_gen_type [16] = Y4953_pgtype16;
	Y4953_gen_type [17] = Y4953_pgtype17;
	Y4953_gen_type [18] = Y4953_pgtype18;
	Y4953_gen_type [19] = Y4953_pgtype19;
	Y4953_gen_type [20] = Y4953_pgtype20;
	Y4953_gen_type [21] = Y4953_pgtype21;
	Y4953_gen_type [22] = Y4953_pgtype22;
	Y4953_gen_type [23] = Y4953_pgtype23;
	Y4953_gen_type [38] = Y4953_pgtype24;
	Y4953_gen_type [75] = Y4953_pgtype25;
	Y4953_gen_type [76] = Y4953_pgtype26;
	Y4953_gen_type [77] = Y4953_pgtype27;
	Y4953_gen_type [78] = Y4953_pgtype28;
	Y4953_gen_type [79] = Y4953_pgtype29;
	Y4953_gen_type [80] = Y4953_pgtype30;
	Y4953_gen_type [81] = Y4953_pgtype31;
	Y4953_gen_type [82] = Y4953_pgtype32;
	Y4953_gen_type [83] = Y4953_pgtype33;
	Y4953_gen_type [84] = Y4953_pgtype34;
	Y4953_gen_type [85] = Y4953_pgtype35;
	Y4953_gen_type [86] = Y4953_pgtype36;
	Y4953_gen_type [87] = Y4953_pgtype37;
	Y4953_gen_type [88] = Y4953_pgtype38;
	Y4953_gen_type [89] = Y4953_pgtype39;
	Y4953_gen_type [90] = Y4953_pgtype40;
	Y4953_gen_type [91] = Y4953_pgtype41;
	Y4953_gen_type [92] = Y4953_pgtype42;
	Y4953_gen_type [93] = Y4953_pgtype43;
	Y4953_gen_type [94] = Y4953_pgtype44;
	Y4953_gen_type [95] = Y4953_pgtype45;
	Y4953_gen_type [147] = Y4953_pgtype46;
	Y4953_gen_type [148] = Y4953_pgtype47;
	Y4953_gen_type [149] = Y4953_pgtype48;
	Y4953_gen_type [150] = Y4953_pgtype49;
	Y4953_gen_type [151] = Y4953_pgtype50;
	Y4953_gen_type [152] = Y4953_pgtype51;
	Y4953_gen_type [153] = Y4953_pgtype52;
	Y4953_gen_type [154] = Y4953_pgtype53;
	Y4953_gen_type [155] = Y4953_pgtype54;
	Y4953_gen_type [156] = Y4953_pgtype55;
	Y4953_gen_type [157] = Y4953_pgtype56;
	Y4953_gen_type [158] = Y4953_pgtype57;
	Y4953_gen_type [159] = Y4953_pgtype58;
	Y4953_gen_type [160] = Y4953_pgtype59;
	Y4953_gen_type [161] = Y4953_pgtype60;
	Y4953_gen_type [162] = Y4953_pgtype61;
	Y4953_gen_type [163] = Y4953_pgtype62;
	Y4953_gen_type [164] = Y4953_pgtype63;
	Y4953_gen_type [165] = Y4953_pgtype64;
	Y4953_gen_type [166] = Y4953_pgtype65;
	Y4953_gen_type [167] = Y4953_pgtype66;
	Y4953_gen_type [168] = Y4953_pgtype67;
	Y4953_gen_type [169] = Y4953_pgtype68;
	Y4953_gen_type [170] = Y4953_pgtype69;
	Y4953_gen_type [171] = Y4953_pgtype70;
	Y4953_gen_type [172] = Y4953_pgtype71;
	Y4953_gen_type [173] = Y4953_pgtype72;
	Y4953_gen_type [174] = Y4953_pgtype73;
	Y4953_gen_type [175] = Y4953_pgtype74;
	Y4953_gen_type [176] = Y4953_pgtype75;
	Y4953_gen_type [177] = Y4953_pgtype76;
	Y4953_gen_type [178] = Y4953_pgtype77;
	Y4953_gen_type [179] = Y4953_pgtype78;
	Y4953_gen_type [180] = Y4953_pgtype79;
	Y4953_gen_type [181] = Y4953_pgtype80;
	Y4953_gen_type [182] = Y4953_pgtype81;
	Y4953_gen_type [183] = Y4953_pgtype82;
	Y4953_gen_type [184] = Y4953_pgtype83;
	Y4953_gen_type [185] = Y4953_pgtype84;
	Y4953_gen_type [186] = Y4953_pgtype85;
	Y4953_gen_type [187] = Y4953_pgtype86;
	Y4953_gen_type [188] = Y4953_pgtype87;
	Y4953_gen_type [189] = Y4953_pgtype88;
	Y4953_gen_type [190] = Y4953_pgtype89;
	Y4953_gen_type [191] = Y4953_pgtype90;
	Y4953_gen_type [192] = Y4953_pgtype91;
	Y4953_gen_type [193] = Y4953_pgtype92;
	Y4953_gen_type [194] = Y4953_pgtype93;
	Y4953_gen_type [195] = Y4953_pgtype94;
	Y4953_gen_type [196] = Y4953_pgtype95;
	Y4953_gen_type [197] = Y4953_pgtype96;
	Y4953_gen_type [198] = Y4953_pgtype97;
	Y4953_gen_type [199] = Y4953_pgtype98;
	Y4953_gen_type [200] = Y4953_pgtype99;
	Y4953_gen_type [201] = Y4953_pgtype100;
	Y4953_gen_type [203] = Y4953_pgtype101;
	Y4953_gen_type [213] = Y4953_pgtype102;
	Y4953_gen_type [214] = Y4953_pgtype103;
	Y4953_gen_type [215] = Y4953_pgtype104;
	Y4953_gen_type [216] = Y4953_pgtype105;
	Y4953_gen_type [217] = Y4953_pgtype106;
	Y4953_gen_type [218] = Y4953_pgtype107;
	Y4953_gen_type [219] = Y4953_pgtype108;
	Y4953_gen_type [220] = Y4953_pgtype109;
	Y4953_gen_type [221] = Y4953_pgtype110;
	Y4953_gen_type [222] = Y4953_pgtype111;
	Y4953_gen_type [223] = Y4953_pgtype112;
	Y4953_gen_type [224] = Y4953_pgtype113;
	Y4953_gen_type [225] = Y4953_pgtype114;
	Y4953_gen_type [226] = Y4953_pgtype115;
	Y4953_gen_type [227] = Y4953_pgtype116;
	Y4953_gen_type [228] = Y4953_pgtype117;
	Y4953_gen_type [229] = Y4953_pgtype118;
	Y4953_gen_type [230] = Y4953_pgtype119;
	Y4953_gen_type [231] = Y4953_pgtype120;
	Y4953_gen_type [232] = Y4953_pgtype121;
	Y4953_gen_type [233] = Y4953_pgtype122;
	Y4953_gen_type [234] = Y4953_pgtype123;
	Y4953_gen_type [235] = Y4953_pgtype124;
	Y4953_gen_type [236] = Y4953_pgtype125;
	Y4953_gen_type [237] = Y4953_pgtype126;
	Y4953_gen_type [238] = Y4953_pgtype127;
	Y4953_gen_type [239] = Y4953_pgtype128;
	Y4953_gen_type [240] = Y4953_pgtype129;
	Y4953_gen_type [241] = Y4953_pgtype130;
	Y4953_gen_type [242] = Y4953_pgtype131;
	Y4953_gen_type [243] = Y4953_pgtype132;
	Y4953_gen_type [244] = Y4953_pgtype133;
	Y4953_gen_type [245] = Y4953_pgtype134;
	Y4953_gen_type [246] = Y4953_pgtype135;
	Y4953_gen_type [247] = Y4953_pgtype136;
	Y4953_gen_type [248] = Y4953_pgtype137;
	Y4953_gen_type [249] = Y4953_pgtype138;
	Y4953_gen_type [250] = Y4953_pgtype139;
	Y4953_gen_type [251] = Y4953_pgtype140;
	Y4953_gen_type [252] = Y4953_pgtype141;
	Y4953_gen_type [253] = Y4953_pgtype142;
	Y4953_gen_type [254] = Y4953_pgtype143;
	Y4953_gen_type [255] = Y4953_pgtype144;
	Y4953_gen_type [681] = Y4953_pgtype145;
	Y4953_gen_type [685] = Y4953_pgtype146;
	Y4953_gen_type [686] = Y4953_pgtype147;
	Y4953_gen_type [687] = Y4953_pgtype148;
	Y4953_gen_type [688] = Y4953_pgtype149;
	Y4953_gen_type [689] = Y4953_pgtype150;
	Y4953_gen_type [690] = Y4953_pgtype151;
	Y4953_gen_type [691] = Y4953_pgtype152;
	Y4953_gen_type [721] = Y4953_pgtype153;
	Y4953_gen_type [730] = Y4953_pgtype154;
	Y4953_gen_type [731] = Y4953_pgtype155;
	Y4953_gen_type [732] = Y4953_pgtype156;
	Y4953_gen_type [733] = Y4953_pgtype157;
	Y4953_gen_type [734] = Y4953_pgtype158;
	Y4953_gen_type [735] = Y4953_pgtype159;
	Y4953_gen_type [736] = Y4953_pgtype160;
	Y4953_gen_type [737] = Y4953_pgtype161;
	Y4953_gen_type [738] = Y4953_pgtype162;
	Y4953_gen_type [739] = Y4953_pgtype163;
	Y4953_gen_type [740] = Y4953_pgtype164;
	Y4953_gen_type [741] = Y4953_pgtype165;
	Y4953_gen_type [742] = Y4953_pgtype166;
	Y4953[234] = 1094;
	{long i; for (i = 235; i < 256; i++) Y4953[i] = 1040;};
	Y4953[278] = 984;
	Y4953[283] = 984;
	{long i; for (i = 475; i < 478; i++) Y4953[i] = 975;};
	{long i; for (i = 685; i < 692; i++) Y4953[i] = 1126;};
	Y4953[721] = 1050;
	Y4953[731] = 1164;
	Y4953[732] = 1165;
	{long i; for (i = 733; i < 736; i++) Y4953[i] = 1163;};
	{long i; for (i = 736; i < 740; i++) Y4953[i] = 1181;};
	{long i; for (i = 740; i < 743; i++) Y4953[i] = 1169;};
	Y4953[929] = 975;
}

char *(*R4957[548])();
void R4957_init () {
	R4957[0] = (char *(*)()) F639_5505;
	R4957[1] = (char *(*)()) F640_5505_4957_4;
	R4957[2] = (char *(*)()) F641_5505_4957_4;
	R4957[3] = (char *(*)()) F639_5505;
	R4957[4] = (char *(*)()) F641_5505_4957_4;
	R4957[5] = (char *(*)()) F640_5505_4957_4;
	R4957[6] = (char *(*)()) F639_5505;
	R4957[18] = (char *(*)()) F657_5763;
	R4957[19] = (char *(*)()) F658_5763_4957_4;
	R4957[20] = (char *(*)()) F659_5763_4957_4;
	R4957[21] = (char *(*)()) F660_5763_4957_4;
	R4957[22] = (char *(*)()) F661_5763_4957_4;
	R4957[23] = (char *(*)()) F662_5763_4957_4;
	R4957[24] = (char *(*)()) F663_5763_4957_4;
	R4957[25] = (char *(*)()) F664_5763_4957_4;
	R4957[26] = (char *(*)()) F665_5763_4957_4;
	R4957[27] = (char *(*)()) F666_5763_4957_4;
	R4957[28] = (char *(*)()) F667_5763_4957_4;
	R4957[29] = (char *(*)()) F668_5763_4957_4;
	R4957[30] = (char *(*)()) F657_5763;
	R4957[31] = (char *(*)()) F658_5763_4957_4;
	R4957[32] = (char *(*)()) F664_5763_4957_4;
	R4957[37] = (char *(*)()) F672_5807;
	R4957[38] = (char *(*)()) F673_5807_4957_4;
	{long i; for (i = 39; i < 43; i++) R4957[i] = (char *(*)()) F672_5807;}
	R4957[47] = (char *(*)()) F672_5807;
	R4957[49] = (char *(*)()) F672_5807;
	R4957[53] = (char *(*)()) F672_5807;
	{long i; for (i = 55; i < 57; i++) R4957[i] = (char *(*)()) F672_5807;}
	{long i; for (i = 58; i < 61; i++) R4957[i] = (char *(*)()) F672_5807;}
	{long i; for (i = 494; i < 497; i++) R4957[i] = (char *(*)()) F1125_10171;}
	R4957[537] = (char *(*)()) F1125_10171;
	R4957[547] = (char *(*)()) F1125_10171;
}
static void F640_5505_4957_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F640_5505(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F641_5505_4957_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F641_5505(Current, *(EIF_BOOLEAN *)arg1);
}
static void F658_5763_4957_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5763(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F659_5763_4957_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5763(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F660_5763_4957_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F660_5763(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F661_5763_4957_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_5763(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F662_5763_4957_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F662_5763(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F663_5763_4957_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_5763(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F664_5763_4957_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5763(Current, *(EIF_BOOLEAN *)arg1);
}
static void F665_5763_4957_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5763(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F666_5763_4957_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5763(Current, *(EIF_REAL_32 *)arg1);
}
static void F667_5763_4957_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5763(Current, *(EIF_POINTER *)arg1);
}
static void F668_5763_4957_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5763(Current, *(EIF_REAL_64 *)arg1);
}
static void F673_5807_4957_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F673_5807(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4958[548])();
void R4958_init () {
	R4958[0] = (char *(*)()) F639_5508;
	R4958[1] = (char *(*)()) F640_5508;
	R4958[2] = (char *(*)()) F641_5508;
	R4958[3] = (char *(*)()) F642_5526;
	R4958[4] = (char *(*)()) F643_5526;
	R4958[5] = (char *(*)()) F644_5526;
	R4958[6] = (char *(*)()) F639_5509;
	R4958[18] = (char *(*)()) F657_5773;
	R4958[19] = (char *(*)()) F658_5773;
	R4958[20] = (char *(*)()) F659_5773;
	R4958[21] = (char *(*)()) F660_5773;
	R4958[22] = (char *(*)()) F661_5773;
	R4958[23] = (char *(*)()) F662_5773;
	R4958[24] = (char *(*)()) F663_5773;
	R4958[25] = (char *(*)()) F664_5773;
	R4958[26] = (char *(*)()) F665_5773;
	R4958[27] = (char *(*)()) F666_5773;
	R4958[28] = (char *(*)()) F667_5773;
	R4958[29] = (char *(*)()) F668_5773;
	R4958[30] = (char *(*)()) F669_5789;
	R4958[31] = (char *(*)()) F670_5789;
	R4958[32] = (char *(*)()) F671_5789;
	R4958[37] = (char *(*)()) F672_5808;
	R4958[38] = (char *(*)()) F673_5808;
	{long i; for (i = 39; i < 43; i++) R4958[i] = (char *(*)()) F672_5808;}
	R4958[47] = (char *(*)()) F672_5808;
	R4958[49] = (char *(*)()) F672_5808;
	R4958[53] = (char *(*)()) F672_5808;
	{long i; for (i = 55; i < 57; i++) R4958[i] = (char *(*)()) F672_5808;}
	{long i; for (i = 58; i < 61; i++) R4958[i] = (char *(*)()) F672_5808;}
	{long i; for (i = 494; i < 497; i++) R4958[i] = (char *(*)()) F1125_10162;}
	R4958[537] = (char *(*)()) F1125_10162;
	R4958[547] = (char *(*)()) F1125_10162;
}


#ifdef __cplusplus
}
#endif
