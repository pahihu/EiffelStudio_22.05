#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O9677[111];
void O9677_init () {
	O9677[0] = + _PTROFF_2_1_0_0_0_0_;
	{long i; for (i = 81; i < 85; i++) O9677[i] = + _PTROFF_46_14_10_6_0_1_;}
	{long i; for (i = 93; i < 95; i++) O9677[i] = + _PTROFF_21_7_6_1_0_1_;}
	O9677[100] = + _PTROFF_23_8_6_1_0_1_;
	{long i; for (i = 101; i < 103; i++) O9677[i] = + _PTROFF_23_9_6_1_0_1_;}
	O9677[103] = + _PTROFF_24_9_6_1_0_1_;
	O9677[104] = + _PTROFF_26_8_6_2_0_1_;
	{long i; for (i = 109; i < 111; i++) O9677[i] = + _PTROFF_29_14_8_2_0_1_;}
}

long O9682[83];
void O9682_init () {
	O9682[0] =  + _REFACS_1_;
	O9682[25] =  + _REFACS_36_;
	O9682[38] =  + _REFACS_36_;
	O9682[71] =  + _REFACS_33_;
	O9682[75] =  + _REFACS_35_;
	O9682[76] =  + _REFACS_40_;
	O9682[77] =  + _REFACS_34_;
	O9682[78] =  + _REFACS_37_;
	{long i; for (i = 79; i < 83; i++) O9682[i] =  + _REFACS_35_;}
}

long O9691[101];
void O9691_init () {
	O9691[0] = + _PTROFF_2_1_0_0_0_0_;
	O9691[69] = + _PTROFF_44_13_10_6_1_1_;
	{long i; for (i = 77; i < 81; i++) O9691[i] = + _PTROFF_46_14_10_6_0_2_;}
	O9691[96] = + _PTROFF_23_8_6_1_0_2_;
	{long i; for (i = 97; i < 99; i++) O9691[i] = + _PTROFF_23_9_6_1_0_2_;}
	O9691[99] = + _PTROFF_24_9_6_1_0_2_;
	O9691[100] = + _PTROFF_26_8_6_2_0_2_;
}

long O9693[101];
void O9693_init () {
	O9693[0] =  + _REFACS_1_;
	O9693[69] =  + _REFACS_34_;
	{long i; for (i = 77; i < 81; i++) O9693[i] =  + _REFACS_36_;}
	{long i; for (i = 96; i < 100; i++) O9693[i] =  + _REFACS_16_;}
	O9693[100] =  + _REFACS_19_;
}

long O9739[103];
void O9739_init () {
	O9739[0] =  + _REFACS_8_;
	O9739[1] =  + _REFACS_11_;
	O9739[2] =  + _REFACS_27_;
	O9739[3] =  + _REFACS_33_;
	O9739[4] =  + _REFACS_28_;
	O9739[5] =  + _REFACS_34_;
	O9739[6] =  + _REFACS_28_;
	O9739[7] =  + _REFACS_29_;
	O9739[8] =  + _REFACS_28_;
	O9739[9] =  + _REFACS_35_;
	O9739[10] =  + _REFACS_37_;
	O9739[11] =  + _REFACS_35_;
	{long i; for (i = 12; i < 15; i++) O9739[i] =  + _REFACS_30_;}
	{long i; for (i = 15; i < 18; i++) O9739[i] =  + _REFACS_37_;}
	{long i; for (i = 18; i < 22; i++) O9739[i] =  + _REFACS_30_;}
	O9739[22] =  + _REFACS_36_;
	O9739[23] =  + _REFACS_37_;
	{long i; for (i = 24; i < 26; i++) O9739[i] =  + _REFACS_36_;}
	{long i; for (i = 26; i < 28; i++) O9739[i] =  + _REFACS_34_;}
	{long i; for (i = 28; i < 30; i++) O9739[i] =  + _REFACS_37_;}
	{long i; for (i = 30; i < 32; i++) O9739[i] =  + _REFACS_41_;}
	{long i; for (i = 32; i < 34; i++) O9739[i] =  + _REFACS_44_;}
	O9739[34] =  + _REFACS_27_;
	O9739[35] =  + _REFACS_28_;
	O9739[36] =  + _REFACS_31_;
	{long i; for (i = 37; i < 39; i++) O9739[i] =  + _REFACS_29_;}
	O9739[39] =  + _REFACS_27_;
	{long i; for (i = 40; i < 42; i++) O9739[i] =  + _REFACS_29_;}
	O9739[42] =  + _REFACS_28_;
	O9739[43] =  + _REFACS_29_;
	O9739[44] =  + _REFACS_33_;
	O9739[45] =  + _REFACS_28_;
	O9739[46] =  + _REFACS_31_;
	{long i; for (i = 47; i < 51; i++) O9739[i] =  + _REFACS_28_;}
	O9739[51] =  + _REFACS_33_;
	O9739[52] =  + _REFACS_34_;
	O9739[53] =  + _REFACS_38_;
	{long i; for (i = 54; i < 56; i++) O9739[i] =  + _REFACS_36_;}
	O9739[56] =  + _REFACS_35_;
	{long i; for (i = 57; i < 59; i++) O9739[i] =  + _REFACS_36_;}
	O9739[59] =  + _REFACS_34_;
	O9739[60] =  + _REFACS_36_;
	O9739[61] =  + _REFACS_41_;
	O9739[62] =  + _REFACS_35_;
	O9739[63] =  + _REFACS_38_;
	{long i; for (i = 64; i < 68; i++) O9739[i] =  + _REFACS_37_;}
	O9739[68] =  + _REFACS_11_;
	{long i; for (i = 69; i < 71; i++) O9739[i] =  + _REFACS_13_;}
	O9739[71] =  + _REFACS_11_;
	{long i; for (i = 72; i < 74; i++) O9739[i] =  + _REFACS_15_;}
	{long i; for (i = 74; i < 76; i++) O9739[i] =  + _REFACS_16_;}
	{long i; for (i = 76; i < 78; i++) O9739[i] =  + _REFACS_15_;}
	{long i; for (i = 78; i < 82; i++) O9739[i] =  + _REFACS_12_;}
	O9739[82] =  + _REFACS_13_;
	{long i; for (i = 83; i < 87; i++) O9739[i] =  + _REFACS_17_;}
	O9739[87] =  + _REFACS_20_;
	{long i; for (i = 88; i < 90; i++) O9739[i] =  + _REFACS_13_;}
	{long i; for (i = 90; i < 92; i++) O9739[i] =  + _REFACS_16_;}
	{long i; for (i = 92; i < 94; i++) O9739[i] =  + _REFACS_21_;}
	O9739[95] =  + _REFACS_28_;
	O9739[97] =  + _REFACS_28_;
	O9739[100] =  + _REFACS_34_;
	O9739[102] =  + _REFACS_34_;
}

long O9740[103];
void O9740_init () {
	O9740[0] =  + _REFACS_9_;
	O9740[1] =  + _REFACS_12_;
	O9740[2] =  + _REFACS_28_;
	O9740[3] =  + _REFACS_34_;
	O9740[4] =  + _REFACS_29_;
	O9740[5] =  + _REFACS_35_;
	O9740[6] =  + _REFACS_29_;
	O9740[7] =  + _REFACS_30_;
	O9740[8] =  + _REFACS_29_;
	O9740[9] =  + _REFACS_36_;
	O9740[10] =  + _REFACS_38_;
	O9740[11] =  + _REFACS_36_;
	{long i; for (i = 12; i < 15; i++) O9740[i] =  + _REFACS_31_;}
	{long i; for (i = 15; i < 18; i++) O9740[i] =  + _REFACS_38_;}
	{long i; for (i = 18; i < 22; i++) O9740[i] =  + _REFACS_31_;}
	O9740[22] =  + _REFACS_37_;
	O9740[23] =  + _REFACS_38_;
	{long i; for (i = 24; i < 26; i++) O9740[i] =  + _REFACS_37_;}
	{long i; for (i = 26; i < 28; i++) O9740[i] =  + _REFACS_35_;}
	{long i; for (i = 28; i < 30; i++) O9740[i] =  + _REFACS_38_;}
	{long i; for (i = 30; i < 32; i++) O9740[i] =  + _REFACS_42_;}
	{long i; for (i = 32; i < 34; i++) O9740[i] =  + _REFACS_45_;}
	O9740[34] =  + _REFACS_28_;
	O9740[35] =  + _REFACS_29_;
	O9740[36] =  + _REFACS_32_;
	{long i; for (i = 37; i < 39; i++) O9740[i] =  + _REFACS_30_;}
	O9740[39] =  + _REFACS_28_;
	{long i; for (i = 40; i < 42; i++) O9740[i] =  + _REFACS_30_;}
	O9740[42] =  + _REFACS_29_;
	O9740[43] =  + _REFACS_30_;
	O9740[44] =  + _REFACS_34_;
	O9740[45] =  + _REFACS_29_;
	O9740[46] =  + _REFACS_32_;
	{long i; for (i = 47; i < 51; i++) O9740[i] =  + _REFACS_29_;}
	O9740[51] =  + _REFACS_34_;
	O9740[52] =  + _REFACS_35_;
	O9740[53] =  + _REFACS_39_;
	{long i; for (i = 54; i < 56; i++) O9740[i] =  + _REFACS_37_;}
	O9740[56] =  + _REFACS_36_;
	{long i; for (i = 57; i < 59; i++) O9740[i] =  + _REFACS_37_;}
	O9740[59] =  + _REFACS_35_;
	O9740[60] =  + _REFACS_37_;
	O9740[61] =  + _REFACS_42_;
	O9740[62] =  + _REFACS_36_;
	O9740[63] =  + _REFACS_39_;
	{long i; for (i = 64; i < 68; i++) O9740[i] =  + _REFACS_38_;}
	O9740[68] =  + _REFACS_12_;
	{long i; for (i = 69; i < 71; i++) O9740[i] =  + _REFACS_14_;}
	O9740[71] =  + _REFACS_12_;
	{long i; for (i = 72; i < 74; i++) O9740[i] =  + _REFACS_16_;}
	{long i; for (i = 74; i < 76; i++) O9740[i] =  + _REFACS_17_;}
	{long i; for (i = 76; i < 78; i++) O9740[i] =  + _REFACS_16_;}
	{long i; for (i = 78; i < 82; i++) O9740[i] =  + _REFACS_13_;}
	O9740[82] =  + _REFACS_14_;
	{long i; for (i = 83; i < 87; i++) O9740[i] =  + _REFACS_18_;}
	O9740[87] =  + _REFACS_21_;
	{long i; for (i = 88; i < 90; i++) O9740[i] =  + _REFACS_14_;}
	{long i; for (i = 90; i < 92; i++) O9740[i] =  + _REFACS_17_;}
	{long i; for (i = 92; i < 94; i++) O9740[i] =  + _REFACS_22_;}
	O9740[95] =  + _REFACS_29_;
	O9740[97] =  + _REFACS_29_;
	O9740[100] =  + _REFACS_35_;
	O9740[102] =  + _REFACS_35_;
}

long O9742[103];
void O9742_init () {
	O9742[0] =  + _REFACS_10_;
	O9742[1] =  + _REFACS_13_;
	O9742[2] =  + _REFACS_29_;
	O9742[3] =  + _REFACS_35_;
	O9742[4] =  + _REFACS_30_;
	O9742[5] =  + _REFACS_36_;
	O9742[6] =  + _REFACS_30_;
	O9742[7] =  + _REFACS_31_;
	O9742[8] =  + _REFACS_30_;
	O9742[9] =  + _REFACS_37_;
	O9742[10] =  + _REFACS_39_;
	O9742[11] =  + _REFACS_37_;
	{long i; for (i = 12; i < 15; i++) O9742[i] =  + _REFACS_32_;}
	{long i; for (i = 15; i < 18; i++) O9742[i] =  + _REFACS_39_;}
	{long i; for (i = 18; i < 22; i++) O9742[i] =  + _REFACS_32_;}
	O9742[22] =  + _REFACS_38_;
	O9742[23] =  + _REFACS_39_;
	{long i; for (i = 24; i < 26; i++) O9742[i] =  + _REFACS_38_;}
	{long i; for (i = 26; i < 28; i++) O9742[i] =  + _REFACS_36_;}
	{long i; for (i = 28; i < 30; i++) O9742[i] =  + _REFACS_39_;}
	{long i; for (i = 30; i < 32; i++) O9742[i] =  + _REFACS_43_;}
	{long i; for (i = 32; i < 34; i++) O9742[i] =  + _REFACS_46_;}
	O9742[34] =  + _REFACS_29_;
	O9742[35] =  + _REFACS_30_;
	O9742[36] =  + _REFACS_33_;
	{long i; for (i = 37; i < 39; i++) O9742[i] =  + _REFACS_31_;}
	O9742[39] =  + _REFACS_29_;
	{long i; for (i = 40; i < 42; i++) O9742[i] =  + _REFACS_31_;}
	O9742[42] =  + _REFACS_30_;
	O9742[43] =  + _REFACS_31_;
	O9742[44] =  + _REFACS_35_;
	O9742[45] =  + _REFACS_30_;
	O9742[46] =  + _REFACS_33_;
	{long i; for (i = 47; i < 51; i++) O9742[i] =  + _REFACS_30_;}
	O9742[51] =  + _REFACS_35_;
	O9742[52] =  + _REFACS_36_;
	O9742[53] =  + _REFACS_40_;
	{long i; for (i = 54; i < 56; i++) O9742[i] =  + _REFACS_38_;}
	O9742[56] =  + _REFACS_37_;
	{long i; for (i = 57; i < 59; i++) O9742[i] =  + _REFACS_38_;}
	O9742[59] =  + _REFACS_36_;
	O9742[60] =  + _REFACS_38_;
	O9742[61] =  + _REFACS_43_;
	O9742[62] =  + _REFACS_37_;
	O9742[63] =  + _REFACS_40_;
	{long i; for (i = 64; i < 68; i++) O9742[i] =  + _REFACS_39_;}
	O9742[68] =  + _REFACS_13_;
	{long i; for (i = 69; i < 71; i++) O9742[i] =  + _REFACS_15_;}
	O9742[71] =  + _REFACS_13_;
	{long i; for (i = 72; i < 74; i++) O9742[i] =  + _REFACS_17_;}
	{long i; for (i = 74; i < 76; i++) O9742[i] =  + _REFACS_18_;}
	{long i; for (i = 76; i < 78; i++) O9742[i] =  + _REFACS_17_;}
	{long i; for (i = 78; i < 82; i++) O9742[i] =  + _REFACS_14_;}
	O9742[82] =  + _REFACS_15_;
	{long i; for (i = 83; i < 87; i++) O9742[i] =  + _REFACS_19_;}
	O9742[87] =  + _REFACS_22_;
	{long i; for (i = 88; i < 90; i++) O9742[i] =  + _REFACS_15_;}
	{long i; for (i = 90; i < 92; i++) O9742[i] =  + _REFACS_18_;}
	{long i; for (i = 92; i < 94; i++) O9742[i] =  + _REFACS_23_;}
	O9742[95] =  + _REFACS_30_;
	O9742[97] =  + _REFACS_30_;
	O9742[100] =  + _REFACS_36_;
	O9742[102] =  + _REFACS_36_;
}

long O9743[103];
void O9743_init () {
	O9743[0] =  + _REFACS_11_;
	O9743[1] =  + _REFACS_14_;
	O9743[2] =  + _REFACS_30_;
	O9743[3] =  + _REFACS_36_;
	O9743[4] =  + _REFACS_31_;
	O9743[5] =  + _REFACS_37_;
	O9743[6] =  + _REFACS_31_;
	O9743[7] =  + _REFACS_32_;
	O9743[8] =  + _REFACS_31_;
	O9743[9] =  + _REFACS_38_;
	O9743[10] =  + _REFACS_40_;
	O9743[11] =  + _REFACS_38_;
	{long i; for (i = 12; i < 15; i++) O9743[i] =  + _REFACS_33_;}
	{long i; for (i = 15; i < 18; i++) O9743[i] =  + _REFACS_40_;}
	{long i; for (i = 18; i < 22; i++) O9743[i] =  + _REFACS_33_;}
	O9743[22] =  + _REFACS_39_;
	O9743[23] =  + _REFACS_40_;
	{long i; for (i = 24; i < 26; i++) O9743[i] =  + _REFACS_39_;}
	{long i; for (i = 26; i < 28; i++) O9743[i] =  + _REFACS_37_;}
	{long i; for (i = 28; i < 30; i++) O9743[i] =  + _REFACS_40_;}
	{long i; for (i = 30; i < 32; i++) O9743[i] =  + _REFACS_44_;}
	{long i; for (i = 32; i < 34; i++) O9743[i] =  + _REFACS_47_;}
	O9743[34] =  + _REFACS_30_;
	O9743[35] =  + _REFACS_31_;
	O9743[36] =  + _REFACS_34_;
	{long i; for (i = 37; i < 39; i++) O9743[i] =  + _REFACS_32_;}
	O9743[39] =  + _REFACS_30_;
	{long i; for (i = 40; i < 42; i++) O9743[i] =  + _REFACS_32_;}
	O9743[42] =  + _REFACS_31_;
	O9743[43] =  + _REFACS_32_;
	O9743[44] =  + _REFACS_36_;
	O9743[45] =  + _REFACS_31_;
	O9743[46] =  + _REFACS_34_;
	{long i; for (i = 47; i < 51; i++) O9743[i] =  + _REFACS_31_;}
	O9743[51] =  + _REFACS_36_;
	O9743[52] =  + _REFACS_37_;
	O9743[53] =  + _REFACS_41_;
	{long i; for (i = 54; i < 56; i++) O9743[i] =  + _REFACS_39_;}
	O9743[56] =  + _REFACS_38_;
	{long i; for (i = 57; i < 59; i++) O9743[i] =  + _REFACS_39_;}
	O9743[59] =  + _REFACS_37_;
	O9743[60] =  + _REFACS_39_;
	O9743[61] =  + _REFACS_44_;
	O9743[62] =  + _REFACS_38_;
	O9743[63] =  + _REFACS_41_;
	{long i; for (i = 64; i < 68; i++) O9743[i] =  + _REFACS_40_;}
	O9743[68] =  + _REFACS_14_;
	{long i; for (i = 69; i < 71; i++) O9743[i] =  + _REFACS_16_;}
	O9743[71] =  + _REFACS_14_;
	{long i; for (i = 72; i < 74; i++) O9743[i] =  + _REFACS_18_;}
	{long i; for (i = 74; i < 76; i++) O9743[i] =  + _REFACS_19_;}
	{long i; for (i = 76; i < 78; i++) O9743[i] =  + _REFACS_18_;}
	{long i; for (i = 78; i < 82; i++) O9743[i] =  + _REFACS_15_;}
	O9743[82] =  + _REFACS_16_;
	{long i; for (i = 83; i < 87; i++) O9743[i] =  + _REFACS_20_;}
	O9743[87] =  + _REFACS_23_;
	{long i; for (i = 88; i < 90; i++) O9743[i] =  + _REFACS_16_;}
	{long i; for (i = 90; i < 92; i++) O9743[i] =  + _REFACS_19_;}
	{long i; for (i = 92; i < 94; i++) O9743[i] =  + _REFACS_24_;}
	O9743[95] =  + _REFACS_31_;
	O9743[97] =  + _REFACS_31_;
	O9743[100] =  + _REFACS_37_;
	O9743[102] =  + _REFACS_37_;
}

long O9744[103];
void O9744_init () {
	O9744[0] =  + _REFACS_12_;
	O9744[1] =  + _REFACS_15_;
	O9744[2] =  + _REFACS_31_;
	O9744[3] =  + _REFACS_37_;
	O9744[4] =  + _REFACS_32_;
	O9744[5] =  + _REFACS_38_;
	O9744[6] =  + _REFACS_32_;
	O9744[7] =  + _REFACS_33_;
	O9744[8] =  + _REFACS_32_;
	O9744[9] =  + _REFACS_39_;
	O9744[10] =  + _REFACS_41_;
	O9744[11] =  + _REFACS_39_;
	{long i; for (i = 12; i < 15; i++) O9744[i] =  + _REFACS_34_;}
	{long i; for (i = 15; i < 18; i++) O9744[i] =  + _REFACS_41_;}
	{long i; for (i = 18; i < 22; i++) O9744[i] =  + _REFACS_34_;}
	O9744[22] =  + _REFACS_40_;
	O9744[23] =  + _REFACS_41_;
	{long i; for (i = 24; i < 26; i++) O9744[i] =  + _REFACS_40_;}
	{long i; for (i = 26; i < 28; i++) O9744[i] =  + _REFACS_38_;}
	{long i; for (i = 28; i < 30; i++) O9744[i] =  + _REFACS_41_;}
	{long i; for (i = 30; i < 32; i++) O9744[i] =  + _REFACS_45_;}
	{long i; for (i = 32; i < 34; i++) O9744[i] =  + _REFACS_48_;}
	O9744[34] =  + _REFACS_31_;
	O9744[35] =  + _REFACS_32_;
	O9744[36] =  + _REFACS_35_;
	{long i; for (i = 37; i < 39; i++) O9744[i] =  + _REFACS_33_;}
	O9744[39] =  + _REFACS_31_;
	{long i; for (i = 40; i < 42; i++) O9744[i] =  + _REFACS_33_;}
	O9744[42] =  + _REFACS_32_;
	O9744[43] =  + _REFACS_33_;
	O9744[44] =  + _REFACS_37_;
	O9744[45] =  + _REFACS_32_;
	O9744[46] =  + _REFACS_35_;
	{long i; for (i = 47; i < 51; i++) O9744[i] =  + _REFACS_32_;}
	O9744[51] =  + _REFACS_37_;
	O9744[52] =  + _REFACS_38_;
	O9744[53] =  + _REFACS_42_;
	{long i; for (i = 54; i < 56; i++) O9744[i] =  + _REFACS_40_;}
	O9744[56] =  + _REFACS_39_;
	{long i; for (i = 57; i < 59; i++) O9744[i] =  + _REFACS_40_;}
	O9744[59] =  + _REFACS_38_;
	O9744[60] =  + _REFACS_40_;
	O9744[61] =  + _REFACS_45_;
	O9744[62] =  + _REFACS_39_;
	O9744[63] =  + _REFACS_42_;
	{long i; for (i = 64; i < 68; i++) O9744[i] =  + _REFACS_41_;}
	O9744[68] =  + _REFACS_15_;
	{long i; for (i = 69; i < 71; i++) O9744[i] =  + _REFACS_17_;}
	O9744[71] =  + _REFACS_15_;
	{long i; for (i = 72; i < 74; i++) O9744[i] =  + _REFACS_19_;}
	{long i; for (i = 74; i < 76; i++) O9744[i] =  + _REFACS_20_;}
	{long i; for (i = 76; i < 78; i++) O9744[i] =  + _REFACS_19_;}
	{long i; for (i = 78; i < 82; i++) O9744[i] =  + _REFACS_16_;}
	O9744[82] =  + _REFACS_17_;
	{long i; for (i = 83; i < 87; i++) O9744[i] =  + _REFACS_21_;}
	O9744[87] =  + _REFACS_24_;
	{long i; for (i = 88; i < 90; i++) O9744[i] =  + _REFACS_17_;}
	{long i; for (i = 90; i < 92; i++) O9744[i] =  + _REFACS_20_;}
	{long i; for (i = 92; i < 94; i++) O9744[i] =  + _REFACS_25_;}
	O9744[95] =  + _REFACS_32_;
	O9744[97] =  + _REFACS_32_;
	O9744[100] =  + _REFACS_38_;
	O9744[102] =  + _REFACS_38_;
}

long O9764[103];
void O9764_init () {
	O9764[0] = + _CHROFF_13_1_;
	O9764[1] = + _CHROFF_16_3_;
	O9764[2] = + _CHROFF_35_5_;
	O9764[3] = + _CHROFF_42_8_;
	O9764[4] = + _CHROFF_37_5_;
	O9764[5] = + _CHROFF_46_8_;
	O9764[6] = + _CHROFF_37_5_;
	O9764[7] = + _CHROFF_38_5_;
	O9764[8] = + _CHROFF_37_5_;
	O9764[9] = + _CHROFF_47_8_;
	O9764[10] = + _CHROFF_49_8_;
	O9764[11] = + _CHROFF_47_8_;
	{long i; for (i = 12; i < 15; i++) O9764[i] = + _CHROFF_39_6_;}
	{long i; for (i = 15; i < 18; i++) O9764[i] = + _CHROFF_49_9_;}
	{long i; for (i = 18; i < 22; i++) O9764[i] = + _CHROFF_39_6_;}
	O9764[22] = + _CHROFF_49_9_;
	O9764[23] = + _CHROFF_51_9_;
	{long i; for (i = 24; i < 26; i++) O9764[i] = + _CHROFF_49_9_;}
	{long i; for (i = 26; i < 28; i++) O9764[i] = + _CHROFF_47_6_;}
	O9764[28] = + _CHROFF_50_6_;
	O9764[29] = + _CHROFF_53_6_;
	{long i; for (i = 30; i < 32; i++) O9764[i] = + _CHROFF_59_11_;}
	O9764[32] = + _CHROFF_65_11_;
	O9764[33] = + _CHROFF_68_11_;
	O9764[34] = + _CHROFF_35_5_;
	O9764[35] = + _CHROFF_37_5_;
	O9764[36] = + _CHROFF_43_5_;
	O9764[37] = + _CHROFF_37_5_;
	O9764[38] = + _CHROFF_37_6_;
	O9764[39] = + _CHROFF_35_5_;
	{long i; for (i = 40; i < 42; i++) O9764[i] = + _CHROFF_37_5_;}
	O9764[42] = + _CHROFF_36_5_;
	O9764[43] = + _CHROFF_37_5_;
	O9764[44] = + _CHROFF_41_5_;
	O9764[45] = + _CHROFF_36_5_;
	O9764[46] = + _CHROFF_40_5_;
	{long i; for (i = 47; i < 51; i++) O9764[i] = + _CHROFF_36_5_;}
	O9764[51] = + _CHROFF_42_8_;
	O9764[52] = + _CHROFF_44_8_;
	O9764[53] = + _CHROFF_58_8_;
	O9764[54] = + _CHROFF_51_8_;
	O9764[55] = + _CHROFF_45_9_;
	O9764[56] = + _CHROFF_44_8_;
	O9764[57] = + _CHROFF_50_8_;
	O9764[58] = + _CHROFF_51_8_;
	O9764[59] = + _CHROFF_43_8_;
	O9764[60] = + _CHROFF_46_8_;
	O9764[61] = + _CHROFF_59_8_;
	O9764[62] = + _CHROFF_44_8_;
	O9764[63] = + _CHROFF_51_8_;
	{long i; for (i = 64; i < 68; i++) O9764[i] = + _CHROFF_46_8_;}
	O9764[68] = + _CHROFF_16_1_;
	O9764[69] = + _CHROFF_18_1_;
	O9764[70] = + _CHROFF_23_1_;
	O9764[71] = + _CHROFF_16_1_;
	{long i; for (i = 72; i < 74; i++) O9764[i] = + _CHROFF_20_1_;}
	{long i; for (i = 74; i < 76; i++) O9764[i] = + _CHROFF_25_1_;}
	{long i; for (i = 76; i < 78; i++) O9764[i] = + _CHROFF_21_3_;}
	{long i; for (i = 78; i < 82; i++) O9764[i] = + _CHROFF_17_2_;}
	O9764[82] = + _CHROFF_18_2_;
	{long i; for (i = 83; i < 86; i++) O9764[i] = + _CHROFF_23_4_;}
	O9764[86] = + _CHROFF_24_4_;
	O9764[87] = + _CHROFF_26_4_;
	O9764[88] = + _CHROFF_19_1_;
	O9764[89] = + _CHROFF_22_1_;
	{long i; for (i = 90; i < 92; i++) O9764[i] = + _CHROFF_21_5_;}
	{long i; for (i = 92; i < 94; i++) O9764[i] = + _CHROFF_29_8_;}
	O9764[95] = + _CHROFF_36_5_;
	O9764[97] = + _CHROFF_36_5_;
	O9764[100] = + _CHROFF_48_8_;
	O9764[102] = + _CHROFF_48_8_;
}

long O9769[103];
void O9769_init () {
	O9769[0] = + _I16OFF_13_5_4_;
	O9769[1] = + _I16OFF_16_7_4_;
	O9769[2] = + _I16OFF_35_9_4_;
	O9769[3] = + _I16OFF_42_12_6_;
	O9769[4] = + _I16OFF_37_9_4_;
	O9769[5] = + _I16OFF_46_12_6_;
	O9769[6] = + _I16OFF_37_9_4_;
	O9769[7] = + _I16OFF_38_9_4_;
	O9769[8] = + _I16OFF_37_9_4_;
	O9769[9] = + _I16OFF_47_12_6_;
	O9769[10] = + _I16OFF_49_12_6_;
	O9769[11] = + _I16OFF_47_12_6_;
	{long i; for (i = 12; i < 15; i++) O9769[i] = + _I16OFF_39_10_4_;}
	{long i; for (i = 15; i < 18; i++) O9769[i] = + _I16OFF_49_13_6_;}
	{long i; for (i = 18; i < 22; i++) O9769[i] = + _I16OFF_39_10_4_;}
	O9769[22] = + _I16OFF_49_13_6_;
	O9769[23] = + _I16OFF_51_13_6_;
	{long i; for (i = 24; i < 26; i++) O9769[i] = + _I16OFF_49_14_6_;}
	O9769[26] = + _I16OFF_47_12_4_;
	O9769[27] = + _I16OFF_47_14_4_;
	O9769[28] = + _I16OFF_50_13_4_;
	O9769[29] = + _I16OFF_53_13_4_;
	O9769[30] = + _I16OFF_59_21_6_;
	O9769[31] = + _I16OFF_59_23_6_;
	O9769[32] = + _I16OFF_65_25_6_;
	O9769[33] = + _I16OFF_68_26_6_;
	O9769[34] = + _I16OFF_35_9_4_;
	O9769[35] = + _I16OFF_37_9_4_;
	O9769[36] = + _I16OFF_43_9_4_;
	O9769[37] = + _I16OFF_37_9_4_;
	O9769[38] = + _I16OFF_37_10_4_;
	O9769[39] = + _I16OFF_35_9_4_;
	O9769[40] = + _I16OFF_37_9_4_;
	O9769[41] = + _I16OFF_37_10_4_;
	O9769[42] = + _I16OFF_36_9_4_;
	O9769[43] = + _I16OFF_37_9_4_;
	O9769[44] = + _I16OFF_41_9_4_;
	O9769[45] = + _I16OFF_36_9_4_;
	O9769[46] = + _I16OFF_40_12_4_;
	{long i; for (i = 47; i < 51; i++) O9769[i] = + _I16OFF_36_9_4_;}
	O9769[51] = + _I16OFF_42_13_6_;
	O9769[52] = + _I16OFF_44_13_6_;
	O9769[53] = + _I16OFF_58_14_6_;
	O9769[54] = + _I16OFF_51_13_6_;
	O9769[55] = + _I16OFF_45_16_6_;
	O9769[56] = + _I16OFF_44_13_6_;
	O9769[57] = + _I16OFF_50_13_6_;
	O9769[58] = + _I16OFF_51_14_6_;
	O9769[59] = + _I16OFF_43_13_6_;
	O9769[60] = + _I16OFF_46_14_6_;
	O9769[61] = + _I16OFF_59_16_6_;
	O9769[62] = + _I16OFF_44_15_6_;
	O9769[63] = + _I16OFF_51_18_6_;
	{long i; for (i = 64; i < 68; i++) O9769[i] = + _I16OFF_46_14_6_;}
	O9769[68] = + _I16OFF_16_5_4_;
	O9769[69] = + _I16OFF_18_5_4_;
	O9769[70] = + _I16OFF_23_5_4_;
	O9769[71] = + _I16OFF_16_5_4_;
	{long i; for (i = 72; i < 74; i++) O9769[i] = + _I16OFF_20_5_4_;}
	{long i; for (i = 74; i < 76; i++) O9769[i] = + _I16OFF_25_6_4_;}
	{long i; for (i = 76; i < 78; i++) O9769[i] = + _I16OFF_21_7_4_;}
	{long i; for (i = 78; i < 82; i++) O9769[i] = + _I16OFF_17_6_4_;}
	O9769[82] = + _I16OFF_18_6_4_;
	O9769[83] = + _I16OFF_23_8_4_;
	{long i; for (i = 84; i < 86; i++) O9769[i] = + _I16OFF_23_9_4_;}
	O9769[86] = + _I16OFF_24_9_4_;
	O9769[87] = + _I16OFF_26_8_4_;
	O9769[88] = + _I16OFF_19_5_4_;
	O9769[89] = + _I16OFF_22_5_4_;
	{long i; for (i = 90; i < 92; i++) O9769[i] = + _I16OFF_21_10_4_;}
	{long i; for (i = 92; i < 94; i++) O9769[i] = + _I16OFF_29_14_6_;}
	O9769[95] = + _I16OFF_36_10_4_;
	O9769[97] = + _I16OFF_36_9_4_;
	O9769[100] = + _I16OFF_48_19_6_;
	O9769[102] = + _I16OFF_48_18_6_;
}

long O9770[103];
void O9770_init () {
	O9770[0] = + _I16OFF_13_5_5_;
	O9770[1] = + _I16OFF_16_7_5_;
	O9770[2] = + _I16OFF_35_9_5_;
	O9770[3] = + _I16OFF_42_12_7_;
	O9770[4] = + _I16OFF_37_9_5_;
	O9770[5] = + _I16OFF_46_12_7_;
	O9770[6] = + _I16OFF_37_9_5_;
	O9770[7] = + _I16OFF_38_9_5_;
	O9770[8] = + _I16OFF_37_9_5_;
	O9770[9] = + _I16OFF_47_12_7_;
	O9770[10] = + _I16OFF_49_12_7_;
	O9770[11] = + _I16OFF_47_12_7_;
	{long i; for (i = 12; i < 15; i++) O9770[i] = + _I16OFF_39_10_5_;}
	{long i; for (i = 15; i < 18; i++) O9770[i] = + _I16OFF_49_13_7_;}
	{long i; for (i = 18; i < 22; i++) O9770[i] = + _I16OFF_39_10_5_;}
	O9770[22] = + _I16OFF_49_13_7_;
	O9770[23] = + _I16OFF_51_13_7_;
	{long i; for (i = 24; i < 26; i++) O9770[i] = + _I16OFF_49_14_7_;}
	O9770[26] = + _I16OFF_47_12_5_;
	O9770[27] = + _I16OFF_47_14_5_;
	O9770[28] = + _I16OFF_50_13_5_;
	O9770[29] = + _I16OFF_53_13_5_;
	O9770[30] = + _I16OFF_59_21_7_;
	O9770[31] = + _I16OFF_59_23_7_;
	O9770[32] = + _I16OFF_65_25_7_;
	O9770[33] = + _I16OFF_68_26_7_;
	O9770[34] = + _I16OFF_35_9_5_;
	O9770[35] = + _I16OFF_37_9_5_;
	O9770[36] = + _I16OFF_43_9_5_;
	O9770[37] = + _I16OFF_37_9_5_;
	O9770[38] = + _I16OFF_37_10_5_;
	O9770[39] = + _I16OFF_35_9_5_;
	O9770[40] = + _I16OFF_37_9_5_;
	O9770[41] = + _I16OFF_37_10_5_;
	O9770[42] = + _I16OFF_36_9_5_;
	O9770[43] = + _I16OFF_37_9_5_;
	O9770[44] = + _I16OFF_41_9_5_;
	O9770[45] = + _I16OFF_36_9_5_;
	O9770[46] = + _I16OFF_40_12_5_;
	{long i; for (i = 47; i < 51; i++) O9770[i] = + _I16OFF_36_9_5_;}
	O9770[51] = + _I16OFF_42_13_7_;
	O9770[52] = + _I16OFF_44_13_7_;
	O9770[53] = + _I16OFF_58_14_7_;
	O9770[54] = + _I16OFF_51_13_7_;
	O9770[55] = + _I16OFF_45_16_7_;
	O9770[56] = + _I16OFF_44_13_7_;
	O9770[57] = + _I16OFF_50_13_7_;
	O9770[58] = + _I16OFF_51_14_7_;
	O9770[59] = + _I16OFF_43_13_7_;
	O9770[60] = + _I16OFF_46_14_7_;
	O9770[61] = + _I16OFF_59_16_7_;
	O9770[62] = + _I16OFF_44_15_7_;
	O9770[63] = + _I16OFF_51_18_7_;
	{long i; for (i = 64; i < 68; i++) O9770[i] = + _I16OFF_46_14_7_;}
	O9770[68] = + _I16OFF_16_5_5_;
	O9770[69] = + _I16OFF_18_5_5_;
	O9770[70] = + _I16OFF_23_5_5_;
	O9770[71] = + _I16OFF_16_5_5_;
	{long i; for (i = 72; i < 74; i++) O9770[i] = + _I16OFF_20_5_5_;}
	{long i; for (i = 74; i < 76; i++) O9770[i] = + _I16OFF_25_6_5_;}
	{long i; for (i = 76; i < 78; i++) O9770[i] = + _I16OFF_21_7_5_;}
	{long i; for (i = 78; i < 82; i++) O9770[i] = + _I16OFF_17_6_5_;}
	O9770[82] = + _I16OFF_18_6_5_;
	O9770[83] = + _I16OFF_23_8_5_;
	{long i; for (i = 84; i < 86; i++) O9770[i] = + _I16OFF_23_9_5_;}
	O9770[86] = + _I16OFF_24_9_5_;
	O9770[87] = + _I16OFF_26_8_5_;
	O9770[88] = + _I16OFF_19_5_5_;
	O9770[89] = + _I16OFF_22_5_5_;
	{long i; for (i = 90; i < 92; i++) O9770[i] = + _I16OFF_21_10_5_;}
	{long i; for (i = 92; i < 94; i++) O9770[i] = + _I16OFF_29_14_7_;}
	O9770[95] = + _I16OFF_36_10_5_;
	O9770[97] = + _I16OFF_36_9_5_;
	O9770[100] = + _I16OFF_48_19_7_;
	O9770[102] = + _I16OFF_48_18_7_;
}

long O9772[103];
void O9772_init () {
	O9772[0] = + _CHROFF_13_4_;
	O9772[1] = + _CHROFF_16_6_;
	O9772[2] = + _CHROFF_35_8_;
	O9772[3] = + _CHROFF_42_11_;
	O9772[4] = + _CHROFF_37_8_;
	O9772[5] = + _CHROFF_46_11_;
	O9772[6] = + _CHROFF_37_8_;
	O9772[7] = + _CHROFF_38_8_;
	O9772[8] = + _CHROFF_37_8_;
	O9772[9] = + _CHROFF_47_11_;
	O9772[10] = + _CHROFF_49_11_;
	O9772[11] = + _CHROFF_47_11_;
	{long i; for (i = 12; i < 15; i++) O9772[i] = + _CHROFF_39_9_;}
	{long i; for (i = 15; i < 18; i++) O9772[i] = + _CHROFF_49_12_;}
	{long i; for (i = 18; i < 22; i++) O9772[i] = + _CHROFF_39_9_;}
	O9772[22] = + _CHROFF_49_12_;
	O9772[23] = + _CHROFF_51_12_;
	{long i; for (i = 24; i < 26; i++) O9772[i] = + _CHROFF_49_13_;}
	O9772[26] = + _CHROFF_47_11_;
	O9772[27] = + _CHROFF_47_13_;
	O9772[28] = + _CHROFF_50_12_;
	O9772[29] = + _CHROFF_53_12_;
	O9772[30] = + _CHROFF_59_20_;
	O9772[31] = + _CHROFF_59_22_;
	O9772[32] = + _CHROFF_65_24_;
	O9772[33] = + _CHROFF_68_25_;
	O9772[34] = + _CHROFF_35_8_;
	O9772[35] = + _CHROFF_37_8_;
	O9772[36] = + _CHROFF_43_8_;
	O9772[37] = + _CHROFF_37_8_;
	O9772[38] = + _CHROFF_37_9_;
	O9772[39] = + _CHROFF_35_8_;
	O9772[40] = + _CHROFF_37_8_;
	O9772[41] = + _CHROFF_37_9_;
	O9772[42] = + _CHROFF_36_8_;
	O9772[43] = + _CHROFF_37_8_;
	O9772[44] = + _CHROFF_41_8_;
	O9772[45] = + _CHROFF_36_8_;
	O9772[46] = + _CHROFF_40_11_;
	{long i; for (i = 47; i < 51; i++) O9772[i] = + _CHROFF_36_8_;}
	O9772[51] = + _CHROFF_42_12_;
	O9772[52] = + _CHROFF_44_12_;
	O9772[53] = + _CHROFF_58_13_;
	O9772[54] = + _CHROFF_51_12_;
	O9772[55] = + _CHROFF_45_15_;
	O9772[56] = + _CHROFF_44_12_;
	O9772[57] = + _CHROFF_50_12_;
	O9772[58] = + _CHROFF_51_13_;
	O9772[59] = + _CHROFF_43_12_;
	O9772[60] = + _CHROFF_46_13_;
	O9772[61] = + _CHROFF_59_15_;
	O9772[62] = + _CHROFF_44_14_;
	O9772[63] = + _CHROFF_51_17_;
	{long i; for (i = 64; i < 68; i++) O9772[i] = + _CHROFF_46_13_;}
	O9772[68] = + _CHROFF_16_4_;
	O9772[69] = + _CHROFF_18_4_;
	O9772[70] = + _CHROFF_23_4_;
	O9772[71] = + _CHROFF_16_4_;
	{long i; for (i = 72; i < 74; i++) O9772[i] = + _CHROFF_20_4_;}
	{long i; for (i = 74; i < 76; i++) O9772[i] = + _CHROFF_25_5_;}
	{long i; for (i = 76; i < 78; i++) O9772[i] = + _CHROFF_21_6_;}
	{long i; for (i = 78; i < 82; i++) O9772[i] = + _CHROFF_17_5_;}
	O9772[82] = + _CHROFF_18_5_;
	O9772[83] = + _CHROFF_23_7_;
	{long i; for (i = 84; i < 86; i++) O9772[i] = + _CHROFF_23_8_;}
	O9772[86] = + _CHROFF_24_8_;
	O9772[87] = + _CHROFF_26_7_;
	O9772[88] = + _CHROFF_19_4_;
	O9772[89] = + _CHROFF_22_4_;
	{long i; for (i = 90; i < 92; i++) O9772[i] = + _CHROFF_21_9_;}
	{long i; for (i = 92; i < 94; i++) O9772[i] = + _CHROFF_29_13_;}
	O9772[95] = + _CHROFF_36_9_;
	O9772[97] = + _CHROFF_36_8_;
	O9772[100] = + _CHROFF_48_16_;
	O9772[102] = + _CHROFF_48_15_;
}

long O9816[101];
void O9816_init () {
	O9816[0] =  + _REFACS_32_;
	O9816[1] =  + _REFACS_38_;
	O9816[2] =  + _REFACS_33_;
	O9816[3] =  + _REFACS_39_;
	O9816[4] =  + _REFACS_33_;
	O9816[5] =  + _REFACS_34_;
	O9816[6] =  + _REFACS_33_;
	O9816[7] =  + _REFACS_40_;
	O9816[8] =  + _REFACS_42_;
	O9816[9] =  + _REFACS_40_;
	{long i; for (i = 10; i < 13; i++) O9816[i] =  + _REFACS_35_;}
	{long i; for (i = 13; i < 16; i++) O9816[i] =  + _REFACS_42_;}
	{long i; for (i = 16; i < 20; i++) O9816[i] =  + _REFACS_35_;}
	O9816[20] =  + _REFACS_41_;
	O9816[21] =  + _REFACS_42_;
	{long i; for (i = 22; i < 24; i++) O9816[i] =  + _REFACS_41_;}
	{long i; for (i = 24; i < 26; i++) O9816[i] =  + _REFACS_39_;}
	{long i; for (i = 26; i < 28; i++) O9816[i] =  + _REFACS_42_;}
	{long i; for (i = 28; i < 30; i++) O9816[i] =  + _REFACS_46_;}
	{long i; for (i = 30; i < 32; i++) O9816[i] =  + _REFACS_49_;}
	O9816[32] =  + _REFACS_32_;
	O9816[33] =  + _REFACS_33_;
	O9816[34] =  + _REFACS_36_;
	{long i; for (i = 35; i < 37; i++) O9816[i] =  + _REFACS_34_;}
	O9816[37] =  + _REFACS_32_;
	{long i; for (i = 38; i < 40; i++) O9816[i] =  + _REFACS_34_;}
	O9816[40] =  + _REFACS_33_;
	O9816[41] =  + _REFACS_34_;
	O9816[42] =  + _REFACS_38_;
	O9816[43] =  + _REFACS_33_;
	O9816[44] =  + _REFACS_36_;
	{long i; for (i = 45; i < 49; i++) O9816[i] =  + _REFACS_33_;}
	O9816[49] =  + _REFACS_38_;
	O9816[50] =  + _REFACS_39_;
	O9816[51] =  + _REFACS_43_;
	{long i; for (i = 52; i < 54; i++) O9816[i] =  + _REFACS_41_;}
	O9816[54] =  + _REFACS_40_;
	{long i; for (i = 55; i < 57; i++) O9816[i] =  + _REFACS_41_;}
	O9816[57] =  + _REFACS_39_;
	O9816[58] =  + _REFACS_41_;
	O9816[59] =  + _REFACS_46_;
	O9816[60] =  + _REFACS_40_;
	O9816[61] =  + _REFACS_43_;
	{long i; for (i = 62; i < 66; i++) O9816[i] =  + _REFACS_42_;}
	O9816[93] =  + _REFACS_33_;
	O9816[95] =  + _REFACS_33_;
	O9816[98] =  + _REFACS_39_;
	O9816[100] =  + _REFACS_39_;
}

long O9817[101];
void O9817_init () {
	O9817[0] =  + _REFACS_33_;
	O9817[1] =  + _REFACS_39_;
	O9817[2] =  + _REFACS_34_;
	O9817[3] =  + _REFACS_40_;
	O9817[4] =  + _REFACS_34_;
	O9817[5] =  + _REFACS_35_;
	O9817[6] =  + _REFACS_34_;
	O9817[7] =  + _REFACS_41_;
	O9817[8] =  + _REFACS_43_;
	O9817[9] =  + _REFACS_41_;
	{long i; for (i = 10; i < 13; i++) O9817[i] =  + _REFACS_36_;}
	{long i; for (i = 13; i < 16; i++) O9817[i] =  + _REFACS_43_;}
	{long i; for (i = 16; i < 20; i++) O9817[i] =  + _REFACS_36_;}
	O9817[20] =  + _REFACS_42_;
	O9817[21] =  + _REFACS_43_;
	{long i; for (i = 22; i < 24; i++) O9817[i] =  + _REFACS_42_;}
	{long i; for (i = 24; i < 26; i++) O9817[i] =  + _REFACS_40_;}
	{long i; for (i = 26; i < 28; i++) O9817[i] =  + _REFACS_43_;}
	{long i; for (i = 28; i < 30; i++) O9817[i] =  + _REFACS_47_;}
	{long i; for (i = 30; i < 32; i++) O9817[i] =  + _REFACS_50_;}
	O9817[32] =  + _REFACS_33_;
	O9817[33] =  + _REFACS_34_;
	O9817[34] =  + _REFACS_37_;
	{long i; for (i = 35; i < 37; i++) O9817[i] =  + _REFACS_35_;}
	O9817[37] =  + _REFACS_33_;
	{long i; for (i = 38; i < 40; i++) O9817[i] =  + _REFACS_35_;}
	O9817[40] =  + _REFACS_34_;
	O9817[41] =  + _REFACS_35_;
	O9817[42] =  + _REFACS_39_;
	O9817[43] =  + _REFACS_34_;
	O9817[44] =  + _REFACS_37_;
	{long i; for (i = 45; i < 49; i++) O9817[i] =  + _REFACS_34_;}
	O9817[49] =  + _REFACS_39_;
	O9817[50] =  + _REFACS_40_;
	O9817[51] =  + _REFACS_44_;
	{long i; for (i = 52; i < 54; i++) O9817[i] =  + _REFACS_42_;}
	O9817[54] =  + _REFACS_41_;
	{long i; for (i = 55; i < 57; i++) O9817[i] =  + _REFACS_42_;}
	O9817[57] =  + _REFACS_40_;
	O9817[58] =  + _REFACS_42_;
	O9817[59] =  + _REFACS_47_;
	O9817[60] =  + _REFACS_41_;
	O9817[61] =  + _REFACS_44_;
	{long i; for (i = 62; i < 66; i++) O9817[i] =  + _REFACS_43_;}
	O9817[93] =  + _REFACS_34_;
	O9817[95] =  + _REFACS_34_;
	O9817[98] =  + _REFACS_40_;
	O9817[100] =  + _REFACS_40_;
}

long O9818[101];
void O9818_init () {
	O9818[0] =  + _REFACS_34_;
	O9818[1] =  + _REFACS_40_;
	O9818[2] =  + _REFACS_35_;
	O9818[3] =  + _REFACS_41_;
	O9818[4] =  + _REFACS_35_;
	O9818[5] =  + _REFACS_36_;
	O9818[6] =  + _REFACS_35_;
	O9818[7] =  + _REFACS_42_;
	O9818[8] =  + _REFACS_44_;
	O9818[9] =  + _REFACS_42_;
	{long i; for (i = 10; i < 13; i++) O9818[i] =  + _REFACS_37_;}
	{long i; for (i = 13; i < 16; i++) O9818[i] =  + _REFACS_44_;}
	{long i; for (i = 16; i < 20; i++) O9818[i] =  + _REFACS_37_;}
	O9818[20] =  + _REFACS_43_;
	O9818[21] =  + _REFACS_44_;
	{long i; for (i = 22; i < 24; i++) O9818[i] =  + _REFACS_43_;}
	{long i; for (i = 24; i < 26; i++) O9818[i] =  + _REFACS_41_;}
	{long i; for (i = 26; i < 28; i++) O9818[i] =  + _REFACS_44_;}
	{long i; for (i = 28; i < 30; i++) O9818[i] =  + _REFACS_48_;}
	{long i; for (i = 30; i < 32; i++) O9818[i] =  + _REFACS_51_;}
	O9818[32] =  + _REFACS_34_;
	O9818[33] =  + _REFACS_35_;
	O9818[34] =  + _REFACS_38_;
	{long i; for (i = 35; i < 37; i++) O9818[i] =  + _REFACS_36_;}
	O9818[37] =  + _REFACS_34_;
	{long i; for (i = 38; i < 40; i++) O9818[i] =  + _REFACS_36_;}
	O9818[40] =  + _REFACS_35_;
	O9818[41] =  + _REFACS_36_;
	O9818[42] =  + _REFACS_40_;
	O9818[43] =  + _REFACS_35_;
	O9818[44] =  + _REFACS_38_;
	{long i; for (i = 45; i < 49; i++) O9818[i] =  + _REFACS_35_;}
	O9818[49] =  + _REFACS_40_;
	O9818[50] =  + _REFACS_41_;
	O9818[51] =  + _REFACS_45_;
	{long i; for (i = 52; i < 54; i++) O9818[i] =  + _REFACS_43_;}
	O9818[54] =  + _REFACS_42_;
	{long i; for (i = 55; i < 57; i++) O9818[i] =  + _REFACS_43_;}
	O9818[57] =  + _REFACS_41_;
	O9818[58] =  + _REFACS_43_;
	O9818[59] =  + _REFACS_48_;
	O9818[60] =  + _REFACS_42_;
	O9818[61] =  + _REFACS_45_;
	{long i; for (i = 62; i < 66; i++) O9818[i] =  + _REFACS_44_;}
	O9818[93] =  + _REFACS_35_;
	O9818[95] =  + _REFACS_35_;
	O9818[98] =  + _REFACS_41_;
	O9818[100] =  + _REFACS_41_;
}

long O9848[100];
void O9848_init () {
	O9848[0] = + _LNGOFF_42_12_10_2_;
	O9848[2] = + _LNGOFF_46_12_10_2_;
	O9848[6] = + _LNGOFF_47_12_10_3_;
	O9848[7] = + _LNGOFF_49_12_10_5_;
	O9848[8] = + _LNGOFF_47_12_10_3_;
	{long i; for (i = 12; i < 15; i++) O9848[i] = + _LNGOFF_49_13_10_3_;}
	O9848[19] = + _LNGOFF_49_13_10_2_;
	O9848[20] = + _LNGOFF_51_13_10_2_;
	{long i; for (i = 21; i < 23; i++) O9848[i] = + _LNGOFF_49_14_10_2_;}
	O9848[27] = + _LNGOFF_59_21_10_2_;
	O9848[28] = + _LNGOFF_59_23_10_2_;
	O9848[29] = + _LNGOFF_65_25_10_2_;
	O9848[30] = + _LNGOFF_68_26_10_2_;
	O9848[48] = + _LNGOFF_42_13_10_2_;
	O9848[49] = + _LNGOFF_44_13_10_2_;
	O9848[50] = + _LNGOFF_58_14_10_5_;
	O9848[51] = + _LNGOFF_51_13_10_5_;
	O9848[52] = + _LNGOFF_45_16_10_3_;
	O9848[53] = + _LNGOFF_44_13_10_2_;
	O9848[54] = + _LNGOFF_50_13_10_5_;
	O9848[55] = + _LNGOFF_51_14_10_5_;
	O9848[56] = + _LNGOFF_43_13_10_2_;
	O9848[57] = + _LNGOFF_46_14_10_2_;
	O9848[58] = + _LNGOFF_59_16_10_5_;
	O9848[59] = + _LNGOFF_44_15_10_2_;
	O9848[60] = + _LNGOFF_51_18_10_2_;
	{long i; for (i = 61; i < 65; i++) O9848[i] = + _LNGOFF_46_14_10_2_;}
	O9848[97] = + _LNGOFF_48_19_10_2_;
	O9848[99] = + _LNGOFF_48_18_10_2_;
}

long O9849[100];
void O9849_init () {
	O9849[0] = + _LNGOFF_42_12_10_3_;
	O9849[2] = + _LNGOFF_46_12_10_3_;
	O9849[6] = + _LNGOFF_47_12_10_4_;
	O9849[7] = + _LNGOFF_49_12_10_6_;
	O9849[8] = + _LNGOFF_47_12_10_4_;
	{long i; for (i = 12; i < 15; i++) O9849[i] = + _LNGOFF_49_13_10_4_;}
	O9849[19] = + _LNGOFF_49_13_10_3_;
	O9849[20] = + _LNGOFF_51_13_10_3_;
	{long i; for (i = 21; i < 23; i++) O9849[i] = + _LNGOFF_49_14_10_3_;}
	O9849[27] = + _LNGOFF_59_21_10_3_;
	O9849[28] = + _LNGOFF_59_23_10_3_;
	O9849[29] = + _LNGOFF_65_25_10_3_;
	O9849[30] = + _LNGOFF_68_26_10_3_;
	O9849[48] = + _LNGOFF_42_13_10_3_;
	O9849[49] = + _LNGOFF_44_13_10_3_;
	O9849[50] = + _LNGOFF_58_14_10_6_;
	O9849[51] = + _LNGOFF_51_13_10_6_;
	O9849[52] = + _LNGOFF_45_16_10_4_;
	O9849[53] = + _LNGOFF_44_13_10_3_;
	O9849[54] = + _LNGOFF_50_13_10_6_;
	O9849[55] = + _LNGOFF_51_14_10_6_;
	O9849[56] = + _LNGOFF_43_13_10_3_;
	O9849[57] = + _LNGOFF_46_14_10_3_;
	O9849[58] = + _LNGOFF_59_16_10_6_;
	O9849[59] = + _LNGOFF_44_15_10_3_;
	O9849[60] = + _LNGOFF_51_18_10_3_;
	{long i; for (i = 61; i < 65; i++) O9849[i] = + _LNGOFF_46_14_10_3_;}
	O9849[97] = + _LNGOFF_48_19_10_3_;
	O9849[99] = + _LNGOFF_48_18_10_3_;
}

long O9850[100];
void O9850_init () {
	O9850[0] = + _LNGOFF_42_12_10_4_;
	O9850[2] = + _LNGOFF_46_12_10_4_;
	O9850[6] = + _LNGOFF_47_12_10_5_;
	O9850[7] = + _LNGOFF_49_12_10_7_;
	O9850[8] = + _LNGOFF_47_12_10_5_;
	{long i; for (i = 12; i < 15; i++) O9850[i] = + _LNGOFF_49_13_10_5_;}
	O9850[19] = + _LNGOFF_49_13_10_4_;
	O9850[20] = + _LNGOFF_51_13_10_4_;
	{long i; for (i = 21; i < 23; i++) O9850[i] = + _LNGOFF_49_14_10_4_;}
	O9850[27] = + _LNGOFF_59_21_10_4_;
	O9850[28] = + _LNGOFF_59_23_10_4_;
	O9850[29] = + _LNGOFF_65_25_10_4_;
	O9850[30] = + _LNGOFF_68_26_10_4_;
	O9850[48] = + _LNGOFF_42_13_10_4_;
	O9850[49] = + _LNGOFF_44_13_10_4_;
	O9850[50] = + _LNGOFF_58_14_10_7_;
	O9850[51] = + _LNGOFF_51_13_10_7_;
	O9850[52] = + _LNGOFF_45_16_10_5_;
	O9850[53] = + _LNGOFF_44_13_10_4_;
	O9850[54] = + _LNGOFF_50_13_10_7_;
	O9850[55] = + _LNGOFF_51_14_10_7_;
	O9850[56] = + _LNGOFF_43_13_10_4_;
	O9850[57] = + _LNGOFF_46_14_10_4_;
	O9850[58] = + _LNGOFF_59_16_10_7_;
	O9850[59] = + _LNGOFF_44_15_10_4_;
	O9850[60] = + _LNGOFF_51_18_10_4_;
	{long i; for (i = 61; i < 65; i++) O9850[i] = + _LNGOFF_46_14_10_4_;}
	O9850[97] = + _LNGOFF_48_19_10_4_;
	O9850[99] = + _LNGOFF_48_18_10_4_;
}

long O9851[100];
void O9851_init () {
	O9851[0] = + _LNGOFF_42_12_10_5_;
	O9851[2] = + _LNGOFF_46_12_10_5_;
	O9851[6] = + _LNGOFF_47_12_10_6_;
	O9851[7] = + _LNGOFF_49_12_10_8_;
	O9851[8] = + _LNGOFF_47_12_10_6_;
	{long i; for (i = 12; i < 15; i++) O9851[i] = + _LNGOFF_49_13_10_6_;}
	O9851[19] = + _LNGOFF_49_13_10_5_;
	O9851[20] = + _LNGOFF_51_13_10_5_;
	{long i; for (i = 21; i < 23; i++) O9851[i] = + _LNGOFF_49_14_10_5_;}
	O9851[27] = + _LNGOFF_59_21_10_5_;
	O9851[28] = + _LNGOFF_59_23_10_5_;
	O9851[29] = + _LNGOFF_65_25_10_5_;
	O9851[30] = + _LNGOFF_68_26_10_5_;
	O9851[48] = + _LNGOFF_42_13_10_5_;
	O9851[49] = + _LNGOFF_44_13_10_5_;
	O9851[50] = + _LNGOFF_58_14_10_8_;
	O9851[51] = + _LNGOFF_51_13_10_8_;
	O9851[52] = + _LNGOFF_45_16_10_6_;
	O9851[53] = + _LNGOFF_44_13_10_5_;
	O9851[54] = + _LNGOFF_50_13_10_8_;
	O9851[55] = + _LNGOFF_51_14_10_8_;
	O9851[56] = + _LNGOFF_43_13_10_5_;
	O9851[57] = + _LNGOFF_46_14_10_5_;
	O9851[58] = + _LNGOFF_59_16_10_8_;
	O9851[59] = + _LNGOFF_44_15_10_5_;
	O9851[60] = + _LNGOFF_51_18_10_5_;
	{long i; for (i = 61; i < 65; i++) O9851[i] = + _LNGOFF_46_14_10_5_;}
	O9851[97] = + _LNGOFF_48_19_10_5_;
	O9851[99] = + _LNGOFF_48_18_10_5_;
}

long O9856[100];
void O9856_init () {
	O9856[0] =  + _REFACS_41_;
	O9856[2] =  + _REFACS_42_;
	O9856[6] =  + _REFACS_43_;
	O9856[7] =  + _REFACS_45_;
	O9856[8] =  + _REFACS_43_;
	{long i; for (i = 12; i < 15; i++) O9856[i] =  + _REFACS_45_;}
	O9856[19] =  + _REFACS_44_;
	O9856[20] =  + _REFACS_45_;
	{long i; for (i = 21; i < 23; i++) O9856[i] =  + _REFACS_44_;}
	{long i; for (i = 27; i < 29; i++) O9856[i] =  + _REFACS_49_;}
	{long i; for (i = 29; i < 31; i++) O9856[i] =  + _REFACS_52_;}
	O9856[48] =  + _REFACS_41_;
	O9856[49] =  + _REFACS_42_;
	O9856[50] =  + _REFACS_46_;
	{long i; for (i = 51; i < 53; i++) O9856[i] =  + _REFACS_44_;}
	O9856[53] =  + _REFACS_43_;
	{long i; for (i = 54; i < 56; i++) O9856[i] =  + _REFACS_44_;}
	O9856[56] =  + _REFACS_42_;
	O9856[57] =  + _REFACS_44_;
	O9856[58] =  + _REFACS_49_;
	O9856[59] =  + _REFACS_43_;
	O9856[60] =  + _REFACS_46_;
	{long i; for (i = 61; i < 65; i++) O9856[i] =  + _REFACS_45_;}
	O9856[97] =  + _REFACS_42_;
	O9856[99] =  + _REFACS_42_;
}

long O9865[100];
void O9865_init () {
	O9865[0] = + _I16OFF_42_12_8_;
	O9865[2] = + _I16OFF_46_12_8_;
	O9865[6] = + _I16OFF_47_12_8_;
	O9865[7] = + _I16OFF_49_12_8_;
	O9865[8] = + _I16OFF_47_12_8_;
	{long i; for (i = 12; i < 15; i++) O9865[i] = + _I16OFF_49_13_8_;}
	O9865[19] = + _I16OFF_49_13_8_;
	O9865[20] = + _I16OFF_51_13_8_;
	{long i; for (i = 21; i < 23; i++) O9865[i] = + _I16OFF_49_14_8_;}
	O9865[27] = + _I16OFF_59_21_8_;
	O9865[28] = + _I16OFF_59_23_8_;
	O9865[29] = + _I16OFF_65_25_8_;
	O9865[30] = + _I16OFF_68_26_8_;
	O9865[48] = + _I16OFF_42_13_8_;
	O9865[49] = + _I16OFF_44_13_8_;
	O9865[50] = + _I16OFF_58_14_8_;
	O9865[51] = + _I16OFF_51_13_8_;
	O9865[52] = + _I16OFF_45_16_8_;
	O9865[53] = + _I16OFF_44_13_8_;
	O9865[54] = + _I16OFF_50_13_8_;
	O9865[55] = + _I16OFF_51_14_8_;
	O9865[56] = + _I16OFF_43_13_8_;
	O9865[57] = + _I16OFF_46_14_8_;
	O9865[58] = + _I16OFF_59_16_8_;
	O9865[59] = + _I16OFF_44_15_8_;
	O9865[60] = + _I16OFF_51_18_8_;
	{long i; for (i = 61; i < 65; i++) O9865[i] = + _I16OFF_46_14_8_;}
	O9865[97] = + _I16OFF_48_19_8_;
	O9865[99] = + _I16OFF_48_18_8_;
}

long O9866[100];
void O9866_init () {
	O9866[0] = + _I16OFF_42_12_9_;
	O9866[2] = + _I16OFF_46_12_9_;
	O9866[6] = + _I16OFF_47_12_9_;
	O9866[7] = + _I16OFF_49_12_9_;
	O9866[8] = + _I16OFF_47_12_9_;
	{long i; for (i = 12; i < 15; i++) O9866[i] = + _I16OFF_49_13_9_;}
	O9866[19] = + _I16OFF_49_13_9_;
	O9866[20] = + _I16OFF_51_13_9_;
	{long i; for (i = 21; i < 23; i++) O9866[i] = + _I16OFF_49_14_9_;}
	O9866[27] = + _I16OFF_59_21_9_;
	O9866[28] = + _I16OFF_59_23_9_;
	O9866[29] = + _I16OFF_65_25_9_;
	O9866[30] = + _I16OFF_68_26_9_;
	O9866[48] = + _I16OFF_42_13_9_;
	O9866[49] = + _I16OFF_44_13_9_;
	O9866[50] = + _I16OFF_58_14_9_;
	O9866[51] = + _I16OFF_51_13_9_;
	O9866[52] = + _I16OFF_45_16_9_;
	O9866[53] = + _I16OFF_44_13_9_;
	O9866[54] = + _I16OFF_50_13_9_;
	O9866[55] = + _I16OFF_51_14_9_;
	O9866[56] = + _I16OFF_43_13_9_;
	O9866[57] = + _I16OFF_46_14_9_;
	O9866[58] = + _I16OFF_59_16_9_;
	O9866[59] = + _I16OFF_44_15_9_;
	O9866[60] = + _I16OFF_51_18_9_;
	{long i; for (i = 61; i < 65; i++) O9866[i] = + _I16OFF_46_14_9_;}
	O9866[97] = + _I16OFF_48_19_9_;
	O9866[99] = + _I16OFF_48_18_9_;
}

long O9894[29];
void O9894_init () {
	O9894[0] =  + _REFACS_44_;
	O9894[4] =  + _REFACS_45_;
	O9894[5] =  + _REFACS_47_;
	O9894[6] =  + _REFACS_45_;
	{long i; for (i = 10; i < 13; i++) O9894[i] =  + _REFACS_47_;}
	O9894[17] =  + _REFACS_46_;
	O9894[18] =  + _REFACS_47_;
	{long i; for (i = 19; i < 21; i++) O9894[i] =  + _REFACS_46_;}
	{long i; for (i = 25; i < 27; i++) O9894[i] =  + _REFACS_51_;}
	{long i; for (i = 27; i < 29; i++) O9894[i] =  + _REFACS_54_;}
}

long O9908[29];
void O9908_init () {
	O9908[0] =  + _REFACS_45_;
	O9908[4] =  + _REFACS_46_;
	O9908[5] =  + _REFACS_48_;
	O9908[6] =  + _REFACS_46_;
	{long i; for (i = 10; i < 13; i++) O9908[i] =  + _REFACS_48_;}
	O9908[17] =  + _REFACS_47_;
	O9908[18] =  + _REFACS_48_;
	{long i; for (i = 19; i < 21; i++) O9908[i] =  + _REFACS_47_;}
	{long i; for (i = 25; i < 27; i++) O9908[i] =  + _REFACS_52_;}
	{long i; for (i = 27; i < 29; i++) O9908[i] =  + _REFACS_55_;}
}

long O9979[12];
void O9979_init () {
	O9979[0] =  + _REFACS_48_;
	O9979[1] =  + _REFACS_49_;
	{long i; for (i = 2; i < 4; i++) O9979[i] =  + _REFACS_48_;}
	{long i; for (i = 8; i < 10; i++) O9979[i] =  + _REFACS_53_;}
	{long i; for (i = 10; i < 12; i++) O9979[i] =  + _REFACS_56_;}
}

long O10002[8];
void O10002_init () {
	{long i; for (i = 0; i < 2; i++) O10002[i] =  + _REFACS_43_;}
	{long i; for (i = 2; i < 4; i++) O10002[i] =  + _REFACS_46_;}
	{long i; for (i = 4; i < 6; i++) O10002[i] =  + _REFACS_54_;}
	{long i; for (i = 6; i < 8; i++) O10002[i] =  + _REFACS_57_;}
}

long O10003[8];
void O10003_init () {
	{long i; for (i = 0; i < 2; i++) O10003[i] =  + _REFACS_44_;}
	{long i; for (i = 2; i < 4; i++) O10003[i] =  + _REFACS_47_;}
	{long i; for (i = 4; i < 6; i++) O10003[i] =  + _REFACS_55_;}
	{long i; for (i = 6; i < 8; i++) O10003[i] =  + _REFACS_58_;}
}

long O10009[8];
void O10009_init () {
	{long i; for (i = 0; i < 2; i++) O10009[i] = + _CHROFF_47_8_;}
	O10009[2] = + _CHROFF_50_8_;
	O10009[3] = + _CHROFF_53_8_;
	{long i; for (i = 4; i < 6; i++) O10009[i] = + _CHROFF_59_13_;}
	O10009[6] = + _CHROFF_65_13_;
	O10009[7] = + _CHROFF_68_13_;
}

long O10030[8];
void O10030_init () {
	{long i; for (i = 0; i < 2; i++) O10030[i] =  + _REFACS_45_;}
	{long i; for (i = 2; i < 4; i++) O10030[i] =  + _REFACS_48_;}
	{long i; for (i = 4; i < 6; i++) O10030[i] =  + _REFACS_56_;}
	{long i; for (i = 6; i < 8; i++) O10030[i] =  + _REFACS_59_;}
}

long O10033[8];
void O10033_init () {
	{long i; for (i = 0; i < 2; i++) O10033[i] = + _CHROFF_47_9_;}
	O10033[2] = + _CHROFF_50_9_;
	O10033[3] = + _CHROFF_53_9_;
	{long i; for (i = 4; i < 6; i++) O10033[i] = + _CHROFF_59_14_;}
	O10033[6] = + _CHROFF_65_14_;
	O10033[7] = + _CHROFF_68_14_;
}

long O10034[8];
void O10034_init () {
	{long i; for (i = 0; i < 2; i++) O10034[i] =  + _REFACS_46_;}
	{long i; for (i = 2; i < 4; i++) O10034[i] =  + _REFACS_49_;}
	{long i; for (i = 4; i < 6; i++) O10034[i] =  + _REFACS_57_;}
	{long i; for (i = 6; i < 8; i++) O10034[i] =  + _REFACS_60_;}
}

long O10074[4];
void O10074_init () {
	O10074[0] = + _CHROFF_59_15_;
	O10074[1] = + _CHROFF_59_17_;
	O10074[2] = + _CHROFF_65_16_;
	O10074[3] = + _CHROFF_68_16_;
}

long O10075[4];
void O10075_init () {
	O10075[0] = + _CHROFF_59_16_;
	O10075[1] = + _CHROFF_59_18_;
	O10075[2] = + _CHROFF_65_17_;
	O10075[3] = + _CHROFF_68_17_;
}

long O10076[4];
void O10076_init () {
	O10076[0] = + _CHROFF_59_17_;
	O10076[1] = + _CHROFF_59_19_;
	O10076[2] = + _CHROFF_65_18_;
	O10076[3] = + _CHROFF_68_18_;
}

long O10078[4];
void O10078_init () {
	O10078[0] = + _CHROFF_59_18_;
	O10078[1] = + _CHROFF_59_20_;
	O10078[2] = + _CHROFF_65_19_;
	O10078[3] = + _CHROFF_68_19_;
}

long O10080[4];
void O10080_init () {
	O10080[0] = + _PTROFF_59_21_10_11_0_1_;
	O10080[1] = + _PTROFF_59_23_10_11_0_1_;
	O10080[2] = + _PTROFF_65_25_10_11_0_1_;
	O10080[3] = + _PTROFF_68_26_10_11_0_1_;
}

long O10082[4];
void O10082_init () {
	O10082[0] = + _LNGOFF_59_21_10_6_;
	O10082[1] = + _LNGOFF_59_23_10_6_;
	O10082[2] = + _LNGOFF_65_25_10_6_;
	O10082[3] = + _LNGOFF_68_26_10_6_;
}

long O10083[4];
void O10083_init () {
	O10083[0] = + _LNGOFF_59_21_10_7_;
	O10083[1] = + _LNGOFF_59_23_10_7_;
	O10083[2] = + _LNGOFF_65_25_10_7_;
	O10083[3] = + _LNGOFF_68_26_10_7_;
}

long O10088[4];
void O10088_init () {
	O10088[0] = + _LNGOFF_59_21_10_8_;
	O10088[1] = + _LNGOFF_59_23_10_8_;
	O10088[2] = + _LNGOFF_65_25_10_8_;
	O10088[3] = + _LNGOFF_68_26_10_8_;
}

long O10103[4];
void O10103_init () {
	O10103[0] = + _PTROFF_59_21_10_11_0_2_;
	O10103[1] = + _PTROFF_59_23_10_11_0_2_;
	O10103[2] = + _PTROFF_65_25_10_11_0_2_;
	O10103[3] = + _PTROFF_68_26_10_11_0_2_;
}

long O10104[4];
void O10104_init () {
	O10104[0] = + _PTROFF_59_21_10_11_0_3_;
	O10104[1] = + _PTROFF_59_23_10_11_0_3_;
	O10104[2] = + _PTROFF_65_25_10_11_0_3_;
	O10104[3] = + _PTROFF_68_26_10_11_0_3_;
}

long O10106[4];
void O10106_init () {
	O10106[0] = + _LNGOFF_59_21_10_9_;
	O10106[1] = + _LNGOFF_59_23_10_9_;
	O10106[2] = + _LNGOFF_65_25_10_9_;
	O10106[3] = + _LNGOFF_68_26_10_9_;
}

long O10107[4];
void O10107_init () {
	O10107[0] = + _LNGOFF_59_21_10_10_;
	O10107[1] = + _LNGOFF_59_23_10_10_;
	O10107[2] = + _LNGOFF_65_25_10_10_;
	O10107[3] = + _LNGOFF_68_26_10_10_;
}

long O10113[2];
void O10113_init () {
	O10113[0] = + _CHROFF_65_20_;
	O10113[1] = + _CHROFF_68_20_;
}

long O10114[2];
void O10114_init () {
	O10114[0] =  + _REFACS_62_;
	O10114[1] =  + _REFACS_65_;
}

long O10117[2];
void O10117_init () {
	O10117[0] = + _CHROFF_65_21_;
	O10117[1] = + _CHROFF_68_21_;
}

long O10118[2];
void O10118_init () {
	O10118[0] = + _CHROFF_65_22_;
	O10118[1] = + _CHROFF_68_22_;
}

long O10291[52];
void O10291_init () {
	O10291[0] = + _CHROFF_42_10_;
	O10291[1] = + _CHROFF_44_10_;
	O10291[2] = + _CHROFF_58_10_;
	O10291[3] = + _CHROFF_51_10_;
	O10291[4] = + _CHROFF_45_11_;
	O10291[5] = + _CHROFF_44_10_;
	O10291[6] = + _CHROFF_50_10_;
	O10291[7] = + _CHROFF_51_11_;
	O10291[8] = + _CHROFF_43_10_;
	O10291[9] = + _CHROFF_46_10_;
	O10291[10] = + _CHROFF_59_10_;
	O10291[11] = + _CHROFF_44_10_;
	O10291[12] = + _CHROFF_51_13_;
	{long i; for (i = 13; i < 17; i++) O10291[i] = + _CHROFF_46_10_;}
	O10291[49] = + _CHROFF_48_10_;
	O10291[51] = + _CHROFF_48_10_;
}

long O10479[18];
void O10479_init () {
	{long i; for (i = 0; i < 2; i++) O10479[i] =  + _REFACS_20_;}
	{long i; for (i = 7; i < 11; i++) O10479[i] =  + _REFACS_22_;}
	O10479[11] =  + _REFACS_25_;
	{long i; for (i = 16; i < 18; i++) O10479[i] =  + _REFACS_26_;}
}

long O10485[5];
void O10485_init () {
	O10485[0] = + _PTROFF_23_8_6_1_0_3_;
	{long i; for (i = 1; i < 3; i++) O10485[i] = + _PTROFF_23_9_6_1_0_3_;}
	O10485[3] = + _PTROFF_24_9_6_1_0_3_;
	O10485[4] = + _PTROFF_26_8_6_2_0_3_;
}

long O10547[10];
void O10547_init () {
	O10547[0] = + _LNGOFF_1_1_0_0_;
	O10547[1] = + _LNGOFF_36_10_6_1_;
	O10547[2] = + _LNGOFF_1_1_0_0_;
	O10547[3] = + _LNGOFF_36_9_6_1_;
	O10547[4] = + _LNGOFF_1_1_0_0_;
	O10547[5] = + _LNGOFF_6_5_0_0_;
	O10547[6] = + _LNGOFF_48_19_10_6_;
	O10547[7] = + _LNGOFF_6_5_0_0_;
	O10547[8] = + _LNGOFF_48_18_10_6_;
	O10547[9] = + _LNGOFF_6_7_0_0_;
}

long O10623[5];
void O10623_init () {
	O10623[0] = + _PTROFF_6_5_0_3_0_0_;
	O10623[1] = + _PTROFF_48_19_10_9_0_1_;
	O10623[2] = + _PTROFF_6_5_0_3_0_0_;
	O10623[3] = + _PTROFF_48_18_10_9_0_1_;
	O10623[4] = + _PTROFF_6_7_0_5_0_0_;
}

long O10631[5];
void O10631_init () {
	O10631[0] = + _CHROFF_6_3_;
	O10631[1] = + _CHROFF_48_17_;
	O10631[2] = + _CHROFF_6_3_;
	O10631[3] = + _CHROFF_48_16_;
	O10631[4] = + _CHROFF_6_5_;
}

long O10632[5];
void O10632_init () {
	O10632[0] = + _CHROFF_6_4_;
	O10632[1] = + _CHROFF_48_18_;
	O10632[2] = + _CHROFF_6_4_;
	O10632[3] = + _CHROFF_48_17_;
	O10632[4] = + _CHROFF_6_6_;
}

long O10636[5];
void O10636_init () {
	O10636[0] = + _CHROFF_6_0_;
	O10636[1] = + _CHROFF_48_12_;
	O10636[2] = + _CHROFF_6_0_;
	O10636[3] = + _CHROFF_48_11_;
	O10636[4] = + _CHROFF_6_0_;
}

long O10637[5];
void O10637_init () {
	O10637[0] = + _R64OFF_6_5_0_3_0_1_0_0_;
	O10637[1] = + _R64OFF_48_19_10_9_0_3_0_0_;
	O10637[2] = + _R64OFF_6_5_0_3_0_2_0_0_;
	O10637[3] = + _R64OFF_48_18_10_9_0_4_0_0_;
	O10637[4] = + _R64OFF_6_7_0_5_0_5_0_0_;
}

long O10656[5];
void O10656_init () {
	O10656[0] =  + _REFACS_2_;
	O10656[1] =  + _REFACS_44_;
	O10656[2] =  + _REFACS_2_;
	O10656[3] =  + _REFACS_44_;
	O10656[4] =  + _REFACS_2_;
}

long O10657[5];
void O10657_init () {
	O10657[0] =  + _REFACS_3_;
	O10657[1] =  + _REFACS_45_;
	O10657[2] =  + _REFACS_3_;
	O10657[3] =  + _REFACS_45_;
	O10657[4] =  + _REFACS_3_;
}

long O10661[5];
void O10661_init () {
	O10661[0] =  + _REFACS_4_;
	O10661[1] =  + _REFACS_46_;
	O10661[2] =  + _REFACS_4_;
	O10661[3] =  + _REFACS_46_;
	O10661[4] =  + _REFACS_4_;
}

long O10662[5];
void O10662_init () {
	O10662[0] = + _CHROFF_6_1_;
	O10662[1] = + _CHROFF_48_13_;
	O10662[2] = + _CHROFF_6_1_;
	O10662[3] = + _CHROFF_48_12_;
	O10662[4] = + _CHROFF_6_1_;
}

long O10663[5];
void O10663_init () {
	O10663[0] =  + _REFACS_5_;
	O10663[1] =  + _REFACS_47_;
	O10663[2] =  + _REFACS_5_;
	O10663[3] =  + _REFACS_47_;
	O10663[4] =  + _REFACS_5_;
}

long O10664[5];
void O10664_init () {
	O10664[0] = + _LNGOFF_6_5_0_1_;
	O10664[1] = + _LNGOFF_48_19_10_7_;
	O10664[2] = + _LNGOFF_6_5_0_1_;
	O10664[3] = + _LNGOFF_48_18_10_7_;
	O10664[4] = + _LNGOFF_6_7_0_1_;
}

long O10665[5];
void O10665_init () {
	O10665[0] = + _LNGOFF_6_5_0_2_;
	O10665[1] = + _LNGOFF_48_19_10_8_;
	O10665[2] = + _LNGOFF_6_5_0_2_;
	O10665[3] = + _LNGOFF_48_18_10_8_;
	O10665[4] = + _LNGOFF_6_7_0_2_;
}


#ifdef __cplusplus
}
#endif
