#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O4810[1038];
void O4810_init () {
	{long i; for (i = 0; i < 12; i++) O4810[i] = + _CHROFF_0_0_;}
	O4810[12] = + _CHROFF_1_0_;
	{long i; for (i = 13; i < 15; i++) O4810[i] = + _CHROFF_4_0_;}
	{long i; for (i = 15; i < 199; i++) O4810[i] = + _CHROFF_0_0_;}
	O4810[199] = + _CHROFF_1_0_;
	{long i; for (i = 200; i < 216; i++) O4810[i] = + _CHROFF_0_0_;}
	{long i; for (i = 228; i < 241; i++) O4810[i] = + _CHROFF_0_0_;}
	{long i; for (i = 241; i < 254; i++) O4810[i] = + _CHROFF_1_0_;}
	O4810[254] = + _CHROFF_2_0_;
	{long i; for (i = 255; i < 303; i++) O4810[i] = + _CHROFF_0_0_;}
	{long i; for (i = 303; i < 310; i++) O4810[i] = + _CHROFF_2_0_;}
	O4810[311] = + _CHROFF_1_0_;
	O4810[312] = + _CHROFF_7_0_;
	O4810[313] = + _CHROFF_5_0_;
	O4810[314] = + _CHROFF_6_0_;
	{long i; for (i = 315; i < 317; i++) O4810[i] = + _CHROFF_4_0_;}
	O4810[317] = + _CHROFF_5_0_;
	O4810[318] = + _CHROFF_7_0_;
	O4810[319] = + _CHROFF_5_0_;
	O4810[320] = + _CHROFF_9_0_;
	{long i; for (i = 321; i < 338; i++) O4810[i] = + _CHROFF_1_0_;}
	{long i; for (i = 338; i < 340; i++) O4810[i] = + _CHROFF_3_0_;}
	{long i; for (i = 340; i < 343; i++) O4810[i] = + _CHROFF_5_0_;}
	{long i; for (i = 343; i < 345; i++) O4810[i] = + _CHROFF_9_0_;}
	O4810[345] = + _CHROFF_10_0_;
	{long i; for (i = 346; i < 364; i++) O4810[i] = + _CHROFF_9_0_;}
	O4810[386] = + _CHROFF_0_0_;
	O4810[389] = + _CHROFF_2_0_;
	O4810[391] = + _CHROFF_0_0_;
	O4810[583] = + _CHROFF_3_2_;
	O4810[584] = + _CHROFF_4_2_;
	O4810[585] = + _CHROFF_5_2_;
	O4810[715] = + _CHROFF_1_0_;
	{long i; for (i = 718; i < 720; i++) O4810[i] = + _CHROFF_1_0_;}
	O4810[789] = + _CHROFF_3_0_;
	{long i; for (i = 792; i < 799; i++) O4810[i] = + _CHROFF_6_0_;}
	O4810[799] = + _CHROFF_10_0_;
	{long i; for (i = 800; i < 807; i++) O4810[i] = + _CHROFF_6_0_;}
	{long i; for (i = 807; i < 809; i++) O4810[i] = + _CHROFF_12_0_;}
	O4810[809] = + _CHROFF_6_0_;
	O4810[810] = + _CHROFF_7_0_;
	{long i; for (i = 811; i < 813; i++) O4810[i] = + _CHROFF_14_0_;}
	O4810[829] = + _CHROFF_7_0_;
	O4810[838] = + _CHROFF_3_0_;
	{long i; for (i = 839; i < 844; i++) O4810[i] = + _CHROFF_5_0_;}
	O4810[844] = + _CHROFF_3_0_;
	O4810[845] = + _CHROFF_5_0_;
	{long i; for (i = 846; i < 848; i++) O4810[i] = + _CHROFF_6_0_;}
	{long i; for (i = 848; i < 850; i++) O4810[i] = + _CHROFF_3_0_;}
	O4810[850] = + _CHROFF_6_0_;
	O4810[1037] = + _CHROFF_5_2_;
}

static EIF_TYPE_INDEX Y4878_pgtype0[] = {348,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4878_pgtype1[] = {349,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y4878_gen_type [2];
EIF_TYPE_INDEX Y4878 [2];
void Y4878_init (void)
{
	egc_routines_types [4878] = Y4878;
	egc_routines_gen_types [4878] = Y4878_gen_type;
	egc_routines_offset [4878] = 348;
	Y4878_gen_type [0] = Y4878_pgtype0;
	Y4878_gen_type [1] = Y4878_pgtype1;
	Y4878[0] = 348;
	Y4878[1] = 349;
}

EIF_TYPE_INDEX *Y5125_gen_type [1];
EIF_TYPE_INDEX Y5125 [1];
void Y5125_init (void)
{
	egc_routines_types [5125] = Y5125;
	egc_routines_gen_types [5125] = Y5125_gen_type;
	egc_routines_offset [5125] = 646;
	Y5125[0] = 984;
}

long O5130[9];
void O5130_init () {
	O5130[0] = 0;
	O5130[1] = + _LNGOFF_5_3_0_0_;
	O5130[2] = 0;
	O5130[3] = + _LNGOFF_4_3_0_0_;
	O5130[4] = + _LNGOFF_4_3_0_1_;
	O5130[5] = + _PTROFF_5_3_0_7_0_0_;
	O5130[6] = 0;
	O5130[7] = + _LNGOFF_5_4_0_0_;
	O5130[8] = 0;
}

long O5139[9];
void O5139_init () {
	O5139[0] = + _LNGOFF_7_3_0_0_;
	O5139[1] = + _LNGOFF_5_3_0_1_;
	O5139[2] = + _LNGOFF_6_3_0_0_;
	O5139[3] = + _LNGOFF_4_3_0_1_;
	O5139[4] = + _LNGOFF_4_3_0_2_;
	O5139[5] = + _LNGOFF_5_3_0_0_;
	O5139[6] = + _LNGOFF_7_4_0_0_;
	O5139[7] = + _LNGOFF_5_4_0_1_;
	O5139[8] = + _LNGOFF_9_3_0_0_;
}

long O5166[9];
void O5166_init () {
	O5166[0] =  + _REFACS_1_;
	O5166[1] = 0;
	O5166[2] =  + _REFACS_1_;
	{long i; for (i = 3; i < 6; i++) O5166[i] = 0;}
	O5166[6] =  + _REFACS_1_;
	O5166[7] = 0;
	O5166[8] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y5166_pgtype0[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5166_pgtype1[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5166_pgtype2[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5166_pgtype3[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5166_pgtype4[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5166_pgtype5[] = {0xFF01,844,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5166_pgtype6[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5166_pgtype7[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5166_pgtype8[] = {0xFF01,834,0,0xFFFF};
EIF_TYPE_INDEX *Y5166_gen_type [9];
EIF_TYPE_INDEX Y5166 [9];
void Y5166_init (void)
{
	egc_routines_types [5166] = Y5166;
	egc_routines_gen_types [5166] = Y5166_gen_type;
	egc_routines_offset [5166] = 647;
	Y5166_gen_type [0] = Y5166_pgtype0;
	Y5166_gen_type [1] = Y5166_pgtype1;
	Y5166_gen_type [2] = Y5166_pgtype2;
	Y5166_gen_type [3] = Y5166_pgtype3;
	Y5166_gen_type [4] = Y5166_pgtype4;
	Y5166_gen_type [5] = Y5166_pgtype5;
	Y5166_gen_type [6] = Y5166_pgtype6;
	Y5166_gen_type [7] = Y5166_pgtype7;
	Y5166_gen_type [8] = Y5166_pgtype8;
	Y5166[0] = 834;
	Y5166[1] = 835;
	Y5166[2] = 834;
	{long i; for (i = 3; i < 5; i++) Y5166[i] = 835;};
	Y5166[5] = 844;
	Y5166[6] = 834;
	Y5166[7] = 835;
	Y5166[8] = 834;
}

long O5167[9];
void O5167_init () {
	O5167[0] =  + _REFACS_2_;
	O5167[1] =  + _REFACS_1_;
	O5167[2] =  + _REFACS_2_;
	{long i; for (i = 3; i < 6; i++) O5167[i] =  + _REFACS_1_;}
	O5167[6] =  + _REFACS_2_;
	O5167[7] =  + _REFACS_1_;
	O5167[8] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y5167_pgtype0[] = {0xFF01,834,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5167_pgtype1[] = {0xFF01,834,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5167_pgtype2[] = {0xFF01,835,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5167_pgtype3[] = {0xFF01,835,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5167_pgtype4[] = {0xFF01,839,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5167_pgtype5[] = {0xFF01,834,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5167_pgtype6[] = {0xFF01,834,0xFF01,1045,0xFFFF};
static EIF_TYPE_INDEX Y5167_pgtype7[] = {0xFF01,834,0xFF01,1045,0xFFFF};
static EIF_TYPE_INDEX Y5167_pgtype8[] = {0xFF01,834,0xFF01,1053,0xFFFF};
EIF_TYPE_INDEX *Y5167_gen_type [9];
EIF_TYPE_INDEX Y5167 [9];
void Y5167_init (void)
{
	egc_routines_types [5167] = Y5167;
	egc_routines_gen_types [5167] = Y5167_gen_type;
	egc_routines_offset [5167] = 647;
	Y5167_gen_type [0] = Y5167_pgtype0;
	Y5167_gen_type [1] = Y5167_pgtype1;
	Y5167_gen_type [2] = Y5167_pgtype2;
	Y5167_gen_type [3] = Y5167_pgtype3;
	Y5167_gen_type [4] = Y5167_pgtype4;
	Y5167_gen_type [5] = Y5167_pgtype5;
	Y5167_gen_type [6] = Y5167_pgtype6;
	Y5167_gen_type [7] = Y5167_pgtype7;
	Y5167_gen_type [8] = Y5167_pgtype8;
	{long i; for (i = 0; i < 2; i++) Y5167[i] = 834;};
	{long i; for (i = 2; i < 4; i++) Y5167[i] = 835;};
	Y5167[4] = 839;
	{long i; for (i = 5; i < 9; i++) Y5167[i] = 834;};
}

long O5168[9];
void O5168_init () {
	O5168[0] =  + _REFACS_3_;
	O5168[1] =  + _REFACS_2_;
	O5168[2] =  + _REFACS_3_;
	{long i; for (i = 3; i < 6; i++) O5168[i] =  + _REFACS_2_;}
	O5168[6] =  + _REFACS_3_;
	O5168[7] =  + _REFACS_2_;
	O5168[8] =  + _REFACS_3_;
}

long O5169[9];
void O5169_init () {
	O5169[0] =  + _REFACS_4_;
	O5169[1] =  + _REFACS_3_;
	O5169[2] =  + _REFACS_4_;
	{long i; for (i = 3; i < 6; i++) O5169[i] =  + _REFACS_3_;}
	O5169[6] =  + _REFACS_4_;
	O5169[7] =  + _REFACS_3_;
	O5169[8] =  + _REFACS_4_;
}

long O5170[9];
void O5170_init () {
	O5170[0] = + _LNGOFF_7_3_0_1_;
	O5170[1] = + _LNGOFF_5_3_0_2_;
	O5170[2] = + _LNGOFF_6_3_0_1_;
	O5170[3] = + _LNGOFF_4_3_0_2_;
	O5170[4] = + _LNGOFF_4_3_0_3_;
	O5170[5] = + _LNGOFF_5_3_0_1_;
	O5170[6] = + _LNGOFF_7_4_0_1_;
	O5170[7] = + _LNGOFF_5_4_0_2_;
	O5170[8] = + _LNGOFF_9_3_0_1_;
}

long O5171[9];
void O5171_init () {
	O5171[0] = + _CHROFF_7_2_;
	O5171[1] = + _CHROFF_5_2_;
	O5171[2] = + _CHROFF_6_2_;
	{long i; for (i = 3; i < 5; i++) O5171[i] = + _CHROFF_4_2_;}
	O5171[5] = + _CHROFF_5_2_;
	O5171[6] = + _CHROFF_7_2_;
	O5171[7] = + _CHROFF_5_2_;
	O5171[8] = + _CHROFF_9_2_;
}

long O5172[9];
void O5172_init () {
	O5172[0] = + _LNGOFF_7_3_0_2_;
	O5172[1] = + _LNGOFF_5_3_0_3_;
	O5172[2] = + _LNGOFF_6_3_0_2_;
	O5172[3] = + _LNGOFF_4_3_0_3_;
	O5172[4] = + _LNGOFF_4_3_0_4_;
	O5172[5] = + _LNGOFF_5_3_0_2_;
	O5172[6] = + _LNGOFF_7_4_0_2_;
	O5172[7] = + _LNGOFF_5_4_0_3_;
	O5172[8] = + _LNGOFF_9_3_0_2_;
}

long O5175[9];
void O5175_init () {
	O5175[0] = + _LNGOFF_7_3_0_3_;
	O5175[1] = + _LNGOFF_5_3_0_4_;
	O5175[2] = + _LNGOFF_6_3_0_3_;
	O5175[3] = + _LNGOFF_4_3_0_4_;
	O5175[4] = + _LNGOFF_4_3_0_5_;
	O5175[5] = + _LNGOFF_5_3_0_3_;
	O5175[6] = + _LNGOFF_7_4_0_3_;
	O5175[7] = + _LNGOFF_5_4_0_4_;
	O5175[8] = + _LNGOFF_9_3_0_3_;
}

long O5176[9];
void O5176_init () {
	O5176[0] = + _LNGOFF_7_3_0_4_;
	O5176[1] = + _LNGOFF_5_3_0_5_;
	O5176[2] = + _LNGOFF_6_3_0_4_;
	O5176[3] = + _LNGOFF_4_3_0_5_;
	O5176[4] = + _LNGOFF_4_3_0_6_;
	O5176[5] = + _LNGOFF_5_3_0_4_;
	O5176[6] = + _LNGOFF_7_4_0_4_;
	O5176[7] = + _LNGOFF_5_4_0_5_;
	O5176[8] = + _LNGOFF_9_3_0_4_;
}

long O5180[9];
void O5180_init () {
	O5180[0] = + _LNGOFF_7_3_0_5_;
	O5180[1] = + _LNGOFF_5_3_0_6_;
	O5180[2] = + _LNGOFF_6_3_0_5_;
	O5180[3] = + _LNGOFF_4_3_0_6_;
	O5180[4] = + _LNGOFF_4_3_0_7_;
	O5180[5] = + _LNGOFF_5_3_0_5_;
	O5180[6] = + _LNGOFF_7_4_0_5_;
	O5180[7] = + _LNGOFF_5_4_0_6_;
	O5180[8] = + _LNGOFF_9_3_0_5_;
}

long O5181[9];
void O5181_init () {
	O5181[0] =  + _REFACS_5_;
	O5181[1] = + _LNGOFF_5_3_0_7_;
	O5181[2] =  + _REFACS_5_;
	O5181[3] = + _LNGOFF_4_3_0_7_;
	O5181[4] = + _LNGOFF_4_3_0_8_;
	O5181[5] = + _PTROFF_5_3_0_7_0_1_;
	O5181[6] =  + _REFACS_5_;
	O5181[7] = + _LNGOFF_5_4_0_7_;
	O5181[8] =  + _REFACS_5_;
}

long O5182[9];
void O5182_init () {
	O5182[0] =  + _REFACS_6_;
	O5182[1] =  + _REFACS_4_;
	O5182[2] = + _LNGOFF_6_3_0_6_;
	O5182[3] = + _LNGOFF_4_3_0_8_;
	O5182[4] = + _LNGOFF_4_3_0_0_;
	O5182[5] =  + _REFACS_4_;
	O5182[6] =  + _REFACS_6_;
	O5182[7] =  + _REFACS_4_;
	O5182[8] =  + _REFACS_6_;
}

long O5216[9];
void O5216_init () {
	O5216[0] = + _LNGOFF_7_3_0_6_;
	O5216[1] = + _LNGOFF_5_3_0_8_;
	O5216[2] = + _LNGOFF_6_3_0_7_;
	{long i; for (i = 3; i < 5; i++) O5216[i] = + _LNGOFF_4_3_0_9_;}
	O5216[5] = + _LNGOFF_5_3_0_6_;
	O5216[6] = + _LNGOFF_7_4_0_6_;
	O5216[7] = + _LNGOFF_5_4_0_8_;
	O5216[8] = + _LNGOFF_9_3_0_6_;
}

long O5219[2];
void O5219_init () {
	O5219[0] = + _CHROFF_7_3_;
	O5219[1] = + _CHROFF_5_3_;
}

long O5244[509];
void O5244_init () {
	{long i; for (i = 0; i < 15; i++) O5244[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 15; i < 17; i++) O5244[i] = + _LNGOFF_1_2_0_0_;}
	{long i; for (i = 17; i < 19; i++) O5244[i] = + _LNGOFF_3_2_0_0_;}
	{long i; for (i = 19; i < 22; i++) O5244[i] = + _LNGOFF_5_2_0_0_;}
	{long i; for (i = 22; i < 24; i++) O5244[i] = + _LNGOFF_9_2_0_0_;}
	O5244[24] = + _LNGOFF_10_2_0_0_;
	{long i; for (i = 25; i < 43; i++) O5244[i] = + _LNGOFF_9_2_0_0_;}
	O5244[508] = + _LNGOFF_7_2_0_0_;
}

long O5252[494];
void O5252_init () {
	{long i; for (i = 0; i < 2; i++) O5252[i] = + _CHROFF_1_1_;}
	{long i; for (i = 2; i < 4; i++) O5252[i] = + _CHROFF_3_1_;}
	{long i; for (i = 4; i < 7; i++) O5252[i] = + _CHROFF_5_1_;}
	{long i; for (i = 7; i < 9; i++) O5252[i] = + _CHROFF_9_1_;}
	O5252[9] = + _CHROFF_10_1_;
	{long i; for (i = 10; i < 28; i++) O5252[i] = + _CHROFF_9_1_;}
	O5252[493] = + _CHROFF_7_1_;
}

static EIF_TYPE_INDEX Y5255_pgtype0[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype1[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype2[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype3[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype4[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFF01,1094,0xFFFF};
EIF_TYPE_INDEX *Y5255_gen_type [5];
EIF_TYPE_INDEX Y5255 [5];
void Y5255_init (void)
{
	egc_routines_types [5255] = Y5255;
	egc_routines_gen_types [5255] = Y5255_gen_type;
	egc_routines_offset [5255] = 673;
	Y5255_gen_type [0] = Y5255_pgtype0;
	Y5255_gen_type [1] = Y5255_pgtype1;
	Y5255_gen_type [2] = Y5255_pgtype2;
	Y5255_gen_type [3] = Y5255_pgtype3;
	Y5255_gen_type [4] = Y5255_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y5255[i] = 678;};
}

static EIF_TYPE_INDEX Y5256_pgtype0[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5256_pgtype1[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5256_pgtype2[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5256_pgtype3[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5256_pgtype4[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFF01,1094,0xFFFF};
EIF_TYPE_INDEX *Y5256_gen_type [5];
EIF_TYPE_INDEX Y5256 [5];
void Y5256_init (void)
{
	egc_routines_types [5256] = Y5256;
	egc_routines_gen_types [5256] = Y5256_gen_type;
	egc_routines_offset [5256] = 673;
	Y5256_gen_type [0] = Y5256_pgtype0;
	Y5256_gen_type [1] = Y5256_pgtype1;
	Y5256_gen_type [2] = Y5256_pgtype2;
	Y5256_gen_type [3] = Y5256_pgtype3;
	Y5256_gen_type [4] = Y5256_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y5256[i] = 678;};
}

static EIF_TYPE_INDEX Y5257_pgtype0[] = {0xFF01,679,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5257_pgtype1[] = {0xFF01,679,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5257_pgtype2[] = {0xFF01,679,0xFF01,0xFFF9,1,966,0xFF01,1094,0xFFFF};
EIF_TYPE_INDEX *Y5257_gen_type [3];
EIF_TYPE_INDEX Y5257 [3];
void Y5257_init (void)
{
	egc_routines_types [5257] = Y5257;
	egc_routines_gen_types [5257] = Y5257_gen_type;
	egc_routines_offset [5257] = 675;
	Y5257_gen_type [0] = Y5257_pgtype0;
	Y5257_gen_type [1] = Y5257_pgtype1;
	Y5257_gen_type [2] = Y5257_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y5257[i] = 679;};
}

static EIF_TYPE_INDEX Y5258_pgtype0[] = {0xFF01,679,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5258_pgtype1[] = {0xFF01,679,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5258_pgtype2[] = {0xFF01,679,0xFF01,0xFFF9,1,966,0xFF01,1094,0xFFFF};
EIF_TYPE_INDEX *Y5258_gen_type [3];
EIF_TYPE_INDEX Y5258 [3];
void Y5258_init (void)
{
	egc_routines_types [5258] = Y5258;
	egc_routines_gen_types [5258] = Y5258_gen_type;
	egc_routines_offset [5258] = 675;
	Y5258_gen_type [0] = Y5258_pgtype0;
	Y5258_gen_type [1] = Y5258_pgtype1;
	Y5258_gen_type [2] = Y5258_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y5258[i] = 679;};
}

long O5271[21];
void O5271_init () {
	{long i; for (i = 0; i < 2; i++) O5271[i] = + _LNGOFF_9_2_0_1_;}
	O5271[2] = + _LNGOFF_10_2_0_1_;
	{long i; for (i = 3; i < 21; i++) O5271[i] = + _LNGOFF_9_2_0_1_;}
}

long O5413[510];
void O5413_init () {
	{long i; for (i = 0; i < 4; i++) O5413[i] = + _LNGOFF_0_0_0_0_;}
	O5413[4] = + _LNGOFF_13_16_0_4_;
	O5413[219] = + _LNGOFF_15_11_0_0_;
	O5413[221] = + _LNGOFF_1_0_0_0_;
	O5413[504] = + _LNGOFF_1_1_0_0_;
	O5413[509] = + _LNGOFF_49_16_0_2_;
}

long O5523[21];
void O5523_init () {
	{long i; for (i = 0; i < 12; i++) O5523[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 12; i < 15; i++) O5523[i] = + _LNGOFF_2_1_0_0_;}
	{long i; for (i = 15; i < 21; i++) O5523[i] = + _LNGOFF_1_1_0_0_;}
}

long O5527[21];
void O5527_init () {
	{long i; for (i = 0; i < 12; i++) O5527[i] = + _CHROFF_1_0_;}
	{long i; for (i = 12; i < 15; i++) O5527[i] = + _CHROFF_2_0_;}
	{long i; for (i = 15; i < 21; i++) O5527[i] = + _CHROFF_1_0_;}
}

long O5528[21];
void O5528_init () {
	{long i; for (i = 0; i < 12; i++) O5528[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 12; i < 15; i++) O5528[i] = + _LNGOFF_2_1_0_1_;}
	{long i; for (i = 15; i < 21; i++) O5528[i] = + _LNGOFF_1_1_0_1_;}
}

long O5529[21];
void O5529_init () {
	{long i; for (i = 0; i < 12; i++) O5529[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 12; i < 15; i++) O5529[i] = + _LNGOFF_2_1_0_2_;}
	{long i; for (i = 15; i < 21; i++) O5529[i] = + _LNGOFF_1_1_0_2_;}
}

long O5530[21];
void O5530_init () {
	{long i; for (i = 0; i < 12; i++) O5530[i] = + _LNGOFF_1_1_0_3_;}
	{long i; for (i = 12; i < 15; i++) O5530[i] = + _LNGOFF_2_1_0_3_;}
	{long i; for (i = 15; i < 21; i++) O5530[i] = + _LNGOFF_1_1_0_3_;}
}

long O5531[21];
void O5531_init () {
	{long i; for (i = 0; i < 12; i++) O5531[i] = + _LNGOFF_1_1_0_4_;}
	{long i; for (i = 12; i < 15; i++) O5531[i] = + _LNGOFF_2_1_0_4_;}
	{long i; for (i = 15; i < 21; i++) O5531[i] = + _LNGOFF_1_1_0_4_;}
}

long O5534[50];
void O5534_init () {
	{long i; for (i = 0; i < 12; i++) O5534[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 12; i < 38; i++) O5534[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 38; i < 50; i++) O5534[i] = + _LNGOFF_1_0_0_0_;}
}

long O5536[50];
void O5536_init () {
	{long i; for (i = 0; i < 12; i++) O5536[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 12; i < 38; i++) O5536[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 38; i < 50; i++) O5536[i] = + _LNGOFF_1_0_0_1_;}
}

long O5716[10];
void O5716_init () {
	O5716[0] = + _CHROFF_8_0_;
	O5716[1] = + _CHROFF_10_0_;
	{long i; for (i = 2; i < 10; i++) O5716[i] = + _CHROFF_9_0_;}
}

long O5717[10];
void O5717_init () {
	O5717[0] = + _CHROFF_8_1_;
	O5717[1] = + _CHROFF_10_1_;
	{long i; for (i = 2; i < 10; i++) O5717[i] = + _CHROFF_9_1_;}
}

long O6097[457];
void O6097_init () {
	O6097[0] = + _CHROFF_1_0_;
	O6097[1] = + _CHROFF_2_0_;
	O6097[2] = + _CHROFF_3_0_;
	O6097[3] = + _CHROFF_4_0_;
	O6097[4] = + _CHROFF_5_0_;
	O6097[456] = + _CHROFF_5_0_;
}

long O6214[455];
void O6214_init () {
	O6214[0] = + _PTROFF_3_6_2_4_1_0_;
	O6214[1] = + _PTROFF_4_6_2_4_1_0_;
	O6214[2] = + _PTROFF_5_7_2_4_1_0_;
	O6214[454] = + _PTROFF_5_7_2_4_1_0_;
}

long O6353[455];
void O6353_init () {
	O6353[0] = + _LNGOFF_3_6_2_3_;
	O6353[1] = + _LNGOFF_4_6_2_3_;
	O6353[2] = + _LNGOFF_5_7_2_3_;
	O6353[454] = + _LNGOFF_5_7_2_3_;
}

long O6362[455];
void O6362_init () {
	O6362[0] = + _CHROFF_3_3_;
	O6362[1] = + _CHROFF_4_3_;
	O6362[2] = + _CHROFF_5_3_;
	O6362[454] = + _CHROFF_5_3_;
}

long O6502[443];
void O6502_init () {
	O6502[0] = + _LNGOFF_0_0_0_0_;
	O6502[1] = + _LNGOFF_1_0_0_1_;
	{long i; for (i = 2; i < 4; i++) O6502[i] = + _LNGOFF_0_0_0_0_;}
	O6502[4] = + _LNGOFF_2_0_0_0_;
	O6502[5] = + _LNGOFF_0_1_0_0_;
	O6502[182] = + _LNGOFF_2_0_0_0_;
	O6502[199] = + _LNGOFF_4_0_0_0_;
	O6502[203] = + _LNGOFF_5_2_0_0_;
	{long i; for (i = 204; i < 211; i++) O6502[i] = + _LNGOFF_6_3_0_0_;}
	O6502[211] = + _LNGOFF_10_3_0_0_;
	{long i; for (i = 212; i < 217; i++) O6502[i] = + _LNGOFF_6_3_0_0_;}
	O6502[217] = + _LNGOFF_6_4_0_0_;
	O6502[218] = + _LNGOFF_6_3_0_0_;
	{long i; for (i = 219; i < 221; i++) O6502[i] = + _LNGOFF_12_3_0_0_;}
	O6502[221] = + _LNGOFF_6_3_0_0_;
	O6502[222] = + _LNGOFF_7_4_0_0_;
	{long i; for (i = 223; i < 225; i++) O6502[i] = + _LNGOFF_14_3_0_0_;}
	{long i; for (i = 225; i < 228; i++) O6502[i] = + _LNGOFF_5_2_0_0_;}
	O6502[228] = + _LNGOFF_6_3_0_0_;
	O6502[229] = + _LNGOFF_5_2_0_0_;
	O6502[230] = + _LNGOFF_6_2_0_0_;
	{long i; for (i = 231; i < 235; i++) O6502[i] = + _LNGOFF_5_2_0_0_;}
	{long i; for (i = 235; i < 239; i++) O6502[i] = + _LNGOFF_6_2_0_0_;}
	{long i; for (i = 239; i < 241; i++) O6502[i] = + _LNGOFF_6_0_0_0_;}
	O6502[241] = + _LNGOFF_7_2_0_1_;
	{long i; for (i = 242; i < 250; i++) O6502[i] = + _LNGOFF_6_0_0_0_;}
	{long i; for (i = 251; i < 256; i++) O6502[i] = + _LNGOFF_5_3_0_0_;}
	O6502[257] = + _LNGOFF_5_3_0_0_;
	{long i; for (i = 258; i < 260; i++) O6502[i] = + _LNGOFF_6_1_0_0_;}
	O6502[262] = + _LNGOFF_6_1_0_0_;
	O6502[268] = + _LNGOFF_2_4_0_0_;
	O6502[270] = + _LNGOFF_2_2_0_1_;
	O6502[289] = + _LNGOFF_49_16_0_3_;
	O6502[290] = + _LNGOFF_2_3_0_0_;
	O6502[291] = + _LNGOFF_4_3_0_0_;
	O6502[292] = + _LNGOFF_5_5_0_0_;
	O6502[293] = + _LNGOFF_10_10_0_0_;
	O6502[308] = + _LNGOFF_6_3_0_0_;
	O6502[332] = + _LNGOFF_8_5_0_0_;
	O6502[333] = + _LNGOFF_9_5_0_0_;
	O6502[337] = + _LNGOFF_11_5_0_0_;
	O6502[338] = + _LNGOFF_11_6_0_0_;
	O6502[339] = + _LNGOFF_11_5_0_0_;
	O6502[341] = + _LNGOFF_16_7_6_0_;
	O6502[343] = + _LNGOFF_42_12_10_0_;
	O6502[345] = + _LNGOFF_46_12_10_0_;
	O6502[349] = + _LNGOFF_47_12_10_0_;
	O6502[350] = + _LNGOFF_49_12_10_0_;
	O6502[351] = + _LNGOFF_47_12_10_0_;
	{long i; for (i = 355; i < 358; i++) O6502[i] = + _LNGOFF_49_13_10_0_;}
	O6502[362] = + _LNGOFF_49_13_10_0_;
	O6502[363] = + _LNGOFF_51_13_10_0_;
	{long i; for (i = 364; i < 366; i++) O6502[i] = + _LNGOFF_49_14_10_0_;}
	O6502[370] = + _LNGOFF_59_21_10_0_;
	O6502[371] = + _LNGOFF_59_23_10_0_;
	O6502[372] = + _LNGOFF_65_25_10_0_;
	O6502[373] = + _LNGOFF_68_26_10_0_;
	O6502[391] = + _LNGOFF_42_13_10_0_;
	O6502[392] = + _LNGOFF_44_13_10_0_;
	O6502[393] = + _LNGOFF_58_14_10_0_;
	O6502[394] = + _LNGOFF_51_13_10_0_;
	O6502[395] = + _LNGOFF_45_16_10_0_;
	O6502[396] = + _LNGOFF_44_13_10_0_;
	O6502[397] = + _LNGOFF_50_13_10_0_;
	O6502[398] = + _LNGOFF_51_14_10_0_;
	O6502[399] = + _LNGOFF_43_13_10_0_;
	O6502[400] = + _LNGOFF_46_14_10_0_;
	O6502[401] = + _LNGOFF_59_16_10_0_;
	O6502[402] = + _LNGOFF_44_15_10_0_;
	O6502[403] = + _LNGOFF_51_18_10_0_;
	{long i; for (i = 404; i < 408; i++) O6502[i] = + _LNGOFF_46_14_10_0_;}
	{long i; for (i = 416; i < 418; i++) O6502[i] = + _LNGOFF_21_7_6_0_;}
	O6502[423] = + _LNGOFF_23_8_6_0_;
	{long i; for (i = 424; i < 426; i++) O6502[i] = + _LNGOFF_23_9_6_0_;}
	O6502[426] = + _LNGOFF_24_9_6_0_;
	O6502[427] = + _LNGOFF_26_8_6_0_;
	{long i; for (i = 432; i < 434; i++) O6502[i] = + _LNGOFF_29_14_8_0_;}
	O6502[440] = + _LNGOFF_48_19_10_0_;
	O6502[442] = + _LNGOFF_48_18_10_0_;
}

long O6562[259];
void O6562_init () {
	O6562[0] =  + _REFACS_1_;
	O6562[195] =  + _REFACS_1_;
	{long i; for (i = 199; i < 215; i++) O6562[i] =  + _REFACS_1_;}
	{long i; for (i = 215; i < 217; i++) O6562[i] =  + _REFACS_7_;}
	{long i; for (i = 217; i < 237; i++) O6562[i] =  + _REFACS_1_;}
	O6562[237] =  + _REFACS_2_;
	{long i; for (i = 238; i < 246; i++) O6562[i] =  + _REFACS_1_;}
	{long i; for (i = 247; i < 252; i++) O6562[i] =  + _REFACS_1_;}
	{long i; for (i = 253; i < 256; i++) O6562[i] =  + _REFACS_1_;}
	O6562[258] =  + _REFACS_1_;
}

long O7450[6];
void O7450_init () {
	{long i; for (i = 0; i < 2; i++) O7450[i] = + _CHROFF_4_0_;}
	O7450[2] = + _CHROFF_5_0_;
	{long i; for (i = 3; i < 6; i++) O7450[i] = + _CHROFF_4_0_;}
}

long O7451[6];
void O7451_init () {
	{long i; for (i = 0; i < 2; i++) O7451[i] = + _LNGOFF_4_2_0_0_;}
	O7451[2] = + _LNGOFF_5_2_0_0_;
	O7451[3] = + _LNGOFF_4_3_0_0_;
	O7451[4] = + _LNGOFF_4_2_0_0_;
	O7451[5] = + _LNGOFF_4_3_0_0_;
}

long O7459[6];
void O7459_init () {
	{long i; for (i = 0; i < 2; i++) O7459[i] = + _PTROFF_4_2_0_3_0_0_;}
	O7459[2] = + _PTROFF_5_2_0_3_0_0_;
	O7459[3] = + _PTROFF_4_3_0_3_0_0_;
	O7459[4] = + _PTROFF_4_2_0_3_0_0_;
	O7459[5] = + _PTROFF_4_3_0_3_0_0_;
}

long O7460[6];
void O7460_init () {
	{long i; for (i = 0; i < 2; i++) O7460[i] = + _PTROFF_4_2_0_3_0_1_;}
	O7460[2] = + _PTROFF_5_2_0_3_0_1_;
	O7460[3] = + _PTROFF_4_3_0_3_0_1_;
	O7460[4] = + _PTROFF_4_2_0_3_0_1_;
	O7460[5] = + _PTROFF_4_3_0_3_0_1_;
}

long O7462[6];
void O7462_init () {
	{long i; for (i = 0; i < 2; i++) O7462[i] = + _PTROFF_4_2_0_3_0_2_;}
	O7462[2] = + _PTROFF_5_2_0_3_0_2_;
	O7462[3] = + _PTROFF_4_3_0_3_0_2_;
	O7462[4] = + _PTROFF_4_2_0_3_0_2_;
	O7462[5] = + _PTROFF_4_3_0_3_0_2_;
}

long O7463[6];
void O7463_init () {
	{long i; for (i = 0; i < 2; i++) O7463[i] = + _LNGOFF_4_2_0_1_;}
	O7463[2] = + _LNGOFF_5_2_0_1_;
	O7463[3] = + _LNGOFF_4_3_0_1_;
	O7463[4] = + _LNGOFF_4_2_0_1_;
	O7463[5] = + _LNGOFF_4_3_0_1_;
}

long O7464[6];
void O7464_init () {
	{long i; for (i = 0; i < 2; i++) O7464[i] = + _CHROFF_4_1_;}
	O7464[2] = + _CHROFF_5_1_;
	{long i; for (i = 3; i < 6; i++) O7464[i] = + _CHROFF_4_1_;}
}

long O7465[6];
void O7465_init () {
	{long i; for (i = 0; i < 2; i++) O7465[i] = + _LNGOFF_4_2_0_2_;}
	O7465[2] = + _LNGOFF_5_2_0_2_;
	O7465[3] = + _LNGOFF_4_3_0_2_;
	O7465[4] = + _LNGOFF_4_2_0_2_;
	O7465[5] = + _LNGOFF_4_3_0_2_;
}

long O7478[4];
void O7478_init () {
	O7478[0] =  + _REFACS_4_;
	O7478[1] = + _CHROFF_4_2_;
	O7478[2] = + _PTROFF_4_2_0_3_0_3_;
	O7478[3] = + _CHROFF_4_2_;
}

long O7577[10];
void O7577_init () {
	{long i; for (i = 0; i < 3; i++) O7577[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O7577[i] = + _LNGOFF_1_0_0_0_;}
	O7577[5] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 6; i < 8; i++) O7577[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 8; i < 10; i++) O7577[i] = + _LNGOFF_1_1_0_0_;}
}

long O7578[10];
void O7578_init () {
	{long i; for (i = 0; i < 3; i++) O7578[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O7578[i] = + _LNGOFF_1_0_0_1_;}
	O7578[5] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 6; i < 8; i++) O7578[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 8; i < 10; i++) O7578[i] = + _LNGOFF_1_1_0_1_;}
}

long O7643[3];
void O7643_init () {
	{long i; for (i = 0; i < 2; i++) O7643[i] = + _LNGOFF_1_0_0_2_;}
	O7643[2] = + _LNGOFF_1_1_0_2_;
}

long O7723[4];
void O7723_init () {
	{long i; for (i = 0; i < 2; i++) O7723[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 4; i++) O7723[i] = + _LNGOFF_1_1_0_2_;}
}

long O7883[105];
void O7883_init () {
	{long i; for (i = 0; i < 40; i++) O7883[i] = 0;}
	O7883[40] =  + _REFACS_2_;
	{long i; for (i = 41; i < 44; i++) O7883[i] = 0;}
	{long i; for (i = 44; i < 60; i++) O7883[i] =  + _REFACS_2_;}
	{long i; for (i = 60; i < 62; i++) O7883[i] =  + _REFACS_8_;}
	{long i; for (i = 62; i < 82; i++) O7883[i] =  + _REFACS_2_;}
	O7883[82] =  + _REFACS_3_;
	{long i; for (i = 83; i < 91; i++) O7883[i] =  + _REFACS_2_;}
	O7883[91] = 0;
	{long i; for (i = 92; i < 97; i++) O7883[i] =  + _REFACS_2_;}
	O7883[97] = 0;
	{long i; for (i = 98; i < 101; i++) O7883[i] =  + _REFACS_2_;}
	{long i; for (i = 101; i < 103; i++) O7883[i] = 0;}
	O7883[103] =  + _REFACS_2_;
	O7883[104] = 0;
}

long O7887[105];
void O7887_init () {
	{long i; for (i = 0; i < 40; i++) O7887[i] =  + _REFACS_1_;}
	O7887[40] =  + _REFACS_3_;
	{long i; for (i = 41; i < 44; i++) O7887[i] =  + _REFACS_1_;}
	{long i; for (i = 44; i < 60; i++) O7887[i] =  + _REFACS_3_;}
	{long i; for (i = 60; i < 62; i++) O7887[i] =  + _REFACS_9_;}
	{long i; for (i = 62; i < 82; i++) O7887[i] =  + _REFACS_3_;}
	O7887[82] =  + _REFACS_4_;
	{long i; for (i = 83; i < 91; i++) O7887[i] =  + _REFACS_3_;}
	O7887[91] =  + _REFACS_1_;
	{long i; for (i = 92; i < 97; i++) O7887[i] =  + _REFACS_3_;}
	O7887[97] =  + _REFACS_1_;
	{long i; for (i = 98; i < 101; i++) O7887[i] =  + _REFACS_3_;}
	{long i; for (i = 101; i < 103; i++) O7887[i] =  + _REFACS_1_;}
	O7887[103] =  + _REFACS_3_;
	O7887[104] =  + _REFACS_1_;
}

long O8078[91];
void O8078_init () {
	O8078[0] =  + _REFACS_2_;
	{long i; for (i = 28; i < 31; i++) O8078[i] =  + _REFACS_2_;}
	{long i; for (i = 31; i < 47; i++) O8078[i] =  + _REFACS_4_;}
	{long i; for (i = 47; i < 49; i++) O8078[i] =  + _REFACS_10_;}
	{long i; for (i = 49; i < 69; i++) O8078[i] =  + _REFACS_4_;}
	O8078[69] =  + _REFACS_5_;
	{long i; for (i = 70; i < 78; i++) O8078[i] =  + _REFACS_4_;}
	O8078[78] =  + _REFACS_2_;
	{long i; for (i = 79; i < 84; i++) O8078[i] =  + _REFACS_4_;}
	O8078[84] =  + _REFACS_2_;
	{long i; for (i = 85; i < 88; i++) O8078[i] =  + _REFACS_4_;}
	{long i; for (i = 88; i < 90; i++) O8078[i] =  + _REFACS_2_;}
	O8078[90] =  + _REFACS_4_;
}

long O8362[55];
void O8362_init () {
	O8362[0] = + _CHROFF_5_0_;
	{long i; for (i = 1; i < 8; i++) O8362[i] = + _CHROFF_6_1_;}
	O8362[8] = + _CHROFF_10_1_;
	{long i; for (i = 9; i < 16; i++) O8362[i] = + _CHROFF_6_1_;}
	{long i; for (i = 16; i < 18; i++) O8362[i] = + _CHROFF_12_1_;}
	O8362[18] = + _CHROFF_6_1_;
	O8362[19] = + _CHROFF_7_1_;
	{long i; for (i = 20; i < 22; i++) O8362[i] = + _CHROFF_14_1_;}
	{long i; for (i = 22; i < 25; i++) O8362[i] = + _CHROFF_5_0_;}
	O8362[25] = + _CHROFF_6_0_;
	O8362[26] = + _CHROFF_5_0_;
	O8362[27] = + _CHROFF_6_0_;
	{long i; for (i = 28; i < 32; i++) O8362[i] = + _CHROFF_5_0_;}
	{long i; for (i = 32; i < 36; i++) O8362[i] = + _CHROFF_6_0_;}
	{long i; for (i = 48; i < 53; i++) O8362[i] = + _CHROFF_5_1_;}
	O8362[54] = + _CHROFF_5_1_;
}

long O8363[55];
void O8363_init () {
	O8363[0] = + _CHROFF_5_1_;
	{long i; for (i = 1; i < 8; i++) O8363[i] = + _CHROFF_6_2_;}
	O8363[8] = + _CHROFF_10_2_;
	{long i; for (i = 9; i < 16; i++) O8363[i] = + _CHROFF_6_2_;}
	{long i; for (i = 16; i < 18; i++) O8363[i] = + _CHROFF_12_2_;}
	O8363[18] = + _CHROFF_6_2_;
	O8363[19] = + _CHROFF_7_2_;
	{long i; for (i = 20; i < 22; i++) O8363[i] = + _CHROFF_14_2_;}
	{long i; for (i = 22; i < 25; i++) O8363[i] = + _CHROFF_5_1_;}
	O8363[25] = + _CHROFF_6_1_;
	O8363[26] = + _CHROFF_5_1_;
	O8363[27] = + _CHROFF_6_1_;
	{long i; for (i = 28; i < 32; i++) O8363[i] = + _CHROFF_5_1_;}
	{long i; for (i = 32; i < 36; i++) O8363[i] = + _CHROFF_6_1_;}
	{long i; for (i = 48; i < 53; i++) O8363[i] = + _CHROFF_5_2_;}
	O8363[54] = + _CHROFF_5_2_;
}

long O8822[182];
void O8822_init () {
	{long i; for (i = 0; i < 24; i++) O8822[i] = 0;}
	O8822[24] =  + _REFACS_22_;
	O8822[25] =  + _REFACS_23_;
	{long i; for (i = 26; i < 35; i++) O8822[i] = 0;}
	O8822[35] =  + _REFACS_1_;
	O8822[36] = 0;
	O8822[37] =  + _REFACS_1_;
	{long i; for (i = 38; i < 40; i++) O8822[i] = 0;}
	{long i; for (i = 40; i < 42; i++) O8822[i] =  + _REFACS_5_;}
	O8822[42] = 0;
	{long i; for (i = 43; i < 45; i++) O8822[i] =  + _REFACS_1_;}
	{long i; for (i = 45; i < 49; i++) O8822[i] = 0;}
	{long i; for (i = 49; i < 51; i++) O8822[i] =  + _REFACS_1_;}
	{long i; for (i = 51; i < 66; i++) O8822[i] = 0;}
	{long i; for (i = 66; i < 76; i++) O8822[i] =  + _REFACS_2_;}
	{long i; for (i = 76; i < 78; i++) O8822[i] =  + _REFACS_7_;}
	{long i; for (i = 78; i < 80; i++) O8822[i] =  + _REFACS_24_;}
	{long i; for (i = 80; i < 83; i++) O8822[i] =  + _REFACS_25_;}
	O8822[83] =  + _REFACS_26_;
	{long i; for (i = 84; i < 86; i++) O8822[i] =  + _REFACS_25_;}
	O8822[86] =  + _REFACS_26_;
	O8822[87] =  + _REFACS_25_;
	{long i; for (i = 88; i < 102; i++) O8822[i] =  + _REFACS_26_;}
	{long i; for (i = 102; i < 104; i++) O8822[i] =  + _REFACS_30_;}
	{long i; for (i = 104; i < 106; i++) O8822[i] =  + _REFACS_33_;}
	{long i; for (i = 106; i < 108; i++) O8822[i] =  + _REFACS_30_;}
	{long i; for (i = 108; i < 110; i++) O8822[i] =  + _REFACS_33_;}
	O8822[110] =  + _REFACS_24_;
	O8822[111] =  + _REFACS_25_;
	O8822[112] =  + _REFACS_28_;
	O8822[113] =  + _REFACS_26_;
	O8822[114] =  + _REFACS_25_;
	O8822[115] =  + _REFACS_24_;
	{long i; for (i = 116; i < 118; i++) O8822[i] =  + _REFACS_26_;}
	O8822[118] =  + _REFACS_25_;
	O8822[119] =  + _REFACS_26_;
	O8822[120] =  + _REFACS_30_;
	O8822[121] =  + _REFACS_25_;
	O8822[122] =  + _REFACS_28_;
	{long i; for (i = 123; i < 127; i++) O8822[i] =  + _REFACS_25_;}
	O8822[127] =  + _REFACS_24_;
	O8822[128] =  + _REFACS_25_;
	O8822[129] =  + _REFACS_28_;
	O8822[130] =  + _REFACS_26_;
	O8822[131] =  + _REFACS_25_;
	O8822[132] =  + _REFACS_24_;
	{long i; for (i = 133; i < 135; i++) O8822[i] =  + _REFACS_26_;}
	O8822[135] =  + _REFACS_25_;
	O8822[136] =  + _REFACS_26_;
	O8822[137] =  + _REFACS_30_;
	O8822[138] =  + _REFACS_25_;
	O8822[139] =  + _REFACS_28_;
	{long i; for (i = 140; i < 144; i++) O8822[i] =  + _REFACS_25_;}
	O8822[144] =  + _REFACS_10_;
	{long i; for (i = 145; i < 147; i++) O8822[i] =  + _REFACS_12_;}
	O8822[147] =  + _REFACS_10_;
	{long i; for (i = 148; i < 152; i++) O8822[i] =  + _REFACS_14_;}
	{long i; for (i = 152; i < 154; i++) O8822[i] =  + _REFACS_10_;}
	{long i; for (i = 154; i < 158; i++) O8822[i] =  + _REFACS_11_;}
	O8822[158] =  + _REFACS_12_;
	{long i; for (i = 159; i < 163; i++) O8822[i] =  + _REFACS_11_;}
	{long i; for (i = 163; i < 166; i++) O8822[i] =  + _REFACS_12_;}
	{long i; for (i = 166; i < 170; i++) O8822[i] =  + _REFACS_14_;}
	O8822[170] = 0;
	O8822[171] =  + _REFACS_25_;
	O8822[172] = 0;
	O8822[173] =  + _REFACS_25_;
	{long i; for (i = 174; i < 176; i++) O8822[i] = 0;}
	O8822[176] =  + _REFACS_25_;
	O8822[177] = 0;
	O8822[178] =  + _REFACS_25_;
	{long i; for (i = 179; i < 182; i++) O8822[i] = 0;}
}

static EIF_TYPE_INDEX Y8822_pgtype0[] = {1124,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8822_pgtype1[] = {1124,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8822_pgtype2[] = {1173,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8822_pgtype3[] = {1173,0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y8822_pgtype4[] = {1173,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y8822_pgtype5[] = {1173,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y8822_gen_type [182];
EIF_TYPE_INDEX Y8822 [182];
void Y8822_init (void)
{
	egc_routines_types [8822] = Y8822;
	egc_routines_gen_types [8822] = Y8822_gen_type;
	egc_routines_offset [8822] = 1187;
	Y8822_gen_type [31] = Y8822_pgtype0;
	Y8822_gen_type [32] = Y8822_pgtype1;
	Y8822_gen_type [33] = Y8822_pgtype2;
	Y8822_gen_type [34] = Y8822_pgtype3;
	Y8822_gen_type [35] = Y8822_pgtype4;
	Y8822_gen_type [36] = Y8822_pgtype5;
	Y8822[0] = 1082;
	{long i; for (i = 1; i < 3; i++) Y8822[i] = 1083;};
	{long i; for (i = 3; i < 5; i++) Y8822[i] = 1084;};
	{long i; for (i = 5; i < 7; i++) Y8822[i] = 1085;};
	Y8822[7] = 1086;
	{long i; for (i = 8; i < 10; i++) Y8822[i] = 1087;};
	{long i; for (i = 10; i < 12; i++) Y8822[i] = 1088;};
	{long i; for (i = 12; i < 14; i++) Y8822[i] = 1089;};
	Y8822[14] = 1097;
	{long i; for (i = 15; i < 17; i++) Y8822[i] = 1090;};
	{long i; for (i = 17; i < 19; i++) Y8822[i] = 1091;};
	{long i; for (i = 19; i < 21; i++) Y8822[i] = 1092;};
	Y8822[21] = 1093;
	{long i; for (i = 22; i < 24; i++) Y8822[i] = 1094;};
	{long i; for (i = 24; i < 26; i++) Y8822[i] = 1098;};
	{long i; for (i = 26; i < 29; i++) Y8822[i] = 1082;};
	Y8822[29] = 1086;
	Y8822[30] = 1096;
	{long i; for (i = 31; i < 33; i++) Y8822[i] = 1124;};
	{long i; for (i = 33; i < 37; i++) Y8822[i] = 1173;};
	Y8822[37] = 1183;
	{long i; for (i = 38; i < 40; i++) Y8822[i] = 1100;};
	{long i; for (i = 40; i < 42; i++) Y8822[i] = 1101;};
	Y8822[42] = 1103;
	{long i; for (i = 43; i < 45; i++) Y8822[i] = 1184;};
	Y8822[45] = 1104;
	Y8822[46] = 1106;
	{long i; for (i = 47; i < 49; i++) Y8822[i] = 1102;};
	{long i; for (i = 49; i < 51; i++) Y8822[i] = 1105;};
	{long i; for (i = 51; i < 53; i++) Y8822[i] = 1125;};
	Y8822[53] = 1109;
	Y8822[54] = 1110;
	Y8822[55] = 1122;
	{long i; for (i = 56; i < 58; i++) Y8822[i] = 1108;};
	{long i; for (i = 58; i < 60; i++) Y8822[i] = 1107;};
	{long i; for (i = 60; i < 62; i++) Y8822[i] = 1113;};
	{long i; for (i = 62; i < 65; i++) Y8822[i] = 1111;};
	Y8822[65] = 1093;
	{long i; for (i = 66; i < 69; i++) Y8822[i] = 1117;};
	Y8822[69] = 1118;
	{long i; for (i = 70; i < 73; i++) Y8822[i] = 1117;};
	Y8822[73] = 1119;
	Y8822[74] = 1120;
	Y8822[75] = 1121;
	{long i; for (i = 76; i < 78; i++) Y8822[i] = 1122;};
	{long i; for (i = 78; i < 80; i++) Y8822[i] = 1126;};
	{long i; for (i = 80; i < 82; i++) Y8822[i] = 1127;};
	Y8822[82] = 1128;
	Y8822[83] = 1129;
	Y8822[84] = 1130;
	Y8822[85] = 1128;
	Y8822[86] = 1129;
	Y8822[87] = 1130;
	Y8822[88] = 1131;
	Y8822[89] = 1133;
	Y8822[90] = 1132;
	Y8822[91] = 1131;
	Y8822[92] = 1133;
	Y8822[93] = 1132;
	Y8822[94] = 1135;
	Y8822[95] = 1136;
	{long i; for (i = 96; i < 99; i++) Y8822[i] = 1135;};
	Y8822[99] = 1136;
	Y8822[100] = 1137;
	Y8822[101] = 1138;
	Y8822[102] = 1139;
	Y8822[103] = 1140;
	Y8822[104] = 1141;
	Y8822[105] = 1144;
	Y8822[106] = 1139;
	Y8822[107] = 1140;
	Y8822[108] = 1141;
	Y8822[109] = 1144;
	Y8822[110] = 1148;
	Y8822[111] = 1149;
	Y8822[112] = 1174;
	Y8822[113] = 1180;
	Y8822[114] = 1175;
	Y8822[115] = 1152;
	Y8822[116] = 1176;
	Y8822[117] = 1177;
	Y8822[118] = 1154;
	Y8822[119] = 1155;
	Y8822[120] = 1178;
	Y8822[121] = 1156;
	Y8822[122] = 1157;
	Y8822[123] = 1158;
	Y8822[124] = 1159;
	Y8822[125] = 1160;
	Y8822[126] = 1161;
	Y8822[127] = 1148;
	Y8822[128] = 1149;
	Y8822[129] = 1174;
	Y8822[130] = 1180;
	Y8822[131] = 1175;
	Y8822[132] = 1152;
	Y8822[133] = 1176;
	Y8822[134] = 1177;
	Y8822[135] = 1154;
	Y8822[136] = 1155;
	Y8822[137] = 1178;
	Y8822[138] = 1156;
	Y8822[139] = 1157;
	Y8822[140] = 1158;
	Y8822[141] = 1159;
	Y8822[142] = 1160;
	Y8822[143] = 1161;
	Y8822[144] = 1162;
	{long i; for (i = 145; i < 147; i++) Y8822[i] = 1163;};
	Y8822[147] = 1162;
	Y8822[148] = 1181;
	Y8822[149] = 1182;
	Y8822[150] = 1181;
	Y8822[151] = 1182;
	Y8822[152] = 1162;
	Y8822[153] = 1166;
	Y8822[154] = 1169;
	Y8822[155] = 1170;
	Y8822[156] = 1171;
	Y8822[157] = 1169;
	Y8822[158] = 1185;
	Y8822[159] = 1169;
	Y8822[160] = 1170;
	Y8822[161] = 1171;
	Y8822[162] = 1172;
	Y8822[163] = 1185;
	{long i; for (i = 164; i < 166; i++) Y8822[i] = 1164;};
	Y8822[166] = 1167;
	Y8822[167] = 1168;
	Y8822[168] = 1167;
	Y8822[169] = 1168;
	Y8822[170] = 1114;
	Y8822[171] = 1150;
	Y8822[172] = 1115;
	Y8822[173] = 1151;
	Y8822[174] = 1116;
	Y8822[175] = 1114;
	Y8822[176] = 1150;
	Y8822[177] = 1115;
	Y8822[178] = 1151;
	Y8822[179] = 1116;
	{long i; for (i = 180; i < 182; i++) Y8822[i] = 1186;};
}

long O8823[182];
void O8823_init () {
	{long i; for (i = 0; i < 4; i++) O8823[i] = + _CHROFF_1_0_;}
	O8823[4] = + _CHROFF_2_3_;
	O8823[5] = + _CHROFF_1_1_;
	O8823[6] = + _CHROFF_2_1_;
	{long i; for (i = 7; i < 10; i++) O8823[i] = + _CHROFF_1_0_;}
	O8823[10] = + _CHROFF_2_1_;
	O8823[11] = + _CHROFF_4_1_;
	O8823[12] = + _CHROFF_1_0_;
	{long i; for (i = 13; i < 16; i++) O8823[i] = + _CHROFF_2_0_;}
	O8823[16] = + _CHROFF_3_1_;
	{long i; for (i = 17; i < 22; i++) O8823[i] = + _CHROFF_1_0_;}
	O8823[22] = + _CHROFF_2_1_;
	O8823[23] = + _CHROFF_3_4_;
	O8823[24] = + _CHROFF_40_8_;
	O8823[25] = + _CHROFF_49_15_;
	O8823[26] = + _CHROFF_2_2_;
	O8823[27] = + _CHROFF_4_2_;
	O8823[28] = + _CHROFF_5_4_;
	O8823[29] = + _CHROFF_10_9_;
	{long i; for (i = 30; i < 32; i++) O8823[i] = + _CHROFF_1_0_;}
	O8823[32] = + _CHROFF_2_0_;
	{long i; for (i = 33; i < 35; i++) O8823[i] = + _CHROFF_1_0_;}
	{long i; for (i = 35; i < 37; i++) O8823[i] = + _CHROFF_2_0_;}
	O8823[37] = + _CHROFF_4_0_;
	O8823[38] = + _CHROFF_1_0_;
	O8823[39] = + _CHROFF_3_0_;
	O8823[40] = + _CHROFF_7_4_;
	O8823[41] = + _CHROFF_8_5_;
	O8823[42] = + _CHROFF_1_0_;
	O8823[43] = + _CHROFF_2_0_;
	O8823[44] = + _CHROFF_6_2_;
	{long i; for (i = 45; i < 49; i++) O8823[i] = + _CHROFF_1_0_;}
	{long i; for (i = 49; i < 51; i++) O8823[i] = + _CHROFF_3_1_;}
	{long i; for (i = 51; i < 53; i++) O8823[i] = + _CHROFF_1_1_;}
	{long i; for (i = 53; i < 59; i++) O8823[i] = + _CHROFF_1_0_;}
	O8823[59] = + _CHROFF_2_0_;
	O8823[60] = + _CHROFF_1_0_;
	O8823[61] = + _CHROFF_2_0_;
	O8823[62] = + _CHROFF_1_0_;
	O8823[63] = + _CHROFF_2_0_;
	{long i; for (i = 64; i < 66; i++) O8823[i] = + _CHROFF_1_0_;}
	{long i; for (i = 66; i < 68; i++) O8823[i] = + _CHROFF_3_0_;}
	O8823[68] = + _CHROFF_8_4_;
	O8823[69] = + _CHROFF_9_4_;
	{long i; for (i = 70; i < 73; i++) O8823[i] = + _CHROFF_4_0_;}
	O8823[73] = + _CHROFF_11_4_;
	O8823[74] = + _CHROFF_11_5_;
	O8823[75] = + _CHROFF_11_4_;
	O8823[76] = + _CHROFF_13_3_;
	O8823[77] = + _CHROFF_16_5_;
	O8823[78] = + _CHROFF_35_7_;
	O8823[79] = + _CHROFF_42_10_;
	O8823[80] = + _CHROFF_37_7_;
	O8823[81] = + _CHROFF_46_10_;
	O8823[82] = + _CHROFF_37_7_;
	O8823[83] = + _CHROFF_38_7_;
	O8823[84] = + _CHROFF_37_7_;
	O8823[85] = + _CHROFF_47_10_;
	O8823[86] = + _CHROFF_49_10_;
	O8823[87] = + _CHROFF_47_10_;
	{long i; for (i = 88; i < 91; i++) O8823[i] = + _CHROFF_39_8_;}
	{long i; for (i = 91; i < 94; i++) O8823[i] = + _CHROFF_49_11_;}
	{long i; for (i = 94; i < 98; i++) O8823[i] = + _CHROFF_39_8_;}
	O8823[98] = + _CHROFF_49_11_;
	O8823[99] = + _CHROFF_51_11_;
	{long i; for (i = 100; i < 102; i++) O8823[i] = + _CHROFF_49_12_;}
	O8823[102] = + _CHROFF_47_10_;
	O8823[103] = + _CHROFF_47_12_;
	O8823[104] = + _CHROFF_50_11_;
	O8823[105] = + _CHROFF_53_11_;
	O8823[106] = + _CHROFF_59_19_;
	O8823[107] = + _CHROFF_59_21_;
	O8823[108] = + _CHROFF_65_23_;
	O8823[109] = + _CHROFF_68_24_;
	O8823[110] = + _CHROFF_35_7_;
	O8823[111] = + _CHROFF_37_7_;
	O8823[112] = + _CHROFF_43_7_;
	O8823[113] = + _CHROFF_37_7_;
	O8823[114] = + _CHROFF_37_8_;
	O8823[115] = + _CHROFF_35_7_;
	O8823[116] = + _CHROFF_37_7_;
	O8823[117] = + _CHROFF_37_8_;
	O8823[118] = + _CHROFF_36_7_;
	O8823[119] = + _CHROFF_37_7_;
	O8823[120] = + _CHROFF_41_7_;
	O8823[121] = + _CHROFF_36_7_;
	O8823[122] = + _CHROFF_40_10_;
	{long i; for (i = 123; i < 127; i++) O8823[i] = + _CHROFF_36_7_;}
	O8823[127] = + _CHROFF_42_11_;
	O8823[128] = + _CHROFF_44_11_;
	O8823[129] = + _CHROFF_58_12_;
	O8823[130] = + _CHROFF_51_11_;
	O8823[131] = + _CHROFF_45_14_;
	O8823[132] = + _CHROFF_44_11_;
	O8823[133] = + _CHROFF_50_11_;
	O8823[134] = + _CHROFF_51_12_;
	O8823[135] = + _CHROFF_43_11_;
	O8823[136] = + _CHROFF_46_12_;
	O8823[137] = + _CHROFF_59_14_;
	O8823[138] = + _CHROFF_44_13_;
	O8823[139] = + _CHROFF_51_16_;
	{long i; for (i = 140; i < 144; i++) O8823[i] = + _CHROFF_46_12_;}
	O8823[144] = + _CHROFF_16_3_;
	O8823[145] = + _CHROFF_18_3_;
	O8823[146] = + _CHROFF_23_3_;
	O8823[147] = + _CHROFF_16_3_;
	{long i; for (i = 148; i < 150; i++) O8823[i] = + _CHROFF_20_3_;}
	{long i; for (i = 150; i < 152; i++) O8823[i] = + _CHROFF_25_4_;}
	{long i; for (i = 152; i < 154; i++) O8823[i] = + _CHROFF_21_5_;}
	{long i; for (i = 154; i < 158; i++) O8823[i] = + _CHROFF_17_4_;}
	O8823[158] = + _CHROFF_18_4_;
	O8823[159] = + _CHROFF_23_6_;
	{long i; for (i = 160; i < 162; i++) O8823[i] = + _CHROFF_23_7_;}
	O8823[162] = + _CHROFF_24_7_;
	O8823[163] = + _CHROFF_26_6_;
	O8823[164] = + _CHROFF_19_3_;
	O8823[165] = + _CHROFF_22_3_;
	{long i; for (i = 166; i < 168; i++) O8823[i] = + _CHROFF_21_8_;}
	{long i; for (i = 168; i < 170; i++) O8823[i] = + _CHROFF_29_12_;}
	O8823[170] = + _CHROFF_1_0_;
	O8823[171] = + _CHROFF_36_8_;
	O8823[172] = + _CHROFF_1_0_;
	O8823[173] = + _CHROFF_36_7_;
	O8823[174] = + _CHROFF_1_0_;
	O8823[175] = + _CHROFF_6_2_;
	O8823[176] = + _CHROFF_48_15_;
	O8823[177] = + _CHROFF_6_2_;
	O8823[178] = + _CHROFF_48_14_;
	O8823[179] = + _CHROFF_6_4_;
	{long i; for (i = 180; i < 182; i++) O8823[i] = + _CHROFF_3_0_;}
}

long O8996[165];
void O8996_init () {
	O8996[0] =  + _REFACS_1_;
	{long i; for (i = 64; i < 66; i++) O8996[i] =  + _REFACS_25_;}
	{long i; for (i = 66; i < 69; i++) O8996[i] =  + _REFACS_26_;}
	O8996[69] =  + _REFACS_27_;
	{long i; for (i = 70; i < 72; i++) O8996[i] =  + _REFACS_26_;}
	O8996[72] =  + _REFACS_27_;
	O8996[73] =  + _REFACS_26_;
	{long i; for (i = 74; i < 88; i++) O8996[i] =  + _REFACS_27_;}
	{long i; for (i = 88; i < 90; i++) O8996[i] =  + _REFACS_31_;}
	{long i; for (i = 90; i < 92; i++) O8996[i] =  + _REFACS_34_;}
	{long i; for (i = 92; i < 94; i++) O8996[i] =  + _REFACS_31_;}
	{long i; for (i = 94; i < 96; i++) O8996[i] =  + _REFACS_34_;}
	O8996[96] =  + _REFACS_25_;
	O8996[97] =  + _REFACS_26_;
	O8996[98] =  + _REFACS_29_;
	O8996[99] =  + _REFACS_27_;
	O8996[100] =  + _REFACS_26_;
	O8996[101] =  + _REFACS_25_;
	{long i; for (i = 102; i < 104; i++) O8996[i] =  + _REFACS_27_;}
	O8996[104] =  + _REFACS_26_;
	O8996[105] =  + _REFACS_27_;
	O8996[106] =  + _REFACS_31_;
	O8996[107] =  + _REFACS_26_;
	O8996[108] =  + _REFACS_29_;
	{long i; for (i = 109; i < 113; i++) O8996[i] =  + _REFACS_26_;}
	O8996[113] =  + _REFACS_25_;
	O8996[114] =  + _REFACS_26_;
	O8996[115] =  + _REFACS_29_;
	O8996[116] =  + _REFACS_27_;
	O8996[117] =  + _REFACS_26_;
	O8996[118] =  + _REFACS_25_;
	{long i; for (i = 119; i < 121; i++) O8996[i] =  + _REFACS_27_;}
	O8996[121] =  + _REFACS_26_;
	O8996[122] =  + _REFACS_27_;
	O8996[123] =  + _REFACS_31_;
	O8996[124] =  + _REFACS_26_;
	O8996[125] =  + _REFACS_29_;
	{long i; for (i = 126; i < 130; i++) O8996[i] =  + _REFACS_26_;}
	O8996[157] =  + _REFACS_26_;
	O8996[159] =  + _REFACS_26_;
	O8996[162] =  + _REFACS_26_;
	O8996[164] =  + _REFACS_26_;
}

long O9348[153];
void O9348_init () {
	O9348[0] = + _PTROFF_2_3_0_1_0_0_;
	O9348[1] = + _PTROFF_4_3_0_1_0_0_;
	O9348[2] = + _PTROFF_5_5_0_1_0_0_;
	O9348[3] = + _PTROFF_10_10_0_9_0_0_;
	O9348[18] = + _PTROFF_6_3_0_2_0_0_;
	O9348[42] = + _PTROFF_8_5_0_1_0_0_;
	O9348[43] = + _PTROFF_9_5_0_1_0_0_;
	O9348[47] = + _PTROFF_11_5_0_1_0_0_;
	O9348[48] = + _PTROFF_11_6_0_1_0_0_;
	O9348[49] = + _PTROFF_11_5_0_1_0_0_;
	O9348[51] = + _PTROFF_16_7_6_1_0_0_;
	O9348[53] = + _PTROFF_42_12_10_6_0_0_;
	O9348[55] = + _PTROFF_46_12_10_6_0_0_;
	O9348[59] = + _PTROFF_47_12_10_7_0_0_;
	O9348[60] = + _PTROFF_49_12_10_10_0_0_;
	O9348[61] = + _PTROFF_47_12_10_7_0_0_;
	{long i; for (i = 65; i < 68; i++) O9348[i] = + _PTROFF_49_13_10_7_0_0_;}
	O9348[72] = + _PTROFF_49_13_10_6_0_0_;
	O9348[73] = + _PTROFF_51_13_10_8_0_0_;
	O9348[74] = + _PTROFF_49_14_10_8_0_0_;
	O9348[75] = + _PTROFF_49_14_10_10_0_0_;
	O9348[80] = + _PTROFF_59_21_10_11_0_0_;
	O9348[81] = + _PTROFF_59_23_10_11_0_0_;
	O9348[82] = + _PTROFF_65_25_10_11_0_0_;
	O9348[83] = + _PTROFF_68_26_10_11_0_0_;
	O9348[101] = + _PTROFF_42_13_10_6_0_0_;
	O9348[102] = + _PTROFF_44_13_10_7_0_0_;
	O9348[103] = + _PTROFF_58_14_10_9_0_0_;
	O9348[104] = + _PTROFF_51_13_10_9_0_0_;
	O9348[105] = + _PTROFF_45_16_10_7_0_0_;
	O9348[106] = + _PTROFF_44_13_10_6_1_0_;
	O9348[107] = + _PTROFF_50_13_10_9_0_0_;
	O9348[108] = + _PTROFF_51_14_10_9_0_0_;
	O9348[109] = + _PTROFF_43_13_10_6_0_0_;
	O9348[110] = + _PTROFF_46_14_10_7_0_0_;
	O9348[111] = + _PTROFF_59_16_10_12_0_0_;
	O9348[112] = + _PTROFF_44_15_10_6_0_0_;
	O9348[113] = + _PTROFF_51_18_10_10_0_0_;
	{long i; for (i = 114; i < 118; i++) O9348[i] = + _PTROFF_46_14_10_6_0_0_;}
	{long i; for (i = 126; i < 128; i++) O9348[i] = + _PTROFF_21_7_6_1_0_0_;}
	O9348[133] = + _PTROFF_23_8_6_1_0_0_;
	{long i; for (i = 134; i < 136; i++) O9348[i] = + _PTROFF_23_9_6_1_0_0_;}
	O9348[136] = + _PTROFF_24_9_6_1_0_0_;
	O9348[137] = + _PTROFF_26_8_6_2_0_0_;
	{long i; for (i = 142; i < 144; i++) O9348[i] = + _PTROFF_29_14_8_2_0_0_;}
	O9348[150] = + _PTROFF_48_19_10_9_0_0_;
	O9348[152] = + _PTROFF_48_18_10_9_0_0_;
}

long O9349[153];
void O9349_init () {
	O9349[0] = + _CHROFF_2_0_;
	O9349[1] = + _CHROFF_4_0_;
	O9349[2] = + _CHROFF_5_0_;
	O9349[3] = + _CHROFF_10_0_;
	O9349[18] = + _CHROFF_6_0_;
	O9349[42] = + _CHROFF_8_0_;
	O9349[43] = + _CHROFF_9_0_;
	{long i; for (i = 47; i < 50; i++) O9349[i] = + _CHROFF_11_0_;}
	O9349[51] = + _CHROFF_16_1_;
	O9349[53] = + _CHROFF_42_1_;
	O9349[55] = + _CHROFF_46_1_;
	O9349[59] = + _CHROFF_47_1_;
	O9349[60] = + _CHROFF_49_1_;
	O9349[61] = + _CHROFF_47_1_;
	{long i; for (i = 65; i < 68; i++) O9349[i] = + _CHROFF_49_1_;}
	O9349[72] = + _CHROFF_49_1_;
	O9349[73] = + _CHROFF_51_1_;
	{long i; for (i = 74; i < 76; i++) O9349[i] = + _CHROFF_49_1_;}
	{long i; for (i = 80; i < 82; i++) O9349[i] = + _CHROFF_59_1_;}
	O9349[82] = + _CHROFF_65_1_;
	O9349[83] = + _CHROFF_68_1_;
	O9349[101] = + _CHROFF_42_1_;
	O9349[102] = + _CHROFF_44_1_;
	O9349[103] = + _CHROFF_58_1_;
	O9349[104] = + _CHROFF_51_1_;
	O9349[105] = + _CHROFF_45_1_;
	O9349[106] = + _CHROFF_44_1_;
	O9349[107] = + _CHROFF_50_1_;
	O9349[108] = + _CHROFF_51_1_;
	O9349[109] = + _CHROFF_43_1_;
	O9349[110] = + _CHROFF_46_1_;
	O9349[111] = + _CHROFF_59_1_;
	O9349[112] = + _CHROFF_44_1_;
	O9349[113] = + _CHROFF_51_1_;
	{long i; for (i = 114; i < 118; i++) O9349[i] = + _CHROFF_46_1_;}
	{long i; for (i = 126; i < 128; i++) O9349[i] = + _CHROFF_21_1_;}
	{long i; for (i = 133; i < 136; i++) O9349[i] = + _CHROFF_23_1_;}
	O9349[136] = + _CHROFF_24_1_;
	O9349[137] = + _CHROFF_26_1_;
	{long i; for (i = 142; i < 144; i++) O9349[i] = + _CHROFF_29_1_;}
	O9349[150] = + _CHROFF_48_1_;
	O9349[152] = + _CHROFF_48_1_;
}

long O9360[153];
void O9360_init () {
	{long i; for (i = 0; i < 4; i++) O9360[i] =  + _REFACS_1_;}
	O9360[18] =  + _REFACS_2_;
	{long i; for (i = 42; i < 44; i++) O9360[i] =  + _REFACS_3_;}
	{long i; for (i = 47; i < 50; i++) O9360[i] =  + _REFACS_3_;}
	O9360[51] =  + _REFACS_8_;
	O9360[53] =  + _REFACS_26_;
	O9360[55] =  + _REFACS_27_;
	O9360[59] =  + _REFACS_27_;
	O9360[60] =  + _REFACS_28_;
	O9360[61] =  + _REFACS_27_;
	{long i; for (i = 65; i < 68; i++) O9360[i] =  + _REFACS_28_;}
	{long i; for (i = 72; i < 76; i++) O9360[i] =  + _REFACS_28_;}
	{long i; for (i = 80; i < 82; i++) O9360[i] =  + _REFACS_32_;}
	{long i; for (i = 82; i < 84; i++) O9360[i] =  + _REFACS_35_;}
	O9360[101] =  + _REFACS_26_;
	O9360[102] =  + _REFACS_27_;
	O9360[103] =  + _REFACS_30_;
	O9360[104] =  + _REFACS_28_;
	O9360[105] =  + _REFACS_27_;
	O9360[106] =  + _REFACS_26_;
	{long i; for (i = 107; i < 109; i++) O9360[i] =  + _REFACS_28_;}
	O9360[109] =  + _REFACS_27_;
	O9360[110] =  + _REFACS_28_;
	O9360[111] =  + _REFACS_32_;
	O9360[112] =  + _REFACS_27_;
	O9360[113] =  + _REFACS_30_;
	{long i; for (i = 114; i < 118; i++) O9360[i] =  + _REFACS_27_;}
	{long i; for (i = 126; i < 128; i++) O9360[i] =  + _REFACS_11_;}
	{long i; for (i = 133; i < 137; i++) O9360[i] =  + _REFACS_12_;}
	O9360[137] =  + _REFACS_13_;
	{long i; for (i = 142; i < 144; i++) O9360[i] =  + _REFACS_15_;}
	O9360[150] =  + _REFACS_27_;
	O9360[152] =  + _REFACS_27_;
}

long O9362[153];
void O9362_init () {
	O9362[0] = + _CHROFF_2_1_;
	O9362[1] = + _CHROFF_4_1_;
	O9362[2] = + _CHROFF_5_1_;
	O9362[3] = + _CHROFF_10_1_;
	O9362[18] = + _CHROFF_6_1_;
	O9362[42] = + _CHROFF_8_1_;
	O9362[43] = + _CHROFF_9_1_;
	{long i; for (i = 47; i < 50; i++) O9362[i] = + _CHROFF_11_1_;}
	O9362[51] = + _CHROFF_16_2_;
	O9362[53] = + _CHROFF_42_2_;
	O9362[55] = + _CHROFF_46_2_;
	O9362[59] = + _CHROFF_47_2_;
	O9362[60] = + _CHROFF_49_2_;
	O9362[61] = + _CHROFF_47_2_;
	{long i; for (i = 65; i < 68; i++) O9362[i] = + _CHROFF_49_2_;}
	O9362[72] = + _CHROFF_49_2_;
	O9362[73] = + _CHROFF_51_2_;
	{long i; for (i = 74; i < 76; i++) O9362[i] = + _CHROFF_49_2_;}
	{long i; for (i = 80; i < 82; i++) O9362[i] = + _CHROFF_59_2_;}
	O9362[82] = + _CHROFF_65_2_;
	O9362[83] = + _CHROFF_68_2_;
	O9362[101] = + _CHROFF_42_2_;
	O9362[102] = + _CHROFF_44_2_;
	O9362[103] = + _CHROFF_58_2_;
	O9362[104] = + _CHROFF_51_2_;
	O9362[105] = + _CHROFF_45_2_;
	O9362[106] = + _CHROFF_44_2_;
	O9362[107] = + _CHROFF_50_2_;
	O9362[108] = + _CHROFF_51_2_;
	O9362[109] = + _CHROFF_43_2_;
	O9362[110] = + _CHROFF_46_2_;
	O9362[111] = + _CHROFF_59_2_;
	O9362[112] = + _CHROFF_44_2_;
	O9362[113] = + _CHROFF_51_2_;
	{long i; for (i = 114; i < 118; i++) O9362[i] = + _CHROFF_46_2_;}
	{long i; for (i = 126; i < 128; i++) O9362[i] = + _CHROFF_21_2_;}
	{long i; for (i = 133; i < 136; i++) O9362[i] = + _CHROFF_23_2_;}
	O9362[136] = + _CHROFF_24_2_;
	O9362[137] = + _CHROFF_26_2_;
	{long i; for (i = 142; i < 144; i++) O9362[i] = + _CHROFF_29_2_;}
	O9362[150] = + _CHROFF_48_2_;
	O9362[152] = + _CHROFF_48_2_;
}

long O9394[152];
void O9394_init () {
	{long i; for (i = 0; i < 3; i++) O9394[i] =  + _REFACS_2_;}
	{long i; for (i = 41; i < 43; i++) O9394[i] =  + _REFACS_4_;}
	{long i; for (i = 46; i < 49; i++) O9394[i] =  + _REFACS_4_;}
	O9394[50] =  + _REFACS_9_;
	O9394[52] =  + _REFACS_27_;
	O9394[54] =  + _REFACS_28_;
	O9394[58] =  + _REFACS_28_;
	O9394[59] =  + _REFACS_29_;
	O9394[60] =  + _REFACS_28_;
	{long i; for (i = 64; i < 67; i++) O9394[i] =  + _REFACS_29_;}
	{long i; for (i = 71; i < 75; i++) O9394[i] =  + _REFACS_29_;}
	{long i; for (i = 79; i < 81; i++) O9394[i] =  + _REFACS_33_;}
	{long i; for (i = 81; i < 83; i++) O9394[i] =  + _REFACS_36_;}
	O9394[100] =  + _REFACS_27_;
	O9394[101] =  + _REFACS_28_;
	O9394[102] =  + _REFACS_31_;
	O9394[103] =  + _REFACS_29_;
	O9394[104] =  + _REFACS_28_;
	O9394[105] =  + _REFACS_27_;
	{long i; for (i = 106; i < 108; i++) O9394[i] =  + _REFACS_29_;}
	O9394[108] =  + _REFACS_28_;
	O9394[109] =  + _REFACS_29_;
	O9394[110] =  + _REFACS_33_;
	O9394[111] =  + _REFACS_28_;
	O9394[112] =  + _REFACS_31_;
	{long i; for (i = 113; i < 117; i++) O9394[i] =  + _REFACS_28_;}
	{long i; for (i = 125; i < 127; i++) O9394[i] =  + _REFACS_12_;}
	{long i; for (i = 132; i < 136; i++) O9394[i] =  + _REFACS_13_;}
	O9394[136] =  + _REFACS_14_;
	{long i; for (i = 141; i < 143; i++) O9394[i] =  + _REFACS_16_;}
	O9394[149] =  + _REFACS_28_;
	O9394[151] =  + _REFACS_28_;
}

long O9395[152];
void O9395_init () {
	{long i; for (i = 0; i < 3; i++) O9395[i] =  + _REFACS_3_;}
	{long i; for (i = 41; i < 43; i++) O9395[i] =  + _REFACS_5_;}
	{long i; for (i = 46; i < 49; i++) O9395[i] =  + _REFACS_5_;}
	O9395[50] =  + _REFACS_10_;
	O9395[52] =  + _REFACS_28_;
	O9395[54] =  + _REFACS_29_;
	O9395[58] =  + _REFACS_29_;
	O9395[59] =  + _REFACS_30_;
	O9395[60] =  + _REFACS_29_;
	{long i; for (i = 64; i < 67; i++) O9395[i] =  + _REFACS_30_;}
	{long i; for (i = 71; i < 75; i++) O9395[i] =  + _REFACS_30_;}
	{long i; for (i = 79; i < 81; i++) O9395[i] =  + _REFACS_34_;}
	{long i; for (i = 81; i < 83; i++) O9395[i] =  + _REFACS_37_;}
	O9395[100] =  + _REFACS_28_;
	O9395[101] =  + _REFACS_29_;
	O9395[102] =  + _REFACS_32_;
	O9395[103] =  + _REFACS_30_;
	O9395[104] =  + _REFACS_29_;
	O9395[105] =  + _REFACS_28_;
	{long i; for (i = 106; i < 108; i++) O9395[i] =  + _REFACS_30_;}
	O9395[108] =  + _REFACS_29_;
	O9395[109] =  + _REFACS_30_;
	O9395[110] =  + _REFACS_34_;
	O9395[111] =  + _REFACS_29_;
	O9395[112] =  + _REFACS_32_;
	{long i; for (i = 113; i < 117; i++) O9395[i] =  + _REFACS_29_;}
	{long i; for (i = 125; i < 127; i++) O9395[i] =  + _REFACS_13_;}
	{long i; for (i = 132; i < 136; i++) O9395[i] =  + _REFACS_14_;}
	O9395[136] =  + _REFACS_15_;
	{long i; for (i = 141; i < 143; i++) O9395[i] =  + _REFACS_17_;}
	O9395[149] =  + _REFACS_29_;
	O9395[151] =  + _REFACS_29_;
}

long O9415[82];
void O9415_init () {
	{long i; for (i = 0; i < 2; i++) O9415[i] =  + _REFACS_4_;}
	{long i; for (i = 40; i < 42; i++) O9415[i] =  + _REFACS_6_;}
	{long i; for (i = 45; i < 48; i++) O9415[i] =  + _REFACS_6_;}
	{long i; for (i = 78; i < 80; i++) O9415[i] =  + _REFACS_35_;}
	{long i; for (i = 80; i < 82; i++) O9415[i] =  + _REFACS_38_;}
}

long O9422[82];
void O9422_init () {
	O9422[0] = + _CHROFF_5_2_;
	O9422[1] = + _CHROFF_10_2_;
	O9422[40] = + _CHROFF_8_2_;
	O9422[41] = + _CHROFF_9_2_;
	{long i; for (i = 45; i < 48; i++) O9422[i] = + _CHROFF_11_2_;}
	{long i; for (i = 78; i < 80; i++) O9422[i] = + _CHROFF_59_3_;}
	O9422[80] = + _CHROFF_65_3_;
	O9422[81] = + _CHROFF_68_3_;
}

long O9428[82];
void O9428_init () {
	O9428[0] = + _CHROFF_5_3_;
	O9428[1] = + _CHROFF_10_3_;
	O9428[40] = + _CHROFF_8_3_;
	O9428[41] = + _CHROFF_9_3_;
	{long i; for (i = 45; i < 48; i++) O9428[i] = + _CHROFF_11_3_;}
	{long i; for (i = 78; i < 80; i++) O9428[i] = + _CHROFF_59_4_;}
	O9428[80] = + _CHROFF_65_4_;
	O9428[81] = + _CHROFF_68_4_;
}

long O9478[133];
void O9478_init () {
	O9478[0] = + _LNGOFF_1_1_0_0_;
	O9478[1] = + _LNGOFF_2_1_0_0_;
	{long i; for (i = 2; i < 4; i++) O9478[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 4; i < 6; i++) O9478[i] = + _LNGOFF_2_1_0_0_;}
	O9478[6] = + _LNGOFF_4_1_0_0_;
	O9478[12] = + _LNGOFF_2_1_0_0_;
	O9478[13] = + _LNGOFF_6_3_0_1_;
	O9478[51] = + _LNGOFF_37_9_6_0_;
	O9478[52] = + _LNGOFF_38_9_6_0_;
	O9478[53] = + _LNGOFF_37_9_6_0_;
	O9478[54] = + _LNGOFF_47_12_10_1_;
	O9478[55] = + _LNGOFF_49_12_10_1_;
	O9478[56] = + _LNGOFF_47_12_10_1_;
	{long i; for (i = 57; i < 60; i++) O9478[i] = + _LNGOFF_39_10_6_0_;}
	{long i; for (i = 60; i < 63; i++) O9478[i] = + _LNGOFF_49_13_10_1_;}
	O9478[81] = + _LNGOFF_43_9_6_0_;
	O9478[82] = + _LNGOFF_37_9_6_0_;
	O9478[83] = + _LNGOFF_37_10_6_0_;
	O9478[85] = + _LNGOFF_37_9_6_0_;
	O9478[86] = + _LNGOFF_37_10_6_0_;
	O9478[89] = + _LNGOFF_41_9_6_0_;
	O9478[98] = + _LNGOFF_58_14_10_1_;
	O9478[99] = + _LNGOFF_51_13_10_1_;
	O9478[100] = + _LNGOFF_45_16_10_1_;
	O9478[102] = + _LNGOFF_50_13_10_1_;
	O9478[103] = + _LNGOFF_51_14_10_1_;
	O9478[106] = + _LNGOFF_59_16_10_1_;
	{long i; for (i = 117; i < 119; i++) O9478[i] = + _LNGOFF_20_5_6_0_;}
	{long i; for (i = 119; i < 121; i++) O9478[i] = + _LNGOFF_25_6_6_0_;}
	O9478[127] = + _LNGOFF_18_6_6_0_;
	O9478[132] = + _LNGOFF_26_8_6_1_;
}

long O9512[132];
void O9512_init () {
	O9512[0] =  + _REFACS_1_;
	O9512[4] =  + _REFACS_1_;
	O9512[5] =  + _REFACS_2_;
	O9512[12] =  + _REFACS_3_;
	O9512[53] =  + _REFACS_30_;
	O9512[54] =  + _REFACS_31_;
	O9512[55] =  + _REFACS_30_;
	{long i; for (i = 59; i < 62; i++) O9512[i] =  + _REFACS_31_;}
	O9512[97] =  + _REFACS_33_;
	O9512[98] =  + _REFACS_31_;
	O9512[99] =  + _REFACS_30_;
	{long i; for (i = 101; i < 103; i++) O9512[i] =  + _REFACS_31_;}
	O9512[105] =  + _REFACS_35_;
	{long i; for (i = 118; i < 120; i++) O9512[i] =  + _REFACS_15_;}
	O9512[131] =  + _REFACS_16_;
}

static EIF_TYPE_INDEX Y9512_pgtype0[] = {0xFF01,656,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype1[] = {0xFF01,656,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype2[] = {0xFF01,656,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype3[] = {0xFF01,656,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype4[] = {0xFF01,656,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype5[] = {0xFF01,656,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype6[] = {0xFF01,656,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype7[] = {0xFF01,656,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype8[] = {0xFF01,656,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype9[] = {0xFF01,656,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype10[] = {0xFF01,656,0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype11[] = {0xFF01,656,0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype12[] = {0xFF01,656,0xFF01,1165,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype13[] = {0xFF01,656,0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype14[] = {0xFF01,656,0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype15[] = {0xFF01,656,0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype16[] = {0xFF01,656,0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype17[] = {0xFF01,656,0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y9512_pgtype18[] = {0xFF01,656,0xFF01,1169,0xFFFF};
EIF_TYPE_INDEX *Y9512_gen_type [132];
EIF_TYPE_INDEX Y9512 [132];
void Y9512_init (void)
{
	egc_routines_types [9512] = Y9512;
	egc_routines_gen_types [9512] = Y9512_gen_type;
	egc_routines_offset [9512] = 1219;
	Y9512_gen_type [0] = Y9512_pgtype0;
	Y9512_gen_type [4] = Y9512_pgtype1;
	Y9512_gen_type [5] = Y9512_pgtype2;
	Y9512_gen_type [12] = Y9512_pgtype3;
	Y9512_gen_type [53] = Y9512_pgtype4;
	Y9512_gen_type [54] = Y9512_pgtype5;
	Y9512_gen_type [55] = Y9512_pgtype6;
	Y9512_gen_type [59] = Y9512_pgtype7;
	Y9512_gen_type [60] = Y9512_pgtype8;
	Y9512_gen_type [61] = Y9512_pgtype9;
	Y9512_gen_type [97] = Y9512_pgtype10;
	Y9512_gen_type [98] = Y9512_pgtype11;
	Y9512_gen_type [99] = Y9512_pgtype12;
	Y9512_gen_type [101] = Y9512_pgtype13;
	Y9512_gen_type [102] = Y9512_pgtype14;
	Y9512_gen_type [105] = Y9512_pgtype15;
	Y9512_gen_type [118] = Y9512_pgtype16;
	Y9512_gen_type [119] = Y9512_pgtype17;
	Y9512_gen_type [131] = Y9512_pgtype18;
	Y9512[0] = 656;
	{long i; for (i = 4; i < 6; i++) Y9512[i] = 656;};
	Y9512[12] = 656;
	{long i; for (i = 53; i < 56; i++) Y9512[i] = 656;};
	{long i; for (i = 59; i < 62; i++) Y9512[i] = 656;};
	{long i; for (i = 97; i < 100; i++) Y9512[i] = 656;};
	{long i; for (i = 101; i < 103; i++) Y9512[i] = 656;};
	Y9512[105] = 656;
	{long i; for (i = 118; i < 120; i++) Y9512[i] = 656;};
	Y9512[131] = 656;
}

long O9549[140];
void O9549_init () {
	O9549[0] =  + _REFACS_1_;
	O9549[40] =  + _REFACS_29_;
	O9549[42] =  + _REFACS_30_;
	O9549[46] =  + _REFACS_31_;
	O9549[47] =  + _REFACS_32_;
	O9549[48] =  + _REFACS_31_;
	{long i; for (i = 52; i < 55; i++) O9549[i] =  + _REFACS_32_;}
	{long i; for (i = 59; i < 63; i++) O9549[i] =  + _REFACS_31_;}
	{long i; for (i = 67; i < 69; i++) O9549[i] =  + _REFACS_36_;}
	{long i; for (i = 69; i < 71; i++) O9549[i] =  + _REFACS_39_;}
	O9549[88] =  + _REFACS_29_;
	O9549[89] =  + _REFACS_30_;
	O9549[90] =  + _REFACS_34_;
	O9549[91] =  + _REFACS_32_;
	O9549[92] =  + _REFACS_31_;
	O9549[93] =  + _REFACS_29_;
	{long i; for (i = 94; i < 96; i++) O9549[i] =  + _REFACS_32_;}
	O9549[96] =  + _REFACS_30_;
	O9549[97] =  + _REFACS_31_;
	O9549[98] =  + _REFACS_36_;
	O9549[99] =  + _REFACS_30_;
	O9549[100] =  + _REFACS_33_;
	{long i; for (i = 101; i < 105; i++) O9549[i] =  + _REFACS_30_;}
	O9549[137] =  + _REFACS_30_;
	O9549[139] =  + _REFACS_30_;
}

long O9550[140];
void O9550_init () {
	O9550[0] =  + _REFACS_2_;
	O9550[40] =  + _REFACS_30_;
	O9550[42] =  + _REFACS_31_;
	O9550[46] =  + _REFACS_32_;
	O9550[47] =  + _REFACS_33_;
	O9550[48] =  + _REFACS_32_;
	{long i; for (i = 52; i < 55; i++) O9550[i] =  + _REFACS_33_;}
	{long i; for (i = 59; i < 63; i++) O9550[i] =  + _REFACS_32_;}
	{long i; for (i = 67; i < 69; i++) O9550[i] =  + _REFACS_37_;}
	{long i; for (i = 69; i < 71; i++) O9550[i] =  + _REFACS_40_;}
	O9550[88] =  + _REFACS_30_;
	O9550[89] =  + _REFACS_31_;
	O9550[90] =  + _REFACS_35_;
	O9550[91] =  + _REFACS_33_;
	O9550[92] =  + _REFACS_32_;
	O9550[93] =  + _REFACS_30_;
	{long i; for (i = 94; i < 96; i++) O9550[i] =  + _REFACS_33_;}
	O9550[96] =  + _REFACS_31_;
	O9550[97] =  + _REFACS_32_;
	O9550[98] =  + _REFACS_37_;
	O9550[99] =  + _REFACS_31_;
	O9550[100] =  + _REFACS_34_;
	{long i; for (i = 101; i < 105; i++) O9550[i] =  + _REFACS_31_;}
	O9550[137] =  + _REFACS_31_;
	O9550[139] =  + _REFACS_31_;
}

long O9558[139];
void O9558_init () {
	{long i; for (i = 0; i < 2; i++) O9558[i] =  + _REFACS_6_;}
	O9558[38] =  + _REFACS_26_;
	O9558[39] =  + _REFACS_31_;
	O9558[40] =  + _REFACS_27_;
	O9558[41] =  + _REFACS_32_;
	O9558[42] =  + _REFACS_27_;
	O9558[43] =  + _REFACS_28_;
	O9558[44] =  + _REFACS_27_;
	O9558[45] =  + _REFACS_33_;
	O9558[46] =  + _REFACS_34_;
	O9558[47] =  + _REFACS_33_;
	{long i; for (i = 48; i < 51; i++) O9558[i] =  + _REFACS_28_;}
	{long i; for (i = 51; i < 54; i++) O9558[i] =  + _REFACS_34_;}
	{long i; for (i = 54; i < 58; i++) O9558[i] =  + _REFACS_28_;}
	{long i; for (i = 58; i < 62; i++) O9558[i] =  + _REFACS_33_;}
	{long i; for (i = 62; i < 64; i++) O9558[i] =  + _REFACS_32_;}
	{long i; for (i = 64; i < 66; i++) O9558[i] =  + _REFACS_35_;}
	{long i; for (i = 66; i < 68; i++) O9558[i] =  + _REFACS_38_;}
	{long i; for (i = 68; i < 70; i++) O9558[i] =  + _REFACS_41_;}
	O9558[70] =  + _REFACS_26_;
	O9558[71] =  + _REFACS_27_;
	O9558[72] =  + _REFACS_30_;
	O9558[73] =  + _REFACS_28_;
	O9558[74] =  + _REFACS_27_;
	O9558[75] =  + _REFACS_26_;
	{long i; for (i = 76; i < 78; i++) O9558[i] =  + _REFACS_28_;}
	O9558[78] =  + _REFACS_27_;
	O9558[79] =  + _REFACS_28_;
	O9558[80] =  + _REFACS_32_;
	O9558[81] =  + _REFACS_27_;
	O9558[82] =  + _REFACS_30_;
	{long i; for (i = 83; i < 87; i++) O9558[i] =  + _REFACS_27_;}
	O9558[87] =  + _REFACS_31_;
	O9558[88] =  + _REFACS_32_;
	O9558[89] =  + _REFACS_36_;
	O9558[90] =  + _REFACS_34_;
	O9558[91] =  + _REFACS_33_;
	O9558[92] =  + _REFACS_31_;
	{long i; for (i = 93; i < 95; i++) O9558[i] =  + _REFACS_34_;}
	O9558[95] =  + _REFACS_32_;
	O9558[96] =  + _REFACS_33_;
	O9558[97] =  + _REFACS_38_;
	O9558[98] =  + _REFACS_32_;
	O9558[99] =  + _REFACS_35_;
	{long i; for (i = 100; i < 104; i++) O9558[i] =  + _REFACS_32_;}
	{long i; for (i = 126; i < 128; i++) O9558[i] =  + _REFACS_15_;}
	{long i; for (i = 128; i < 130; i++) O9558[i] =  + _REFACS_18_;}
	O9558[131] =  + _REFACS_27_;
	O9558[133] =  + _REFACS_27_;
	O9558[136] =  + _REFACS_32_;
	O9558[138] =  + _REFACS_32_;
}

long O9559[139];
void O9559_init () {
	O9559[0] = + _CHROFF_7_1_;
	O9559[1] = + _CHROFF_8_1_;
	O9559[38] = + _CHROFF_35_1_;
	O9559[39] = + _CHROFF_42_3_;
	O9559[40] = + _CHROFF_37_1_;
	O9559[41] = + _CHROFF_46_3_;
	O9559[42] = + _CHROFF_37_1_;
	O9559[43] = + _CHROFF_38_1_;
	O9559[44] = + _CHROFF_37_1_;
	O9559[45] = + _CHROFF_47_3_;
	O9559[46] = + _CHROFF_49_3_;
	O9559[47] = + _CHROFF_47_3_;
	{long i; for (i = 48; i < 51; i++) O9559[i] = + _CHROFF_39_1_;}
	{long i; for (i = 51; i < 54; i++) O9559[i] = + _CHROFF_49_3_;}
	{long i; for (i = 54; i < 58; i++) O9559[i] = + _CHROFF_39_1_;}
	O9559[58] = + _CHROFF_49_3_;
	O9559[59] = + _CHROFF_51_3_;
	{long i; for (i = 60; i < 62; i++) O9559[i] = + _CHROFF_49_3_;}
	{long i; for (i = 62; i < 64; i++) O9559[i] = + _CHROFF_47_1_;}
	O9559[64] = + _CHROFF_50_1_;
	O9559[65] = + _CHROFF_53_1_;
	{long i; for (i = 66; i < 68; i++) O9559[i] = + _CHROFF_59_5_;}
	O9559[68] = + _CHROFF_65_5_;
	O9559[69] = + _CHROFF_68_5_;
	O9559[70] = + _CHROFF_35_1_;
	O9559[71] = + _CHROFF_37_1_;
	O9559[72] = + _CHROFF_43_1_;
	{long i; for (i = 73; i < 75; i++) O9559[i] = + _CHROFF_37_1_;}
	O9559[75] = + _CHROFF_35_1_;
	{long i; for (i = 76; i < 78; i++) O9559[i] = + _CHROFF_37_1_;}
	O9559[78] = + _CHROFF_36_1_;
	O9559[79] = + _CHROFF_37_1_;
	O9559[80] = + _CHROFF_41_1_;
	O9559[81] = + _CHROFF_36_1_;
	O9559[82] = + _CHROFF_40_1_;
	{long i; for (i = 83; i < 87; i++) O9559[i] = + _CHROFF_36_1_;}
	O9559[87] = + _CHROFF_42_3_;
	O9559[88] = + _CHROFF_44_3_;
	O9559[89] = + _CHROFF_58_3_;
	O9559[90] = + _CHROFF_51_3_;
	O9559[91] = + _CHROFF_45_3_;
	O9559[92] = + _CHROFF_44_3_;
	O9559[93] = + _CHROFF_50_3_;
	O9559[94] = + _CHROFF_51_3_;
	O9559[95] = + _CHROFF_43_3_;
	O9559[96] = + _CHROFF_46_3_;
	O9559[97] = + _CHROFF_59_3_;
	O9559[98] = + _CHROFF_44_3_;
	O9559[99] = + _CHROFF_51_3_;
	{long i; for (i = 100; i < 104; i++) O9559[i] = + _CHROFF_46_3_;}
	{long i; for (i = 126; i < 128; i++) O9559[i] = + _CHROFF_21_1_;}
	{long i; for (i = 128; i < 130; i++) O9559[i] = + _CHROFF_29_3_;}
	O9559[131] = + _CHROFF_36_1_;
	O9559[133] = + _CHROFF_36_1_;
	O9559[136] = + _CHROFF_48_3_;
	O9559[138] = + _CHROFF_48_3_;
}

long O9560[139];
void O9560_init () {
	O9560[0] = + _CHROFF_7_2_;
	O9560[1] = + _CHROFF_8_2_;
	O9560[38] = + _CHROFF_35_2_;
	O9560[39] = + _CHROFF_42_4_;
	O9560[40] = + _CHROFF_37_2_;
	O9560[41] = + _CHROFF_46_4_;
	O9560[42] = + _CHROFF_37_2_;
	O9560[43] = + _CHROFF_38_2_;
	O9560[44] = + _CHROFF_37_2_;
	O9560[45] = + _CHROFF_47_4_;
	O9560[46] = + _CHROFF_49_4_;
	O9560[47] = + _CHROFF_47_4_;
	{long i; for (i = 48; i < 51; i++) O9560[i] = + _CHROFF_39_2_;}
	{long i; for (i = 51; i < 54; i++) O9560[i] = + _CHROFF_49_4_;}
	{long i; for (i = 54; i < 58; i++) O9560[i] = + _CHROFF_39_2_;}
	O9560[58] = + _CHROFF_49_4_;
	O9560[59] = + _CHROFF_51_4_;
	{long i; for (i = 60; i < 62; i++) O9560[i] = + _CHROFF_49_4_;}
	{long i; for (i = 62; i < 64; i++) O9560[i] = + _CHROFF_47_2_;}
	O9560[64] = + _CHROFF_50_2_;
	O9560[65] = + _CHROFF_53_2_;
	{long i; for (i = 66; i < 68; i++) O9560[i] = + _CHROFF_59_6_;}
	O9560[68] = + _CHROFF_65_6_;
	O9560[69] = + _CHROFF_68_6_;
	O9560[70] = + _CHROFF_35_2_;
	O9560[71] = + _CHROFF_37_2_;
	O9560[72] = + _CHROFF_43_2_;
	{long i; for (i = 73; i < 75; i++) O9560[i] = + _CHROFF_37_2_;}
	O9560[75] = + _CHROFF_35_2_;
	{long i; for (i = 76; i < 78; i++) O9560[i] = + _CHROFF_37_2_;}
	O9560[78] = + _CHROFF_36_2_;
	O9560[79] = + _CHROFF_37_2_;
	O9560[80] = + _CHROFF_41_2_;
	O9560[81] = + _CHROFF_36_2_;
	O9560[82] = + _CHROFF_40_2_;
	{long i; for (i = 83; i < 87; i++) O9560[i] = + _CHROFF_36_2_;}
	O9560[87] = + _CHROFF_42_4_;
	O9560[88] = + _CHROFF_44_4_;
	O9560[89] = + _CHROFF_58_4_;
	O9560[90] = + _CHROFF_51_4_;
	O9560[91] = + _CHROFF_45_4_;
	O9560[92] = + _CHROFF_44_4_;
	O9560[93] = + _CHROFF_50_4_;
	O9560[94] = + _CHROFF_51_4_;
	O9560[95] = + _CHROFF_43_4_;
	O9560[96] = + _CHROFF_46_4_;
	O9560[97] = + _CHROFF_59_4_;
	O9560[98] = + _CHROFF_44_4_;
	O9560[99] = + _CHROFF_51_4_;
	{long i; for (i = 100; i < 104; i++) O9560[i] = + _CHROFF_46_4_;}
	{long i; for (i = 126; i < 128; i++) O9560[i] = + _CHROFF_21_2_;}
	{long i; for (i = 128; i < 130; i++) O9560[i] = + _CHROFF_29_4_;}
	O9560[131] = + _CHROFF_36_2_;
	O9560[133] = + _CHROFF_36_2_;
	O9560[136] = + _CHROFF_48_4_;
	O9560[138] = + _CHROFF_48_4_;
}

long O9562[139];
void O9562_init () {
	O9562[0] = + _CHROFF_7_3_;
	O9562[1] = + _CHROFF_8_3_;
	O9562[38] = + _CHROFF_35_3_;
	O9562[39] = + _CHROFF_42_5_;
	O9562[40] = + _CHROFF_37_3_;
	O9562[41] = + _CHROFF_46_5_;
	O9562[42] = + _CHROFF_37_3_;
	O9562[43] = + _CHROFF_38_3_;
	O9562[44] = + _CHROFF_37_3_;
	O9562[45] = + _CHROFF_47_5_;
	O9562[46] = + _CHROFF_49_5_;
	O9562[47] = + _CHROFF_47_5_;
	{long i; for (i = 48; i < 51; i++) O9562[i] = + _CHROFF_39_3_;}
	{long i; for (i = 51; i < 54; i++) O9562[i] = + _CHROFF_49_5_;}
	{long i; for (i = 54; i < 58; i++) O9562[i] = + _CHROFF_39_3_;}
	O9562[58] = + _CHROFF_49_5_;
	O9562[59] = + _CHROFF_51_5_;
	{long i; for (i = 60; i < 62; i++) O9562[i] = + _CHROFF_49_5_;}
	{long i; for (i = 62; i < 64; i++) O9562[i] = + _CHROFF_47_3_;}
	O9562[64] = + _CHROFF_50_3_;
	O9562[65] = + _CHROFF_53_3_;
	{long i; for (i = 66; i < 68; i++) O9562[i] = + _CHROFF_59_7_;}
	O9562[68] = + _CHROFF_65_7_;
	O9562[69] = + _CHROFF_68_7_;
	O9562[70] = + _CHROFF_35_3_;
	O9562[71] = + _CHROFF_37_3_;
	O9562[72] = + _CHROFF_43_3_;
	{long i; for (i = 73; i < 75; i++) O9562[i] = + _CHROFF_37_3_;}
	O9562[75] = + _CHROFF_35_3_;
	{long i; for (i = 76; i < 78; i++) O9562[i] = + _CHROFF_37_3_;}
	O9562[78] = + _CHROFF_36_3_;
	O9562[79] = + _CHROFF_37_3_;
	O9562[80] = + _CHROFF_41_3_;
	O9562[81] = + _CHROFF_36_3_;
	O9562[82] = + _CHROFF_40_3_;
	{long i; for (i = 83; i < 87; i++) O9562[i] = + _CHROFF_36_3_;}
	O9562[87] = + _CHROFF_42_5_;
	O9562[88] = + _CHROFF_44_5_;
	O9562[89] = + _CHROFF_58_5_;
	O9562[90] = + _CHROFF_51_5_;
	O9562[91] = + _CHROFF_45_5_;
	O9562[92] = + _CHROFF_44_5_;
	O9562[93] = + _CHROFF_50_5_;
	O9562[94] = + _CHROFF_51_5_;
	O9562[95] = + _CHROFF_43_5_;
	O9562[96] = + _CHROFF_46_5_;
	O9562[97] = + _CHROFF_59_5_;
	O9562[98] = + _CHROFF_44_5_;
	O9562[99] = + _CHROFF_51_5_;
	{long i; for (i = 100; i < 104; i++) O9562[i] = + _CHROFF_46_5_;}
	{long i; for (i = 126; i < 128; i++) O9562[i] = + _CHROFF_21_3_;}
	{long i; for (i = 128; i < 130; i++) O9562[i] = + _CHROFF_29_5_;}
	O9562[131] = + _CHROFF_36_3_;
	O9562[133] = + _CHROFF_36_3_;
	O9562[136] = + _CHROFF_48_5_;
	O9562[138] = + _CHROFF_48_5_;
}

long O9591[138];
void O9591_init () {
	O9591[0] = + _CHROFF_8_4_;
	O9591[38] = + _CHROFF_42_6_;
	O9591[40] = + _CHROFF_46_6_;
	O9591[44] = + _CHROFF_47_6_;
	O9591[45] = + _CHROFF_49_6_;
	O9591[46] = + _CHROFF_47_6_;
	{long i; for (i = 50; i < 53; i++) O9591[i] = + _CHROFF_49_6_;}
	O9591[57] = + _CHROFF_49_6_;
	O9591[58] = + _CHROFF_51_6_;
	{long i; for (i = 59; i < 61; i++) O9591[i] = + _CHROFF_49_6_;}
	{long i; for (i = 65; i < 67; i++) O9591[i] = + _CHROFF_59_8_;}
	O9591[67] = + _CHROFF_65_8_;
	O9591[68] = + _CHROFF_68_8_;
	O9591[86] = + _CHROFF_42_6_;
	O9591[87] = + _CHROFF_44_6_;
	O9591[88] = + _CHROFF_58_6_;
	O9591[89] = + _CHROFF_51_6_;
	O9591[90] = + _CHROFF_45_6_;
	O9591[91] = + _CHROFF_44_6_;
	O9591[92] = + _CHROFF_50_6_;
	O9591[93] = + _CHROFF_51_6_;
	O9591[94] = + _CHROFF_43_6_;
	O9591[95] = + _CHROFF_46_6_;
	O9591[96] = + _CHROFF_59_6_;
	O9591[97] = + _CHROFF_44_6_;
	O9591[98] = + _CHROFF_51_6_;
	{long i; for (i = 99; i < 103; i++) O9591[i] = + _CHROFF_46_6_;}
	{long i; for (i = 127; i < 129; i++) O9591[i] = + _CHROFF_29_6_;}
	O9591[135] = + _CHROFF_48_6_;
	O9591[137] = + _CHROFF_48_6_;
}

long O9592[138];
void O9592_init () {
	O9592[0] = + _I16OFF_8_6_4_;
	O9592[38] = + _I16OFF_42_12_4_;
	O9592[40] = + _I16OFF_46_12_4_;
	O9592[44] = + _I16OFF_47_12_4_;
	O9592[45] = + _I16OFF_49_12_4_;
	O9592[46] = + _I16OFF_47_12_4_;
	{long i; for (i = 50; i < 53; i++) O9592[i] = + _I16OFF_49_13_4_;}
	O9592[57] = + _I16OFF_49_13_4_;
	O9592[58] = + _I16OFF_51_13_4_;
	{long i; for (i = 59; i < 61; i++) O9592[i] = + _I16OFF_49_14_4_;}
	O9592[65] = + _I16OFF_59_21_4_;
	O9592[66] = + _I16OFF_59_23_4_;
	O9592[67] = + _I16OFF_65_25_4_;
	O9592[68] = + _I16OFF_68_26_4_;
	O9592[86] = + _I16OFF_42_13_4_;
	O9592[87] = + _I16OFF_44_13_4_;
	O9592[88] = + _I16OFF_58_14_4_;
	O9592[89] = + _I16OFF_51_13_4_;
	O9592[90] = + _I16OFF_45_16_4_;
	O9592[91] = + _I16OFF_44_13_4_;
	O9592[92] = + _I16OFF_50_13_4_;
	O9592[93] = + _I16OFF_51_14_4_;
	O9592[94] = + _I16OFF_43_13_4_;
	O9592[95] = + _I16OFF_46_14_4_;
	O9592[96] = + _I16OFF_59_16_4_;
	O9592[97] = + _I16OFF_44_15_4_;
	O9592[98] = + _I16OFF_51_18_4_;
	{long i; for (i = 99; i < 103; i++) O9592[i] = + _I16OFF_46_14_4_;}
	{long i; for (i = 127; i < 129; i++) O9592[i] = + _I16OFF_29_14_4_;}
	O9592[135] = + _I16OFF_48_19_4_;
	O9592[137] = + _I16OFF_48_18_4_;
}

long O9593[138];
void O9593_init () {
	O9593[0] = + _I16OFF_8_6_5_;
	O9593[38] = + _I16OFF_42_12_5_;
	O9593[40] = + _I16OFF_46_12_5_;
	O9593[44] = + _I16OFF_47_12_5_;
	O9593[45] = + _I16OFF_49_12_5_;
	O9593[46] = + _I16OFF_47_12_5_;
	{long i; for (i = 50; i < 53; i++) O9593[i] = + _I16OFF_49_13_5_;}
	O9593[57] = + _I16OFF_49_13_5_;
	O9593[58] = + _I16OFF_51_13_5_;
	{long i; for (i = 59; i < 61; i++) O9593[i] = + _I16OFF_49_14_5_;}
	O9593[65] = + _I16OFF_59_21_5_;
	O9593[66] = + _I16OFF_59_23_5_;
	O9593[67] = + _I16OFF_65_25_5_;
	O9593[68] = + _I16OFF_68_26_5_;
	O9593[86] = + _I16OFF_42_13_5_;
	O9593[87] = + _I16OFF_44_13_5_;
	O9593[88] = + _I16OFF_58_14_5_;
	O9593[89] = + _I16OFF_51_13_5_;
	O9593[90] = + _I16OFF_45_16_5_;
	O9593[91] = + _I16OFF_44_13_5_;
	O9593[92] = + _I16OFF_50_13_5_;
	O9593[93] = + _I16OFF_51_14_5_;
	O9593[94] = + _I16OFF_43_13_5_;
	O9593[95] = + _I16OFF_46_14_5_;
	O9593[96] = + _I16OFF_59_16_5_;
	O9593[97] = + _I16OFF_44_15_5_;
	O9593[98] = + _I16OFF_51_18_5_;
	{long i; for (i = 99; i < 103; i++) O9593[i] = + _I16OFF_46_14_5_;}
	{long i; for (i = 127; i < 129; i++) O9593[i] = + _I16OFF_29_14_5_;}
	O9593[135] = + _I16OFF_48_19_5_;
	O9593[137] = + _I16OFF_48_18_5_;
}

long O9598[138];
void O9598_init () {
	O9598[0] =  + _REFACS_7_;
	O9598[38] =  + _REFACS_32_;
	O9598[40] =  + _REFACS_33_;
	O9598[44] =  + _REFACS_34_;
	O9598[45] =  + _REFACS_35_;
	O9598[46] =  + _REFACS_34_;
	{long i; for (i = 50; i < 53; i++) O9598[i] =  + _REFACS_35_;}
	{long i; for (i = 57; i < 61; i++) O9598[i] =  + _REFACS_34_;}
	{long i; for (i = 65; i < 67; i++) O9598[i] =  + _REFACS_39_;}
	{long i; for (i = 67; i < 69; i++) O9598[i] =  + _REFACS_42_;}
	O9598[86] =  + _REFACS_32_;
	O9598[87] =  + _REFACS_33_;
	O9598[88] =  + _REFACS_37_;
	O9598[89] =  + _REFACS_35_;
	O9598[90] =  + _REFACS_34_;
	O9598[91] =  + _REFACS_32_;
	{long i; for (i = 92; i < 94; i++) O9598[i] =  + _REFACS_35_;}
	O9598[94] =  + _REFACS_33_;
	O9598[95] =  + _REFACS_34_;
	O9598[96] =  + _REFACS_39_;
	O9598[97] =  + _REFACS_33_;
	O9598[98] =  + _REFACS_36_;
	{long i; for (i = 99; i < 103; i++) O9598[i] =  + _REFACS_33_;}
	{long i; for (i = 127; i < 129; i++) O9598[i] =  + _REFACS_19_;}
	O9598[135] =  + _REFACS_33_;
	O9598[137] =  + _REFACS_33_;
}

long O9642[83];
void O9642_init () {
	{long i; for (i = 0; i < 2; i++) O9642[i] =  + _REFACS_2_;}
	{long i; for (i = 39; i < 42; i++) O9642[i] =  + _REFACS_29_;}
	{long i; for (i = 42; i < 45; i++) O9642[i] =  + _REFACS_36_;}
	{long i; for (i = 45; i < 49; i++) O9642[i] =  + _REFACS_29_;}
	{long i; for (i = 49; i < 53; i++) O9642[i] =  + _REFACS_35_;}
	{long i; for (i = 53; i < 55; i++) O9642[i] =  + _REFACS_33_;}
	{long i; for (i = 55; i < 57; i++) O9642[i] =  + _REFACS_36_;}
	{long i; for (i = 57; i < 59; i++) O9642[i] =  + _REFACS_40_;}
	{long i; for (i = 59; i < 61; i++) O9642[i] =  + _REFACS_43_;}
	O9642[65] =  + _REFACS_28_;
	O9642[82] =  + _REFACS_35_;
}

long O9643[83];
void O9643_init () {
	{long i; for (i = 0; i < 2; i++) O9643[i] = + _CHROFF_3_0_;}
	{long i; for (i = 39; i < 42; i++) O9643[i] = + _CHROFF_39_4_;}
	{long i; for (i = 42; i < 45; i++) O9643[i] = + _CHROFF_49_7_;}
	{long i; for (i = 45; i < 49; i++) O9643[i] = + _CHROFF_39_4_;}
	O9643[49] = + _CHROFF_49_7_;
	O9643[50] = + _CHROFF_51_7_;
	{long i; for (i = 51; i < 53; i++) O9643[i] = + _CHROFF_49_7_;}
	{long i; for (i = 53; i < 55; i++) O9643[i] = + _CHROFF_47_4_;}
	O9643[55] = + _CHROFF_50_4_;
	O9643[56] = + _CHROFF_53_4_;
	{long i; for (i = 57; i < 59; i++) O9643[i] = + _CHROFF_59_9_;}
	O9643[59] = + _CHROFF_65_9_;
	O9643[60] = + _CHROFF_68_9_;
	O9643[65] = + _CHROFF_37_4_;
	O9643[82] = + _CHROFF_45_7_;
}

long O9648[128];
void O9648_init () {
	{long i; for (i = 0; i < 2; i++) O9648[i] = + _CHROFF_1_0_;}
	O9648[27] = + _CHROFF_35_4_;
	O9648[28] = + _CHROFF_42_7_;
	O9648[29] = + _CHROFF_37_4_;
	O9648[30] = + _CHROFF_46_7_;
	O9648[31] = + _CHROFF_37_4_;
	O9648[32] = + _CHROFF_38_4_;
	O9648[33] = + _CHROFF_37_4_;
	O9648[34] = + _CHROFF_47_7_;
	O9648[35] = + _CHROFF_49_7_;
	O9648[36] = + _CHROFF_47_7_;
	{long i; for (i = 37; i < 40; i++) O9648[i] = + _CHROFF_39_5_;}
	{long i; for (i = 40; i < 43; i++) O9648[i] = + _CHROFF_49_8_;}
	{long i; for (i = 43; i < 47; i++) O9648[i] = + _CHROFF_39_5_;}
	O9648[47] = + _CHROFF_49_8_;
	O9648[48] = + _CHROFF_51_8_;
	{long i; for (i = 49; i < 51; i++) O9648[i] = + _CHROFF_49_8_;}
	{long i; for (i = 51; i < 53; i++) O9648[i] = + _CHROFF_47_5_;}
	O9648[53] = + _CHROFF_50_5_;
	O9648[54] = + _CHROFF_53_5_;
	{long i; for (i = 55; i < 57; i++) O9648[i] = + _CHROFF_59_10_;}
	O9648[57] = + _CHROFF_65_10_;
	O9648[58] = + _CHROFF_68_10_;
	O9648[59] = + _CHROFF_35_4_;
	O9648[60] = + _CHROFF_37_4_;
	O9648[61] = + _CHROFF_43_4_;
	O9648[62] = + _CHROFF_37_4_;
	O9648[63] = + _CHROFF_37_5_;
	O9648[64] = + _CHROFF_35_4_;
	{long i; for (i = 65; i < 67; i++) O9648[i] = + _CHROFF_37_4_;}
	O9648[67] = + _CHROFF_36_4_;
	O9648[68] = + _CHROFF_37_4_;
	O9648[69] = + _CHROFF_41_4_;
	O9648[70] = + _CHROFF_36_4_;
	O9648[71] = + _CHROFF_40_4_;
	{long i; for (i = 72; i < 76; i++) O9648[i] = + _CHROFF_36_4_;}
	O9648[76] = + _CHROFF_42_7_;
	O9648[77] = + _CHROFF_44_7_;
	O9648[78] = + _CHROFF_58_7_;
	O9648[79] = + _CHROFF_51_7_;
	O9648[80] = + _CHROFF_45_8_;
	O9648[81] = + _CHROFF_44_7_;
	O9648[82] = + _CHROFF_50_7_;
	O9648[83] = + _CHROFF_51_7_;
	O9648[84] = + _CHROFF_43_7_;
	O9648[85] = + _CHROFF_46_7_;
	O9648[86] = + _CHROFF_59_7_;
	O9648[87] = + _CHROFF_44_7_;
	O9648[88] = + _CHROFF_51_7_;
	{long i; for (i = 89; i < 93; i++) O9648[i] = + _CHROFF_46_7_;}
	{long i; for (i = 103; i < 107; i++) O9648[i] = + _CHROFF_17_1_;}
	O9648[107] = + _CHROFF_18_1_;
	{long i; for (i = 108; i < 111; i++) O9648[i] = + _CHROFF_23_3_;}
	O9648[111] = + _CHROFF_24_3_;
	O9648[112] = + _CHROFF_26_3_;
	{long i; for (i = 115; i < 117; i++) O9648[i] = + _CHROFF_21_4_;}
	{long i; for (i = 117; i < 119; i++) O9648[i] = + _CHROFF_29_7_;}
	O9648[120] = + _CHROFF_36_4_;
	O9648[122] = + _CHROFF_36_4_;
	O9648[125] = + _CHROFF_48_7_;
	O9648[127] = + _CHROFF_48_7_;
}

long O9675[111];
void O9675_init () {
	O9675[0] =  + _REFACS_1_;
	{long i; for (i = 81; i < 85; i++) O9675[i] =  + _REFACS_34_;}
	{long i; for (i = 93; i < 95; i++) O9675[i] =  + _REFACS_14_;}
	{long i; for (i = 100; i < 104; i++) O9675[i] =  + _REFACS_15_;}
	O9675[104] =  + _REFACS_18_;
	{long i; for (i = 109; i < 111; i++) O9675[i] =  + _REFACS_20_;}
}


#ifdef __cplusplus
}
#endif
