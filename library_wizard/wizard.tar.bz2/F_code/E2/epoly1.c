#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O1692[1264];
void O1692_init () {
	O1692[0] = 0;
	O1692[1238] = 0;
	{long i; for (i = 1239; i < 1241; i++) O1692[i] =  + _REFACS_2_;}
	O1692[1241] = 0;
	{long i; for (i = 1242; i < 1246; i++) O1692[i] =  + _REFACS_4_;}
	{long i; for (i = 1246; i < 1252; i++) O1692[i] = 0;}
	O1692[1252] =  + _REFACS_1_;
	{long i; for (i = 1253; i < 1257; i++) O1692[i] = 0;}
	O1692[1257] =  + _REFACS_1_;
	{long i; for (i = 1258; i < 1264; i++) O1692[i] =  + _REFACS_2_;}
}

long O1694[1264];
void O1694_init () {
	O1694[0] =  + _REFACS_1_;
	O1694[1238] =  + _REFACS_1_;
	{long i; for (i = 1239; i < 1241; i++) O1694[i] =  + _REFACS_3_;}
	O1694[1241] =  + _REFACS_1_;
	{long i; for (i = 1242; i < 1246; i++) O1694[i] =  + _REFACS_5_;}
	{long i; for (i = 1246; i < 1252; i++) O1694[i] =  + _REFACS_1_;}
	O1694[1252] =  + _REFACS_2_;
	{long i; for (i = 1253; i < 1257; i++) O1694[i] =  + _REFACS_1_;}
	O1694[1257] =  + _REFACS_2_;
	{long i; for (i = 1258; i < 1264; i++) O1694[i] =  + _REFACS_3_;}
}

long O1696[1264];
void O1696_init () {
	O1696[0] =  + _REFACS_2_;
	O1696[1238] =  + _REFACS_2_;
	{long i; for (i = 1239; i < 1241; i++) O1696[i] =  + _REFACS_4_;}
	O1696[1241] =  + _REFACS_2_;
	{long i; for (i = 1242; i < 1246; i++) O1696[i] =  + _REFACS_6_;}
	{long i; for (i = 1246; i < 1252; i++) O1696[i] =  + _REFACS_2_;}
	O1696[1252] =  + _REFACS_3_;
	{long i; for (i = 1253; i < 1257; i++) O1696[i] =  + _REFACS_2_;}
	O1696[1257] =  + _REFACS_3_;
	{long i; for (i = 1258; i < 1264; i++) O1696[i] =  + _REFACS_4_;}
}

long O1698[1233];
void O1698_init () {
	O1698[0] = 0;
	O1698[1211] = 0;
	O1698[1212] =  + _REFACS_1_;
	O1698[1213] =  + _REFACS_5_;
	O1698[1214] = 0;
	O1698[1215] =  + _REFACS_3_;
	O1698[1228] = 0;
	O1698[1229] =  + _REFACS_1_;
	O1698[1230] =  + _REFACS_5_;
	O1698[1231] = 0;
	O1698[1232] =  + _REFACS_3_;
}

long O1771[1267];
void O1771_init () {
	O1771[0] = 0;
	{long i; for (i = 1128; i < 1130; i++) O1771[i] = 0;}
	{long i; for (i = 1166; i < 1171; i++) O1771[i] = 0;}
	O1771[1171] =  + _REFACS_1_;
	{long i; for (i = 1172; i < 1174; i++) O1771[i] = 0;}
	O1771[1174] =  + _REFACS_1_;
	{long i; for (i = 1175; i < 1199; i++) O1771[i] = 0;}
	O1771[1199] =  + _REFACS_1_;
	O1771[1200] =  + _REFACS_4_;
	O1771[1201] =  + _REFACS_2_;
	{long i; for (i = 1202; i < 1204; i++) O1771[i] = 0;}
	{long i; for (i = 1204; i < 1206; i++) O1771[i] =  + _REFACS_2_;}
	O1771[1206] =  + _REFACS_1_;
	O1771[1207] =  + _REFACS_2_;
	O1771[1208] =  + _REFACS_6_;
	O1771[1209] =  + _REFACS_1_;
	O1771[1210] =  + _REFACS_4_;
	{long i; for (i = 1211; i < 1216; i++) O1771[i] = 0;}
	O1771[1216] =  + _REFACS_1_;
	O1771[1217] =  + _REFACS_4_;
	O1771[1218] =  + _REFACS_2_;
	{long i; for (i = 1219; i < 1221; i++) O1771[i] = 0;}
	{long i; for (i = 1221; i < 1223; i++) O1771[i] =  + _REFACS_2_;}
	O1771[1223] =  + _REFACS_1_;
	O1771[1224] =  + _REFACS_2_;
	O1771[1225] =  + _REFACS_6_;
	O1771[1226] =  + _REFACS_1_;
	O1771[1227] =  + _REFACS_4_;
	{long i; for (i = 1228; i < 1232; i++) O1771[i] = 0;}
	{long i; for (i = 1254; i < 1258; i++) O1771[i] =  + _REFACS_5_;}
	O1771[1259] = 0;
	O1771[1261] = 0;
	O1771[1264] = 0;
	O1771[1266] = 0;
}

long O1772[1267];
void O1772_init () {
	O1772[0] =  + _REFACS_1_;
	{long i; for (i = 1128; i < 1130; i++) O1772[i] =  + _REFACS_1_;}
	{long i; for (i = 1166; i < 1171; i++) O1772[i] =  + _REFACS_1_;}
	O1772[1171] =  + _REFACS_2_;
	{long i; for (i = 1172; i < 1174; i++) O1772[i] =  + _REFACS_1_;}
	O1772[1174] =  + _REFACS_2_;
	{long i; for (i = 1175; i < 1199; i++) O1772[i] =  + _REFACS_1_;}
	O1772[1199] =  + _REFACS_2_;
	O1772[1200] =  + _REFACS_5_;
	O1772[1201] =  + _REFACS_3_;
	{long i; for (i = 1202; i < 1204; i++) O1772[i] =  + _REFACS_1_;}
	{long i; for (i = 1204; i < 1206; i++) O1772[i] =  + _REFACS_3_;}
	O1772[1206] =  + _REFACS_2_;
	O1772[1207] =  + _REFACS_3_;
	O1772[1208] =  + _REFACS_7_;
	O1772[1209] =  + _REFACS_2_;
	O1772[1210] =  + _REFACS_5_;
	{long i; for (i = 1211; i < 1216; i++) O1772[i] =  + _REFACS_1_;}
	O1772[1216] =  + _REFACS_2_;
	O1772[1217] =  + _REFACS_5_;
	O1772[1218] =  + _REFACS_3_;
	{long i; for (i = 1219; i < 1221; i++) O1772[i] =  + _REFACS_1_;}
	{long i; for (i = 1221; i < 1223; i++) O1772[i] =  + _REFACS_3_;}
	O1772[1223] =  + _REFACS_2_;
	O1772[1224] =  + _REFACS_3_;
	O1772[1225] =  + _REFACS_7_;
	O1772[1226] =  + _REFACS_2_;
	O1772[1227] =  + _REFACS_5_;
	{long i; for (i = 1228; i < 1232; i++) O1772[i] =  + _REFACS_1_;}
	{long i; for (i = 1254; i < 1258; i++) O1772[i] =  + _REFACS_6_;}
	O1772[1259] =  + _REFACS_1_;
	O1772[1261] =  + _REFACS_1_;
	O1772[1264] =  + _REFACS_1_;
	O1772[1266] =  + _REFACS_1_;
}

long O1776[1250];
void O1776_init () {
	O1776[0] = 0;
	{long i; for (i = 1240; i < 1244; i++) O1776[i] =  + _REFACS_3_;}
	O1776[1244] =  + _REFACS_4_;
	{long i; for (i = 1245; i < 1249; i++) O1776[i] =  + _REFACS_3_;}
	O1776[1249] =  + _REFACS_4_;
}

long O2964[1178];
void O2964_init () {
	O2964[0] = 0;
	{long i; for (i = 1170; i < 1172; i++) O2964[i] =  + _REFACS_4_;}
	{long i; for (i = 1172; i < 1174; i++) O2964[i] =  + _REFACS_7_;}
	{long i; for (i = 1174; i < 1176; i++) O2964[i] =  + _REFACS_4_;}
	{long i; for (i = 1176; i < 1178; i++) O2964[i] =  + _REFACS_7_;}
}

long O2966[1178];
void O2966_init () {
	O2966[0] =  + _REFACS_1_;
	{long i; for (i = 1170; i < 1172; i++) O2966[i] =  + _REFACS_5_;}
	{long i; for (i = 1172; i < 1174; i++) O2966[i] =  + _REFACS_8_;}
	{long i; for (i = 1174; i < 1176; i++) O2966[i] =  + _REFACS_5_;}
	{long i; for (i = 1176; i < 1178; i++) O2966[i] =  + _REFACS_8_;}
}


#ifdef __cplusplus
}
#endif
