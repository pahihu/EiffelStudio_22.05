#include "epoly9.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5080[7])();
void R5080_init () {
	R5080[0] = (char *(*)()) F639_5490;
	R5080[1] = (char *(*)()) F640_5490;
	R5080[2] = (char *(*)()) F641_5490;
	R5080[3] = (char *(*)()) F639_5490;
	R5080[4] = (char *(*)()) F641_5490;
	R5080[5] = (char *(*)()) F640_5490;
	R5080[6] = (char *(*)()) F639_5490;
}

char *(*R5085[7])();
void R5085_init () {
	R5085[0] = (char *(*)()) F639_5501;
	R5085[1] = (char *(*)()) F640_5501_5085_4;
	R5085[2] = (char *(*)()) F641_5501_5085_4;
	R5085[3] = (char *(*)()) F639_5501;
	R5085[4] = (char *(*)()) F641_5501_5085_4;
	R5085[5] = (char *(*)()) F640_5501_5085_4;
	R5085[6] = (char *(*)()) F639_5501;
}
static void F640_5501_5085_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F640_5501(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F641_5501_5085_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F641_5501(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R5086[43])();
void R5086_init () {
	R5086[0] = (char *(*)()) F657_5761;
	R5086[1] = (char *(*)()) F658_5761_5086_4;
	R5086[2] = (char *(*)()) F659_5761_5086_4;
	R5086[3] = (char *(*)()) F660_5761_5086_4;
	R5086[4] = (char *(*)()) F661_5761_5086_4;
	R5086[5] = (char *(*)()) F662_5761_5086_4;
	R5086[6] = (char *(*)()) F663_5761_5086_4;
	R5086[7] = (char *(*)()) F664_5761_5086_4;
	R5086[8] = (char *(*)()) F665_5761_5086_4;
	R5086[9] = (char *(*)()) F666_5761_5086_4;
	R5086[10] = (char *(*)()) F667_5761_5086_4;
	R5086[11] = (char *(*)()) F668_5761_5086_4;
	R5086[12] = (char *(*)()) F657_5761;
	R5086[13] = (char *(*)()) F658_5761_5086_4;
	R5086[14] = (char *(*)()) F664_5761_5086_4;
	R5086[19] = (char *(*)()) F672_5804;
	R5086[20] = (char *(*)()) F673_5804_5086_4;
	{long i; for (i = 21; i < 25; i++) R5086[i] = (char *(*)()) F672_5804;}
	R5086[29] = (char *(*)()) F672_5804;
	R5086[31] = (char *(*)()) F672_5804;
	R5086[35] = (char *(*)()) F672_5804;
	{long i; for (i = 37; i < 39; i++) R5086[i] = (char *(*)()) F672_5804;}
	{long i; for (i = 40; i < 43; i++) R5086[i] = (char *(*)()) F672_5804;}
}
static void F658_5761_5086_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5761(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F659_5761_5086_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5761(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F660_5761_5086_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F660_5761(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F661_5761_5086_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_5761(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F662_5761_5086_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F662_5761(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F663_5761_5086_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_5761(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F664_5761_5086_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5761(Current, *(EIF_BOOLEAN *)arg1);
}
static void F665_5761_5086_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5761(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F666_5761_5086_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5761(Current, *(EIF_REAL_32 *)arg1);
}
static void F667_5761_5086_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5761(Current, *(EIF_POINTER *)arg1);
}
static void F668_5761_5086_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5761(Current, *(EIF_REAL_64 *)arg1);
}
static void F673_5804_5086_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F673_5804(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5091[7])();
void R5091_init () {
	R5091[0] = (char *(*)()) F639_5510;
	R5091[1] = (char *(*)()) F640_5510;
	R5091[2] = (char *(*)()) F641_5510;
	R5091[3] = (char *(*)()) F639_5510;
	R5091[4] = (char *(*)()) F641_5510;
	R5091[5] = (char *(*)()) F640_5510;
	R5091[6] = (char *(*)()) F639_5510;
}

char *(*R5096[7])();
void R5096_init () {
	R5096[0] = (char *(*)()) F639_5514;
	R5096[1] = (char *(*)()) F640_5514_5096_5;
	R5096[2] = (char *(*)()) F641_5514_5096_5;
	R5096[3] = (char *(*)()) F639_5514;
	R5096[4] = (char *(*)()) F641_5514_5096_5;
	R5096[5] = (char *(*)()) F640_5514_5096_5;
	R5096[6] = (char *(*)()) F639_5514;
}
static EIF_REFERENCE F640_5514_5096_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F640_5514(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F641_5514_5096_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F641_5514(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R5097[7])();
void R5097_init () {
	R5097[0] = (char *(*)()) F639_5515;
	R5097[1] = (char *(*)()) F640_5515;
	R5097[2] = (char *(*)()) F641_5515;
	R5097[3] = (char *(*)()) F639_5515;
	R5097[4] = (char *(*)()) F641_5515;
	R5097[5] = (char *(*)()) F640_5515;
	R5097[6] = (char *(*)()) F639_5515;
}

char *(*R5100[7])();
void R5100_init () {
	R5100[0] = (char *(*)()) F639_5518;
	R5100[1] = (char *(*)()) F640_5518;
	R5100[2] = (char *(*)()) F641_5518;
	R5100[3] = (char *(*)()) F639_5518;
	R5100[4] = (char *(*)()) F641_5518;
	R5100[5] = (char *(*)()) F640_5518;
	R5100[6] = (char *(*)()) F639_5518;
}

char *(*R5101[7])();
void R5101_init () {
	R5101[0] = (char *(*)()) F639_5519;
	R5101[1] = (char *(*)()) F640_5519;
	R5101[2] = (char *(*)()) F641_5519;
	R5101[3] = (char *(*)()) F639_5519;
	R5101[4] = (char *(*)()) F641_5519;
	R5101[5] = (char *(*)()) F640_5519;
	R5101[6] = (char *(*)()) F639_5519;
}

char *(*R5102[7])();
void R5102_init () {
	R5102[0] = (char *(*)()) F639_5520;
	R5102[1] = (char *(*)()) F640_5520;
	R5102[2] = (char *(*)()) F641_5520;
	R5102[3] = (char *(*)()) F639_5520;
	R5102[4] = (char *(*)()) F641_5520;
	R5102[5] = (char *(*)()) F640_5520;
	R5102[6] = (char *(*)()) F639_5520;
}

char *(*R5107[3])();
void R5107_init () {
	R5107[0] = (char *(*)()) F639_5477;
	R5107[1] = (char *(*)()) F641_5477_5107_1;
	R5107[2] = (char *(*)()) F640_5477_5107_1;
}
static EIF_REFERENCE F641_5477_5107_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F641_5477(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F640_5477_5107_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F640_5477(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5108[3])();
void R5108_init () {
	R5108[0] = (char *(*)()) F639_5508;
	R5108[1] = (char *(*)()) F641_5508;
	R5108[2] = (char *(*)()) F640_5508;
}

char *(*R5114[407])();
void R5114_init () {
	R5114[0] = (char *(*)()) F648_5647;
	R5114[1] = (char *(*)()) F649_5647;
	R5114[2] = (char *(*)()) F650_5647;
	R5114[3] = (char *(*)()) F651_5647;
	R5114[4] = (char *(*)()) F652_5647;
	R5114[5] = (char *(*)()) F653_5647;
	R5114[6] = (char *(*)()) F648_5647;
	R5114[7] = (char *(*)()) F649_5647;
	R5114[8] = (char *(*)()) F648_5647;
	R5114[9] = (char *(*)()) F657_5780;
	R5114[10] = (char *(*)()) F658_5780;
	R5114[11] = (char *(*)()) F659_5780;
	R5114[12] = (char *(*)()) F660_5780;
	R5114[13] = (char *(*)()) F661_5780;
	R5114[14] = (char *(*)()) F662_5780;
	R5114[15] = (char *(*)()) F663_5780;
	R5114[16] = (char *(*)()) F664_5780;
	R5114[17] = (char *(*)()) F665_5780;
	R5114[18] = (char *(*)()) F666_5780;
	R5114[19] = (char *(*)()) F667_5780;
	R5114[20] = (char *(*)()) F668_5780;
	R5114[21] = (char *(*)()) F657_5780;
	R5114[22] = (char *(*)()) F658_5780;
	R5114[23] = (char *(*)()) F664_5780;
	R5114[28] = (char *(*)()) F657_5780;
	R5114[29] = (char *(*)()) F658_5780;
	{long i; for (i = 30; i < 34; i++) R5114[i] = (char *(*)()) F657_5780;}
	R5114[38] = (char *(*)()) F657_5780;
	R5114[40] = (char *(*)()) F657_5780;
	R5114[44] = (char *(*)()) F657_5780;
	{long i; for (i = 46; i < 48; i++) R5114[i] = (char *(*)()) F657_5780;}
	{long i; for (i = 49; i < 52; i++) R5114[i] = (char *(*)()) F657_5780;}
	R5114[319] = (char *(*)()) F967_7860;
	{long i; for (i = 393; i < 398; i++) R5114[i] = (char *(*)()) F1040_8951;}
	R5114[402] = (char *(*)()) F1050_9190;
	R5114[403] = (char *(*)()) F1051_9281;
	R5114[406] = (char *(*)()) F1054_9445;
}

char *(*R5126[9])();
void R5126_init () {
	R5126[0] = (char *(*)()) F648_5588;
	R5126[1] = (char *(*)()) F649_5588;
	R5126[2] = (char *(*)()) F650_5588;
	R5126[3] = (char *(*)()) F651_5588;
	R5126[4] = (char *(*)()) F652_5588;
	R5126[5] = (char *(*)()) F653_5588;
	R5126[6] = (char *(*)()) F648_5588;
	R5126[7] = (char *(*)()) F649_5588;
	R5126[8] = (char *(*)()) F648_5588;
}

char *(*R5129[9])();
void R5129_init () {
	R5129[0] = (char *(*)()) F648_5591;
	R5129[1] = (char *(*)()) F649_5591;
	R5129[2] = (char *(*)()) F650_5591;
	R5129[3] = (char *(*)()) F651_5591;
	R5129[4] = (char *(*)()) F652_5591;
	R5129[5] = (char *(*)()) F653_5591;
	R5129[6] = (char *(*)()) F648_5591;
	R5129[7] = (char *(*)()) F649_5591;
	R5129[8] = (char *(*)()) F648_5591;
}

char *(*R5130[9])();
void R5130_init () {
	R5130[0] = (char *(*)()) F648_5592;
	R5130[1] = (char *(*)()) F649_5592_5130_1;
	R5130[2] = (char *(*)()) F650_5592;
	R5130[3] = (char *(*)()) F651_5592_5130_1;
	R5130[4] = (char *(*)()) F652_5592_5130_1;
	R5130[5] = (char *(*)()) F653_5592_5130_1;
	R5130[6] = (char *(*)()) F648_5592;
	R5130[7] = (char *(*)()) F649_5592_5130_1;
	R5130[8] = (char *(*)()) F648_5592;
}
static EIF_REFERENCE F649_5592_5130_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F649_5592(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F651_5592_5130_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5592(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5592_5130_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F652_5592(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F653_5592_5130_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F653_5592(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R5131[9])();
void R5131_init () {
	R5131[0] = (char *(*)()) F648_5594;
	R5131[1] = (char *(*)()) F649_5594_5131_5;
	R5131[2] = (char *(*)()) F650_5594_5131_5;
	R5131[3] = (char *(*)()) F651_5594_5131_5;
	R5131[4] = (char *(*)()) F652_5594_5131_5;
	R5131[5] = (char *(*)()) F653_5594_5131_5;
	R5131[6] = (char *(*)()) F648_5594;
	R5131[7] = (char *(*)()) F649_5594_5131_5;
	R5131[8] = (char *(*)()) F648_5594;
}
static EIF_REFERENCE F649_5594_5131_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F649_5594(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F650_5594_5131_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F650_5594(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F651_5594_5131_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5594(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5594_5131_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F652_5594(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F653_5594_5131_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F653_5594(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R5133[9])();
void R5133_init () {
	R5133[0] = (char *(*)()) F648_5597;
	R5133[1] = (char *(*)()) F649_5597;
	R5133[2] = (char *(*)()) F650_5597_5133_2;
	R5133[3] = (char *(*)()) F651_5597_5133_2;
	R5133[4] = (char *(*)()) F652_5597_5133_2;
	R5133[5] = (char *(*)()) F653_5597;
	R5133[6] = (char *(*)()) F648_5597;
	R5133[7] = (char *(*)()) F649_5597;
	R5133[8] = (char *(*)()) F648_5597;
}
static EIF_BOOLEAN F650_5597_5133_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F650_5597(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F651_5597_5133_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F651_5597(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F652_5597_5133_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F652_5597(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R5135[9])();
void R5135_init () {
	R5135[0] = (char *(*)()) F648_5600;
	R5135[1] = (char *(*)()) F649_5600_5135_1;
	R5135[2] = (char *(*)()) F650_5600;
	R5135[3] = (char *(*)()) F651_5600_5135_1;
	R5135[4] = (char *(*)()) F652_5600_5135_1;
	R5135[5] = (char *(*)()) F653_5600_5135_1;
	R5135[6] = (char *(*)()) F648_5600;
	R5135[7] = (char *(*)()) F649_5600_5135_1;
	R5135[8] = (char *(*)()) F648_5600;
}
static EIF_REFERENCE F649_5600_5135_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F649_5600(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F651_5600_5135_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5600(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5600_5135_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F652_5600(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F653_5600_5135_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F653_5600(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R5136[9])();
void R5136_init () {
	R5136[0] = (char *(*)()) F648_5601;
	R5136[1] = (char *(*)()) F649_5601;
	R5136[2] = (char *(*)()) F650_5601_5136_1;
	R5136[3] = (char *(*)()) F651_5601_5136_1;
	R5136[4] = (char *(*)()) F652_5601_5136_1;
	R5136[5] = (char *(*)()) F653_5601;
	R5136[6] = (char *(*)()) F648_5601;
	R5136[7] = (char *(*)()) F649_5601;
	R5136[8] = (char *(*)()) F648_5601;
}
static EIF_REFERENCE F650_5601_5136_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F650_5601(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F651_5601_5136_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5601(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5601_5136_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F652_5601(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R5138[9])();
void R5138_init () {
	R5138[0] = (char *(*)()) F648_5605;
	R5138[1] = (char *(*)()) F649_5605;
	R5138[2] = (char *(*)()) F650_5605_5138_73;
	R5138[3] = (char *(*)()) F651_5605_5138_73;
	R5138[4] = (char *(*)()) F652_5605_5138_73;
	R5138[5] = (char *(*)()) F653_5605;
	R5138[6] = (char *(*)()) F654_5702;
	R5138[7] = (char *(*)()) F655_5702;
	R5138[8] = (char *(*)()) F648_5605;
}
static EIF_INTEGER_32 F650_5605_5138_73 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F650_5605(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F651_5605_5138_73 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F651_5605(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F652_5605_5138_73 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F652_5605(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R5140[9])();
void R5140_init () {
	R5140[0] = (char *(*)()) F648_5612;
	R5140[1] = (char *(*)()) F649_5612;
	R5140[2] = (char *(*)()) F650_5612_5140_3;
	R5140[3] = (char *(*)()) F651_5612_5140_3;
	R5140[4] = (char *(*)()) F652_5612_5140_3;
	R5140[5] = (char *(*)()) F653_5612;
	R5140[6] = (char *(*)()) F654_5704;
	R5140[7] = (char *(*)()) F655_5704;
	R5140[8] = (char *(*)()) F648_5612;
}
static EIF_BOOLEAN F650_5612_5140_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F650_5612(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F651_5612_5140_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F651_5612(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F652_5612_5140_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F652_5612(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}

char *(*R5146[9])();
void R5146_init () {
	R5146[0] = (char *(*)()) F648_5620;
	R5146[1] = (char *(*)()) F649_5620;
	R5146[2] = (char *(*)()) F650_5620;
	R5146[3] = (char *(*)()) F651_5620;
	R5146[4] = (char *(*)()) F652_5620;
	R5146[5] = (char *(*)()) F653_5620;
	R5146[6] = (char *(*)()) F648_5620;
	R5146[7] = (char *(*)()) F649_5620;
	R5146[8] = (char *(*)()) F648_5620;
}

char *(*R5147[9])();
void R5147_init () {
	R5147[0] = (char *(*)()) F648_5621;
	R5147[1] = (char *(*)()) F649_5621;
	R5147[2] = (char *(*)()) F650_5621;
	R5147[3] = (char *(*)()) F651_5621;
	R5147[4] = (char *(*)()) F652_5621;
	R5147[5] = (char *(*)()) F653_5621;
	R5147[6] = (char *(*)()) F648_5621;
	R5147[7] = (char *(*)()) F649_5621;
	R5147[8] = (char *(*)()) F648_5621;
}

char *(*R5148[9])();
void R5148_init () {
	R5148[0] = (char *(*)()) F648_5622;
	R5148[1] = (char *(*)()) F649_5622;
	R5148[2] = (char *(*)()) F650_5622;
	R5148[3] = (char *(*)()) F651_5622;
	R5148[4] = (char *(*)()) F652_5622;
	R5148[5] = (char *(*)()) F653_5622;
	R5148[6] = (char *(*)()) F648_5622;
	R5148[7] = (char *(*)()) F649_5622;
	R5148[8] = (char *(*)()) F648_5622;
}

char *(*R5149[9])();
void R5149_init () {
	R5149[0] = (char *(*)()) F648_5623;
	R5149[1] = (char *(*)()) F649_5623;
	R5149[2] = (char *(*)()) F650_5623;
	R5149[3] = (char *(*)()) F651_5623;
	R5149[4] = (char *(*)()) F652_5623;
	R5149[5] = (char *(*)()) F653_5623;
	R5149[6] = (char *(*)()) F648_5623;
	R5149[7] = (char *(*)()) F649_5623;
	R5149[8] = (char *(*)()) F648_5623;
}

char *(*R5152[9])();
void R5152_init () {
	R5152[0] = (char *(*)()) F648_5627;
	R5152[1] = (char *(*)()) F649_5627;
	R5152[2] = (char *(*)()) F650_5627;
	R5152[3] = (char *(*)()) F651_5627;
	R5152[4] = (char *(*)()) F652_5627;
	R5152[5] = (char *(*)()) F653_5627;
	R5152[6] = (char *(*)()) F648_5627;
	R5152[7] = (char *(*)()) F649_5627;
	R5152[8] = (char *(*)()) F648_5627;
}

char *(*R5153[9])();
void R5153_init () {
	R5153[0] = (char *(*)()) F648_5628;
	R5153[1] = (char *(*)()) F649_5628;
	R5153[2] = (char *(*)()) F650_5628;
	R5153[3] = (char *(*)()) F651_5628;
	R5153[4] = (char *(*)()) F652_5628;
	R5153[5] = (char *(*)()) F653_5628;
	R5153[6] = (char *(*)()) F648_5628;
	R5153[7] = (char *(*)()) F649_5628;
	R5153[8] = (char *(*)()) F648_5628;
}

char *(*R5155[9])();
void R5155_init () {
	R5155[0] = (char *(*)()) F648_5630;
	R5155[1] = (char *(*)()) F649_5630;
	R5155[2] = (char *(*)()) F650_5630_5155_4;
	R5155[3] = (char *(*)()) F651_5630_5155_4;
	R5155[4] = (char *(*)()) F652_5630_5155_4;
	R5155[5] = (char *(*)()) F653_5630;
	R5155[6] = (char *(*)()) F648_5630;
	R5155[7] = (char *(*)()) F649_5630;
	R5155[8] = (char *(*)()) F648_5630;
}
static void F650_5630_5155_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F650_5630(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F651_5630_5155_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F651_5630(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F652_5630_5155_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F652_5630(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R5157[9])();
void R5157_init () {
	R5157[0] = (char *(*)()) F648_5632;
	R5157[1] = (char *(*)()) F649_5632;
	R5157[2] = (char *(*)()) F650_5632;
	R5157[3] = (char *(*)()) F651_5632;
	R5157[4] = (char *(*)()) F652_5632;
	R5157[5] = (char *(*)()) F653_5632;
	R5157[6] = (char *(*)()) F648_5632;
	R5157[7] = (char *(*)()) F649_5632;
	R5157[8] = (char *(*)()) F648_5632;
}

char *(*R5158[9])();
void R5158_init () {
	R5158[0] = (char *(*)()) F648_5633;
	R5158[1] = (char *(*)()) F649_5633;
	R5158[2] = (char *(*)()) F650_5633;
	R5158[3] = (char *(*)()) F651_5633;
	R5158[4] = (char *(*)()) F652_5633;
	R5158[5] = (char *(*)()) F653_5633;
	R5158[6] = (char *(*)()) F648_5633;
	R5158[7] = (char *(*)()) F649_5633;
	R5158[8] = (char *(*)()) F648_5633;
}

char *(*R5164[9])();
void R5164_init () {
	R5164[0] = (char *(*)()) F648_5646;
	R5164[1] = (char *(*)()) F649_5646;
	R5164[2] = (char *(*)()) F650_5646;
	R5164[3] = (char *(*)()) F651_5646;
	R5164[4] = (char *(*)()) F652_5646;
	R5164[5] = (char *(*)()) F653_5646;
	R5164[6] = (char *(*)()) F654_5706;
	R5164[7] = (char *(*)()) F655_5706;
	R5164[8] = (char *(*)()) F648_5646;
}

char *(*R5173[9])();
void R5173_init () {
	R5173[0] = (char *(*)()) F648_5656;
	R5173[1] = (char *(*)()) F649_5656;
	R5173[2] = (char *(*)()) F650_5656;
	R5173[3] = (char *(*)()) F651_5656;
	R5173[4] = (char *(*)()) F652_5656;
	R5173[5] = (char *(*)()) F653_5656;
	R5173[6] = (char *(*)()) F648_5656;
	R5173[7] = (char *(*)()) F649_5656;
	R5173[8] = (char *(*)()) F648_5656;
}

char *(*R5174[9])();
void R5174_init () {
	R5174[0] = (char *(*)()) F648_5657;
	R5174[1] = (char *(*)()) F649_5657;
	R5174[2] = (char *(*)()) F650_5657;
	R5174[3] = (char *(*)()) F651_5657;
	R5174[4] = (char *(*)()) F652_5657;
	R5174[5] = (char *(*)()) F653_5657;
	R5174[6] = (char *(*)()) F648_5657;
	R5174[7] = (char *(*)()) F649_5657;
	R5174[8] = (char *(*)()) F648_5657;
}

char *(*R5181[9])();
void R5181_init () {
	R5181[0] = (char *(*)()) F648_5664;
	R5181[1] = (char *(*)()) F649_5664_5181_1;
	R5181[2] = (char *(*)()) F650_5664;
	R5181[3] = (char *(*)()) F651_5664_5181_1;
	R5181[4] = (char *(*)()) F652_5664_5181_1;
	R5181[5] = (char *(*)()) F653_5664_5181_1;
	R5181[6] = (char *(*)()) F648_5664;
	R5181[7] = (char *(*)()) F649_5664_5181_1;
	R5181[8] = (char *(*)()) F648_5664;
}
static EIF_REFERENCE F649_5664_5181_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F649_5664(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F651_5664_5181_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5664(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5664_5181_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F652_5664(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F653_5664_5181_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F653_5664(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R5182[9])();
void R5182_init () {
	R5182[0] = (char *(*)()) F648_5665;
	R5182[1] = (char *(*)()) F649_5665;
	R5182[2] = (char *(*)()) F650_5665_5182_1;
	R5182[3] = (char *(*)()) F651_5665_5182_1;
	R5182[4] = (char *(*)()) F652_5665_5182_1;
	R5182[5] = (char *(*)()) F653_5665;
	R5182[6] = (char *(*)()) F648_5665;
	R5182[7] = (char *(*)()) F649_5665;
	R5182[8] = (char *(*)()) F648_5665;
}
static EIF_REFERENCE F650_5665_5182_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F650_5665(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F651_5665_5182_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5665(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5665_5182_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F652_5665(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R5183[9])();
void R5183_init () {
	R5183[0] = (char *(*)()) F648_5666;
	R5183[1] = (char *(*)()) F649_5666;
	R5183[2] = (char *(*)()) F650_5666;
	R5183[3] = (char *(*)()) F651_5666;
	R5183[4] = (char *(*)()) F652_5666;
	R5183[5] = (char *(*)()) F653_5666;
	R5183[6] = (char *(*)()) F648_5666;
	R5183[7] = (char *(*)()) F649_5666;
	R5183[8] = (char *(*)()) F648_5666;
}

char *(*R5184[9])();
void R5184_init () {
	R5184[0] = (char *(*)()) F648_5667;
	R5184[1] = (char *(*)()) F649_5667;
	R5184[2] = (char *(*)()) F650_5667;
	R5184[3] = (char *(*)()) F651_5667;
	R5184[4] = (char *(*)()) F652_5667;
	R5184[5] = (char *(*)()) F653_5667;
	R5184[6] = (char *(*)()) F648_5667;
	R5184[7] = (char *(*)()) F649_5667;
	R5184[8] = (char *(*)()) F648_5667;
}

char *(*R5185[9])();
void R5185_init () {
	R5185[0] = (char *(*)()) F648_5668;
	R5185[1] = (char *(*)()) F649_5668;
	R5185[2] = (char *(*)()) F650_5668;
	R5185[3] = (char *(*)()) F651_5668;
	R5185[4] = (char *(*)()) F652_5668;
	R5185[5] = (char *(*)()) F653_5668;
	R5185[6] = (char *(*)()) F648_5668;
	R5185[7] = (char *(*)()) F649_5668;
	R5185[8] = (char *(*)()) F648_5668;
}

char *(*R5186[9])();
void R5186_init () {
	R5186[0] = (char *(*)()) F648_5669;
	R5186[1] = (char *(*)()) F649_5669;
	R5186[2] = (char *(*)()) F650_5669;
	R5186[3] = (char *(*)()) F651_5669;
	R5186[4] = (char *(*)()) F652_5669;
	R5186[5] = (char *(*)()) F653_5669;
	R5186[6] = (char *(*)()) F648_5669;
	R5186[7] = (char *(*)()) F649_5669;
	R5186[8] = (char *(*)()) F648_5669;
}

char *(*R5187[9])();
void R5187_init () {
	R5187[0] = (char *(*)()) F648_5670;
	R5187[1] = (char *(*)()) F649_5670;
	R5187[2] = (char *(*)()) F650_5670;
	R5187[3] = (char *(*)()) F651_5670;
	R5187[4] = (char *(*)()) F652_5670;
	R5187[5] = (char *(*)()) F653_5670;
	R5187[6] = (char *(*)()) F648_5670;
	R5187[7] = (char *(*)()) F649_5670;
	R5187[8] = (char *(*)()) F648_5670;
}

char *(*R5189[9])();
void R5189_init () {
	R5189[0] = (char *(*)()) F648_5672;
	R5189[1] = (char *(*)()) F649_5672;
	R5189[2] = (char *(*)()) F650_5672;
	R5189[3] = (char *(*)()) F651_5672;
	R5189[4] = (char *(*)()) F652_5672;
	R5189[5] = (char *(*)()) F653_5672;
	R5189[6] = (char *(*)()) F648_5672;
	R5189[7] = (char *(*)()) F649_5672;
	R5189[8] = (char *(*)()) F648_5672;
}

char *(*R5190[9])();
void R5190_init () {
	R5190[0] = (char *(*)()) F648_5673;
	R5190[1] = (char *(*)()) F649_5673;
	R5190[2] = (char *(*)()) F650_5673;
	R5190[3] = (char *(*)()) F651_5673;
	R5190[4] = (char *(*)()) F652_5673;
	R5190[5] = (char *(*)()) F653_5673;
	R5190[6] = (char *(*)()) F648_5673;
	R5190[7] = (char *(*)()) F649_5673;
	R5190[8] = (char *(*)()) F648_5673;
}

char *(*R5191[9])();
void R5191_init () {
	R5191[0] = (char *(*)()) F648_5674;
	R5191[1] = (char *(*)()) F649_5674;
	R5191[2] = (char *(*)()) F650_5674;
	R5191[3] = (char *(*)()) F651_5674;
	R5191[4] = (char *(*)()) F652_5674;
	R5191[5] = (char *(*)()) F653_5674;
	R5191[6] = (char *(*)()) F648_5674;
	R5191[7] = (char *(*)()) F649_5674;
	R5191[8] = (char *(*)()) F648_5674;
}

char *(*R5195[9])();
void R5195_init () {
	R5195[0] = (char *(*)()) F648_5678;
	R5195[1] = (char *(*)()) F649_5678;
	R5195[2] = (char *(*)()) F650_5678_5195_4;
	R5195[3] = (char *(*)()) F651_5678_5195_4;
	R5195[4] = (char *(*)()) F652_5678_5195_4;
	R5195[5] = (char *(*)()) F653_5678;
	R5195[6] = (char *(*)()) F648_5678;
	R5195[7] = (char *(*)()) F649_5678;
	R5195[8] = (char *(*)()) F648_5678;
}
static void F650_5678_5195_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F650_5678(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F651_5678_5195_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F651_5678(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F652_5678_5195_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F652_5678(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R5201[9])();
void R5201_init () {
	R5201[0] = (char *(*)()) F648_5684;
	R5201[1] = (char *(*)()) F649_5684;
	R5201[2] = (char *(*)()) F650_5684;
	R5201[3] = (char *(*)()) F651_5684;
	R5201[4] = (char *(*)()) F652_5684;
	R5201[5] = (char *(*)()) F653_5684;
	R5201[6] = (char *(*)()) F648_5684;
	R5201[7] = (char *(*)()) F649_5684;
	R5201[8] = (char *(*)()) F648_5684;
}

char *(*R5214[9])();
void R5214_init () {
	R5214[0] = (char *(*)()) F648_5697;
	R5214[1] = (char *(*)()) F649_5697;
	R5214[2] = (char *(*)()) F650_5697;
	R5214[3] = (char *(*)()) F651_5697;
	R5214[4] = (char *(*)()) F652_5697;
	R5214[5] = (char *(*)()) F653_5697;
	R5214[6] = (char *(*)()) F648_5697;
	R5214[7] = (char *(*)()) F649_5697;
	R5214[8] = (char *(*)()) F648_5697;
}

char *(*R5217[2])();
void R5217_init () {
	R5217[0] = (char *(*)()) F654_5700;
	R5217[1] = (char *(*)()) F655_5700;
}

char *(*R5230[43])();
void R5230_init () {
	R5230[0] = (char *(*)()) F657_5719;
	R5230[1] = (char *(*)()) F658_5719;
	R5230[2] = (char *(*)()) F659_5719;
	R5230[3] = (char *(*)()) F660_5719;
	R5230[4] = (char *(*)()) F661_5719;
	R5230[5] = (char *(*)()) F662_5719;
	R5230[6] = (char *(*)()) F663_5719;
	R5230[7] = (char *(*)()) F664_5719;
	R5230[8] = (char *(*)()) F665_5719;
	R5230[9] = (char *(*)()) F666_5719;
	R5230[10] = (char *(*)()) F667_5719;
	R5230[11] = (char *(*)()) F668_5719;
	R5230[12] = (char *(*)()) F657_5719;
	R5230[13] = (char *(*)()) F658_5719;
	R5230[14] = (char *(*)()) F664_5719;
	R5230[19] = (char *(*)()) F657_5719;
	R5230[20] = (char *(*)()) F658_5719;
	{long i; for (i = 21; i < 25; i++) R5230[i] = (char *(*)()) F657_5719;}
	R5230[29] = (char *(*)()) F657_5719;
	R5230[31] = (char *(*)()) F657_5719;
	R5230[35] = (char *(*)()) F657_5719;
	{long i; for (i = 37; i < 39; i++) R5230[i] = (char *(*)()) F657_5719;}
	{long i; for (i = 40; i < 43; i++) R5230[i] = (char *(*)()) F657_5719;}
}

char *(*R5234[43])();
void R5234_init () {
	R5234[0] = (char *(*)()) F657_5723;
	R5234[1] = (char *(*)()) F658_5723;
	R5234[2] = (char *(*)()) F659_5723;
	R5234[3] = (char *(*)()) F660_5723;
	R5234[4] = (char *(*)()) F661_5723;
	R5234[5] = (char *(*)()) F662_5723;
	R5234[6] = (char *(*)()) F663_5723;
	R5234[7] = (char *(*)()) F664_5723;
	R5234[8] = (char *(*)()) F665_5723;
	R5234[9] = (char *(*)()) F666_5723;
	R5234[10] = (char *(*)()) F667_5723;
	R5234[11] = (char *(*)()) F668_5723;
	R5234[12] = (char *(*)()) F657_5723;
	R5234[13] = (char *(*)()) F658_5723;
	R5234[14] = (char *(*)()) F664_5723;
	R5234[19] = (char *(*)()) F657_5723;
	R5234[20] = (char *(*)()) F658_5723;
	{long i; for (i = 21; i < 25; i++) R5234[i] = (char *(*)()) F657_5723;}
	R5234[29] = (char *(*)()) F657_5723;
	R5234[31] = (char *(*)()) F657_5723;
	R5234[35] = (char *(*)()) F657_5723;
	{long i; for (i = 37; i < 39; i++) R5234[i] = (char *(*)()) F657_5723;}
	{long i; for (i = 40; i < 43; i++) R5234[i] = (char *(*)()) F657_5723;}
}

char *(*R5238[43])();
void R5238_init () {
	R5238[0] = (char *(*)()) F657_5742;
	R5238[1] = (char *(*)()) F658_5742;
	R5238[2] = (char *(*)()) F659_5742;
	R5238[3] = (char *(*)()) F660_5742;
	R5238[4] = (char *(*)()) F661_5742;
	R5238[5] = (char *(*)()) F662_5742;
	R5238[6] = (char *(*)()) F663_5742;
	R5238[7] = (char *(*)()) F664_5742;
	R5238[8] = (char *(*)()) F665_5742;
	R5238[9] = (char *(*)()) F666_5742;
	R5238[10] = (char *(*)()) F667_5742;
	R5238[11] = (char *(*)()) F668_5742;
	R5238[12] = (char *(*)()) F657_5742;
	R5238[13] = (char *(*)()) F658_5742;
	R5238[14] = (char *(*)()) F664_5742;
	R5238[19] = (char *(*)()) F657_5742;
	R5238[20] = (char *(*)()) F658_5742;
	{long i; for (i = 21; i < 25; i++) R5238[i] = (char *(*)()) F657_5742;}
	R5238[29] = (char *(*)()) F657_5742;
	R5238[31] = (char *(*)()) F657_5742;
	R5238[35] = (char *(*)()) F657_5742;
	{long i; for (i = 37; i < 39; i++) R5238[i] = (char *(*)()) F657_5742;}
	{long i; for (i = 40; i < 43; i++) R5238[i] = (char *(*)()) F657_5742;}
}

char *(*R5242[43])();
void R5242_init () {
	R5242[0] = (char *(*)()) F657_5783;
	R5242[1] = (char *(*)()) F658_5783_5242_250;
	R5242[2] = (char *(*)()) F659_5783_5242_250;
	R5242[3] = (char *(*)()) F660_5783_5242_250;
	R5242[4] = (char *(*)()) F661_5783_5242_250;
	R5242[5] = (char *(*)()) F662_5783_5242_250;
	R5242[6] = (char *(*)()) F663_5783_5242_250;
	R5242[7] = (char *(*)()) F664_5783_5242_250;
	R5242[8] = (char *(*)()) F665_5783_5242_250;
	R5242[9] = (char *(*)()) F666_5783_5242_250;
	R5242[10] = (char *(*)()) F667_5783_5242_250;
	R5242[11] = (char *(*)()) F668_5783_5242_250;
	R5242[12] = (char *(*)()) F657_5783;
	R5242[13] = (char *(*)()) F658_5783_5242_250;
	R5242[14] = (char *(*)()) F664_5783_5242_250;
	R5242[19] = (char *(*)()) F657_5783;
	R5242[20] = (char *(*)()) F658_5783_5242_250;
	{long i; for (i = 21; i < 25; i++) R5242[i] = (char *(*)()) F657_5783;}
	R5242[29] = (char *(*)()) F657_5783;
	R5242[31] = (char *(*)()) F657_5783;
	R5242[35] = (char *(*)()) F657_5783;
	{long i; for (i = 37; i < 39; i++) R5242[i] = (char *(*)()) F657_5783;}
	{long i; for (i = 40; i < 43; i++) R5242[i] = (char *(*)()) F657_5783;}
}
static void F658_5783_5242_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F658_5783(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F659_5783_5242_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F659_5783(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F660_5783_5242_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F660_5783(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F661_5783_5242_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F661_5783(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F662_5783_5242_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F662_5783(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F663_5783_5242_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F663_5783(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F664_5783_5242_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F664_5783(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F665_5783_5242_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F665_5783(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F666_5783_5242_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F666_5783(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F667_5783_5242_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F667_5783(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F668_5783_5242_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F668_5783(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5246[3])();
void R5246_init () {
	R5246[0] = (char *(*)()) F657_5760;
	R5246[1] = (char *(*)()) F658_5760_5246_4;
	R5246[2] = (char *(*)()) F664_5760_5246_4;
}
static void F658_5760_5246_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5760(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F664_5760_5246_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5760(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R5247[3])();
void R5247_init () {
	R5247[0] = (char *(*)()) F657_5773;
	R5247[1] = (char *(*)()) F658_5773;
	R5247[2] = (char *(*)()) F664_5773;
}

char *(*R5248[24])();
void R5248_init () {
	R5248[0] = (char *(*)()) F676_5828;
	R5248[1] = (char *(*)()) F677_5828_5248_250;
	R5248[2] = (char *(*)()) F676_5828;
	{long i; for (i = 3; i < 6; i++) R5248[i] = (char *(*)()) F679_5837;}
	R5248[10] = (char *(*)()) F679_5837;
	R5248[12] = (char *(*)()) F679_5837;
	R5248[16] = (char *(*)()) F679_5837;
	{long i; for (i = 18; i < 20; i++) R5248[i] = (char *(*)()) F679_5837;}
	{long i; for (i = 21; i < 24; i++) R5248[i] = (char *(*)()) F679_5837;}
}
static void F677_5828_5248_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F677_5828(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R5249[24])();
void R5249_init () {
	R5249[0] = (char *(*)()) F676_5829;
	R5249[1] = (char *(*)()) F677_5829_5249_250;
	R5249[2] = (char *(*)()) F676_5829;
	{long i; for (i = 3; i < 6; i++) R5249[i] = (char *(*)()) F679_5838;}
	R5249[10] = (char *(*)()) F679_5838;
	R5249[12] = (char *(*)()) F679_5838;
	R5249[16] = (char *(*)()) F679_5838;
	{long i; for (i = 18; i < 20; i++) R5249[i] = (char *(*)()) F679_5838;}
	{long i; for (i = 21; i < 24; i++) R5249[i] = (char *(*)()) F679_5838;}
}
static void F677_5829_5249_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F677_5829(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R5253[24])();
void R5253_init () {
	R5253[0] = (char *(*)()) F672_5817;
	R5253[1] = (char *(*)()) F673_5817_5253_250;
	{long i; for (i = 2; i < 6; i++) R5253[i] = (char *(*)()) F672_5817;}
	R5253[10] = (char *(*)()) F672_5817;
	R5253[12] = (char *(*)()) F672_5817;
	R5253[16] = (char *(*)()) F672_5817;
	{long i; for (i = 18; i < 20; i++) R5253[i] = (char *(*)()) F672_5817;}
	{long i; for (i = 21; i < 24; i++) R5253[i] = (char *(*)()) F672_5817;}
}
static void F673_5817_5253_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F673_5817(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R5254[24])();
void R5254_init () {
	R5254[0] = (char *(*)()) F672_5818;
	R5254[1] = (char *(*)()) F673_5818_5254_250;
	{long i; for (i = 2; i < 6; i++) R5254[i] = (char *(*)()) F672_5818;}
	R5254[10] = (char *(*)()) F672_5818;
	R5254[12] = (char *(*)()) F672_5818;
	R5254[16] = (char *(*)()) F672_5818;
	{long i; for (i = 18; i < 20; i++) R5254[i] = (char *(*)()) F672_5818;}
	{long i; for (i = 21; i < 24; i++) R5254[i] = (char *(*)()) F672_5818;}
}
static void F673_5818_5254_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F673_5818(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R5262[21])();
void R5262_init () {
	R5262[0] = (char *(*)()) F679_5839;
	R5262[1] = (char *(*)()) F680_5873;
	R5262[2] = (char *(*)()) F681_5874;
	R5262[7] = (char *(*)()) F680_5873;
	R5262[9] = (char *(*)()) F680_5873;
	R5262[13] = (char *(*)()) F680_5873;
	{long i; for (i = 15; i < 17; i++) R5262[i] = (char *(*)()) F680_5873;}
	{long i; for (i = 18; i < 21; i++) R5262[i] = (char *(*)()) F680_5873;}
}

static EIF_TYPE_INDEX Y5294_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype2[] = {0xFFF9,1,966,0xFF01,0,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype4[] = {0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype5[] = {0xFF01,0xFFF9,1,966,0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype6[] = {0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype7[] = {0xFF01,0xFFF9,1,966,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype8[] = {0xFF01,0xFFF9,1,966,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype9[] = {0xFF01,0xFFF9,1,966,0xFF01,1101,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype10[] = {0xFF01,0xFFF9,1,966,927,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype11[] = {0xFF01,0xFFF9,5,966,996,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype12[] = {0xFF01,0xFFF9,1,966,0xFF01,1050,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype13[] = {0xFF01,0xFFF9,1,966,0xFF01,1371,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype14[] = {0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype15[] = {0xFF01,0xFFF9,4,966,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype16[] = {0xFF01,0xFFF9,7,966,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype17[] = {0xFF01,0xFFF9,2,966,984,984,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype18[] = {0xFF01,0xFFF9,3,966,984,984,927,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype19[] = {0xFF01,0xFFF9,8,966,984,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y5294_pgtype20[] = {0xFF01,0xFFF9,0,966,0xFFFF};
EIF_TYPE_INDEX *Y5294_gen_type [21];
EIF_TYPE_INDEX Y5294 [21];
void Y5294_init (void)
{
	egc_routines_types [5294] = Y5294;
	egc_routines_gen_types [5294] = Y5294_gen_type;
	egc_routines_offset [5294] = 678;
	Y5294_gen_type [0] = Y5294_pgtype0;
	Y5294_gen_type [1] = Y5294_pgtype1;
	Y5294_gen_type [2] = Y5294_pgtype2;
	Y5294_gen_type [3] = Y5294_pgtype3;
	Y5294_gen_type [4] = Y5294_pgtype4;
	Y5294_gen_type [5] = Y5294_pgtype5;
	Y5294_gen_type [6] = Y5294_pgtype6;
	Y5294_gen_type [7] = Y5294_pgtype7;
	Y5294_gen_type [8] = Y5294_pgtype8;
	Y5294_gen_type [9] = Y5294_pgtype9;
	Y5294_gen_type [10] = Y5294_pgtype10;
	Y5294_gen_type [11] = Y5294_pgtype11;
	Y5294_gen_type [12] = Y5294_pgtype12;
	Y5294_gen_type [13] = Y5294_pgtype13;
	Y5294_gen_type [14] = Y5294_pgtype14;
	Y5294_gen_type [15] = Y5294_pgtype15;
	Y5294_gen_type [16] = Y5294_pgtype16;
	Y5294_gen_type [17] = Y5294_pgtype17;
	Y5294_gen_type [18] = Y5294_pgtype18;
	Y5294_gen_type [19] = Y5294_pgtype19;
	Y5294_gen_type [20] = Y5294_pgtype20;
	Y5294[2] = 966;
	{long i; for (i = 4; i < 21; i++) Y5294[i] = 966;};
}

char *(*R5444[192])();
void R5444_init () {
	R5444[0] = (char *(*)()) F721_6080;
	R5444[1] = (char *(*)()) F482_5211_5444_1;
	R5444[6] = (char *(*)()) F482_5211_5444_1;
	R5444[37] = (char *(*)()) F746_6181;
	R5444[38] = (char *(*)()) F747_6181_5444_1;
	R5444[39] = (char *(*)()) F748_6181_5444_1;
	R5444[40] = (char *(*)()) F749_6181_5444_1;
	R5444[41] = (char *(*)()) F750_6181_5444_1;
	R5444[42] = (char *(*)()) F751_6181_5444_1;
	R5444[43] = (char *(*)()) F752_6181_5444_1;
	R5444[44] = (char *(*)()) F753_6181_5444_1;
	R5444[45] = (char *(*)()) F754_6181_5444_1;
	R5444[46] = (char *(*)()) F755_6181_5444_1;
	R5444[47] = (char *(*)()) F756_6181_5444_1;
	R5444[48] = (char *(*)()) F757_6181_5444_1;
	R5444[49] = (char *(*)()) F770_6209;
	R5444[50] = (char *(*)()) F771_6209_5444_1;
	R5444[51] = (char *(*)()) F772_6209_5444_1;
	R5444[52] = (char *(*)()) F773_6215;
	R5444[53] = (char *(*)()) F774_6215_5444_1;
	R5444[54] = (char *(*)()) F775_6215;
	R5444[55] = (char *(*)()) F776_6215_5444_1;
	R5444[56] = (char *(*)()) F777_6215_5444_1;
	R5444[57] = (char *(*)()) F778_6215_5444_1;
	R5444[70] = (char *(*)()) F779_6221;
	R5444[71] = (char *(*)()) F780_6221_5444_1;
	R5444[72] = (char *(*)()) F781_6221_5444_1;
	R5444[73] = (char *(*)()) F782_6221_5444_1;
	R5444[74] = (char *(*)()) F783_6221_5444_1;
	R5444[75] = (char *(*)()) F784_6221_5444_1;
	R5444[76] = (char *(*)()) F785_6221_5444_1;
	R5444[77] = (char *(*)()) F786_6221_5444_1;
	R5444[78] = (char *(*)()) F787_6221_5444_1;
	R5444[79] = (char *(*)()) F788_6221_5444_1;
	R5444[80] = (char *(*)()) F789_6221_5444_1;
	R5444[81] = (char *(*)()) F790_6221_5444_1;
	R5444[82] = (char *(*)()) F787_6221_5444_1;
	R5444[83] = (char *(*)()) F785_6221_5444_1;
	R5444[84] = (char *(*)()) F779_6221;
	R5444[85] = (char *(*)()) F780_6221_5444_1;
	R5444[86] = (char *(*)()) F781_6221_5444_1;
	R5444[87] = (char *(*)()) F782_6221_5444_1;
	R5444[88] = (char *(*)()) F783_6221_5444_1;
	R5444[89] = (char *(*)()) F784_6221_5444_1;
	R5444[90] = (char *(*)()) F785_6221_5444_1;
	R5444[91] = (char *(*)()) F786_6221_5444_1;
	R5444[92] = (char *(*)()) F787_6221_5444_1;
	R5444[93] = (char *(*)()) F788_6221_5444_1;
	R5444[94] = (char *(*)()) F789_6221_5444_1;
	R5444[95] = (char *(*)()) F790_6221_5444_1;
	R5444[96] = (char *(*)()) F779_6221;
	R5444[97] = (char *(*)()) F780_6221_5444_1;
	R5444[98] = (char *(*)()) F781_6221_5444_1;
	R5444[99] = (char *(*)()) F782_6221_5444_1;
	R5444[100] = (char *(*)()) F783_6221_5444_1;
	R5444[101] = (char *(*)()) F784_6221_5444_1;
	R5444[102] = (char *(*)()) F785_6221_5444_1;
	R5444[103] = (char *(*)()) F786_6221_5444_1;
	R5444[104] = (char *(*)()) F787_6221_5444_1;
	R5444[105] = (char *(*)()) F788_6221_5444_1;
	R5444[106] = (char *(*)()) F789_6221_5444_1;
	R5444[107] = (char *(*)()) F790_6221_5444_1;
	R5444[191] = (char *(*)()) F912_6712_5444_1;
}
static EIF_REFERENCE F482_5211_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F482_5211(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F747_6181_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F747_6181(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F748_6181_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F748_6181(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F749_6181_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F749_6181(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F750_6181_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F750_6181(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F751_6181_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F751_6181(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F752_6181_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F752_6181(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F753_6181_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F753_6181(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F754_6181_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F754_6181(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F755_6181_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F755_6181(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F756_6181_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F756_6181(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F757_6181_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F757_6181(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F771_6209_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F771_6209(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F772_6209_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F772_6209(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F774_6215_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F774_6215(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F776_6215_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F776_6215(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F777_6215_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F777_6215(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F778_6215_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F778_6215(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F780_6221_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F780_6221(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F781_6221_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F781_6221(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F782_6221_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F782_6221(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F783_6221_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F783_6221(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F784_6221_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F784_6221(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F785_6221_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F785_6221(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F786_6221_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F786_6221(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F787_6221_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F787_6221(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F788_6221_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F788_6221(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F789_6221_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F789_6221(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F790_6221_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F790_6221(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F912_6712_5444_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F912_6712(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R5445[192])();
void R5445_init () {
	R5445[0] = (char *(*)()) F721_6081;
	R5445[1] = (char *(*)()) F482_5212;
	R5445[6] = (char *(*)()) F482_5212;
	R5445[37] = (char *(*)()) F758_6199;
	R5445[38] = (char *(*)()) F759_6199;
	R5445[39] = (char *(*)()) F760_6199;
	R5445[40] = (char *(*)()) F761_6199;
	R5445[41] = (char *(*)()) F762_6199;
	R5445[42] = (char *(*)()) F763_6199;
	R5445[43] = (char *(*)()) F764_6199;
	R5445[44] = (char *(*)()) F765_6199;
	R5445[45] = (char *(*)()) F766_6199;
	R5445[46] = (char *(*)()) F767_6199;
	R5445[47] = (char *(*)()) F768_6199;
	R5445[48] = (char *(*)()) F769_6199;
	R5445[49] = (char *(*)()) F770_6210;
	R5445[50] = (char *(*)()) F771_6210;
	R5445[51] = (char *(*)()) F772_6210;
	R5445[52] = (char *(*)()) F773_6218;
	R5445[53] = (char *(*)()) F774_6218;
	R5445[54] = (char *(*)()) F775_6218;
	R5445[55] = (char *(*)()) F776_6218;
	R5445[56] = (char *(*)()) F777_6218;
	R5445[57] = (char *(*)()) F778_6218;
	R5445[70] = (char *(*)()) F779_6230;
	R5445[71] = (char *(*)()) F780_6230;
	R5445[72] = (char *(*)()) F781_6230;
	R5445[73] = (char *(*)()) F782_6230;
	R5445[74] = (char *(*)()) F783_6230;
	R5445[75] = (char *(*)()) F784_6230;
	R5445[76] = (char *(*)()) F785_6230;
	R5445[77] = (char *(*)()) F786_6230;
	R5445[78] = (char *(*)()) F787_6230;
	R5445[79] = (char *(*)()) F788_6230;
	R5445[80] = (char *(*)()) F789_6230;
	R5445[81] = (char *(*)()) F790_6230;
	R5445[82] = (char *(*)()) F787_6230;
	R5445[83] = (char *(*)()) F785_6230;
	R5445[84] = (char *(*)()) F779_6230;
	R5445[85] = (char *(*)()) F780_6230;
	R5445[86] = (char *(*)()) F781_6230;
	R5445[87] = (char *(*)()) F782_6230;
	R5445[88] = (char *(*)()) F783_6230;
	R5445[89] = (char *(*)()) F784_6230;
	R5445[90] = (char *(*)()) F785_6230;
	R5445[91] = (char *(*)()) F786_6230;
	R5445[92] = (char *(*)()) F787_6230;
	R5445[93] = (char *(*)()) F788_6230;
	R5445[94] = (char *(*)()) F789_6230;
	R5445[95] = (char *(*)()) F790_6230;
	R5445[96] = (char *(*)()) F779_6230;
	R5445[97] = (char *(*)()) F780_6230;
	R5445[98] = (char *(*)()) F781_6230;
	R5445[99] = (char *(*)()) F782_6230;
	R5445[100] = (char *(*)()) F783_6230;
	R5445[101] = (char *(*)()) F784_6230;
	R5445[102] = (char *(*)()) F785_6230;
	R5445[103] = (char *(*)()) F786_6230;
	R5445[104] = (char *(*)()) F787_6230;
	R5445[105] = (char *(*)()) F788_6230;
	R5445[106] = (char *(*)()) F789_6230;
	R5445[107] = (char *(*)()) F790_6230;
	R5445[191] = (char *(*)()) F912_6714;
}

char *(*R5446[192])();
void R5446_init () {
	R5446[0] = (char *(*)()) F721_6082;
	R5446[1] = (char *(*)()) F482_5218;
	R5446[6] = (char *(*)()) F482_5218;
	R5446[37] = (char *(*)()) F758_6207;
	R5446[38] = (char *(*)()) F759_6207;
	R5446[39] = (char *(*)()) F760_6207;
	R5446[40] = (char *(*)()) F761_6207;
	R5446[41] = (char *(*)()) F762_6207;
	R5446[42] = (char *(*)()) F763_6207;
	R5446[43] = (char *(*)()) F764_6207;
	R5446[44] = (char *(*)()) F765_6207;
	R5446[45] = (char *(*)()) F766_6207;
	R5446[46] = (char *(*)()) F767_6207;
	R5446[47] = (char *(*)()) F768_6207;
	R5446[48] = (char *(*)()) F769_6207;
	R5446[49] = (char *(*)()) F770_6212;
	R5446[50] = (char *(*)()) F771_6212;
	R5446[51] = (char *(*)()) F772_6212;
	R5446[52] = (char *(*)()) F773_6219;
	R5446[53] = (char *(*)()) F774_6219;
	R5446[54] = (char *(*)()) F775_6219;
	R5446[55] = (char *(*)()) F776_6219;
	R5446[56] = (char *(*)()) F777_6219;
	R5446[57] = (char *(*)()) F778_6219;
	R5446[70] = (char *(*)()) F779_6236;
	R5446[71] = (char *(*)()) F780_6236;
	R5446[72] = (char *(*)()) F781_6236;
	R5446[73] = (char *(*)()) F782_6236;
	R5446[74] = (char *(*)()) F783_6236;
	R5446[75] = (char *(*)()) F784_6236;
	R5446[76] = (char *(*)()) F785_6236;
	R5446[77] = (char *(*)()) F786_6236;
	R5446[78] = (char *(*)()) F787_6236;
	R5446[79] = (char *(*)()) F788_6236;
	R5446[80] = (char *(*)()) F789_6236;
	R5446[81] = (char *(*)()) F790_6236;
	R5446[82] = (char *(*)()) F787_6236;
	R5446[83] = (char *(*)()) F785_6236;
	R5446[84] = (char *(*)()) F779_6236;
	R5446[85] = (char *(*)()) F780_6236;
	R5446[86] = (char *(*)()) F781_6236;
	R5446[87] = (char *(*)()) F782_6236;
	R5446[88] = (char *(*)()) F783_6236;
	R5446[89] = (char *(*)()) F784_6236;
	R5446[90] = (char *(*)()) F785_6236;
	R5446[91] = (char *(*)()) F786_6236;
	R5446[92] = (char *(*)()) F787_6236;
	R5446[93] = (char *(*)()) F788_6236;
	R5446[94] = (char *(*)()) F789_6236;
	R5446[95] = (char *(*)()) F790_6236;
	R5446[96] = (char *(*)()) F779_6236;
	R5446[97] = (char *(*)()) F780_6236;
	R5446[98] = (char *(*)()) F781_6236;
	R5446[99] = (char *(*)()) F782_6236;
	R5446[100] = (char *(*)()) F783_6236;
	R5446[101] = (char *(*)()) F784_6236;
	R5446[102] = (char *(*)()) F785_6236;
	R5446[103] = (char *(*)()) F786_6236;
	R5446[104] = (char *(*)()) F787_6236;
	R5446[105] = (char *(*)()) F788_6236;
	R5446[106] = (char *(*)()) F789_6236;
	R5446[107] = (char *(*)()) F790_6236;
	R5446[191] = (char *(*)()) F912_6715;
}

static EIF_TYPE_INDEX Y5447_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype13[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype16[] = {0xFF01,30,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype17[] = {972,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype18[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype94[] = {972,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype95[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5447_pgtype120[] = {975,0xFFFF};
EIF_TYPE_INDEX *Y5447_gen_type [204];
EIF_TYPE_INDEX Y5447 [204];
void Y5447_init (void)
{
	egc_routines_types [5447] = Y5447;
	egc_routines_gen_types [5447] = Y5447_gen_type;
	egc_routines_offset [5447] = 708;
	Y5447_gen_type [0] = Y5447_pgtype0;
	Y5447_gen_type [1] = Y5447_pgtype1;
	Y5447_gen_type [2] = Y5447_pgtype2;
	Y5447_gen_type [3] = Y5447_pgtype3;
	Y5447_gen_type [4] = Y5447_pgtype4;
	Y5447_gen_type [5] = Y5447_pgtype5;
	Y5447_gen_type [6] = Y5447_pgtype6;
	Y5447_gen_type [7] = Y5447_pgtype7;
	Y5447_gen_type [8] = Y5447_pgtype8;
	Y5447_gen_type [9] = Y5447_pgtype9;
	Y5447_gen_type [10] = Y5447_pgtype10;
	Y5447_gen_type [11] = Y5447_pgtype11;
	Y5447_gen_type [12] = Y5447_pgtype12;
	Y5447_gen_type [13] = Y5447_pgtype13;
	Y5447_gen_type [14] = Y5447_pgtype14;
	Y5447_gen_type [15] = Y5447_pgtype15;
	Y5447_gen_type [16] = Y5447_pgtype16;
	Y5447_gen_type [17] = Y5447_pgtype17;
	Y5447_gen_type [18] = Y5447_pgtype18;
	Y5447_gen_type [19] = Y5447_pgtype19;
	Y5447_gen_type [20] = Y5447_pgtype20;
	Y5447_gen_type [21] = Y5447_pgtype21;
	Y5447_gen_type [22] = Y5447_pgtype22;
	Y5447_gen_type [23] = Y5447_pgtype23;
	Y5447_gen_type [24] = Y5447_pgtype24;
	Y5447_gen_type [25] = Y5447_pgtype25;
	Y5447_gen_type [26] = Y5447_pgtype26;
	Y5447_gen_type [27] = Y5447_pgtype27;
	Y5447_gen_type [28] = Y5447_pgtype28;
	Y5447_gen_type [29] = Y5447_pgtype29;
	Y5447_gen_type [30] = Y5447_pgtype30;
	Y5447_gen_type [31] = Y5447_pgtype31;
	Y5447_gen_type [32] = Y5447_pgtype32;
	Y5447_gen_type [33] = Y5447_pgtype33;
	Y5447_gen_type [34] = Y5447_pgtype34;
	Y5447_gen_type [35] = Y5447_pgtype35;
	Y5447_gen_type [36] = Y5447_pgtype36;
	Y5447_gen_type [37] = Y5447_pgtype37;
	Y5447_gen_type [38] = Y5447_pgtype38;
	Y5447_gen_type [39] = Y5447_pgtype39;
	Y5447_gen_type [40] = Y5447_pgtype40;
	Y5447_gen_type [41] = Y5447_pgtype41;
	Y5447_gen_type [42] = Y5447_pgtype42;
	Y5447_gen_type [43] = Y5447_pgtype43;
	Y5447_gen_type [44] = Y5447_pgtype44;
	Y5447_gen_type [45] = Y5447_pgtype45;
	Y5447_gen_type [46] = Y5447_pgtype46;
	Y5447_gen_type [47] = Y5447_pgtype47;
	Y5447_gen_type [48] = Y5447_pgtype48;
	Y5447_gen_type [49] = Y5447_pgtype49;
	Y5447_gen_type [50] = Y5447_pgtype50;
	Y5447_gen_type [51] = Y5447_pgtype51;
	Y5447_gen_type [52] = Y5447_pgtype52;
	Y5447_gen_type [53] = Y5447_pgtype53;
	Y5447_gen_type [54] = Y5447_pgtype54;
	Y5447_gen_type [55] = Y5447_pgtype55;
	Y5447_gen_type [56] = Y5447_pgtype56;
	Y5447_gen_type [57] = Y5447_pgtype57;
	Y5447_gen_type [58] = Y5447_pgtype58;
	Y5447_gen_type [59] = Y5447_pgtype59;
	Y5447_gen_type [60] = Y5447_pgtype60;
	Y5447_gen_type [61] = Y5447_pgtype61;
	Y5447_gen_type [62] = Y5447_pgtype62;
	Y5447_gen_type [63] = Y5447_pgtype63;
	Y5447_gen_type [64] = Y5447_pgtype64;
	Y5447_gen_type [65] = Y5447_pgtype65;
	Y5447_gen_type [66] = Y5447_pgtype66;
	Y5447_gen_type [67] = Y5447_pgtype67;
	Y5447_gen_type [68] = Y5447_pgtype68;
	Y5447_gen_type [69] = Y5447_pgtype69;
	Y5447_gen_type [70] = Y5447_pgtype70;
	Y5447_gen_type [71] = Y5447_pgtype71;
	Y5447_gen_type [72] = Y5447_pgtype72;
	Y5447_gen_type [73] = Y5447_pgtype73;
	Y5447_gen_type [74] = Y5447_pgtype74;
	Y5447_gen_type [75] = Y5447_pgtype75;
	Y5447_gen_type [76] = Y5447_pgtype76;
	Y5447_gen_type [77] = Y5447_pgtype77;
	Y5447_gen_type [78] = Y5447_pgtype78;
	Y5447_gen_type [79] = Y5447_pgtype79;
	Y5447_gen_type [80] = Y5447_pgtype80;
	Y5447_gen_type [81] = Y5447_pgtype81;
	Y5447_gen_type [82] = Y5447_pgtype82;
	Y5447_gen_type [83] = Y5447_pgtype83;
	Y5447_gen_type [84] = Y5447_pgtype84;
	Y5447_gen_type [85] = Y5447_pgtype85;
	Y5447_gen_type [86] = Y5447_pgtype86;
	Y5447_gen_type [87] = Y5447_pgtype87;
	Y5447_gen_type [88] = Y5447_pgtype88;
	Y5447_gen_type [89] = Y5447_pgtype89;
	Y5447_gen_type [90] = Y5447_pgtype90;
	Y5447_gen_type [91] = Y5447_pgtype91;
	Y5447_gen_type [92] = Y5447_pgtype92;
	Y5447_gen_type [93] = Y5447_pgtype93;
	Y5447_gen_type [94] = Y5447_pgtype94;
	Y5447_gen_type [95] = Y5447_pgtype95;
	Y5447_gen_type [96] = Y5447_pgtype96;
	Y5447_gen_type [97] = Y5447_pgtype97;
	Y5447_gen_type [98] = Y5447_pgtype98;
	Y5447_gen_type [99] = Y5447_pgtype99;
	Y5447_gen_type [100] = Y5447_pgtype100;
	Y5447_gen_type [101] = Y5447_pgtype101;
	Y5447_gen_type [102] = Y5447_pgtype102;
	Y5447_gen_type [103] = Y5447_pgtype103;
	Y5447_gen_type [104] = Y5447_pgtype104;
	Y5447_gen_type [105] = Y5447_pgtype105;
	Y5447_gen_type [106] = Y5447_pgtype106;
	Y5447_gen_type [107] = Y5447_pgtype107;
	Y5447_gen_type [108] = Y5447_pgtype108;
	Y5447_gen_type [109] = Y5447_pgtype109;
	Y5447_gen_type [110] = Y5447_pgtype110;
	Y5447_gen_type [111] = Y5447_pgtype111;
	Y5447_gen_type [112] = Y5447_pgtype112;
	Y5447_gen_type [113] = Y5447_pgtype113;
	Y5447_gen_type [114] = Y5447_pgtype114;
	Y5447_gen_type [115] = Y5447_pgtype115;
	Y5447_gen_type [116] = Y5447_pgtype116;
	Y5447_gen_type [117] = Y5447_pgtype117;
	Y5447_gen_type [118] = Y5447_pgtype118;
	Y5447_gen_type [119] = Y5447_pgtype119;
	Y5447_gen_type [203] = Y5447_pgtype120;
	Y5447[13] = 984;
	Y5447[16] = 30;
	Y5447[17] = 972;
	Y5447[18] = 984;
	Y5447[94] = 972;
	Y5447[95] = 975;
	Y5447[203] = 975;
}

char *(*R5504[6])();
void R5504_init () {
	R5504[0] = (char *(*)()) F773_6216;
	R5504[1] = (char *(*)()) F774_6216;
	R5504[2] = (char *(*)()) F775_6216_5504_1;
	R5504[3] = (char *(*)()) F776_6216_5504_1;
	R5504[4] = (char *(*)()) F777_6216_5504_1;
	R5504[5] = (char *(*)()) F778_6216;
}
static EIF_REFERENCE F775_6216_5504_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F775_6216(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F776_6216_5504_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F776_6216(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F777_6216_5504_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F777_6216(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R5507[71])();
void R5507_init () {
	R5507[0] = (char *(*)()) F758_6189;
	R5507[1] = (char *(*)()) F759_6189;
	R5507[2] = (char *(*)()) F760_6189;
	R5507[3] = (char *(*)()) F761_6189;
	R5507[4] = (char *(*)()) F762_6189;
	R5507[5] = (char *(*)()) F763_6189;
	R5507[6] = (char *(*)()) F764_6189;
	R5507[7] = (char *(*)()) F765_6189;
	R5507[8] = (char *(*)()) F766_6189;
	R5507[9] = (char *(*)()) F767_6189;
	R5507[10] = (char *(*)()) F768_6189;
	R5507[11] = (char *(*)()) F769_6189;
	R5507[12] = (char *(*)()) F758_6189;
	R5507[13] = (char *(*)()) F759_6189;
	R5507[14] = (char *(*)()) F765_6189;
	R5507[15] = (char *(*)()) F758_6189;
	R5507[16] = (char *(*)()) F759_6189;
	R5507[17] = (char *(*)()) F758_6189;
	{long i; for (i = 18; i < 20; i++) R5507[i] = (char *(*)()) F759_6189;}
	R5507[20] = (char *(*)()) F768_6189;
	R5507[33] = (char *(*)()) F779_6223;
	R5507[34] = (char *(*)()) F780_6223;
	R5507[35] = (char *(*)()) F781_6223;
	R5507[36] = (char *(*)()) F782_6223;
	R5507[37] = (char *(*)()) F783_6223;
	R5507[38] = (char *(*)()) F784_6223;
	R5507[39] = (char *(*)()) F785_6223;
	R5507[40] = (char *(*)()) F786_6223;
	R5507[41] = (char *(*)()) F787_6223;
	R5507[42] = (char *(*)()) F788_6223;
	R5507[43] = (char *(*)()) F789_6223;
	R5507[44] = (char *(*)()) F790_6223;
	R5507[45] = (char *(*)()) F787_6223;
	R5507[46] = (char *(*)()) F785_6223;
	R5507[47] = (char *(*)()) F779_6223;
	R5507[48] = (char *(*)()) F780_6223;
	R5507[49] = (char *(*)()) F781_6223;
	R5507[50] = (char *(*)()) F782_6223;
	R5507[51] = (char *(*)()) F783_6223;
	R5507[52] = (char *(*)()) F784_6223;
	R5507[53] = (char *(*)()) F785_6223;
	R5507[54] = (char *(*)()) F786_6223;
	R5507[55] = (char *(*)()) F787_6223;
	R5507[56] = (char *(*)()) F788_6223;
	R5507[57] = (char *(*)()) F789_6223;
	R5507[58] = (char *(*)()) F790_6223;
	R5507[59] = (char *(*)()) F779_6223;
	R5507[60] = (char *(*)()) F780_6223;
	R5507[61] = (char *(*)()) F781_6223;
	R5507[62] = (char *(*)()) F782_6223;
	R5507[63] = (char *(*)()) F783_6223;
	R5507[64] = (char *(*)()) F784_6223;
	R5507[65] = (char *(*)()) F785_6223;
	R5507[66] = (char *(*)()) F786_6223;
	R5507[67] = (char *(*)()) F787_6223;
	R5507[68] = (char *(*)()) F788_6223;
	R5507[69] = (char *(*)()) F789_6223;
	R5507[70] = (char *(*)()) F790_6223;
}

char *(*R5508[71])();
void R5508_init () {
	R5508[0] = (char *(*)()) F758_6190;
	R5508[1] = (char *(*)()) F759_6190;
	R5508[2] = (char *(*)()) F760_6190;
	R5508[3] = (char *(*)()) F761_6190;
	R5508[4] = (char *(*)()) F762_6190;
	R5508[5] = (char *(*)()) F763_6190;
	R5508[6] = (char *(*)()) F764_6190;
	R5508[7] = (char *(*)()) F765_6190;
	R5508[8] = (char *(*)()) F766_6190;
	R5508[9] = (char *(*)()) F767_6190;
	R5508[10] = (char *(*)()) F768_6190;
	R5508[11] = (char *(*)()) F769_6190;
	R5508[12] = (char *(*)()) F758_6190;
	R5508[13] = (char *(*)()) F759_6190;
	R5508[14] = (char *(*)()) F765_6190;
	R5508[15] = (char *(*)()) F758_6190;
	R5508[16] = (char *(*)()) F759_6190;
	R5508[17] = (char *(*)()) F758_6190;
	{long i; for (i = 18; i < 20; i++) R5508[i] = (char *(*)()) F759_6190;}
	R5508[20] = (char *(*)()) F768_6190;
	R5508[33] = (char *(*)()) F791_6242;
	R5508[34] = (char *(*)()) F792_6242;
	R5508[35] = (char *(*)()) F793_6242;
	R5508[36] = (char *(*)()) F794_6242;
	R5508[37] = (char *(*)()) F795_6242;
	R5508[38] = (char *(*)()) F796_6242;
	R5508[39] = (char *(*)()) F797_6242;
	R5508[40] = (char *(*)()) F798_6242;
	R5508[41] = (char *(*)()) F799_6242;
	R5508[42] = (char *(*)()) F800_6242;
	R5508[43] = (char *(*)()) F801_6242;
	R5508[44] = (char *(*)()) F802_6242;
	R5508[45] = (char *(*)()) F803_6248;
	R5508[46] = (char *(*)()) F804_6254;
	R5508[47] = (char *(*)()) F805_6260;
	R5508[48] = (char *(*)()) F806_6260;
	R5508[49] = (char *(*)()) F807_6260;
	R5508[50] = (char *(*)()) F808_6260;
	R5508[51] = (char *(*)()) F809_6260;
	R5508[52] = (char *(*)()) F810_6260;
	R5508[53] = (char *(*)()) F811_6260;
	R5508[54] = (char *(*)()) F812_6260;
	R5508[55] = (char *(*)()) F813_6260;
	R5508[56] = (char *(*)()) F814_6260;
	R5508[57] = (char *(*)()) F815_6260;
	R5508[58] = (char *(*)()) F816_6260;
	R5508[59] = (char *(*)()) F817_6266;
	R5508[60] = (char *(*)()) F818_6266;
	R5508[61] = (char *(*)()) F819_6266;
	R5508[62] = (char *(*)()) F820_6266;
	R5508[63] = (char *(*)()) F821_6266;
	R5508[64] = (char *(*)()) F822_6266;
	R5508[65] = (char *(*)()) F823_6266;
	R5508[66] = (char *(*)()) F824_6266;
	R5508[67] = (char *(*)()) F825_6266;
	R5508[68] = (char *(*)()) F826_6266;
	R5508[69] = (char *(*)()) F827_6266;
	R5508[70] = (char *(*)()) F828_6266;
}

char *(*R5516[21])();
void R5516_init () {
	R5516[0] = (char *(*)()) F758_6201;
	R5516[1] = (char *(*)()) F759_6201;
	R5516[2] = (char *(*)()) F760_6201;
	R5516[3] = (char *(*)()) F761_6201;
	R5516[4] = (char *(*)()) F762_6201;
	R5516[5] = (char *(*)()) F763_6201;
	R5516[6] = (char *(*)()) F764_6201;
	R5516[7] = (char *(*)()) F765_6201;
	R5516[8] = (char *(*)()) F766_6201;
	R5516[9] = (char *(*)()) F767_6201;
	R5516[10] = (char *(*)()) F768_6201;
	R5516[11] = (char *(*)()) F769_6201;
	R5516[12] = (char *(*)()) F758_6201;
	R5516[13] = (char *(*)()) F759_6201;
	R5516[14] = (char *(*)()) F765_6201;
	R5516[15] = (char *(*)()) F758_6201;
	R5516[16] = (char *(*)()) F759_6201;
	R5516[17] = (char *(*)()) F758_6201;
	{long i; for (i = 18; i < 20; i++) R5516[i] = (char *(*)()) F759_6201;}
	R5516[20] = (char *(*)()) F768_6201;
}

char *(*R5519[71])();
void R5519_init () {
	R5519[0] = (char *(*)()) F758_6206;
	R5519[1] = (char *(*)()) F759_6206;
	R5519[2] = (char *(*)()) F760_6206;
	R5519[3] = (char *(*)()) F761_6206;
	R5519[4] = (char *(*)()) F762_6206;
	R5519[5] = (char *(*)()) F763_6206;
	R5519[6] = (char *(*)()) F764_6206;
	R5519[7] = (char *(*)()) F765_6206;
	R5519[8] = (char *(*)()) F766_6206;
	R5519[9] = (char *(*)()) F767_6206;
	R5519[10] = (char *(*)()) F768_6206;
	R5519[11] = (char *(*)()) F769_6206;
	R5519[12] = (char *(*)()) F770_6211;
	R5519[13] = (char *(*)()) F771_6211;
	R5519[14] = (char *(*)()) F772_6211;
	R5519[15] = (char *(*)()) F758_6206;
	R5519[16] = (char *(*)()) F759_6206;
	R5519[17] = (char *(*)()) F758_6206;
	{long i; for (i = 18; i < 20; i++) R5519[i] = (char *(*)()) F759_6206;}
	R5519[20] = (char *(*)()) F768_6206;
	R5519[33] = (char *(*)()) F779_6235;
	R5519[34] = (char *(*)()) F780_6235;
	R5519[35] = (char *(*)()) F781_6235;
	R5519[36] = (char *(*)()) F782_6235;
	R5519[37] = (char *(*)()) F783_6235;
	R5519[38] = (char *(*)()) F784_6235;
	R5519[39] = (char *(*)()) F785_6235;
	R5519[40] = (char *(*)()) F786_6235;
	R5519[41] = (char *(*)()) F787_6235;
	R5519[42] = (char *(*)()) F788_6235;
	R5519[43] = (char *(*)()) F789_6235;
	R5519[44] = (char *(*)()) F790_6235;
	R5519[45] = (char *(*)()) F787_6235;
	R5519[46] = (char *(*)()) F785_6235;
	R5519[47] = (char *(*)()) F779_6235;
	R5519[48] = (char *(*)()) F780_6235;
	R5519[49] = (char *(*)()) F781_6235;
	R5519[50] = (char *(*)()) F782_6235;
	R5519[51] = (char *(*)()) F783_6235;
	R5519[52] = (char *(*)()) F784_6235;
	R5519[53] = (char *(*)()) F785_6235;
	R5519[54] = (char *(*)()) F786_6235;
	R5519[55] = (char *(*)()) F787_6235;
	R5519[56] = (char *(*)()) F788_6235;
	R5519[57] = (char *(*)()) F789_6235;
	R5519[58] = (char *(*)()) F790_6235;
	R5519[59] = (char *(*)()) F779_6235;
	R5519[60] = (char *(*)()) F780_6235;
	R5519[61] = (char *(*)()) F781_6235;
	R5519[62] = (char *(*)()) F782_6235;
	R5519[63] = (char *(*)()) F783_6235;
	R5519[64] = (char *(*)()) F784_6235;
	R5519[65] = (char *(*)()) F785_6235;
	R5519[66] = (char *(*)()) F786_6235;
	R5519[67] = (char *(*)()) F787_6235;
	R5519[68] = (char *(*)()) F788_6235;
	R5519[69] = (char *(*)()) F789_6235;
	R5519[70] = (char *(*)()) F790_6235;
}

char *(*R5520[71])();
void R5520_init () {
	R5520[0] = (char *(*)()) F758_6208;
	R5520[1] = (char *(*)()) F759_6208;
	R5520[2] = (char *(*)()) F760_6208;
	R5520[3] = (char *(*)()) F761_6208;
	R5520[4] = (char *(*)()) F762_6208;
	R5520[5] = (char *(*)()) F763_6208;
	R5520[6] = (char *(*)()) F764_6208;
	R5520[7] = (char *(*)()) F765_6208;
	R5520[8] = (char *(*)()) F766_6208;
	R5520[9] = (char *(*)()) F767_6208;
	R5520[10] = (char *(*)()) F768_6208;
	R5520[11] = (char *(*)()) F769_6208;
	R5520[12] = (char *(*)()) F770_6213;
	R5520[13] = (char *(*)()) F771_6213;
	R5520[14] = (char *(*)()) F772_6213;
	R5520[15] = (char *(*)()) F773_6220;
	R5520[16] = (char *(*)()) F774_6220;
	R5520[17] = (char *(*)()) F775_6220;
	R5520[18] = (char *(*)()) F776_6220;
	R5520[19] = (char *(*)()) F777_6220;
	R5520[20] = (char *(*)()) F778_6220;
	R5520[33] = (char *(*)()) F791_6245;
	R5520[34] = (char *(*)()) F792_6245;
	R5520[35] = (char *(*)()) F793_6245;
	R5520[36] = (char *(*)()) F794_6245;
	R5520[37] = (char *(*)()) F795_6245;
	R5520[38] = (char *(*)()) F796_6245;
	R5520[39] = (char *(*)()) F797_6245;
	R5520[40] = (char *(*)()) F798_6245;
	R5520[41] = (char *(*)()) F799_6245;
	R5520[42] = (char *(*)()) F800_6245;
	R5520[43] = (char *(*)()) F801_6245;
	R5520[44] = (char *(*)()) F802_6245;
	R5520[45] = (char *(*)()) F803_6251;
	R5520[46] = (char *(*)()) F804_6257;
	R5520[47] = (char *(*)()) F805_6263;
	R5520[48] = (char *(*)()) F806_6263;
	R5520[49] = (char *(*)()) F807_6263;
	R5520[50] = (char *(*)()) F808_6263;
	R5520[51] = (char *(*)()) F809_6263;
	R5520[52] = (char *(*)()) F810_6263;
	R5520[53] = (char *(*)()) F811_6263;
	R5520[54] = (char *(*)()) F812_6263;
	R5520[55] = (char *(*)()) F813_6263;
	R5520[56] = (char *(*)()) F814_6263;
	R5520[57] = (char *(*)()) F815_6263;
	R5520[58] = (char *(*)()) F816_6263;
	R5520[59] = (char *(*)()) F779_6237;
	R5520[60] = (char *(*)()) F780_6237;
	R5520[61] = (char *(*)()) F781_6237;
	R5520[62] = (char *(*)()) F782_6237;
	R5520[63] = (char *(*)()) F783_6237;
	R5520[64] = (char *(*)()) F784_6237;
	R5520[65] = (char *(*)()) F785_6237;
	R5520[66] = (char *(*)()) F786_6237;
	R5520[67] = (char *(*)()) F787_6237;
	R5520[68] = (char *(*)()) F788_6237;
	R5520[69] = (char *(*)()) F789_6237;
	R5520[70] = (char *(*)()) F790_6237;
}

char *(*R5522[21])();
void R5522_init () {
	R5522[0] = (char *(*)()) F758_6187;
	R5522[1] = (char *(*)()) F759_6187;
	R5522[2] = (char *(*)()) F760_6187;
	R5522[3] = (char *(*)()) F761_6187;
	R5522[4] = (char *(*)()) F762_6187;
	R5522[5] = (char *(*)()) F763_6187;
	R5522[6] = (char *(*)()) F764_6187;
	R5522[7] = (char *(*)()) F765_6187;
	R5522[8] = (char *(*)()) F766_6187;
	R5522[9] = (char *(*)()) F767_6187;
	R5522[10] = (char *(*)()) F768_6187;
	R5522[11] = (char *(*)()) F769_6187;
	R5522[12] = (char *(*)()) F758_6187;
	R5522[13] = (char *(*)()) F759_6187;
	R5522[14] = (char *(*)()) F765_6187;
	R5522[15] = (char *(*)()) F758_6187;
	R5522[16] = (char *(*)()) F759_6187;
	R5522[17] = (char *(*)()) F758_6187;
	{long i; for (i = 18; i < 20; i++) R5522[i] = (char *(*)()) F759_6187;}
	R5522[20] = (char *(*)()) F768_6187;
}

char *(*R5535[38])();
void R5535_init () {
	R5535[0] = (char *(*)()) F791_6246;
	R5535[1] = (char *(*)()) F792_6246;
	R5535[2] = (char *(*)()) F793_6246;
	R5535[3] = (char *(*)()) F794_6246;
	R5535[4] = (char *(*)()) F795_6246;
	R5535[5] = (char *(*)()) F796_6246;
	R5535[6] = (char *(*)()) F797_6246;
	R5535[7] = (char *(*)()) F798_6246;
	R5535[8] = (char *(*)()) F799_6246;
	R5535[9] = (char *(*)()) F800_6246;
	R5535[10] = (char *(*)()) F801_6246;
	R5535[11] = (char *(*)()) F802_6246;
	R5535[12] = (char *(*)()) F803_6252;
	R5535[13] = (char *(*)()) F804_6258;
	R5535[14] = (char *(*)()) F805_6264;
	R5535[15] = (char *(*)()) F806_6264;
	R5535[16] = (char *(*)()) F807_6264;
	R5535[17] = (char *(*)()) F808_6264;
	R5535[18] = (char *(*)()) F809_6264;
	R5535[19] = (char *(*)()) F810_6264;
	R5535[20] = (char *(*)()) F811_6264;
	R5535[21] = (char *(*)()) F812_6264;
	R5535[22] = (char *(*)()) F813_6264;
	R5535[23] = (char *(*)()) F814_6264;
	R5535[24] = (char *(*)()) F815_6264;
	R5535[25] = (char *(*)()) F816_6264;
	R5535[26] = (char *(*)()) F817_6268;
	R5535[27] = (char *(*)()) F818_6268;
	R5535[28] = (char *(*)()) F819_6268;
	R5535[29] = (char *(*)()) F820_6268;
	R5535[30] = (char *(*)()) F821_6268;
	R5535[31] = (char *(*)()) F822_6268;
	R5535[32] = (char *(*)()) F823_6268;
	R5535[33] = (char *(*)()) F824_6268;
	R5535[34] = (char *(*)()) F825_6268;
	R5535[35] = (char *(*)()) F826_6268;
	R5535[36] = (char *(*)()) F827_6268;
	R5535[37] = (char *(*)()) F828_6268;
}

char *(*R5537[12])();
void R5537_init () {
	R5537[0] = (char *(*)()) F791_6241;
	R5537[1] = (char *(*)()) F792_6241;
	R5537[2] = (char *(*)()) F793_6241;
	R5537[3] = (char *(*)()) F794_6241;
	R5537[4] = (char *(*)()) F795_6241;
	R5537[5] = (char *(*)()) F796_6241;
	R5537[6] = (char *(*)()) F797_6241;
	R5537[7] = (char *(*)()) F798_6241;
	R5537[8] = (char *(*)()) F799_6241;
	R5537[9] = (char *(*)()) F800_6241;
	R5537[10] = (char *(*)()) F801_6241;
	R5537[11] = (char *(*)()) F802_6241;
}

char *(*R5545[12])();
void R5545_init () {
	R5545[0] = (char *(*)()) F805_6259;
	R5545[1] = (char *(*)()) F806_6259;
	R5545[2] = (char *(*)()) F807_6259;
	R5545[3] = (char *(*)()) F808_6259;
	R5545[4] = (char *(*)()) F809_6259;
	R5545[5] = (char *(*)()) F810_6259;
	R5545[6] = (char *(*)()) F811_6259;
	R5545[7] = (char *(*)()) F812_6259;
	R5545[8] = (char *(*)()) F813_6259;
	R5545[9] = (char *(*)()) F814_6259;
	R5545[10] = (char *(*)()) F815_6259;
	R5545[11] = (char *(*)()) F816_6259;
}

char *(*R5548[12])();
void R5548_init () {
	R5548[0] = (char *(*)()) F817_6265;
	R5548[1] = (char *(*)()) F818_6265;
	R5548[2] = (char *(*)()) F819_6265;
	R5548[3] = (char *(*)()) F820_6265;
	R5548[4] = (char *(*)()) F821_6265;
	R5548[5] = (char *(*)()) F822_6265;
	R5548[6] = (char *(*)()) F823_6265;
	R5548[7] = (char *(*)()) F824_6265;
	R5548[8] = (char *(*)()) F825_6265;
	R5548[9] = (char *(*)()) F826_6265;
	R5548[10] = (char *(*)()) F827_6265;
	R5548[11] = (char *(*)()) F828_6265;
}

char *(*R5670[12])();
void R5670_init () {
	R5670[0] = (char *(*)()) F835_6413;
	R5670[1] = (char *(*)()) F836_6413;
	R5670[2] = (char *(*)()) F837_6413;
	R5670[3] = (char *(*)()) F838_6413;
	R5670[4] = (char *(*)()) F839_6413;
	R5670[5] = (char *(*)()) F840_6413;
	R5670[6] = (char *(*)()) F841_6413;
	R5670[7] = (char *(*)()) F842_6413;
	R5670[8] = (char *(*)()) F843_6413;
	R5670[9] = (char *(*)()) F844_6413;
	R5670[10] = (char *(*)()) F845_6413;
	R5670[11] = (char *(*)()) F846_6413;
}

char *(*R5671[12])();
void R5671_init () {
	R5671[0] = (char *(*)()) F835_6414;
	R5671[1] = (char *(*)()) F836_6414;
	R5671[2] = (char *(*)()) F837_6414;
	R5671[3] = (char *(*)()) F838_6414;
	R5671[4] = (char *(*)()) F839_6414;
	R5671[5] = (char *(*)()) F840_6414;
	R5671[6] = (char *(*)()) F841_6414;
	R5671[7] = (char *(*)()) F842_6414;
	R5671[8] = (char *(*)()) F843_6414;
	R5671[9] = (char *(*)()) F844_6414;
	R5671[10] = (char *(*)()) F845_6414;
	R5671[11] = (char *(*)()) F846_6414;
}

char *(*R5673[12])();
void R5673_init () {
	R5673[0] = (char *(*)()) F835_6400;
	R5673[1] = (char *(*)()) F836_6400;
	R5673[2] = (char *(*)()) F837_6400;
	R5673[3] = (char *(*)()) F838_6400;
	R5673[4] = (char *(*)()) F839_6400;
	R5673[5] = (char *(*)()) F840_6400;
	R5673[6] = (char *(*)()) F841_6400;
	R5673[7] = (char *(*)()) F842_6400;
	R5673[8] = (char *(*)()) F843_6400;
	R5673[9] = (char *(*)()) F844_6400;
	R5673[10] = (char *(*)()) F845_6400;
	R5673[11] = (char *(*)()) F846_6400;
}

char *(*R5674[12])();
void R5674_init () {
	R5674[0] = (char *(*)()) F835_6401;
	R5674[1] = (char *(*)()) F836_6401_5674_250;
	R5674[2] = (char *(*)()) F837_6401_5674_250;
	R5674[3] = (char *(*)()) F838_6401_5674_250;
	R5674[4] = (char *(*)()) F839_6401_5674_250;
	R5674[5] = (char *(*)()) F840_6401_5674_250;
	R5674[6] = (char *(*)()) F841_6401_5674_250;
	R5674[7] = (char *(*)()) F842_6401_5674_250;
	R5674[8] = (char *(*)()) F843_6401_5674_250;
	R5674[9] = (char *(*)()) F844_6401_5674_250;
	R5674[10] = (char *(*)()) F845_6401_5674_250;
	R5674[11] = (char *(*)()) F846_6401_5674_250;
}
static void F836_6401_5674_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F836_6401(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F837_6401_5674_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F837_6401(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F838_6401_5674_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F838_6401(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F839_6401_5674_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F839_6401(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F840_6401_5674_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F840_6401(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F841_6401_5674_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F841_6401(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F842_6401_5674_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F842_6401(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F843_6401_5674_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F843_6401(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F844_6401_5674_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F844_6401(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F845_6401_5674_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F845_6401(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F846_6401_5674_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F846_6401(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5683[12])();
void R5683_init () {
	R5683[0] = (char *(*)()) F835_6416;
	R5683[1] = (char *(*)()) F836_6416;
	R5683[2] = (char *(*)()) F837_6416;
	R5683[3] = (char *(*)()) F838_6416;
	R5683[4] = (char *(*)()) F839_6416;
	R5683[5] = (char *(*)()) F840_6416;
	R5683[6] = (char *(*)()) F841_6416;
	R5683[7] = (char *(*)()) F842_6416;
	R5683[8] = (char *(*)()) F843_6416;
	R5683[9] = (char *(*)()) F844_6416;
	R5683[10] = (char *(*)()) F845_6416;
	R5683[11] = (char *(*)()) F846_6416;
}

char *(*R5684[12])();
void R5684_init () {
	R5684[0] = (char *(*)()) F835_6418;
	R5684[1] = (char *(*)()) F836_6418_5684_250;
	R5684[2] = (char *(*)()) F837_6418_5684_250;
	R5684[3] = (char *(*)()) F838_6418_5684_250;
	R5684[4] = (char *(*)()) F839_6418_5684_250;
	R5684[5] = (char *(*)()) F840_6418_5684_250;
	R5684[6] = (char *(*)()) F841_6418_5684_250;
	R5684[7] = (char *(*)()) F842_6418_5684_250;
	R5684[8] = (char *(*)()) F843_6418_5684_250;
	R5684[9] = (char *(*)()) F844_6418_5684_250;
	R5684[10] = (char *(*)()) F845_6418_5684_250;
	R5684[11] = (char *(*)()) F846_6418_5684_250;
}
static void F836_6418_5684_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F836_6418(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F837_6418_5684_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F837_6418(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F838_6418_5684_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F838_6418(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F839_6418_5684_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F839_6418(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F840_6418_5684_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F840_6418(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F841_6418_5684_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F841_6418(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F842_6418_5684_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F842_6418(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F843_6418_5684_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F843_6418(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F844_6418_5684_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F844_6418(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F845_6418_5684_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F845_6418(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F846_6418_5684_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F846_6418(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5685[12])();
void R5685_init () {
	R5685[0] = (char *(*)()) F835_6419;
	R5685[1] = (char *(*)()) F836_6419_5685_250;
	R5685[2] = (char *(*)()) F837_6419_5685_250;
	R5685[3] = (char *(*)()) F838_6419_5685_250;
	R5685[4] = (char *(*)()) F839_6419_5685_250;
	R5685[5] = (char *(*)()) F840_6419_5685_250;
	R5685[6] = (char *(*)()) F841_6419_5685_250;
	R5685[7] = (char *(*)()) F842_6419_5685_250;
	R5685[8] = (char *(*)()) F843_6419_5685_250;
	R5685[9] = (char *(*)()) F844_6419_5685_250;
	R5685[10] = (char *(*)()) F845_6419_5685_250;
	R5685[11] = (char *(*)()) F846_6419_5685_250;
}
static void F836_6419_5685_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F836_6419(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F837_6419_5685_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F837_6419(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F838_6419_5685_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F838_6419(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F839_6419_5685_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F839_6419(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F840_6419_5685_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F840_6419(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F841_6419_5685_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F841_6419(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F842_6419_5685_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F842_6419(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F843_6419_5685_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F843_6419(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F844_6419_5685_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F844_6419(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F845_6419_5685_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F845_6419(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F846_6419_5685_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F846_6419(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5686[12])();
void R5686_init () {
	R5686[0] = (char *(*)()) F835_6420;
	R5686[1] = (char *(*)()) F836_6420_5686_4;
	R5686[2] = (char *(*)()) F837_6420_5686_4;
	R5686[3] = (char *(*)()) F838_6420_5686_4;
	R5686[4] = (char *(*)()) F839_6420_5686_4;
	R5686[5] = (char *(*)()) F840_6420_5686_4;
	R5686[6] = (char *(*)()) F841_6420_5686_4;
	R5686[7] = (char *(*)()) F842_6420_5686_4;
	R5686[8] = (char *(*)()) F843_6420_5686_4;
	R5686[9] = (char *(*)()) F844_6420_5686_4;
	R5686[10] = (char *(*)()) F845_6420_5686_4;
	R5686[11] = (char *(*)()) F846_6420_5686_4;
}
static void F836_6420_5686_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F836_6420(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F837_6420_5686_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F837_6420(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F838_6420_5686_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F838_6420(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F839_6420_5686_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F839_6420(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F840_6420_5686_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F840_6420(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F841_6420_5686_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F841_6420(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F842_6420_5686_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F842_6420(Current, *(EIF_BOOLEAN *)arg1);
}
static void F843_6420_5686_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F843_6420(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F844_6420_5686_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F844_6420(Current, *(EIF_REAL_32 *)arg1);
}
static void F845_6420_5686_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F845_6420(Current, *(EIF_POINTER *)arg1);
}
static void F846_6420_5686_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F846_6420(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R5688[12])();
void R5688_init () {
	R5688[0] = (char *(*)()) F835_6422;
	R5688[1] = (char *(*)()) F836_6422_5688_268;
	R5688[2] = (char *(*)()) F837_6422_5688_268;
	R5688[3] = (char *(*)()) F838_6422_5688_268;
	R5688[4] = (char *(*)()) F839_6422_5688_268;
	R5688[5] = (char *(*)()) F840_6422_5688_268;
	R5688[6] = (char *(*)()) F841_6422_5688_268;
	R5688[7] = (char *(*)()) F842_6422_5688_268;
	R5688[8] = (char *(*)()) F843_6422_5688_268;
	R5688[9] = (char *(*)()) F844_6422_5688_268;
	R5688[10] = (char *(*)()) F845_6422_5688_268;
	R5688[11] = (char *(*)()) F846_6422_5688_268;
}
static void F836_6422_5688_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F836_6422(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F837_6422_5688_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F837_6422(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F838_6422_5688_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F838_6422(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F839_6422_5688_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F839_6422(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F840_6422_5688_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F840_6422(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F841_6422_5688_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F841_6422(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F842_6422_5688_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F842_6422(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F843_6422_5688_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F843_6422(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F844_6422_5688_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F844_6422(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F845_6422_5688_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F845_6422(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F846_6422_5688_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F846_6422(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R5691[12])();
void R5691_init () {
	R5691[0] = (char *(*)()) F835_6425;
	R5691[1] = (char *(*)()) F836_6425;
	R5691[2] = (char *(*)()) F837_6425;
	R5691[3] = (char *(*)()) F838_6425;
	R5691[4] = (char *(*)()) F839_6425;
	R5691[5] = (char *(*)()) F840_6425;
	R5691[6] = (char *(*)()) F841_6425;
	R5691[7] = (char *(*)()) F842_6425;
	R5691[8] = (char *(*)()) F843_6425;
	R5691[9] = (char *(*)()) F844_6425;
	R5691[10] = (char *(*)()) F845_6425;
	R5691[11] = (char *(*)()) F846_6425;
}

char *(*R5692[12])();
void R5692_init () {
	R5692[0] = (char *(*)()) F835_6426;
	R5692[1] = (char *(*)()) F836_6426;
	R5692[2] = (char *(*)()) F837_6426;
	R5692[3] = (char *(*)()) F838_6426;
	R5692[4] = (char *(*)()) F839_6426;
	R5692[5] = (char *(*)()) F840_6426;
	R5692[6] = (char *(*)()) F841_6426;
	R5692[7] = (char *(*)()) F842_6426;
	R5692[8] = (char *(*)()) F843_6426;
	R5692[9] = (char *(*)()) F844_6426;
	R5692[10] = (char *(*)()) F845_6426;
	R5692[11] = (char *(*)()) F846_6426;
}

char *(*R5693[12])();
void R5693_init () {
	R5693[0] = (char *(*)()) F835_6427;
	R5693[1] = (char *(*)()) F836_6427;
	R5693[2] = (char *(*)()) F837_6427;
	R5693[3] = (char *(*)()) F838_6427;
	R5693[4] = (char *(*)()) F839_6427;
	R5693[5] = (char *(*)()) F840_6427;
	R5693[6] = (char *(*)()) F841_6427;
	R5693[7] = (char *(*)()) F842_6427;
	R5693[8] = (char *(*)()) F843_6427;
	R5693[9] = (char *(*)()) F844_6427;
	R5693[10] = (char *(*)()) F845_6427;
	R5693[11] = (char *(*)()) F846_6427;
}

char *(*R5694[12])();
void R5694_init () {
	R5694[0] = (char *(*)()) F835_6428;
	R5694[1] = (char *(*)()) F836_6428;
	R5694[2] = (char *(*)()) F837_6428;
	R5694[3] = (char *(*)()) F838_6428;
	R5694[4] = (char *(*)()) F839_6428;
	R5694[5] = (char *(*)()) F840_6428;
	R5694[6] = (char *(*)()) F841_6428;
	R5694[7] = (char *(*)()) F842_6428;
	R5694[8] = (char *(*)()) F843_6428;
	R5694[9] = (char *(*)()) F844_6428;
	R5694[10] = (char *(*)()) F845_6428;
	R5694[11] = (char *(*)()) F846_6428;
}

char *(*R5695[12])();
void R5695_init () {
	R5695[0] = (char *(*)()) F835_6429;
	R5695[1] = (char *(*)()) F836_6429;
	R5695[2] = (char *(*)()) F837_6429;
	R5695[3] = (char *(*)()) F838_6429;
	R5695[4] = (char *(*)()) F839_6429;
	R5695[5] = (char *(*)()) F840_6429;
	R5695[6] = (char *(*)()) F841_6429;
	R5695[7] = (char *(*)()) F842_6429;
	R5695[8] = (char *(*)()) F843_6429;
	R5695[9] = (char *(*)()) F844_6429;
	R5695[10] = (char *(*)()) F845_6429;
	R5695[11] = (char *(*)()) F846_6429;
}

char *(*R5698[12])();
void R5698_init () {
	R5698[0] = (char *(*)()) F835_6432;
	R5698[1] = (char *(*)()) F836_6432;
	R5698[2] = (char *(*)()) F837_6432;
	R5698[3] = (char *(*)()) F838_6432;
	R5698[4] = (char *(*)()) F839_6432;
	R5698[5] = (char *(*)()) F840_6432;
	R5698[6] = (char *(*)()) F841_6432;
	R5698[7] = (char *(*)()) F842_6432;
	R5698[8] = (char *(*)()) F843_6432;
	R5698[9] = (char *(*)()) F844_6432;
	R5698[10] = (char *(*)()) F845_6432;
	R5698[11] = (char *(*)()) F846_6432;
}

char *(*R5701[12])();
void R5701_init () {
	R5701[0] = (char *(*)()) F835_6435;
	R5701[1] = (char *(*)()) F836_6435;
	R5701[2] = (char *(*)()) F837_6435;
	R5701[3] = (char *(*)()) F838_6435;
	R5701[4] = (char *(*)()) F839_6435;
	R5701[5] = (char *(*)()) F840_6435;
	R5701[6] = (char *(*)()) F841_6435;
	R5701[7] = (char *(*)()) F842_6435;
	R5701[8] = (char *(*)()) F843_6435;
	R5701[9] = (char *(*)()) F844_6435;
	R5701[10] = (char *(*)()) F845_6435;
	R5701[11] = (char *(*)()) F846_6435;
}

char *(*R5702[12])();
void R5702_init () {
	R5702[0] = (char *(*)()) F835_6436;
	R5702[1] = (char *(*)()) F836_6436_5702_150;
	R5702[2] = (char *(*)()) F837_6436_5702_150;
	R5702[3] = (char *(*)()) F838_6436_5702_150;
	R5702[4] = (char *(*)()) F839_6436_5702_150;
	R5702[5] = (char *(*)()) F840_6436_5702_150;
	R5702[6] = (char *(*)()) F841_6436_5702_150;
	R5702[7] = (char *(*)()) F842_6436_5702_150;
	R5702[8] = (char *(*)()) F843_6436_5702_150;
	R5702[9] = (char *(*)()) F844_6436_5702_150;
	R5702[10] = (char *(*)()) F845_6436_5702_150;
	R5702[11] = (char *(*)()) F846_6436_5702_150;
}
static EIF_REFERENCE F836_6436_5702_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F836_6436(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F837_6436_5702_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F837_6436(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F838_6436_5702_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F838_6436(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F839_6436_5702_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F839_6436(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F840_6436_5702_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F840_6436(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F841_6436_5702_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F841_6436(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F842_6436_5702_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F842_6436(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F843_6436_5702_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F843_6436(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F844_6436_5702_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F844_6436(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F845_6436_5702_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F845_6436(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F846_6436_5702_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F846_6436(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5704[12])();
void R5704_init () {
	R5704[0] = (char *(*)()) F835_6438;
	R5704[1] = (char *(*)()) F836_6438;
	R5704[2] = (char *(*)()) F837_6438;
	R5704[3] = (char *(*)()) F838_6438;
	R5704[4] = (char *(*)()) F839_6438;
	R5704[5] = (char *(*)()) F840_6438;
	R5704[6] = (char *(*)()) F841_6438;
	R5704[7] = (char *(*)()) F842_6438;
	R5704[8] = (char *(*)()) F843_6438;
	R5704[9] = (char *(*)()) F844_6438;
	R5704[10] = (char *(*)()) F845_6438;
	R5704[11] = (char *(*)()) F846_6438;
}

char *(*R5713[12])();
void R5713_init () {
	R5713[0] = (char *(*)()) F835_6448;
	R5713[1] = (char *(*)()) F836_6448;
	R5713[2] = (char *(*)()) F837_6448;
	R5713[3] = (char *(*)()) F838_6448;
	R5713[4] = (char *(*)()) F839_6448;
	R5713[5] = (char *(*)()) F840_6448;
	R5713[6] = (char *(*)()) F841_6448;
	R5713[7] = (char *(*)()) F842_6448;
	R5713[8] = (char *(*)()) F843_6448;
	R5713[9] = (char *(*)()) F844_6448;
	R5713[10] = (char *(*)()) F845_6448;
	R5713[11] = (char *(*)()) F846_6448;
}

char *(*R5734[10])();
void R5734_init () {
	{long i; for (i = 0; i < 2; i++) R5734[i] = (char *(*)()) F847_6470;}
	R5734[3] = (char *(*)()) F850_6501;
	R5734[4] = (char *(*)()) F851_6503;
	R5734[5] = (char *(*)()) F852_6506;
	R5734[6] = (char *(*)()) F853_6519;
	R5734[7] = (char *(*)()) F854_6523;
	R5734[8] = (char *(*)()) F855_6525;
	R5734[9] = (char *(*)()) F856_6527;
}

char *(*R5736[10])();
void R5736_init () {
	R5736[0] = (char *(*)()) F847_6472;
	R5736[1] = (char *(*)()) F848_6485;
	{long i; for (i = 3; i < 5; i++) R5736[i] = (char *(*)()) F849_6494;}
	R5736[5] = (char *(*)()) F852_6507;
	{long i; for (i = 6; i < 10; i++) R5736[i] = (char *(*)()) F849_6494;}
}

char *(*R5737[10])();
void R5737_init () {
	{long i; for (i = 0; i < 2; i++) R5737[i] = (char *(*)()) F847_6473;}
	{long i; for (i = 3; i < 6; i++) R5737[i] = (char *(*)()) F849_6497;}
	R5737[6] = (char *(*)()) F853_6520;
	{long i; for (i = 7; i < 10; i++) R5737[i] = (char *(*)()) F849_6497;}
}

char *(*R5752[7])();
void R5752_init () {
	R5752[0] = (char *(*)()) F849_6493;
	R5752[1] = (char *(*)()) F851_6504;
	{long i; for (i = 2; i < 7; i++) R5752[i] = (char *(*)()) F849_6493;}
}

char *(*R5809[2])();
void R5809_init () {
	R5809[0] = (char *(*)()) F858_6583;
	R5809[1] = (char *(*)()) F859_6591;
}

char *(*R5810[2])();
void R5810_init () {
	R5810[0] = (char *(*)()) F858_6584;
	R5810[1] = (char *(*)()) F859_6592;
}

char *(*R5816[2])();
void R5816_init () {
	R5816[0] = (char *(*)()) F858_6582;
	R5816[1] = (char *(*)()) F859_6590;
}

char *(*R5874[38])();
void R5874_init () {
	R5874[0] = (char *(*)()) F969_7941_5874_1;
	R5874[1] = (char *(*)()) F970_7941_5874_1;
	R5874[12] = (char *(*)()) F981_8137_5874_1;
	R5874[13] = (char *(*)()) F982_8137_5874_1;
	R5874[15] = (char *(*)()) F984_8236_5874_1;
	R5874[16] = (char *(*)()) F985_8236_5874_1;
	R5874[18] = (char *(*)()) F987_8335_5874_1;
	R5874[19] = (char *(*)()) F988_8335_5874_1;
	R5874[21] = (char *(*)()) F990_8434_5874_1;
	R5874[22] = (char *(*)()) F991_8434_5874_1;
	R5874[36] = (char *(*)()) F1005_8891_5874_1;
	R5874[37] = (char *(*)()) F1006_8891_5874_1;
}
static EIF_REFERENCE F969_7941_5874_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F969_7941(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F970_7941_5874_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F970_7941(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F981_8137_5874_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F981_8137(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(981, 0x00).id, 981, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F982_8137_5874_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F982_8137(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(981, 0x00).id, 981, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F984_8236_5874_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F984_8236(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F985_8236_5874_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F985_8236(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F987_8335_5874_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F987_8335(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(987, 0x00).id, 987, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F988_8335_5874_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F988_8335(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(987, 0x00).id, 987, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F990_8434_5874_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F990_8434(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(990, 0x00).id, 990, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F991_8434_5874_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F991_8434(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(990, 0x00).id, 990, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1005_8891_5874_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1005_8891(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1006_8891_5874_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1006_8891(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}

char *(*R6114[454])();
void R6114_init () {
	{long i; for (i = 0; i < 2; i++) R6114[i] = (char *(*)()) F919_7117;}
	R6114[453] = (char *(*)()) F1373_14084;
}

char *(*R6125[454])();
void R6125_init () {
	{long i; for (i = 0; i < 2; i++) R6125[i] = (char *(*)()) F919_7196;}
	R6125[453] = (char *(*)()) F1373_14115;
}

char *(*R6127[454])();
void R6127_init () {
	{long i; for (i = 0; i < 2; i++) R6127[i] = (char *(*)()) F919_7191;}
	R6127[453] = (char *(*)()) F1373_14107;
}

char *(*R6129[454])();
void R6129_init () {
	{long i; for (i = 0; i < 2; i++) R6129[i] = (char *(*)()) F919_7194;}
	R6129[453] = (char *(*)()) F1373_14105;
}

char *(*R6157[454])();
void R6157_init () {
	{long i; for (i = 0; i < 2; i++) R6157[i] = (char *(*)()) F919_7224;}
	R6157[453] = (char *(*)()) F1373_14102;
}

char *(*R6170[454])();
void R6170_init () {
	{long i; for (i = 0; i < 2; i++) R6170[i] = (char *(*)()) F919_7231;}
	R6170[453] = (char *(*)()) F1373_14096;
}

char *(*R6173[454])();
void R6173_init () {
	{long i; for (i = 0; i < 2; i++) R6173[i] = (char *(*)()) F919_7228;}
	R6173[453] = (char *(*)()) F1373_14093;
}

char *(*R6226[454])();
void R6226_init () {
	{long i; for (i = 0; i < 2; i++) R6226[i] = (char *(*)()) F919_7116;}
	R6226[453] = (char *(*)()) F1373_14083;
}

char *(*R6295[454])();
void R6295_init () {
	R6295[0] = (char *(*)()) F920_7357;
	R6295[1] = (char *(*)()) F919_7240;
	R6295[453] = (char *(*)()) F919_7240;
}

char *(*R6296[454])();
void R6296_init () {
	{long i; for (i = 0; i < 2; i++) R6296[i] = (char *(*)()) F919_7241;}
	R6296[453] = (char *(*)()) F1373_14139;
}

char *(*R6379[453])();
void R6379_init () {
	R6379[0] = (char *(*)()) F921_7409;
	R6379[452] = (char *(*)()) F1373_14081;
}

char *(*R6602[160])();
void R6602_init () {
	R6602[0] = (char *(*)()) F931_7647;
	R6602[1] = (char *(*)()) F932_7684;
	R6602[2] = (char *(*)()) F933_7726;
	R6602[3] = (char *(*)()) F934_7726;
	R6602[4] = (char *(*)()) F935_7726;
	R6602[5] = (char *(*)()) F936_7726;
	R6602[6] = (char *(*)()) F937_7726;
	R6602[7] = (char *(*)()) F938_7726;
	R6602[8] = (char *(*)()) F939_7726;
	R6602[9] = (char *(*)()) F940_7726;
	R6602[10] = (char *(*)()) F941_7726;
	R6602[11] = (char *(*)()) F942_7726;
	R6602[12] = (char *(*)()) F943_7726;
	R6602[13] = (char *(*)()) F944_7726;
	R6602[14] = (char *(*)()) F945_7726;
	R6602[15] = (char *(*)()) F946_7726;
	R6602[16] = (char *(*)()) F947_7726;
	R6602[17] = (char *(*)()) F948_7726;
	R6602[18] = (char *(*)()) F949_7726;
	R6602[19] = (char *(*)()) F950_7726;
	R6602[20] = (char *(*)()) F951_7726;
	R6602[21] = (char *(*)()) F952_7726;
	R6602[22] = (char *(*)()) F953_7726;
	R6602[23] = (char *(*)()) F954_7726;
	R6602[24] = (char *(*)()) F955_7726;
	R6602[25] = (char *(*)()) F956_7726;
	R6602[26] = (char *(*)()) F957_7726;
	R6602[27] = (char *(*)()) F958_7726;
	R6602[28] = (char *(*)()) F959_7726;
	R6602[29] = (char *(*)()) F960_7726;
	R6602[30] = (char *(*)()) F961_7726;
	R6602[31] = (char *(*)()) F962_7726;
	R6602[32] = (char *(*)()) F963_7726;
	R6602[33] = (char *(*)()) F964_7726;
	R6602[34] = (char *(*)()) F965_7726;
	R6602[35] = (char *(*)()) F966_7726;
	R6602[36] = (char *(*)()) F967_7778;
	{long i; for (i = 38; i < 40; i++) R6602[i] = (char *(*)()) F968_7885;}
	{long i; for (i = 41; i < 43; i++) R6602[i] = (char *(*)()) F971_7952;}
	{long i; for (i = 44; i < 46; i++) R6602[i] = (char *(*)()) F974_7993;}
	{long i; for (i = 47; i < 49; i++) R6602[i] = (char *(*)()) F977_8041;}
	{long i; for (i = 50; i < 52; i++) R6602[i] = (char *(*)()) F980_8062;}
	{long i; for (i = 53; i < 55; i++) R6602[i] = (char *(*)()) F983_8160;}
	{long i; for (i = 56; i < 58; i++) R6602[i] = (char *(*)()) F986_8259;}
	{long i; for (i = 59; i < 61; i++) R6602[i] = (char *(*)()) F989_8358;}
	{long i; for (i = 62; i < 64; i++) R6602[i] = (char *(*)()) F992_8457;}
	{long i; for (i = 65; i < 67; i++) R6602[i] = (char *(*)()) F995_8551;}
	{long i; for (i = 68; i < 70; i++) R6602[i] = (char *(*)()) F998_8645;}
	{long i; for (i = 71; i < 73; i++) R6602[i] = (char *(*)()) F1001_8740;}
	{long i; for (i = 74; i < 76; i++) R6602[i] = (char *(*)()) F1004_8835;}
	{long i; for (i = 76; i < 107; i++) R6602[i] = (char *(*)()) F1007_8901;}
	R6602[107] = (char *(*)()) F1038_8927;
	R6602[108] = (char *(*)()) F1039_8927;
	{long i; for (i = 110; i < 115; i++) R6602[i] = (char *(*)()) F1040_8935;}
	{long i; for (i = 119; i < 121; i++) R6602[i] = (char *(*)()) F1046_8994;}
	{long i; for (i = 122; i < 124; i++) R6602[i] = (char *(*)()) F1046_8994;}
	R6602[159] = (char *(*)()) F1090_9712;
}

char *(*R6677[34])();
void R6677_init () {
	R6677[0] = (char *(*)()) F933_7722;
	R6677[1] = (char *(*)()) F934_7722;
	R6677[2] = (char *(*)()) F935_7722;
	R6677[3] = (char *(*)()) F936_7722;
	R6677[4] = (char *(*)()) F937_7722;
	R6677[5] = (char *(*)()) F938_7722;
	R6677[6] = (char *(*)()) F939_7722;
	R6677[7] = (char *(*)()) F940_7722;
	R6677[8] = (char *(*)()) F941_7722;
	R6677[9] = (char *(*)()) F942_7722;
	R6677[10] = (char *(*)()) F943_7722;
	R6677[11] = (char *(*)()) F944_7722;
	R6677[12] = (char *(*)()) F945_7722;
	R6677[13] = (char *(*)()) F946_7722;
	R6677[14] = (char *(*)()) F947_7722;
	R6677[15] = (char *(*)()) F948_7722;
	R6677[16] = (char *(*)()) F949_7722;
	R6677[17] = (char *(*)()) F950_7722;
	R6677[18] = (char *(*)()) F951_7722;
	R6677[19] = (char *(*)()) F952_7722;
	R6677[20] = (char *(*)()) F953_7722;
	R6677[21] = (char *(*)()) F954_7722;
	R6677[22] = (char *(*)()) F955_7722;
	R6677[23] = (char *(*)()) F956_7722;
	R6677[24] = (char *(*)()) F957_7722;
	R6677[25] = (char *(*)()) F958_7722;
	R6677[26] = (char *(*)()) F959_7722;
	R6677[27] = (char *(*)()) F960_7722;
	R6677[28] = (char *(*)()) F961_7722;
	R6677[29] = (char *(*)()) F962_7722;
	R6677[30] = (char *(*)()) F963_7722;
	R6677[31] = (char *(*)()) F964_7722;
	R6677[32] = (char *(*)()) F965_7722;
	R6677[33] = (char *(*)()) F966_7722;
}

char *(*R6678[34])();
void R6678_init () {
	R6678[0] = (char *(*)()) F933_7723;
	R6678[1] = (char *(*)()) F934_7723;
	R6678[2] = (char *(*)()) F935_7723;
	R6678[3] = (char *(*)()) F936_7723;
	R6678[4] = (char *(*)()) F937_7723;
	R6678[5] = (char *(*)()) F938_7723;
	R6678[6] = (char *(*)()) F939_7723;
	R6678[7] = (char *(*)()) F940_7723;
	R6678[8] = (char *(*)()) F941_7723;
	R6678[9] = (char *(*)()) F942_7723;
	R6678[10] = (char *(*)()) F943_7723;
	R6678[11] = (char *(*)()) F944_7723;
	R6678[12] = (char *(*)()) F945_7723;
	R6678[13] = (char *(*)()) F946_7723;
	R6678[14] = (char *(*)()) F947_7723;
	R6678[15] = (char *(*)()) F948_7723;
	R6678[16] = (char *(*)()) F949_7723;
	R6678[17] = (char *(*)()) F950_7723;
	R6678[18] = (char *(*)()) F951_7723;
	R6678[19] = (char *(*)()) F952_7723;
	R6678[20] = (char *(*)()) F953_7723;
	R6678[21] = (char *(*)()) F954_7723;
	R6678[22] = (char *(*)()) F955_7723;
	R6678[23] = (char *(*)()) F956_7723;
	R6678[24] = (char *(*)()) F957_7723;
	R6678[25] = (char *(*)()) F958_7723;
	R6678[26] = (char *(*)()) F959_7723;
	R6678[27] = (char *(*)()) F960_7723;
	R6678[28] = (char *(*)()) F961_7723;
	R6678[29] = (char *(*)()) F962_7723;
	R6678[30] = (char *(*)()) F963_7723;
	R6678[31] = (char *(*)()) F964_7723;
	R6678[32] = (char *(*)()) F965_7723;
	R6678[33] = (char *(*)()) F966_7723;
}

char *(*R6679[34])();
void R6679_init () {
	R6679[0] = (char *(*)()) F933_7724;
	R6679[1] = (char *(*)()) F934_7724;
	R6679[2] = (char *(*)()) F935_7724;
	R6679[3] = (char *(*)()) F936_7724;
	R6679[4] = (char *(*)()) F937_7724;
	R6679[5] = (char *(*)()) F938_7724;
	R6679[6] = (char *(*)()) F939_7724;
	R6679[7] = (char *(*)()) F940_7724;
	R6679[8] = (char *(*)()) F941_7724;
	R6679[9] = (char *(*)()) F942_7724;
	R6679[10] = (char *(*)()) F943_7724;
	R6679[11] = (char *(*)()) F944_7724;
	R6679[12] = (char *(*)()) F945_7724;
	R6679[13] = (char *(*)()) F946_7724;
	R6679[14] = (char *(*)()) F947_7724;
	R6679[15] = (char *(*)()) F948_7724;
	R6679[16] = (char *(*)()) F949_7724;
	R6679[17] = (char *(*)()) F950_7724;
	R6679[18] = (char *(*)()) F951_7724;
	R6679[19] = (char *(*)()) F952_7724;
	R6679[20] = (char *(*)()) F953_7724;
	R6679[21] = (char *(*)()) F954_7724;
	R6679[22] = (char *(*)()) F955_7724;
	R6679[23] = (char *(*)()) F956_7724;
	R6679[24] = (char *(*)()) F957_7724;
	R6679[25] = (char *(*)()) F958_7724;
	R6679[26] = (char *(*)()) F959_7724;
	R6679[27] = (char *(*)()) F960_7724;
	R6679[28] = (char *(*)()) F961_7724;
	R6679[29] = (char *(*)()) F962_7724;
	R6679[30] = (char *(*)()) F963_7724;
	R6679[31] = (char *(*)()) F964_7724;
	R6679[32] = (char *(*)()) F965_7724;
	R6679[33] = (char *(*)()) F966_7724;
}

char *(*R6680[34])();
void R6680_init () {
	R6680[0] = (char *(*)()) F933_7725;
	R6680[1] = (char *(*)()) F934_7725;
	R6680[2] = (char *(*)()) F935_7725;
	R6680[3] = (char *(*)()) F936_7725;
	R6680[4] = (char *(*)()) F937_7725;
	R6680[5] = (char *(*)()) F938_7725;
	R6680[6] = (char *(*)()) F939_7725;
	R6680[7] = (char *(*)()) F940_7725;
	R6680[8] = (char *(*)()) F941_7725;
	R6680[9] = (char *(*)()) F942_7725;
	R6680[10] = (char *(*)()) F943_7725;
	R6680[11] = (char *(*)()) F944_7725;
	R6680[12] = (char *(*)()) F945_7725;
	R6680[13] = (char *(*)()) F946_7725;
	R6680[14] = (char *(*)()) F947_7725;
	R6680[15] = (char *(*)()) F948_7725;
	R6680[16] = (char *(*)()) F949_7725;
	R6680[17] = (char *(*)()) F950_7725;
	R6680[18] = (char *(*)()) F951_7725;
	R6680[19] = (char *(*)()) F952_7725;
	R6680[20] = (char *(*)()) F953_7725;
	R6680[21] = (char *(*)()) F954_7725;
	R6680[22] = (char *(*)()) F955_7725;
	R6680[23] = (char *(*)()) F956_7725;
	R6680[24] = (char *(*)()) F957_7725;
	R6680[25] = (char *(*)()) F958_7725;
	R6680[26] = (char *(*)()) F959_7725;
	R6680[27] = (char *(*)()) F960_7725;
	R6680[28] = (char *(*)()) F961_7725;
	R6680[29] = (char *(*)()) F962_7725;
	R6680[30] = (char *(*)()) F963_7725;
	R6680[31] = (char *(*)()) F964_7725;
	R6680[32] = (char *(*)()) F965_7725;
	R6680[33] = (char *(*)()) F966_7725;
}

char *(*R6685[34])();
void R6685_init () {
	R6685[0] = (char *(*)()) F933_7731;
	R6685[1] = (char *(*)()) F934_7731;
	R6685[2] = (char *(*)()) F935_7731;
	R6685[3] = (char *(*)()) F936_7731;
	R6685[4] = (char *(*)()) F937_7731;
	R6685[5] = (char *(*)()) F938_7731;
	R6685[6] = (char *(*)()) F939_7731;
	R6685[7] = (char *(*)()) F940_7731;
	R6685[8] = (char *(*)()) F941_7731;
	R6685[9] = (char *(*)()) F942_7731;
	R6685[10] = (char *(*)()) F943_7731;
	R6685[11] = (char *(*)()) F944_7731;
	R6685[12] = (char *(*)()) F945_7731;
	R6685[13] = (char *(*)()) F946_7731;
	R6685[14] = (char *(*)()) F947_7731;
	R6685[15] = (char *(*)()) F948_7731;
	R6685[16] = (char *(*)()) F949_7731;
	R6685[17] = (char *(*)()) F950_7731;
	R6685[18] = (char *(*)()) F951_7731;
	R6685[19] = (char *(*)()) F952_7731;
	R6685[20] = (char *(*)()) F953_7731;
	R6685[21] = (char *(*)()) F954_7731;
	R6685[22] = (char *(*)()) F955_7731;
	R6685[23] = (char *(*)()) F956_7731;
	R6685[24] = (char *(*)()) F957_7731;
	R6685[25] = (char *(*)()) F958_7731;
	R6685[26] = (char *(*)()) F959_7731;
	R6685[27] = (char *(*)()) F960_7731;
	R6685[28] = (char *(*)()) F961_7731;
	R6685[29] = (char *(*)()) F962_7731;
	R6685[30] = (char *(*)()) F963_7731;
	R6685[31] = (char *(*)()) F964_7731;
	R6685[32] = (char *(*)()) F965_7731;
	R6685[33] = (char *(*)()) F966_7731;
}

char *(*R6690[34])();
void R6690_init () {
	R6690[0] = (char *(*)()) F933_7739;
	R6690[1] = (char *(*)()) F934_7739_6690_1;
	R6690[2] = (char *(*)()) F935_7739_6690_1;
	R6690[3] = (char *(*)()) F936_7739_6690_1;
	R6690[4] = (char *(*)()) F937_7739_6690_1;
	R6690[5] = (char *(*)()) F938_7739_6690_1;
	R6690[6] = (char *(*)()) F939_7739_6690_1;
	R6690[7] = (char *(*)()) F940_7739_6690_1;
	R6690[8] = (char *(*)()) F941_7739_6690_1;
	R6690[9] = (char *(*)()) F942_7739_6690_1;
	R6690[10] = (char *(*)()) F943_7739_6690_1;
	R6690[11] = (char *(*)()) F944_7739_6690_1;
	R6690[12] = (char *(*)()) F945_7739_6690_1;
	R6690[13] = (char *(*)()) F946_7739_6690_1;
	R6690[14] = (char *(*)()) F947_7739_6690_1;
	R6690[15] = (char *(*)()) F948_7739_6690_1;
	R6690[16] = (char *(*)()) F949_7739;
	R6690[17] = (char *(*)()) F950_7739;
	R6690[18] = (char *(*)()) F951_7739;
	R6690[19] = (char *(*)()) F952_7739_6690_1;
	R6690[20] = (char *(*)()) F953_7739_6690_1;
	R6690[21] = (char *(*)()) F954_7739;
	R6690[22] = (char *(*)()) F955_7739_6690_1;
	R6690[23] = (char *(*)()) F956_7739_6690_1;
	R6690[24] = (char *(*)()) F957_7739_6690_1;
	R6690[25] = (char *(*)()) F958_7739_6690_1;
	R6690[26] = (char *(*)()) F959_7739_6690_1;
	R6690[27] = (char *(*)()) F960_7739_6690_1;
	R6690[28] = (char *(*)()) F961_7739_6690_1;
	R6690[29] = (char *(*)()) F962_7739_6690_1;
	R6690[30] = (char *(*)()) F963_7739_6690_1;
	R6690[31] = (char *(*)()) F964_7739_6690_1;
	R6690[32] = (char *(*)()) F965_7739_6690_1;
	R6690[33] = (char *(*)()) F966_7739_6690_1;
}
static EIF_REFERENCE F934_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F934_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F935_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F935_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1008,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1008, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F936_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F936_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F937_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F937_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F938_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F938_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F939_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F939_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F940_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F940_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F941_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F941_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F942_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F942_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(990, 0x00).id, 990, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F943_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F943_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(987, 0x00).id, 987, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F944_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F944_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F945_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F945_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(981, 0x00).id, 981, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F946_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F946_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F947_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F947_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F948_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F948_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F952_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F952_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1010,999,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1010, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F953_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F953_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1012,972,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1012, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F955_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F955_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1014,987,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1014, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F956_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F956_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1016,1038,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1016, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F957_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F957_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1018,1005,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1018, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F958_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F958_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1020,969,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1020, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F959_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F959_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1022,978,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1022, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F960_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F960_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1024,993,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1024, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F961_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F961_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1026,996,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1026, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F962_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F962_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1028,975,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1028, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F963_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F963_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1030,1002,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1030, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F964_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F964_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1032,990,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1032, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F965_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F965_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1034,984,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1034, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F966_7739_6690_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F966_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1036,981,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1036, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}

char *(*R6700[34])();
void R6700_init () {
	R6700[0] = (char *(*)()) F933_7751;
	R6700[1] = (char *(*)()) F934_7751;
	R6700[2] = (char *(*)()) F935_7751;
	R6700[3] = (char *(*)()) F936_7751;
	R6700[4] = (char *(*)()) F937_7751;
	R6700[5] = (char *(*)()) F938_7751;
	R6700[6] = (char *(*)()) F939_7751;
	R6700[7] = (char *(*)()) F940_7751;
	R6700[8] = (char *(*)()) F941_7751;
	R6700[9] = (char *(*)()) F942_7751;
	R6700[10] = (char *(*)()) F943_7751;
	R6700[11] = (char *(*)()) F944_7751;
	R6700[12] = (char *(*)()) F945_7751;
	R6700[13] = (char *(*)()) F946_7751;
	R6700[14] = (char *(*)()) F947_7751;
	R6700[15] = (char *(*)()) F948_7751;
	R6700[16] = (char *(*)()) F949_7751;
	R6700[17] = (char *(*)()) F950_7751;
	R6700[18] = (char *(*)()) F951_7751;
	R6700[19] = (char *(*)()) F952_7751;
	R6700[20] = (char *(*)()) F953_7751;
	R6700[21] = (char *(*)()) F954_7751;
	R6700[22] = (char *(*)()) F955_7751;
	R6700[23] = (char *(*)()) F956_7751;
	R6700[24] = (char *(*)()) F957_7751;
	R6700[25] = (char *(*)()) F958_7751;
	R6700[26] = (char *(*)()) F959_7751;
	R6700[27] = (char *(*)()) F960_7751;
	R6700[28] = (char *(*)()) F961_7751;
	R6700[29] = (char *(*)()) F962_7751;
	R6700[30] = (char *(*)()) F963_7751;
	R6700[31] = (char *(*)()) F964_7751;
	R6700[32] = (char *(*)()) F965_7751;
	R6700[33] = (char *(*)()) F966_7751;
}

char *(*R6842[2])();
void R6842_init () {
	R6842[0] = (char *(*)()) F969_7930;
	R6842[1] = (char *(*)()) F970_7930;
}

char *(*R6849[2])();
void R6849_init () {
	R6849[0] = (char *(*)()) F969_7934;
	R6849[1] = (char *(*)()) F970_7934;
}

char *(*R6863[2])();
void R6863_init () {
	R6863[0] = (char *(*)()) F972_7988;
	R6863[1] = (char *(*)()) F973_7988;
}

char *(*R6969[2])();
void R6969_init () {
	R6969[0] = (char *(*)()) F981_8144;
	R6969[1] = (char *(*)()) F982_8144;
}

char *(*R6972[2])();
void R6972_init () {
	R6972[0] = (char *(*)()) F981_8147;
	R6972[1] = (char *(*)()) F982_8147;
}

char *(*R7024[2])();
void R7024_init () {
	R7024[0] = (char *(*)()) F984_8242;
	R7024[1] = (char *(*)()) F985_8242;
}

char *(*R7025[2])();
void R7025_init () {
	R7025[0] = (char *(*)()) F984_8243;
	R7025[1] = (char *(*)()) F985_8243;
}

char *(*R7027[2])();
void R7027_init () {
	R7027[0] = (char *(*)()) F984_8245;
	R7027[1] = (char *(*)()) F985_8245;
}

char *(*R7029[2])();
void R7029_init () {
	R7029[0] = (char *(*)()) F984_8247;
	R7029[1] = (char *(*)()) F985_8247;
}

char *(*R7081[2])();
void R7081_init () {
	R7081[0] = (char *(*)()) F987_8342;
	R7081[1] = (char *(*)()) F988_8342;
}

char *(*R7084[2])();
void R7084_init () {
	R7084[0] = (char *(*)()) F987_8345;
	R7084[1] = (char *(*)()) F988_8345;
}

char *(*R7134[2])();
void R7134_init () {
	R7134[0] = (char *(*)()) F990_8438;
	R7134[1] = (char *(*)()) F991_8438;
}

char *(*R7137[2])();
void R7137_init () {
	R7137[0] = (char *(*)()) F990_8441;
	R7137[1] = (char *(*)()) F991_8441;
}

char *(*R7140[2])();
void R7140_init () {
	R7140[0] = (char *(*)()) F990_8444;
	R7140[1] = (char *(*)()) F991_8444;
}

char *(*R7194[2])();
void R7194_init () {
	R7194[0] = (char *(*)()) F993_8538;
	R7194[1] = (char *(*)()) F994_8538;
}

char *(*R7240[2])();
void R7240_init () {
	R7240[0] = (char *(*)()) F996_8626;
	R7240[1] = (char *(*)()) F997_8626;
}

char *(*R7241[2])();
void R7241_init () {
	R7241[0] = (char *(*)()) F996_8627;
	R7241[1] = (char *(*)()) F997_8627;
}

char *(*R7243[2])();
void R7243_init () {
	R7243[0] = (char *(*)()) F996_8629;
	R7243[1] = (char *(*)()) F997_8629;
}

char *(*R7246[2])();
void R7246_init () {
	R7246[0] = (char *(*)()) F996_8632;
	R7246[1] = (char *(*)()) F997_8632;
}

char *(*R7247[2])();
void R7247_init () {
	R7247[0] = (char *(*)()) F996_8633;
	R7247[1] = (char *(*)()) F997_8633;
}

char *(*R7295[2])();
void R7295_init () {
	R7295[0] = (char *(*)()) F999_8723;
	R7295[1] = (char *(*)()) F1000_8723;
}

char *(*R7296[2])();
void R7296_init () {
	R7296[0] = (char *(*)()) F999_8724;
	R7296[1] = (char *(*)()) F1000_8724;
}

char *(*R7299[2])();
void R7299_init () {
	R7299[0] = (char *(*)()) F999_8727;
	R7299[1] = (char *(*)()) F1000_8727;
}

char *(*R7347[2])();
void R7347_init () {
	R7347[0] = (char *(*)()) F1002_8817;
	R7347[1] = (char *(*)()) F1003_8817;
}

char *(*R7348[2])();
void R7348_init () {
	R7348[0] = (char *(*)()) F1002_8818;
	R7348[1] = (char *(*)()) F1003_8818;
}

char *(*R7349[2])();
void R7349_init () {
	R7349[0] = (char *(*)()) F1002_8819;
	R7349[1] = (char *(*)()) F1003_8819;
}

char *(*R7350[2])();
void R7350_init () {
	R7350[0] = (char *(*)()) F1002_8820;
	R7350[1] = (char *(*)()) F1003_8820;
}

char *(*R7352[2])();
void R7352_init () {
	R7352[0] = (char *(*)()) F1002_8822;
	R7352[1] = (char *(*)()) F1003_8822;
}

char *(*R7398[2])();
void R7398_init () {
	R7398[0] = (char *(*)()) F1005_8880;
	R7398[1] = (char *(*)()) F1006_8880;
}

char *(*R7405[2])();
void R7405_init () {
	R7405[0] = (char *(*)()) F1005_8884;
	R7405[1] = (char *(*)()) F1006_8884;
}

char *(*R7454[5])();
void R7454_init () {
	R7454[0] = (char *(*)()) F1041_8972;
	R7454[1] = (char *(*)()) F1042_8975;
	R7454[2] = (char *(*)()) F1043_8975;
	R7454[3] = (char *(*)()) F1044_8975;
	R7454[4] = (char *(*)()) F1043_8975;
}

char *(*R7478[4])();
void R7478_init () {
	R7478[0] = (char *(*)()) F1042_8974;
	R7478[1] = (char *(*)()) F1043_8974_7478_1;
	R7478[2] = (char *(*)()) F1044_8974_7478_1;
	R7478[3] = (char *(*)()) F1043_8974_7478_1;
}
static EIF_REFERENCE F1043_8974_7478_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1043_8974(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1044_8974_7478_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1044_8974(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R7479[4])();
void R7479_init () {
	R7479[0] = (char *(*)()) F1042_8976;
	R7479[1] = (char *(*)()) F1043_8976_7479_5;
	R7479[2] = (char *(*)()) F1044_8976_7479_5;
	R7479[3] = (char *(*)()) F1043_8976_7479_5;
}
static EIF_REFERENCE F1043_8976_7479_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1043_8976(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1044_8976_7479_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1044_8976(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R7483[4])();
void R7483_init () {
	R7483[0] = (char *(*)()) F1042_8983;
	R7483[1] = (char *(*)()) F1043_8983_7483_611;
	R7483[2] = (char *(*)()) F1044_8983_7483_611;
	R7483[3] = (char *(*)()) F1043_8983_7483_611;
}
static EIF_REFERENCE F1043_8983_7483_611 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1043_8983(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1044_8983_7483_611 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1044_8983(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y7484_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7484_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7484_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7484_pgtype3[] = {978,0xFFFF};
EIF_TYPE_INDEX *Y7484_gen_type [4];
EIF_TYPE_INDEX Y7484 [4];
void Y7484_init (void)
{
	egc_routines_types [7484] = Y7484;
	egc_routines_gen_types [7484] = Y7484_gen_type;
	egc_routines_offset [7484] = 1041;
	Y7484_gen_type [0] = Y7484_pgtype0;
	Y7484_gen_type [1] = Y7484_pgtype1;
	Y7484_gen_type [2] = Y7484_pgtype2;
	Y7484_gen_type [3] = Y7484_pgtype3;
	Y7484[3] = 978;
}

char *(*R7485[5])();
void R7485_init () {
	{long i; for (i = 0; i < 2; i++) R7485[i] = (char *(*)()) F1049_9115;}
	{long i; for (i = 3; i < 5; i++) R7485[i] = (char *(*)()) F1052_9282;}
}

char *(*R7487[5])();
void R7487_init () {
	R7487[0] = (char *(*)()) F1050_9176;
	R7487[1] = (char *(*)()) F1051_9199;
	R7487[3] = (char *(*)()) F1053_9342;
	R7487[4] = (char *(*)()) F1054_9364;
}

char *(*R7488[5])();
void R7488_init () {
	R7488[0] = (char *(*)()) F1050_9174;
	R7488[1] = (char *(*)()) F1051_9197;
	R7488[3] = (char *(*)()) F1053_9341;
	R7488[4] = (char *(*)()) F1054_9363;
}

char *(*R7489[5])();
void R7489_init () {
	{long i; for (i = 0; i < 2; i++) R7489[i] = (char *(*)()) F1049_9127;}
	{long i; for (i = 3; i < 5; i++) R7489[i] = (char *(*)()) F1046_8988;}
}

char *(*R7499[5])();
void R7499_init () {
	{long i; for (i = 0; i < 2; i++) R7499[i] = (char *(*)()) F1049_9145;}
	{long i; for (i = 3; i < 5; i++) R7499[i] = (char *(*)()) F1052_9313;}
}

char *(*R7501[5])();
void R7501_init () {
	{long i; for (i = 0; i < 2; i++) R7501[i] = (char *(*)()) F1049_9147;}
	{long i; for (i = 3; i < 5; i++) R7501[i] = (char *(*)()) F1052_9315;}
}

char *(*R7502[5])();
void R7502_init () {
	R7502[0] = (char *(*)()) F1050_9186;
	R7502[1] = (char *(*)()) F491_5229;
	R7502[3] = (char *(*)()) F1053_9351;
	R7502[4] = (char *(*)()) F489_5229;
}

char *(*R7504[5])();
void R7504_init () {
	{long i; for (i = 0; i < 2; i++) R7504[i] = (char *(*)()) F1049_9148;}
	{long i; for (i = 3; i < 5; i++) R7504[i] = (char *(*)()) F1052_9316;}
}

char *(*R7505[5])();
void R7505_init () {
	{long i; for (i = 0; i < 2; i++) R7505[i] = (char *(*)()) F1049_9149;}
	{long i; for (i = 3; i < 5; i++) R7505[i] = (char *(*)()) F1046_9005;}
}

char *(*R7524[5])();
void R7524_init () {
	{long i; for (i = 0; i < 2; i++) R7524[i] = (char *(*)()) F1049_9136;}
	{long i; for (i = 3; i < 5; i++) R7524[i] = (char *(*)()) F1052_9304;}
}

char *(*R7525[5])();
void R7525_init () {
	{long i; for (i = 0; i < 2; i++) R7525[i] = (char *(*)()) F1049_9135;}
	{long i; for (i = 3; i < 5; i++) R7525[i] = (char *(*)()) F1052_9303;}
}

char *(*R7535[5])();
void R7535_init () {
	{long i; for (i = 0; i < 2; i++) R7535[i] = (char *(*)()) F1049_9132;}
	{long i; for (i = 3; i < 5; i++) R7535[i] = (char *(*)()) F1052_9300;}
}

char *(*R7546[5])();
void R7546_init () {
	R7546[0] = (char *(*)()) F1050_9181;
	R7546[1] = (char *(*)()) F1051_9265;
	R7546[4] = (char *(*)()) F1054_9430;
}

char *(*R7565[5])();
void R7565_init () {
	R7565[0] = (char *(*)()) F1050_9183;
	R7565[1] = (char *(*)()) F1051_9277;
	R7565[3] = (char *(*)()) F1053_9349;
	R7565[4] = (char *(*)()) F1054_9442;
}

char *(*R7569[5])();
void R7569_init () {
	R7569[0] = (char *(*)()) F1050_9187;
	R7569[1] = (char *(*)()) F1051_9280;
	R7569[3] = (char *(*)()) F1053_9353;
	R7569[4] = (char *(*)()) F1054_9446;
}

char *(*R7580[4])();
void R7580_init () {
	R7580[0] = (char *(*)()) F1051_9279;
	R7580[3] = (char *(*)()) F1054_9444;
}

char *(*R7583[4])();
void R7583_init () {
	R7583[0] = (char *(*)()) F1051_9218;
	R7583[3] = (char *(*)()) F1054_9383;
}

char *(*R7595[4])();
void R7595_init () {
	R7595[0] = (char *(*)()) F1051_9229;
	R7595[3] = (char *(*)()) F1054_9394;
}

char *(*R7613[4])();
void R7613_init () {
	R7613[0] = (char *(*)()) F1051_9262;
	R7613[3] = (char *(*)()) F1054_9427;
}

char *(*R7641[2])();
void R7641_init () {
	R7641[0] = (char *(*)()) F1050_9189;
	R7641[1] = (char *(*)()) F1049_9166;
}

char *(*R7713[2])();
void R7713_init () {
	R7713[0] = (char *(*)()) F1053_9344;
	R7713[1] = (char *(*)()) F1054_9414;
}

char *(*R7721[2])();
void R7721_init () {
	R7721[0] = (char *(*)()) F1053_9355;
	R7721[1] = (char *(*)()) F1052_9334;
}

char *(*R7818[2])();
void R7818_init () {
	R7818[0] = (char *(*)()) F1156_10604;
	R7818[1] = (char *(*)()) F1157_10625;
}

char *(*R7823[44])();
void R7823_init () {
	R7823[0] = (char *(*)()) F1133_10301;
	{long i; for (i = 1; i < 3; i++) R7823[i] = (char *(*)()) F1134_10303;}
	R7823[3] = (char *(*)()) F1136_10353;
	R7823[4] = (char *(*)()) F1137_10361;
	R7823[6] = (char *(*)()) F1139_10385;
	R7823[7] = (char *(*)()) F1140_10418;
	R7823[11] = (char *(*)()) F1142_10444;
	{long i; for (i = 12; i < 14; i++) R7823[i] = (char *(*)()) F1145_10463;}
	R7823[15] = (char *(*)()) F1145_10463;
	R7823[43] = (char *(*)()) F1176_10779;
}

char *(*R7825[17])();
void R7825_init () {
	R7825[0] = (char *(*)()) F1170_10719;
	R7825[16] = (char *(*)()) F1186_10843;
}

char *(*R7827[54])();
void R7827_init () {
	R7827[0] = (char *(*)()) F1133_10301;
	{long i; for (i = 1; i < 3; i++) R7827[i] = (char *(*)()) F1134_10303;}
	R7827[3] = (char *(*)()) F1136_10353;
	R7827[4] = (char *(*)()) F1137_10361;
	R7827[6] = (char *(*)()) F1139_10385;
	R7827[7] = (char *(*)()) F1140_10418;
	R7827[11] = (char *(*)()) F1142_10444;
	{long i; for (i = 12; i < 14; i++) R7827[i] = (char *(*)()) F1145_10463;}
	R7827[15] = (char *(*)()) F1145_10463;
	R7827[18] = (char *(*)()) F1151_10534;
	R7827[19] = (char *(*)()) F1152_10557;
	R7827[20] = (char *(*)()) F1153_10564;
	R7827[23] = (char *(*)()) F1156_10604;
	R7827[24] = (char *(*)()) F1157_10625;
	R7827[26] = (char *(*)()) F1159_10666;
	R7827[34] = (char *(*)()) F1167_10698;
	R7827[37] = (char *(*)()) F1170_10719;
	R7827[43] = (char *(*)()) F1176_10779;
	R7827[53] = (char *(*)()) F1186_10843;
}

char *(*R7839[9])();
void R7839_init () {
	R7839[0] = (char *(*)()) F1140_10418;
	R7839[4] = (char *(*)()) F1142_10444;
	{long i; for (i = 5; i < 7; i++) R7839[i] = (char *(*)()) F1145_10463;}
	R7839[8] = (char *(*)()) F1145_10463;
}

char *(*R7844[44])();
void R7844_init () {
	R7844[0] = (char *(*)()) F1133_10301;
	{long i; for (i = 1; i < 3; i++) R7844[i] = (char *(*)()) F1134_10303;}
	R7844[3] = (char *(*)()) F1136_10353;
	R7844[4] = (char *(*)()) F1137_10361;
	R7844[6] = (char *(*)()) F1139_10385;
	R7844[7] = (char *(*)()) F1140_10418;
	R7844[11] = (char *(*)()) F1142_10444;
	{long i; for (i = 12; i < 14; i++) R7844[i] = (char *(*)()) F1145_10463;}
	R7844[15] = (char *(*)()) F1145_10463;
	R7844[18] = (char *(*)()) F1151_10534;
	R7844[19] = (char *(*)()) F1152_10557;
	R7844[20] = (char *(*)()) F1153_10564;
	R7844[23] = (char *(*)()) F1156_10604;
	R7844[24] = (char *(*)()) F1157_10625;
	R7844[26] = (char *(*)()) F1159_10666;
	R7844[43] = (char *(*)()) F1176_10779;
}

char *(*R7887[101])();
void R7887_init () {
	R7887[0] = (char *(*)()) F1086_9630;
	R7887[1] = (char *(*)()) F1087_9636;
	R7887[3] = (char *(*)()) F1089_9676;
	R7887[4] = (char *(*)()) F1090_9717;
	R7887[5] = (char *(*)()) F1091_9748;
	R7887[6] = (char *(*)()) F1092_9764;
	R7887[7] = (char *(*)()) F1093_9775;
	R7887[9] = (char *(*)()) F1095_9803;
	R7887[14] = (char *(*)()) F1099_9866;
	R7887[31] = (char *(*)()) F1117_10056;
	R7887[33] = (char *(*)()) F1119_10075;
	R7887[47] = (char *(*)()) F1133_10301;
	{long i; for (i = 48; i < 50; i++) R7887[i] = (char *(*)()) F1134_10303;}
	R7887[50] = (char *(*)()) F1136_10353;
	R7887[51] = (char *(*)()) F1137_10361;
	R7887[53] = (char *(*)()) F1139_10385;
	R7887[54] = (char *(*)()) F1140_10418;
	R7887[58] = (char *(*)()) F1142_10444;
	{long i; for (i = 59; i < 61; i++) R7887[i] = (char *(*)()) F1145_10463;}
	R7887[62] = (char *(*)()) F1145_10463;
	R7887[65] = (char *(*)()) F1151_10534;
	R7887[66] = (char *(*)()) F1152_10557;
	R7887[67] = (char *(*)()) F1153_10564;
	R7887[70] = (char *(*)()) F1156_10604;
	R7887[71] = (char *(*)()) F1157_10625;
	R7887[73] = (char *(*)()) F1159_10666;
	R7887[81] = (char *(*)()) F1167_10698;
	R7887[84] = (char *(*)()) F1170_10719;
	R7887[90] = (char *(*)()) F1176_10779;
	R7887[100] = (char *(*)()) F1186_10843;
}

char *(*R7889[101])();
void R7889_init () {
	R7889[0] = (char *(*)()) F1086_9632;
	R7889[1] = (char *(*)()) F1087_9637;
	R7889[3] = (char *(*)()) F1089_9675;
	R7889[4] = (char *(*)()) F1090_9719;
	R7889[5] = (char *(*)()) F1091_9750;
	R7889[6] = (char *(*)()) F1092_9763;
	R7889[7] = (char *(*)()) F1093_9778;
	R7889[9] = (char *(*)()) F1095_9805;
	R7889[14] = (char *(*)()) F1099_9868;
	R7889[31] = (char *(*)()) F1117_10058;
	R7889[33] = (char *(*)()) F1119_10076;
	R7889[47] = (char *(*)()) F1133_10302;
	{long i; for (i = 48; i < 50; i++) R7889[i] = (char *(*)()) F1134_10304;}
	R7889[50] = (char *(*)()) F1136_10354;
	R7889[51] = (char *(*)()) F1137_10362;
	R7889[53] = (char *(*)()) F1139_10386;
	R7889[54] = (char *(*)()) F1140_10422;
	R7889[58] = (char *(*)()) F1142_10445;
	{long i; for (i = 59; i < 61; i++) R7889[i] = (char *(*)()) F1145_10464;}
	R7889[62] = (char *(*)()) F1145_10464;
	R7889[65] = (char *(*)()) F1151_10535;
	R7889[66] = (char *(*)()) F1152_10558;
	R7889[67] = (char *(*)()) F1153_10565;
	R7889[70] = (char *(*)()) F1156_10605;
	R7889[71] = (char *(*)()) F1157_10626;
	R7889[73] = (char *(*)()) F1159_10667;
	R7889[81] = (char *(*)()) F1167_10699;
	R7889[84] = (char *(*)()) F1170_10720;
	R7889[90] = (char *(*)()) F1176_10769;
	R7889[100] = (char *(*)()) F1186_10844;
}

char *(*R7890[101])();
void R7890_init () {
	R7890[0] = (char *(*)()) F1086_9631;
	R7890[1] = (char *(*)()) F1087_9638;
	R7890[3] = (char *(*)()) F1089_9674;
	R7890[4] = (char *(*)()) F1090_9718;
	R7890[5] = (char *(*)()) F1091_9749;
	R7890[6] = (char *(*)()) F1092_9762;
	R7890[7] = (char *(*)()) F1093_9777;
	R7890[9] = (char *(*)()) F1095_9804;
	R7890[14] = (char *(*)()) F1099_9867;
	R7890[31] = (char *(*)()) F1117_10057;
	R7890[33] = (char *(*)()) F1118_10067;
	{long i; for (i = 47; i < 52; i++) R7890[i] = (char *(*)()) F928_7612;}
	{long i; for (i = 53; i < 55; i++) R7890[i] = (char *(*)()) F928_7612;}
	R7890[58] = (char *(*)()) F1143_10446;
	{long i; for (i = 59; i < 61; i++) R7890[i] = (char *(*)()) F928_7612;}
	R7890[62] = (char *(*)()) F1147_10473;
	{long i; for (i = 65; i < 68; i++) R7890[i] = (char *(*)()) F928_7612;}
	{long i; for (i = 70; i < 72; i++) R7890[i] = (char *(*)()) F928_7612;}
	R7890[73] = (char *(*)()) F928_7612;
	R7890[81] = (char *(*)()) F928_7612;
	R7890[84] = (char *(*)()) F928_7612;
	R7890[90] = (char *(*)()) F928_7612;
	R7890[100] = (char *(*)()) F928_7612;
}

char *(*R7891[101])();
void R7891_init () {
	{long i; for (i = 0; i < 2; i++) R7891[i] = (char *(*)()) F1083_9571;}
	{long i; for (i = 3; i < 8; i++) R7891[i] = (char *(*)()) F1083_9571;}
	R7891[9] = (char *(*)()) F1083_9571;
	R7891[14] = (char *(*)()) F1099_9829;
	R7891[31] = (char *(*)()) F1083_9571;
	R7891[33] = (char *(*)()) F1083_9571;
	{long i; for (i = 47; i < 52; i++) R7891[i] = (char *(*)()) F1083_9571;}
	R7891[53] = (char *(*)()) F1083_9571;
	R7891[54] = (char *(*)()) F1140_10388;
	R7891[58] = (char *(*)()) F1143_10447;
	{long i; for (i = 59; i < 61; i++) R7891[i] = (char *(*)()) F1145_10450;}
	R7891[62] = (char *(*)()) F1148_10505;
	{long i; for (i = 65; i < 68; i++) R7891[i] = (char *(*)()) F1083_9571;}
	{long i; for (i = 70; i < 72; i++) R7891[i] = (char *(*)()) F1083_9571;}
	R7891[73] = (char *(*)()) F1083_9571;
	R7891[81] = (char *(*)()) F1083_9571;
	R7891[84] = (char *(*)()) F1083_9571;
	R7891[90] = (char *(*)()) F1083_9571;
	R7891[100] = (char *(*)()) F1083_9571;
}

char *(*R8070[54])();
void R8070_init () {
	{long i; for (i = 0; i < 5; i++) R8070[i] = (char *(*)()) F1127_10187;}
	{long i; for (i = 6; i < 8; i++) R8070[i] = (char *(*)()) F1127_10187;}
	{long i; for (i = 11; i < 14; i++) R8070[i] = (char *(*)()) F1127_10187;}
	R8070[15] = (char *(*)()) F1127_10187;
	{long i; for (i = 18; i < 21; i++) R8070[i] = (char *(*)()) F1127_10187;}
	{long i; for (i = 23; i < 25; i++) R8070[i] = (char *(*)()) F1127_10187;}
	R8070[26] = (char *(*)()) F1127_10187;
	R8070[34] = (char *(*)()) F1166_10697;
	R8070[37] = (char *(*)()) F1163_10676;
	R8070[43] = (char *(*)()) F1127_10187;
	R8070[53] = (char *(*)()) F1186_10838;
}

char *(*R8072[54])();
void R8072_init () {
	{long i; for (i = 0; i < 4; i++) R8072[i] = (char *(*)()) F1096_9809;}
	R8072[4] = (char *(*)()) F1137_10356;
	{long i; for (i = 6; i < 8; i++) R8072[i] = (char *(*)()) F1096_9809;}
	{long i; for (i = 11; i < 14; i++) R8072[i] = (char *(*)()) F1096_9809;}
	R8072[15] = (char *(*)()) F1147_10479;
	{long i; for (i = 18; i < 21; i++) R8072[i] = (char *(*)()) F1096_9809;}
	{long i; for (i = 23; i < 25; i++) R8072[i] = (char *(*)()) F1096_9809;}
	R8072[26] = (char *(*)()) F1159_10661;
	R8072[34] = (char *(*)()) F1096_9809;
	R8072[37] = (char *(*)()) F1170_10714;
	R8072[43] = (char *(*)()) F1096_9809;
	R8072[53] = (char *(*)()) F1170_10714;
}

char *(*R8129[60])();
void R8129_init () {
	R8129[0] = (char *(*)()) F1101_9873;
	{long i; for (i = 16; i < 21; i++) R8129[i] = (char *(*)()) F1101_9873;}
	{long i; for (i = 22; i < 24; i++) R8129[i] = (char *(*)()) F1101_9873;}
	{long i; for (i = 27; i < 30; i++) R8129[i] = (char *(*)()) F1101_9873;}
	R8129[31] = (char *(*)()) F1147_10477;
	{long i; for (i = 34; i < 37; i++) R8129[i] = (char *(*)()) F1101_9873;}
	{long i; for (i = 39; i < 41; i++) R8129[i] = (char *(*)()) F1101_9873;}
	R8129[42] = (char *(*)()) F1101_9873;
	R8129[59] = (char *(*)()) F1101_9873;
}

char *(*R8130[60])();
void R8130_init () {
	R8130[0] = (char *(*)()) F1101_9874;
	{long i; for (i = 16; i < 21; i++) R8130[i] = (char *(*)()) F1101_9874;}
	{long i; for (i = 22; i < 24; i++) R8130[i] = (char *(*)()) F1101_9874;}
	{long i; for (i = 27; i < 30; i++) R8130[i] = (char *(*)()) F1101_9874;}
	R8130[31] = (char *(*)()) F1147_10478;
	{long i; for (i = 34; i < 37; i++) R8130[i] = (char *(*)()) F1101_9874;}
	{long i; for (i = 39; i < 41; i++) R8130[i] = (char *(*)()) F1101_9874;}
	R8130[42] = (char *(*)()) F1101_9874;
	R8130[59] = (char *(*)()) F1101_9874;
}

char *(*R8131[60])();
void R8131_init () {
	R8131[0] = (char *(*)()) F1101_9875;
	{long i; for (i = 16; i < 21; i++) R8131[i] = (char *(*)()) F1101_9875;}
	{long i; for (i = 22; i < 24; i++) R8131[i] = (char *(*)()) F1101_9875;}
	{long i; for (i = 27; i < 30; i++) R8131[i] = (char *(*)()) F1101_9875;}
	R8131[31] = (char *(*)()) F1147_10481;
	{long i; for (i = 34; i < 37; i++) R8131[i] = (char *(*)()) F1101_9875;}
	{long i; for (i = 39; i < 41; i++) R8131[i] = (char *(*)()) F1101_9875;}
	R8131[42] = (char *(*)()) F1101_9875;
	R8131[59] = (char *(*)()) F1101_9875;
}

char *(*R8132[60])();
void R8132_init () {
	R8132[0] = (char *(*)()) F1101_9876;
	{long i; for (i = 16; i < 21; i++) R8132[i] = (char *(*)()) F1101_9876;}
	{long i; for (i = 22; i < 24; i++) R8132[i] = (char *(*)()) F1101_9876;}
	{long i; for (i = 27; i < 30; i++) R8132[i] = (char *(*)()) F1101_9876;}
	R8132[31] = (char *(*)()) F1147_10480;
	{long i; for (i = 34; i < 37; i++) R8132[i] = (char *(*)()) F1101_9876;}
	{long i; for (i = 39; i < 41; i++) R8132[i] = (char *(*)()) F1101_9876;}
	R8132[42] = (char *(*)()) F1101_9876;
	R8132[59] = (char *(*)()) F1101_9876;
}

char *(*R8394[16])();
void R8394_init () {
	{long i; for (i = 0; i < 3; i++) R8394[i] = (char *(*)()) F1125_10152;}
	{long i; for (i = 3; i < 5; i++) R8394[i] = (char *(*)()) F1128_10228;}
	{long i; for (i = 6; i < 8; i++) R8394[i] = (char *(*)()) F1128_10228;}
	{long i; for (i = 11; i < 14; i++) R8394[i] = (char *(*)()) F1128_10228;}
	R8394[15] = (char *(*)()) F1128_10228;
}

char *(*R8397[16])();
void R8397_init () {
	{long i; for (i = 0; i < 3; i++) R8397[i] = (char *(*)()) F1125_10161;}
	{long i; for (i = 3; i < 5; i++) R8397[i] = (char *(*)()) F1136_10350;}
	{long i; for (i = 6; i < 8; i++) R8397[i] = (char *(*)()) F1136_10350;}
	{long i; for (i = 11; i < 14; i++) R8397[i] = (char *(*)()) F1136_10350;}
	R8397[15] = (char *(*)()) F1136_10350;
}

char *(*R8819[174])();
void R8819_init () {
	R8819[0] = (char *(*)()) F1194_10986;
	R8819[5] = (char *(*)()) F1199_11062;
	R8819[7] = (char *(*)()) F1201_11118;
	R8819[10] = (char *(*)()) F1204_11208;
	R8819[12] = (char *(*)()) F1206_11228;
	R8819[14] = (char *(*)()) F1207_11258;
	R8819[17] = (char *(*)()) F1211_11305;
	R8819[19] = (char *(*)()) F1213_11510;
	R8819[23] = (char *(*)()) F1214_11562;
	R8819[63] = (char *(*)()) F1214_11562;
	{long i; for (i = 86; i < 88; i++) R8819[i] = (char *(*)()) F1269_12298;}
	{long i; for (i = 92; i < 94; i++) R8819[i] = (char *(*)()) F1269_12298;}
	R8819[95] = (char *(*)()) F1269_12298;
	R8819[100] = (char *(*)()) F1294_12631;
	{long i; for (i = 102; i < 104; i++) R8819[i] = (char *(*)()) F1294_12631;}
	{long i; for (i = 125; i < 127; i++) R8819[i] = (char *(*)()) F1267_12239;}
	R8819[130] = (char *(*)()) F1267_12239;
	R8819[132] = (char *(*)()) F1267_12239;
	R8819[134] = (char *(*)()) F1267_12239;
	R8819[147] = (char *(*)()) F1340_13504;
	R8819[153] = (char *(*)()) F1340_13504;
	R8819[157] = (char *(*)()) F1351_13577;
	R8819[170] = (char *(*)()) F1364_13862;
	R8819[172] = (char *(*)()) F1366_13945;
	R8819[173] = (char *(*)()) F1367_14031;
}

char *(*R9361[150])();
void R9361_init () {
	R9361[0] = (char *(*)()) F1214_11571;
	R9361[40] = (char *(*)()) F1214_11571;
	{long i; for (i = 63; i < 65; i++) R9361[i] = (char *(*)()) F1279_12410;}
	R9361[69] = (char *(*)()) F1214_11571;
	R9361[70] = (char *(*)()) F1287_12454;
	R9361[72] = (char *(*)()) F1289_12498;
	R9361[77] = (char *(*)()) F1214_11571;
	{long i; for (i = 79; i < 81; i++) R9361[i] = (char *(*)()) F1214_11571;}
	R9361[102] = (char *(*)()) F1319_13061;
	R9361[103] = (char *(*)()) F1320_13088;
	R9361[107] = (char *(*)()) F1324_13154;
	R9361[109] = (char *(*)()) F1214_11571;
	R9361[111] = (char *(*)()) F1328_13346;
	R9361[124] = (char *(*)()) F1341_13509;
	R9361[130] = (char *(*)()) F1347_13525;
	R9361[134] = (char *(*)()) F1347_13525;
	R9361[147] = (char *(*)()) F1214_11571;
	R9361[149] = (char *(*)()) F1214_11571;
}

char *(*R9363[150])();
void R9363_init () {
	R9363[0] = (char *(*)()) F1214_11574;
	R9363[40] = (char *(*)()) F1214_11574;
	{long i; for (i = 63; i < 65; i++) R9363[i] = (char *(*)()) F1214_11574;}
	{long i; for (i = 69; i < 71; i++) R9363[i] = (char *(*)()) F1214_11574;}
	R9363[72] = (char *(*)()) F1214_11574;
	R9363[77] = (char *(*)()) F1214_11574;
	{long i; for (i = 79; i < 81; i++) R9363[i] = (char *(*)()) F1214_11574;}
	{long i; for (i = 102; i < 104; i++) R9363[i] = (char *(*)()) F1214_11574;}
	R9363[107] = (char *(*)()) F1214_11574;
	R9363[109] = (char *(*)()) F1326_13259;
	R9363[111] = (char *(*)()) F1214_11574;
	R9363[124] = (char *(*)()) F1214_11574;
	R9363[130] = (char *(*)()) F1214_11574;
	R9363[134] = (char *(*)()) F1214_11574;
	R9363[147] = (char *(*)()) F1364_13863;
	R9363[149] = (char *(*)()) F1366_13946;
}

char *(*R9364[150])();
void R9364_init () {
	R9364[0] = (char *(*)()) F1214_11575;
	R9364[40] = (char *(*)()) F1214_11575;
	{long i; for (i = 63; i < 65; i++) R9364[i] = (char *(*)()) F1214_11575;}
	{long i; for (i = 69; i < 71; i++) R9364[i] = (char *(*)()) F1214_11575;}
	R9364[72] = (char *(*)()) F1214_11575;
	R9364[77] = (char *(*)()) F1214_11575;
	{long i; for (i = 79; i < 81; i++) R9364[i] = (char *(*)()) F1214_11575;}
	{long i; for (i = 102; i < 104; i++) R9364[i] = (char *(*)()) F1214_11575;}
	R9364[107] = (char *(*)()) F1214_11575;
	R9364[109] = (char *(*)()) F1214_11575;
	R9364[111] = (char *(*)()) F1214_11575;
	R9364[124] = (char *(*)()) F1214_11575;
	R9364[130] = (char *(*)()) F1214_11575;
	R9364[134] = (char *(*)()) F1214_11575;
	R9364[147] = (char *(*)()) F1364_13876;
	R9364[149] = (char *(*)()) F1366_13930;
}

char *(*R9366[150])();
void R9366_init () {
	R9366[0] = (char *(*)()) F1214_11577;
	R9366[40] = (char *(*)()) F1214_11577;
	{long i; for (i = 63; i < 65; i++) R9366[i] = (char *(*)()) F1214_11577;}
	{long i; for (i = 69; i < 71; i++) R9366[i] = (char *(*)()) F1214_11577;}
	R9366[72] = (char *(*)()) F1214_11577;
	R9366[77] = (char *(*)()) F1214_11577;
	{long i; for (i = 79; i < 81; i++) R9366[i] = (char *(*)()) F1214_11577;}
	{long i; for (i = 102; i < 104; i++) R9366[i] = (char *(*)()) F1214_11577;}
	R9366[107] = (char *(*)()) F1214_11577;
	R9366[109] = (char *(*)()) F1214_11577;
	R9366[111] = (char *(*)()) F1214_11577;
	R9366[124] = (char *(*)()) F1214_11577;
	R9366[130] = (char *(*)()) F1214_11577;
	R9366[134] = (char *(*)()) F1214_11577;
	R9366[147] = (char *(*)()) F1364_13877;
	R9366[149] = (char *(*)()) F1214_11577;
}

char *(*R9369[150])();
void R9369_init () {
	R9369[0] = (char *(*)()) F1214_11580;
	R9369[40] = (char *(*)()) F1214_11580;
	{long i; for (i = 63; i < 65; i++) R9369[i] = (char *(*)()) F1214_11580;}
	{long i; for (i = 69; i < 71; i++) R9369[i] = (char *(*)()) F1214_11580;}
	R9369[72] = (char *(*)()) F1214_11580;
	R9369[77] = (char *(*)()) F1214_11580;
	{long i; for (i = 79; i < 81; i++) R9369[i] = (char *(*)()) F1214_11580;}
	{long i; for (i = 102; i < 104; i++) R9369[i] = (char *(*)()) F1214_11580;}
	R9369[107] = (char *(*)()) F1214_11580;
	R9369[109] = (char *(*)()) F1214_11580;
	R9369[111] = (char *(*)()) F1214_11580;
	R9369[124] = (char *(*)()) F1214_11580;
	R9369[130] = (char *(*)()) F1214_11580;
	R9369[134] = (char *(*)()) F1214_11580;
	R9369[147] = (char *(*)()) F1364_13878;
	R9369[149] = (char *(*)()) F1214_11580;
}


#ifdef __cplusplus
}
#endif
