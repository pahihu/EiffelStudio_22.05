#include "epoly8.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4959[548])();
void R4959_init () {
	R4959[0] = (char *(*)()) F639_5481;
	R4959[1] = (char *(*)()) F640_5481;
	R4959[2] = (char *(*)()) F641_5481;
	R4959[3] = (char *(*)()) F639_5481;
	R4959[4] = (char *(*)()) F641_5481;
	R4959[5] = (char *(*)()) F640_5481;
	R4959[6] = (char *(*)()) F639_5481;
	R4959[18] = (char *(*)()) F657_5730;
	R4959[19] = (char *(*)()) F658_5730;
	R4959[20] = (char *(*)()) F659_5730;
	R4959[21] = (char *(*)()) F660_5730;
	R4959[22] = (char *(*)()) F661_5730;
	R4959[23] = (char *(*)()) F662_5730;
	R4959[24] = (char *(*)()) F663_5730;
	R4959[25] = (char *(*)()) F664_5730;
	R4959[26] = (char *(*)()) F665_5730;
	R4959[27] = (char *(*)()) F666_5730;
	R4959[28] = (char *(*)()) F667_5730;
	R4959[29] = (char *(*)()) F668_5730;
	R4959[30] = (char *(*)()) F657_5730;
	R4959[31] = (char *(*)()) F658_5730;
	R4959[32] = (char *(*)()) F664_5730;
	R4959[37] = (char *(*)()) F657_5730;
	R4959[38] = (char *(*)()) F658_5730;
	{long i; for (i = 39; i < 43; i++) R4959[i] = (char *(*)()) F657_5730;}
	R4959[47] = (char *(*)()) F657_5730;
	R4959[49] = (char *(*)()) F657_5730;
	R4959[53] = (char *(*)()) F657_5730;
	{long i; for (i = 55; i < 57; i++) R4959[i] = (char *(*)()) F657_5730;}
	{long i; for (i = 58; i < 61; i++) R4959[i] = (char *(*)()) F657_5730;}
	{long i; for (i = 494; i < 497; i++) R4959[i] = (char *(*)()) F1125_10136;}
	R4959[537] = (char *(*)()) F1125_10136;
	R4959[547] = (char *(*)()) F1125_10136;
}

static EIF_TYPE_INDEX Y4959_pgtype0[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype1[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype2[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype3[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype4[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype5[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype6[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype7[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype8[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype9[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype10[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype11[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype12[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype13[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype14[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype15[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype16[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype17[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype18[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype19[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype20[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype21[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype22[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype23[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype24[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype25[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype26[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype27[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype28[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype29[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype30[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype31[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype32[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype33[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype34[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype35[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype36[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype37[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype38[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype39[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype40[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype41[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype42[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype43[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype44[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype45[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype46[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype47[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype48[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype49[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype50[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype51[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype52[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype53[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype54[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype55[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype56[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype57[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype58[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype59[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype60[] = {0xFF01,246,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype61[] = {0xFF01,247,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype62[] = {0xFF01,248,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype63[] = {0xFF01,246,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype64[] = {0xFF01,248,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype65[] = {0xFF01,247,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype66[] = {0xFF01,246,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype67[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype68[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype69[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype70[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype71[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype72[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype73[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype74[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype75[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype76[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype77[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype78[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype79[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype80[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype81[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype82[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype83[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype84[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype85[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype86[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype87[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype88[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype89[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype90[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype91[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype92[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype93[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype94[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype95[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype96[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype97[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype98[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype99[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype100[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype101[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype102[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype103[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype104[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype105[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype106[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype107[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype108[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype109[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype110[] = {0xFF01,245,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype111[] = {0xFF01,245,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype112[] = {0xFF01,245,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype113[] = {0xFF01,245,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype114[] = {0xFF01,245,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype115[] = {0xFF01,245,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype116[] = {0xFF01,245,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype117[] = {0xFF01,245,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype118[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype119[] = {0xFF01,245,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype120[] = {0xFF01,245,0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype121[] = {0xFF01,245,0xFF01,1165,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype122[] = {0xFF01,245,0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype123[] = {0xFF01,245,0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype124[] = {0xFF01,245,0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype125[] = {0xFF01,245,0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype126[] = {0xFF01,245,0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype127[] = {0xFF01,245,0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype128[] = {0xFF01,245,0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype129[] = {0xFF01,245,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype130[] = {0xFF01,245,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4959_pgtype131[] = {0xFF01,245,0xFF01,1169,0xFFFF};
EIF_TYPE_INDEX *Y4959_gen_type [731];
EIF_TYPE_INDEX Y4959 [731];
void Y4959_init (void)
{
	egc_routines_types [4959] = Y4959;
	egc_routines_gen_types [4959] = Y4959_gen_type;
	egc_routines_offset [4959] = 455;
	Y4959_gen_type [0] = Y4959_pgtype0;
	Y4959_gen_type [1] = Y4959_pgtype1;
	Y4959_gen_type [2] = Y4959_pgtype2;
	Y4959_gen_type [3] = Y4959_pgtype3;
	Y4959_gen_type [4] = Y4959_pgtype4;
	Y4959_gen_type [5] = Y4959_pgtype5;
	Y4959_gen_type [6] = Y4959_pgtype6;
	Y4959_gen_type [7] = Y4959_pgtype7;
	Y4959_gen_type [8] = Y4959_pgtype8;
	Y4959_gen_type [9] = Y4959_pgtype9;
	Y4959_gen_type [10] = Y4959_pgtype10;
	Y4959_gen_type [11] = Y4959_pgtype11;
	Y4959_gen_type [135] = Y4959_pgtype12;
	Y4959_gen_type [136] = Y4959_pgtype13;
	Y4959_gen_type [137] = Y4959_pgtype14;
	Y4959_gen_type [138] = Y4959_pgtype15;
	Y4959_gen_type [139] = Y4959_pgtype16;
	Y4959_gen_type [140] = Y4959_pgtype17;
	Y4959_gen_type [141] = Y4959_pgtype18;
	Y4959_gen_type [142] = Y4959_pgtype19;
	Y4959_gen_type [143] = Y4959_pgtype20;
	Y4959_gen_type [144] = Y4959_pgtype21;
	Y4959_gen_type [145] = Y4959_pgtype22;
	Y4959_gen_type [146] = Y4959_pgtype23;
	Y4959_gen_type [147] = Y4959_pgtype24;
	Y4959_gen_type [148] = Y4959_pgtype25;
	Y4959_gen_type [149] = Y4959_pgtype26;
	Y4959_gen_type [150] = Y4959_pgtype27;
	Y4959_gen_type [151] = Y4959_pgtype28;
	Y4959_gen_type [152] = Y4959_pgtype29;
	Y4959_gen_type [153] = Y4959_pgtype30;
	Y4959_gen_type [154] = Y4959_pgtype31;
	Y4959_gen_type [155] = Y4959_pgtype32;
	Y4959_gen_type [156] = Y4959_pgtype33;
	Y4959_gen_type [157] = Y4959_pgtype34;
	Y4959_gen_type [158] = Y4959_pgtype35;
	Y4959_gen_type [159] = Y4959_pgtype36;
	Y4959_gen_type [160] = Y4959_pgtype37;
	Y4959_gen_type [161] = Y4959_pgtype38;
	Y4959_gen_type [162] = Y4959_pgtype39;
	Y4959_gen_type [163] = Y4959_pgtype40;
	Y4959_gen_type [164] = Y4959_pgtype41;
	Y4959_gen_type [165] = Y4959_pgtype42;
	Y4959_gen_type [166] = Y4959_pgtype43;
	Y4959_gen_type [167] = Y4959_pgtype44;
	Y4959_gen_type [168] = Y4959_pgtype45;
	Y4959_gen_type [169] = Y4959_pgtype46;
	Y4959_gen_type [170] = Y4959_pgtype47;
	Y4959_gen_type [171] = Y4959_pgtype48;
	Y4959_gen_type [172] = Y4959_pgtype49;
	Y4959_gen_type [173] = Y4959_pgtype50;
	Y4959_gen_type [174] = Y4959_pgtype51;
	Y4959_gen_type [175] = Y4959_pgtype52;
	Y4959_gen_type [176] = Y4959_pgtype53;
	Y4959_gen_type [177] = Y4959_pgtype54;
	Y4959_gen_type [178] = Y4959_pgtype55;
	Y4959_gen_type [179] = Y4959_pgtype56;
	Y4959_gen_type [180] = Y4959_pgtype57;
	Y4959_gen_type [181] = Y4959_pgtype58;
	Y4959_gen_type [182] = Y4959_pgtype59;
	Y4959_gen_type [183] = Y4959_pgtype60;
	Y4959_gen_type [184] = Y4959_pgtype61;
	Y4959_gen_type [185] = Y4959_pgtype62;
	Y4959_gen_type [186] = Y4959_pgtype63;
	Y4959_gen_type [187] = Y4959_pgtype64;
	Y4959_gen_type [188] = Y4959_pgtype65;
	Y4959_gen_type [189] = Y4959_pgtype66;
	Y4959_gen_type [201] = Y4959_pgtype67;
	Y4959_gen_type [202] = Y4959_pgtype68;
	Y4959_gen_type [203] = Y4959_pgtype69;
	Y4959_gen_type [204] = Y4959_pgtype70;
	Y4959_gen_type [205] = Y4959_pgtype71;
	Y4959_gen_type [206] = Y4959_pgtype72;
	Y4959_gen_type [207] = Y4959_pgtype73;
	Y4959_gen_type [208] = Y4959_pgtype74;
	Y4959_gen_type [209] = Y4959_pgtype75;
	Y4959_gen_type [210] = Y4959_pgtype76;
	Y4959_gen_type [211] = Y4959_pgtype77;
	Y4959_gen_type [212] = Y4959_pgtype78;
	Y4959_gen_type [213] = Y4959_pgtype79;
	Y4959_gen_type [214] = Y4959_pgtype80;
	Y4959_gen_type [215] = Y4959_pgtype81;
	Y4959_gen_type [216] = Y4959_pgtype82;
	Y4959_gen_type [217] = Y4959_pgtype83;
	Y4959_gen_type [218] = Y4959_pgtype84;
	Y4959_gen_type [219] = Y4959_pgtype85;
	Y4959_gen_type [220] = Y4959_pgtype86;
	Y4959_gen_type [221] = Y4959_pgtype87;
	Y4959_gen_type [222] = Y4959_pgtype88;
	Y4959_gen_type [223] = Y4959_pgtype89;
	Y4959_gen_type [224] = Y4959_pgtype90;
	Y4959_gen_type [225] = Y4959_pgtype91;
	Y4959_gen_type [226] = Y4959_pgtype92;
	Y4959_gen_type [227] = Y4959_pgtype93;
	Y4959_gen_type [228] = Y4959_pgtype94;
	Y4959_gen_type [229] = Y4959_pgtype95;
	Y4959_gen_type [230] = Y4959_pgtype96;
	Y4959_gen_type [231] = Y4959_pgtype97;
	Y4959_gen_type [232] = Y4959_pgtype98;
	Y4959_gen_type [233] = Y4959_pgtype99;
	Y4959_gen_type [234] = Y4959_pgtype100;
	Y4959_gen_type [235] = Y4959_pgtype101;
	Y4959_gen_type [236] = Y4959_pgtype102;
	Y4959_gen_type [237] = Y4959_pgtype103;
	Y4959_gen_type [238] = Y4959_pgtype104;
	Y4959_gen_type [239] = Y4959_pgtype105;
	Y4959_gen_type [240] = Y4959_pgtype106;
	Y4959_gen_type [241] = Y4959_pgtype107;
	Y4959_gen_type [242] = Y4959_pgtype108;
	Y4959_gen_type [243] = Y4959_pgtype109;
	Y4959_gen_type [669] = Y4959_pgtype110;
	Y4959_gen_type [673] = Y4959_pgtype111;
	Y4959_gen_type [674] = Y4959_pgtype112;
	Y4959_gen_type [675] = Y4959_pgtype113;
	Y4959_gen_type [676] = Y4959_pgtype114;
	Y4959_gen_type [677] = Y4959_pgtype115;
	Y4959_gen_type [678] = Y4959_pgtype116;
	Y4959_gen_type [679] = Y4959_pgtype117;
	Y4959_gen_type [709] = Y4959_pgtype118;
	Y4959_gen_type [718] = Y4959_pgtype119;
	Y4959_gen_type [719] = Y4959_pgtype120;
	Y4959_gen_type [720] = Y4959_pgtype121;
	Y4959_gen_type [721] = Y4959_pgtype122;
	Y4959_gen_type [722] = Y4959_pgtype123;
	Y4959_gen_type [723] = Y4959_pgtype124;
	Y4959_gen_type [724] = Y4959_pgtype125;
	Y4959_gen_type [725] = Y4959_pgtype126;
	Y4959_gen_type [726] = Y4959_pgtype127;
	Y4959_gen_type [727] = Y4959_pgtype128;
	Y4959_gen_type [728] = Y4959_pgtype129;
	Y4959_gen_type [729] = Y4959_pgtype130;
	Y4959_gen_type [730] = Y4959_pgtype131;
	{long i; for (i = 0; i < 12; i++) Y4959[i] = 244;};
	{long i; for (i = 135; i < 183; i++) Y4959[i] = 244;};
	Y4959[183] = 246;
	Y4959[184] = 247;
	Y4959[185] = 248;
	Y4959[186] = 246;
	Y4959[187] = 248;
	Y4959[188] = 247;
	Y4959[189] = 246;
	{long i; for (i = 201; i < 244; i++) Y4959[i] = 250;};
	Y4959[669] = 245;
	{long i; for (i = 673; i < 680; i++) Y4959[i] = 245;};
	Y4959[709] = 250;
	{long i; for (i = 718; i < 731; i++) Y4959[i] = 245;};
}

char *(*R4961[548])();
void R4961_init () {
	R4961[0] = (char *(*)()) F639_5500;
	R4961[1] = (char *(*)()) F640_5500;
	R4961[2] = (char *(*)()) F641_5500;
	R4961[3] = (char *(*)()) F639_5500;
	R4961[4] = (char *(*)()) F641_5500;
	R4961[5] = (char *(*)()) F640_5500;
	R4961[6] = (char *(*)()) F639_5500;
	R4961[18] = (char *(*)()) F657_5755;
	R4961[19] = (char *(*)()) F658_5755;
	R4961[20] = (char *(*)()) F659_5755;
	R4961[21] = (char *(*)()) F660_5755;
	R4961[22] = (char *(*)()) F661_5755;
	R4961[23] = (char *(*)()) F662_5755;
	R4961[24] = (char *(*)()) F663_5755;
	R4961[25] = (char *(*)()) F664_5755;
	R4961[26] = (char *(*)()) F665_5755;
	R4961[27] = (char *(*)()) F666_5755;
	R4961[28] = (char *(*)()) F667_5755;
	R4961[29] = (char *(*)()) F668_5755;
	R4961[30] = (char *(*)()) F657_5755;
	R4961[31] = (char *(*)()) F658_5755;
	R4961[32] = (char *(*)()) F664_5755;
	R4961[37] = (char *(*)()) F657_5755;
	R4961[38] = (char *(*)()) F658_5755;
	{long i; for (i = 39; i < 43; i++) R4961[i] = (char *(*)()) F657_5755;}
	R4961[47] = (char *(*)()) F657_5755;
	R4961[49] = (char *(*)()) F657_5755;
	R4961[53] = (char *(*)()) F657_5755;
	{long i; for (i = 55; i < 57; i++) R4961[i] = (char *(*)()) F657_5755;}
	{long i; for (i = 58; i < 61; i++) R4961[i] = (char *(*)()) F657_5755;}
	{long i; for (i = 494; i < 497; i++) R4961[i] = (char *(*)()) F1125_10148;}
	R4961[537] = (char *(*)()) F1125_10148;
	R4961[547] = (char *(*)()) F1125_10148;
}

char *(*R4963[6])();
void R4963_init () {
	R4963[0] = (char *(*)()) F722_6094;
	R4963[5] = (char *(*)()) F727_6159;
}

char *(*R4965[798])();
void R4965_init () {
	R4965[0] = (char *(*)()) F576_5308;
	R4965[2] = (char *(*)()) F578_5357;
	R4965[3] = (char *(*)()) F579_5357;
	R4965[4] = (char *(*)()) F580_5357;
	R4965[5] = (char *(*)()) F581_5357;
	R4965[6] = (char *(*)()) F582_5357;
	R4965[7] = (char *(*)()) F583_5357;
	R4965[8] = (char *(*)()) F584_5357;
	R4965[9] = (char *(*)()) F585_5357;
	R4965[10] = (char *(*)()) F586_5357;
	R4965[11] = (char *(*)()) F587_5357;
	R4965[12] = (char *(*)()) F588_5357;
	R4965[13] = (char *(*)()) F589_5357;
	R4965[63] = (char *(*)()) F639_5484;
	R4965[64] = (char *(*)()) F640_5484;
	R4965[65] = (char *(*)()) F641_5484;
	R4965[66] = (char *(*)()) F639_5484;
	R4965[67] = (char *(*)()) F641_5484;
	R4965[68] = (char *(*)()) F640_5484;
	R4965[69] = (char *(*)()) F639_5484;
	R4965[72] = (char *(*)()) F648_5606;
	R4965[73] = (char *(*)()) F649_5606;
	R4965[74] = (char *(*)()) F650_5606;
	R4965[75] = (char *(*)()) F651_5606;
	R4965[76] = (char *(*)()) F652_5606;
	R4965[77] = (char *(*)()) F653_5606;
	R4965[78] = (char *(*)()) F648_5606;
	R4965[79] = (char *(*)()) F649_5606;
	R4965[80] = (char *(*)()) F648_5606;
	R4965[81] = (char *(*)()) F657_5740;
	R4965[82] = (char *(*)()) F658_5740;
	R4965[83] = (char *(*)()) F659_5740;
	R4965[84] = (char *(*)()) F660_5740;
	R4965[85] = (char *(*)()) F661_5740;
	R4965[86] = (char *(*)()) F662_5740;
	R4965[87] = (char *(*)()) F663_5740;
	R4965[88] = (char *(*)()) F664_5740;
	R4965[89] = (char *(*)()) F665_5740;
	R4965[90] = (char *(*)()) F666_5740;
	R4965[91] = (char *(*)()) F667_5740;
	R4965[92] = (char *(*)()) F668_5740;
	R4965[93] = (char *(*)()) F657_5740;
	R4965[94] = (char *(*)()) F658_5740;
	R4965[95] = (char *(*)()) F664_5740;
	R4965[100] = (char *(*)()) F657_5740;
	R4965[101] = (char *(*)()) F658_5740;
	{long i; for (i = 102; i < 106; i++) R4965[i] = (char *(*)()) F657_5740;}
	R4965[110] = (char *(*)()) F657_5740;
	R4965[112] = (char *(*)()) F657_5740;
	R4965[116] = (char *(*)()) F657_5740;
	{long i; for (i = 118; i < 120; i++) R4965[i] = (char *(*)()) F657_5740;}
	{long i; for (i = 121; i < 124; i++) R4965[i] = (char *(*)()) F657_5740;}
	{long i; for (i = 344; i < 346; i++) R4965[i] = (char *(*)()) F919_7112;}
	R4965[475] = (char *(*)()) F1049_9136;
	R4965[478] = (char *(*)()) F1052_9304;
	{long i; for (i = 557; i < 560; i++) R4965[i] = (char *(*)()) F1125_10141;}
	R4965[600] = (char *(*)()) F1125_10141;
	R4965[610] = (char *(*)()) F1125_10141;
	R4965[797] = (char *(*)()) F1373_14085;
}

char *(*R4966[479])();
void R4966_init () {
	R4966[0] = (char *(*)()) F576_5307;
	R4966[2] = (char *(*)()) F578_5358;
	R4966[3] = (char *(*)()) F579_5358;
	R4966[4] = (char *(*)()) F580_5358;
	R4966[5] = (char *(*)()) F581_5358;
	R4966[6] = (char *(*)()) F582_5358;
	R4966[7] = (char *(*)()) F583_5358;
	R4966[8] = (char *(*)()) F584_5358;
	R4966[9] = (char *(*)()) F585_5358;
	R4966[10] = (char *(*)()) F586_5358;
	R4966[11] = (char *(*)()) F587_5358;
	R4966[12] = (char *(*)()) F588_5358;
	R4966[13] = (char *(*)()) F589_5358;
	R4966[81] = (char *(*)()) F657_5741;
	R4966[82] = (char *(*)()) F658_5741;
	R4966[83] = (char *(*)()) F659_5741;
	R4966[84] = (char *(*)()) F660_5741;
	R4966[85] = (char *(*)()) F661_5741;
	R4966[86] = (char *(*)()) F662_5741;
	R4966[87] = (char *(*)()) F663_5741;
	R4966[88] = (char *(*)()) F664_5741;
	R4966[89] = (char *(*)()) F665_5741;
	R4966[90] = (char *(*)()) F666_5741;
	R4966[91] = (char *(*)()) F667_5741;
	R4966[92] = (char *(*)()) F668_5741;
	R4966[93] = (char *(*)()) F657_5741;
	R4966[94] = (char *(*)()) F658_5741;
	R4966[95] = (char *(*)()) F664_5741;
	R4966[100] = (char *(*)()) F657_5741;
	R4966[101] = (char *(*)()) F658_5741;
	{long i; for (i = 102; i < 106; i++) R4966[i] = (char *(*)()) F657_5741;}
	R4966[110] = (char *(*)()) F657_5741;
	R4966[112] = (char *(*)()) F657_5741;
	R4966[116] = (char *(*)()) F657_5741;
	{long i; for (i = 118; i < 120; i++) R4966[i] = (char *(*)()) F657_5741;}
	{long i; for (i = 121; i < 124; i++) R4966[i] = (char *(*)()) F657_5741;}
	R4966[475] = (char *(*)()) F1049_9135;
	R4966[478] = (char *(*)()) F1052_9303;
}

char *(*R4970[479])();
void R4970_init () {
	R4970[0] = (char *(*)()) F508_5235;
	R4970[2] = (char *(*)()) F507_5235;
	R4970[3] = (char *(*)()) F508_5235;
	R4970[4] = (char *(*)()) F509_5235;
	R4970[5] = (char *(*)()) F510_5235;
	R4970[6] = (char *(*)()) F511_5235;
	R4970[7] = (char *(*)()) F512_5235;
	R4970[8] = (char *(*)()) F513_5235;
	R4970[9] = (char *(*)()) F514_5235;
	R4970[10] = (char *(*)()) F515_5235;
	R4970[11] = (char *(*)()) F516_5235;
	R4970[12] = (char *(*)()) F517_5235;
	R4970[13] = (char *(*)()) F518_5235;
	R4970[81] = (char *(*)()) F507_5235;
	R4970[82] = (char *(*)()) F508_5235;
	R4970[83] = (char *(*)()) F509_5235;
	R4970[84] = (char *(*)()) F510_5235;
	R4970[85] = (char *(*)()) F511_5235;
	R4970[86] = (char *(*)()) F512_5235;
	R4970[87] = (char *(*)()) F513_5235;
	R4970[88] = (char *(*)()) F514_5235;
	R4970[89] = (char *(*)()) F515_5235;
	R4970[90] = (char *(*)()) F516_5235;
	R4970[91] = (char *(*)()) F517_5235;
	R4970[92] = (char *(*)()) F518_5235;
	R4970[93] = (char *(*)()) F507_5235;
	R4970[94] = (char *(*)()) F508_5235;
	R4970[95] = (char *(*)()) F514_5235;
	R4970[100] = (char *(*)()) F507_5235;
	R4970[101] = (char *(*)()) F508_5235;
	{long i; for (i = 102; i < 106; i++) R4970[i] = (char *(*)()) F507_5235;}
	R4970[110] = (char *(*)()) F507_5235;
	R4970[112] = (char *(*)()) F507_5235;
	R4970[116] = (char *(*)()) F507_5235;
	{long i; for (i = 118; i < 120; i++) R4970[i] = (char *(*)()) F507_5235;}
	{long i; for (i = 121; i < 124; i++) R4970[i] = (char *(*)()) F507_5235;}
	R4970[475] = (char *(*)()) F515_5235;
	R4970[478] = (char *(*)()) F513_5235;
}

char *(*R4972[479])();
void R4972_init () {
	R4972[0] = (char *(*)()) F576_5318;
	R4972[2] = (char *(*)()) F578_5388;
	R4972[3] = (char *(*)()) F579_5388;
	R4972[4] = (char *(*)()) F580_5388;
	R4972[5] = (char *(*)()) F581_5388;
	R4972[6] = (char *(*)()) F582_5388;
	R4972[7] = (char *(*)()) F583_5388;
	R4972[8] = (char *(*)()) F584_5388;
	R4972[9] = (char *(*)()) F585_5388;
	R4972[10] = (char *(*)()) F586_5388;
	R4972[11] = (char *(*)()) F587_5388;
	R4972[12] = (char *(*)()) F588_5388;
	R4972[13] = (char *(*)()) F589_5388;
	R4972[81] = (char *(*)()) F657_5767;
	R4972[82] = (char *(*)()) F658_5767;
	R4972[83] = (char *(*)()) F659_5767;
	R4972[84] = (char *(*)()) F660_5767;
	R4972[85] = (char *(*)()) F661_5767;
	R4972[86] = (char *(*)()) F662_5767;
	R4972[87] = (char *(*)()) F663_5767;
	R4972[88] = (char *(*)()) F664_5767;
	R4972[89] = (char *(*)()) F665_5767;
	R4972[90] = (char *(*)()) F666_5767;
	R4972[91] = (char *(*)()) F667_5767;
	R4972[92] = (char *(*)()) F668_5767;
	R4972[93] = (char *(*)()) F657_5767;
	R4972[94] = (char *(*)()) F658_5767;
	R4972[95] = (char *(*)()) F664_5767;
	R4972[100] = (char *(*)()) F657_5767;
	R4972[101] = (char *(*)()) F658_5767;
	{long i; for (i = 102; i < 106; i++) R4972[i] = (char *(*)()) F657_5767;}
	R4972[110] = (char *(*)()) F657_5767;
	R4972[112] = (char *(*)()) F657_5767;
	R4972[116] = (char *(*)()) F657_5767;
	{long i; for (i = 118; i < 120; i++) R4972[i] = (char *(*)()) F657_5767;}
	{long i; for (i = 121; i < 124; i++) R4972[i] = (char *(*)()) F657_5767;}
	R4972[475] = (char *(*)()) F1051_9263;
	R4972[478] = (char *(*)()) F1054_9428;
}

char *(*R4974[735])();
void R4974_init () {
	R4974[0] = (char *(*)()) F519_5242;
	R4974[1] = (char *(*)()) F520_5242_4974_4;
	R4974[2] = (char *(*)()) F526_5242_4974_4;
	R4974[3] = (char *(*)()) F642_5523;
	R4974[4] = (char *(*)()) F643_5523_4974_4;
	R4974[5] = (char *(*)()) F644_5523_4974_4;
	R4974[6] = (char *(*)()) F645_5540;
	R4974[18] = (char *(*)()) F657_5759;
	R4974[19] = (char *(*)()) F658_5759_4974_4;
	R4974[20] = (char *(*)()) F659_5759_4974_4;
	R4974[21] = (char *(*)()) F660_5759_4974_4;
	R4974[22] = (char *(*)()) F661_5759_4974_4;
	R4974[23] = (char *(*)()) F662_5759_4974_4;
	R4974[24] = (char *(*)()) F663_5759_4974_4;
	R4974[25] = (char *(*)()) F664_5759_4974_4;
	R4974[26] = (char *(*)()) F665_5759_4974_4;
	R4974[27] = (char *(*)()) F666_5759_4974_4;
	R4974[28] = (char *(*)()) F667_5759_4974_4;
	R4974[29] = (char *(*)()) F668_5759_4974_4;
	R4974[30] = (char *(*)()) F657_5759;
	R4974[31] = (char *(*)()) F658_5759_4974_4;
	R4974[32] = (char *(*)()) F664_5759_4974_4;
	R4974[37] = (char *(*)()) F657_5759;
	R4974[38] = (char *(*)()) F658_5759_4974_4;
	{long i; for (i = 39; i < 43; i++) R4974[i] = (char *(*)()) F657_5759;}
	R4974[47] = (char *(*)()) F657_5759;
	R4974[49] = (char *(*)()) F657_5759;
	R4974[53] = (char *(*)()) F657_5759;
	{long i; for (i = 55; i < 57; i++) R4974[i] = (char *(*)()) F657_5759;}
	{long i; for (i = 58; i < 61; i++) R4974[i] = (char *(*)()) F657_5759;}
	{long i; for (i = 281; i < 283; i++) R4974[i] = (char *(*)()) F525_5242_4974_4;}
	{long i; for (i = 494; i < 497; i++) R4974[i] = (char *(*)()) F519_5242;}
	R4974[537] = (char *(*)()) F519_5242;
	R4974[547] = (char *(*)()) F519_5242;
	R4974[734] = (char *(*)()) F525_5242_4974_4;
}
static void F520_5242_4974_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F520_5242(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F526_5242_4974_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F526_5242(Current, *(EIF_BOOLEAN *)arg1);
}
static void F643_5523_4974_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F643_5523(Current, *(EIF_BOOLEAN *)arg1);
}
static void F644_5523_4974_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F644_5523(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F658_5759_4974_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5759(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F659_5759_4974_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5759(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F660_5759_4974_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F660_5759(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F661_5759_4974_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_5759(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F662_5759_4974_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F662_5759(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F663_5759_4974_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_5759(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F664_5759_4974_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5759(Current, *(EIF_BOOLEAN *)arg1);
}
static void F665_5759_4974_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5759(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F666_5759_4974_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5759(Current, *(EIF_REAL_32 *)arg1);
}
static void F667_5759_4974_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5759(Current, *(EIF_POINTER *)arg1);
}
static void F668_5759_4974_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5759(Current, *(EIF_REAL_64 *)arg1);
}
static void F525_5242_4974_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F525_5242(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4988[611])();
void R4988_init () {
	R4988[0] = (char *(*)()) F576_5302_4988_20;
	R4988[2] = (char *(*)()) F578_5350;
	R4988[3] = (char *(*)()) F579_5350_4988_20;
	R4988[4] = (char *(*)()) F580_5350_4988_20;
	R4988[5] = (char *(*)()) F581_5350_4988_20;
	R4988[6] = (char *(*)()) F582_5350_4988_20;
	R4988[7] = (char *(*)()) F583_5350_4988_20;
	R4988[8] = (char *(*)()) F584_5350_4988_20;
	R4988[9] = (char *(*)()) F585_5350_4988_20;
	R4988[10] = (char *(*)()) F586_5350_4988_20;
	R4988[11] = (char *(*)()) F587_5350_4988_20;
	R4988[12] = (char *(*)()) F588_5350_4988_20;
	R4988[13] = (char *(*)()) F589_5350_4988_20;
	R4988[63] = (char *(*)()) F591_5429;
	R4988[64] = (char *(*)()) F592_5429_4988_20;
	R4988[65] = (char *(*)()) F598_5429_4988_20;
	R4988[66] = (char *(*)()) F591_5429;
	R4988[67] = (char *(*)()) F598_5429_4988_20;
	R4988[68] = (char *(*)()) F592_5429_4988_20;
	R4988[69] = (char *(*)()) F591_5429;
	R4988[72] = (char *(*)()) F648_5604;
	R4988[73] = (char *(*)()) F649_5604_4988_20;
	R4988[74] = (char *(*)()) F650_5604;
	R4988[75] = (char *(*)()) F651_5604_4988_20;
	R4988[76] = (char *(*)()) F652_5604_4988_20;
	R4988[77] = (char *(*)()) F653_5604_4988_20;
	R4988[78] = (char *(*)()) F648_5604;
	R4988[79] = (char *(*)()) F649_5604_4988_20;
	R4988[80] = (char *(*)()) F648_5604;
	R4988[81] = (char *(*)()) F657_5725;
	R4988[82] = (char *(*)()) F658_5725_4988_20;
	R4988[83] = (char *(*)()) F659_5725_4988_20;
	R4988[84] = (char *(*)()) F660_5725_4988_20;
	R4988[85] = (char *(*)()) F661_5725_4988_20;
	R4988[86] = (char *(*)()) F662_5725_4988_20;
	R4988[87] = (char *(*)()) F663_5725_4988_20;
	R4988[88] = (char *(*)()) F664_5725_4988_20;
	R4988[89] = (char *(*)()) F665_5725_4988_20;
	R4988[90] = (char *(*)()) F666_5725_4988_20;
	R4988[91] = (char *(*)()) F667_5725_4988_20;
	R4988[92] = (char *(*)()) F668_5725_4988_20;
	R4988[93] = (char *(*)()) F657_5725;
	R4988[94] = (char *(*)()) F658_5725_4988_20;
	R4988[95] = (char *(*)()) F664_5725_4988_20;
	R4988[100] = (char *(*)()) F657_5725;
	R4988[101] = (char *(*)()) F658_5725_4988_20;
	{long i; for (i = 102; i < 106; i++) R4988[i] = (char *(*)()) F657_5725;}
	R4988[110] = (char *(*)()) F657_5725;
	R4988[112] = (char *(*)()) F657_5725;
	R4988[116] = (char *(*)()) F657_5725;
	{long i; for (i = 118; i < 120; i++) R4988[i] = (char *(*)()) F657_5725;}
	{long i; for (i = 121; i < 124; i++) R4988[i] = (char *(*)()) F657_5725;}
	R4988[259] = (char *(*)()) F835_6403;
	R4988[260] = (char *(*)()) F836_6403_4988_20;
	R4988[261] = (char *(*)()) F837_6403_4988_20;
	R4988[262] = (char *(*)()) F838_6403_4988_20;
	R4988[263] = (char *(*)()) F839_6403_4988_20;
	R4988[264] = (char *(*)()) F840_6403_4988_20;
	R4988[265] = (char *(*)()) F841_6403_4988_20;
	R4988[266] = (char *(*)()) F842_6403_4988_20;
	R4988[267] = (char *(*)()) F843_6403_4988_20;
	R4988[268] = (char *(*)()) F844_6403_4988_20;
	R4988[269] = (char *(*)()) F845_6403_4988_20;
	R4988[270] = (char *(*)()) F846_6403_4988_20;
	R4988[391] = (char *(*)()) F967_7752;
	R4988[474] = (char *(*)()) F1050_9174_4988_20;
	R4988[475] = (char *(*)()) F1051_9197_4988_20;
	R4988[477] = (char *(*)()) F1053_9339_4988_20;
	R4988[478] = (char *(*)()) F1054_9361_4988_20;
	{long i; for (i = 557; i < 560; i++) R4988[i] = (char *(*)()) F1125_10137;}
	R4988[600] = (char *(*)()) F1125_10137;
	R4988[610] = (char *(*)()) F1125_10137;
}
static EIF_REFERENCE F576_5302_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F576_5302(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F579_5350_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F579_5350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_5350_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F580_5350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F581_5350_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F581_5350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F582_5350_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F582_5350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F583_5350_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F583_5350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F584_5350_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F584_5350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F585_5350_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F585_5350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F586_5350_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F586_5350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_5350_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F587_5350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_5350_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F588_5350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_5350_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F589_5350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F592_5429_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F592_5429(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F598_5429_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F598_5429(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F649_5604_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F649_5604(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F651_5604_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5604(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5604_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F652_5604(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F653_5604_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F653_5604(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_5725_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5725(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5725_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F659_5725(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5725_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F660_5725(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_5725_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F661_5725(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_5725_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F662_5725(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_5725_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F663_5725(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5725_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F664_5725(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5725_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F665_5725(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5725_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F666_5725(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5725_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F667_5725(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5725_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F668_5725(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F836_6403_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F836_6403(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F837_6403_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F837_6403(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F838_6403_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F838_6403(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F839_6403_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F839_6403(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F840_6403_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F840_6403(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F841_6403_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F841_6403(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F842_6403_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F842_6403(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F843_6403_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F843_6403(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F844_6403_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F844_6403(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F845_6403_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F845_6403(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F846_6403_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F846_6403(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1050_9174_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1050_9174(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1051_9197_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1051_9197(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1053_9339_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1053_9339(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1054_9361_4988_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1054_9361(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4989[611])();
void R4989_init () {
	R4989[0] = (char *(*)()) F576_5299;
	R4989[2] = (char *(*)()) F578_5355;
	R4989[3] = (char *(*)()) F579_5355;
	R4989[4] = (char *(*)()) F580_5355;
	R4989[5] = (char *(*)()) F581_5355;
	R4989[6] = (char *(*)()) F582_5355;
	R4989[7] = (char *(*)()) F583_5355;
	R4989[8] = (char *(*)()) F584_5355;
	R4989[9] = (char *(*)()) F585_5355;
	R4989[10] = (char *(*)()) F586_5355;
	R4989[11] = (char *(*)()) F587_5355;
	R4989[12] = (char *(*)()) F588_5355;
	R4989[13] = (char *(*)()) F589_5355;
	R4989[63] = (char *(*)()) F591_5432;
	R4989[64] = (char *(*)()) F592_5432;
	R4989[65] = (char *(*)()) F598_5432;
	R4989[66] = (char *(*)()) F591_5432;
	R4989[67] = (char *(*)()) F598_5432;
	R4989[68] = (char *(*)()) F592_5432;
	R4989[69] = (char *(*)()) F591_5432;
	R4989[72] = (char *(*)()) F648_5609;
	R4989[73] = (char *(*)()) F649_5609;
	R4989[74] = (char *(*)()) F650_5609;
	R4989[75] = (char *(*)()) F651_5609;
	R4989[76] = (char *(*)()) F652_5609;
	R4989[77] = (char *(*)()) F653_5609;
	R4989[78] = (char *(*)()) F648_5609;
	R4989[79] = (char *(*)()) F649_5609;
	R4989[80] = (char *(*)()) F648_5609;
	R4989[81] = (char *(*)()) F591_5432;
	R4989[82] = (char *(*)()) F592_5432;
	R4989[83] = (char *(*)()) F593_5432;
	R4989[84] = (char *(*)()) F594_5432;
	R4989[85] = (char *(*)()) F595_5432;
	R4989[86] = (char *(*)()) F596_5432;
	R4989[87] = (char *(*)()) F597_5432;
	R4989[88] = (char *(*)()) F598_5432;
	R4989[89] = (char *(*)()) F599_5432;
	R4989[90] = (char *(*)()) F600_5432;
	R4989[91] = (char *(*)()) F601_5432;
	R4989[92] = (char *(*)()) F602_5432;
	R4989[93] = (char *(*)()) F591_5432;
	R4989[94] = (char *(*)()) F592_5432;
	R4989[95] = (char *(*)()) F598_5432;
	R4989[100] = (char *(*)()) F591_5432;
	R4989[101] = (char *(*)()) F592_5432;
	{long i; for (i = 102; i < 106; i++) R4989[i] = (char *(*)()) F591_5432;}
	R4989[110] = (char *(*)()) F591_5432;
	R4989[112] = (char *(*)()) F591_5432;
	R4989[116] = (char *(*)()) F591_5432;
	{long i; for (i = 118; i < 120; i++) R4989[i] = (char *(*)()) F591_5432;}
	{long i; for (i = 121; i < 124; i++) R4989[i] = (char *(*)()) F591_5432;}
	R4989[259] = (char *(*)()) F835_6411;
	R4989[260] = (char *(*)()) F836_6411;
	R4989[261] = (char *(*)()) F837_6411;
	R4989[262] = (char *(*)()) F838_6411;
	R4989[263] = (char *(*)()) F839_6411;
	R4989[264] = (char *(*)()) F840_6411;
	R4989[265] = (char *(*)()) F841_6411;
	R4989[266] = (char *(*)()) F842_6411;
	R4989[267] = (char *(*)()) F843_6411;
	R4989[268] = (char *(*)()) F844_6411;
	R4989[269] = (char *(*)()) F845_6411;
	R4989[270] = (char *(*)()) F846_6411;
	R4989[391] = (char *(*)()) F967_7782;
	{long i; for (i = 474; i < 476; i++) R4989[i] = (char *(*)()) F1049_9138;}
	{long i; for (i = 477; i < 479; i++) R4989[i] = (char *(*)()) F1052_9306;}
	{long i; for (i = 557; i < 560; i++) R4989[i] = (char *(*)()) F591_5432;}
	R4989[600] = (char *(*)()) F591_5432;
	R4989[610] = (char *(*)()) F591_5432;
}

EIF_TYPE_INDEX *Y4989_gen_type [635];
EIF_TYPE_INDEX Y4989 [635];
void Y4989_init (void)
{
	egc_routines_types [4989] = Y4989;
	egc_routines_gen_types [4989] = Y4989_gen_type;
	egc_routines_offset [4989] = 551;
	{long i; for (i = 0; i < 94; i++) Y4989[i] = 984;};
	{long i; for (i = 96; i < 148; i++) Y4989[i] = 984;};
	{long i; for (i = 283; i < 295; i++) Y4989[i] = 984;};
	Y4989[415] = 984;
	{long i; for (i = 497; i < 504; i++) Y4989[i] = 984;};
	Y4989[573] = 984;
	{long i; for (i = 577; i < 584; i++) Y4989[i] = 984;};
	Y4989[613] = 984;
	{long i; for (i = 622; i < 635; i++) Y4989[i] = 984;};
}

char *(*R4990[611])();
void R4990_init () {
	R4990[0] = (char *(*)()) F576_5301;
	R4990[2] = (char *(*)()) F578_5356;
	R4990[3] = (char *(*)()) F579_5356;
	R4990[4] = (char *(*)()) F580_5356;
	R4990[5] = (char *(*)()) F581_5356;
	R4990[6] = (char *(*)()) F582_5356;
	R4990[7] = (char *(*)()) F583_5356;
	R4990[8] = (char *(*)()) F584_5356;
	R4990[9] = (char *(*)()) F585_5356;
	R4990[10] = (char *(*)()) F586_5356;
	R4990[11] = (char *(*)()) F587_5356;
	R4990[12] = (char *(*)()) F588_5356;
	R4990[13] = (char *(*)()) F589_5356;
	R4990[63] = (char *(*)()) F639_5484;
	R4990[64] = (char *(*)()) F640_5484;
	R4990[65] = (char *(*)()) F641_5484;
	R4990[66] = (char *(*)()) F639_5484;
	R4990[67] = (char *(*)()) F641_5484;
	R4990[68] = (char *(*)()) F640_5484;
	R4990[69] = (char *(*)()) F639_5484;
	R4990[72] = (char *(*)()) F648_5610;
	R4990[73] = (char *(*)()) F649_5610;
	R4990[74] = (char *(*)()) F650_5610;
	R4990[75] = (char *(*)()) F651_5610;
	R4990[76] = (char *(*)()) F652_5610;
	R4990[77] = (char *(*)()) F653_5610;
	R4990[78] = (char *(*)()) F648_5610;
	R4990[79] = (char *(*)()) F649_5610;
	R4990[80] = (char *(*)()) F648_5610;
	R4990[81] = (char *(*)()) F657_5740;
	R4990[82] = (char *(*)()) F658_5740;
	R4990[83] = (char *(*)()) F659_5740;
	R4990[84] = (char *(*)()) F660_5740;
	R4990[85] = (char *(*)()) F661_5740;
	R4990[86] = (char *(*)()) F662_5740;
	R4990[87] = (char *(*)()) F663_5740;
	R4990[88] = (char *(*)()) F664_5740;
	R4990[89] = (char *(*)()) F665_5740;
	R4990[90] = (char *(*)()) F666_5740;
	R4990[91] = (char *(*)()) F667_5740;
	R4990[92] = (char *(*)()) F668_5740;
	R4990[93] = (char *(*)()) F657_5740;
	R4990[94] = (char *(*)()) F658_5740;
	R4990[95] = (char *(*)()) F664_5740;
	R4990[100] = (char *(*)()) F657_5740;
	R4990[101] = (char *(*)()) F658_5740;
	{long i; for (i = 102; i < 106; i++) R4990[i] = (char *(*)()) F657_5740;}
	R4990[110] = (char *(*)()) F657_5740;
	R4990[112] = (char *(*)()) F657_5740;
	R4990[116] = (char *(*)()) F657_5740;
	{long i; for (i = 118; i < 120; i++) R4990[i] = (char *(*)()) F657_5740;}
	{long i; for (i = 121; i < 124; i++) R4990[i] = (char *(*)()) F657_5740;}
	R4990[259] = (char *(*)()) F835_6412;
	R4990[260] = (char *(*)()) F836_6412;
	R4990[261] = (char *(*)()) F837_6412;
	R4990[262] = (char *(*)()) F838_6412;
	R4990[263] = (char *(*)()) F839_6412;
	R4990[264] = (char *(*)()) F840_6412;
	R4990[265] = (char *(*)()) F841_6412;
	R4990[266] = (char *(*)()) F842_6412;
	R4990[267] = (char *(*)()) F843_6412;
	R4990[268] = (char *(*)()) F844_6412;
	R4990[269] = (char *(*)()) F845_6412;
	R4990[270] = (char *(*)()) F846_6412;
	R4990[391] = (char *(*)()) F967_7781;
	{long i; for (i = 474; i < 476; i++) R4990[i] = (char *(*)()) F1049_9136;}
	{long i; for (i = 477; i < 479; i++) R4990[i] = (char *(*)()) F1052_9304;}
	{long i; for (i = 557; i < 560; i++) R4990[i] = (char *(*)()) F1125_10141;}
	R4990[600] = (char *(*)()) F1125_10141;
	R4990[610] = (char *(*)()) F1125_10141;
}

char *(*R4992[611])();
void R4992_init () {
	R4992[0] = (char *(*)()) F576_5305;
	R4992[2] = (char *(*)()) F578_5365;
	R4992[3] = (char *(*)()) F579_5365;
	R4992[4] = (char *(*)()) F580_5365;
	R4992[5] = (char *(*)()) F581_5365;
	R4992[6] = (char *(*)()) F582_5365;
	R4992[7] = (char *(*)()) F583_5365;
	R4992[8] = (char *(*)()) F584_5365;
	R4992[9] = (char *(*)()) F585_5365;
	R4992[10] = (char *(*)()) F586_5365;
	R4992[11] = (char *(*)()) F587_5365;
	R4992[12] = (char *(*)()) F588_5365;
	R4992[13] = (char *(*)()) F589_5365;
	R4992[63] = (char *(*)()) F591_5437;
	R4992[64] = (char *(*)()) F592_5437;
	R4992[65] = (char *(*)()) F598_5437;
	R4992[66] = (char *(*)()) F591_5437;
	R4992[67] = (char *(*)()) F598_5437;
	R4992[68] = (char *(*)()) F592_5437;
	R4992[69] = (char *(*)()) F591_5437;
	R4992[72] = (char *(*)()) F648_5626;
	R4992[73] = (char *(*)()) F649_5626;
	R4992[74] = (char *(*)()) F650_5626;
	R4992[75] = (char *(*)()) F651_5626;
	R4992[76] = (char *(*)()) F652_5626;
	R4992[77] = (char *(*)()) F653_5626;
	R4992[78] = (char *(*)()) F648_5626;
	R4992[79] = (char *(*)()) F649_5626;
	R4992[80] = (char *(*)()) F648_5626;
	R4992[81] = (char *(*)()) F657_5746;
	R4992[82] = (char *(*)()) F658_5746;
	R4992[83] = (char *(*)()) F659_5746;
	R4992[84] = (char *(*)()) F660_5746;
	R4992[85] = (char *(*)()) F661_5746;
	R4992[86] = (char *(*)()) F662_5746;
	R4992[87] = (char *(*)()) F663_5746;
	R4992[88] = (char *(*)()) F664_5746;
	R4992[89] = (char *(*)()) F665_5746;
	R4992[90] = (char *(*)()) F666_5746;
	R4992[91] = (char *(*)()) F667_5746;
	R4992[92] = (char *(*)()) F668_5746;
	R4992[93] = (char *(*)()) F657_5746;
	R4992[94] = (char *(*)()) F658_5746;
	R4992[95] = (char *(*)()) F664_5746;
	R4992[100] = (char *(*)()) F657_5746;
	R4992[101] = (char *(*)()) F658_5746;
	{long i; for (i = 102; i < 106; i++) R4992[i] = (char *(*)()) F657_5746;}
	R4992[110] = (char *(*)()) F657_5746;
	R4992[112] = (char *(*)()) F657_5746;
	R4992[116] = (char *(*)()) F657_5746;
	{long i; for (i = 118; i < 120; i++) R4992[i] = (char *(*)()) F657_5746;}
	{long i; for (i = 121; i < 124; i++) R4992[i] = (char *(*)()) F657_5746;}
	R4992[259] = (char *(*)()) F835_6417;
	R4992[260] = (char *(*)()) F836_6417;
	R4992[261] = (char *(*)()) F837_6417;
	R4992[262] = (char *(*)()) F838_6417;
	R4992[263] = (char *(*)()) F839_6417;
	R4992[264] = (char *(*)()) F840_6417;
	R4992[265] = (char *(*)()) F841_6417;
	R4992[266] = (char *(*)()) F842_6417;
	R4992[267] = (char *(*)()) F843_6417;
	R4992[268] = (char *(*)()) F844_6417;
	R4992[269] = (char *(*)()) F845_6417;
	R4992[270] = (char *(*)()) F846_6417;
	R4992[391] = (char *(*)()) F967_7779;
	{long i; for (i = 474; i < 476; i++) R4992[i] = (char *(*)()) F1046_8997;}
	{long i; for (i = 477; i < 479; i++) R4992[i] = (char *(*)()) F1046_8997;}
	{long i; for (i = 557; i < 560; i++) R4992[i] = (char *(*)()) F591_5437;}
	R4992[600] = (char *(*)()) F591_5437;
	R4992[610] = (char *(*)()) F591_5437;
}

char *(*R5019[12])();
void R5019_init () {
	R5019[0] = (char *(*)()) F578_5348;
	R5019[1] = (char *(*)()) F579_5348;
	R5019[2] = (char *(*)()) F580_5348;
	R5019[3] = (char *(*)()) F581_5348;
	R5019[4] = (char *(*)()) F582_5348;
	R5019[5] = (char *(*)()) F583_5348;
	R5019[6] = (char *(*)()) F584_5348;
	R5019[7] = (char *(*)()) F585_5348;
	R5019[8] = (char *(*)()) F586_5348;
	R5019[9] = (char *(*)()) F587_5348;
	R5019[10] = (char *(*)()) F588_5348;
	R5019[11] = (char *(*)()) F589_5348;
}

char *(*R5043[12])();
void R5043_init () {
	R5043[0] = (char *(*)()) F578_5390;
	R5043[1] = (char *(*)()) F579_5390_5043_268;
	R5043[2] = (char *(*)()) F580_5390_5043_268;
	R5043[3] = (char *(*)()) F581_5390_5043_268;
	R5043[4] = (char *(*)()) F582_5390_5043_268;
	R5043[5] = (char *(*)()) F583_5390_5043_268;
	R5043[6] = (char *(*)()) F584_5390_5043_268;
	R5043[7] = (char *(*)()) F585_5390_5043_268;
	R5043[8] = (char *(*)()) F586_5390_5043_268;
	R5043[9] = (char *(*)()) F587_5390_5043_268;
	R5043[10] = (char *(*)()) F588_5390_5043_268;
	R5043[11] = (char *(*)()) F589_5390_5043_268;
}
static void F579_5390_5043_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F579_5390(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F580_5390_5043_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F580_5390(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F581_5390_5043_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F581_5390(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F582_5390_5043_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F582_5390(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F583_5390_5043_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F583_5390(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F584_5390_5043_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F584_5390(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F585_5390_5043_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F585_5390(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F586_5390_5043_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F586_5390(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F587_5390_5043_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F587_5390(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F588_5390_5043_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F588_5390(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F589_5390_5043_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F589_5390(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R5050[12])();
void R5050_init () {
	R5050[0] = (char *(*)()) F578_5402;
	R5050[1] = (char *(*)()) F579_5402;
	R5050[2] = (char *(*)()) F580_5402;
	R5050[3] = (char *(*)()) F581_5402;
	R5050[4] = (char *(*)()) F582_5402;
	R5050[5] = (char *(*)()) F583_5402;
	R5050[6] = (char *(*)()) F584_5402;
	R5050[7] = (char *(*)()) F585_5402;
	R5050[8] = (char *(*)()) F586_5402;
	R5050[9] = (char *(*)()) F587_5402;
	R5050[10] = (char *(*)()) F588_5402;
	R5050[11] = (char *(*)()) F589_5402;
}

char *(*R5075[548])();
void R5075_init () {
	R5075[0] = (char *(*)()) F639_5478;
	R5075[1] = (char *(*)()) F640_5478_5075_1;
	R5075[2] = (char *(*)()) F641_5478_5075_1;
	R5075[3] = (char *(*)()) F639_5478;
	R5075[4] = (char *(*)()) F641_5478_5075_1;
	R5075[5] = (char *(*)()) F640_5478_5075_1;
	R5075[6] = (char *(*)()) F639_5478;
	R5075[18] = (char *(*)()) F657_5727;
	R5075[19] = (char *(*)()) F658_5727_5075_1;
	R5075[20] = (char *(*)()) F659_5727_5075_1;
	R5075[21] = (char *(*)()) F660_5727_5075_1;
	R5075[22] = (char *(*)()) F661_5727_5075_1;
	R5075[23] = (char *(*)()) F662_5727_5075_1;
	R5075[24] = (char *(*)()) F663_5727_5075_1;
	R5075[25] = (char *(*)()) F664_5727_5075_1;
	R5075[26] = (char *(*)()) F665_5727_5075_1;
	R5075[27] = (char *(*)()) F666_5727_5075_1;
	R5075[28] = (char *(*)()) F667_5727_5075_1;
	R5075[29] = (char *(*)()) F668_5727_5075_1;
	R5075[30] = (char *(*)()) F657_5727;
	R5075[31] = (char *(*)()) F658_5727_5075_1;
	R5075[32] = (char *(*)()) F664_5727_5075_1;
	R5075[37] = (char *(*)()) F657_5727;
	R5075[38] = (char *(*)()) F658_5727_5075_1;
	{long i; for (i = 39; i < 43; i++) R5075[i] = (char *(*)()) F657_5727;}
	R5075[47] = (char *(*)()) F657_5727;
	R5075[49] = (char *(*)()) F657_5727;
	R5075[53] = (char *(*)()) F657_5727;
	{long i; for (i = 55; i < 57; i++) R5075[i] = (char *(*)()) F657_5727;}
	{long i; for (i = 58; i < 61; i++) R5075[i] = (char *(*)()) F657_5727;}
	{long i; for (i = 494; i < 497; i++) R5075[i] = (char *(*)()) F591_5425;}
	R5075[537] = (char *(*)()) F591_5425;
	R5075[547] = (char *(*)()) F591_5425;
}
static EIF_REFERENCE F640_5478_5075_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F640_5478(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_5478_5075_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F641_5478(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_5727_5075_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5727(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5727_5075_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F659_5727(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5727_5075_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F660_5727(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_5727_5075_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F661_5727(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_5727_5075_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F662_5727(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_5727_5075_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F663_5727(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5727_5075_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F664_5727(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5727_5075_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F665_5727(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5727_5075_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F666_5727(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5727_5075_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F667_5727(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5727_5075_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F668_5727(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5076[548])();
void R5076_init () {
	R5076[0] = (char *(*)()) F639_5479;
	R5076[1] = (char *(*)()) F640_5479_5076_1;
	R5076[2] = (char *(*)()) F641_5479_5076_1;
	R5076[3] = (char *(*)()) F639_5479;
	R5076[4] = (char *(*)()) F641_5479_5076_1;
	R5076[5] = (char *(*)()) F640_5479_5076_1;
	R5076[6] = (char *(*)()) F639_5479;
	R5076[18] = (char *(*)()) F657_5728;
	R5076[19] = (char *(*)()) F658_5728_5076_1;
	R5076[20] = (char *(*)()) F659_5728_5076_1;
	R5076[21] = (char *(*)()) F660_5728_5076_1;
	R5076[22] = (char *(*)()) F661_5728_5076_1;
	R5076[23] = (char *(*)()) F662_5728_5076_1;
	R5076[24] = (char *(*)()) F663_5728_5076_1;
	R5076[25] = (char *(*)()) F664_5728_5076_1;
	R5076[26] = (char *(*)()) F665_5728_5076_1;
	R5076[27] = (char *(*)()) F666_5728_5076_1;
	R5076[28] = (char *(*)()) F667_5728_5076_1;
	R5076[29] = (char *(*)()) F668_5728_5076_1;
	R5076[30] = (char *(*)()) F657_5728;
	R5076[31] = (char *(*)()) F658_5728_5076_1;
	R5076[32] = (char *(*)()) F664_5728_5076_1;
	R5076[37] = (char *(*)()) F657_5728;
	R5076[38] = (char *(*)()) F658_5728_5076_1;
	{long i; for (i = 39; i < 43; i++) R5076[i] = (char *(*)()) F657_5728;}
	R5076[47] = (char *(*)()) F657_5728;
	R5076[49] = (char *(*)()) F657_5728;
	R5076[53] = (char *(*)()) F657_5728;
	{long i; for (i = 55; i < 57; i++) R5076[i] = (char *(*)()) F657_5728;}
	{long i; for (i = 58; i < 61; i++) R5076[i] = (char *(*)()) F657_5728;}
	{long i; for (i = 494; i < 497; i++) R5076[i] = (char *(*)()) F591_5426;}
	R5076[537] = (char *(*)()) F591_5426;
	R5076[547] = (char *(*)()) F591_5426;
}
static EIF_REFERENCE F640_5479_5076_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F640_5479(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_5479_5076_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F641_5479(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_5728_5076_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5728_5076_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F659_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5728_5076_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F660_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_5728_5076_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F661_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_5728_5076_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F662_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_5728_5076_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F663_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5728_5076_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F664_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5728_5076_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F665_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5728_5076_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F666_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5728_5076_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F667_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5728_5076_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F668_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5077[7])();
void R5077_init () {
	R5077[0] = (char *(*)()) F639_5498;
	R5077[1] = (char *(*)()) F640_5498;
	R5077[2] = (char *(*)()) F641_5498;
	R5077[3] = (char *(*)()) F639_5498;
	R5077[4] = (char *(*)()) F641_5498;
	R5077[5] = (char *(*)()) F640_5498;
	R5077[6] = (char *(*)()) F639_5498;
}

char *(*R5078[548])();
void R5078_init () {
	R5078[0] = (char *(*)()) F639_5499;
	R5078[1] = (char *(*)()) F640_5499;
	R5078[2] = (char *(*)()) F641_5499;
	R5078[3] = (char *(*)()) F639_5499;
	R5078[4] = (char *(*)()) F641_5499;
	R5078[5] = (char *(*)()) F640_5499;
	R5078[6] = (char *(*)()) F639_5499;
	R5078[18] = (char *(*)()) F657_5754;
	R5078[19] = (char *(*)()) F658_5754;
	R5078[20] = (char *(*)()) F659_5754;
	R5078[21] = (char *(*)()) F660_5754;
	R5078[22] = (char *(*)()) F661_5754;
	R5078[23] = (char *(*)()) F662_5754;
	R5078[24] = (char *(*)()) F663_5754;
	R5078[25] = (char *(*)()) F664_5754;
	R5078[26] = (char *(*)()) F665_5754;
	R5078[27] = (char *(*)()) F666_5754;
	R5078[28] = (char *(*)()) F667_5754;
	R5078[29] = (char *(*)()) F668_5754;
	R5078[30] = (char *(*)()) F657_5754;
	R5078[31] = (char *(*)()) F658_5754;
	R5078[32] = (char *(*)()) F664_5754;
	R5078[37] = (char *(*)()) F657_5754;
	R5078[38] = (char *(*)()) F658_5754;
	{long i; for (i = 39; i < 43; i++) R5078[i] = (char *(*)()) F657_5754;}
	R5078[47] = (char *(*)()) F657_5754;
	R5078[49] = (char *(*)()) F657_5754;
	R5078[53] = (char *(*)()) F657_5754;
	{long i; for (i = 55; i < 57; i++) R5078[i] = (char *(*)()) F657_5754;}
	{long i; for (i = 58; i < 61; i++) R5078[i] = (char *(*)()) F657_5754;}
	{long i; for (i = 494; i < 497; i++) R5078[i] = (char *(*)()) F1125_10147;}
	R5078[537] = (char *(*)()) F1125_10147;
	R5078[547] = (char *(*)()) F1125_10147;
}

char *(*R5079[548])();
void R5079_init () {
	R5079[0] = (char *(*)()) F639_5489;
	R5079[1] = (char *(*)()) F640_5489;
	R5079[2] = (char *(*)()) F641_5489;
	R5079[3] = (char *(*)()) F639_5489;
	R5079[4] = (char *(*)()) F641_5489;
	R5079[5] = (char *(*)()) F640_5489;
	R5079[6] = (char *(*)()) F639_5489;
	R5079[18] = (char *(*)()) F591_5438;
	R5079[19] = (char *(*)()) F592_5438;
	R5079[20] = (char *(*)()) F593_5438;
	R5079[21] = (char *(*)()) F594_5438;
	R5079[22] = (char *(*)()) F595_5438;
	R5079[23] = (char *(*)()) F596_5438;
	R5079[24] = (char *(*)()) F597_5438;
	R5079[25] = (char *(*)()) F598_5438;
	R5079[26] = (char *(*)()) F599_5438;
	R5079[27] = (char *(*)()) F600_5438;
	R5079[28] = (char *(*)()) F601_5438;
	R5079[29] = (char *(*)()) F602_5438;
	R5079[30] = (char *(*)()) F591_5438;
	R5079[31] = (char *(*)()) F592_5438;
	R5079[32] = (char *(*)()) F598_5438;
	R5079[37] = (char *(*)()) F591_5438;
	R5079[38] = (char *(*)()) F592_5438;
	{long i; for (i = 39; i < 43; i++) R5079[i] = (char *(*)()) F591_5438;}
	R5079[47] = (char *(*)()) F591_5438;
	R5079[49] = (char *(*)()) F591_5438;
	R5079[53] = (char *(*)()) F591_5438;
	{long i; for (i = 55; i < 57; i++) R5079[i] = (char *(*)()) F591_5438;}
	{long i; for (i = 58; i < 61; i++) R5079[i] = (char *(*)()) F591_5438;}
	{long i; for (i = 494; i < 497; i++) R5079[i] = (char *(*)()) F591_5438;}
	R5079[537] = (char *(*)()) F591_5438;
	R5079[547] = (char *(*)()) F591_5438;
}


#ifdef __cplusplus
}
#endif
