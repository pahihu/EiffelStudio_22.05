#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O3382[1215];
void O3382_init () {
	O3382[0] =  + _REFACS_13_;
	{long i; for (i = 1114; i < 1116; i++) O3382[i] =  + _REFACS_19_;}
	{long i; for (i = 1116; i < 1119; i++) O3382[i] =  + _REFACS_20_;}
	O3382[1119] =  + _REFACS_21_;
	{long i; for (i = 1120; i < 1122; i++) O3382[i] =  + _REFACS_20_;}
	O3382[1122] =  + _REFACS_21_;
	O3382[1123] =  + _REFACS_20_;
	{long i; for (i = 1124; i < 1138; i++) O3382[i] =  + _REFACS_21_;}
	{long i; for (i = 1138; i < 1140; i++) O3382[i] =  + _REFACS_25_;}
	{long i; for (i = 1140; i < 1142; i++) O3382[i] =  + _REFACS_28_;}
	{long i; for (i = 1142; i < 1144; i++) O3382[i] =  + _REFACS_25_;}
	{long i; for (i = 1144; i < 1146; i++) O3382[i] =  + _REFACS_28_;}
	O3382[1146] =  + _REFACS_19_;
	O3382[1147] =  + _REFACS_20_;
	O3382[1148] =  + _REFACS_23_;
	O3382[1149] =  + _REFACS_21_;
	O3382[1150] =  + _REFACS_20_;
	O3382[1151] =  + _REFACS_19_;
	{long i; for (i = 1152; i < 1154; i++) O3382[i] =  + _REFACS_21_;}
	O3382[1154] =  + _REFACS_20_;
	O3382[1155] =  + _REFACS_21_;
	O3382[1156] =  + _REFACS_25_;
	O3382[1157] =  + _REFACS_20_;
	O3382[1158] =  + _REFACS_23_;
	{long i; for (i = 1159; i < 1163; i++) O3382[i] =  + _REFACS_20_;}
	O3382[1163] =  + _REFACS_19_;
	O3382[1164] =  + _REFACS_20_;
	O3382[1165] =  + _REFACS_23_;
	O3382[1166] =  + _REFACS_21_;
	O3382[1167] =  + _REFACS_20_;
	O3382[1168] =  + _REFACS_19_;
	{long i; for (i = 1169; i < 1171; i++) O3382[i] =  + _REFACS_21_;}
	O3382[1171] =  + _REFACS_20_;
	O3382[1172] =  + _REFACS_21_;
	O3382[1173] =  + _REFACS_25_;
	O3382[1174] =  + _REFACS_20_;
	O3382[1175] =  + _REFACS_23_;
	{long i; for (i = 1176; i < 1180; i++) O3382[i] =  + _REFACS_20_;}
	O3382[1207] =  + _REFACS_20_;
	O3382[1209] =  + _REFACS_20_;
	O3382[1212] =  + _REFACS_20_;
	O3382[1214] =  + _REFACS_20_;
}

long O3391[1214];
void O3391_init () {
	O3391[0] = 0;
	{long i; for (i = 1075; i < 1077; i++) O3391[i] =  + _REFACS_2_;}
	{long i; for (i = 1111; i < 1113; i++) O3391[i] =  + _REFACS_4_;}
	{long i; for (i = 1113; i < 1115; i++) O3391[i] =  + _REFACS_21_;}
	{long i; for (i = 1115; i < 1118; i++) O3391[i] =  + _REFACS_22_;}
	O3391[1118] =  + _REFACS_23_;
	{long i; for (i = 1119; i < 1121; i++) O3391[i] =  + _REFACS_22_;}
	O3391[1121] =  + _REFACS_23_;
	O3391[1122] =  + _REFACS_22_;
	{long i; for (i = 1123; i < 1137; i++) O3391[i] =  + _REFACS_23_;}
	{long i; for (i = 1137; i < 1139; i++) O3391[i] =  + _REFACS_27_;}
	{long i; for (i = 1139; i < 1141; i++) O3391[i] =  + _REFACS_30_;}
	{long i; for (i = 1141; i < 1143; i++) O3391[i] =  + _REFACS_27_;}
	{long i; for (i = 1143; i < 1145; i++) O3391[i] =  + _REFACS_30_;}
	O3391[1145] =  + _REFACS_21_;
	O3391[1146] =  + _REFACS_22_;
	O3391[1147] =  + _REFACS_25_;
	O3391[1148] =  + _REFACS_23_;
	O3391[1149] =  + _REFACS_22_;
	O3391[1150] =  + _REFACS_21_;
	{long i; for (i = 1151; i < 1153; i++) O3391[i] =  + _REFACS_23_;}
	O3391[1153] =  + _REFACS_22_;
	O3391[1154] =  + _REFACS_23_;
	O3391[1155] =  + _REFACS_27_;
	O3391[1156] =  + _REFACS_22_;
	O3391[1157] =  + _REFACS_25_;
	{long i; for (i = 1158; i < 1162; i++) O3391[i] =  + _REFACS_22_;}
	O3391[1162] =  + _REFACS_21_;
	O3391[1163] =  + _REFACS_22_;
	O3391[1164] =  + _REFACS_25_;
	O3391[1165] =  + _REFACS_23_;
	O3391[1166] =  + _REFACS_22_;
	O3391[1167] =  + _REFACS_21_;
	{long i; for (i = 1168; i < 1170; i++) O3391[i] =  + _REFACS_23_;}
	O3391[1170] =  + _REFACS_22_;
	O3391[1171] =  + _REFACS_23_;
	O3391[1172] =  + _REFACS_27_;
	O3391[1173] =  + _REFACS_22_;
	O3391[1174] =  + _REFACS_25_;
	{long i; for (i = 1175; i < 1179; i++) O3391[i] =  + _REFACS_22_;}
	O3391[1179] =  + _REFACS_7_;
	{long i; for (i = 1180; i < 1182; i++) O3391[i] =  + _REFACS_9_;}
	O3391[1182] =  + _REFACS_7_;
	{long i; for (i = 1183; i < 1187; i++) O3391[i] =  + _REFACS_11_;}
	{long i; for (i = 1187; i < 1189; i++) O3391[i] =  + _REFACS_7_;}
	{long i; for (i = 1189; i < 1193; i++) O3391[i] =  + _REFACS_8_;}
	O3391[1193] =  + _REFACS_9_;
	{long i; for (i = 1194; i < 1198; i++) O3391[i] =  + _REFACS_8_;}
	{long i; for (i = 1198; i < 1201; i++) O3391[i] =  + _REFACS_9_;}
	{long i; for (i = 1201; i < 1205; i++) O3391[i] =  + _REFACS_11_;}
	O3391[1206] =  + _REFACS_22_;
	O3391[1208] =  + _REFACS_22_;
	O3391[1211] =  + _REFACS_22_;
	O3391[1213] =  + _REFACS_22_;
}

long O3392[1214];
void O3392_init () {
	O3392[0] =  + _REFACS_1_;
	{long i; for (i = 1075; i < 1077; i++) O3392[i] =  + _REFACS_3_;}
	{long i; for (i = 1111; i < 1113; i++) O3392[i] =  + _REFACS_5_;}
	{long i; for (i = 1113; i < 1115; i++) O3392[i] =  + _REFACS_22_;}
	{long i; for (i = 1115; i < 1118; i++) O3392[i] =  + _REFACS_23_;}
	O3392[1118] =  + _REFACS_24_;
	{long i; for (i = 1119; i < 1121; i++) O3392[i] =  + _REFACS_23_;}
	O3392[1121] =  + _REFACS_24_;
	O3392[1122] =  + _REFACS_23_;
	{long i; for (i = 1123; i < 1137; i++) O3392[i] =  + _REFACS_24_;}
	{long i; for (i = 1137; i < 1139; i++) O3392[i] =  + _REFACS_28_;}
	{long i; for (i = 1139; i < 1141; i++) O3392[i] =  + _REFACS_31_;}
	{long i; for (i = 1141; i < 1143; i++) O3392[i] =  + _REFACS_28_;}
	{long i; for (i = 1143; i < 1145; i++) O3392[i] =  + _REFACS_31_;}
	O3392[1145] =  + _REFACS_22_;
	O3392[1146] =  + _REFACS_23_;
	O3392[1147] =  + _REFACS_26_;
	O3392[1148] =  + _REFACS_24_;
	O3392[1149] =  + _REFACS_23_;
	O3392[1150] =  + _REFACS_22_;
	{long i; for (i = 1151; i < 1153; i++) O3392[i] =  + _REFACS_24_;}
	O3392[1153] =  + _REFACS_23_;
	O3392[1154] =  + _REFACS_24_;
	O3392[1155] =  + _REFACS_28_;
	O3392[1156] =  + _REFACS_23_;
	O3392[1157] =  + _REFACS_26_;
	{long i; for (i = 1158; i < 1162; i++) O3392[i] =  + _REFACS_23_;}
	O3392[1162] =  + _REFACS_22_;
	O3392[1163] =  + _REFACS_23_;
	O3392[1164] =  + _REFACS_26_;
	O3392[1165] =  + _REFACS_24_;
	O3392[1166] =  + _REFACS_23_;
	O3392[1167] =  + _REFACS_22_;
	{long i; for (i = 1168; i < 1170; i++) O3392[i] =  + _REFACS_24_;}
	O3392[1170] =  + _REFACS_23_;
	O3392[1171] =  + _REFACS_24_;
	O3392[1172] =  + _REFACS_28_;
	O3392[1173] =  + _REFACS_23_;
	O3392[1174] =  + _REFACS_26_;
	{long i; for (i = 1175; i < 1179; i++) O3392[i] =  + _REFACS_23_;}
	O3392[1179] =  + _REFACS_8_;
	{long i; for (i = 1180; i < 1182; i++) O3392[i] =  + _REFACS_10_;}
	O3392[1182] =  + _REFACS_8_;
	{long i; for (i = 1183; i < 1187; i++) O3392[i] =  + _REFACS_12_;}
	{long i; for (i = 1187; i < 1189; i++) O3392[i] =  + _REFACS_8_;}
	{long i; for (i = 1189; i < 1193; i++) O3392[i] =  + _REFACS_9_;}
	O3392[1193] =  + _REFACS_10_;
	{long i; for (i = 1194; i < 1198; i++) O3392[i] =  + _REFACS_9_;}
	{long i; for (i = 1198; i < 1201; i++) O3392[i] =  + _REFACS_10_;}
	{long i; for (i = 1201; i < 1205; i++) O3392[i] =  + _REFACS_12_;}
	O3392[1206] =  + _REFACS_23_;
	O3392[1208] =  + _REFACS_23_;
	O3392[1211] =  + _REFACS_23_;
	O3392[1213] =  + _REFACS_23_;
}

long O3393[1214];
void O3393_init () {
	O3393[0] = + _I16OFF_3_1_0_;
	O3393[1075] = + _I16OFF_7_5_0_;
	O3393[1076] = + _I16OFF_8_6_0_;
	O3393[1111] = + _I16OFF_13_5_0_;
	O3393[1112] = + _I16OFF_16_7_0_;
	O3393[1113] = + _I16OFF_35_9_0_;
	O3393[1114] = + _I16OFF_42_12_0_;
	O3393[1115] = + _I16OFF_37_9_0_;
	O3393[1116] = + _I16OFF_46_12_0_;
	O3393[1117] = + _I16OFF_37_9_0_;
	O3393[1118] = + _I16OFF_38_9_0_;
	O3393[1119] = + _I16OFF_37_9_0_;
	O3393[1120] = + _I16OFF_47_12_0_;
	O3393[1121] = + _I16OFF_49_12_0_;
	O3393[1122] = + _I16OFF_47_12_0_;
	{long i; for (i = 1123; i < 1126; i++) O3393[i] = + _I16OFF_39_10_0_;}
	{long i; for (i = 1126; i < 1129; i++) O3393[i] = + _I16OFF_49_13_0_;}
	{long i; for (i = 1129; i < 1133; i++) O3393[i] = + _I16OFF_39_10_0_;}
	O3393[1133] = + _I16OFF_49_13_0_;
	O3393[1134] = + _I16OFF_51_13_0_;
	{long i; for (i = 1135; i < 1137; i++) O3393[i] = + _I16OFF_49_14_0_;}
	O3393[1137] = + _I16OFF_47_12_0_;
	O3393[1138] = + _I16OFF_47_14_0_;
	O3393[1139] = + _I16OFF_50_13_0_;
	O3393[1140] = + _I16OFF_53_13_0_;
	O3393[1141] = + _I16OFF_59_21_0_;
	O3393[1142] = + _I16OFF_59_23_0_;
	O3393[1143] = + _I16OFF_65_25_0_;
	O3393[1144] = + _I16OFF_68_26_0_;
	O3393[1145] = + _I16OFF_35_9_0_;
	O3393[1146] = + _I16OFF_37_9_0_;
	O3393[1147] = + _I16OFF_43_9_0_;
	O3393[1148] = + _I16OFF_37_9_0_;
	O3393[1149] = + _I16OFF_37_10_0_;
	O3393[1150] = + _I16OFF_35_9_0_;
	O3393[1151] = + _I16OFF_37_9_0_;
	O3393[1152] = + _I16OFF_37_10_0_;
	O3393[1153] = + _I16OFF_36_9_0_;
	O3393[1154] = + _I16OFF_37_9_0_;
	O3393[1155] = + _I16OFF_41_9_0_;
	O3393[1156] = + _I16OFF_36_9_0_;
	O3393[1157] = + _I16OFF_40_12_0_;
	{long i; for (i = 1158; i < 1162; i++) O3393[i] = + _I16OFF_36_9_0_;}
	O3393[1162] = + _I16OFF_42_13_0_;
	O3393[1163] = + _I16OFF_44_13_0_;
	O3393[1164] = + _I16OFF_58_14_0_;
	O3393[1165] = + _I16OFF_51_13_0_;
	O3393[1166] = + _I16OFF_45_16_0_;
	O3393[1167] = + _I16OFF_44_13_0_;
	O3393[1168] = + _I16OFF_50_13_0_;
	O3393[1169] = + _I16OFF_51_14_0_;
	O3393[1170] = + _I16OFF_43_13_0_;
	O3393[1171] = + _I16OFF_46_14_0_;
	O3393[1172] = + _I16OFF_59_16_0_;
	O3393[1173] = + _I16OFF_44_15_0_;
	O3393[1174] = + _I16OFF_51_18_0_;
	{long i; for (i = 1175; i < 1179; i++) O3393[i] = + _I16OFF_46_14_0_;}
	O3393[1179] = + _I16OFF_16_5_0_;
	O3393[1180] = + _I16OFF_18_5_0_;
	O3393[1181] = + _I16OFF_23_5_0_;
	O3393[1182] = + _I16OFF_16_5_0_;
	{long i; for (i = 1183; i < 1185; i++) O3393[i] = + _I16OFF_20_5_0_;}
	{long i; for (i = 1185; i < 1187; i++) O3393[i] = + _I16OFF_25_6_0_;}
	{long i; for (i = 1187; i < 1189; i++) O3393[i] = + _I16OFF_21_7_0_;}
	{long i; for (i = 1189; i < 1193; i++) O3393[i] = + _I16OFF_17_6_0_;}
	O3393[1193] = + _I16OFF_18_6_0_;
	O3393[1194] = + _I16OFF_23_8_0_;
	{long i; for (i = 1195; i < 1197; i++) O3393[i] = + _I16OFF_23_9_0_;}
	O3393[1197] = + _I16OFF_24_9_0_;
	O3393[1198] = + _I16OFF_26_8_0_;
	O3393[1199] = + _I16OFF_19_5_0_;
	O3393[1200] = + _I16OFF_22_5_0_;
	{long i; for (i = 1201; i < 1203; i++) O3393[i] = + _I16OFF_21_10_0_;}
	{long i; for (i = 1203; i < 1205; i++) O3393[i] = + _I16OFF_29_14_0_;}
	O3393[1206] = + _I16OFF_36_10_0_;
	O3393[1208] = + _I16OFF_36_9_0_;
	O3393[1211] = + _I16OFF_48_19_0_;
	O3393[1213] = + _I16OFF_48_18_0_;
}

long O3394[1214];
void O3394_init () {
	O3394[0] = + _I16OFF_3_1_1_;
	O3394[1075] = + _I16OFF_7_5_1_;
	O3394[1076] = + _I16OFF_8_6_1_;
	O3394[1111] = + _I16OFF_13_5_1_;
	O3394[1112] = + _I16OFF_16_7_1_;
	O3394[1113] = + _I16OFF_35_9_1_;
	O3394[1114] = + _I16OFF_42_12_1_;
	O3394[1115] = + _I16OFF_37_9_1_;
	O3394[1116] = + _I16OFF_46_12_1_;
	O3394[1117] = + _I16OFF_37_9_1_;
	O3394[1118] = + _I16OFF_38_9_1_;
	O3394[1119] = + _I16OFF_37_9_1_;
	O3394[1120] = + _I16OFF_47_12_1_;
	O3394[1121] = + _I16OFF_49_12_1_;
	O3394[1122] = + _I16OFF_47_12_1_;
	{long i; for (i = 1123; i < 1126; i++) O3394[i] = + _I16OFF_39_10_1_;}
	{long i; for (i = 1126; i < 1129; i++) O3394[i] = + _I16OFF_49_13_1_;}
	{long i; for (i = 1129; i < 1133; i++) O3394[i] = + _I16OFF_39_10_1_;}
	O3394[1133] = + _I16OFF_49_13_1_;
	O3394[1134] = + _I16OFF_51_13_1_;
	{long i; for (i = 1135; i < 1137; i++) O3394[i] = + _I16OFF_49_14_1_;}
	O3394[1137] = + _I16OFF_47_12_1_;
	O3394[1138] = + _I16OFF_47_14_1_;
	O3394[1139] = + _I16OFF_50_13_1_;
	O3394[1140] = + _I16OFF_53_13_1_;
	O3394[1141] = + _I16OFF_59_21_1_;
	O3394[1142] = + _I16OFF_59_23_1_;
	O3394[1143] = + _I16OFF_65_25_1_;
	O3394[1144] = + _I16OFF_68_26_1_;
	O3394[1145] = + _I16OFF_35_9_1_;
	O3394[1146] = + _I16OFF_37_9_1_;
	O3394[1147] = + _I16OFF_43_9_1_;
	O3394[1148] = + _I16OFF_37_9_1_;
	O3394[1149] = + _I16OFF_37_10_1_;
	O3394[1150] = + _I16OFF_35_9_1_;
	O3394[1151] = + _I16OFF_37_9_1_;
	O3394[1152] = + _I16OFF_37_10_1_;
	O3394[1153] = + _I16OFF_36_9_1_;
	O3394[1154] = + _I16OFF_37_9_1_;
	O3394[1155] = + _I16OFF_41_9_1_;
	O3394[1156] = + _I16OFF_36_9_1_;
	O3394[1157] = + _I16OFF_40_12_1_;
	{long i; for (i = 1158; i < 1162; i++) O3394[i] = + _I16OFF_36_9_1_;}
	O3394[1162] = + _I16OFF_42_13_1_;
	O3394[1163] = + _I16OFF_44_13_1_;
	O3394[1164] = + _I16OFF_58_14_1_;
	O3394[1165] = + _I16OFF_51_13_1_;
	O3394[1166] = + _I16OFF_45_16_1_;
	O3394[1167] = + _I16OFF_44_13_1_;
	O3394[1168] = + _I16OFF_50_13_1_;
	O3394[1169] = + _I16OFF_51_14_1_;
	O3394[1170] = + _I16OFF_43_13_1_;
	O3394[1171] = + _I16OFF_46_14_1_;
	O3394[1172] = + _I16OFF_59_16_1_;
	O3394[1173] = + _I16OFF_44_15_1_;
	O3394[1174] = + _I16OFF_51_18_1_;
	{long i; for (i = 1175; i < 1179; i++) O3394[i] = + _I16OFF_46_14_1_;}
	O3394[1179] = + _I16OFF_16_5_1_;
	O3394[1180] = + _I16OFF_18_5_1_;
	O3394[1181] = + _I16OFF_23_5_1_;
	O3394[1182] = + _I16OFF_16_5_1_;
	{long i; for (i = 1183; i < 1185; i++) O3394[i] = + _I16OFF_20_5_1_;}
	{long i; for (i = 1185; i < 1187; i++) O3394[i] = + _I16OFF_25_6_1_;}
	{long i; for (i = 1187; i < 1189; i++) O3394[i] = + _I16OFF_21_7_1_;}
	{long i; for (i = 1189; i < 1193; i++) O3394[i] = + _I16OFF_17_6_1_;}
	O3394[1193] = + _I16OFF_18_6_1_;
	O3394[1194] = + _I16OFF_23_8_1_;
	{long i; for (i = 1195; i < 1197; i++) O3394[i] = + _I16OFF_23_9_1_;}
	O3394[1197] = + _I16OFF_24_9_1_;
	O3394[1198] = + _I16OFF_26_8_1_;
	O3394[1199] = + _I16OFF_19_5_1_;
	O3394[1200] = + _I16OFF_22_5_1_;
	{long i; for (i = 1201; i < 1203; i++) O3394[i] = + _I16OFF_21_10_1_;}
	{long i; for (i = 1203; i < 1205; i++) O3394[i] = + _I16OFF_29_14_1_;}
	O3394[1206] = + _I16OFF_36_10_1_;
	O3394[1208] = + _I16OFF_36_9_1_;
	O3394[1211] = + _I16OFF_48_19_1_;
	O3394[1213] = + _I16OFF_48_18_1_;
}

long O3402[1214];
void O3402_init () {
	O3402[0] =  + _REFACS_2_;
	{long i; for (i = 1075; i < 1077; i++) O3402[i] =  + _REFACS_4_;}
	{long i; for (i = 1111; i < 1113; i++) O3402[i] =  + _REFACS_6_;}
	{long i; for (i = 1113; i < 1115; i++) O3402[i] =  + _REFACS_23_;}
	{long i; for (i = 1115; i < 1118; i++) O3402[i] =  + _REFACS_24_;}
	O3402[1118] =  + _REFACS_25_;
	{long i; for (i = 1119; i < 1121; i++) O3402[i] =  + _REFACS_24_;}
	O3402[1121] =  + _REFACS_25_;
	O3402[1122] =  + _REFACS_24_;
	{long i; for (i = 1123; i < 1137; i++) O3402[i] =  + _REFACS_25_;}
	{long i; for (i = 1137; i < 1139; i++) O3402[i] =  + _REFACS_29_;}
	{long i; for (i = 1139; i < 1141; i++) O3402[i] =  + _REFACS_32_;}
	{long i; for (i = 1141; i < 1143; i++) O3402[i] =  + _REFACS_29_;}
	{long i; for (i = 1143; i < 1145; i++) O3402[i] =  + _REFACS_32_;}
	O3402[1145] =  + _REFACS_23_;
	O3402[1146] =  + _REFACS_24_;
	O3402[1147] =  + _REFACS_27_;
	O3402[1148] =  + _REFACS_25_;
	O3402[1149] =  + _REFACS_24_;
	O3402[1150] =  + _REFACS_23_;
	{long i; for (i = 1151; i < 1153; i++) O3402[i] =  + _REFACS_25_;}
	O3402[1153] =  + _REFACS_24_;
	O3402[1154] =  + _REFACS_25_;
	O3402[1155] =  + _REFACS_29_;
	O3402[1156] =  + _REFACS_24_;
	O3402[1157] =  + _REFACS_27_;
	{long i; for (i = 1158; i < 1162; i++) O3402[i] =  + _REFACS_24_;}
	O3402[1162] =  + _REFACS_23_;
	O3402[1163] =  + _REFACS_24_;
	O3402[1164] =  + _REFACS_27_;
	O3402[1165] =  + _REFACS_25_;
	O3402[1166] =  + _REFACS_24_;
	O3402[1167] =  + _REFACS_23_;
	{long i; for (i = 1168; i < 1170; i++) O3402[i] =  + _REFACS_25_;}
	O3402[1170] =  + _REFACS_24_;
	O3402[1171] =  + _REFACS_25_;
	O3402[1172] =  + _REFACS_29_;
	O3402[1173] =  + _REFACS_24_;
	O3402[1174] =  + _REFACS_27_;
	{long i; for (i = 1175; i < 1179; i++) O3402[i] =  + _REFACS_24_;}
	O3402[1179] =  + _REFACS_9_;
	{long i; for (i = 1180; i < 1182; i++) O3402[i] =  + _REFACS_11_;}
	O3402[1182] =  + _REFACS_9_;
	{long i; for (i = 1183; i < 1187; i++) O3402[i] =  + _REFACS_13_;}
	{long i; for (i = 1187; i < 1189; i++) O3402[i] =  + _REFACS_9_;}
	{long i; for (i = 1189; i < 1193; i++) O3402[i] =  + _REFACS_10_;}
	O3402[1193] =  + _REFACS_11_;
	{long i; for (i = 1194; i < 1198; i++) O3402[i] =  + _REFACS_10_;}
	{long i; for (i = 1198; i < 1201; i++) O3402[i] =  + _REFACS_11_;}
	{long i; for (i = 1201; i < 1205; i++) O3402[i] =  + _REFACS_13_;}
	O3402[1206] =  + _REFACS_24_;
	O3402[1208] =  + _REFACS_24_;
	O3402[1211] =  + _REFACS_24_;
	O3402[1213] =  + _REFACS_24_;
}

long O3404[1214];
void O3404_init () {
	O3404[0] = + _I16OFF_3_1_2_;
	O3404[1075] = + _I16OFF_7_5_2_;
	O3404[1076] = + _I16OFF_8_6_2_;
	O3404[1111] = + _I16OFF_13_5_2_;
	O3404[1112] = + _I16OFF_16_7_2_;
	O3404[1113] = + _I16OFF_35_9_2_;
	O3404[1114] = + _I16OFF_42_12_2_;
	O3404[1115] = + _I16OFF_37_9_2_;
	O3404[1116] = + _I16OFF_46_12_2_;
	O3404[1117] = + _I16OFF_37_9_2_;
	O3404[1118] = + _I16OFF_38_9_2_;
	O3404[1119] = + _I16OFF_37_9_2_;
	O3404[1120] = + _I16OFF_47_12_2_;
	O3404[1121] = + _I16OFF_49_12_2_;
	O3404[1122] = + _I16OFF_47_12_2_;
	{long i; for (i = 1123; i < 1126; i++) O3404[i] = + _I16OFF_39_10_2_;}
	{long i; for (i = 1126; i < 1129; i++) O3404[i] = + _I16OFF_49_13_2_;}
	{long i; for (i = 1129; i < 1133; i++) O3404[i] = + _I16OFF_39_10_2_;}
	O3404[1133] = + _I16OFF_49_13_2_;
	O3404[1134] = + _I16OFF_51_13_2_;
	{long i; for (i = 1135; i < 1137; i++) O3404[i] = + _I16OFF_49_14_2_;}
	O3404[1137] = + _I16OFF_47_12_2_;
	O3404[1138] = + _I16OFF_47_14_2_;
	O3404[1139] = + _I16OFF_50_13_2_;
	O3404[1140] = + _I16OFF_53_13_2_;
	O3404[1141] = + _I16OFF_59_21_2_;
	O3404[1142] = + _I16OFF_59_23_2_;
	O3404[1143] = + _I16OFF_65_25_2_;
	O3404[1144] = + _I16OFF_68_26_2_;
	O3404[1145] = + _I16OFF_35_9_2_;
	O3404[1146] = + _I16OFF_37_9_2_;
	O3404[1147] = + _I16OFF_43_9_2_;
	O3404[1148] = + _I16OFF_37_9_2_;
	O3404[1149] = + _I16OFF_37_10_2_;
	O3404[1150] = + _I16OFF_35_9_2_;
	O3404[1151] = + _I16OFF_37_9_2_;
	O3404[1152] = + _I16OFF_37_10_2_;
	O3404[1153] = + _I16OFF_36_9_2_;
	O3404[1154] = + _I16OFF_37_9_2_;
	O3404[1155] = + _I16OFF_41_9_2_;
	O3404[1156] = + _I16OFF_36_9_2_;
	O3404[1157] = + _I16OFF_40_12_2_;
	{long i; for (i = 1158; i < 1162; i++) O3404[i] = + _I16OFF_36_9_2_;}
	O3404[1162] = + _I16OFF_42_13_2_;
	O3404[1163] = + _I16OFF_44_13_2_;
	O3404[1164] = + _I16OFF_58_14_2_;
	O3404[1165] = + _I16OFF_51_13_2_;
	O3404[1166] = + _I16OFF_45_16_2_;
	O3404[1167] = + _I16OFF_44_13_2_;
	O3404[1168] = + _I16OFF_50_13_2_;
	O3404[1169] = + _I16OFF_51_14_2_;
	O3404[1170] = + _I16OFF_43_13_2_;
	O3404[1171] = + _I16OFF_46_14_2_;
	O3404[1172] = + _I16OFF_59_16_2_;
	O3404[1173] = + _I16OFF_44_15_2_;
	O3404[1174] = + _I16OFF_51_18_2_;
	{long i; for (i = 1175; i < 1179; i++) O3404[i] = + _I16OFF_46_14_2_;}
	O3404[1179] = + _I16OFF_16_5_2_;
	O3404[1180] = + _I16OFF_18_5_2_;
	O3404[1181] = + _I16OFF_23_5_2_;
	O3404[1182] = + _I16OFF_16_5_2_;
	{long i; for (i = 1183; i < 1185; i++) O3404[i] = + _I16OFF_20_5_2_;}
	{long i; for (i = 1185; i < 1187; i++) O3404[i] = + _I16OFF_25_6_2_;}
	{long i; for (i = 1187; i < 1189; i++) O3404[i] = + _I16OFF_21_7_2_;}
	{long i; for (i = 1189; i < 1193; i++) O3404[i] = + _I16OFF_17_6_2_;}
	O3404[1193] = + _I16OFF_18_6_2_;
	O3404[1194] = + _I16OFF_23_8_2_;
	{long i; for (i = 1195; i < 1197; i++) O3404[i] = + _I16OFF_23_9_2_;}
	O3404[1197] = + _I16OFF_24_9_2_;
	O3404[1198] = + _I16OFF_26_8_2_;
	O3404[1199] = + _I16OFF_19_5_2_;
	O3404[1200] = + _I16OFF_22_5_2_;
	{long i; for (i = 1201; i < 1203; i++) O3404[i] = + _I16OFF_21_10_2_;}
	{long i; for (i = 1203; i < 1205; i++) O3404[i] = + _I16OFF_29_14_2_;}
	O3404[1206] = + _I16OFF_36_10_2_;
	O3404[1208] = + _I16OFF_36_9_2_;
	O3404[1211] = + _I16OFF_48_19_2_;
	O3404[1213] = + _I16OFF_48_18_2_;
}

long O3405[1214];
void O3405_init () {
	O3405[0] = + _I16OFF_3_1_3_;
	O3405[1075] = + _I16OFF_7_5_3_;
	O3405[1076] = + _I16OFF_8_6_3_;
	O3405[1111] = + _I16OFF_13_5_3_;
	O3405[1112] = + _I16OFF_16_7_3_;
	O3405[1113] = + _I16OFF_35_9_3_;
	O3405[1114] = + _I16OFF_42_12_3_;
	O3405[1115] = + _I16OFF_37_9_3_;
	O3405[1116] = + _I16OFF_46_12_3_;
	O3405[1117] = + _I16OFF_37_9_3_;
	O3405[1118] = + _I16OFF_38_9_3_;
	O3405[1119] = + _I16OFF_37_9_3_;
	O3405[1120] = + _I16OFF_47_12_3_;
	O3405[1121] = + _I16OFF_49_12_3_;
	O3405[1122] = + _I16OFF_47_12_3_;
	{long i; for (i = 1123; i < 1126; i++) O3405[i] = + _I16OFF_39_10_3_;}
	{long i; for (i = 1126; i < 1129; i++) O3405[i] = + _I16OFF_49_13_3_;}
	{long i; for (i = 1129; i < 1133; i++) O3405[i] = + _I16OFF_39_10_3_;}
	O3405[1133] = + _I16OFF_49_13_3_;
	O3405[1134] = + _I16OFF_51_13_3_;
	{long i; for (i = 1135; i < 1137; i++) O3405[i] = + _I16OFF_49_14_3_;}
	O3405[1137] = + _I16OFF_47_12_3_;
	O3405[1138] = + _I16OFF_47_14_3_;
	O3405[1139] = + _I16OFF_50_13_3_;
	O3405[1140] = + _I16OFF_53_13_3_;
	O3405[1141] = + _I16OFF_59_21_3_;
	O3405[1142] = + _I16OFF_59_23_3_;
	O3405[1143] = + _I16OFF_65_25_3_;
	O3405[1144] = + _I16OFF_68_26_3_;
	O3405[1145] = + _I16OFF_35_9_3_;
	O3405[1146] = + _I16OFF_37_9_3_;
	O3405[1147] = + _I16OFF_43_9_3_;
	O3405[1148] = + _I16OFF_37_9_3_;
	O3405[1149] = + _I16OFF_37_10_3_;
	O3405[1150] = + _I16OFF_35_9_3_;
	O3405[1151] = + _I16OFF_37_9_3_;
	O3405[1152] = + _I16OFF_37_10_3_;
	O3405[1153] = + _I16OFF_36_9_3_;
	O3405[1154] = + _I16OFF_37_9_3_;
	O3405[1155] = + _I16OFF_41_9_3_;
	O3405[1156] = + _I16OFF_36_9_3_;
	O3405[1157] = + _I16OFF_40_12_3_;
	{long i; for (i = 1158; i < 1162; i++) O3405[i] = + _I16OFF_36_9_3_;}
	O3405[1162] = + _I16OFF_42_13_3_;
	O3405[1163] = + _I16OFF_44_13_3_;
	O3405[1164] = + _I16OFF_58_14_3_;
	O3405[1165] = + _I16OFF_51_13_3_;
	O3405[1166] = + _I16OFF_45_16_3_;
	O3405[1167] = + _I16OFF_44_13_3_;
	O3405[1168] = + _I16OFF_50_13_3_;
	O3405[1169] = + _I16OFF_51_14_3_;
	O3405[1170] = + _I16OFF_43_13_3_;
	O3405[1171] = + _I16OFF_46_14_3_;
	O3405[1172] = + _I16OFF_59_16_3_;
	O3405[1173] = + _I16OFF_44_15_3_;
	O3405[1174] = + _I16OFF_51_18_3_;
	{long i; for (i = 1175; i < 1179; i++) O3405[i] = + _I16OFF_46_14_3_;}
	O3405[1179] = + _I16OFF_16_5_3_;
	O3405[1180] = + _I16OFF_18_5_3_;
	O3405[1181] = + _I16OFF_23_5_3_;
	O3405[1182] = + _I16OFF_16_5_3_;
	{long i; for (i = 1183; i < 1185; i++) O3405[i] = + _I16OFF_20_5_3_;}
	{long i; for (i = 1185; i < 1187; i++) O3405[i] = + _I16OFF_25_6_3_;}
	{long i; for (i = 1187; i < 1189; i++) O3405[i] = + _I16OFF_21_7_3_;}
	{long i; for (i = 1189; i < 1193; i++) O3405[i] = + _I16OFF_17_6_3_;}
	O3405[1193] = + _I16OFF_18_6_3_;
	O3405[1194] = + _I16OFF_23_8_3_;
	{long i; for (i = 1195; i < 1197; i++) O3405[i] = + _I16OFF_23_9_3_;}
	O3405[1197] = + _I16OFF_24_9_3_;
	O3405[1198] = + _I16OFF_26_8_3_;
	O3405[1199] = + _I16OFF_19_5_3_;
	O3405[1200] = + _I16OFF_22_5_3_;
	{long i; for (i = 1201; i < 1203; i++) O3405[i] = + _I16OFF_21_10_3_;}
	{long i; for (i = 1203; i < 1205; i++) O3405[i] = + _I16OFF_29_14_3_;}
	O3405[1206] = + _I16OFF_36_10_3_;
	O3405[1208] = + _I16OFF_36_9_3_;
	O3405[1211] = + _I16OFF_48_19_3_;
	O3405[1213] = + _I16OFF_48_18_3_;
}

long O3620[4];
void O3620_init () {
	O3620[0] = + _CHROFF_2_0_;
	O3620[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O3620[i] = + _CHROFF_2_0_;}
}

long O3621[4];
void O3621_init () {
	O3621[0] = + _CHROFF_2_1_;
	O3621[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O3621[i] = + _CHROFF_2_1_;}
}

long O3689[167];
void O3689_init () {
	O3689[0] = 0;
	O3689[1] = + _LNGOFF_0_0_0_0_;
	O3689[2] = + _I64OFF_0_0_0_0_0_0_0_;
	O3689[3] = + _LNGOFF_0_0_0_0_;
	O3689[4] = + _CHROFF_0_0_;
	O3689[5] = 0;
	O3689[6] = + _LNGOFF_1_0_0_0_;
	O3689[7] = + _CHROFF_1_0_;
	{long i; for (i = 165; i < 167; i++) O3689[i] = 0;}
}

long O3693[3];
void O3693_init () {
	O3693[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O3693[i] = 0;}
}

static EIF_TYPE_INDEX Y4560_pgtype0[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype1[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype2[] = {0xFF01,836,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype3[] = {0xFF01,837,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype4[] = {0xFF01,838,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype5[] = {0xFF01,839,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype6[] = {0xFF01,840,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype7[] = {0xFF01,841,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype8[] = {0xFF01,842,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype9[] = {0xFF01,843,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype10[] = {0xFF01,844,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype11[] = {0xFF01,845,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype12[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype13[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype14[] = {0xFF01,836,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype15[] = {0xFF01,837,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype16[] = {0xFF01,838,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype17[] = {0xFF01,839,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype18[] = {0xFF01,840,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype19[] = {0xFF01,841,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype20[] = {0xFF01,842,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype21[] = {0xFF01,843,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype22[] = {0xFF01,844,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype23[] = {0xFF01,845,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype24[] = {0xFF01,836,1002,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype25[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype26[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype27[] = {0xFF01,836,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype28[] = {0xFF01,837,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype29[] = {0xFF01,838,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype30[] = {0xFF01,839,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype31[] = {0xFF01,840,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype32[] = {0xFF01,841,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype33[] = {0xFF01,842,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype34[] = {0xFF01,843,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype35[] = {0xFF01,844,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype36[] = {0xFF01,845,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype37[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype38[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype39[] = {0xFF01,841,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype40[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype41[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype42[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype43[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype44[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype45[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype46[] = {0xFF01,834,0xFF01,1094,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype47[] = {0xFF01,834,0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype48[] = {0xFF01,834,0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype49[] = {0xFF01,834,0xFF01,1040,0xFFF9,1,966,0xFF01,0,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype50[] = {0xFF01,834,0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype51[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype52[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype53[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype54[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype55[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype56[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1101,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype57[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,927,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype58[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,5,966,996,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype59[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1050,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype60[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1371,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype61[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype62[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,4,966,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype63[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,7,966,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype64[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,2,966,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype65[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,3,966,984,984,927,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype66[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,8,966,984,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype67[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype68[] = {0xFF01,836,1002,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype69[] = {0xFF01,836,1002,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype70[] = {0xFF01,842,972,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype71[] = {0xFF01,840,975,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype72[] = {0xFF01,840,975,0xFFFF};
static EIF_TYPE_INDEX Y4560_pgtype73[] = {0xFF01,834,0xFF01,1050,0xFFFF};
EIF_TYPE_INDEX *Y4560_gen_type [873];
EIF_TYPE_INDEX Y4560 [873];
void Y4560_init (void)
{
	egc_routines_types [4560] = Y4560;
	egc_routines_gen_types [4560] = Y4560_gen_type;
	egc_routines_offset [4560] = 292;
	Y4560_gen_type [0] = Y4560_pgtype0;
	Y4560_gen_type [1] = Y4560_pgtype1;
	Y4560_gen_type [2] = Y4560_pgtype2;
	Y4560_gen_type [3] = Y4560_pgtype3;
	Y4560_gen_type [4] = Y4560_pgtype4;
	Y4560_gen_type [5] = Y4560_pgtype5;
	Y4560_gen_type [6] = Y4560_pgtype6;
	Y4560_gen_type [7] = Y4560_pgtype7;
	Y4560_gen_type [8] = Y4560_pgtype8;
	Y4560_gen_type [9] = Y4560_pgtype9;
	Y4560_gen_type [10] = Y4560_pgtype10;
	Y4560_gen_type [11] = Y4560_pgtype11;
	Y4560_gen_type [285] = Y4560_pgtype12;
	Y4560_gen_type [286] = Y4560_pgtype13;
	Y4560_gen_type [287] = Y4560_pgtype14;
	Y4560_gen_type [288] = Y4560_pgtype15;
	Y4560_gen_type [289] = Y4560_pgtype16;
	Y4560_gen_type [290] = Y4560_pgtype17;
	Y4560_gen_type [291] = Y4560_pgtype18;
	Y4560_gen_type [292] = Y4560_pgtype19;
	Y4560_gen_type [293] = Y4560_pgtype20;
	Y4560_gen_type [294] = Y4560_pgtype21;
	Y4560_gen_type [295] = Y4560_pgtype22;
	Y4560_gen_type [296] = Y4560_pgtype23;
	Y4560_gen_type [297] = Y4560_pgtype24;
	Y4560_gen_type [364] = Y4560_pgtype25;
	Y4560_gen_type [365] = Y4560_pgtype26;
	Y4560_gen_type [366] = Y4560_pgtype27;
	Y4560_gen_type [367] = Y4560_pgtype28;
	Y4560_gen_type [368] = Y4560_pgtype29;
	Y4560_gen_type [369] = Y4560_pgtype30;
	Y4560_gen_type [370] = Y4560_pgtype31;
	Y4560_gen_type [371] = Y4560_pgtype32;
	Y4560_gen_type [372] = Y4560_pgtype33;
	Y4560_gen_type [373] = Y4560_pgtype34;
	Y4560_gen_type [374] = Y4560_pgtype35;
	Y4560_gen_type [375] = Y4560_pgtype36;
	Y4560_gen_type [376] = Y4560_pgtype37;
	Y4560_gen_type [377] = Y4560_pgtype38;
	Y4560_gen_type [378] = Y4560_pgtype39;
	Y4560_gen_type [379] = Y4560_pgtype40;
	Y4560_gen_type [380] = Y4560_pgtype41;
	Y4560_gen_type [381] = Y4560_pgtype42;
	Y4560_gen_type [382] = Y4560_pgtype43;
	Y4560_gen_type [383] = Y4560_pgtype44;
	Y4560_gen_type [384] = Y4560_pgtype45;
	Y4560_gen_type [385] = Y4560_pgtype46;
	Y4560_gen_type [386] = Y4560_pgtype47;
	Y4560_gen_type [387] = Y4560_pgtype48;
	Y4560_gen_type [388] = Y4560_pgtype49;
	Y4560_gen_type [389] = Y4560_pgtype50;
	Y4560_gen_type [390] = Y4560_pgtype51;
	Y4560_gen_type [391] = Y4560_pgtype52;
	Y4560_gen_type [392] = Y4560_pgtype53;
	Y4560_gen_type [393] = Y4560_pgtype54;
	Y4560_gen_type [394] = Y4560_pgtype55;
	Y4560_gen_type [395] = Y4560_pgtype56;
	Y4560_gen_type [396] = Y4560_pgtype57;
	Y4560_gen_type [397] = Y4560_pgtype58;
	Y4560_gen_type [398] = Y4560_pgtype59;
	Y4560_gen_type [399] = Y4560_pgtype60;
	Y4560_gen_type [400] = Y4560_pgtype61;
	Y4560_gen_type [401] = Y4560_pgtype62;
	Y4560_gen_type [402] = Y4560_pgtype63;
	Y4560_gen_type [403] = Y4560_pgtype64;
	Y4560_gen_type [404] = Y4560_pgtype65;
	Y4560_gen_type [405] = Y4560_pgtype66;
	Y4560_gen_type [406] = Y4560_pgtype67;
	Y4560_gen_type [409] = Y4560_pgtype68;
	Y4560_gen_type [410] = Y4560_pgtype69;
	Y4560_gen_type [758] = Y4560_pgtype70;
	Y4560_gen_type [761] = Y4560_pgtype71;
	Y4560_gen_type [762] = Y4560_pgtype72;
	Y4560_gen_type [872] = Y4560_pgtype73;
	Y4560[0] = 834;
	Y4560[1] = 835;
	Y4560[2] = 836;
	Y4560[3] = 837;
	Y4560[4] = 838;
	Y4560[5] = 839;
	Y4560[6] = 840;
	Y4560[7] = 841;
	Y4560[8] = 842;
	Y4560[9] = 843;
	Y4560[10] = 844;
	Y4560[11] = 845;
	Y4560[285] = 834;
	Y4560[286] = 835;
	Y4560[287] = 836;
	Y4560[288] = 837;
	Y4560[289] = 838;
	Y4560[290] = 839;
	Y4560[291] = 840;
	Y4560[292] = 841;
	Y4560[293] = 842;
	Y4560[294] = 843;
	Y4560[295] = 844;
	Y4560[296] = 845;
	Y4560[297] = 836;
	Y4560[364] = 834;
	Y4560[365] = 835;
	Y4560[366] = 836;
	Y4560[367] = 837;
	Y4560[368] = 838;
	Y4560[369] = 839;
	Y4560[370] = 840;
	Y4560[371] = 841;
	Y4560[372] = 842;
	Y4560[373] = 843;
	Y4560[374] = 844;
	Y4560[375] = 845;
	Y4560[376] = 834;
	Y4560[377] = 835;
	Y4560[378] = 841;
	Y4560[379] = 834;
	Y4560[380] = 835;
	Y4560[381] = 834;
	Y4560[382] = 835;
	Y4560[383] = 834;
	Y4560[384] = 835;
	{long i; for (i = 385; i < 407; i++) Y4560[i] = 834;};
	{long i; for (i = 409; i < 411; i++) Y4560[i] = 836;};
	Y4560[758] = 842;
	{long i; for (i = 761; i < 763; i++) Y4560[i] = 840;};
	Y4560[872] = 834;
}


#ifdef __cplusplus
}
#endif
