
#ifndef _C17_dy847_
#define _C17_dy847_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F431_5195(EIF_REFERENCE);
extern void EIF_Minit847(void);

#ifdef __cplusplus
}
#endif

#endif
