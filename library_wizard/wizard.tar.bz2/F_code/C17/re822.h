
#ifndef _C17_re822_
#define _C17_re822_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F553_5291(EIF_REFERENCE);
extern void EIF_Minit822(void);
extern void F759_6187(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5519[])();
extern EIF_TYPE_INDEX Y4756[];
extern EIF_TYPE_INDEX *Y4756_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
