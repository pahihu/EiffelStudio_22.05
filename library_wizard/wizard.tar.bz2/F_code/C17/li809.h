
#ifndef _C17_li809_
#define _C17_li809_

#ifdef __cplusplus
extern "C" {
#endif

extern void F247_4244(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN);
extern void EIF_Minit809(void);

#ifdef __cplusplus
}
#endif

#endif
