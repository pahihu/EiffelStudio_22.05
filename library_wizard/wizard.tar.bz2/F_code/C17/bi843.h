
#ifndef _C17_bi843_
#define _C17_bi843_

#ifdef __cplusplus
extern "C" {
#endif

extern void F376_5172(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit843(void);
extern EIF_BOOLEAN F484_5229(EIF_REFERENCE);
extern void F364_5155(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R4932[])();
extern char *(*R4933[])();

#ifdef __cplusplus
}
#endif

#endif
