
#ifndef _C17_li819_
#define _C17_li819_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F364_5153(EIF_REFERENCE, EIF_INTEGER_32);
extern void F364_5155(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F364_5159(EIF_REFERENCE);
extern EIF_BOOLEAN F364_5161(EIF_REFERENCE);
extern EIF_REFERENCE F364_5168(EIF_REFERENCE);
extern void EIF_Minit819(void);
extern char *(*R4917[])();
extern char *(*R4918[])();
extern char *(*R4919[])();
extern char *(*R4808[])();
extern char *(*R4925[])();
extern char *(*R4930[])();
extern char *(*R4932[])();
extern long O4810[];

#ifdef __cplusplus
}
#endif

#endif
