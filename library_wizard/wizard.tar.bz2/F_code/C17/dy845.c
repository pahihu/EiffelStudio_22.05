/*
 * Code for class DYNAMIC_CHAIN [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dy845.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DYNAMIC_CHAIN}.extendible */
EIF_BOOLEAN F604_5449 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {DYNAMIC_CHAIN}.prune */
void F604_5455 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4925[dtype-638])(Current, (EIF_REFERENCE) &arg1);
	if ((EIF_BOOLEAN) !F364_5159(Current)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4958[dtype-638])(Current);
	}
	RTLE;
}

/* {DYNAMIC_CHAIN}.prune_all */
void F604_5456 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4919[dtype-638])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4925[dtype-638])(Current, (EIF_REFERENCE) &arg1);
	for (;;) {
		if (F364_5159(Current)) break;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4958[dtype-638])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4925[dtype-638])(Current, (EIF_REFERENCE) &arg1);
	}
	RTLE;
}

void EIF_Minit845 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
