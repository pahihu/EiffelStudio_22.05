
#ifndef _C17_ch848_
#define _C17_ch848_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F592_5425(EIF_REFERENCE);
extern EIF_INTEGER_32 F592_5426(EIF_REFERENCE);
extern EIF_BOOLEAN F592_5427(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F592_5429(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F592_5430(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F592_5432(EIF_REFERENCE);
extern void F592_5434(EIF_REFERENCE);
extern EIF_BOOLEAN F592_5437(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F592_5438(EIF_REFERENCE);
extern EIF_BOOLEAN F592_5440(EIF_REFERENCE);
extern void F592_5445(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit848(void);
extern EIF_BOOLEAN F484_5229(EIF_REFERENCE);
extern EIF_BOOLEAN F604_5449(EIF_REFERENCE);
extern EIF_BOOLEAN F364_5153(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R4953[])();
extern char *(*R4959[])();
extern char *(*R4917[])();
extern char *(*R4918[])();
extern char *(*R4919[])();
extern char *(*R4961[])();
extern char *(*R5078[])();
extern char *(*R4965[])();
extern char *(*R4926[])();
extern char *(*R4814[])();
extern char *(*R4931[])();
extern char *(*R4932[])();
extern char *(*R4939[])();

#ifdef __cplusplus
}
#endif

#endif
