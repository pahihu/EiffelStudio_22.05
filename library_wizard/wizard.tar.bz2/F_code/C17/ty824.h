
#ifndef _C17_ty824_
#define _C17_ty824_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F747_6181(EIF_REFERENCE);
extern void EIF_Minit824(void);
extern char *(*R5520[])();
extern char *(*R5507[])();
extern char *(*R4988[])();

#ifdef __cplusplus
}
#endif

#endif
