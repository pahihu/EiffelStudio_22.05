
#ifndef _C17_li849_
#define _C17_li849_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F616_5463(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F616_5464(EIF_REFERENCE);
extern EIF_BOOLEAN F616_5465(EIF_REFERENCE);
extern void EIF_Minit849(void);
extern EIF_BOOLEAN F484_5229(EIF_REFERENCE);
extern char *(*R4953[])();
extern char *(*R4959[])();
extern char *(*R4919[])();
extern char *(*R4961[])();
extern char *(*R4965[])();
extern char *(*R4926[])();
extern char *(*R4930[])();
extern char *(*R4932[])();
extern long O4810[];

#ifdef __cplusplus
}
#endif

#endif
