
#ifndef _C17_se842_
#define _C17_se842_

#ifdef __cplusplus
extern "C" {
#endif

extern void F520_5242(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit842(void);
extern char *(*R4939[])();

#ifdef __cplusplus
}
#endif

#endif
