
#ifndef _C17_co821_
#define _C17_co821_

#ifdef __cplusplus
extern "C" {
#endif

extern void F337_5000(EIF_REFERENCE);
extern void F337_5001(EIF_REFERENCE);
extern void EIF_Minit821(void);
extern long O4810[];

#ifdef __cplusplus
}
#endif

#endif
