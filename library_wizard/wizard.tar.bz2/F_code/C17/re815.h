
#ifndef _C17_re815_
#define _C17_re815_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F508_5235(EIF_REFERENCE);
extern void F508_5237(EIF_REFERENCE);
extern void EIF_Minit815(void);
extern char *(*R4966[])();
extern char *(*R4972[])();

#ifdef __cplusplus
}
#endif

#endif
