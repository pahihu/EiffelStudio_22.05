
#ifndef _C17_ev803_
#define _C17_ev803_

#ifdef __cplusplus
extern "C" {
#endif

extern void F680_5873(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit803(void);
extern EIF_INTEGER_32 F657_5740(EIF_REFERENCE);
extern EIF_REFERENCE F242_3970(EIF_REFERENCE);
extern EIF_REFERENCE F1207_11244(EIF_REFERENCE);
extern void F1212_11361(EIF_REFERENCE);
extern void F679_5839(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,3970)

#ifdef __cplusplus
}
#endif

#endif
