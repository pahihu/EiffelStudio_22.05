
#ifndef _C17_ar832_
#define _C17_ar832_

#ifdef __cplusplus
extern "C" {
#endif

extern void F792_6241(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F792_6242(EIF_REFERENCE);
extern EIF_REFERENCE F792_6243(EIF_REFERENCE);
extern EIF_REFERENCE F792_6245(EIF_REFERENCE);
extern EIF_INTEGER_32 F792_6246(EIF_REFERENCE);
extern void EIF_Minit832(void);
extern EIF_REFERENCE F658_5723(EIF_REFERENCE);
extern EIF_INTEGER_32 F658_5742(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5447[];
extern EIF_TYPE_INDEX *Y5447_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
