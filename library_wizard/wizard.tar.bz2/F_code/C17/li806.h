
#ifndef _C17_li806_
#define _C17_li806_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F770_6209(EIF_REFERENCE);
extern EIF_BOOLEAN F770_6210(EIF_REFERENCE);
extern void F770_6211(EIF_REFERENCE);
extern void F770_6212(EIF_REFERENCE);
extern EIF_REFERENCE F770_6213(EIF_REFERENCE);
extern void EIF_Minit806(void);
extern EIF_BOOLEAN F758_6199(EIF_REFERENCE);
extern void F758_6207(EIF_REFERENCE);
extern void F758_6206(EIF_REFERENCE);
extern EIF_REFERENCE F746_6181(EIF_REFERENCE);
extern char *(*R3689[])();
extern char *(*R5516[])();
extern long O3693[];

#ifdef __cplusplus
}
#endif

#endif
