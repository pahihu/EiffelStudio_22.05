
#ifndef _C17_to841_
#define _C17_to841_

#ifdef __cplusplus
extern "C" {
#endif

extern void F294_4739(EIF_REFERENCE, EIF_INTEGER_32);
extern void F294_4740(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F294_4746(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit841(void);
extern void F836_6401(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4560[];
extern EIF_TYPE_INDEX *Y4560_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
