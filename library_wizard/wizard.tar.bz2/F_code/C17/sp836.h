
#ifndef _C17_sp836_
#define _C17_sp836_

#ifdef __cplusplus
extern "C" {
#endif

extern void F818_6265(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F818_6266(EIF_REFERENCE);
extern EIF_REFERENCE F818_6267(EIF_REFERENCE);
extern EIF_INTEGER_32 F818_6268(EIF_REFERENCE);
extern void EIF_Minit836(void);
extern EIF_INTEGER_32 F836_6412(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5447[];
extern EIF_TYPE_INDEX *Y5447_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
