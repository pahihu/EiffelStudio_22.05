
#ifndef _C17_dy845_
#define _C17_dy845_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F604_5449(EIF_REFERENCE);
extern void F604_5455(EIF_REFERENCE, EIF_INTEGER_32);
extern void F604_5456(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit845(void);
extern EIF_BOOLEAN F364_5159(EIF_REFERENCE);
extern char *(*R4958[])();
extern char *(*R4919[])();
extern char *(*R4925[])();

#ifdef __cplusplus
}
#endif

#endif
