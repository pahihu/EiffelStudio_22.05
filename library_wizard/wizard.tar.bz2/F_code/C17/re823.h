
#ifndef _C17_re823_
#define _C17_re823_

#ifdef __cplusplus
extern "C" {
#endif

extern void F759_6187(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F759_6189(EIF_REFERENCE);
extern EIF_INTEGER_32 F759_6190(EIF_REFERENCE);
extern EIF_INTEGER_32 F759_6191(EIF_REFERENCE);
extern EIF_INTEGER_32 F759_6192(EIF_REFERENCE);
extern EIF_REFERENCE F759_6193(EIF_REFERENCE);
extern EIF_BOOLEAN F759_6199(EIF_REFERENCE);
extern EIF_BOOLEAN F759_6200(EIF_REFERENCE);
extern EIF_BOOLEAN F759_6201(EIF_REFERENCE);
extern void F759_6206(EIF_REFERENCE);
extern void F759_6207(EIF_REFERENCE);
extern EIF_REFERENCE F759_6208(EIF_REFERENCE);
extern void EIF_Minit823(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R4989[])();
extern char *(*R4990[])();
extern char *(*R4992[])();
extern char *(*R5519[])();
extern long O5523[];
extern long O5527[];
extern long O5528[];
extern long O5529[];
extern long O5530[];
extern long O5531[];

#ifdef __cplusplus
}
#endif

#endif
