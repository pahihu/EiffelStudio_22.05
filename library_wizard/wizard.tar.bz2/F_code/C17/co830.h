
#ifndef _C17_co830_
#define _C17_co830_

#ifdef __cplusplus
extern "C" {
#endif

extern void F388_5180(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit830(void);
extern char *(*R4941[])();
extern char *(*R4807[])();

#ifdef __cplusplus
}
#endif

#endif
