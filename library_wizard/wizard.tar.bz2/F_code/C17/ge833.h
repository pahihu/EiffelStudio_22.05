
#ifndef _C17_ge833_
#define _C17_ge833_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F780_6221(EIF_REFERENCE);
extern EIF_INTEGER_32 F780_6223(EIF_REFERENCE);
extern EIF_BOOLEAN F780_6230(EIF_REFERENCE);
extern void F780_6235(EIF_REFERENCE);
extern void F780_6236(EIF_REFERENCE);
extern EIF_REFERENCE F780_6237(EIF_REFERENCE);
extern void EIF_Minit833(void);
extern char *(*R5535[])();
extern char *(*R5508[])();
extern long O5534[];
extern long O5536[];

#ifdef __cplusplus
}
#endif

#endif
