
#ifndef _C17_li805_
#define _C17_li805_

#ifdef __cplusplus
extern "C" {
#endif

extern void F639_5475(EIF_REFERENCE);
extern EIF_REFERENCE F639_5477(EIF_REFERENCE);
extern EIF_REFERENCE F639_5478(EIF_REFERENCE);
extern EIF_REFERENCE F639_5479(EIF_REFERENCE);
extern EIF_INTEGER_32 F639_5480(EIF_REFERENCE);
extern EIF_REFERENCE F639_5481(EIF_REFERENCE);
extern EIF_REFERENCE F639_5482(EIF_REFERENCE);
extern EIF_INTEGER_32 F639_5484(EIF_REFERENCE);
extern EIF_BOOLEAN F639_5486(EIF_REFERENCE);
extern EIF_BOOLEAN F639_5487(EIF_REFERENCE);
extern EIF_BOOLEAN F639_5488(EIF_REFERENCE);
extern EIF_BOOLEAN F639_5489(EIF_REFERENCE);
extern EIF_BOOLEAN F639_5490(EIF_REFERENCE);
extern void F639_5494(EIF_REFERENCE);
extern void F639_5495(EIF_REFERENCE);
extern void F639_5496(EIF_REFERENCE);
extern void F639_5498(EIF_REFERENCE, EIF_INTEGER_32);
extern void F639_5499(EIF_REFERENCE, EIF_INTEGER_32);
extern void F639_5500(EIF_REFERENCE, EIF_REFERENCE);
extern void F639_5501(EIF_REFERENCE, EIF_REFERENCE);
extern void F639_5502(EIF_REFERENCE, EIF_REFERENCE);
extern void F639_5505(EIF_REFERENCE, EIF_REFERENCE);
extern void F639_5508(EIF_REFERENCE);
extern void F639_5509(EIF_REFERENCE);
extern void F639_5510(EIF_REFERENCE);
extern void F639_5512(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F639_5514(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F639_5515(EIF_REFERENCE);
extern EIF_REFERENCE F639_5518(EIF_REFERENCE);
extern void F639_5519(EIF_REFERENCE, EIF_REFERENCE);
extern void F639_5520(EIF_REFERENCE);
extern void EIF_Minit805(void);
extern char *(*R4122[])();
extern char *(*R5522[])();
extern char *(*R4953[])();
extern char *(*R5100[])();
extern char *(*R5101[])();
extern char *(*R5102[])();
extern char *(*R4959[])();
extern char *(*R4918[])();
extern char *(*R4919[])();
extern char *(*R4961[])();
extern char *(*R5077[])();
extern char *(*R5079[])();
extern char *(*R3689[])();
extern char *(*R4808[])();
extern char *(*R4926[])();
extern char *(*R5097[])();
extern char *(*R5080[])();
extern char *(*R3690[])();
extern char *(*R3694[])();
extern char *(*R3695[])();
extern char *(*R4931[])();
extern char *(*R4932[])();
extern char *(*R4939[])();
extern char *(*R5091[])();
extern char *(*R5519[])();
extern char *(*R5096[])();
extern long O3693[];
extern EIF_TYPE_INDEX Y4756[];
extern EIF_TYPE_INDEX *Y4756_gen_type [];
extern EIF_TYPE_INDEX Y4953[];
extern EIF_TYPE_INDEX *Y4953_gen_type [];
extern EIF_TYPE_INDEX Y4959[];
extern EIF_TYPE_INDEX *Y4959_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
