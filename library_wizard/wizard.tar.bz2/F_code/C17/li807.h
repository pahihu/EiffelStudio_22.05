
#ifndef _C17_li807_
#define _C17_li807_

#ifdef __cplusplus
extern "C" {
#endif

extern void F189_3756(EIF_REFERENCE, EIF_REFERENCE);
extern void F189_3757(EIF_REFERENCE);
extern void EIF_Minit807(void);
extern long O3693[];

#ifdef __cplusplus
}
#endif

#endif
