
#ifndef _C17_li804_
#define _C17_li804_

#ifdef __cplusplus
extern "C" {
#endif

extern void F645_5535(EIF_REFERENCE);
extern EIF_REFERENCE F645_5537(EIF_REFERENCE);
extern void F645_5539(EIF_REFERENCE, EIF_REFERENCE);
extern void F645_5540(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F645_5541(EIF_REFERENCE);
extern void F645_5543(EIF_REFERENCE, EIF_REFERENCE);
extern void F645_5544(EIF_REFERENCE, EIF_REFERENCE);
extern void F645_5545(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit804(void);
extern void F639_5500(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F639_5477(EIF_REFERENCE);
extern void F639_5520(EIF_REFERENCE);
extern EIF_BOOLEAN F483_5229(EIF_REFERENCE);
extern EIF_REFERENCE F639_5481(EIF_REFERENCE);
extern EIF_BOOLEAN F639_5488(EIF_REFERENCE);
extern void F639_5501(EIF_REFERENCE, EIF_REFERENCE);
extern void F639_5496(EIF_REFERENCE);
extern void F639_5494(EIF_REFERENCE);
extern void F639_5502(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4953[])();
extern char *(*R3689[])();
extern char *(*R5230[])();
extern char *(*R4931[])();
extern char *(*R4933[])();
extern char *(*R4934[])();
extern char *(*R4939[])();
extern EIF_TYPE_INDEX Y4756[];
extern EIF_TYPE_INDEX *Y4756_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
