
#ifndef _C17_in813_
#define _C17_in813_

#ifdef __cplusplus
extern "C" {
#endif

extern void F672_5797(EIF_REFERENCE);
extern void F672_5802(EIF_REFERENCE, EIF_REFERENCE);
extern void F672_5803(EIF_REFERENCE, EIF_REFERENCE);
extern void F672_5804(EIF_REFERENCE, EIF_REFERENCE);
extern void F672_5806(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F672_5807(EIF_REFERENCE, EIF_REFERENCE);
extern void F672_5808(EIF_REFERENCE);
extern void F672_5812(EIF_REFERENCE, EIF_REFERENCE);
extern void F672_5814(EIF_REFERENCE);
extern void F672_5817(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F672_5818(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit813(void);
extern void F657_5761(EIF_REFERENCE, EIF_REFERENCE);
extern void F657_5778(EIF_REFERENCE);
extern void F657_5763(EIF_REFERENCE, EIF_REFERENCE);
extern void F657_5758(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F657_5760(EIF_REFERENCE, EIF_REFERENCE);
extern void F657_5773(EIF_REFERENCE);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R5444[])();
extern char *(*R5445[])();
extern char *(*R5446[])();
extern char *(*R4988[])();
extern char *(*R4946[])();
extern char *(*R5253[])();
extern char *(*R5254[])();
extern char *(*R4755[])();
extern char *(*R4953[])();
extern char *(*R5698[])();
extern char *(*R4965[])();
extern char *(*R4966[])();
extern char *(*R5230[])();
extern char *(*R5234[])();
extern char *(*R5684[])();
extern char *(*R4972[])();
extern char *(*R4939[])();
extern char *(*R5248[])();
extern char *(*R5249[])();
extern long O4810[];
extern long O5244[];
extern long O5252[];

#ifdef __cplusplus
}
#endif

#endif
