
#ifndef _C17_fi826_
#define _C17_fi826_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F484_5229(EIF_REFERENCE);
extern void EIF_Minit826(void);
extern char *(*R4965[])();

#ifdef __cplusplus
}
#endif

#endif
