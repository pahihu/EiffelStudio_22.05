
#ifndef _C17_ce808_
#define _C17_ce808_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F184_3752(EIF_REFERENCE);
extern void F184_3753(EIF_REFERENCE, EIF_REFERENCE);
extern void F184_3754(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit808(void);
extern long O3689[];

#ifdef __cplusplus
}
#endif

#endif
