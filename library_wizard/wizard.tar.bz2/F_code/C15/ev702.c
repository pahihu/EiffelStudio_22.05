/*
 * Code for class EV_MENU_ITEM_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev702.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F28_739
static EIF_NATURAL_8 inline_F28_739 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F28_739
#endif
#ifndef INLINE_F106_2576
static EIF_POINTER inline_F106_2576 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F106_2576
#endif
#ifndef INLINE_F107_2792
static void inline_F107_2792 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_xalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F107_2792
#endif
#ifndef INLINE_F107_2793
static void inline_F107_2793 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_yalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F107_2793
#endif
#ifndef INLINE_F107_2600
static EIF_POINTER inline_F107_2600 (void)
{
	return gtk_settings_get_default();
	;
}
#define INLINE_F107_2600
#endif
#ifndef INLINE_F34_881
static EIF_POINTER inline_F34_881 (void)
{
	static char *v = "gtk-menu-images";
return (EIF_POINTER) v;
	;
}
#define INLINE_F34_881
#endif
#ifndef INLINE_F105_2453
static void inline_F105_2453 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	g_object_set((gpointer) arg1, (gchar*) arg2, arg3 ? TRUE : FALSE, NULL)
	;
}
#define INLINE_F105_2453
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MENU_ITEM_IMP}.make */
RTEOMS(13522,1);
void F1347_13523 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	F1347_13524(Current);
	F1215_11586(Current);
	tp1 = F1347_13529(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,966,0xFF01,928,1038,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	tr2 = *(EIF_REFERENCE *)(RTCV(RTOSCF(11584,F1214_11584, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
	RTAR(tr1,tr2);
	tp2 = *(EIF_POINTER *)(Current + O9348[dtype-1213]);
	((EIF_TYPED_VALUE *)tr1+2)->it_p = tp2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2= RTLNRF(typres0.id, (EIF_POINTER) __A360_338, (EIF_POINTER) _A360_338, (EIF_POINTER)(F927_7592),tr1, 1, 0);
	}
	F1214_11564(Current, tp1, RTOMS(13522,0), tr2);
	F1251_11982(Current);
	tu1_1 = inline_F28_739();
	loc1 = inline_F106_2576(tu1_1, ((EIF_INTEGER_32) 0L));
	tp1 = F1347_13529(Current);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) loc1);
	gtk_widget_show((GtkWidget*) loc1);
	tp1 = *(EIF_POINTER *)(Current + O9677[dtype-1246]);
	tb1 = !tp1;
	if (tb1) {
		F1247_11960(Current);
		tp1 = *(EIF_POINTER *)(Current + O9677[dtype-1246]);
		gtk_box_pack_start((GtkBox*) loc1, (GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	}
	tp1 = *(EIF_POINTER *)(Current + O9691[dtype-1250]);
	gtk_box_pack_start((GtkBox*) loc1, (GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	tp1 = (EIF_POINTER) gtk_label_new((gchar*) tp2);
	*(EIF_POINTER *)(Current + O10485[dtype-1346]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O10485[dtype-1346]);
	inline_F107_2792(tp1, (EIF_REAL_32) 1.0);
	tp1 = *(EIF_POINTER *)(Current + O10485[dtype-1346]);
	inline_F107_2793(tp1, (EIF_REAL_32) 0.5);
	tp1 = *(EIF_POINTER *)(Current + O10485[dtype-1346]);
	gtk_box_pack_start((GtkBox*) loc1, (GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 1, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 2L));
	tp1 = *(EIF_POINTER *)(Current + O10485[dtype-1346]);
	ti4_1 = (EIF_INTEGER_32) GTK_JUSTIFY_RIGHT;
	gtk_label_set_justify((GtkLabel*) tp1, (GtkJustification) ti4_1);
	tp1 = inline_F107_2600();
	tp2 = inline_F34_881();
	inline_F105_2453(tp1, tp2, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_MENU_ITEM_IMP}.initialize_menu_item */
void F1347_13524 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (EIF_POINTER) gtk_menu_item_new();
	F1214_11559(Current, tp1);
	F1247_11960(Current);
	F1347_13530(Current);
	RTLE;
}

/* {EV_MENU_ITEM_IMP}.needs_event_box */
EIF_BOOLEAN F1347_13525 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

/* {EV_MENU_ITEM_IMP}.is_dockable */
EIF_BOOLEAN F1347_13526 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

/* {EV_MENU_ITEM_IMP}.set_text */
void F1347_13528 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\011';
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_CHARACTER_32)) R7505[Dtype(RTCW(arg1))-1049])(arg1, tw1);
	if (tb1) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\011';
		loc1 = F1046_9063(RTCW(arg1), tw1);
	}
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4965[Dtype(RTCW(loc1))-575])(loc1);
		tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L));
	}
	if (tb1) {
		ti4_1 = ((EIF_INTEGER_32) 1L);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4947[Dtype(RTCW(loc1))-577])(loc1, (EIF_REFERENCE) &ti4_1);
		F1251_11988(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(Current + O9693[dtype-1250]);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\011';
			F1051_9243(loc3, tw1);
			ti4_1 = ((EIF_INTEGER_32) 2L);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4947[Dtype(RTCW(loc1))-577])(loc1, (EIF_REFERENCE) &ti4_1);
			F1051_9229(loc3, tr1);
		} else {
		}
		loc2 = RTLNS(eif_new_type(910, 0x00).id, 910, _OBJSIZ_0_1_0_1_0_1_0_0_);
		tr1 = RTMS32_EX_H(" \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000",12,286432288);
		ti4_1 = ((EIF_INTEGER_32) 2L);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4947[Dtype(RTCW(loc1))-577])(loc1, (EIF_REFERENCE) &ti4_1);
		tr2 = F1046_9044(RTCW(tr2));
		tr1 = F1051_9249(tr1, tr2);
		F911_6701(RTCW(loc2), tr1);
		tp1 = *(EIF_POINTER *)(Current + O10485[dtype-1346]);
		tp2 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_0_1_0_1_0_0_);
		gtk_label_set_text((GtkLabel*) tp1, (gchar*) tp2);
		tp1 = *(EIF_POINTER *)(Current + O10485[dtype-1346]);
		gtk_widget_show((GtkWidget*) tp1);
	} else {
		F1251_11988(Current, arg1);
		tp1 = *(EIF_POINTER *)(Current + O10485[dtype-1346]);
		gtk_widget_hide((GtkWidget*) tp1);
	}
	RTLE;
}

/* {EV_MENU_ITEM_IMP}.menu_item */
EIF_POINTER F1347_13529 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) *(EIF_POINTER *)(Current + O9348[Dtype(Current)-1213]);
}

/* {EV_MENU_ITEM_IMP}.image_menu_item_new */
void F1347_13530 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1347_13529(Current);
	gtk_widget_show((GtkWidget*) tp1);
	RTLE;
}

/* {EV_MENU_ITEM_IMP}.allow_on_activate */
EIF_BOOLEAN F1347_13531 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1340_13503(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != NULL);
	RTLE;
	return Result;
}

/* {EV_MENU_ITEM_IMP}.accelerators_enabled */
EIF_BOOLEAN F1347_13532 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {EV_MENU_ITEM_IMP}.on_activate */
void F1347_13533 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	tr1 = F1340_13503(Current);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1224, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F91_1684(loc1);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,966,0xFF01,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y8822,Y8822_gen_type,Dftype(Current),1187);
					typarr0[5] = l_type.annotations | 0xFF00;
					typarr0[6] = l_type.id;
				}
				
				typres0 = eif_compound_id(Dftype(Current), typarr0);
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F1188_10859(Current);
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			F680_5873(RTCW(tr1), tr2);
		}
		tp1 = *(EIF_POINTER *)(loc1+ _PTROFF_26_8_6_2_0_4_);
		gtk_menu_shell_deactivate((GtkMenuShell*) tp1);
	}
	tp1 = F1347_13529(Current);
	gtk_menu_item_deselect((GtkMenuItem*) tp1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O1776[dtype-101]) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + O1776[dtype-101]);
		F680_5873(RTCW(tr1), NULL);
	}
	RTLE;
}

void EIF_Minit702 (void)
{
	GTCX
	RTPOMS(13522,0,"activate",8,526134885);
}


#ifdef __cplusplus
}
#endif
