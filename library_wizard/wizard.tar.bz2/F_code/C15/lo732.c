/*
 * Code for class LOCALIZED_PRINTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lo732.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LOCALIZED_PRINTER}.localized_print */
void F1377_14187 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = arg1;
		loc1 = RTRV(eif_new_type(1051, 0x01),loc1);
		if (EIF_TEST(loc1)) {
			tr1 = RTOSCF(24,F1_24, (Current));
			F66_1414(RTCW(tr1), loc1);
		} else {
			tr1 = RTOSCF(24,F1_24, (Current));
			tr2 = F1046_9045(RTCW(arg1));
			F66_1416(RTCW(tr1), tr2);
		}
	}
	RTLE;
}

void EIF_Minit732 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
