
#ifndef _C15_ec743_
#define _C15_ec743_

#ifdef __cplusplus
extern "C" {
#endif
RTOSHF (EIF_REFERENCE, 14721)


extern EIF_REFERENCE F1388_14721(EIF_REFERENCE);
extern void EIF_Minit743(void);

#ifdef __cplusplus
}
#endif

#endif
