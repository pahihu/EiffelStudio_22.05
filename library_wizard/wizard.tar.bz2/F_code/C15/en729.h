
#ifndef _C15_en729_
#define _C15_en729_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1374_14141(EIF_REFERENCE);
extern EIF_REFERENCE F1374_14142(EIF_REFERENCE);
extern void EIF_Minit729(void);
extern EIF_REFERENCE F147_3347(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1046_9044(EIF_REFERENCE);
extern EIF_REFERENCE F147_3348(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
