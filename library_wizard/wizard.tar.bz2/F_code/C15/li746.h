
#ifndef _C15_li746_
#define _C15_li746_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F615_5463(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F615_5464(EIF_REFERENCE);
extern EIF_BOOLEAN F615_5465(EIF_REFERENCE);
extern void EIF_Minit746(void);
extern char *(*R4953[])();
extern char *(*R4959[])();
extern char *(*R4919[])();
extern char *(*R4961[])();
extern char *(*R4965[])();
extern char *(*R4808[])();
extern char *(*R4926[])();
extern char *(*R4930[])();
extern char *(*R4932[])();
extern long O4810[];

#ifdef __cplusplus
}
#endif

#endif
