
#ifndef _C15_co747_
#define _C15_co747_

#ifdef __cplusplus
extern "C" {
#endif

extern void F336_5000(EIF_REFERENCE);
extern void F336_5001(EIF_REFERENCE);
extern void EIF_Minit747(void);
extern long O4810[];

#ifdef __cplusplus
}
#endif

#endif
