/*
 * Code for class EV_DRAWABLE_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev713.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DRAWABLE_I}.is_in_drawing_session */
EIF_BOOLEAN F1358_13691 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O10547[Dtype(Current)-1357]) > ((EIF_INTEGER_32) 0L));
}

/* {EV_DRAWABLE_I}.is_in_top_drawing_session */
EIF_BOOLEAN F1358_13692 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O10547[Dtype(Current)-1357]) == ((EIF_INTEGER_32) 1L));
}

/* {EV_DRAWABLE_I}.start_drawing_session */
void F1358_13694 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	(*(EIF_INTEGER_32 *)(Current + O10547[dtype-1357]))++;
}

/* {EV_DRAWABLE_I}.end_drawing_session */
void F1358_13695 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	(*(EIF_INTEGER_32 *)(Current + O10547[dtype-1357]))--;
}

void EIF_Minit713 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
