
#ifndef _C15_lo732_
#define _C15_lo732_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1377_14187(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit732(void);
extern EIF_REFERENCE F1046_9045(EIF_REFERENCE);
extern void F66_1416(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1_24(EIF_REFERENCE);
extern void F66_1414(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,24)

#ifdef __cplusplus
}
#endif

#endif
