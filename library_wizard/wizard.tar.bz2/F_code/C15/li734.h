
#ifndef _C15_li734_
#define _C15_li734_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1379_14203(EIF_REFERENCE);
extern EIF_REFERENCE F1379_14204(EIF_REFERENCE);
extern void EIF_Minit734(void);
extern void F1378_14193(EIF_REFERENCE);
extern void F310_4864(EIF_REFERENCE);
extern void F129_3062(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
