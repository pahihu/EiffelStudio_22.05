/*
 * Code for class LIBRARY_CONSOLE_WIZARD_APPLICATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li734.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LIBRARY_CONSOLE_WIZARD_APPLICATION}.make */
void F1379_14203 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F310_4864(Current);
	F1378_14193(Current);
	RTLE;
}

/* {LIBRARY_CONSOLE_WIZARD_APPLICATION}.new_wizard */
EIF_REFERENCE F1379_14204 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(129, 0x01).id, 129, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F129_3062(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit734 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
