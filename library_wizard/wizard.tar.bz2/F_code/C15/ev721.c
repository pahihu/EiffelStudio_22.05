/*
 * Code for class EV_PIXMAP_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev721.h"
#include <ev_gtk.h>
#include "ev_gtk.h"
#include <cairo.h>
#include "ev_c_util.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F107_2660
static void inline_F107_2660 (EIF_POINTER arg1)
{
	gtk_widget_queue_draw ((GtkWidget *)arg1)
	;
}
#define INLINE_F107_2660
#endif
#ifndef INLINE_F104_2006
static EIF_POINTER inline_F104_2006 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_get_from_surface ((cairo_surface_t *) arg1, (gint) arg2, (gint) arg3, (gint) arg4, (gint) arg5);
	;
}
#define INLINE_F104_2006
#endif
#ifndef INLINE_F104_1997
static EIF_POINTER inline_F104_1997 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	return (EIF_POINTER) (gdk_pixbuf_scale_simple ((GdkPixbuf*) arg1, (int) arg2, (int) arg3, (int) arg4))
	;
}
#define INLINE_F104_1997
#endif
#ifndef INLINE_F104_1857
static void inline_F104_1857 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F104_1857
#endif
#ifndef INLINE_F18_526
static void inline_F18_526 (EIF_POINTER arg1)
{
	cairo_paint ((cairo_t*)arg1)
	;
}
#define INLINE_F18_526
#endif
#ifndef INLINE_F104_2010
static EIF_INTEGER_32 inline_F104_2010 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_width ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F104_2010
#endif
#ifndef INLINE_F104_2011
static EIF_INTEGER_32 inline_F104_2011 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_height ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F104_2011
#endif
#ifndef INLINE_F18_468
static void inline_F18_468 (EIF_POINTER arg1)
{
	cairo_surface_destroy((cairo_surface_t*) arg1)
	;
}
#define INLINE_F18_468
#endif
#ifndef INLINE_F104_2017
static EIF_POINTER inline_F104_2017 (EIF_POINTER arg1)
{
	return gdk_pixbuf_new_from_xpm_data ((const char**) arg1);
	;
}
#define INLINE_F104_2017
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PIXMAP_IMP}.make */
void F1366_13912 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLR(7,loc2);
	RTLIU(8);
	
	RTGC;
	tp1 = (EIF_POINTER) gtk_drawing_area_new();
	F1214_11559(Current, tp1);
	F1315_12910(Current);
	loc1 = RTOSCF(11584,F1214_11584, (Current));
	tp1 = F1214_11583(Current);
	tr1 = RTOSCF(763,F29_763, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,966,0xFF01,928,1038,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_0_);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = tp2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1044,0xFF01,0xFFF9,1,966,1038,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A360_329_3, (EIF_POINTER) _A360_329_3, (EIF_POINTER)(F927_7583),tr2, 1, 1);
	}
	F1214_11564(Current, tp1, tr1, tr5);
	F1366_13925(Current, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	F1363_13772(Current);
	F1363_13814(Current, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	loc2 = F144_3314(Current);
	RTLE;
}

/* {EV_PIXMAP_IMP}.init_from_pixel_buffer */
void F1366_13914 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	RTCT0("attached {EV_PIXEL_BUFFER_IMP} a_pixel_buffer.implementation as l_pixel_buffer_imp", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1198, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = *(EIF_POINTER *)(loc1+ _PTROFF_4_2_0_0_0_0_);
	F1366_13933(Current, tp1);
	RTLE;
}

/* {EV_PIXMAP_IMP}.update_if_needed */
void F1366_13915 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_48_13_)) {
		tp1 = F1214_11583(Current);
		inline_F107_2660(tp1);
	}
	RTLE;
}

/* {EV_PIXMAP_IMP}.width */
EIF_INTEGER_32 F1366_13919 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_) != tp1)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) cairo_image_surface_get_width((cairo_surface_t*) tp1);
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_PIXMAP_IMP}.height */
EIF_INTEGER_32 F1366_13920 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_) != tp1)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) cairo_image_surface_get_height((cairo_surface_t*) tp1);
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_PIXMAP_IMP}.pixbuf */
EIF_POINTER F1366_13922 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
	ti4_1 = F1366_13919(Current);
	ti4_2 = F1366_13920(Current);
	Result = inline_F104_2006(tp1, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2);
	RTLE;
	return Result;
}

/* {EV_PIXMAP_IMP}.set_with_default */
void F1366_13923 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (EIF_POINTER) default_pixmap_xpm();
	F1366_13942(Current, tp1);
	RTLE;
}

/* {EV_PIXMAP_IMP}.stretch */
void F1366_13924 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc4 = F1366_13919(Current);
	loc5 = F1366_13920(Current);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 != arg1) || (EIF_BOOLEAN)(loc5 != arg2))) {
		loc1 = F1363_13845(Current);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 <= ((EIF_INTEGER_32) 16L)) && (EIF_BOOLEAN) (loc5 <= ((EIF_INTEGER_32) 16L)))) {
			loc3 = (EIF_INTEGER_32) GDK_INTERP_NEAREST;
		} else {
			loc3 = (EIF_INTEGER_32) GDK_INTERP_BILINEAR;
		}
		loc2 = inline_F104_1997(loc1, arg1, arg2, loc3);
		inline_F104_1857(loc1);
		F1366_13933(Current, loc2);
		inline_F104_1857(loc2);
	}
	RTLE;
}

/* {EV_PIXMAP_IMP}.set_size */
void F1366_13925 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1366_13940(Current);
	tp1 = (EIF_POINTER) cairo_image_surface_create((cairo_format_t) ((EIF_INTEGER_8) 0L), (int) arg1, (int) arg2);
	*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_) = (EIF_POINTER) tp1;
	F1363_13777(Current);
	F1363_13772(Current);
	RTLE;
}

/* {EV_PIXMAP_IMP}.pixbuf_from_drawable_at_position */
EIF_POINTER F1366_13928 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
	return (EIF_POINTER) inline_F104_2006(tp1, arg1, arg2, arg5, arg6);
}

/* {EV_PIXMAP_IMP}.process_draw_event */
EIF_BOOLEAN F1366_13930 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_0_);
	loc1 = (EIF_INTEGER_32) gtk_widget_get_allocated_width((GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_0_);
	loc2 = (EIF_INTEGER_32) gtk_widget_get_allocated_height((GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
	ti4_1 = F1366_13919(Current);
	ti4_2 = F1366_13920(Current);
	cairo_set_source_surface((cairo_t*) arg1, (cairo_surface_t*) tp1, (double) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc1 - ti4_1)) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L))), (double) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc2 - ti4_2)) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L))));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_48_13_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		F1358_13694(Current);
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(11584,F1214_11584, (Current))) + _REFACS_42_);
		tr1 = F929_7617(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc1, loc2);
		F680_5873(loc3, tr1);
		F1366_13936(Current);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_48_13_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	inline_F18_526(arg1);
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_PIXMAP_IMP}.copy_pixmap */
void F1366_13932 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc4);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc4 = tr1;
	loc4 = RTRV(eif_new_type(1365, 0x01),loc4);
	if (EIF_TEST(loc4)) {
		loc1 = F1366_13919(loc4);
		loc2 = F1366_13920(loc4);
		F1366_13940(Current);
		tp1 = (EIF_POINTER) cairo_image_surface_create((cairo_format_t) ((EIF_INTEGER_8) 0L), (int) loc1, (int) loc2);
		*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_) = (EIF_POINTER) tp1;
		F1363_13777(Current);
		loc3 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_);
		F1363_13772(Current);
		tp1 = *(EIF_POINTER *)(loc4+ _PTROFF_48_18_10_9_0_2_);
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		cairo_set_source_surface((cairo_t*) loc3, (cairo_surface_t*) tp1, (double) tr8_1, (double) tr8_2);
		inline_F18_526(loc3);
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		tr8_3 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		cairo_set_source_rgb((cairo_t*) loc3, (double) tr8_1, (double) tr8_2, (double) tr8_3);
	}
	RTLE;
}

/* {EV_PIXMAP_IMP}.set_pixmap_from_pixbuf */
void F1366_13933 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1366_13940(Current);
	ti4_1 = inline_F104_2010(arg1);
	ti4_2 = inline_F104_2011(arg1);
	tp1 = (EIF_POINTER) cairo_image_surface_create((cairo_format_t) ((EIF_INTEGER_8) 0L), (int) ti4_1, (int) ti4_2);
	*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_) = (EIF_POINTER) tp1;
	F1363_13777(Current);
	loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_);
	F1363_13799(Current, ((EIF_INTEGER_32) 0L));
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
	tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
	gdk_cairo_set_source_pixbuf((cairo_t*) loc1, (GdkPixbuf*) arg1, (double) tr8_1, (double) tr8_2);
	inline_F18_526(loc1);
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
	tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
	tr8_3 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
	cairo_set_source_rgb((cairo_t*) loc1, (double) tr8_1, (double) tr8_2, (double) tr8_3);
	RTLE;
}

/* {EV_PIXMAP_IMP}.pre_drawing */
void F1366_13934 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1358_13691(Current)) {
		F1366_13938(Current);
		loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			cairo_save((cairo_t*) loc1);
		}
	}
	RTLE;
}

/* {EV_PIXMAP_IMP}.post_drawing */
void F1366_13935 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1358_13691(Current)) {
		loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			cairo_restore((cairo_t*) loc1);
		}
		F1366_13915(Current);
	}
	RTLE;
}

/* {EV_PIXMAP_IMP}.end_drawing_session */
void F1366_13936 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (F1358_13692(Current)) {
		F1366_13915(Current);
	}
	F1358_13695(Current);
	RTLE;
}

/* {EV_PIXMAP_IMP}.get_cairo_context */
void F1366_13938 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_);
	tb1 = !tp1;
	if (tb1) {
		loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			tp1 = (EIF_POINTER) cairo_create((cairo_surface_t*) loc1);
			*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_) = (EIF_POINTER) tp1;
		}
	}
	RTLE;
}

/* {EV_PIXMAP_IMP}.release_cairo_surface */
void F1366_13939 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	
	
	RTGC;
	tb1 = !arg1;
	if ((EIF_BOOLEAN) !tb1) {
		inline_F18_468(arg1);
	}
}

/* {EV_PIXMAP_IMP}.release_previous_cairo_surface */
void F1366_13940 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1363_13843(Current);
	F1366_13939(Current, *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_));
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_) = (EIF_POINTER) tp2;
	RTLE;
}

/* {EV_PIXMAP_IMP}.set_from_xpm_data */
void F1366_13942 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_3_) = (EIF_POINTER) arg1;
	loc1 = inline_F104_2017(arg1);
	F1366_13933(Current, loc1);
	inline_F104_1857(loc1);
	RTLE;
}

/* {EV_PIXMAP_IMP}.destroy */
void F1366_13945 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1363_13843(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		F1366_13939(Current, *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_));
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_) = (EIF_POINTER) tp2;
	}
	F1267_12239(Current);
	RTLE;
}

/* {EV_PIXMAP_IMP}.c_object_dispose */
void F1366_13946 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_);
		cairo_destroy((cairo_t*) tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_) = (EIF_POINTER) tp2;
	}
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
		inline_F18_468(tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_) = (EIF_POINTER) tp2;
	}
	F1214_11574(Current);
	RTLE;
}

/* {EV_PIXMAP_IMP}.default_pixmap_xpm */
EIF_POINTER F1366_13947 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) default_pixmap_xpm();
	
	return Result;
}

void EIF_Minit721 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
