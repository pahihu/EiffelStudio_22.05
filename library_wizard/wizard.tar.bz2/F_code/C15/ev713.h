
#ifndef _C15_ev713_
#define _C15_ev713_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1358_13691(EIF_REFERENCE);
extern EIF_BOOLEAN F1358_13692(EIF_REFERENCE);
extern void F1358_13694(EIF_REFERENCE);
extern void F1358_13695(EIF_REFERENCE);
extern void EIF_Minit713(void);
extern long O10547[];

#ifdef __cplusplus
}
#endif

#endif
