/*
 * Code for class ENCODING_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "en730.h"
#include <string.h>
#include <iconv.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1375_14173
static EIF_POINTER inline_F1375_14173 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32* arg4, EIF_INTEGER_32* arg5)
{
	size_t insize = 0;
iconv_t cd = (iconv_t) arg1;
size_t nconv, avail, alloc;
char *res, *tres, *wrptr, *inptr;
char **l_inptr = &inptr;

insize = (size_t)arg3;
alloc = avail = insize + insize/4;

if (!(res = malloc(alloc))) {
	*arg5 = 1;
	return NULL;
} else {
	*arg5 = 0;
	wrptr = res;   /* duplicate pointers because they */
	inptr = arg2; /* get modified by iconv */
	
	/* Reset the descriptor to intial state. */
	iconv (cd, NULL, 0, NULL, 0);
	
	do {				
		nconv = iconv (cd, l_inptr, &insize, &wrptr, &avail); /*convertions */
		
		if (nconv == (size_t)(-1)) {
			if (errno == E2BIG) { /* need more room for result */							
				tres = realloc(res, alloc += 20);
				avail += 20;
				if (!tres) {
					*arg5 = 2;
					break;
				}
				wrptr = tres + (wrptr - res);
				res = tres;
			}
			else if (errno == EILSEQ) {
				*arg5 = 4;
				break;
			}
			else if (errno == EINVAL){
				*arg5 = 5;
				break;
			}
			else if (errno == EBADF){
				*arg5 = 6;
				break;
			}
			else{
				*arg5 = 7;
				break;
			}
		}
	} while (insize);
	
	*arg4 = alloc - avail;
	
	return res;
}
	;
}
#define INLINE_F1375_14173
#endif
#ifndef INLINE_F1375_14172
static EIF_POINTER inline_F1375_14172 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3, EIF_BOOLEAN* arg4)
{
	iconv_t cd;

cd = iconv_open (arg2, arg1);
if (cd == (iconv_t)(-1)) {
	*arg3 = 3;
	return NULL;
}
*arg4 = EIF_TRUE;
return cd;
	;
}
#define INLINE_F1375_14172
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ENCODING_IMP}.convert_to */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1375_14151 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER EIF_VOLATILE loc3 = (EIF_POINTER) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE EIF_VOLATILE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc7 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN EIF_VOLATILE loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_POINTER  EIF_VOLATILE tp1;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_NATURAL_32  EIF_VOLATILE tu4_1;
	EIF_CHARACTER_32  EIF_VOLATILE tw1;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_BOOLEAN  EIF_VOLATILE tb3;
	RTLD;
	RTXD;
	
	RTLI(12);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,arg3);
	RTLR(6,loc1);
	RTLR(7,loc6);
	RTLR(8,loc10);
	RTLR(9,loc11);
	RTLR(10,loc12);
	RTLR(11,saved_except);
	RTLIU(12);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc9) {
		loc7 = '\01';
		if (!F1375_14158(Current, arg1)) {
			tb1 = '\0';
			if ((EIF_BOOLEAN) !RTOSCF(3351,F147_3351, (Current))) {
				tb1 = (EIF_BOOLEAN) !F1375_14159(Current, arg1);
			}
			loc7 = tb1;
		}
		if (F1375_14157(Current, arg1)) {
			tr1 = F1046_9044(RTCW(arg2));
			loc5 = F1_14(tr1);
			tr1 = RTOSCF(14161,F1375_14161, (Current));
			tb1 = F21_593(RTCW(tr1), arg1, arg3);
			if ((EIF_BOOLEAN) !tb1) {
				if (((loc7) != (RTOSCF(3351,F147_3351, (Current))))) {
					tw1 = RTOSCF(14168,F1375_14168, (Current));
				} else {
					tw1 = RTOSCF(14169,F1375_14169, (Current));
				}
				F1051_9220(RTCW(loc5), tw1);
			}
			loc1 = F1375_14167(Current, loc5);
			loc2 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 * ((EIF_INTEGER_32) 4L));
		} else {
			if (F1375_14156(Current, arg1)) {
				tr1 = F1046_9044(RTCW(arg2));
				loc5 = F1_14(tr1);
				tr1 = RTOSCF(14161,F1375_14161, (Current));
				tb1 = F21_593(RTCW(tr1), arg1, arg3);
				if ((EIF_BOOLEAN) !tb1) {
					if (((loc7) != (RTOSCF(3351,F147_3351, (Current))))) {
						tw1 = RTOSCF(14168,F1375_14168, (Current));
					} else {
						tw1 = RTOSCF(14170,F1375_14170, (Current));
					}
					F1051_9220(RTCW(loc5), tw1);
				}
				loc1 = F147_3341(Current, loc5);
				loc2 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 * ((EIF_INTEGER_32) 2L));
			} else {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7501[Dtype(RTCW(arg2))-1049])(arg2);
				if (tb1) {
					loc6 = F1046_9038(RTCW(arg2));
				} else {
					tr1 = RTLNS(eif_new_type(51, 0x00).id, 51, _OBJSIZ_0_0_0_0_0_0_0_0_);
					loc6 = F52_1212(RTCW(tr1), arg2);
				}
				loc1 = F147_3340(Current, loc6);
				loc2 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
			}
		}
		tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
		loc3 = F1375_14162(Current, arg1, arg3, tp1, loc2, (EIF_INTEGER_32 *) &(loc4), (EIF_INTEGER_32 *) &(loc8));
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc8 == ((EIF_INTEGER_32) 0L))) {
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			tb1 = (EIF_BOOLEAN)(loc3 != tp1);
		}
		if (tb1) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			if (F1375_14157(Current, arg3)) {
				loc5 = F147_3344(Current, loc3, loc4);
				tb1 = F491_5229(RTCW(loc5));
				if ((EIF_BOOLEAN) !tb1) {
					tu4_1 = F1051_9199(RTCW(loc5), ((EIF_INTEGER_32) 1L));
					if (F1375_14165(Current, tu4_1)) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
						tr1 = F1051_9277(RTCW(loc5), ((EIF_INTEGER_32) 2L), ti4_1);
						loc5 = (EIF_REFERENCE) tr1;
						tb1 = '\01';
						tb2 = '\0';
						if (F1375_14158(Current, arg3)) {
							tb2 = RTOSCF(3351,F147_3351, (Current));
						}
						if (!tb2) {
							tb2 = '\0';
							if (F1375_14159(Current, arg3)) {
								tb2 = (EIF_BOOLEAN) !RTOSCF(3351,F147_3351, (Current));
							}
							tb1 = tb2;
						}
						if (tb1) {
							tr1 = F147_3349(Current, loc5);
							loc5 = (EIF_REFERENCE) tr1;
						}
					} else {
						tu4_1 = F1051_9199(RTCW(loc5), ((EIF_INTEGER_32) 1L));
						if (F1375_14166(Current, tu4_1)) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
							tr1 = F1051_9277(RTCW(loc5), ((EIF_INTEGER_32) 2L), ti4_1);
							loc5 = (EIF_REFERENCE) tr1;
							tb1 = '\01';
							tb2 = '\01';
							tb3 = '\0';
							if (F1375_14159(Current, arg3)) {
								tb3 = RTOSCF(3351,F147_3351, (Current));
							}
							if (!tb3) {
								tb3 = '\0';
								if (F1375_14158(Current, arg3)) {
									tb3 = (EIF_BOOLEAN) !RTOSCF(3351,F147_3351, (Current));
								}
								tb2 = tb3;
							}
							if (!tb2) {
								tb1 = (EIF_BOOLEAN) !F1375_14160(Current, arg3);
							}
							if (tb1) {
								tr1 = F147_3349(Current, loc5);
								loc5 = (EIF_REFERENCE) tr1;
							}
						}
					}
				}
				loc10 = (EIF_REFERENCE) loc5;
			} else {
				if (F1375_14156(Current, arg3)) {
					loc5 = F147_3343(Current, loc3, loc4);
					tb1 = F491_5229(RTCW(loc5));
					if ((EIF_BOOLEAN) !tb1) {
						tu4_1 = F1051_9199(RTCW(loc5), ((EIF_INTEGER_32) 1L));
						if (F1375_14165(Current, tu4_1)) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
							tr1 = F1051_9277(RTCW(loc5), ((EIF_INTEGER_32) 2L), ti4_1);
							loc5 = (EIF_REFERENCE) tr1;
							tb1 = '\01';
							tb2 = '\0';
							if (F1375_14158(Current, arg3)) {
								tb2 = RTOSCF(3351,F147_3351, (Current));
							}
							if (!tb2) {
								tb2 = '\0';
								if (F1375_14159(Current, arg3)) {
									tb2 = (EIF_BOOLEAN) !RTOSCF(3351,F147_3351, (Current));
								}
								tb1 = tb2;
							}
							if (tb1) {
								tr1 = F147_3350(Current, loc5);
								loc5 = (EIF_REFERENCE) tr1;
							}
						} else {
							tu4_1 = F1051_9199(RTCW(loc5), ((EIF_INTEGER_32) 1L));
							if (F1375_14166(Current, tu4_1)) {
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
								tr1 = F1051_9277(RTCW(loc5), ((EIF_INTEGER_32) 2L), ti4_1);
								loc5 = (EIF_REFERENCE) tr1;
								tb1 = '\01';
								tb2 = '\01';
								tb3 = '\0';
								if (F1375_14159(Current, arg3)) {
									tb3 = RTOSCF(3351,F147_3351, (Current));
								}
								if (!tb3) {
									tb3 = '\0';
									if (F1375_14158(Current, arg3)) {
										tb3 = (EIF_BOOLEAN) !RTOSCF(3351,F147_3351, (Current));
									}
									tb2 = tb3;
								}
								if (!tb2) {
									tb1 = (EIF_BOOLEAN) !F1375_14160(Current, arg3);
								}
								if (tb1) {
									tr1 = F147_3350(Current, loc5);
									loc5 = (EIF_REFERENCE) tr1;
								}
							}
						}
					}
					*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc10 = (EIF_REFERENCE) loc5;
				} else {
					loc10 = F147_3342(Current, loc3, loc4);
				}
			}
			RTAR(Current, loc10);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc10;
		} else {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc3 != tp1)) {
			free(loc3);
		}
	}
	RTE_E
	RTXSC;
	loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc3 != tp1)) {
		free(loc3);
	}
	loc11 = F137_3133(RTCV(RTOSCF(3816,F199_3816, (Current))));
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc11 != NULL)) {
		tr1 = F201_3851(RTCW(loc11));
		loc12 = tr1;
		loc12 = RTRV(eif_new_type(202, 0x01),loc12);
		tb1 = EIF_TEST(loc12);
	}
	if (tb1) {
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {ENCODING_IMP}.is_code_page_valid */
EIF_BOOLEAN F1375_14152 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7502[Dtype(RTCW(arg1))-1049])(arg1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) F1375_14155(Current, arg1);
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {ENCODING_IMP}.is_code_page_convertible */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_BOOLEAN F1375_14153 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	RTED;
	EIF_INTEGER_32 EIF_VOLATILE loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_VOLATILE EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	RTXD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,saved_except);
	RTLIU(5);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc2) {
		Result = F1375_14163(Current, arg1, arg2, (EIF_INTEGER_32 *) &(loc1));
		if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
			tr1 = F1375_14171(Current, loc1);
			F201_3843(RTCW(tr1));
		}
	}
	RTE_E
	RTXSC;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {ENCODING_IMP}.is_known_code_page */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_BOOLEAN F1375_14155 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_INTEGER_32 EIF_VOLATILE loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_VOLATILE EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	RTXD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,saved_except);
	RTLIU(4);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc2) {
		tr1 = RTOSCF(960,F38_960, (Current));
		tb1 = F1052_9308(RTCW(arg1), tr1);
		if ((EIF_BOOLEAN) !tb1) {
			Result = F1375_14164(Current, arg1, (EIF_INTEGER_32 *) &(loc1));
			if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
				tr1 = F1375_14171(Current, loc1);
				F201_3843(RTCW(tr1));
			}
		} else {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTE_E
	RTXSC;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {ENCODING_IMP}.is_two_byte_code_page */
EIF_BOOLEAN F1375_14156 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(1764,F98_1764, (Current));
	Result = F648_5596(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {ENCODING_IMP}.is_four_byte_code_page */
EIF_BOOLEAN F1375_14157 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(1765,F98_1765, (Current));
	Result = F648_5596(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {ENCODING_IMP}.is_big_endian_code_page */
EIF_BOOLEAN F1375_14158 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(1767,F98_1767, (Current));
	Result = F648_5596(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {ENCODING_IMP}.is_little_endian_code_page */
EIF_BOOLEAN F1375_14159 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(1766,F98_1766, (Current));
	Result = F648_5596(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {ENCODING_IMP}.is_endianness_specified */
EIF_BOOLEAN F1375_14160 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = '\01';
	if (!F1375_14158(Current, arg1)) {
		Result = F1375_14159(Current, arg1);
	}
	RTLE;
	return Result;
}

/* {ENCODING_IMP}.descriptor_cache */
static EIF_REFERENCE F1375_14161_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (14161);
#define Result RTOSR(14161)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(20, 0x01).id, 20, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F21_587(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (14161);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1375_14161 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14161,F1375_14161_body,(Current));
}

/* {ENCODING_IMP}.iconv_imp */
EIF_POINTER F1375_14162 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32* arg5, EIF_INTEGER_32* arg6)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(14161,F1375_14161, (Current));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7713[Dtype(RTCW(arg1))-1052])(arg1, arg2);
	F21_589(RTCW(tr1), tr2);
	tp1 = F21_592(RTCV(RTOSCF(14161,F1375_14161, (Current))));
	Result = inline_F1375_14173(tp1, arg3, arg4, arg5, arg6);
	tr1 = RTOSCF(14161,F1375_14161, (Current));
	F21_590(RTCW(tr1), arg1, arg2);
	RTLE;
	return Result;
}

/* {ENCODING_IMP}.is_codeset_convertible */
EIF_BOOLEAN F1375_14163 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7713[Dtype(RTCW(arg1))-1052])(arg1, arg2);
	tr1 = RTOSCF(14161,F1375_14161, (Current));
	F21_589(RTCW(tr1), loc3);
	tb1 = F21_591(RTCV(RTOSCF(14161,F1375_14161, (Current))));
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		loc1 = F147_3340(Current, arg1);
		loc2 = F147_3340(Current, arg2);
		tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
		tp2 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_0_1_0_1_0_0_);
		loc4 = inline_F1375_14172(tp1, tp2, arg3, (EIF_BOOLEAN *) &(loc5));
		if (loc5) {
			tr1 = RTOSCF(14161,F1375_14161, (Current));
			F21_588(RTCW(tr1), loc4, loc3);
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {ENCODING_IMP}.c_codeset_valid */
EIF_BOOLEAN F1375_14164 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32* arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("utf-8",5,1953751864);
	Result = F1375_14163(Current, arg1, tr1, arg2);
	RTLE;
	return Result;
}

/* {ENCODING_IMP}.same_endian */
EIF_BOOLEAN F1375_14165 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(arg1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 65279L));
	return Result;
}

/* {ENCODING_IMP}.reverse_endian */
EIF_BOOLEAN F1375_14166 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 65534L)) || (EIF_BOOLEAN)(arg1 == (EIF_NATURAL_32) ((EIF_INTEGER_64) RTI64C(4294836224))));
	return Result;
}

/* {ENCODING_IMP}.string_32_to_pointer */
EIF_REFERENCE F1375_14167 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7643[Dtype(arg1)-1048]);
	Result = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_0_1_0_1_0_1_1_0_);
	F915_6793(RTCW(Result), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)) * ((EIF_INTEGER_32) 4L)));
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 - loc5) + ((EIF_INTEGER_32) 1L));
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)) * ((EIF_INTEGER_32) 4L));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_0_1_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 < loc3)) {
		F915_6883(RTCW(Result), loc3);
	}
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == loc2)) break;
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7487[Dtype(RTCW(arg1))-1049])(arg1, (EIF_INTEGER_32) (loc1 + loc5));
		F915_6826(RTCW(Result), tu4_1, (EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 4L)));
		loc1++;
	}
	F915_6826(RTCW(Result), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 4L)));
	RTLE;
	return Result;
}

/* {ENCODING_IMP}.byte_order_mark */
static EIF_CHARACTER_32 F1375_14168_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (14168);
#define Result RTOSR(14168)
	Result = (EIF_CHARACTER_32) ((EIF_INTEGER_32) 65279L);
	RTOSE (14168);
	RTEE;
	return Result;
#undef Result
}

EIF_CHARACTER_32 F1375_14168 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14168,F1375_14168_body,(Current));
}

/* {ENCODING_IMP}.byte_order_mark_32_reverse */
static EIF_CHARACTER_32 F1375_14169_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (14169);
#define Result RTOSR(14169)
	Result = (EIF_CHARACTER_32) ((EIF_INTEGER_64) RTI64C(4294836224));
	RTOSE (14169);
	RTEE;
	return Result;
#undef Result
}

EIF_CHARACTER_32 F1375_14169 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14169,F1375_14169_body,(Current));
}

/* {ENCODING_IMP}.byte_order_mark_16_reverse */
static EIF_CHARACTER_32 F1375_14170_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (14170);
#define Result RTOSR(14170)
	Result = (EIF_CHARACTER_32) ((EIF_INTEGER_32) 65534L);
	RTOSE (14170);
	RTEE;
	return Result;
#undef Result
}

EIF_CHARACTER_32 F1375_14170 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14170,F1375_14170_body,(Current));
}

/* {ENCODING_IMP}.conversion_exception */
EIF_REFERENCE F1375_14171 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	switch (arg1) {
		case 1L:
			Result = RTLNS(eif_new_type(202, 0x01).id, 202, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("`malloc\' error",14,583574386);
			F203_3876(RTCW(Result), tr1);
			break;
		case 2L:
			Result = RTLNS(eif_new_type(202, 0x01).id, 202, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("`realloc\' error",15,1198130290);
			F203_3876(RTCW(Result), tr1);
			break;
		case 3L:
			Result = RTLNS(eif_new_type(202, 0x01).id, 202, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("`iconv_open\' error",18,665611378);
			F203_3876(RTCW(Result), tr1);
			break;
		case 4L:
			Result = RTLNS(eif_new_type(202, 0x01).id, 202, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("EILSEQ error in `iconv\'. Input conversion stopped due to an input byte that does not belong to the input codeset.",113,266392366);
			F203_3876(RTCW(Result), tr1);
			break;
		case 5L:
			Result = RTLNS(eif_new_type(202, 0x01).id, 202, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("EINVAL error in `iconv\'. Input conversion stopped due to an incomplete character or shift sequence at the end of the input buffer.",130,1207171630);
			F203_3876(RTCW(Result), tr1);
			break;
		case 6L:
			Result = RTLNS(eif_new_type(202, 0x01).id, 202, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("EBADF error in `iconv\'. The cd argument is not a valid open conversion descriptor.",82,1722040110);
			F203_3876(RTCW(Result), tr1);
			break;
		case 7L:
			Result = RTLNS(eif_new_type(202, 0x01).id, 202, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("Unexpected error in `iconv\'",27,1286010151);
			F203_3876(RTCW(Result), tr1);
			break;
		case 8L:
			Result = RTLNS(eif_new_type(202, 0x01).id, 202, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("`iconv_close\' error",19,1032340594);
			F203_3876(RTCW(Result), tr1);
			break;
		default:
			Result = RTLNS(eif_new_type(202, 0x01).id, 202, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("Unexpected error",16,578286706);
			F203_3876(RTCW(Result), tr1);
			break;
	}
	RTLE;
	return Result;
}

/* {ENCODING_IMP}.c_iconv_open */
EIF_POINTER F1375_14172 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3, EIF_BOOLEAN* arg4)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F1375_14172 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32*) arg3, (EIF_BOOLEAN*) arg4);
	return Result;
}

/* {ENCODING_IMP}.c_iconv */
EIF_POINTER F1375_14173 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32* arg4, EIF_INTEGER_32* arg5)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F1375_14173 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32*) arg4, (EIF_INTEGER_32*) arg5);
	return Result;
}

void EIF_Minit730 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
