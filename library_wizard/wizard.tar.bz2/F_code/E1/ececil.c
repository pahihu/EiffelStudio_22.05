#include "eif_eiffel.h"
#include "eif_rout_obj.h"
#include "eaddress.h"
#include "eoffsets.h"

#ifdef __cplusplus
extern "C" {
#endif

	/* DESCRIPTOR_CACHE c_iconv_close */
void _A21_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_p);
}

	/* DESCRIPTOR_CACHE c_iconv_close */
void __A21_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* LIBRARY_WIZARD inline-agent#1 of final_page */
void _A115_48 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F130_14733)(closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r);
}

	/* LIBRARY_WIZARD inline-agent#1 of final_page */
void __A115_48 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F130_14733)(closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r);
}

	/* LIBRARY_WIZARD inline-agent#1 of library_page */
void _A115_49_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F130_14734)(closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* LIBRARY_WIZARD inline-agent#1 of library_page */
void __A115_49_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F130_14734)(closed [1].it_r, op_2, closed [2].it_r);
}

	/* LIBRARY_WIZARD inline-agent#2 of library_page */
void _A115_50_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F130_14735)(closed [1].it_r, open [1].it_r);
}

	/* LIBRARY_WIZARD inline-agent#2 of library_page */
void __A115_50_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F130_14735)(closed [1].it_r, op_2);
}

	/* GRAPHICAL_WIZARD_STRING_QUESTION on_value_changed */
void _A256_46 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* GRAPHICAL_WIZARD_STRING_QUESTION on_value_changed */
void __A256_46 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* ACTION_SEQUENCE [G#1] call */
void _A812_166 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ACTION_SEQUENCE [G#1] call */
void __A812_166 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* GRAPHICAL_WIZARD_APPLICATION on_back */
void _A271_57 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* GRAPHICAL_WIZARD_APPLICATION on_back */
void __A271_57 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* GRAPHICAL_WIZARD_APPLICATION on_finish */
void _A271_60 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* GRAPHICAL_WIZARD_APPLICATION on_finish */
void __A271_60 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* GRAPHICAL_WIZARD_APPLICATION on_next */
void _A271_58 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* GRAPHICAL_WIZARD_APPLICATION on_next */
void __A271_58 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* GRAPHICAL_WIZARD_APPLICATION on_cancel */
void _A271_59 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* GRAPHICAL_WIZARD_APPLICATION on_cancel */
void __A271_59 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* MISMATCH_INFORMATION wipe_out */
void A282_98 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F648_5642)(Current);
}

	/* MISMATCH_INFORMATION internal_put */
void A282_162 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER)) F656_5715)(Current, arg1, arg2);
}

	/* MISMATCH_INFORMATION set_string_versions */
void A282_163 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER)) F656_5716)(Current, arg1, arg2);
}

	/* EV_ACCELERATOR_LIST enable_item_parented */
void _A283_166_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_ACCELERATOR_LIST enable_item_parented */
void __A283_166_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_ACCELERATOR_LIST disable_item_parented */
void _A283_167_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_ACCELERATOR_LIST disable_item_parented */
void __A283_167_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_MENU_ITEM_SELECT_ACTION_SEQUENCE wrapper */
void _A288_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* EV_MENU_ITEM_SELECT_ACTION_SEQUENCE wrapper */
void __A288_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* EV_DOCKABLE_SOURCE_ACTION_SEQUENCE wrapper */
void _A290_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* EV_DOCKABLE_SOURCE_ACTION_SEQUENCE wrapper */
void __A290_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* EV_KEY_ACTION_SEQUENCE wrapper */
void _A294_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* EV_KEY_ACTION_SEQUENCE wrapper */
void __A294_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* EV_GEOMETRY_ACTION_SEQUENCE wrapper */
void _A296_181_2_3_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, open [3].it_i4, open [4].it_i4, closed [2].it_r);
}

	/* EV_GEOMETRY_ACTION_SEQUENCE wrapper */
void __A296_181_2_3_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3, EIF_INTEGER_32 op_4, EIF_INTEGER_32 op_5)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5, closed [2].it_r);
}

	/* EV_POINTER_MOTION_ACTION_SEQUENCE wrapper */
void _A297_181_2_3_4_5_6_7_8 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, open [3].it_r8, open [4].it_r8, open [5].it_r8, open [6].it_i4, open [7].it_i4, closed [2].it_r);
}

	/* EV_POINTER_MOTION_ACTION_SEQUENCE wrapper */
void __A297_181_2_3_4_5_6_7_8 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3, EIF_REAL_64 op_4, EIF_REAL_64 op_5, EIF_REAL_64 op_6, EIF_INTEGER_32 op_7, EIF_INTEGER_32 op_8)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5, op_6, op_7, op_8, closed [2].it_r);
}

	/* EV_PND_MOTION_ACTION_SEQUENCE wrapper */
void _A299_181_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, open [3].it_r, closed [2].it_r);
}

	/* EV_PND_MOTION_ACTION_SEQUENCE wrapper */
void __A299_181_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3, EIF_REFERENCE op_4)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, closed [2].it_r);
}

	/* EV_POINTER_BUTTON_ACTION_SEQUENCE wrapper */
void _A300_181_2_3_4_5_6_7_8_9 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, open [3].it_i4, open [4].it_r8, open [5].it_r8, open [6].it_r8, open [7].it_i4, open [8].it_i4, closed [2].it_r);
}

	/* EV_POINTER_BUTTON_ACTION_SEQUENCE wrapper */
void __A300_181_2_3_4_5_6_7_8_9 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3, EIF_INTEGER_32 op_4, EIF_REAL_64 op_5, EIF_REAL_64 op_6, EIF_REAL_64 op_7, EIF_INTEGER_32 op_8, EIF_INTEGER_32 op_9)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5, op_6, op_7, op_8, op_9, closed [2].it_r);
}

	/* EV_NOTIFY_ACTION_SEQUENCE wrapper */
void _A301_180 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_NOTIFY_ACTION_SEQUENCE wrapper */
void __A301_180 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_NOTIFY_ACTION_SEQUENCE call */
void _A301_175 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_NOTIFY_ACTION_SEQUENCE call */
void __A301_175 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_MENU_ITEM_IMP on_activate */
void _A702_278 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_MENU_ITEM_IMP on_activate */
void __A702_278 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* HASH_TABLE [G#1, G#2] put */
void _A968_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* HASH_TABLE [INTEGER_32, G#2] put */
void _A1105_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,closed [3].it_r);
	RTLR(1,arg1);
	RTLIU(3);
	arg1 = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = closed [2].it_i4;
	f_ptr (closed [1].it_r, arg1, closed [3].it_r);
	RTLE;
}

	/* HASH_TABLE [G#1, INTEGER_32] put */
void _A1172_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg2 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,arg2);
	RTLR(1,closed [2].it_r);
	RTLIU(3);
	arg2 = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg2 = closed [3].it_i4;
	f_ptr (closed [1].it_r, closed [2].it_r, arg2);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, INTEGER_32] put */
void _A850_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* HASH_TABLE [INTEGER_32, NATURAL_32] put */
void _A974_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_n4);
}

	/* HASH_TABLE [POINTER, G#2] put */
void _A1378_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p, closed [3].it_r);
}

	/* HASH_TABLE [G#1, G#2] put */
void __A968_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* HASH_TABLE [INTEGER_32, G#2] put */
void __A1105_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,closed [3].it_r);
	RTLR(1,arg1);
	RTLIU(3);
	arg1 = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = closed [2].it_i4;
	f_ptr (closed [1].it_r, arg1, closed [3].it_r);
	RTLE;
}

	/* HASH_TABLE [G#1, INTEGER_32] put */
void __A1172_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	EIF_REFERENCE arg2 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,arg2);
	RTLR(1,closed [2].it_r);
	RTLIU(3);
	arg2 = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg2 = closed [3].it_i4;
	f_ptr (closed [1].it_r, closed [2].it_r, arg2);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, INTEGER_32] put */
void __A850_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* HASH_TABLE [INTEGER_32, NATURAL_32] put */
void __A974_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_NATURAL_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_n4);
}

	/* HASH_TABLE [POINTER, G#2] put */
void __A1378_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p, closed [3].it_r);
}

	/* HASH_TABLE [G#1, G#2] remove */
void _A968_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [INTEGER_32, G#2] remove */
void _A1105_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [G#1, INTEGER_32] remove */
void _A1172_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = closed [2].it_i4;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, INTEGER_32] remove */
void _A850_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* HASH_TABLE [INTEGER_32, NATURAL_32] remove */
void _A974_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_n4);
}

	/* HASH_TABLE [POINTER, G#2] remove */
void _A1378_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [G#1, G#2] remove */
void __A968_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [INTEGER_32, G#2] remove */
void __A1105_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [G#1, INTEGER_32] remove */
void __A1172_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = closed [2].it_i4;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, INTEGER_32] remove */
void __A850_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* HASH_TABLE [INTEGER_32, NATURAL_32] remove */
void __A974_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_n4);
}

	/* HASH_TABLE [POINTER, G#2] remove */
void __A1378_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_GTK_CALLBACK_MARSHAL marshal */
void A360_408 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_POINTER, EIF_POINTER)) F929_7624)(Current, arg1, arg2, arg3, arg4);
}

	/* EV_GTK_CALLBACK_MARSHAL on_timeout_intermediary */
void _A360_140 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL on_timeout_intermediary */
void __A360_140 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL gtk_dialog_response_event */
EIF_POINTER _A360_339_3 ( EIF_POINTER(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL gtk_dialog_response_event */
EIF_POINTER __A360_339_3 ( EIF_POINTER(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_mapped_signal_intermediary */
void _A360_326 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_mapped_signal_intermediary */
void __A360_326 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_unmapped_signal_intermediary */
void _A360_327 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_unmapped_signal_intermediary */
void __A360_327 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_hide_signal_intermediary */
void _A360_328 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_hide_signal_intermediary */
void __A360_328 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_size_allocate_event */
void _A360_333_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_size_allocate_event */
void __A360_333_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL on_notebook_page_switch_event */
void _A360_325_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_notebook_page_switch_event */
void __A360_325_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_p, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL on_set_focus_event */
void _A360_334_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_set_focus_event */
void __A360_334_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL on_gauge_value_changed_intermediary */
void _A360_332 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_gauge_value_changed_intermediary */
void __A360_332 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL mcl_column_resize_callback */
void _A360_315 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL mcl_column_resize_callback */
void __A360_315 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL mcl_column_click_callback */
void _A360_314 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL mcl_column_click_callback */
void __A360_314 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL on_pnd_deferred_item_parent_selection_change */
void _A360_320 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL on_pnd_deferred_item_parent_selection_change */
void __A360_320 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL tree_row_expansion_change_intermediary */
void _A360_317_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_BOOLEAN, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_b, open [1].it_i4, open [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL tree_row_expansion_change_intermediary */
void __A360_317_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_BOOLEAN, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_4, EIF_POINTER op_5)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_b, op_4, op_5);
}

	/* EV_GTK_CALLBACK_MARSHAL text_field_return_intermediary */
void _A360_336 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL text_field_return_intermediary */
void __A360_336 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_combo_box_toggle_button_event */
void _A360_321 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL on_combo_box_toggle_button_event */
void __A360_321 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL text_component_change_intermediary */
void _A360_335 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL text_component_change_intermediary */
void __A360_335 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL text_buffer_mark_set_intermediary */
void _A360_316_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, open [1].it_i4, open [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL text_buffer_mark_set_intermediary */
void __A360_316_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_3, EIF_POINTER op_4)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, op_3, op_4);
}

	/* EV_GTK_CALLBACK_MARSHAL button_select_intermediary */
void _A360_337 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL button_select_intermediary */
void __A360_337 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL menu_item_activate_intermediary */
void _A360_338 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL menu_item_activate_intermediary */
void __A360_338 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL new_toolbar_item_select_actions_intermediary */
void _A360_312 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL new_toolbar_item_select_actions_intermediary */
void __A360_312 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL toolbar_item_select_actions_intermediary */
void _A360_322 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL toolbar_item_select_actions_intermediary */
void __A360_322 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL configure_event */
EIF_BOOLEAN _A360_330_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL configure_event */
EIF_BOOLEAN __A360_330_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL scroll_event */
EIF_BOOLEAN _A360_331_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL scroll_event */
EIF_BOOLEAN __A360_331_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL draw_actions_event */
EIF_BOOLEAN _A360_329_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL draw_actions_event */
EIF_BOOLEAN __A360_329_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, op_3);
}

	/* EV_PATH_FIELD browse_for_directory */
void _A495_345 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_PATH_FIELD browse_for_directory */
void __A495_345 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_PATH_FIELD browse_for_save_file */
void _A495_346 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_PATH_FIELD browse_for_save_file */
void __A495_346 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_PATH_FIELD browse_for_open_file */
void _A495_347 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_PATH_FIELD browse_for_open_file */
void __A495_347 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_WINDOW_I connect_accelerator */
void _A645_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_WINDOW_I connect_accelerator */
void __A645_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_WINDOW_I disconnect_accelerator */
void _A645_264_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_WINDOW_I disconnect_accelerator */
void __A645_264_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_DIALOG dialog_key_press_action */
void _A505_314_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_DIALOG dialog_key_press_action */
void __A505_314_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_DIALOG destroy */
void _A505_267 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_DIALOG destroy */
void __A505_267 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_MESSAGE_DIALOG on_button_press */
void _A507_355 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_MESSAGE_DIALOG on_button_press */
void __A507_355 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_MESSAGE_DIALOG on_key_press */
void _A507_356_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_MESSAGE_DIALOG on_key_press */
void __A507_356_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_FONT_IMP update_preferred_faces */
void _A563_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_FONT_IMP update_preferred_faces */
void __A563_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_APPLICATION_I contextual_help */
void _A571_303_2_3_4_5_6_7_8_9 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, open [3].it_i4, open [4].it_r8, open [5].it_r8, open [6].it_r8, open [7].it_i4, open [8].it_i4);
}

	/* EV_APPLICATION_I contextual_help */
void __A571_303_2_3_4_5_6_7_8_9 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3, EIF_INTEGER_32 op_4, EIF_REAL_64 op_5, EIF_REAL_64 op_6, EIF_REAL_64 op_7, EIF_INTEGER_32 op_8, EIF_INTEGER_32 op_9)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5, op_6, op_7, op_8, op_9);
}

	/* EV_APPLICATION_I safe_destroy */
void _A571_68 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_APPLICATION_I safe_destroy */
void __A571_68 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_APPLICATION_I inline-agent#1 of create_target_menu */
EIF_BOOLEAN _A571_308_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1212_14850)(closed [1].it_r, open [1].it_r, open [2].it_r);
}

	/* EV_APPLICATION_I inline-agent#1 of create_target_menu */
EIF_BOOLEAN __A571_308_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1212_14850)(closed [1].it_r, op_2, op_3);
}

	/* EV_APPLICATION_I inline-agent#2 of create_target_menu */
void _A571_309_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1212_14851)(closed [1].it_r, open [1].it_r, open [2].it_r, open [3].it_r);
}

	/* EV_APPLICATION_I inline-agent#2 of create_target_menu */
void __A571_309_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3, EIF_REFERENCE op_4)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1212_14851)(closed [1].it_r, op_2, op_3, op_4);
}

	/* EV_APPLICATION_I help_handler */
void _A571_300 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_APPLICATION_I help_handler */
void __A571_300 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_APPLICATION_I enable_contextual_help */
void _A571_243 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_APPLICATION_I enable_contextual_help */
void __A571_243 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_PND_ACTION_SEQUENCE call */
void _A284_180 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_PND_ACTION_SEQUENCE call */
void __A284_180 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_APPLICATION_IMP on_char_event */
EIF_POINTER _A572_425_2 ( EIF_POINTER(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_p);
}

	/* EV_APPLICATION_IMP on_char_event */
EIF_POINTER __A572_425_2 ( EIF_POINTER(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* EV_ANY_IMP c_object_dispose */
void A573_84 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R9363[Dtype(Current) - 1216])(Current);
}

	/* EV_DOCKABLE_SOURCE_HINT_IMP on_timeout */
void _A576_447 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_DOCKABLE_SOURCE_HINT_IMP on_timeout */
void __A576_447 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_DOCKABLE_SOURCE_I close_dockable_dialog */
void _A583_100 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_DOCKABLE_SOURCE_I close_dockable_dialog */
void __A583_100 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_PICK_AND_DROPABLE_IMP inline-agent#1 of start_transport */
void _A620_232 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) F1265_14859)(closed [1].it_r, closed [2].it_r, closed [3].it_i4, closed [4].it_i4, closed [5].it_i4, closed [6].it_i4);
}

	/* EV_PICK_AND_DROPABLE_IMP inline-agent#1 of start_transport */
void __A620_232 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) F1265_14859)(closed [1].it_r, closed [2].it_r, closed [3].it_i4, closed [4].it_i4, closed [5].it_i4, closed [6].it_i4);
}

	/* EV_MENU_IMP c_gtk_menu_popup_at_pointer */
void _A706_326 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p, closed [3].it_i4, closed [4].it_i4, closed [5].it_i4, closed [6].it_n4);
}

	/* EV_MENU_IMP c_gtk_menu_popup_at_pointer */
void __A706_326 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_NATURAL_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p, closed [3].it_i4, closed [4].it_i4, closed [5].it_i4, closed [6].it_n4);
}

	/* EIFFEL_ENV safe_create_dir */
void _A742_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EIFFEL_ENV safe_create_dir */
void __A742_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}


#ifdef __cplusplus
}
#endif
