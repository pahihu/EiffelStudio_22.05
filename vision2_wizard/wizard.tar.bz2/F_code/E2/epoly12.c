#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

static EIF_TYPE_INDEX Y8598_pgtype0[] = {1133,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8598_pgtype1[] = {1133,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8598_pgtype2[] = {1186,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8598_pgtype3[] = {1186,1194,0xFFFF};
static EIF_TYPE_INDEX Y8598_pgtype4[] = {1186,1182,0xFFFF};
static EIF_TYPE_INDEX Y8598_pgtype5[] = {1186,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y8598_gen_type [192];
EIF_TYPE_INDEX Y8598 [192];
void Y8598_init (void)
{
	egc_routines_types [8598] = Y8598;
	egc_routines_gen_types [8598] = Y8598_gen_type;
	egc_routines_offset [8598] = 1200;
	Y8598_gen_type [31] = Y8598_pgtype0;
	Y8598_gen_type [32] = Y8598_pgtype1;
	Y8598_gen_type [33] = Y8598_pgtype2;
	Y8598_gen_type [34] = Y8598_pgtype3;
	Y8598_gen_type [35] = Y8598_pgtype4;
	Y8598_gen_type [36] = Y8598_pgtype5;
	Y8598[0] = 1090;
	{long i; for (i = 1; i < 3; i++) Y8598[i] = 1092;};
	{long i; for (i = 3; i < 5; i++) Y8598[i] = 1093;};
	{long i; for (i = 5; i < 7; i++) Y8598[i] = 1091;};
	Y8598[7] = 1094;
	Y8598[8] = 1104;
	{long i; for (i = 9; i < 11; i++) Y8598[i] = 1095;};
	Y8598[11] = 1096;
	{long i; for (i = 12; i < 14; i++) Y8598[i] = 1097;};
	{long i; for (i = 14; i < 16; i++) Y8598[i] = 1099;};
	{long i; for (i = 16; i < 18; i++) Y8598[i] = 1100;};
	{long i; for (i = 18; i < 20; i++) Y8598[i] = 1098;};
	{long i; for (i = 20; i < 22; i++) Y8598[i] = 1106;};
	{long i; for (i = 22; i < 24; i++) Y8598[i] = 1101;};
	{long i; for (i = 24; i < 26; i++) Y8598[i] = 1102;};
	{long i; for (i = 26; i < 29; i++) Y8598[i] = 1090;};
	Y8598[29] = 1094;
	Y8598[30] = 1105;
	{long i; for (i = 31; i < 33; i++) Y8598[i] = 1133;};
	{long i; for (i = 33; i < 37; i++) Y8598[i] = 1186;};
	Y8598[37] = 1196;
	Y8598[38] = 1113;
	{long i; for (i = 39; i < 41; i++) Y8598[i] = 1197;};
	Y8598[41] = 1114;
	{long i; for (i = 42; i < 44; i++) Y8598[i] = 1110;};
	{long i; for (i = 44; i < 46; i++) Y8598[i] = 1111;};
	Y8598[46] = 1116;
	{long i; for (i = 47; i < 49; i++) Y8598[i] = 1112;};
	{long i; for (i = 49; i < 51; i++) Y8598[i] = 1134;};
	{long i; for (i = 51; i < 53; i++) Y8598[i] = 1115;};
	Y8598[53] = 1119;
	Y8598[54] = 1120;
	Y8598[55] = 1131;
	{long i; for (i = 56; i < 58; i++) Y8598[i] = 1118;};
	{long i; for (i = 58; i < 60; i++) Y8598[i] = 1117;};
	{long i; for (i = 60; i < 62; i++) Y8598[i] = 1123;};
	{long i; for (i = 62; i < 65; i++) Y8598[i] = 1121;};
	Y8598[65] = 1096;
	{long i; for (i = 66; i < 71; i++) Y8598[i] = 1127;};
	Y8598[71] = 1128;
	Y8598[72] = 1129;
	Y8598[73] = 1130;
	{long i; for (i = 74; i < 76; i++) Y8598[i] = 1131;};
	{long i; for (i = 76; i < 78; i++) Y8598[i] = 1135;};
	{long i; for (i = 78; i < 80; i++) Y8598[i] = 1136;};
	Y8598[80] = 1137;
	Y8598[81] = 1138;
	Y8598[82] = 1139;
	Y8598[83] = 1137;
	Y8598[84] = 1138;
	Y8598[85] = 1139;
	Y8598[86] = 1140;
	Y8598[87] = 1141;
	Y8598[88] = 1142;
	Y8598[89] = 1140;
	Y8598[90] = 1141;
	Y8598[91] = 1142;
	Y8598[92] = 1143;
	Y8598[93] = 1144;
	{long i; for (i = 94; i < 96; i++) Y8598[i] = 1143;};
	Y8598[96] = 1147;
	Y8598[97] = 1148;
	Y8598[98] = 1149;
	Y8598[99] = 1151;
	Y8598[100] = 1143;
	Y8598[101] = 1144;
	Y8598[102] = 1145;
	Y8598[103] = 1146;
	Y8598[104] = 1147;
	Y8598[105] = 1148;
	Y8598[106] = 1149;
	Y8598[107] = 1151;
	Y8598[108] = 1156;
	Y8598[109] = 1187;
	Y8598[110] = 1193;
	Y8598[111] = 1188;
	Y8598[112] = 1158;
	{long i; for (i = 113; i < 115; i++) Y8598[i] = 1160;};
	Y8598[115] = 1162;
	Y8598[116] = 1189;
	Y8598[117] = 1190;
	Y8598[118] = 1163;
	Y8598[119] = 1164;
	Y8598[120] = 1165;
	Y8598[121] = 1166;
	Y8598[122] = 1191;
	Y8598[123] = 1166;
	Y8598[124] = 1168;
	Y8598[125] = 1169;
	Y8598[126] = 1170;
	Y8598[127] = 1171;
	Y8598[128] = 1172;
	Y8598[129] = 1173;
	Y8598[130] = 1174;
	Y8598[131] = 1156;
	Y8598[132] = 1188;
	Y8598[133] = 1187;
	Y8598[134] = 1193;
	Y8598[135] = 1158;
	Y8598[136] = 1160;
	Y8598[137] = 1161;
	Y8598[138] = 1162;
	Y8598[139] = 1189;
	Y8598[140] = 1190;
	Y8598[141] = 1168;
	Y8598[142] = 1169;
	Y8598[143] = 1170;
	Y8598[144] = 1163;
	Y8598[145] = 1164;
	Y8598[146] = 1165;
	Y8598[147] = 1166;
	Y8598[148] = 1191;
	Y8598[149] = 1167;
	Y8598[150] = 1171;
	Y8598[151] = 1172;
	Y8598[152] = 1173;
	Y8598[153] = 1174;
	Y8598[154] = 1175;
	{long i; for (i = 155; i < 157; i++) Y8598[i] = 1176;};
	Y8598[157] = 1175;
	Y8598[158] = 1194;
	Y8598[159] = 1195;
	Y8598[160] = 1194;
	Y8598[161] = 1195;
	Y8598[162] = 1175;
	Y8598[163] = 1179;
	Y8598[164] = 1182;
	Y8598[165] = 1183;
	Y8598[166] = 1184;
	Y8598[167] = 1182;
	Y8598[168] = 1198;
	Y8598[169] = 1182;
	Y8598[170] = 1183;
	Y8598[171] = 1184;
	Y8598[172] = 1185;
	Y8598[173] = 1198;
	{long i; for (i = 174; i < 176; i++) Y8598[i] = 1177;};
	Y8598[176] = 1180;
	Y8598[177] = 1181;
	Y8598[178] = 1180;
	Y8598[179] = 1181;
	Y8598[180] = 1124;
	Y8598[181] = 1157;
	Y8598[182] = 1125;
	Y8598[183] = 1126;
	Y8598[184] = 1159;
	Y8598[185] = 1124;
	Y8598[186] = 1157;
	Y8598[187] = 1125;
	Y8598[188] = 1126;
	Y8598[189] = 1159;
	{long i; for (i = 190; i < 192; i++) Y8598[i] = 1199;};
}

long O8599[192];
void O8599_init () {
	{long i; for (i = 0; i < 4; i++) O8599[i] = + _CHROFF_1_0_;}
	O8599[4] = + _CHROFF_2_3_;
	O8599[5] = + _CHROFF_1_1_;
	O8599[6] = + _CHROFF_2_1_;
	O8599[7] = + _CHROFF_1_0_;
	O8599[8] = + _CHROFF_2_0_;
	O8599[9] = + _CHROFF_1_0_;
	O8599[10] = + _CHROFF_2_0_;
	O8599[11] = + _CHROFF_1_0_;
	O8599[12] = + _CHROFF_2_1_;
	O8599[13] = + _CHROFF_3_4_;
	{long i; for (i = 14; i < 16; i++) O8599[i] = + _CHROFF_1_0_;}
	O8599[16] = + _CHROFF_2_0_;
	O8599[17] = + _CHROFF_3_1_;
	{long i; for (i = 18; i < 20; i++) O8599[i] = + _CHROFF_1_0_;}
	O8599[20] = + _CHROFF_40_8_;
	O8599[21] = + _CHROFF_49_15_;
	O8599[22] = + _CHROFF_2_1_;
	O8599[23] = + _CHROFF_4_1_;
	{long i; for (i = 24; i < 26; i++) O8599[i] = + _CHROFF_1_0_;}
	O8599[26] = + _CHROFF_2_2_;
	O8599[27] = + _CHROFF_4_2_;
	O8599[28] = + _CHROFF_5_4_;
	O8599[29] = + _CHROFF_10_9_;
	{long i; for (i = 30; i < 32; i++) O8599[i] = + _CHROFF_1_0_;}
	O8599[32] = + _CHROFF_2_0_;
	{long i; for (i = 33; i < 35; i++) O8599[i] = + _CHROFF_1_0_;}
	{long i; for (i = 35; i < 37; i++) O8599[i] = + _CHROFF_2_0_;}
	O8599[37] = + _CHROFF_4_0_;
	O8599[38] = + _CHROFF_1_0_;
	O8599[39] = + _CHROFF_2_0_;
	O8599[40] = + _CHROFF_6_2_;
	O8599[41] = + _CHROFF_1_0_;
	O8599[42] = + _CHROFF_7_4_;
	O8599[43] = + _CHROFF_8_5_;
	O8599[44] = + _CHROFF_1_0_;
	O8599[45] = + _CHROFF_3_0_;
	{long i; for (i = 46; i < 49; i++) O8599[i] = + _CHROFF_1_0_;}
	{long i; for (i = 49; i < 51; i++) O8599[i] = + _CHROFF_1_1_;}
	{long i; for (i = 51; i < 53; i++) O8599[i] = + _CHROFF_3_1_;}
	{long i; for (i = 53; i < 59; i++) O8599[i] = + _CHROFF_1_0_;}
	O8599[59] = + _CHROFF_2_0_;
	O8599[60] = + _CHROFF_1_0_;
	O8599[61] = + _CHROFF_2_0_;
	O8599[62] = + _CHROFF_1_0_;
	O8599[63] = + _CHROFF_2_0_;
	{long i; for (i = 64; i < 66; i++) O8599[i] = + _CHROFF_1_0_;}
	{long i; for (i = 66; i < 68; i++) O8599[i] = + _CHROFF_3_0_;}
	{long i; for (i = 68; i < 70; i++) O8599[i] = + _CHROFF_4_0_;}
	O8599[70] = + _CHROFF_8_4_;
	O8599[71] = + _CHROFF_9_4_;
	O8599[72] = + _CHROFF_11_4_;
	O8599[73] = + _CHROFF_11_5_;
	O8599[74] = + _CHROFF_13_3_;
	O8599[75] = + _CHROFF_16_5_;
	O8599[76] = + _CHROFF_35_7_;
	O8599[77] = + _CHROFF_42_10_;
	O8599[78] = + _CHROFF_37_7_;
	O8599[79] = + _CHROFF_46_10_;
	O8599[80] = + _CHROFF_37_7_;
	O8599[81] = + _CHROFF_38_7_;
	O8599[82] = + _CHROFF_37_7_;
	O8599[83] = + _CHROFF_47_10_;
	O8599[84] = + _CHROFF_49_10_;
	O8599[85] = + _CHROFF_47_10_;
	{long i; for (i = 86; i < 89; i++) O8599[i] = + _CHROFF_39_8_;}
	{long i; for (i = 89; i < 92; i++) O8599[i] = + _CHROFF_49_11_;}
	{long i; for (i = 92; i < 96; i++) O8599[i] = + _CHROFF_39_8_;}
	O8599[96] = + _CHROFF_47_10_;
	O8599[97] = + _CHROFF_47_12_;
	O8599[98] = + _CHROFF_50_11_;
	O8599[99] = + _CHROFF_53_11_;
	O8599[100] = + _CHROFF_49_11_;
	O8599[101] = + _CHROFF_51_11_;
	{long i; for (i = 102; i < 104; i++) O8599[i] = + _CHROFF_49_12_;}
	O8599[104] = + _CHROFF_59_19_;
	O8599[105] = + _CHROFF_59_21_;
	O8599[106] = + _CHROFF_65_23_;
	O8599[107] = + _CHROFF_68_24_;
	O8599[108] = + _CHROFF_35_7_;
	O8599[109] = + _CHROFF_43_7_;
	O8599[110] = + _CHROFF_37_7_;
	O8599[111] = + _CHROFF_37_8_;
	O8599[112] = + _CHROFF_35_7_;
	{long i; for (i = 113; i < 117; i++) O8599[i] = + _CHROFF_37_7_;}
	O8599[117] = + _CHROFF_37_8_;
	{long i; for (i = 118; i < 120; i++) O8599[i] = + _CHROFF_36_7_;}
	O8599[120] = + _CHROFF_40_10_;
	O8599[121] = + _CHROFF_37_7_;
	O8599[122] = + _CHROFF_41_7_;
	O8599[123] = + _CHROFF_37_7_;
	{long i; for (i = 124; i < 127; i++) O8599[i] = + _CHROFF_35_7_;}
	{long i; for (i = 127; i < 131; i++) O8599[i] = + _CHROFF_36_7_;}
	O8599[131] = + _CHROFF_42_11_;
	O8599[132] = + _CHROFF_45_14_;
	O8599[133] = + _CHROFF_58_12_;
	O8599[134] = + _CHROFF_51_11_;
	{long i; for (i = 135; i < 137; i++) O8599[i] = + _CHROFF_44_11_;}
	{long i; for (i = 137; i < 139; i++) O8599[i] = + _CHROFF_44_12_;}
	O8599[139] = + _CHROFF_50_11_;
	O8599[140] = + _CHROFF_51_12_;
	{long i; for (i = 141; i < 144; i++) O8599[i] = + _CHROFF_42_11_;}
	O8599[144] = + _CHROFF_43_11_;
	O8599[145] = + _CHROFF_44_13_;
	O8599[146] = + _CHROFF_51_16_;
	O8599[147] = + _CHROFF_46_12_;
	O8599[148] = + _CHROFF_59_14_;
	{long i; for (i = 149; i < 154; i++) O8599[i] = + _CHROFF_46_12_;}
	O8599[154] = + _CHROFF_16_3_;
	O8599[155] = + _CHROFF_18_3_;
	O8599[156] = + _CHROFF_23_3_;
	O8599[157] = + _CHROFF_16_3_;
	{long i; for (i = 158; i < 160; i++) O8599[i] = + _CHROFF_20_3_;}
	{long i; for (i = 160; i < 162; i++) O8599[i] = + _CHROFF_25_4_;}
	{long i; for (i = 162; i < 164; i++) O8599[i] = + _CHROFF_21_5_;}
	{long i; for (i = 164; i < 168; i++) O8599[i] = + _CHROFF_17_4_;}
	O8599[168] = + _CHROFF_18_4_;
	O8599[169] = + _CHROFF_23_6_;
	{long i; for (i = 170; i < 172; i++) O8599[i] = + _CHROFF_23_7_;}
	O8599[172] = + _CHROFF_24_7_;
	O8599[173] = + _CHROFF_26_6_;
	O8599[174] = + _CHROFF_19_3_;
	O8599[175] = + _CHROFF_22_3_;
	{long i; for (i = 176; i < 178; i++) O8599[i] = + _CHROFF_21_8_;}
	{long i; for (i = 178; i < 180; i++) O8599[i] = + _CHROFF_29_12_;}
	O8599[180] = + _CHROFF_1_0_;
	O8599[181] = + _CHROFF_36_8_;
	{long i; for (i = 182; i < 184; i++) O8599[i] = + _CHROFF_1_0_;}
	O8599[184] = + _CHROFF_36_7_;
	O8599[185] = + _CHROFF_6_2_;
	O8599[186] = + _CHROFF_48_15_;
	O8599[187] = + _CHROFF_6_4_;
	O8599[188] = + _CHROFF_6_2_;
	O8599[189] = + _CHROFF_48_14_;
	{long i; for (i = 190; i < 192; i++) O8599[i] = + _CHROFF_3_0_;}
}

long O8701[182];
void O8701_init () {
	O8701[0] =  + _REFACS_1_;
	{long i; for (i = 68; i < 70; i++) O8701[i] =  + _REFACS_25_;}
	{long i; for (i = 70; i < 73; i++) O8701[i] =  + _REFACS_26_;}
	O8701[73] =  + _REFACS_27_;
	{long i; for (i = 74; i < 76; i++) O8701[i] =  + _REFACS_26_;}
	O8701[76] =  + _REFACS_27_;
	O8701[77] =  + _REFACS_26_;
	{long i; for (i = 78; i < 88; i++) O8701[i] =  + _REFACS_27_;}
	{long i; for (i = 88; i < 90; i++) O8701[i] =  + _REFACS_31_;}
	{long i; for (i = 90; i < 92; i++) O8701[i] =  + _REFACS_34_;}
	{long i; for (i = 92; i < 96; i++) O8701[i] =  + _REFACS_27_;}
	{long i; for (i = 96; i < 98; i++) O8701[i] =  + _REFACS_31_;}
	{long i; for (i = 98; i < 100; i++) O8701[i] =  + _REFACS_34_;}
	O8701[100] =  + _REFACS_25_;
	O8701[101] =  + _REFACS_29_;
	O8701[102] =  + _REFACS_27_;
	O8701[103] =  + _REFACS_26_;
	O8701[104] =  + _REFACS_25_;
	{long i; for (i = 105; i < 108; i++) O8701[i] =  + _REFACS_26_;}
	{long i; for (i = 108; i < 110; i++) O8701[i] =  + _REFACS_27_;}
	{long i; for (i = 110; i < 112; i++) O8701[i] =  + _REFACS_26_;}
	O8701[112] =  + _REFACS_29_;
	O8701[113] =  + _REFACS_27_;
	O8701[114] =  + _REFACS_31_;
	O8701[115] =  + _REFACS_27_;
	{long i; for (i = 116; i < 119; i++) O8701[i] =  + _REFACS_25_;}
	{long i; for (i = 119; i < 123; i++) O8701[i] =  + _REFACS_26_;}
	O8701[123] =  + _REFACS_25_;
	O8701[124] =  + _REFACS_26_;
	O8701[125] =  + _REFACS_29_;
	O8701[126] =  + _REFACS_27_;
	O8701[127] =  + _REFACS_25_;
	{long i; for (i = 128; i < 131; i++) O8701[i] =  + _REFACS_26_;}
	{long i; for (i = 131; i < 133; i++) O8701[i] =  + _REFACS_27_;}
	{long i; for (i = 133; i < 136; i++) O8701[i] =  + _REFACS_25_;}
	{long i; for (i = 136; i < 138; i++) O8701[i] =  + _REFACS_26_;}
	O8701[138] =  + _REFACS_29_;
	O8701[139] =  + _REFACS_27_;
	O8701[140] =  + _REFACS_31_;
	O8701[141] =  + _REFACS_27_;
	{long i; for (i = 142; i < 146; i++) O8701[i] =  + _REFACS_26_;}
	O8701[173] =  + _REFACS_26_;
	O8701[176] =  + _REFACS_26_;
	O8701[178] =  + _REFACS_26_;
	O8701[181] =  + _REFACS_26_;
}

long O9124[164];
void O9124_init () {
	O9124[0] = + _PTROFF_2_3_0_1_0_0_;
	O9124[1] = + _PTROFF_4_3_0_1_0_0_;
	O9124[2] = + _PTROFF_5_5_0_1_0_0_;
	O9124[3] = + _PTROFF_10_10_0_9_0_0_;
	O9124[14] = + _PTROFF_6_3_0_2_0_0_;
	O9124[44] = + _PTROFF_8_5_0_1_0_0_;
	O9124[45] = + _PTROFF_9_5_0_1_0_0_;
	O9124[46] = + _PTROFF_11_5_0_1_0_0_;
	O9124[47] = + _PTROFF_11_6_0_1_0_0_;
	O9124[49] = + _PTROFF_16_7_6_1_0_0_;
	O9124[51] = + _PTROFF_42_12_10_6_0_0_;
	O9124[53] = + _PTROFF_46_12_10_6_0_0_;
	O9124[57] = + _PTROFF_47_12_10_7_0_0_;
	O9124[58] = + _PTROFF_49_12_10_10_0_0_;
	O9124[59] = + _PTROFF_47_12_10_7_0_0_;
	{long i; for (i = 63; i < 66; i++) O9124[i] = + _PTROFF_49_13_10_7_0_0_;}
	O9124[74] = + _PTROFF_49_13_10_6_0_0_;
	O9124[75] = + _PTROFF_51_13_10_8_0_0_;
	O9124[76] = + _PTROFF_49_14_10_8_0_0_;
	O9124[77] = + _PTROFF_49_14_10_10_0_0_;
	O9124[78] = + _PTROFF_59_21_10_11_0_0_;
	O9124[79] = + _PTROFF_59_23_10_11_0_0_;
	O9124[80] = + _PTROFF_65_25_10_11_0_0_;
	O9124[81] = + _PTROFF_68_26_10_11_0_0_;
	O9124[105] = + _PTROFF_42_13_10_6_0_0_;
	O9124[106] = + _PTROFF_45_16_10_7_0_0_;
	O9124[107] = + _PTROFF_58_14_10_9_0_0_;
	O9124[108] = + _PTROFF_51_13_10_9_0_0_;
	O9124[109] = + _PTROFF_44_13_10_6_1_0_;
	O9124[110] = + _PTROFF_44_13_10_7_0_0_;
	{long i; for (i = 111; i < 113; i++) O9124[i] = + _PTROFF_44_14_10_7_0_0_;}
	O9124[113] = + _PTROFF_50_13_10_9_0_0_;
	O9124[114] = + _PTROFF_51_14_10_9_0_0_;
	{long i; for (i = 115; i < 118; i++) O9124[i] = + _PTROFF_42_13_10_6_0_0_;}
	O9124[118] = + _PTROFF_43_13_10_6_0_0_;
	O9124[119] = + _PTROFF_44_15_10_6_0_0_;
	O9124[120] = + _PTROFF_51_18_10_10_0_0_;
	O9124[121] = + _PTROFF_46_14_10_7_0_0_;
	O9124[122] = + _PTROFF_59_16_10_12_0_0_;
	O9124[123] = + _PTROFF_46_14_10_7_0_0_;
	{long i; for (i = 124; i < 128; i++) O9124[i] = + _PTROFF_46_14_10_6_0_0_;}
	{long i; for (i = 136; i < 138; i++) O9124[i] = + _PTROFF_21_7_6_1_0_0_;}
	O9124[143] = + _PTROFF_23_8_6_1_0_0_;
	{long i; for (i = 144; i < 146; i++) O9124[i] = + _PTROFF_23_9_6_1_0_0_;}
	O9124[146] = + _PTROFF_24_9_6_1_0_0_;
	O9124[147] = + _PTROFF_26_8_6_2_0_0_;
	{long i; for (i = 152; i < 154; i++) O9124[i] = + _PTROFF_29_14_8_2_0_0_;}
	O9124[160] = + _PTROFF_48_19_10_9_0_0_;
	O9124[163] = + _PTROFF_48_18_10_9_0_0_;
}

long O9125[164];
void O9125_init () {
	O9125[0] = + _CHROFF_2_0_;
	O9125[1] = + _CHROFF_4_0_;
	O9125[2] = + _CHROFF_5_0_;
	O9125[3] = + _CHROFF_10_0_;
	O9125[14] = + _CHROFF_6_0_;
	O9125[44] = + _CHROFF_8_0_;
	O9125[45] = + _CHROFF_9_0_;
	{long i; for (i = 46; i < 48; i++) O9125[i] = + _CHROFF_11_0_;}
	O9125[49] = + _CHROFF_16_1_;
	O9125[51] = + _CHROFF_42_1_;
	O9125[53] = + _CHROFF_46_1_;
	O9125[57] = + _CHROFF_47_1_;
	O9125[58] = + _CHROFF_49_1_;
	O9125[59] = + _CHROFF_47_1_;
	{long i; for (i = 63; i < 66; i++) O9125[i] = + _CHROFF_49_1_;}
	O9125[74] = + _CHROFF_49_1_;
	O9125[75] = + _CHROFF_51_1_;
	{long i; for (i = 76; i < 78; i++) O9125[i] = + _CHROFF_49_1_;}
	{long i; for (i = 78; i < 80; i++) O9125[i] = + _CHROFF_59_1_;}
	O9125[80] = + _CHROFF_65_1_;
	O9125[81] = + _CHROFF_68_1_;
	O9125[105] = + _CHROFF_42_1_;
	O9125[106] = + _CHROFF_45_1_;
	O9125[107] = + _CHROFF_58_1_;
	O9125[108] = + _CHROFF_51_1_;
	{long i; for (i = 109; i < 113; i++) O9125[i] = + _CHROFF_44_1_;}
	O9125[113] = + _CHROFF_50_1_;
	O9125[114] = + _CHROFF_51_1_;
	{long i; for (i = 115; i < 118; i++) O9125[i] = + _CHROFF_42_1_;}
	O9125[118] = + _CHROFF_43_1_;
	O9125[119] = + _CHROFF_44_1_;
	O9125[120] = + _CHROFF_51_1_;
	O9125[121] = + _CHROFF_46_1_;
	O9125[122] = + _CHROFF_59_1_;
	{long i; for (i = 123; i < 128; i++) O9125[i] = + _CHROFF_46_1_;}
	{long i; for (i = 136; i < 138; i++) O9125[i] = + _CHROFF_21_1_;}
	{long i; for (i = 143; i < 146; i++) O9125[i] = + _CHROFF_23_1_;}
	O9125[146] = + _CHROFF_24_1_;
	O9125[147] = + _CHROFF_26_1_;
	{long i; for (i = 152; i < 154; i++) O9125[i] = + _CHROFF_29_1_;}
	O9125[160] = + _CHROFF_48_1_;
	O9125[163] = + _CHROFF_48_1_;
}

long O9136[164];
void O9136_init () {
	{long i; for (i = 0; i < 4; i++) O9136[i] =  + _REFACS_1_;}
	O9136[14] =  + _REFACS_2_;
	{long i; for (i = 44; i < 48; i++) O9136[i] =  + _REFACS_3_;}
	O9136[49] =  + _REFACS_8_;
	O9136[51] =  + _REFACS_26_;
	O9136[53] =  + _REFACS_27_;
	O9136[57] =  + _REFACS_27_;
	O9136[58] =  + _REFACS_28_;
	O9136[59] =  + _REFACS_27_;
	{long i; for (i = 63; i < 66; i++) O9136[i] =  + _REFACS_28_;}
	{long i; for (i = 74; i < 78; i++) O9136[i] =  + _REFACS_28_;}
	{long i; for (i = 78; i < 80; i++) O9136[i] =  + _REFACS_32_;}
	{long i; for (i = 80; i < 82; i++) O9136[i] =  + _REFACS_35_;}
	O9136[105] =  + _REFACS_26_;
	O9136[106] =  + _REFACS_27_;
	O9136[107] =  + _REFACS_30_;
	O9136[108] =  + _REFACS_28_;
	O9136[109] =  + _REFACS_26_;
	{long i; for (i = 110; i < 113; i++) O9136[i] =  + _REFACS_27_;}
	{long i; for (i = 113; i < 115; i++) O9136[i] =  + _REFACS_28_;}
	{long i; for (i = 115; i < 118; i++) O9136[i] =  + _REFACS_26_;}
	{long i; for (i = 118; i < 120; i++) O9136[i] =  + _REFACS_27_;}
	O9136[120] =  + _REFACS_30_;
	O9136[121] =  + _REFACS_28_;
	O9136[122] =  + _REFACS_32_;
	O9136[123] =  + _REFACS_28_;
	{long i; for (i = 124; i < 128; i++) O9136[i] =  + _REFACS_27_;}
	{long i; for (i = 136; i < 138; i++) O9136[i] =  + _REFACS_11_;}
	{long i; for (i = 143; i < 147; i++) O9136[i] =  + _REFACS_12_;}
	O9136[147] =  + _REFACS_13_;
	{long i; for (i = 152; i < 154; i++) O9136[i] =  + _REFACS_15_;}
	O9136[160] =  + _REFACS_27_;
	O9136[163] =  + _REFACS_27_;
}

long O9138[164];
void O9138_init () {
	O9138[0] = + _CHROFF_2_1_;
	O9138[1] = + _CHROFF_4_1_;
	O9138[2] = + _CHROFF_5_1_;
	O9138[3] = + _CHROFF_10_1_;
	O9138[14] = + _CHROFF_6_1_;
	O9138[44] = + _CHROFF_8_1_;
	O9138[45] = + _CHROFF_9_1_;
	{long i; for (i = 46; i < 48; i++) O9138[i] = + _CHROFF_11_1_;}
	O9138[49] = + _CHROFF_16_2_;
	O9138[51] = + _CHROFF_42_2_;
	O9138[53] = + _CHROFF_46_2_;
	O9138[57] = + _CHROFF_47_2_;
	O9138[58] = + _CHROFF_49_2_;
	O9138[59] = + _CHROFF_47_2_;
	{long i; for (i = 63; i < 66; i++) O9138[i] = + _CHROFF_49_2_;}
	O9138[74] = + _CHROFF_49_2_;
	O9138[75] = + _CHROFF_51_2_;
	{long i; for (i = 76; i < 78; i++) O9138[i] = + _CHROFF_49_2_;}
	{long i; for (i = 78; i < 80; i++) O9138[i] = + _CHROFF_59_2_;}
	O9138[80] = + _CHROFF_65_2_;
	O9138[81] = + _CHROFF_68_2_;
	O9138[105] = + _CHROFF_42_2_;
	O9138[106] = + _CHROFF_45_2_;
	O9138[107] = + _CHROFF_58_2_;
	O9138[108] = + _CHROFF_51_2_;
	{long i; for (i = 109; i < 113; i++) O9138[i] = + _CHROFF_44_2_;}
	O9138[113] = + _CHROFF_50_2_;
	O9138[114] = + _CHROFF_51_2_;
	{long i; for (i = 115; i < 118; i++) O9138[i] = + _CHROFF_42_2_;}
	O9138[118] = + _CHROFF_43_2_;
	O9138[119] = + _CHROFF_44_2_;
	O9138[120] = + _CHROFF_51_2_;
	O9138[121] = + _CHROFF_46_2_;
	O9138[122] = + _CHROFF_59_2_;
	{long i; for (i = 123; i < 128; i++) O9138[i] = + _CHROFF_46_2_;}
	{long i; for (i = 136; i < 138; i++) O9138[i] = + _CHROFF_21_2_;}
	{long i; for (i = 143; i < 146; i++) O9138[i] = + _CHROFF_23_2_;}
	O9138[146] = + _CHROFF_24_2_;
	O9138[147] = + _CHROFF_26_2_;
	{long i; for (i = 152; i < 154; i++) O9138[i] = + _CHROFF_29_2_;}
	O9138[160] = + _CHROFF_48_2_;
	O9138[163] = + _CHROFF_48_2_;
}

long O9170[163];
void O9170_init () {
	{long i; for (i = 0; i < 3; i++) O9170[i] =  + _REFACS_2_;}
	{long i; for (i = 43; i < 47; i++) O9170[i] =  + _REFACS_4_;}
	O9170[48] =  + _REFACS_9_;
	O9170[50] =  + _REFACS_27_;
	O9170[52] =  + _REFACS_28_;
	O9170[56] =  + _REFACS_28_;
	O9170[57] =  + _REFACS_29_;
	O9170[58] =  + _REFACS_28_;
	{long i; for (i = 62; i < 65; i++) O9170[i] =  + _REFACS_29_;}
	{long i; for (i = 73; i < 77; i++) O9170[i] =  + _REFACS_29_;}
	{long i; for (i = 77; i < 79; i++) O9170[i] =  + _REFACS_33_;}
	{long i; for (i = 79; i < 81; i++) O9170[i] =  + _REFACS_36_;}
	O9170[104] =  + _REFACS_27_;
	O9170[105] =  + _REFACS_28_;
	O9170[106] =  + _REFACS_31_;
	O9170[107] =  + _REFACS_29_;
	O9170[108] =  + _REFACS_27_;
	{long i; for (i = 109; i < 112; i++) O9170[i] =  + _REFACS_28_;}
	{long i; for (i = 112; i < 114; i++) O9170[i] =  + _REFACS_29_;}
	{long i; for (i = 114; i < 117; i++) O9170[i] =  + _REFACS_27_;}
	{long i; for (i = 117; i < 119; i++) O9170[i] =  + _REFACS_28_;}
	O9170[119] =  + _REFACS_31_;
	O9170[120] =  + _REFACS_29_;
	O9170[121] =  + _REFACS_33_;
	O9170[122] =  + _REFACS_29_;
	{long i; for (i = 123; i < 127; i++) O9170[i] =  + _REFACS_28_;}
	{long i; for (i = 135; i < 137; i++) O9170[i] =  + _REFACS_12_;}
	{long i; for (i = 142; i < 146; i++) O9170[i] =  + _REFACS_13_;}
	O9170[146] =  + _REFACS_14_;
	{long i; for (i = 151; i < 153; i++) O9170[i] =  + _REFACS_16_;}
	O9170[159] =  + _REFACS_28_;
	O9170[162] =  + _REFACS_28_;
}

long O9171[163];
void O9171_init () {
	{long i; for (i = 0; i < 3; i++) O9171[i] =  + _REFACS_3_;}
	{long i; for (i = 43; i < 47; i++) O9171[i] =  + _REFACS_5_;}
	O9171[48] =  + _REFACS_10_;
	O9171[50] =  + _REFACS_28_;
	O9171[52] =  + _REFACS_29_;
	O9171[56] =  + _REFACS_29_;
	O9171[57] =  + _REFACS_30_;
	O9171[58] =  + _REFACS_29_;
	{long i; for (i = 62; i < 65; i++) O9171[i] =  + _REFACS_30_;}
	{long i; for (i = 73; i < 77; i++) O9171[i] =  + _REFACS_30_;}
	{long i; for (i = 77; i < 79; i++) O9171[i] =  + _REFACS_34_;}
	{long i; for (i = 79; i < 81; i++) O9171[i] =  + _REFACS_37_;}
	O9171[104] =  + _REFACS_28_;
	O9171[105] =  + _REFACS_29_;
	O9171[106] =  + _REFACS_32_;
	O9171[107] =  + _REFACS_30_;
	O9171[108] =  + _REFACS_28_;
	{long i; for (i = 109; i < 112; i++) O9171[i] =  + _REFACS_29_;}
	{long i; for (i = 112; i < 114; i++) O9171[i] =  + _REFACS_30_;}
	{long i; for (i = 114; i < 117; i++) O9171[i] =  + _REFACS_28_;}
	{long i; for (i = 117; i < 119; i++) O9171[i] =  + _REFACS_29_;}
	O9171[119] =  + _REFACS_32_;
	O9171[120] =  + _REFACS_30_;
	O9171[121] =  + _REFACS_34_;
	O9171[122] =  + _REFACS_30_;
	{long i; for (i = 123; i < 127; i++) O9171[i] =  + _REFACS_29_;}
	{long i; for (i = 135; i < 137; i++) O9171[i] =  + _REFACS_13_;}
	{long i; for (i = 142; i < 146; i++) O9171[i] =  + _REFACS_14_;}
	O9171[146] =  + _REFACS_15_;
	{long i; for (i = 151; i < 153; i++) O9171[i] =  + _REFACS_17_;}
	O9171[159] =  + _REFACS_29_;
	O9171[162] =  + _REFACS_29_;
}

long O9191[80];
void O9191_init () {
	{long i; for (i = 0; i < 2; i++) O9191[i] =  + _REFACS_4_;}
	{long i; for (i = 42; i < 46; i++) O9191[i] =  + _REFACS_6_;}
	{long i; for (i = 76; i < 78; i++) O9191[i] =  + _REFACS_35_;}
	{long i; for (i = 78; i < 80; i++) O9191[i] =  + _REFACS_38_;}
}

long O9198[80];
void O9198_init () {
	O9198[0] = + _CHROFF_5_2_;
	O9198[1] = + _CHROFF_10_2_;
	O9198[42] = + _CHROFF_8_2_;
	O9198[43] = + _CHROFF_9_2_;
	{long i; for (i = 44; i < 46; i++) O9198[i] = + _CHROFF_11_2_;}
	{long i; for (i = 76; i < 78; i++) O9198[i] = + _CHROFF_59_3_;}
	O9198[78] = + _CHROFF_65_3_;
	O9198[79] = + _CHROFF_68_3_;
}

long O9204[80];
void O9204_init () {
	O9204[0] = + _CHROFF_5_3_;
	O9204[1] = + _CHROFF_10_3_;
	O9204[42] = + _CHROFF_8_3_;
	O9204[43] = + _CHROFF_9_3_;
	{long i; for (i = 44; i < 46; i++) O9204[i] = + _CHROFF_11_3_;}
	{long i; for (i = 76; i < 78; i++) O9204[i] = + _CHROFF_59_4_;}
	O9204[78] = + _CHROFF_65_4_;
	O9204[79] = + _CHROFF_68_4_;
}

long O9254[143];
void O9254_init () {
	O9254[0] = + _LNGOFF_1_1_0_0_;
	O9254[1] = + _LNGOFF_2_1_0_0_;
	{long i; for (i = 2; i < 4; i++) O9254[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 4; i < 6; i++) O9254[i] = + _LNGOFF_2_1_0_0_;}
	O9254[6] = + _LNGOFF_4_1_0_0_;
	O9254[8] = + _LNGOFF_2_1_0_0_;
	O9254[9] = + _LNGOFF_6_3_0_1_;
	O9254[49] = + _LNGOFF_37_9_6_0_;
	O9254[50] = + _LNGOFF_38_9_6_0_;
	O9254[51] = + _LNGOFF_37_9_6_0_;
	O9254[52] = + _LNGOFF_47_12_10_1_;
	O9254[53] = + _LNGOFF_49_12_10_1_;
	O9254[54] = + _LNGOFF_47_12_10_1_;
	{long i; for (i = 55; i < 58; i++) O9254[i] = + _LNGOFF_39_10_6_0_;}
	{long i; for (i = 58; i < 61; i++) O9254[i] = + _LNGOFF_49_13_10_1_;}
	O9254[78] = + _LNGOFF_43_9_6_0_;
	O9254[79] = + _LNGOFF_37_9_6_0_;
	O9254[80] = + _LNGOFF_37_10_6_0_;
	O9254[85] = + _LNGOFF_37_9_6_0_;
	O9254[86] = + _LNGOFF_37_10_6_0_;
	O9254[91] = + _LNGOFF_41_9_6_0_;
	O9254[101] = + _LNGOFF_45_16_10_1_;
	O9254[102] = + _LNGOFF_58_14_10_1_;
	O9254[103] = + _LNGOFF_51_13_10_1_;
	O9254[108] = + _LNGOFF_50_13_10_1_;
	O9254[109] = + _LNGOFF_51_14_10_1_;
	O9254[117] = + _LNGOFF_59_16_10_1_;
	{long i; for (i = 127; i < 129; i++) O9254[i] = + _LNGOFF_20_5_6_0_;}
	{long i; for (i = 129; i < 131; i++) O9254[i] = + _LNGOFF_25_6_6_0_;}
	O9254[137] = + _LNGOFF_18_6_6_0_;
	O9254[142] = + _LNGOFF_26_8_6_1_;
}

long O9288[142];
void O9288_init () {
	O9288[0] =  + _REFACS_1_;
	O9288[4] =  + _REFACS_1_;
	O9288[5] =  + _REFACS_2_;
	O9288[8] =  + _REFACS_3_;
	O9288[51] =  + _REFACS_30_;
	O9288[52] =  + _REFACS_31_;
	O9288[53] =  + _REFACS_30_;
	{long i; for (i = 57; i < 60; i++) O9288[i] =  + _REFACS_31_;}
	O9288[100] =  + _REFACS_30_;
	O9288[101] =  + _REFACS_33_;
	O9288[102] =  + _REFACS_31_;
	{long i; for (i = 107; i < 109; i++) O9288[i] =  + _REFACS_31_;}
	O9288[116] =  + _REFACS_35_;
	{long i; for (i = 128; i < 130; i++) O9288[i] =  + _REFACS_15_;}
	O9288[141] =  + _REFACS_16_;
}

static EIF_TYPE_INDEX Y9288_pgtype0[] = {688,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype1[] = {688,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype2[] = {688,1182,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype3[] = {688,1182,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype4[] = {688,1135,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype5[] = {688,1135,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype6[] = {688,1135,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype7[] = {688,1135,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype8[] = {688,1135,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype9[] = {688,1135,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype10[] = {688,1178,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype11[] = {688,1177,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype12[] = {688,1194,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype13[] = {688,1176,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype14[] = {688,1176,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype15[] = {688,1176,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype16[] = {688,1194,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype17[] = {688,1194,0xFFFF};
static EIF_TYPE_INDEX Y9288_pgtype18[] = {688,1182,0xFFFF};
EIF_TYPE_INDEX *Y9288_gen_type [142];
EIF_TYPE_INDEX Y9288 [142];
void Y9288_init (void)
{
	egc_routines_types [9288] = Y9288;
	egc_routines_gen_types [9288] = Y9288_gen_type;
	egc_routines_offset [9288] = 1232;
	Y9288_gen_type [0] = Y9288_pgtype0;
	Y9288_gen_type [4] = Y9288_pgtype1;
	Y9288_gen_type [5] = Y9288_pgtype2;
	Y9288_gen_type [8] = Y9288_pgtype3;
	Y9288_gen_type [51] = Y9288_pgtype4;
	Y9288_gen_type [52] = Y9288_pgtype5;
	Y9288_gen_type [53] = Y9288_pgtype6;
	Y9288_gen_type [57] = Y9288_pgtype7;
	Y9288_gen_type [58] = Y9288_pgtype8;
	Y9288_gen_type [59] = Y9288_pgtype9;
	Y9288_gen_type [100] = Y9288_pgtype10;
	Y9288_gen_type [101] = Y9288_pgtype11;
	Y9288_gen_type [102] = Y9288_pgtype12;
	Y9288_gen_type [107] = Y9288_pgtype13;
	Y9288_gen_type [108] = Y9288_pgtype14;
	Y9288_gen_type [116] = Y9288_pgtype15;
	Y9288_gen_type [128] = Y9288_pgtype16;
	Y9288_gen_type [129] = Y9288_pgtype17;
	Y9288_gen_type [141] = Y9288_pgtype18;
	Y9288[0] = 688;
	{long i; for (i = 4; i < 6; i++) Y9288[i] = 688;};
	Y9288[8] = 688;
	{long i; for (i = 51; i < 54; i++) Y9288[i] = 688;};
	{long i; for (i = 57; i < 60; i++) Y9288[i] = 688;};
	{long i; for (i = 100; i < 103; i++) Y9288[i] = 688;};
	{long i; for (i = 107; i < 109; i++) Y9288[i] = 688;};
	Y9288[116] = 688;
	{long i; for (i = 128; i < 130; i++) Y9288[i] = 688;};
	Y9288[141] = 688;
}

long O9326[148];
void O9326_init () {
	{long i; for (i = 0; i < 2; i++) O9326[i] =  + _REFACS_6_;}
	O9326[34] =  + _REFACS_26_;
	O9326[35] =  + _REFACS_29_;
	O9326[36] =  + _REFACS_27_;
	O9326[37] =  + _REFACS_30_;
	O9326[38] =  + _REFACS_27_;
	O9326[39] =  + _REFACS_28_;
	O9326[40] =  + _REFACS_27_;
	O9326[41] =  + _REFACS_31_;
	O9326[42] =  + _REFACS_32_;
	O9326[43] =  + _REFACS_31_;
	{long i; for (i = 44; i < 47; i++) O9326[i] =  + _REFACS_28_;}
	{long i; for (i = 47; i < 50; i++) O9326[i] =  + _REFACS_32_;}
	{long i; for (i = 50; i < 54; i++) O9326[i] =  + _REFACS_28_;}
	{long i; for (i = 54; i < 56; i++) O9326[i] =  + _REFACS_32_;}
	{long i; for (i = 56; i < 58; i++) O9326[i] =  + _REFACS_35_;}
	{long i; for (i = 58; i < 62; i++) O9326[i] =  + _REFACS_31_;}
	{long i; for (i = 62; i < 64; i++) O9326[i] =  + _REFACS_36_;}
	{long i; for (i = 64; i < 66; i++) O9326[i] =  + _REFACS_39_;}
	O9326[66] =  + _REFACS_26_;
	O9326[67] =  + _REFACS_30_;
	O9326[68] =  + _REFACS_28_;
	O9326[69] =  + _REFACS_27_;
	O9326[70] =  + _REFACS_26_;
	{long i; for (i = 71; i < 74; i++) O9326[i] =  + _REFACS_27_;}
	{long i; for (i = 74; i < 76; i++) O9326[i] =  + _REFACS_28_;}
	{long i; for (i = 76; i < 78; i++) O9326[i] =  + _REFACS_27_;}
	O9326[78] =  + _REFACS_30_;
	O9326[79] =  + _REFACS_28_;
	O9326[80] =  + _REFACS_32_;
	O9326[81] =  + _REFACS_28_;
	{long i; for (i = 82; i < 85; i++) O9326[i] =  + _REFACS_26_;}
	{long i; for (i = 85; i < 89; i++) O9326[i] =  + _REFACS_27_;}
	O9326[89] =  + _REFACS_29_;
	O9326[90] =  + _REFACS_31_;
	O9326[91] =  + _REFACS_34_;
	O9326[92] =  + _REFACS_32_;
	O9326[93] =  + _REFACS_29_;
	{long i; for (i = 94; i < 97; i++) O9326[i] =  + _REFACS_30_;}
	{long i; for (i = 97; i < 99; i++) O9326[i] =  + _REFACS_32_;}
	{long i; for (i = 99; i < 102; i++) O9326[i] =  + _REFACS_29_;}
	{long i; for (i = 102; i < 104; i++) O9326[i] =  + _REFACS_30_;}
	O9326[104] =  + _REFACS_33_;
	O9326[105] =  + _REFACS_31_;
	O9326[106] =  + _REFACS_36_;
	O9326[107] =  + _REFACS_31_;
	{long i; for (i = 108; i < 112; i++) O9326[i] =  + _REFACS_30_;}
	{long i; for (i = 134; i < 136; i++) O9326[i] =  + _REFACS_15_;}
	{long i; for (i = 136; i < 138; i++) O9326[i] =  + _REFACS_18_;}
	O9326[139] =  + _REFACS_27_;
	O9326[142] =  + _REFACS_27_;
	O9326[144] =  + _REFACS_30_;
	O9326[147] =  + _REFACS_30_;
}

long O9327[148];
void O9327_init () {
	O9327[0] = + _CHROFF_7_1_;
	O9327[1] = + _CHROFF_8_1_;
	O9327[34] = + _CHROFF_35_1_;
	O9327[35] = + _CHROFF_42_3_;
	O9327[36] = + _CHROFF_37_1_;
	O9327[37] = + _CHROFF_46_3_;
	O9327[38] = + _CHROFF_37_1_;
	O9327[39] = + _CHROFF_38_1_;
	O9327[40] = + _CHROFF_37_1_;
	O9327[41] = + _CHROFF_47_3_;
	O9327[42] = + _CHROFF_49_3_;
	O9327[43] = + _CHROFF_47_3_;
	{long i; for (i = 44; i < 47; i++) O9327[i] = + _CHROFF_39_1_;}
	{long i; for (i = 47; i < 50; i++) O9327[i] = + _CHROFF_49_3_;}
	{long i; for (i = 50; i < 54; i++) O9327[i] = + _CHROFF_39_1_;}
	{long i; for (i = 54; i < 56; i++) O9327[i] = + _CHROFF_47_1_;}
	O9327[56] = + _CHROFF_50_1_;
	O9327[57] = + _CHROFF_53_1_;
	O9327[58] = + _CHROFF_49_3_;
	O9327[59] = + _CHROFF_51_3_;
	{long i; for (i = 60; i < 62; i++) O9327[i] = + _CHROFF_49_3_;}
	{long i; for (i = 62; i < 64; i++) O9327[i] = + _CHROFF_59_5_;}
	O9327[64] = + _CHROFF_65_5_;
	O9327[65] = + _CHROFF_68_5_;
	O9327[66] = + _CHROFF_35_1_;
	O9327[67] = + _CHROFF_43_1_;
	{long i; for (i = 68; i < 70; i++) O9327[i] = + _CHROFF_37_1_;}
	O9327[70] = + _CHROFF_35_1_;
	{long i; for (i = 71; i < 76; i++) O9327[i] = + _CHROFF_37_1_;}
	{long i; for (i = 76; i < 78; i++) O9327[i] = + _CHROFF_36_1_;}
	O9327[78] = + _CHROFF_40_1_;
	O9327[79] = + _CHROFF_37_1_;
	O9327[80] = + _CHROFF_41_1_;
	O9327[81] = + _CHROFF_37_1_;
	{long i; for (i = 82; i < 85; i++) O9327[i] = + _CHROFF_35_1_;}
	{long i; for (i = 85; i < 89; i++) O9327[i] = + _CHROFF_36_1_;}
	O9327[89] = + _CHROFF_42_3_;
	O9327[90] = + _CHROFF_45_3_;
	O9327[91] = + _CHROFF_58_3_;
	O9327[92] = + _CHROFF_51_3_;
	{long i; for (i = 93; i < 97; i++) O9327[i] = + _CHROFF_44_3_;}
	O9327[97] = + _CHROFF_50_3_;
	O9327[98] = + _CHROFF_51_3_;
	{long i; for (i = 99; i < 102; i++) O9327[i] = + _CHROFF_42_3_;}
	O9327[102] = + _CHROFF_43_3_;
	O9327[103] = + _CHROFF_44_3_;
	O9327[104] = + _CHROFF_51_3_;
	O9327[105] = + _CHROFF_46_3_;
	O9327[106] = + _CHROFF_59_3_;
	{long i; for (i = 107; i < 112; i++) O9327[i] = + _CHROFF_46_3_;}
	{long i; for (i = 134; i < 136; i++) O9327[i] = + _CHROFF_21_1_;}
	{long i; for (i = 136; i < 138; i++) O9327[i] = + _CHROFF_29_3_;}
	O9327[139] = + _CHROFF_36_1_;
	O9327[142] = + _CHROFF_36_1_;
	O9327[144] = + _CHROFF_48_3_;
	O9327[147] = + _CHROFF_48_3_;
}

long O9328[148];
void O9328_init () {
	O9328[0] = + _CHROFF_7_2_;
	O9328[1] = + _CHROFF_8_2_;
	O9328[34] = + _CHROFF_35_2_;
	O9328[35] = + _CHROFF_42_4_;
	O9328[36] = + _CHROFF_37_2_;
	O9328[37] = + _CHROFF_46_4_;
	O9328[38] = + _CHROFF_37_2_;
	O9328[39] = + _CHROFF_38_2_;
	O9328[40] = + _CHROFF_37_2_;
	O9328[41] = + _CHROFF_47_4_;
	O9328[42] = + _CHROFF_49_4_;
	O9328[43] = + _CHROFF_47_4_;
	{long i; for (i = 44; i < 47; i++) O9328[i] = + _CHROFF_39_2_;}
	{long i; for (i = 47; i < 50; i++) O9328[i] = + _CHROFF_49_4_;}
	{long i; for (i = 50; i < 54; i++) O9328[i] = + _CHROFF_39_2_;}
	{long i; for (i = 54; i < 56; i++) O9328[i] = + _CHROFF_47_2_;}
	O9328[56] = + _CHROFF_50_2_;
	O9328[57] = + _CHROFF_53_2_;
	O9328[58] = + _CHROFF_49_4_;
	O9328[59] = + _CHROFF_51_4_;
	{long i; for (i = 60; i < 62; i++) O9328[i] = + _CHROFF_49_4_;}
	{long i; for (i = 62; i < 64; i++) O9328[i] = + _CHROFF_59_6_;}
	O9328[64] = + _CHROFF_65_6_;
	O9328[65] = + _CHROFF_68_6_;
	O9328[66] = + _CHROFF_35_2_;
	O9328[67] = + _CHROFF_43_2_;
	{long i; for (i = 68; i < 70; i++) O9328[i] = + _CHROFF_37_2_;}
	O9328[70] = + _CHROFF_35_2_;
	{long i; for (i = 71; i < 76; i++) O9328[i] = + _CHROFF_37_2_;}
	{long i; for (i = 76; i < 78; i++) O9328[i] = + _CHROFF_36_2_;}
	O9328[78] = + _CHROFF_40_2_;
	O9328[79] = + _CHROFF_37_2_;
	O9328[80] = + _CHROFF_41_2_;
	O9328[81] = + _CHROFF_37_2_;
	{long i; for (i = 82; i < 85; i++) O9328[i] = + _CHROFF_35_2_;}
	{long i; for (i = 85; i < 89; i++) O9328[i] = + _CHROFF_36_2_;}
	O9328[89] = + _CHROFF_42_4_;
	O9328[90] = + _CHROFF_45_4_;
	O9328[91] = + _CHROFF_58_4_;
	O9328[92] = + _CHROFF_51_4_;
	{long i; for (i = 93; i < 97; i++) O9328[i] = + _CHROFF_44_4_;}
	O9328[97] = + _CHROFF_50_4_;
	O9328[98] = + _CHROFF_51_4_;
	{long i; for (i = 99; i < 102; i++) O9328[i] = + _CHROFF_42_4_;}
	O9328[102] = + _CHROFF_43_4_;
	O9328[103] = + _CHROFF_44_4_;
	O9328[104] = + _CHROFF_51_4_;
	O9328[105] = + _CHROFF_46_4_;
	O9328[106] = + _CHROFF_59_4_;
	{long i; for (i = 107; i < 112; i++) O9328[i] = + _CHROFF_46_4_;}
	{long i; for (i = 134; i < 136; i++) O9328[i] = + _CHROFF_21_2_;}
	{long i; for (i = 136; i < 138; i++) O9328[i] = + _CHROFF_29_4_;}
	O9328[139] = + _CHROFF_36_2_;
	O9328[142] = + _CHROFF_36_2_;
	O9328[144] = + _CHROFF_48_4_;
	O9328[147] = + _CHROFF_48_4_;
}

long O9330[148];
void O9330_init () {
	O9330[0] = + _CHROFF_7_3_;
	O9330[1] = + _CHROFF_8_3_;
	O9330[34] = + _CHROFF_35_3_;
	O9330[35] = + _CHROFF_42_5_;
	O9330[36] = + _CHROFF_37_3_;
	O9330[37] = + _CHROFF_46_5_;
	O9330[38] = + _CHROFF_37_3_;
	O9330[39] = + _CHROFF_38_3_;
	O9330[40] = + _CHROFF_37_3_;
	O9330[41] = + _CHROFF_47_5_;
	O9330[42] = + _CHROFF_49_5_;
	O9330[43] = + _CHROFF_47_5_;
	{long i; for (i = 44; i < 47; i++) O9330[i] = + _CHROFF_39_3_;}
	{long i; for (i = 47; i < 50; i++) O9330[i] = + _CHROFF_49_5_;}
	{long i; for (i = 50; i < 54; i++) O9330[i] = + _CHROFF_39_3_;}
	{long i; for (i = 54; i < 56; i++) O9330[i] = + _CHROFF_47_3_;}
	O9330[56] = + _CHROFF_50_3_;
	O9330[57] = + _CHROFF_53_3_;
	O9330[58] = + _CHROFF_49_5_;
	O9330[59] = + _CHROFF_51_5_;
	{long i; for (i = 60; i < 62; i++) O9330[i] = + _CHROFF_49_5_;}
	{long i; for (i = 62; i < 64; i++) O9330[i] = + _CHROFF_59_7_;}
	O9330[64] = + _CHROFF_65_7_;
	O9330[65] = + _CHROFF_68_7_;
	O9330[66] = + _CHROFF_35_3_;
	O9330[67] = + _CHROFF_43_3_;
	{long i; for (i = 68; i < 70; i++) O9330[i] = + _CHROFF_37_3_;}
	O9330[70] = + _CHROFF_35_3_;
	{long i; for (i = 71; i < 76; i++) O9330[i] = + _CHROFF_37_3_;}
	{long i; for (i = 76; i < 78; i++) O9330[i] = + _CHROFF_36_3_;}
	O9330[78] = + _CHROFF_40_3_;
	O9330[79] = + _CHROFF_37_3_;
	O9330[80] = + _CHROFF_41_3_;
	O9330[81] = + _CHROFF_37_3_;
	{long i; for (i = 82; i < 85; i++) O9330[i] = + _CHROFF_35_3_;}
	{long i; for (i = 85; i < 89; i++) O9330[i] = + _CHROFF_36_3_;}
	O9330[89] = + _CHROFF_42_5_;
	O9330[90] = + _CHROFF_45_5_;
	O9330[91] = + _CHROFF_58_5_;
	O9330[92] = + _CHROFF_51_5_;
	{long i; for (i = 93; i < 97; i++) O9330[i] = + _CHROFF_44_5_;}
	O9330[97] = + _CHROFF_50_5_;
	O9330[98] = + _CHROFF_51_5_;
	{long i; for (i = 99; i < 102; i++) O9330[i] = + _CHROFF_42_5_;}
	O9330[102] = + _CHROFF_43_5_;
	O9330[103] = + _CHROFF_44_5_;
	O9330[104] = + _CHROFF_51_5_;
	O9330[105] = + _CHROFF_46_5_;
	O9330[106] = + _CHROFF_59_5_;
	{long i; for (i = 107; i < 112; i++) O9330[i] = + _CHROFF_46_5_;}
	{long i; for (i = 134; i < 136; i++) O9330[i] = + _CHROFF_21_3_;}
	{long i; for (i = 136; i < 138; i++) O9330[i] = + _CHROFF_29_5_;}
	O9330[139] = + _CHROFF_36_3_;
	O9330[142] = + _CHROFF_36_3_;
	O9330[144] = + _CHROFF_48_5_;
	O9330[147] = + _CHROFF_48_5_;
}

long O9359[147];
void O9359_init () {
	O9359[0] = + _CHROFF_8_4_;
	O9359[34] = + _CHROFF_42_6_;
	O9359[36] = + _CHROFF_46_6_;
	O9359[40] = + _CHROFF_47_6_;
	O9359[41] = + _CHROFF_49_6_;
	O9359[42] = + _CHROFF_47_6_;
	{long i; for (i = 46; i < 49; i++) O9359[i] = + _CHROFF_49_6_;}
	O9359[57] = + _CHROFF_49_6_;
	O9359[58] = + _CHROFF_51_6_;
	{long i; for (i = 59; i < 61; i++) O9359[i] = + _CHROFF_49_6_;}
	{long i; for (i = 61; i < 63; i++) O9359[i] = + _CHROFF_59_8_;}
	O9359[63] = + _CHROFF_65_8_;
	O9359[64] = + _CHROFF_68_8_;
	O9359[88] = + _CHROFF_42_6_;
	O9359[89] = + _CHROFF_45_6_;
	O9359[90] = + _CHROFF_58_6_;
	O9359[91] = + _CHROFF_51_6_;
	{long i; for (i = 92; i < 96; i++) O9359[i] = + _CHROFF_44_6_;}
	O9359[96] = + _CHROFF_50_6_;
	O9359[97] = + _CHROFF_51_6_;
	{long i; for (i = 98; i < 101; i++) O9359[i] = + _CHROFF_42_6_;}
	O9359[101] = + _CHROFF_43_6_;
	O9359[102] = + _CHROFF_44_6_;
	O9359[103] = + _CHROFF_51_6_;
	O9359[104] = + _CHROFF_46_6_;
	O9359[105] = + _CHROFF_59_6_;
	{long i; for (i = 106; i < 111; i++) O9359[i] = + _CHROFF_46_6_;}
	{long i; for (i = 135; i < 137; i++) O9359[i] = + _CHROFF_29_6_;}
	O9359[143] = + _CHROFF_48_6_;
	O9359[146] = + _CHROFF_48_6_;
}

long O9360[147];
void O9360_init () {
	O9360[0] = + _I16OFF_8_6_4_;
	O9360[34] = + _I16OFF_42_12_4_;
	O9360[36] = + _I16OFF_46_12_4_;
	O9360[40] = + _I16OFF_47_12_4_;
	O9360[41] = + _I16OFF_49_12_4_;
	O9360[42] = + _I16OFF_47_12_4_;
	{long i; for (i = 46; i < 49; i++) O9360[i] = + _I16OFF_49_13_4_;}
	O9360[57] = + _I16OFF_49_13_4_;
	O9360[58] = + _I16OFF_51_13_4_;
	{long i; for (i = 59; i < 61; i++) O9360[i] = + _I16OFF_49_14_4_;}
	O9360[61] = + _I16OFF_59_21_4_;
	O9360[62] = + _I16OFF_59_23_4_;
	O9360[63] = + _I16OFF_65_25_4_;
	O9360[64] = + _I16OFF_68_26_4_;
	O9360[88] = + _I16OFF_42_13_4_;
	O9360[89] = + _I16OFF_45_16_4_;
	O9360[90] = + _I16OFF_58_14_4_;
	O9360[91] = + _I16OFF_51_13_4_;
	{long i; for (i = 92; i < 94; i++) O9360[i] = + _I16OFF_44_13_4_;}
	{long i; for (i = 94; i < 96; i++) O9360[i] = + _I16OFF_44_14_4_;}
	O9360[96] = + _I16OFF_50_13_4_;
	O9360[97] = + _I16OFF_51_14_4_;
	{long i; for (i = 98; i < 101; i++) O9360[i] = + _I16OFF_42_13_4_;}
	O9360[101] = + _I16OFF_43_13_4_;
	O9360[102] = + _I16OFF_44_15_4_;
	O9360[103] = + _I16OFF_51_18_4_;
	O9360[104] = + _I16OFF_46_14_4_;
	O9360[105] = + _I16OFF_59_16_4_;
	{long i; for (i = 106; i < 111; i++) O9360[i] = + _I16OFF_46_14_4_;}
	{long i; for (i = 135; i < 137; i++) O9360[i] = + _I16OFF_29_14_4_;}
	O9360[143] = + _I16OFF_48_19_4_;
	O9360[146] = + _I16OFF_48_18_4_;
}

long O9361[147];
void O9361_init () {
	O9361[0] = + _I16OFF_8_6_5_;
	O9361[34] = + _I16OFF_42_12_5_;
	O9361[36] = + _I16OFF_46_12_5_;
	O9361[40] = + _I16OFF_47_12_5_;
	O9361[41] = + _I16OFF_49_12_5_;
	O9361[42] = + _I16OFF_47_12_5_;
	{long i; for (i = 46; i < 49; i++) O9361[i] = + _I16OFF_49_13_5_;}
	O9361[57] = + _I16OFF_49_13_5_;
	O9361[58] = + _I16OFF_51_13_5_;
	{long i; for (i = 59; i < 61; i++) O9361[i] = + _I16OFF_49_14_5_;}
	O9361[61] = + _I16OFF_59_21_5_;
	O9361[62] = + _I16OFF_59_23_5_;
	O9361[63] = + _I16OFF_65_25_5_;
	O9361[64] = + _I16OFF_68_26_5_;
	O9361[88] = + _I16OFF_42_13_5_;
	O9361[89] = + _I16OFF_45_16_5_;
	O9361[90] = + _I16OFF_58_14_5_;
	O9361[91] = + _I16OFF_51_13_5_;
	{long i; for (i = 92; i < 94; i++) O9361[i] = + _I16OFF_44_13_5_;}
	{long i; for (i = 94; i < 96; i++) O9361[i] = + _I16OFF_44_14_5_;}
	O9361[96] = + _I16OFF_50_13_5_;
	O9361[97] = + _I16OFF_51_14_5_;
	{long i; for (i = 98; i < 101; i++) O9361[i] = + _I16OFF_42_13_5_;}
	O9361[101] = + _I16OFF_43_13_5_;
	O9361[102] = + _I16OFF_44_15_5_;
	O9361[103] = + _I16OFF_51_18_5_;
	O9361[104] = + _I16OFF_46_14_5_;
	O9361[105] = + _I16OFF_59_16_5_;
	{long i; for (i = 106; i < 111; i++) O9361[i] = + _I16OFF_46_14_5_;}
	{long i; for (i = 135; i < 137; i++) O9361[i] = + _I16OFF_29_14_5_;}
	O9361[143] = + _I16OFF_48_19_5_;
	O9361[146] = + _I16OFF_48_18_5_;
}

long O9366[147];
void O9366_init () {
	O9366[0] =  + _REFACS_7_;
	O9366[34] =  + _REFACS_30_;
	O9366[36] =  + _REFACS_31_;
	O9366[40] =  + _REFACS_32_;
	O9366[41] =  + _REFACS_33_;
	O9366[42] =  + _REFACS_32_;
	{long i; for (i = 46; i < 49; i++) O9366[i] =  + _REFACS_33_;}
	{long i; for (i = 57; i < 61; i++) O9366[i] =  + _REFACS_32_;}
	{long i; for (i = 61; i < 63; i++) O9366[i] =  + _REFACS_37_;}
	{long i; for (i = 63; i < 65; i++) O9366[i] =  + _REFACS_40_;}
	O9366[88] =  + _REFACS_30_;
	O9366[89] =  + _REFACS_32_;
	O9366[90] =  + _REFACS_35_;
	O9366[91] =  + _REFACS_33_;
	O9366[92] =  + _REFACS_30_;
	{long i; for (i = 93; i < 96; i++) O9366[i] =  + _REFACS_31_;}
	{long i; for (i = 96; i < 98; i++) O9366[i] =  + _REFACS_33_;}
	{long i; for (i = 98; i < 101; i++) O9366[i] =  + _REFACS_30_;}
	{long i; for (i = 101; i < 103; i++) O9366[i] =  + _REFACS_31_;}
	O9366[103] =  + _REFACS_34_;
	O9366[104] =  + _REFACS_32_;
	O9366[105] =  + _REFACS_37_;
	O9366[106] =  + _REFACS_32_;
	{long i; for (i = 107; i < 111; i++) O9366[i] =  + _REFACS_31_;}
	{long i; for (i = 135; i < 137; i++) O9366[i] =  + _REFACS_19_;}
	O9366[143] =  + _REFACS_31_;
	O9366[146] =  + _REFACS_31_;
}

long O9395[145];
void O9395_init () {
	O9395[0] =  + _REFACS_1_;
	O9395[32] =  + _REFACS_31_;
	O9395[34] =  + _REFACS_32_;
	O9395[38] =  + _REFACS_33_;
	O9395[39] =  + _REFACS_34_;
	O9395[40] =  + _REFACS_33_;
	{long i; for (i = 44; i < 47; i++) O9395[i] =  + _REFACS_34_;}
	{long i; for (i = 55; i < 59; i++) O9395[i] =  + _REFACS_33_;}
	{long i; for (i = 59; i < 61; i++) O9395[i] =  + _REFACS_38_;}
	{long i; for (i = 61; i < 63; i++) O9395[i] =  + _REFACS_41_;}
	O9395[86] =  + _REFACS_31_;
	O9395[87] =  + _REFACS_33_;
	O9395[88] =  + _REFACS_36_;
	O9395[89] =  + _REFACS_34_;
	O9395[90] =  + _REFACS_31_;
	{long i; for (i = 91; i < 94; i++) O9395[i] =  + _REFACS_32_;}
	{long i; for (i = 94; i < 96; i++) O9395[i] =  + _REFACS_34_;}
	{long i; for (i = 96; i < 99; i++) O9395[i] =  + _REFACS_31_;}
	{long i; for (i = 99; i < 101; i++) O9395[i] =  + _REFACS_32_;}
	O9395[101] =  + _REFACS_35_;
	O9395[102] =  + _REFACS_33_;
	O9395[103] =  + _REFACS_38_;
	O9395[104] =  + _REFACS_33_;
	{long i; for (i = 105; i < 109; i++) O9395[i] =  + _REFACS_32_;}
	O9395[141] =  + _REFACS_32_;
	O9395[144] =  + _REFACS_32_;
}

long O9396[145];
void O9396_init () {
	O9396[0] =  + _REFACS_2_;
	O9396[32] =  + _REFACS_32_;
	O9396[34] =  + _REFACS_33_;
	O9396[38] =  + _REFACS_34_;
	O9396[39] =  + _REFACS_35_;
	O9396[40] =  + _REFACS_34_;
	{long i; for (i = 44; i < 47; i++) O9396[i] =  + _REFACS_35_;}
	{long i; for (i = 55; i < 59; i++) O9396[i] =  + _REFACS_34_;}
	{long i; for (i = 59; i < 61; i++) O9396[i] =  + _REFACS_39_;}
	{long i; for (i = 61; i < 63; i++) O9396[i] =  + _REFACS_42_;}
	O9396[86] =  + _REFACS_32_;
	O9396[87] =  + _REFACS_34_;
	O9396[88] =  + _REFACS_37_;
	O9396[89] =  + _REFACS_35_;
	O9396[90] =  + _REFACS_32_;
	{long i; for (i = 91; i < 94; i++) O9396[i] =  + _REFACS_33_;}
	{long i; for (i = 94; i < 96; i++) O9396[i] =  + _REFACS_35_;}
	{long i; for (i = 96; i < 99; i++) O9396[i] =  + _REFACS_32_;}
	{long i; for (i = 99; i < 101; i++) O9396[i] =  + _REFACS_33_;}
	O9396[101] =  + _REFACS_36_;
	O9396[102] =  + _REFACS_34_;
	O9396[103] =  + _REFACS_39_;
	O9396[104] =  + _REFACS_34_;
	{long i; for (i = 105; i < 109; i++) O9396[i] =  + _REFACS_33_;}
	O9396[141] =  + _REFACS_33_;
	O9396[144] =  + _REFACS_33_;
}

long O9419[141];
void O9419_init () {
	{long i; for (i = 0; i < 2; i++) O9419[i] = + _CHROFF_1_0_;}
	O9419[27] = + _CHROFF_35_4_;
	O9419[28] = + _CHROFF_42_7_;
	O9419[29] = + _CHROFF_37_4_;
	O9419[30] = + _CHROFF_46_7_;
	O9419[31] = + _CHROFF_37_4_;
	O9419[32] = + _CHROFF_38_4_;
	O9419[33] = + _CHROFF_37_4_;
	O9419[34] = + _CHROFF_47_7_;
	O9419[35] = + _CHROFF_49_7_;
	O9419[36] = + _CHROFF_47_7_;
	{long i; for (i = 37; i < 40; i++) O9419[i] = + _CHROFF_39_4_;}
	{long i; for (i = 40; i < 43; i++) O9419[i] = + _CHROFF_49_7_;}
	{long i; for (i = 43; i < 47; i++) O9419[i] = + _CHROFF_39_4_;}
	{long i; for (i = 47; i < 49; i++) O9419[i] = + _CHROFF_47_4_;}
	O9419[49] = + _CHROFF_50_4_;
	O9419[50] = + _CHROFF_53_4_;
	O9419[51] = + _CHROFF_49_7_;
	O9419[52] = + _CHROFF_51_7_;
	{long i; for (i = 53; i < 55; i++) O9419[i] = + _CHROFF_49_7_;}
	{long i; for (i = 55; i < 57; i++) O9419[i] = + _CHROFF_59_9_;}
	O9419[57] = + _CHROFF_65_9_;
	O9419[58] = + _CHROFF_68_9_;
	O9419[59] = + _CHROFF_35_4_;
	O9419[60] = + _CHROFF_43_4_;
	{long i; for (i = 61; i < 63; i++) O9419[i] = + _CHROFF_37_4_;}
	O9419[63] = + _CHROFF_35_4_;
	{long i; for (i = 64; i < 69; i++) O9419[i] = + _CHROFF_37_4_;}
	{long i; for (i = 69; i < 71; i++) O9419[i] = + _CHROFF_36_4_;}
	O9419[71] = + _CHROFF_40_4_;
	O9419[72] = + _CHROFF_37_4_;
	O9419[73] = + _CHROFF_41_4_;
	O9419[74] = + _CHROFF_37_4_;
	{long i; for (i = 75; i < 78; i++) O9419[i] = + _CHROFF_35_4_;}
	{long i; for (i = 78; i < 82; i++) O9419[i] = + _CHROFF_36_4_;}
	O9419[82] = + _CHROFF_42_7_;
	O9419[83] = + _CHROFF_45_7_;
	O9419[84] = + _CHROFF_58_7_;
	O9419[85] = + _CHROFF_51_7_;
	{long i; for (i = 86; i < 90; i++) O9419[i] = + _CHROFF_44_7_;}
	O9419[90] = + _CHROFF_50_7_;
	O9419[91] = + _CHROFF_51_7_;
	{long i; for (i = 92; i < 95; i++) O9419[i] = + _CHROFF_42_7_;}
	O9419[95] = + _CHROFF_43_7_;
	O9419[96] = + _CHROFF_44_7_;
	O9419[97] = + _CHROFF_51_7_;
	O9419[98] = + _CHROFF_46_7_;
	O9419[99] = + _CHROFF_59_7_;
	{long i; for (i = 100; i < 105; i++) O9419[i] = + _CHROFF_46_7_;}
	{long i; for (i = 115; i < 119; i++) O9419[i] = + _CHROFF_17_1_;}
	O9419[119] = + _CHROFF_18_1_;
	{long i; for (i = 120; i < 123; i++) O9419[i] = + _CHROFF_23_3_;}
	O9419[123] = + _CHROFF_24_3_;
	O9419[124] = + _CHROFF_26_3_;
	{long i; for (i = 127; i < 129; i++) O9419[i] = + _CHROFF_21_4_;}
	{long i; for (i = 129; i < 131; i++) O9419[i] = + _CHROFF_29_7_;}
	O9419[132] = + _CHROFF_36_4_;
	O9419[135] = + _CHROFF_36_4_;
	O9419[137] = + _CHROFF_48_7_;
	O9419[140] = + _CHROFF_48_7_;
}

long O9429[82];
void O9429_init () {
	{long i; for (i = 0; i < 2; i++) O9429[i] =  + _REFACS_2_;}
	{long i; for (i = 35; i < 38; i++) O9429[i] =  + _REFACS_29_;}
	{long i; for (i = 38; i < 41; i++) O9429[i] =  + _REFACS_36_;}
	{long i; for (i = 41; i < 45; i++) O9429[i] =  + _REFACS_29_;}
	{long i; for (i = 45; i < 47; i++) O9429[i] =  + _REFACS_33_;}
	{long i; for (i = 47; i < 49; i++) O9429[i] =  + _REFACS_36_;}
	{long i; for (i = 49; i < 53; i++) O9429[i] =  + _REFACS_35_;}
	{long i; for (i = 53; i < 55; i++) O9429[i] =  + _REFACS_40_;}
	{long i; for (i = 55; i < 57; i++) O9429[i] =  + _REFACS_43_;}
	O9429[60] =  + _REFACS_28_;
	O9429[81] =  + _REFACS_35_;
}

long O9430[82];
void O9430_init () {
	{long i; for (i = 0; i < 2; i++) O9430[i] = + _CHROFF_3_0_;}
	{long i; for (i = 35; i < 38; i++) O9430[i] = + _CHROFF_39_5_;}
	{long i; for (i = 38; i < 41; i++) O9430[i] = + _CHROFF_49_8_;}
	{long i; for (i = 41; i < 45; i++) O9430[i] = + _CHROFF_39_5_;}
	{long i; for (i = 45; i < 47; i++) O9430[i] = + _CHROFF_47_5_;}
	O9430[47] = + _CHROFF_50_5_;
	O9430[48] = + _CHROFF_53_5_;
	O9430[49] = + _CHROFF_49_8_;
	O9430[50] = + _CHROFF_51_8_;
	{long i; for (i = 51; i < 53; i++) O9430[i] = + _CHROFF_49_8_;}
	{long i; for (i = 53; i < 55; i++) O9430[i] = + _CHROFF_59_10_;}
	O9430[55] = + _CHROFF_65_10_;
	O9430[56] = + _CHROFF_68_10_;
	O9430[60] = + _CHROFF_37_5_;
	O9430[81] = + _CHROFF_45_8_;
}

long O9451[121];
void O9451_init () {
	O9451[0] =  + _REFACS_1_;
	{long i; for (i = 91; i < 95; i++) O9451[i] =  + _REFACS_34_;}
	{long i; for (i = 103; i < 105; i++) O9451[i] =  + _REFACS_14_;}
	{long i; for (i = 110; i < 114; i++) O9451[i] =  + _REFACS_15_;}
	O9451[114] =  + _REFACS_18_;
	{long i; for (i = 119; i < 121; i++) O9451[i] =  + _REFACS_20_;}
}

long O9453[121];
void O9453_init () {
	O9453[0] = + _PTROFF_2_1_0_0_0_0_;
	{long i; for (i = 91; i < 95; i++) O9453[i] = + _PTROFF_46_14_10_6_0_1_;}
	{long i; for (i = 103; i < 105; i++) O9453[i] = + _PTROFF_21_7_6_1_0_1_;}
	O9453[110] = + _PTROFF_23_8_6_1_0_1_;
	{long i; for (i = 111; i < 113; i++) O9453[i] = + _PTROFF_23_9_6_1_0_1_;}
	O9453[113] = + _PTROFF_24_9_6_1_0_1_;
	O9453[114] = + _PTROFF_26_8_6_2_0_1_;
	{long i; for (i = 119; i < 121; i++) O9453[i] = + _PTROFF_29_14_8_2_0_1_;}
}

long O9458[93];
void O9458_init () {
	O9458[0] =  + _REFACS_1_;
	O9458[23] =  + _REFACS_36_;
	O9458[40] =  + _REFACS_36_;
	O9458[74] =  + _REFACS_33_;
	O9458[84] =  + _REFACS_34_;
	O9458[85] =  + _REFACS_37_;
	O9458[86] =  + _REFACS_35_;
	O9458[87] =  + _REFACS_40_;
	{long i; for (i = 88; i < 93; i++) O9458[i] =  + _REFACS_35_;}
}

long O9467[111];
void O9467_init () {
	O9467[0] = + _PTROFF_2_1_0_0_0_0_;
	O9467[72] = + _PTROFF_44_13_10_6_1_1_;
	{long i; for (i = 87; i < 91; i++) O9467[i] = + _PTROFF_46_14_10_6_0_2_;}
	O9467[106] = + _PTROFF_23_8_6_1_0_2_;
	{long i; for (i = 107; i < 109; i++) O9467[i] = + _PTROFF_23_9_6_1_0_2_;}
	O9467[109] = + _PTROFF_24_9_6_1_0_2_;
	O9467[110] = + _PTROFF_26_8_6_2_0_2_;
}

long O9469[111];
void O9469_init () {
	O9469[0] =  + _REFACS_1_;
	O9469[72] =  + _REFACS_34_;
	{long i; for (i = 87; i < 91; i++) O9469[i] =  + _REFACS_36_;}
	{long i; for (i = 106; i < 110; i++) O9469[i] =  + _REFACS_16_;}
	O9469[110] =  + _REFACS_19_;
}

long O9515[116];
void O9515_init () {
	O9515[0] =  + _REFACS_8_;
	O9515[1] =  + _REFACS_11_;
	O9515[2] =  + _REFACS_27_;
	O9515[3] =  + _REFACS_33_;
	O9515[4] =  + _REFACS_28_;
	O9515[5] =  + _REFACS_34_;
	O9515[6] =  + _REFACS_28_;
	O9515[7] =  + _REFACS_29_;
	O9515[8] =  + _REFACS_28_;
	O9515[9] =  + _REFACS_35_;
	O9515[10] =  + _REFACS_37_;
	O9515[11] =  + _REFACS_35_;
	{long i; for (i = 12; i < 15; i++) O9515[i] =  + _REFACS_30_;}
	{long i; for (i = 15; i < 18; i++) O9515[i] =  + _REFACS_37_;}
	{long i; for (i = 18; i < 22; i++) O9515[i] =  + _REFACS_30_;}
	{long i; for (i = 22; i < 24; i++) O9515[i] =  + _REFACS_34_;}
	{long i; for (i = 24; i < 26; i++) O9515[i] =  + _REFACS_37_;}
	O9515[26] =  + _REFACS_36_;
	O9515[27] =  + _REFACS_37_;
	{long i; for (i = 28; i < 30; i++) O9515[i] =  + _REFACS_36_;}
	{long i; for (i = 30; i < 32; i++) O9515[i] =  + _REFACS_41_;}
	{long i; for (i = 32; i < 34; i++) O9515[i] =  + _REFACS_44_;}
	O9515[34] =  + _REFACS_27_;
	O9515[35] =  + _REFACS_31_;
	{long i; for (i = 36; i < 38; i++) O9515[i] =  + _REFACS_29_;}
	O9515[38] =  + _REFACS_27_;
	{long i; for (i = 39; i < 42; i++) O9515[i] =  + _REFACS_28_;}
	{long i; for (i = 42; i < 44; i++) O9515[i] =  + _REFACS_29_;}
	{long i; for (i = 44; i < 46; i++) O9515[i] =  + _REFACS_28_;}
	O9515[46] =  + _REFACS_31_;
	O9515[47] =  + _REFACS_29_;
	O9515[48] =  + _REFACS_33_;
	O9515[49] =  + _REFACS_29_;
	{long i; for (i = 50; i < 53; i++) O9515[i] =  + _REFACS_27_;}
	{long i; for (i = 53; i < 57; i++) O9515[i] =  + _REFACS_28_;}
	O9515[57] =  + _REFACS_33_;
	O9515[58] =  + _REFACS_36_;
	O9515[59] =  + _REFACS_38_;
	O9515[60] =  + _REFACS_36_;
	O9515[61] =  + _REFACS_35_;
	{long i; for (i = 62; i < 65; i++) O9515[i] =  + _REFACS_34_;}
	{long i; for (i = 65; i < 67; i++) O9515[i] =  + _REFACS_36_;}
	{long i; for (i = 67; i < 70; i++) O9515[i] =  + _REFACS_33_;}
	O9515[70] =  + _REFACS_34_;
	O9515[71] =  + _REFACS_35_;
	O9515[72] =  + _REFACS_38_;
	O9515[73] =  + _REFACS_36_;
	O9515[74] =  + _REFACS_41_;
	O9515[75] =  + _REFACS_36_;
	{long i; for (i = 76; i < 80; i++) O9515[i] =  + _REFACS_37_;}
	O9515[80] =  + _REFACS_11_;
	{long i; for (i = 81; i < 83; i++) O9515[i] =  + _REFACS_13_;}
	O9515[83] =  + _REFACS_11_;
	{long i; for (i = 84; i < 86; i++) O9515[i] =  + _REFACS_15_;}
	{long i; for (i = 86; i < 88; i++) O9515[i] =  + _REFACS_16_;}
	{long i; for (i = 88; i < 90; i++) O9515[i] =  + _REFACS_15_;}
	{long i; for (i = 90; i < 94; i++) O9515[i] =  + _REFACS_12_;}
	O9515[94] =  + _REFACS_13_;
	{long i; for (i = 95; i < 99; i++) O9515[i] =  + _REFACS_17_;}
	O9515[99] =  + _REFACS_20_;
	{long i; for (i = 100; i < 102; i++) O9515[i] =  + _REFACS_13_;}
	{long i; for (i = 102; i < 104; i++) O9515[i] =  + _REFACS_16_;}
	{long i; for (i = 104; i < 106; i++) O9515[i] =  + _REFACS_21_;}
	O9515[107] =  + _REFACS_28_;
	O9515[110] =  + _REFACS_28_;
	O9515[112] =  + _REFACS_34_;
	O9515[115] =  + _REFACS_34_;
}

long O9516[116];
void O9516_init () {
	O9516[0] =  + _REFACS_9_;
	O9516[1] =  + _REFACS_12_;
	O9516[2] =  + _REFACS_28_;
	O9516[3] =  + _REFACS_34_;
	O9516[4] =  + _REFACS_29_;
	O9516[5] =  + _REFACS_35_;
	O9516[6] =  + _REFACS_29_;
	O9516[7] =  + _REFACS_30_;
	O9516[8] =  + _REFACS_29_;
	O9516[9] =  + _REFACS_36_;
	O9516[10] =  + _REFACS_38_;
	O9516[11] =  + _REFACS_36_;
	{long i; for (i = 12; i < 15; i++) O9516[i] =  + _REFACS_31_;}
	{long i; for (i = 15; i < 18; i++) O9516[i] =  + _REFACS_38_;}
	{long i; for (i = 18; i < 22; i++) O9516[i] =  + _REFACS_31_;}
	{long i; for (i = 22; i < 24; i++) O9516[i] =  + _REFACS_35_;}
	{long i; for (i = 24; i < 26; i++) O9516[i] =  + _REFACS_38_;}
	O9516[26] =  + _REFACS_37_;
	O9516[27] =  + _REFACS_38_;
	{long i; for (i = 28; i < 30; i++) O9516[i] =  + _REFACS_37_;}
	{long i; for (i = 30; i < 32; i++) O9516[i] =  + _REFACS_42_;}
	{long i; for (i = 32; i < 34; i++) O9516[i] =  + _REFACS_45_;}
	O9516[34] =  + _REFACS_28_;
	O9516[35] =  + _REFACS_32_;
	{long i; for (i = 36; i < 38; i++) O9516[i] =  + _REFACS_30_;}
	O9516[38] =  + _REFACS_28_;
	{long i; for (i = 39; i < 42; i++) O9516[i] =  + _REFACS_29_;}
	{long i; for (i = 42; i < 44; i++) O9516[i] =  + _REFACS_30_;}
	{long i; for (i = 44; i < 46; i++) O9516[i] =  + _REFACS_29_;}
	O9516[46] =  + _REFACS_32_;
	O9516[47] =  + _REFACS_30_;
	O9516[48] =  + _REFACS_34_;
	O9516[49] =  + _REFACS_30_;
	{long i; for (i = 50; i < 53; i++) O9516[i] =  + _REFACS_28_;}
	{long i; for (i = 53; i < 57; i++) O9516[i] =  + _REFACS_29_;}
	O9516[57] =  + _REFACS_34_;
	O9516[58] =  + _REFACS_37_;
	O9516[59] =  + _REFACS_39_;
	O9516[60] =  + _REFACS_37_;
	O9516[61] =  + _REFACS_36_;
	{long i; for (i = 62; i < 65; i++) O9516[i] =  + _REFACS_35_;}
	{long i; for (i = 65; i < 67; i++) O9516[i] =  + _REFACS_37_;}
	{long i; for (i = 67; i < 70; i++) O9516[i] =  + _REFACS_34_;}
	O9516[70] =  + _REFACS_35_;
	O9516[71] =  + _REFACS_36_;
	O9516[72] =  + _REFACS_39_;
	O9516[73] =  + _REFACS_37_;
	O9516[74] =  + _REFACS_42_;
	O9516[75] =  + _REFACS_37_;
	{long i; for (i = 76; i < 80; i++) O9516[i] =  + _REFACS_38_;}
	O9516[80] =  + _REFACS_12_;
	{long i; for (i = 81; i < 83; i++) O9516[i] =  + _REFACS_14_;}
	O9516[83] =  + _REFACS_12_;
	{long i; for (i = 84; i < 86; i++) O9516[i] =  + _REFACS_16_;}
	{long i; for (i = 86; i < 88; i++) O9516[i] =  + _REFACS_17_;}
	{long i; for (i = 88; i < 90; i++) O9516[i] =  + _REFACS_16_;}
	{long i; for (i = 90; i < 94; i++) O9516[i] =  + _REFACS_13_;}
	O9516[94] =  + _REFACS_14_;
	{long i; for (i = 95; i < 99; i++) O9516[i] =  + _REFACS_18_;}
	O9516[99] =  + _REFACS_21_;
	{long i; for (i = 100; i < 102; i++) O9516[i] =  + _REFACS_14_;}
	{long i; for (i = 102; i < 104; i++) O9516[i] =  + _REFACS_17_;}
	{long i; for (i = 104; i < 106; i++) O9516[i] =  + _REFACS_22_;}
	O9516[107] =  + _REFACS_29_;
	O9516[110] =  + _REFACS_29_;
	O9516[112] =  + _REFACS_35_;
	O9516[115] =  + _REFACS_35_;
}

long O9518[116];
void O9518_init () {
	O9518[0] =  + _REFACS_10_;
	O9518[1] =  + _REFACS_13_;
	O9518[2] =  + _REFACS_29_;
	O9518[3] =  + _REFACS_35_;
	O9518[4] =  + _REFACS_30_;
	O9518[5] =  + _REFACS_36_;
	O9518[6] =  + _REFACS_30_;
	O9518[7] =  + _REFACS_31_;
	O9518[8] =  + _REFACS_30_;
	O9518[9] =  + _REFACS_37_;
	O9518[10] =  + _REFACS_39_;
	O9518[11] =  + _REFACS_37_;
	{long i; for (i = 12; i < 15; i++) O9518[i] =  + _REFACS_32_;}
	{long i; for (i = 15; i < 18; i++) O9518[i] =  + _REFACS_39_;}
	{long i; for (i = 18; i < 22; i++) O9518[i] =  + _REFACS_32_;}
	{long i; for (i = 22; i < 24; i++) O9518[i] =  + _REFACS_36_;}
	{long i; for (i = 24; i < 26; i++) O9518[i] =  + _REFACS_39_;}
	O9518[26] =  + _REFACS_38_;
	O9518[27] =  + _REFACS_39_;
	{long i; for (i = 28; i < 30; i++) O9518[i] =  + _REFACS_38_;}
	{long i; for (i = 30; i < 32; i++) O9518[i] =  + _REFACS_43_;}
	{long i; for (i = 32; i < 34; i++) O9518[i] =  + _REFACS_46_;}
	O9518[34] =  + _REFACS_29_;
	O9518[35] =  + _REFACS_33_;
	{long i; for (i = 36; i < 38; i++) O9518[i] =  + _REFACS_31_;}
	O9518[38] =  + _REFACS_29_;
	{long i; for (i = 39; i < 42; i++) O9518[i] =  + _REFACS_30_;}
	{long i; for (i = 42; i < 44; i++) O9518[i] =  + _REFACS_31_;}
	{long i; for (i = 44; i < 46; i++) O9518[i] =  + _REFACS_30_;}
	O9518[46] =  + _REFACS_33_;
	O9518[47] =  + _REFACS_31_;
	O9518[48] =  + _REFACS_35_;
	O9518[49] =  + _REFACS_31_;
	{long i; for (i = 50; i < 53; i++) O9518[i] =  + _REFACS_29_;}
	{long i; for (i = 53; i < 57; i++) O9518[i] =  + _REFACS_30_;}
	O9518[57] =  + _REFACS_35_;
	O9518[58] =  + _REFACS_38_;
	O9518[59] =  + _REFACS_40_;
	O9518[60] =  + _REFACS_38_;
	O9518[61] =  + _REFACS_37_;
	{long i; for (i = 62; i < 65; i++) O9518[i] =  + _REFACS_36_;}
	{long i; for (i = 65; i < 67; i++) O9518[i] =  + _REFACS_38_;}
	{long i; for (i = 67; i < 70; i++) O9518[i] =  + _REFACS_35_;}
	O9518[70] =  + _REFACS_36_;
	O9518[71] =  + _REFACS_37_;
	O9518[72] =  + _REFACS_40_;
	O9518[73] =  + _REFACS_38_;
	O9518[74] =  + _REFACS_43_;
	O9518[75] =  + _REFACS_38_;
	{long i; for (i = 76; i < 80; i++) O9518[i] =  + _REFACS_39_;}
	O9518[80] =  + _REFACS_13_;
	{long i; for (i = 81; i < 83; i++) O9518[i] =  + _REFACS_15_;}
	O9518[83] =  + _REFACS_13_;
	{long i; for (i = 84; i < 86; i++) O9518[i] =  + _REFACS_17_;}
	{long i; for (i = 86; i < 88; i++) O9518[i] =  + _REFACS_18_;}
	{long i; for (i = 88; i < 90; i++) O9518[i] =  + _REFACS_17_;}
	{long i; for (i = 90; i < 94; i++) O9518[i] =  + _REFACS_14_;}
	O9518[94] =  + _REFACS_15_;
	{long i; for (i = 95; i < 99; i++) O9518[i] =  + _REFACS_19_;}
	O9518[99] =  + _REFACS_22_;
	{long i; for (i = 100; i < 102; i++) O9518[i] =  + _REFACS_15_;}
	{long i; for (i = 102; i < 104; i++) O9518[i] =  + _REFACS_18_;}
	{long i; for (i = 104; i < 106; i++) O9518[i] =  + _REFACS_23_;}
	O9518[107] =  + _REFACS_30_;
	O9518[110] =  + _REFACS_30_;
	O9518[112] =  + _REFACS_36_;
	O9518[115] =  + _REFACS_36_;
}

long O9519[116];
void O9519_init () {
	O9519[0] =  + _REFACS_11_;
	O9519[1] =  + _REFACS_14_;
	O9519[2] =  + _REFACS_30_;
	O9519[3] =  + _REFACS_36_;
	O9519[4] =  + _REFACS_31_;
	O9519[5] =  + _REFACS_37_;
	O9519[6] =  + _REFACS_31_;
	O9519[7] =  + _REFACS_32_;
	O9519[8] =  + _REFACS_31_;
	O9519[9] =  + _REFACS_38_;
	O9519[10] =  + _REFACS_40_;
	O9519[11] =  + _REFACS_38_;
	{long i; for (i = 12; i < 15; i++) O9519[i] =  + _REFACS_33_;}
	{long i; for (i = 15; i < 18; i++) O9519[i] =  + _REFACS_40_;}
	{long i; for (i = 18; i < 22; i++) O9519[i] =  + _REFACS_33_;}
	{long i; for (i = 22; i < 24; i++) O9519[i] =  + _REFACS_37_;}
	{long i; for (i = 24; i < 26; i++) O9519[i] =  + _REFACS_40_;}
	O9519[26] =  + _REFACS_39_;
	O9519[27] =  + _REFACS_40_;
	{long i; for (i = 28; i < 30; i++) O9519[i] =  + _REFACS_39_;}
	{long i; for (i = 30; i < 32; i++) O9519[i] =  + _REFACS_44_;}
	{long i; for (i = 32; i < 34; i++) O9519[i] =  + _REFACS_47_;}
	O9519[34] =  + _REFACS_30_;
	O9519[35] =  + _REFACS_34_;
	{long i; for (i = 36; i < 38; i++) O9519[i] =  + _REFACS_32_;}
	O9519[38] =  + _REFACS_30_;
	{long i; for (i = 39; i < 42; i++) O9519[i] =  + _REFACS_31_;}
	{long i; for (i = 42; i < 44; i++) O9519[i] =  + _REFACS_32_;}
	{long i; for (i = 44; i < 46; i++) O9519[i] =  + _REFACS_31_;}
	O9519[46] =  + _REFACS_34_;
	O9519[47] =  + _REFACS_32_;
	O9519[48] =  + _REFACS_36_;
	O9519[49] =  + _REFACS_32_;
	{long i; for (i = 50; i < 53; i++) O9519[i] =  + _REFACS_30_;}
	{long i; for (i = 53; i < 57; i++) O9519[i] =  + _REFACS_31_;}
	O9519[57] =  + _REFACS_36_;
	O9519[58] =  + _REFACS_39_;
	O9519[59] =  + _REFACS_41_;
	O9519[60] =  + _REFACS_39_;
	O9519[61] =  + _REFACS_38_;
	{long i; for (i = 62; i < 65; i++) O9519[i] =  + _REFACS_37_;}
	{long i; for (i = 65; i < 67; i++) O9519[i] =  + _REFACS_39_;}
	{long i; for (i = 67; i < 70; i++) O9519[i] =  + _REFACS_36_;}
	O9519[70] =  + _REFACS_37_;
	O9519[71] =  + _REFACS_38_;
	O9519[72] =  + _REFACS_41_;
	O9519[73] =  + _REFACS_39_;
	O9519[74] =  + _REFACS_44_;
	O9519[75] =  + _REFACS_39_;
	{long i; for (i = 76; i < 80; i++) O9519[i] =  + _REFACS_40_;}
	O9519[80] =  + _REFACS_14_;
	{long i; for (i = 81; i < 83; i++) O9519[i] =  + _REFACS_16_;}
	O9519[83] =  + _REFACS_14_;
	{long i; for (i = 84; i < 86; i++) O9519[i] =  + _REFACS_18_;}
	{long i; for (i = 86; i < 88; i++) O9519[i] =  + _REFACS_19_;}
	{long i; for (i = 88; i < 90; i++) O9519[i] =  + _REFACS_18_;}
	{long i; for (i = 90; i < 94; i++) O9519[i] =  + _REFACS_15_;}
	O9519[94] =  + _REFACS_16_;
	{long i; for (i = 95; i < 99; i++) O9519[i] =  + _REFACS_20_;}
	O9519[99] =  + _REFACS_23_;
	{long i; for (i = 100; i < 102; i++) O9519[i] =  + _REFACS_16_;}
	{long i; for (i = 102; i < 104; i++) O9519[i] =  + _REFACS_19_;}
	{long i; for (i = 104; i < 106; i++) O9519[i] =  + _REFACS_24_;}
	O9519[107] =  + _REFACS_31_;
	O9519[110] =  + _REFACS_31_;
	O9519[112] =  + _REFACS_37_;
	O9519[115] =  + _REFACS_37_;
}

long O9520[116];
void O9520_init () {
	O9520[0] =  + _REFACS_12_;
	O9520[1] =  + _REFACS_15_;
	O9520[2] =  + _REFACS_31_;
	O9520[3] =  + _REFACS_37_;
	O9520[4] =  + _REFACS_32_;
	O9520[5] =  + _REFACS_38_;
	O9520[6] =  + _REFACS_32_;
	O9520[7] =  + _REFACS_33_;
	O9520[8] =  + _REFACS_32_;
	O9520[9] =  + _REFACS_39_;
	O9520[10] =  + _REFACS_41_;
	O9520[11] =  + _REFACS_39_;
	{long i; for (i = 12; i < 15; i++) O9520[i] =  + _REFACS_34_;}
	{long i; for (i = 15; i < 18; i++) O9520[i] =  + _REFACS_41_;}
	{long i; for (i = 18; i < 22; i++) O9520[i] =  + _REFACS_34_;}
	{long i; for (i = 22; i < 24; i++) O9520[i] =  + _REFACS_38_;}
	{long i; for (i = 24; i < 26; i++) O9520[i] =  + _REFACS_41_;}
	O9520[26] =  + _REFACS_40_;
	O9520[27] =  + _REFACS_41_;
	{long i; for (i = 28; i < 30; i++) O9520[i] =  + _REFACS_40_;}
	{long i; for (i = 30; i < 32; i++) O9520[i] =  + _REFACS_45_;}
	{long i; for (i = 32; i < 34; i++) O9520[i] =  + _REFACS_48_;}
	O9520[34] =  + _REFACS_31_;
	O9520[35] =  + _REFACS_35_;
	{long i; for (i = 36; i < 38; i++) O9520[i] =  + _REFACS_33_;}
	O9520[38] =  + _REFACS_31_;
	{long i; for (i = 39; i < 42; i++) O9520[i] =  + _REFACS_32_;}
	{long i; for (i = 42; i < 44; i++) O9520[i] =  + _REFACS_33_;}
	{long i; for (i = 44; i < 46; i++) O9520[i] =  + _REFACS_32_;}
	O9520[46] =  + _REFACS_35_;
	O9520[47] =  + _REFACS_33_;
	O9520[48] =  + _REFACS_37_;
	O9520[49] =  + _REFACS_33_;
	{long i; for (i = 50; i < 53; i++) O9520[i] =  + _REFACS_31_;}
	{long i; for (i = 53; i < 57; i++) O9520[i] =  + _REFACS_32_;}
	O9520[57] =  + _REFACS_37_;
	O9520[58] =  + _REFACS_40_;
	O9520[59] =  + _REFACS_42_;
	O9520[60] =  + _REFACS_40_;
	O9520[61] =  + _REFACS_39_;
	{long i; for (i = 62; i < 65; i++) O9520[i] =  + _REFACS_38_;}
	{long i; for (i = 65; i < 67; i++) O9520[i] =  + _REFACS_40_;}
	{long i; for (i = 67; i < 70; i++) O9520[i] =  + _REFACS_37_;}
	O9520[70] =  + _REFACS_38_;
	O9520[71] =  + _REFACS_39_;
	O9520[72] =  + _REFACS_42_;
	O9520[73] =  + _REFACS_40_;
	O9520[74] =  + _REFACS_45_;
	O9520[75] =  + _REFACS_40_;
	{long i; for (i = 76; i < 80; i++) O9520[i] =  + _REFACS_41_;}
	O9520[80] =  + _REFACS_15_;
	{long i; for (i = 81; i < 83; i++) O9520[i] =  + _REFACS_17_;}
	O9520[83] =  + _REFACS_15_;
	{long i; for (i = 84; i < 86; i++) O9520[i] =  + _REFACS_19_;}
	{long i; for (i = 86; i < 88; i++) O9520[i] =  + _REFACS_20_;}
	{long i; for (i = 88; i < 90; i++) O9520[i] =  + _REFACS_19_;}
	{long i; for (i = 90; i < 94; i++) O9520[i] =  + _REFACS_16_;}
	O9520[94] =  + _REFACS_17_;
	{long i; for (i = 95; i < 99; i++) O9520[i] =  + _REFACS_21_;}
	O9520[99] =  + _REFACS_24_;
	{long i; for (i = 100; i < 102; i++) O9520[i] =  + _REFACS_17_;}
	{long i; for (i = 102; i < 104; i++) O9520[i] =  + _REFACS_20_;}
	{long i; for (i = 104; i < 106; i++) O9520[i] =  + _REFACS_25_;}
	O9520[107] =  + _REFACS_32_;
	O9520[110] =  + _REFACS_32_;
	O9520[112] =  + _REFACS_38_;
	O9520[115] =  + _REFACS_38_;
}

long O9540[116];
void O9540_init () {
	O9540[0] = + _CHROFF_13_1_;
	O9540[1] = + _CHROFF_16_3_;
	O9540[2] = + _CHROFF_35_5_;
	O9540[3] = + _CHROFF_42_8_;
	O9540[4] = + _CHROFF_37_5_;
	O9540[5] = + _CHROFF_46_8_;
	O9540[6] = + _CHROFF_37_5_;
	O9540[7] = + _CHROFF_38_5_;
	O9540[8] = + _CHROFF_37_5_;
	O9540[9] = + _CHROFF_47_8_;
	O9540[10] = + _CHROFF_49_8_;
	O9540[11] = + _CHROFF_47_8_;
	{long i; for (i = 12; i < 15; i++) O9540[i] = + _CHROFF_39_6_;}
	{long i; for (i = 15; i < 18; i++) O9540[i] = + _CHROFF_49_9_;}
	{long i; for (i = 18; i < 22; i++) O9540[i] = + _CHROFF_39_6_;}
	{long i; for (i = 22; i < 24; i++) O9540[i] = + _CHROFF_47_6_;}
	O9540[24] = + _CHROFF_50_6_;
	O9540[25] = + _CHROFF_53_6_;
	O9540[26] = + _CHROFF_49_9_;
	O9540[27] = + _CHROFF_51_9_;
	{long i; for (i = 28; i < 30; i++) O9540[i] = + _CHROFF_49_9_;}
	{long i; for (i = 30; i < 32; i++) O9540[i] = + _CHROFF_59_11_;}
	O9540[32] = + _CHROFF_65_11_;
	O9540[33] = + _CHROFF_68_11_;
	O9540[34] = + _CHROFF_35_5_;
	O9540[35] = + _CHROFF_43_5_;
	O9540[36] = + _CHROFF_37_5_;
	O9540[37] = + _CHROFF_37_6_;
	O9540[38] = + _CHROFF_35_5_;
	{long i; for (i = 39; i < 44; i++) O9540[i] = + _CHROFF_37_5_;}
	{long i; for (i = 44; i < 46; i++) O9540[i] = + _CHROFF_36_5_;}
	O9540[46] = + _CHROFF_40_5_;
	O9540[47] = + _CHROFF_37_5_;
	O9540[48] = + _CHROFF_41_5_;
	O9540[49] = + _CHROFF_37_5_;
	{long i; for (i = 50; i < 53; i++) O9540[i] = + _CHROFF_35_5_;}
	{long i; for (i = 53; i < 57; i++) O9540[i] = + _CHROFF_36_5_;}
	O9540[57] = + _CHROFF_42_8_;
	O9540[58] = + _CHROFF_45_9_;
	O9540[59] = + _CHROFF_58_8_;
	O9540[60] = + _CHROFF_51_8_;
	{long i; for (i = 61; i < 65; i++) O9540[i] = + _CHROFF_44_8_;}
	O9540[65] = + _CHROFF_50_8_;
	O9540[66] = + _CHROFF_51_8_;
	{long i; for (i = 67; i < 70; i++) O9540[i] = + _CHROFF_42_8_;}
	O9540[70] = + _CHROFF_43_8_;
	O9540[71] = + _CHROFF_44_8_;
	O9540[72] = + _CHROFF_51_8_;
	O9540[73] = + _CHROFF_46_8_;
	O9540[74] = + _CHROFF_59_8_;
	{long i; for (i = 75; i < 80; i++) O9540[i] = + _CHROFF_46_8_;}
	O9540[80] = + _CHROFF_16_1_;
	O9540[81] = + _CHROFF_18_1_;
	O9540[82] = + _CHROFF_23_1_;
	O9540[83] = + _CHROFF_16_1_;
	{long i; for (i = 84; i < 86; i++) O9540[i] = + _CHROFF_20_1_;}
	{long i; for (i = 86; i < 88; i++) O9540[i] = + _CHROFF_25_1_;}
	{long i; for (i = 88; i < 90; i++) O9540[i] = + _CHROFF_21_3_;}
	{long i; for (i = 90; i < 94; i++) O9540[i] = + _CHROFF_17_2_;}
	O9540[94] = + _CHROFF_18_2_;
	{long i; for (i = 95; i < 98; i++) O9540[i] = + _CHROFF_23_4_;}
	O9540[98] = + _CHROFF_24_4_;
	O9540[99] = + _CHROFF_26_4_;
	O9540[100] = + _CHROFF_19_1_;
	O9540[101] = + _CHROFF_22_1_;
	{long i; for (i = 102; i < 104; i++) O9540[i] = + _CHROFF_21_5_;}
	{long i; for (i = 104; i < 106; i++) O9540[i] = + _CHROFF_29_8_;}
	O9540[107] = + _CHROFF_36_5_;
	O9540[110] = + _CHROFF_36_5_;
	O9540[112] = + _CHROFF_48_8_;
	O9540[115] = + _CHROFF_48_8_;
}

long O9545[116];
void O9545_init () {
	O9545[0] = + _I16OFF_13_5_4_;
	O9545[1] = + _I16OFF_16_7_4_;
	O9545[2] = + _I16OFF_35_9_4_;
	O9545[3] = + _I16OFF_42_12_6_;
	O9545[4] = + _I16OFF_37_9_4_;
	O9545[5] = + _I16OFF_46_12_6_;
	O9545[6] = + _I16OFF_37_9_4_;
	O9545[7] = + _I16OFF_38_9_4_;
	O9545[8] = + _I16OFF_37_9_4_;
	O9545[9] = + _I16OFF_47_12_6_;
	O9545[10] = + _I16OFF_49_12_6_;
	O9545[11] = + _I16OFF_47_12_6_;
	{long i; for (i = 12; i < 15; i++) O9545[i] = + _I16OFF_39_10_4_;}
	{long i; for (i = 15; i < 18; i++) O9545[i] = + _I16OFF_49_13_6_;}
	{long i; for (i = 18; i < 22; i++) O9545[i] = + _I16OFF_39_10_4_;}
	O9545[22] = + _I16OFF_47_12_4_;
	O9545[23] = + _I16OFF_47_14_4_;
	O9545[24] = + _I16OFF_50_13_4_;
	O9545[25] = + _I16OFF_53_13_4_;
	O9545[26] = + _I16OFF_49_13_6_;
	O9545[27] = + _I16OFF_51_13_6_;
	{long i; for (i = 28; i < 30; i++) O9545[i] = + _I16OFF_49_14_6_;}
	O9545[30] = + _I16OFF_59_21_6_;
	O9545[31] = + _I16OFF_59_23_6_;
	O9545[32] = + _I16OFF_65_25_6_;
	O9545[33] = + _I16OFF_68_26_6_;
	O9545[34] = + _I16OFF_35_9_4_;
	O9545[35] = + _I16OFF_43_9_4_;
	O9545[36] = + _I16OFF_37_9_4_;
	O9545[37] = + _I16OFF_37_10_4_;
	O9545[38] = + _I16OFF_35_9_4_;
	{long i; for (i = 39; i < 43; i++) O9545[i] = + _I16OFF_37_9_4_;}
	O9545[43] = + _I16OFF_37_10_4_;
	{long i; for (i = 44; i < 46; i++) O9545[i] = + _I16OFF_36_9_4_;}
	O9545[46] = + _I16OFF_40_12_4_;
	O9545[47] = + _I16OFF_37_9_4_;
	O9545[48] = + _I16OFF_41_9_4_;
	O9545[49] = + _I16OFF_37_9_4_;
	{long i; for (i = 50; i < 53; i++) O9545[i] = + _I16OFF_35_9_4_;}
	{long i; for (i = 53; i < 57; i++) O9545[i] = + _I16OFF_36_9_4_;}
	O9545[57] = + _I16OFF_42_13_6_;
	O9545[58] = + _I16OFF_45_16_6_;
	O9545[59] = + _I16OFF_58_14_6_;
	O9545[60] = + _I16OFF_51_13_6_;
	{long i; for (i = 61; i < 63; i++) O9545[i] = + _I16OFF_44_13_6_;}
	{long i; for (i = 63; i < 65; i++) O9545[i] = + _I16OFF_44_14_6_;}
	O9545[65] = + _I16OFF_50_13_6_;
	O9545[66] = + _I16OFF_51_14_6_;
	{long i; for (i = 67; i < 70; i++) O9545[i] = + _I16OFF_42_13_6_;}
	O9545[70] = + _I16OFF_43_13_6_;
	O9545[71] = + _I16OFF_44_15_6_;
	O9545[72] = + _I16OFF_51_18_6_;
	O9545[73] = + _I16OFF_46_14_6_;
	O9545[74] = + _I16OFF_59_16_6_;
	{long i; for (i = 75; i < 80; i++) O9545[i] = + _I16OFF_46_14_6_;}
	O9545[80] = + _I16OFF_16_5_4_;
	O9545[81] = + _I16OFF_18_5_4_;
	O9545[82] = + _I16OFF_23_5_4_;
	O9545[83] = + _I16OFF_16_5_4_;
	{long i; for (i = 84; i < 86; i++) O9545[i] = + _I16OFF_20_5_4_;}
	{long i; for (i = 86; i < 88; i++) O9545[i] = + _I16OFF_25_6_4_;}
	{long i; for (i = 88; i < 90; i++) O9545[i] = + _I16OFF_21_7_4_;}
	{long i; for (i = 90; i < 94; i++) O9545[i] = + _I16OFF_17_6_4_;}
	O9545[94] = + _I16OFF_18_6_4_;
	O9545[95] = + _I16OFF_23_8_4_;
	{long i; for (i = 96; i < 98; i++) O9545[i] = + _I16OFF_23_9_4_;}
	O9545[98] = + _I16OFF_24_9_4_;
	O9545[99] = + _I16OFF_26_8_4_;
	O9545[100] = + _I16OFF_19_5_4_;
	O9545[101] = + _I16OFF_22_5_4_;
	{long i; for (i = 102; i < 104; i++) O9545[i] = + _I16OFF_21_10_4_;}
	{long i; for (i = 104; i < 106; i++) O9545[i] = + _I16OFF_29_14_6_;}
	O9545[107] = + _I16OFF_36_10_4_;
	O9545[110] = + _I16OFF_36_9_4_;
	O9545[112] = + _I16OFF_48_19_6_;
	O9545[115] = + _I16OFF_48_18_6_;
}

long O9546[116];
void O9546_init () {
	O9546[0] = + _I16OFF_13_5_5_;
	O9546[1] = + _I16OFF_16_7_5_;
	O9546[2] = + _I16OFF_35_9_5_;
	O9546[3] = + _I16OFF_42_12_7_;
	O9546[4] = + _I16OFF_37_9_5_;
	O9546[5] = + _I16OFF_46_12_7_;
	O9546[6] = + _I16OFF_37_9_5_;
	O9546[7] = + _I16OFF_38_9_5_;
	O9546[8] = + _I16OFF_37_9_5_;
	O9546[9] = + _I16OFF_47_12_7_;
	O9546[10] = + _I16OFF_49_12_7_;
	O9546[11] = + _I16OFF_47_12_7_;
	{long i; for (i = 12; i < 15; i++) O9546[i] = + _I16OFF_39_10_5_;}
	{long i; for (i = 15; i < 18; i++) O9546[i] = + _I16OFF_49_13_7_;}
	{long i; for (i = 18; i < 22; i++) O9546[i] = + _I16OFF_39_10_5_;}
	O9546[22] = + _I16OFF_47_12_5_;
	O9546[23] = + _I16OFF_47_14_5_;
	O9546[24] = + _I16OFF_50_13_5_;
	O9546[25] = + _I16OFF_53_13_5_;
	O9546[26] = + _I16OFF_49_13_7_;
	O9546[27] = + _I16OFF_51_13_7_;
	{long i; for (i = 28; i < 30; i++) O9546[i] = + _I16OFF_49_14_7_;}
	O9546[30] = + _I16OFF_59_21_7_;
	O9546[31] = + _I16OFF_59_23_7_;
	O9546[32] = + _I16OFF_65_25_7_;
	O9546[33] = + _I16OFF_68_26_7_;
	O9546[34] = + _I16OFF_35_9_5_;
	O9546[35] = + _I16OFF_43_9_5_;
	O9546[36] = + _I16OFF_37_9_5_;
	O9546[37] = + _I16OFF_37_10_5_;
	O9546[38] = + _I16OFF_35_9_5_;
	{long i; for (i = 39; i < 43; i++) O9546[i] = + _I16OFF_37_9_5_;}
	O9546[43] = + _I16OFF_37_10_5_;
	{long i; for (i = 44; i < 46; i++) O9546[i] = + _I16OFF_36_9_5_;}
	O9546[46] = + _I16OFF_40_12_5_;
	O9546[47] = + _I16OFF_37_9_5_;
	O9546[48] = + _I16OFF_41_9_5_;
	O9546[49] = + _I16OFF_37_9_5_;
	{long i; for (i = 50; i < 53; i++) O9546[i] = + _I16OFF_35_9_5_;}
	{long i; for (i = 53; i < 57; i++) O9546[i] = + _I16OFF_36_9_5_;}
	O9546[57] = + _I16OFF_42_13_7_;
	O9546[58] = + _I16OFF_45_16_7_;
	O9546[59] = + _I16OFF_58_14_7_;
	O9546[60] = + _I16OFF_51_13_7_;
	{long i; for (i = 61; i < 63; i++) O9546[i] = + _I16OFF_44_13_7_;}
	{long i; for (i = 63; i < 65; i++) O9546[i] = + _I16OFF_44_14_7_;}
	O9546[65] = + _I16OFF_50_13_7_;
	O9546[66] = + _I16OFF_51_14_7_;
	{long i; for (i = 67; i < 70; i++) O9546[i] = + _I16OFF_42_13_7_;}
	O9546[70] = + _I16OFF_43_13_7_;
	O9546[71] = + _I16OFF_44_15_7_;
	O9546[72] = + _I16OFF_51_18_7_;
	O9546[73] = + _I16OFF_46_14_7_;
	O9546[74] = + _I16OFF_59_16_7_;
	{long i; for (i = 75; i < 80; i++) O9546[i] = + _I16OFF_46_14_7_;}
	O9546[80] = + _I16OFF_16_5_5_;
	O9546[81] = + _I16OFF_18_5_5_;
	O9546[82] = + _I16OFF_23_5_5_;
	O9546[83] = + _I16OFF_16_5_5_;
	{long i; for (i = 84; i < 86; i++) O9546[i] = + _I16OFF_20_5_5_;}
	{long i; for (i = 86; i < 88; i++) O9546[i] = + _I16OFF_25_6_5_;}
	{long i; for (i = 88; i < 90; i++) O9546[i] = + _I16OFF_21_7_5_;}
	{long i; for (i = 90; i < 94; i++) O9546[i] = + _I16OFF_17_6_5_;}
	O9546[94] = + _I16OFF_18_6_5_;
	O9546[95] = + _I16OFF_23_8_5_;
	{long i; for (i = 96; i < 98; i++) O9546[i] = + _I16OFF_23_9_5_;}
	O9546[98] = + _I16OFF_24_9_5_;
	O9546[99] = + _I16OFF_26_8_5_;
	O9546[100] = + _I16OFF_19_5_5_;
	O9546[101] = + _I16OFF_22_5_5_;
	{long i; for (i = 102; i < 104; i++) O9546[i] = + _I16OFF_21_10_5_;}
	{long i; for (i = 104; i < 106; i++) O9546[i] = + _I16OFF_29_14_7_;}
	O9546[107] = + _I16OFF_36_10_5_;
	O9546[110] = + _I16OFF_36_9_5_;
	O9546[112] = + _I16OFF_48_19_7_;
	O9546[115] = + _I16OFF_48_18_7_;
}

long O9548[116];
void O9548_init () {
	O9548[0] = + _CHROFF_13_4_;
	O9548[1] = + _CHROFF_16_6_;
	O9548[2] = + _CHROFF_35_8_;
	O9548[3] = + _CHROFF_42_11_;
	O9548[4] = + _CHROFF_37_8_;
	O9548[5] = + _CHROFF_46_11_;
	O9548[6] = + _CHROFF_37_8_;
	O9548[7] = + _CHROFF_38_8_;
	O9548[8] = + _CHROFF_37_8_;
	O9548[9] = + _CHROFF_47_11_;
	O9548[10] = + _CHROFF_49_11_;
	O9548[11] = + _CHROFF_47_11_;
	{long i; for (i = 12; i < 15; i++) O9548[i] = + _CHROFF_39_9_;}
	{long i; for (i = 15; i < 18; i++) O9548[i] = + _CHROFF_49_12_;}
	{long i; for (i = 18; i < 22; i++) O9548[i] = + _CHROFF_39_9_;}
	O9548[22] = + _CHROFF_47_11_;
	O9548[23] = + _CHROFF_47_13_;
	O9548[24] = + _CHROFF_50_12_;
	O9548[25] = + _CHROFF_53_12_;
	O9548[26] = + _CHROFF_49_12_;
	O9548[27] = + _CHROFF_51_12_;
	{long i; for (i = 28; i < 30; i++) O9548[i] = + _CHROFF_49_13_;}
	O9548[30] = + _CHROFF_59_20_;
	O9548[31] = + _CHROFF_59_22_;
	O9548[32] = + _CHROFF_65_24_;
	O9548[33] = + _CHROFF_68_25_;
	O9548[34] = + _CHROFF_35_8_;
	O9548[35] = + _CHROFF_43_8_;
	O9548[36] = + _CHROFF_37_8_;
	O9548[37] = + _CHROFF_37_9_;
	O9548[38] = + _CHROFF_35_8_;
	{long i; for (i = 39; i < 43; i++) O9548[i] = + _CHROFF_37_8_;}
	O9548[43] = + _CHROFF_37_9_;
	{long i; for (i = 44; i < 46; i++) O9548[i] = + _CHROFF_36_8_;}
	O9548[46] = + _CHROFF_40_11_;
	O9548[47] = + _CHROFF_37_8_;
	O9548[48] = + _CHROFF_41_8_;
	O9548[49] = + _CHROFF_37_8_;
	{long i; for (i = 50; i < 53; i++) O9548[i] = + _CHROFF_35_8_;}
	{long i; for (i = 53; i < 57; i++) O9548[i] = + _CHROFF_36_8_;}
	O9548[57] = + _CHROFF_42_12_;
	O9548[58] = + _CHROFF_45_15_;
	O9548[59] = + _CHROFF_58_13_;
	O9548[60] = + _CHROFF_51_12_;
	{long i; for (i = 61; i < 63; i++) O9548[i] = + _CHROFF_44_12_;}
	{long i; for (i = 63; i < 65; i++) O9548[i] = + _CHROFF_44_13_;}
	O9548[65] = + _CHROFF_50_12_;
	O9548[66] = + _CHROFF_51_13_;
	{long i; for (i = 67; i < 70; i++) O9548[i] = + _CHROFF_42_12_;}
	O9548[70] = + _CHROFF_43_12_;
	O9548[71] = + _CHROFF_44_14_;
	O9548[72] = + _CHROFF_51_17_;
	O9548[73] = + _CHROFF_46_13_;
	O9548[74] = + _CHROFF_59_15_;
	{long i; for (i = 75; i < 80; i++) O9548[i] = + _CHROFF_46_13_;}
	O9548[80] = + _CHROFF_16_4_;
	O9548[81] = + _CHROFF_18_4_;
	O9548[82] = + _CHROFF_23_4_;
	O9548[83] = + _CHROFF_16_4_;
	{long i; for (i = 84; i < 86; i++) O9548[i] = + _CHROFF_20_4_;}
	{long i; for (i = 86; i < 88; i++) O9548[i] = + _CHROFF_25_5_;}
	{long i; for (i = 88; i < 90; i++) O9548[i] = + _CHROFF_21_6_;}
	{long i; for (i = 90; i < 94; i++) O9548[i] = + _CHROFF_17_5_;}
	O9548[94] = + _CHROFF_18_5_;
	O9548[95] = + _CHROFF_23_7_;
	{long i; for (i = 96; i < 98; i++) O9548[i] = + _CHROFF_23_8_;}
	O9548[98] = + _CHROFF_24_8_;
	O9548[99] = + _CHROFF_26_7_;
	O9548[100] = + _CHROFF_19_4_;
	O9548[101] = + _CHROFF_22_4_;
	{long i; for (i = 102; i < 104; i++) O9548[i] = + _CHROFF_21_9_;}
	{long i; for (i = 104; i < 106; i++) O9548[i] = + _CHROFF_29_13_;}
	O9548[107] = + _CHROFF_36_9_;
	O9548[110] = + _CHROFF_36_8_;
	O9548[112] = + _CHROFF_48_16_;
	O9548[115] = + _CHROFF_48_15_;
}

long O9592[114];
void O9592_init () {
	O9592[0] =  + _REFACS_32_;
	O9592[1] =  + _REFACS_38_;
	O9592[2] =  + _REFACS_33_;
	O9592[3] =  + _REFACS_39_;
	O9592[4] =  + _REFACS_33_;
	O9592[5] =  + _REFACS_34_;
	O9592[6] =  + _REFACS_33_;
	O9592[7] =  + _REFACS_40_;
	O9592[8] =  + _REFACS_42_;
	O9592[9] =  + _REFACS_40_;
	{long i; for (i = 10; i < 13; i++) O9592[i] =  + _REFACS_35_;}
	{long i; for (i = 13; i < 16; i++) O9592[i] =  + _REFACS_42_;}
	{long i; for (i = 16; i < 20; i++) O9592[i] =  + _REFACS_35_;}
	{long i; for (i = 20; i < 22; i++) O9592[i] =  + _REFACS_39_;}
	{long i; for (i = 22; i < 24; i++) O9592[i] =  + _REFACS_42_;}
	O9592[24] =  + _REFACS_41_;
	O9592[25] =  + _REFACS_42_;
	{long i; for (i = 26; i < 28; i++) O9592[i] =  + _REFACS_41_;}
	{long i; for (i = 28; i < 30; i++) O9592[i] =  + _REFACS_46_;}
	{long i; for (i = 30; i < 32; i++) O9592[i] =  + _REFACS_49_;}
	O9592[32] =  + _REFACS_32_;
	O9592[33] =  + _REFACS_36_;
	{long i; for (i = 34; i < 36; i++) O9592[i] =  + _REFACS_34_;}
	O9592[36] =  + _REFACS_32_;
	{long i; for (i = 37; i < 40; i++) O9592[i] =  + _REFACS_33_;}
	{long i; for (i = 40; i < 42; i++) O9592[i] =  + _REFACS_34_;}
	{long i; for (i = 42; i < 44; i++) O9592[i] =  + _REFACS_33_;}
	O9592[44] =  + _REFACS_36_;
	O9592[45] =  + _REFACS_34_;
	O9592[46] =  + _REFACS_38_;
	O9592[47] =  + _REFACS_34_;
	{long i; for (i = 48; i < 51; i++) O9592[i] =  + _REFACS_32_;}
	{long i; for (i = 51; i < 55; i++) O9592[i] =  + _REFACS_33_;}
	O9592[55] =  + _REFACS_38_;
	O9592[56] =  + _REFACS_41_;
	O9592[57] =  + _REFACS_43_;
	O9592[58] =  + _REFACS_41_;
	O9592[59] =  + _REFACS_40_;
	{long i; for (i = 60; i < 63; i++) O9592[i] =  + _REFACS_39_;}
	{long i; for (i = 63; i < 65; i++) O9592[i] =  + _REFACS_41_;}
	{long i; for (i = 65; i < 68; i++) O9592[i] =  + _REFACS_38_;}
	O9592[68] =  + _REFACS_39_;
	O9592[69] =  + _REFACS_40_;
	O9592[70] =  + _REFACS_43_;
	O9592[71] =  + _REFACS_41_;
	O9592[72] =  + _REFACS_46_;
	O9592[73] =  + _REFACS_41_;
	{long i; for (i = 74; i < 78; i++) O9592[i] =  + _REFACS_42_;}
	O9592[105] =  + _REFACS_33_;
	O9592[108] =  + _REFACS_33_;
	O9592[110] =  + _REFACS_39_;
	O9592[113] =  + _REFACS_39_;
}

long O9593[114];
void O9593_init () {
	O9593[0] =  + _REFACS_33_;
	O9593[1] =  + _REFACS_39_;
	O9593[2] =  + _REFACS_34_;
	O9593[3] =  + _REFACS_40_;
	O9593[4] =  + _REFACS_34_;
	O9593[5] =  + _REFACS_35_;
	O9593[6] =  + _REFACS_34_;
	O9593[7] =  + _REFACS_41_;
	O9593[8] =  + _REFACS_43_;
	O9593[9] =  + _REFACS_41_;
	{long i; for (i = 10; i < 13; i++) O9593[i] =  + _REFACS_36_;}
	{long i; for (i = 13; i < 16; i++) O9593[i] =  + _REFACS_43_;}
	{long i; for (i = 16; i < 20; i++) O9593[i] =  + _REFACS_36_;}
	{long i; for (i = 20; i < 22; i++) O9593[i] =  + _REFACS_40_;}
	{long i; for (i = 22; i < 24; i++) O9593[i] =  + _REFACS_43_;}
	O9593[24] =  + _REFACS_42_;
	O9593[25] =  + _REFACS_43_;
	{long i; for (i = 26; i < 28; i++) O9593[i] =  + _REFACS_42_;}
	{long i; for (i = 28; i < 30; i++) O9593[i] =  + _REFACS_47_;}
	{long i; for (i = 30; i < 32; i++) O9593[i] =  + _REFACS_50_;}
	O9593[32] =  + _REFACS_33_;
	O9593[33] =  + _REFACS_37_;
	{long i; for (i = 34; i < 36; i++) O9593[i] =  + _REFACS_35_;}
	O9593[36] =  + _REFACS_33_;
	{long i; for (i = 37; i < 40; i++) O9593[i] =  + _REFACS_34_;}
	{long i; for (i = 40; i < 42; i++) O9593[i] =  + _REFACS_35_;}
	{long i; for (i = 42; i < 44; i++) O9593[i] =  + _REFACS_34_;}
	O9593[44] =  + _REFACS_37_;
	O9593[45] =  + _REFACS_35_;
	O9593[46] =  + _REFACS_39_;
	O9593[47] =  + _REFACS_35_;
	{long i; for (i = 48; i < 51; i++) O9593[i] =  + _REFACS_33_;}
	{long i; for (i = 51; i < 55; i++) O9593[i] =  + _REFACS_34_;}
	O9593[55] =  + _REFACS_39_;
	O9593[56] =  + _REFACS_42_;
	O9593[57] =  + _REFACS_44_;
	O9593[58] =  + _REFACS_42_;
	O9593[59] =  + _REFACS_41_;
	{long i; for (i = 60; i < 63; i++) O9593[i] =  + _REFACS_40_;}
	{long i; for (i = 63; i < 65; i++) O9593[i] =  + _REFACS_42_;}
	{long i; for (i = 65; i < 68; i++) O9593[i] =  + _REFACS_39_;}
	O9593[68] =  + _REFACS_40_;
	O9593[69] =  + _REFACS_41_;
	O9593[70] =  + _REFACS_44_;
	O9593[71] =  + _REFACS_42_;
	O9593[72] =  + _REFACS_47_;
	O9593[73] =  + _REFACS_42_;
	{long i; for (i = 74; i < 78; i++) O9593[i] =  + _REFACS_43_;}
	O9593[105] =  + _REFACS_34_;
	O9593[108] =  + _REFACS_34_;
	O9593[110] =  + _REFACS_40_;
	O9593[113] =  + _REFACS_40_;
}

long O9594[114];
void O9594_init () {
	O9594[0] =  + _REFACS_34_;
	O9594[1] =  + _REFACS_40_;
	O9594[2] =  + _REFACS_35_;
	O9594[3] =  + _REFACS_41_;
	O9594[4] =  + _REFACS_35_;
	O9594[5] =  + _REFACS_36_;
	O9594[6] =  + _REFACS_35_;
	O9594[7] =  + _REFACS_42_;
	O9594[8] =  + _REFACS_44_;
	O9594[9] =  + _REFACS_42_;
	{long i; for (i = 10; i < 13; i++) O9594[i] =  + _REFACS_37_;}
	{long i; for (i = 13; i < 16; i++) O9594[i] =  + _REFACS_44_;}
	{long i; for (i = 16; i < 20; i++) O9594[i] =  + _REFACS_37_;}
	{long i; for (i = 20; i < 22; i++) O9594[i] =  + _REFACS_41_;}
	{long i; for (i = 22; i < 24; i++) O9594[i] =  + _REFACS_44_;}
	O9594[24] =  + _REFACS_43_;
	O9594[25] =  + _REFACS_44_;
	{long i; for (i = 26; i < 28; i++) O9594[i] =  + _REFACS_43_;}
	{long i; for (i = 28; i < 30; i++) O9594[i] =  + _REFACS_48_;}
	{long i; for (i = 30; i < 32; i++) O9594[i] =  + _REFACS_51_;}
	O9594[32] =  + _REFACS_34_;
	O9594[33] =  + _REFACS_38_;
	{long i; for (i = 34; i < 36; i++) O9594[i] =  + _REFACS_36_;}
	O9594[36] =  + _REFACS_34_;
	{long i; for (i = 37; i < 40; i++) O9594[i] =  + _REFACS_35_;}
	{long i; for (i = 40; i < 42; i++) O9594[i] =  + _REFACS_36_;}
	{long i; for (i = 42; i < 44; i++) O9594[i] =  + _REFACS_35_;}
	O9594[44] =  + _REFACS_38_;
	O9594[45] =  + _REFACS_36_;
	O9594[46] =  + _REFACS_40_;
	O9594[47] =  + _REFACS_36_;
	{long i; for (i = 48; i < 51; i++) O9594[i] =  + _REFACS_34_;}
	{long i; for (i = 51; i < 55; i++) O9594[i] =  + _REFACS_35_;}
	O9594[55] =  + _REFACS_40_;
	O9594[56] =  + _REFACS_43_;
	O9594[57] =  + _REFACS_45_;
	O9594[58] =  + _REFACS_43_;
	O9594[59] =  + _REFACS_42_;
	{long i; for (i = 60; i < 63; i++) O9594[i] =  + _REFACS_41_;}
	{long i; for (i = 63; i < 65; i++) O9594[i] =  + _REFACS_43_;}
	{long i; for (i = 65; i < 68; i++) O9594[i] =  + _REFACS_40_;}
	O9594[68] =  + _REFACS_41_;
	O9594[69] =  + _REFACS_42_;
	O9594[70] =  + _REFACS_45_;
	O9594[71] =  + _REFACS_43_;
	O9594[72] =  + _REFACS_48_;
	O9594[73] =  + _REFACS_43_;
	{long i; for (i = 74; i < 78; i++) O9594[i] =  + _REFACS_44_;}
	O9594[105] =  + _REFACS_35_;
	O9594[108] =  + _REFACS_35_;
	O9594[110] =  + _REFACS_41_;
	O9594[113] =  + _REFACS_41_;
}

long O9624[113];
void O9624_init () {
	O9624[0] = + _LNGOFF_42_12_10_2_;
	O9624[2] = + _LNGOFF_46_12_10_2_;
	O9624[6] = + _LNGOFF_47_12_10_3_;
	O9624[7] = + _LNGOFF_49_12_10_5_;
	O9624[8] = + _LNGOFF_47_12_10_3_;
	{long i; for (i = 12; i < 15; i++) O9624[i] = + _LNGOFF_49_13_10_3_;}
	O9624[23] = + _LNGOFF_49_13_10_2_;
	O9624[24] = + _LNGOFF_51_13_10_2_;
	{long i; for (i = 25; i < 27; i++) O9624[i] = + _LNGOFF_49_14_10_2_;}
	O9624[27] = + _LNGOFF_59_21_10_2_;
	O9624[28] = + _LNGOFF_59_23_10_2_;
	O9624[29] = + _LNGOFF_65_25_10_2_;
	O9624[30] = + _LNGOFF_68_26_10_2_;
	O9624[54] = + _LNGOFF_42_13_10_2_;
	O9624[55] = + _LNGOFF_45_16_10_3_;
	O9624[56] = + _LNGOFF_58_14_10_5_;
	O9624[57] = + _LNGOFF_51_13_10_5_;
	{long i; for (i = 58; i < 60; i++) O9624[i] = + _LNGOFF_44_13_10_2_;}
	{long i; for (i = 60; i < 62; i++) O9624[i] = + _LNGOFF_44_14_10_2_;}
	O9624[62] = + _LNGOFF_50_13_10_5_;
	O9624[63] = + _LNGOFF_51_14_10_5_;
	{long i; for (i = 64; i < 67; i++) O9624[i] = + _LNGOFF_42_13_10_2_;}
	O9624[67] = + _LNGOFF_43_13_10_2_;
	O9624[68] = + _LNGOFF_44_15_10_2_;
	O9624[69] = + _LNGOFF_51_18_10_2_;
	O9624[70] = + _LNGOFF_46_14_10_2_;
	O9624[71] = + _LNGOFF_59_16_10_5_;
	{long i; for (i = 72; i < 77; i++) O9624[i] = + _LNGOFF_46_14_10_2_;}
	O9624[109] = + _LNGOFF_48_19_10_2_;
	O9624[112] = + _LNGOFF_48_18_10_2_;
}

long O9625[113];
void O9625_init () {
	O9625[0] = + _LNGOFF_42_12_10_3_;
	O9625[2] = + _LNGOFF_46_12_10_3_;
	O9625[6] = + _LNGOFF_47_12_10_4_;
	O9625[7] = + _LNGOFF_49_12_10_6_;
	O9625[8] = + _LNGOFF_47_12_10_4_;
	{long i; for (i = 12; i < 15; i++) O9625[i] = + _LNGOFF_49_13_10_4_;}
	O9625[23] = + _LNGOFF_49_13_10_3_;
	O9625[24] = + _LNGOFF_51_13_10_3_;
	{long i; for (i = 25; i < 27; i++) O9625[i] = + _LNGOFF_49_14_10_3_;}
	O9625[27] = + _LNGOFF_59_21_10_3_;
	O9625[28] = + _LNGOFF_59_23_10_3_;
	O9625[29] = + _LNGOFF_65_25_10_3_;
	O9625[30] = + _LNGOFF_68_26_10_3_;
	O9625[54] = + _LNGOFF_42_13_10_3_;
	O9625[55] = + _LNGOFF_45_16_10_4_;
	O9625[56] = + _LNGOFF_58_14_10_6_;
	O9625[57] = + _LNGOFF_51_13_10_6_;
	{long i; for (i = 58; i < 60; i++) O9625[i] = + _LNGOFF_44_13_10_3_;}
	{long i; for (i = 60; i < 62; i++) O9625[i] = + _LNGOFF_44_14_10_3_;}
	O9625[62] = + _LNGOFF_50_13_10_6_;
	O9625[63] = + _LNGOFF_51_14_10_6_;
	{long i; for (i = 64; i < 67; i++) O9625[i] = + _LNGOFF_42_13_10_3_;}
	O9625[67] = + _LNGOFF_43_13_10_3_;
	O9625[68] = + _LNGOFF_44_15_10_3_;
	O9625[69] = + _LNGOFF_51_18_10_3_;
	O9625[70] = + _LNGOFF_46_14_10_3_;
	O9625[71] = + _LNGOFF_59_16_10_6_;
	{long i; for (i = 72; i < 77; i++) O9625[i] = + _LNGOFF_46_14_10_3_;}
	O9625[109] = + _LNGOFF_48_19_10_3_;
	O9625[112] = + _LNGOFF_48_18_10_3_;
}

long O9626[113];
void O9626_init () {
	O9626[0] = + _LNGOFF_42_12_10_4_;
	O9626[2] = + _LNGOFF_46_12_10_4_;
	O9626[6] = + _LNGOFF_47_12_10_5_;
	O9626[7] = + _LNGOFF_49_12_10_7_;
	O9626[8] = + _LNGOFF_47_12_10_5_;
	{long i; for (i = 12; i < 15; i++) O9626[i] = + _LNGOFF_49_13_10_5_;}
	O9626[23] = + _LNGOFF_49_13_10_4_;
	O9626[24] = + _LNGOFF_51_13_10_4_;
	{long i; for (i = 25; i < 27; i++) O9626[i] = + _LNGOFF_49_14_10_4_;}
	O9626[27] = + _LNGOFF_59_21_10_4_;
	O9626[28] = + _LNGOFF_59_23_10_4_;
	O9626[29] = + _LNGOFF_65_25_10_4_;
	O9626[30] = + _LNGOFF_68_26_10_4_;
	O9626[54] = + _LNGOFF_42_13_10_4_;
	O9626[55] = + _LNGOFF_45_16_10_5_;
	O9626[56] = + _LNGOFF_58_14_10_7_;
	O9626[57] = + _LNGOFF_51_13_10_7_;
	{long i; for (i = 58; i < 60; i++) O9626[i] = + _LNGOFF_44_13_10_4_;}
	{long i; for (i = 60; i < 62; i++) O9626[i] = + _LNGOFF_44_14_10_4_;}
	O9626[62] = + _LNGOFF_50_13_10_7_;
	O9626[63] = + _LNGOFF_51_14_10_7_;
	{long i; for (i = 64; i < 67; i++) O9626[i] = + _LNGOFF_42_13_10_4_;}
	O9626[67] = + _LNGOFF_43_13_10_4_;
	O9626[68] = + _LNGOFF_44_15_10_4_;
	O9626[69] = + _LNGOFF_51_18_10_4_;
	O9626[70] = + _LNGOFF_46_14_10_4_;
	O9626[71] = + _LNGOFF_59_16_10_7_;
	{long i; for (i = 72; i < 77; i++) O9626[i] = + _LNGOFF_46_14_10_4_;}
	O9626[109] = + _LNGOFF_48_19_10_4_;
	O9626[112] = + _LNGOFF_48_18_10_4_;
}

long O9627[113];
void O9627_init () {
	O9627[0] = + _LNGOFF_42_12_10_5_;
	O9627[2] = + _LNGOFF_46_12_10_5_;
	O9627[6] = + _LNGOFF_47_12_10_6_;
	O9627[7] = + _LNGOFF_49_12_10_8_;
	O9627[8] = + _LNGOFF_47_12_10_6_;
	{long i; for (i = 12; i < 15; i++) O9627[i] = + _LNGOFF_49_13_10_6_;}
	O9627[23] = + _LNGOFF_49_13_10_5_;
	O9627[24] = + _LNGOFF_51_13_10_5_;
	{long i; for (i = 25; i < 27; i++) O9627[i] = + _LNGOFF_49_14_10_5_;}
	O9627[27] = + _LNGOFF_59_21_10_5_;
	O9627[28] = + _LNGOFF_59_23_10_5_;
	O9627[29] = + _LNGOFF_65_25_10_5_;
	O9627[30] = + _LNGOFF_68_26_10_5_;
	O9627[54] = + _LNGOFF_42_13_10_5_;
	O9627[55] = + _LNGOFF_45_16_10_6_;
	O9627[56] = + _LNGOFF_58_14_10_8_;
	O9627[57] = + _LNGOFF_51_13_10_8_;
	{long i; for (i = 58; i < 60; i++) O9627[i] = + _LNGOFF_44_13_10_5_;}
	{long i; for (i = 60; i < 62; i++) O9627[i] = + _LNGOFF_44_14_10_5_;}
	O9627[62] = + _LNGOFF_50_13_10_8_;
	O9627[63] = + _LNGOFF_51_14_10_8_;
	{long i; for (i = 64; i < 67; i++) O9627[i] = + _LNGOFF_42_13_10_5_;}
	O9627[67] = + _LNGOFF_43_13_10_5_;
	O9627[68] = + _LNGOFF_44_15_10_5_;
	O9627[69] = + _LNGOFF_51_18_10_5_;
	O9627[70] = + _LNGOFF_46_14_10_5_;
	O9627[71] = + _LNGOFF_59_16_10_8_;
	{long i; for (i = 72; i < 77; i++) O9627[i] = + _LNGOFF_46_14_10_5_;}
	O9627[109] = + _LNGOFF_48_19_10_5_;
	O9627[112] = + _LNGOFF_48_18_10_5_;
}

long O9632[113];
void O9632_init () {
	O9632[0] =  + _REFACS_41_;
	O9632[2] =  + _REFACS_42_;
	O9632[6] =  + _REFACS_43_;
	O9632[7] =  + _REFACS_45_;
	O9632[8] =  + _REFACS_43_;
	{long i; for (i = 12; i < 15; i++) O9632[i] =  + _REFACS_45_;}
	O9632[23] =  + _REFACS_44_;
	O9632[24] =  + _REFACS_45_;
	{long i; for (i = 25; i < 27; i++) O9632[i] =  + _REFACS_44_;}
	{long i; for (i = 27; i < 29; i++) O9632[i] =  + _REFACS_49_;}
	{long i; for (i = 29; i < 31; i++) O9632[i] =  + _REFACS_52_;}
	O9632[54] =  + _REFACS_41_;
	O9632[55] =  + _REFACS_44_;
	O9632[56] =  + _REFACS_46_;
	O9632[57] =  + _REFACS_44_;
	O9632[58] =  + _REFACS_43_;
	{long i; for (i = 59; i < 62; i++) O9632[i] =  + _REFACS_42_;}
	{long i; for (i = 62; i < 64; i++) O9632[i] =  + _REFACS_44_;}
	{long i; for (i = 64; i < 67; i++) O9632[i] =  + _REFACS_41_;}
	O9632[67] =  + _REFACS_42_;
	O9632[68] =  + _REFACS_43_;
	O9632[69] =  + _REFACS_46_;
	O9632[70] =  + _REFACS_44_;
	O9632[71] =  + _REFACS_49_;
	O9632[72] =  + _REFACS_44_;
	{long i; for (i = 73; i < 77; i++) O9632[i] =  + _REFACS_45_;}
	O9632[109] =  + _REFACS_42_;
	O9632[112] =  + _REFACS_42_;
}

long O9641[113];
void O9641_init () {
	O9641[0] = + _I16OFF_42_12_8_;
	O9641[2] = + _I16OFF_46_12_8_;
	O9641[6] = + _I16OFF_47_12_8_;
	O9641[7] = + _I16OFF_49_12_8_;
	O9641[8] = + _I16OFF_47_12_8_;
	{long i; for (i = 12; i < 15; i++) O9641[i] = + _I16OFF_49_13_8_;}
	O9641[23] = + _I16OFF_49_13_8_;
	O9641[24] = + _I16OFF_51_13_8_;
	{long i; for (i = 25; i < 27; i++) O9641[i] = + _I16OFF_49_14_8_;}
	O9641[27] = + _I16OFF_59_21_8_;
	O9641[28] = + _I16OFF_59_23_8_;
	O9641[29] = + _I16OFF_65_25_8_;
	O9641[30] = + _I16OFF_68_26_8_;
	O9641[54] = + _I16OFF_42_13_8_;
	O9641[55] = + _I16OFF_45_16_8_;
	O9641[56] = + _I16OFF_58_14_8_;
	O9641[57] = + _I16OFF_51_13_8_;
	{long i; for (i = 58; i < 60; i++) O9641[i] = + _I16OFF_44_13_8_;}
	{long i; for (i = 60; i < 62; i++) O9641[i] = + _I16OFF_44_14_8_;}
	O9641[62] = + _I16OFF_50_13_8_;
	O9641[63] = + _I16OFF_51_14_8_;
	{long i; for (i = 64; i < 67; i++) O9641[i] = + _I16OFF_42_13_8_;}
	O9641[67] = + _I16OFF_43_13_8_;
	O9641[68] = + _I16OFF_44_15_8_;
	O9641[69] = + _I16OFF_51_18_8_;
	O9641[70] = + _I16OFF_46_14_8_;
	O9641[71] = + _I16OFF_59_16_8_;
	{long i; for (i = 72; i < 77; i++) O9641[i] = + _I16OFF_46_14_8_;}
	O9641[109] = + _I16OFF_48_19_8_;
	O9641[112] = + _I16OFF_48_18_8_;
}

long O9642[113];
void O9642_init () {
	O9642[0] = + _I16OFF_42_12_9_;
	O9642[2] = + _I16OFF_46_12_9_;
	O9642[6] = + _I16OFF_47_12_9_;
	O9642[7] = + _I16OFF_49_12_9_;
	O9642[8] = + _I16OFF_47_12_9_;
	{long i; for (i = 12; i < 15; i++) O9642[i] = + _I16OFF_49_13_9_;}
	O9642[23] = + _I16OFF_49_13_9_;
	O9642[24] = + _I16OFF_51_13_9_;
	{long i; for (i = 25; i < 27; i++) O9642[i] = + _I16OFF_49_14_9_;}
	O9642[27] = + _I16OFF_59_21_9_;
	O9642[28] = + _I16OFF_59_23_9_;
	O9642[29] = + _I16OFF_65_25_9_;
	O9642[30] = + _I16OFF_68_26_9_;
	O9642[54] = + _I16OFF_42_13_9_;
	O9642[55] = + _I16OFF_45_16_9_;
	O9642[56] = + _I16OFF_58_14_9_;
	O9642[57] = + _I16OFF_51_13_9_;
	{long i; for (i = 58; i < 60; i++) O9642[i] = + _I16OFF_44_13_9_;}
	{long i; for (i = 60; i < 62; i++) O9642[i] = + _I16OFF_44_14_9_;}
	O9642[62] = + _I16OFF_50_13_9_;
	O9642[63] = + _I16OFF_51_14_9_;
	{long i; for (i = 64; i < 67; i++) O9642[i] = + _I16OFF_42_13_9_;}
	O9642[67] = + _I16OFF_43_13_9_;
	O9642[68] = + _I16OFF_44_15_9_;
	O9642[69] = + _I16OFF_51_18_9_;
	O9642[70] = + _I16OFF_46_14_9_;
	O9642[71] = + _I16OFF_59_16_9_;
	{long i; for (i = 72; i < 77; i++) O9642[i] = + _I16OFF_46_14_9_;}
	O9642[109] = + _I16OFF_48_19_9_;
	O9642[112] = + _I16OFF_48_18_9_;
}

long O9670[29];
void O9670_init () {
	O9670[0] =  + _REFACS_44_;
	O9670[4] =  + _REFACS_45_;
	O9670[5] =  + _REFACS_47_;
	O9670[6] =  + _REFACS_45_;
	{long i; for (i = 10; i < 13; i++) O9670[i] =  + _REFACS_47_;}
	O9670[21] =  + _REFACS_46_;
	O9670[22] =  + _REFACS_47_;
	{long i; for (i = 23; i < 25; i++) O9670[i] =  + _REFACS_46_;}
	{long i; for (i = 25; i < 27; i++) O9670[i] =  + _REFACS_51_;}
	{long i; for (i = 27; i < 29; i++) O9670[i] =  + _REFACS_54_;}
}

long O9684[29];
void O9684_init () {
	O9684[0] =  + _REFACS_45_;
	O9684[4] =  + _REFACS_46_;
	O9684[5] =  + _REFACS_48_;
	O9684[6] =  + _REFACS_46_;
	{long i; for (i = 10; i < 13; i++) O9684[i] =  + _REFACS_48_;}
	O9684[21] =  + _REFACS_47_;
	O9684[22] =  + _REFACS_48_;
	{long i; for (i = 23; i < 25; i++) O9684[i] =  + _REFACS_47_;}
	{long i; for (i = 25; i < 27; i++) O9684[i] =  + _REFACS_52_;}
	{long i; for (i = 27; i < 29; i++) O9684[i] =  + _REFACS_55_;}
}

long O9755[12];
void O9755_init () {
	{long i; for (i = 0; i < 2; i++) O9755[i] =  + _REFACS_43_;}
	{long i; for (i = 2; i < 4; i++) O9755[i] =  + _REFACS_46_;}
	{long i; for (i = 8; i < 10; i++) O9755[i] =  + _REFACS_53_;}
	{long i; for (i = 10; i < 12; i++) O9755[i] =  + _REFACS_56_;}
}

long O9756[12];
void O9756_init () {
	{long i; for (i = 0; i < 2; i++) O9756[i] =  + _REFACS_44_;}
	{long i; for (i = 2; i < 4; i++) O9756[i] =  + _REFACS_47_;}
	{long i; for (i = 8; i < 10; i++) O9756[i] =  + _REFACS_54_;}
	{long i; for (i = 10; i < 12; i++) O9756[i] =  + _REFACS_57_;}
}

long O9762[12];
void O9762_init () {
	{long i; for (i = 0; i < 2; i++) O9762[i] = + _CHROFF_47_8_;}
	O9762[2] = + _CHROFF_50_8_;
	O9762[3] = + _CHROFF_53_8_;
	{long i; for (i = 8; i < 10; i++) O9762[i] = + _CHROFF_59_13_;}
	O9762[10] = + _CHROFF_65_13_;
	O9762[11] = + _CHROFF_68_13_;
}

long O9783[12];
void O9783_init () {
	{long i; for (i = 0; i < 2; i++) O9783[i] =  + _REFACS_45_;}
	{long i; for (i = 2; i < 4; i++) O9783[i] =  + _REFACS_48_;}
	{long i; for (i = 8; i < 10; i++) O9783[i] =  + _REFACS_55_;}
	{long i; for (i = 10; i < 12; i++) O9783[i] =  + _REFACS_58_;}
}

long O9786[12];
void O9786_init () {
	{long i; for (i = 0; i < 2; i++) O9786[i] = + _CHROFF_47_9_;}
	O9786[2] = + _CHROFF_50_9_;
	O9786[3] = + _CHROFF_53_9_;
	{long i; for (i = 8; i < 10; i++) O9786[i] = + _CHROFF_59_14_;}
	O9786[10] = + _CHROFF_65_14_;
	O9786[11] = + _CHROFF_68_14_;
}

long O9787[12];
void O9787_init () {
	{long i; for (i = 0; i < 2; i++) O9787[i] =  + _REFACS_46_;}
	{long i; for (i = 2; i < 4; i++) O9787[i] =  + _REFACS_49_;}
	{long i; for (i = 8; i < 10; i++) O9787[i] =  + _REFACS_56_;}
	{long i; for (i = 10; i < 12; i++) O9787[i] =  + _REFACS_59_;}
}

long O9803[10];
void O9803_init () {
	O9803[0] = + _CHROFF_50_10_;
	O9803[1] = + _CHROFF_53_10_;
	O9803[8] = + _CHROFF_65_15_;
	O9803[9] = + _CHROFF_68_15_;
}

long O9824[8];
void O9824_init () {
	O9824[0] =  + _REFACS_48_;
	O9824[1] =  + _REFACS_49_;
	{long i; for (i = 2; i < 4; i++) O9824[i] =  + _REFACS_48_;}
	{long i; for (i = 4; i < 6; i++) O9824[i] =  + _REFACS_57_;}
	O9824[6] =  + _REFACS_60_;
	O9824[7] =  + _REFACS_63_;
}

long O9850[4];
void O9850_init () {
	O9850[0] = + _CHROFF_59_15_;
	O9850[1] = + _CHROFF_59_17_;
	O9850[2] = + _CHROFF_65_16_;
	O9850[3] = + _CHROFF_68_16_;
}

long O9851[4];
void O9851_init () {
	O9851[0] = + _CHROFF_59_16_;
	O9851[1] = + _CHROFF_59_18_;
	O9851[2] = + _CHROFF_65_17_;
	O9851[3] = + _CHROFF_68_17_;
}

long O9852[4];
void O9852_init () {
	O9852[0] = + _CHROFF_59_17_;
	O9852[1] = + _CHROFF_59_19_;
	O9852[2] = + _CHROFF_65_18_;
	O9852[3] = + _CHROFF_68_18_;
}

long O9854[4];
void O9854_init () {
	O9854[0] = + _CHROFF_59_18_;
	O9854[1] = + _CHROFF_59_20_;
	O9854[2] = + _CHROFF_65_19_;
	O9854[3] = + _CHROFF_68_19_;
}

long O9856[4];
void O9856_init () {
	O9856[0] = + _PTROFF_59_21_10_11_0_1_;
	O9856[1] = + _PTROFF_59_23_10_11_0_1_;
	O9856[2] = + _PTROFF_65_25_10_11_0_1_;
	O9856[3] = + _PTROFF_68_26_10_11_0_1_;
}

long O9858[4];
void O9858_init () {
	O9858[0] = + _LNGOFF_59_21_10_6_;
	O9858[1] = + _LNGOFF_59_23_10_6_;
	O9858[2] = + _LNGOFF_65_25_10_6_;
	O9858[3] = + _LNGOFF_68_26_10_6_;
}

long O9859[4];
void O9859_init () {
	O9859[0] = + _LNGOFF_59_21_10_7_;
	O9859[1] = + _LNGOFF_59_23_10_7_;
	O9859[2] = + _LNGOFF_65_25_10_7_;
	O9859[3] = + _LNGOFF_68_26_10_7_;
}

long O9864[4];
void O9864_init () {
	O9864[0] = + _LNGOFF_59_21_10_8_;
	O9864[1] = + _LNGOFF_59_23_10_8_;
	O9864[2] = + _LNGOFF_65_25_10_8_;
	O9864[3] = + _LNGOFF_68_26_10_8_;
}

long O9879[4];
void O9879_init () {
	O9879[0] = + _PTROFF_59_21_10_11_0_2_;
	O9879[1] = + _PTROFF_59_23_10_11_0_2_;
	O9879[2] = + _PTROFF_65_25_10_11_0_2_;
	O9879[3] = + _PTROFF_68_26_10_11_0_2_;
}

long O9880[4];
void O9880_init () {
	O9880[0] = + _PTROFF_59_21_10_11_0_3_;
	O9880[1] = + _PTROFF_59_23_10_11_0_3_;
	O9880[2] = + _PTROFF_65_25_10_11_0_3_;
	O9880[3] = + _PTROFF_68_26_10_11_0_3_;
}

long O9882[4];
void O9882_init () {
	O9882[0] = + _LNGOFF_59_21_10_9_;
	O9882[1] = + _LNGOFF_59_23_10_9_;
	O9882[2] = + _LNGOFF_65_25_10_9_;
	O9882[3] = + _LNGOFF_68_26_10_9_;
}

long O9883[4];
void O9883_init () {
	O9883[0] = + _LNGOFF_59_21_10_10_;
	O9883[1] = + _LNGOFF_59_23_10_10_;
	O9883[2] = + _LNGOFF_65_25_10_10_;
	O9883[3] = + _LNGOFF_68_26_10_10_;
}

long O9889[2];
void O9889_init () {
	O9889[0] = + _CHROFF_65_20_;
	O9889[1] = + _CHROFF_68_20_;
}

long O9890[2];
void O9890_init () {
	O9890[0] =  + _REFACS_62_;
	O9890[1] =  + _REFACS_65_;
}

long O9893[2];
void O9893_init () {
	O9893[0] = + _CHROFF_65_21_;
	O9893[1] = + _CHROFF_68_21_;
}

long O9894[2];
void O9894_init () {
	O9894[0] = + _CHROFF_65_22_;
	O9894[1] = + _CHROFF_68_22_;
}

long O10070[59];
void O10070_init () {
	O10070[0] = + _CHROFF_42_10_;
	O10070[1] = + _CHROFF_45_11_;
	O10070[2] = + _CHROFF_58_10_;
	O10070[3] = + _CHROFF_51_10_;
	{long i; for (i = 4; i < 8; i++) O10070[i] = + _CHROFF_44_10_;}
	O10070[8] = + _CHROFF_50_10_;
	O10070[9] = + _CHROFF_51_11_;
	{long i; for (i = 10; i < 13; i++) O10070[i] = + _CHROFF_42_10_;}
	O10070[13] = + _CHROFF_43_10_;
	O10070[14] = + _CHROFF_44_10_;
	O10070[15] = + _CHROFF_51_13_;
	O10070[16] = + _CHROFF_46_10_;
	O10070[17] = + _CHROFF_59_10_;
	{long i; for (i = 18; i < 23; i++) O10070[i] = + _CHROFF_46_10_;}
	O10070[55] = + _CHROFF_48_10_;
	O10070[58] = + _CHROFF_48_10_;
}

long O10263[18];
void O10263_init () {
	{long i; for (i = 0; i < 2; i++) O10263[i] =  + _REFACS_20_;}
	{long i; for (i = 7; i < 11; i++) O10263[i] =  + _REFACS_22_;}
	O10263[11] =  + _REFACS_25_;
	{long i; for (i = 16; i < 18; i++) O10263[i] =  + _REFACS_26_;}
}

long O10269[5];
void O10269_init () {
	O10269[0] = + _PTROFF_23_8_6_1_0_3_;
	{long i; for (i = 1; i < 3; i++) O10269[i] = + _PTROFF_23_9_6_1_0_3_;}
	O10269[3] = + _PTROFF_24_9_6_1_0_3_;
	O10269[4] = + _PTROFF_26_8_6_2_0_3_;
}

long O10331[10];
void O10331_init () {
	O10331[0] = + _LNGOFF_1_1_0_0_;
	O10331[1] = + _LNGOFF_36_10_6_1_;
	{long i; for (i = 2; i < 4; i++) O10331[i] = + _LNGOFF_1_1_0_0_;}
	O10331[4] = + _LNGOFF_36_9_6_1_;
	O10331[5] = + _LNGOFF_6_5_0_0_;
	O10331[6] = + _LNGOFF_48_19_10_6_;
	O10331[7] = + _LNGOFF_6_7_0_0_;
	O10331[8] = + _LNGOFF_6_5_0_0_;
	O10331[9] = + _LNGOFF_48_18_10_6_;
}

long O10407[5];
void O10407_init () {
	O10407[0] = + _PTROFF_6_5_0_3_0_0_;
	O10407[1] = + _PTROFF_48_19_10_9_0_1_;
	O10407[2] = + _PTROFF_6_7_0_5_0_0_;
	O10407[3] = + _PTROFF_6_5_0_3_0_0_;
	O10407[4] = + _PTROFF_48_18_10_9_0_1_;
}

long O10415[5];
void O10415_init () {
	O10415[0] = + _CHROFF_6_3_;
	O10415[1] = + _CHROFF_48_17_;
	O10415[2] = + _CHROFF_6_5_;
	O10415[3] = + _CHROFF_6_3_;
	O10415[4] = + _CHROFF_48_16_;
}

long O10416[5];
void O10416_init () {
	O10416[0] = + _CHROFF_6_4_;
	O10416[1] = + _CHROFF_48_18_;
	O10416[2] = + _CHROFF_6_6_;
	O10416[3] = + _CHROFF_6_4_;
	O10416[4] = + _CHROFF_48_17_;
}

long O10420[5];
void O10420_init () {
	O10420[0] = + _CHROFF_6_0_;
	O10420[1] = + _CHROFF_48_12_;
	{long i; for (i = 2; i < 4; i++) O10420[i] = + _CHROFF_6_0_;}
	O10420[4] = + _CHROFF_48_11_;
}

long O10421[5];
void O10421_init () {
	O10421[0] = + _R64OFF_6_5_0_3_0_1_0_0_;
	O10421[1] = + _R64OFF_48_19_10_9_0_3_0_0_;
	O10421[2] = + _R64OFF_6_7_0_5_0_5_0_0_;
	O10421[3] = + _R64OFF_6_5_0_3_0_2_0_0_;
	O10421[4] = + _R64OFF_48_18_10_9_0_4_0_0_;
}

long O10440[5];
void O10440_init () {
	O10440[0] =  + _REFACS_2_;
	O10440[1] =  + _REFACS_44_;
	{long i; for (i = 2; i < 4; i++) O10440[i] =  + _REFACS_2_;}
	O10440[4] =  + _REFACS_44_;
}

long O10441[5];
void O10441_init () {
	O10441[0] =  + _REFACS_3_;
	O10441[1] =  + _REFACS_45_;
	{long i; for (i = 2; i < 4; i++) O10441[i] =  + _REFACS_3_;}
	O10441[4] =  + _REFACS_45_;
}

long O10445[5];
void O10445_init () {
	O10445[0] =  + _REFACS_4_;
	O10445[1] =  + _REFACS_46_;
	{long i; for (i = 2; i < 4; i++) O10445[i] =  + _REFACS_4_;}
	O10445[4] =  + _REFACS_46_;
}

long O10446[5];
void O10446_init () {
	O10446[0] = + _CHROFF_6_1_;
	O10446[1] = + _CHROFF_48_13_;
	{long i; for (i = 2; i < 4; i++) O10446[i] = + _CHROFF_6_1_;}
	O10446[4] = + _CHROFF_48_12_;
}

long O10447[5];
void O10447_init () {
	O10447[0] =  + _REFACS_5_;
	O10447[1] =  + _REFACS_47_;
	{long i; for (i = 2; i < 4; i++) O10447[i] =  + _REFACS_5_;}
	O10447[4] =  + _REFACS_47_;
}

long O10448[5];
void O10448_init () {
	O10448[0] = + _LNGOFF_6_5_0_1_;
	O10448[1] = + _LNGOFF_48_19_10_7_;
	O10448[2] = + _LNGOFF_6_7_0_1_;
	O10448[3] = + _LNGOFF_6_5_0_1_;
	O10448[4] = + _LNGOFF_48_18_10_7_;
}

long O10449[5];
void O10449_init () {
	O10449[0] = + _LNGOFF_6_5_0_2_;
	O10449[1] = + _LNGOFF_48_19_10_8_;
	O10449[2] = + _LNGOFF_6_7_0_2_;
	O10449[3] = + _LNGOFF_6_5_0_2_;
	O10449[4] = + _LNGOFF_48_18_10_8_;
}


#ifdef __cplusplus
}
#endif
