#include "epoly9.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4948[599])();
void R4948_init () {
	R4948[0] = (char *(*)()) F601_5403;
	R4948[1] = (char *(*)()) F602_5403;
	R4948[2] = (char *(*)()) F603_5403;
	R4948[3] = (char *(*)()) F604_5403;
	R4948[4] = (char *(*)()) F605_5403;
	R4948[5] = (char *(*)()) F606_5403;
	R4948[6] = (char *(*)()) F607_5403;
	R4948[7] = (char *(*)()) F608_5403;
	R4948[8] = (char *(*)()) F609_5403;
	R4948[9] = (char *(*)()) F610_5403;
	R4948[10] = (char *(*)()) F611_5403;
	R4948[11] = (char *(*)()) F612_5403;
	R4948[61] = (char *(*)()) F614_5475;
	R4948[62] = (char *(*)()) F618_5475;
	R4948[63] = (char *(*)()) F622_5475;
	{long i; for (i = 64; i < 66; i++) R4948[i] = (char *(*)()) F614_5475;}
	R4948[66] = (char *(*)()) F618_5475;
	R4948[67] = (char *(*)()) F622_5475;
	R4948[68] = (char *(*)()) F614_5475;
	R4948[79] = (char *(*)()) F680_5832;
	R4948[80] = (char *(*)()) F681_5832;
	R4948[81] = (char *(*)()) F682_5832;
	R4948[82] = (char *(*)()) F683_5832;
	R4948[83] = (char *(*)()) F684_5832;
	R4948[84] = (char *(*)()) F685_5832;
	R4948[85] = (char *(*)()) F680_5832;
	R4948[86] = (char *(*)()) F681_5832;
	R4948[87] = (char *(*)()) F680_5832;
	R4948[88] = (char *(*)()) F689_5952;
	R4948[89] = (char *(*)()) F690_5952;
	R4948[90] = (char *(*)()) F691_5952;
	R4948[91] = (char *(*)()) F692_5952;
	R4948[92] = (char *(*)()) F693_5952;
	R4948[93] = (char *(*)()) F694_5952;
	R4948[94] = (char *(*)()) F695_5952;
	R4948[95] = (char *(*)()) F696_5952;
	R4948[96] = (char *(*)()) F697_5952;
	R4948[97] = (char *(*)()) F698_5952;
	R4948[98] = (char *(*)()) F699_5952;
	R4948[99] = (char *(*)()) F700_5952;
	R4948[107] = (char *(*)()) F689_5952;
	R4948[108] = (char *(*)()) F693_5952;
	{long i; for (i = 109; i < 113; i++) R4948[i] = (char *(*)()) F689_5952;}
	R4948[117] = (char *(*)()) F689_5952;
	{long i; for (i = 120; i < 122; i++) R4948[i] = (char *(*)()) F689_5952;}
	R4948[125] = (char *(*)()) F689_5952;
	{long i; for (i = 127; i < 131; i++) R4948[i] = (char *(*)()) F689_5952;}
	R4948[258] = (char *(*)()) F859_6509;
	R4948[259] = (char *(*)()) F860_6509;
	R4948[260] = (char *(*)()) F861_6509;
	R4948[261] = (char *(*)()) F862_6509;
	R4948[262] = (char *(*)()) F863_6509;
	R4948[263] = (char *(*)()) F864_6509;
	R4948[264] = (char *(*)()) F865_6509;
	R4948[265] = (char *(*)()) F866_6509;
	R4948[266] = (char *(*)()) F867_6509;
	R4948[267] = (char *(*)()) F868_6509;
	R4948[268] = (char *(*)()) F869_6509;
	R4948[269] = (char *(*)()) F870_6509;
	R4948[373] = (char *(*)()) F974_7561;
	{long i; for (i = 457; i < 459; i++) R4948[i] = (char *(*)()) F1054_8779;}
	{long i; for (i = 461; i < 463; i++) R4948[i] = (char *(*)()) F1054_8779;}
	{long i; for (i = 541; i < 543; i++) R4948[i] = (char *(*)()) F614_5475;}
	R4948[588] = (char *(*)()) F614_5475;
	R4948[598] = (char *(*)()) F614_5475;
}

char *(*R4975[12])();
void R4975_init () {
	R4975[0] = (char *(*)()) F601_5386;
	R4975[1] = (char *(*)()) F602_5386;
	R4975[2] = (char *(*)()) F603_5386;
	R4975[3] = (char *(*)()) F604_5386;
	R4975[4] = (char *(*)()) F605_5386;
	R4975[5] = (char *(*)()) F606_5386;
	R4975[6] = (char *(*)()) F607_5386;
	R4975[7] = (char *(*)()) F608_5386;
	R4975[8] = (char *(*)()) F609_5386;
	R4975[9] = (char *(*)()) F610_5386;
	R4975[10] = (char *(*)()) F611_5386;
	R4975[11] = (char *(*)()) F612_5386;
}

char *(*R4999[12])();
void R4999_init () {
	R4999[0] = (char *(*)()) F601_5428;
	R4999[1] = (char *(*)()) F602_5428_4999_276;
	R4999[2] = (char *(*)()) F603_5428_4999_276;
	R4999[3] = (char *(*)()) F604_5428_4999_276;
	R4999[4] = (char *(*)()) F605_5428_4999_276;
	R4999[5] = (char *(*)()) F606_5428_4999_276;
	R4999[6] = (char *(*)()) F607_5428_4999_276;
	R4999[7] = (char *(*)()) F608_5428_4999_276;
	R4999[8] = (char *(*)()) F609_5428_4999_276;
	R4999[9] = (char *(*)()) F610_5428_4999_276;
	R4999[10] = (char *(*)()) F611_5428_4999_276;
	R4999[11] = (char *(*)()) F612_5428_4999_276;
}
static void F602_5428_4999_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F602_5428(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F603_5428_4999_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F603_5428(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F604_5428_4999_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F604_5428(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F605_5428_4999_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F605_5428(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F606_5428_4999_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F606_5428(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F607_5428_4999_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F607_5428(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F608_5428_4999_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F608_5428(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F609_5428_4999_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F609_5428(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F610_5428_4999_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F610_5428(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F611_5428_4999_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F611_5428(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F612_5428_4999_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F612_5428(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R5006[12])();
void R5006_init () {
	R5006[0] = (char *(*)()) F601_5440;
	R5006[1] = (char *(*)()) F602_5440;
	R5006[2] = (char *(*)()) F603_5440;
	R5006[3] = (char *(*)()) F604_5440;
	R5006[4] = (char *(*)()) F605_5440;
	R5006[5] = (char *(*)()) F606_5440;
	R5006[6] = (char *(*)()) F607_5440;
	R5006[7] = (char *(*)()) F608_5440;
	R5006[8] = (char *(*)()) F609_5440;
	R5006[9] = (char *(*)()) F610_5440;
	R5006[10] = (char *(*)()) F611_5440;
	R5006[11] = (char *(*)()) F612_5440;
}

char *(*R5032[538])();
void R5032_init () {
	R5032[0] = (char *(*)()) F662_5517;
	R5032[1] = (char *(*)()) F663_5517_5032_1;
	R5032[2] = (char *(*)()) F664_5517_5032_1;
	{long i; for (i = 3; i < 5; i++) R5032[i] = (char *(*)()) F662_5517;}
	R5032[5] = (char *(*)()) F663_5517_5032_1;
	R5032[6] = (char *(*)()) F664_5517_5032_1;
	R5032[7] = (char *(*)()) F662_5517;
	R5032[27] = (char *(*)()) F689_5934;
	R5032[28] = (char *(*)()) F690_5934_5032_1;
	R5032[29] = (char *(*)()) F691_5934_5032_1;
	R5032[30] = (char *(*)()) F692_5934_5032_1;
	R5032[31] = (char *(*)()) F693_5934_5032_1;
	R5032[32] = (char *(*)()) F694_5934_5032_1;
	R5032[33] = (char *(*)()) F695_5934_5032_1;
	R5032[34] = (char *(*)()) F696_5934_5032_1;
	R5032[35] = (char *(*)()) F697_5934_5032_1;
	R5032[36] = (char *(*)()) F698_5934_5032_1;
	R5032[37] = (char *(*)()) F699_5934_5032_1;
	R5032[38] = (char *(*)()) F700_5934_5032_1;
	R5032[46] = (char *(*)()) F689_5934;
	R5032[47] = (char *(*)()) F693_5934_5032_1;
	{long i; for (i = 48; i < 52; i++) R5032[i] = (char *(*)()) F689_5934;}
	R5032[56] = (char *(*)()) F689_5934;
	{long i; for (i = 59; i < 61; i++) R5032[i] = (char *(*)()) F689_5934;}
	R5032[64] = (char *(*)()) F689_5934;
	{long i; for (i = 66; i < 70; i++) R5032[i] = (char *(*)()) F689_5934;}
	{long i; for (i = 480; i < 482; i++) R5032[i] = (char *(*)()) F614_5464;}
	R5032[527] = (char *(*)()) F614_5464;
	R5032[537] = (char *(*)()) F614_5464;
}
static EIF_REFERENCE F663_5517_5032_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F663_5517(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5517_5032_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F664_5517(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F690_5934_5032_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F690_5934(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(976, 0x00).id, 976, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F691_5934_5032_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F691_5934(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(985, 0x00).id, 985, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F692_5934_5032_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F692_5934(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(979, 0x00).id, 979, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F693_5934_5032_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F693_5934(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F694_5934_5032_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F694_5934(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F695_5934_5032_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F695_5934(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F696_5934_5032_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F696_5934(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(982, 0x00).id, 982, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F697_5934_5032_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F697_5934(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F698_5934_5032_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F698_5934(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F699_5934_5032_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F699_5934(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(988, 0x00).id, 988, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F700_5934_5032_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F700_5934(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5033[8])();
void R5033_init () {
	R5033[0] = (char *(*)()) F662_5536;
	R5033[1] = (char *(*)()) F663_5536;
	R5033[2] = (char *(*)()) F664_5536;
	{long i; for (i = 3; i < 5; i++) R5033[i] = (char *(*)()) F662_5536;}
	R5033[5] = (char *(*)()) F663_5536;
	R5033[6] = (char *(*)()) F664_5536;
	R5033[7] = (char *(*)()) F669_5601;
}

char *(*R5034[538])();
void R5034_init () {
	R5034[0] = (char *(*)()) F662_5537;
	R5034[1] = (char *(*)()) F663_5537;
	R5034[2] = (char *(*)()) F664_5537;
	{long i; for (i = 3; i < 5; i++) R5034[i] = (char *(*)()) F662_5537;}
	R5034[5] = (char *(*)()) F663_5537;
	R5034[6] = (char *(*)()) F664_5537;
	R5034[7] = (char *(*)()) F662_5537;
	R5034[27] = (char *(*)()) F689_5960;
	R5034[28] = (char *(*)()) F690_5960;
	R5034[29] = (char *(*)()) F691_5960;
	R5034[30] = (char *(*)()) F692_5960;
	R5034[31] = (char *(*)()) F693_5960;
	R5034[32] = (char *(*)()) F694_5960;
	R5034[33] = (char *(*)()) F695_5960;
	R5034[34] = (char *(*)()) F696_5960;
	R5034[35] = (char *(*)()) F697_5960;
	R5034[36] = (char *(*)()) F698_5960;
	R5034[37] = (char *(*)()) F699_5960;
	R5034[38] = (char *(*)()) F700_5960;
	R5034[46] = (char *(*)()) F689_5960;
	R5034[47] = (char *(*)()) F693_5960;
	{long i; for (i = 48; i < 52; i++) R5034[i] = (char *(*)()) F689_5960;}
	R5034[56] = (char *(*)()) F689_5960;
	{long i; for (i = 59; i < 61; i++) R5034[i] = (char *(*)()) F689_5960;}
	R5034[64] = (char *(*)()) F689_5960;
	{long i; for (i = 66; i < 70; i++) R5034[i] = (char *(*)()) F689_5960;}
	{long i; for (i = 480; i < 482; i++) R5034[i] = (char *(*)()) F1134_9933;}
	R5034[527] = (char *(*)()) F1134_9933;
	R5034[537] = (char *(*)()) F1134_9933;
}

char *(*R5035[538])();
void R5035_init () {
	R5035[0] = (char *(*)()) F662_5527;
	R5035[1] = (char *(*)()) F663_5527;
	R5035[2] = (char *(*)()) F664_5527;
	{long i; for (i = 3; i < 5; i++) R5035[i] = (char *(*)()) F662_5527;}
	R5035[5] = (char *(*)()) F663_5527;
	R5035[6] = (char *(*)()) F664_5527;
	R5035[7] = (char *(*)()) F662_5527;
	R5035[27] = (char *(*)()) F614_5476;
	R5035[28] = (char *(*)()) F615_5476;
	R5035[29] = (char *(*)()) F616_5476;
	R5035[30] = (char *(*)()) F617_5476;
	R5035[31] = (char *(*)()) F618_5476;
	R5035[32] = (char *(*)()) F619_5476;
	R5035[33] = (char *(*)()) F620_5476;
	R5035[34] = (char *(*)()) F621_5476;
	R5035[35] = (char *(*)()) F622_5476;
	R5035[36] = (char *(*)()) F623_5476;
	R5035[37] = (char *(*)()) F624_5476;
	R5035[38] = (char *(*)()) F625_5476;
	R5035[46] = (char *(*)()) F614_5476;
	R5035[47] = (char *(*)()) F618_5476;
	{long i; for (i = 48; i < 52; i++) R5035[i] = (char *(*)()) F614_5476;}
	R5035[56] = (char *(*)()) F614_5476;
	{long i; for (i = 59; i < 61; i++) R5035[i] = (char *(*)()) F614_5476;}
	R5035[64] = (char *(*)()) F614_5476;
	{long i; for (i = 66; i < 70; i++) R5035[i] = (char *(*)()) F614_5476;}
	{long i; for (i = 480; i < 482; i++) R5035[i] = (char *(*)()) F614_5476;}
	R5035[527] = (char *(*)()) F614_5476;
	R5035[537] = (char *(*)()) F614_5476;
}

char *(*R5036[8])();
void R5036_init () {
	R5036[0] = (char *(*)()) F662_5528;
	R5036[1] = (char *(*)()) F663_5528;
	R5036[2] = (char *(*)()) F664_5528;
	{long i; for (i = 3; i < 5; i++) R5036[i] = (char *(*)()) F662_5528;}
	R5036[5] = (char *(*)()) F663_5528;
	R5036[6] = (char *(*)()) F664_5528;
	R5036[7] = (char *(*)()) F669_5597;
}

char *(*R5041[7])();
void R5041_init () {
	R5041[0] = (char *(*)()) F662_5539;
	R5041[1] = (char *(*)()) F663_5539_5041_4;
	R5041[2] = (char *(*)()) F664_5539_5041_4;
	{long i; for (i = 3; i < 5; i++) R5041[i] = (char *(*)()) F662_5539;}
	R5041[5] = (char *(*)()) F663_5539_5041_4;
	R5041[6] = (char *(*)()) F664_5539_5041_4;
}
static void F663_5539_5041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_5539(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F664_5539_5041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5539(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R5042[43])();
void R5042_init () {
	R5042[0] = (char *(*)()) F689_5967;
	R5042[1] = (char *(*)()) F690_5967_5042_4;
	R5042[2] = (char *(*)()) F691_5967_5042_4;
	R5042[3] = (char *(*)()) F692_5967_5042_4;
	R5042[4] = (char *(*)()) F693_5967_5042_4;
	R5042[5] = (char *(*)()) F694_5967_5042_4;
	R5042[6] = (char *(*)()) F695_5967_5042_4;
	R5042[7] = (char *(*)()) F696_5967_5042_4;
	R5042[8] = (char *(*)()) F697_5967_5042_4;
	R5042[9] = (char *(*)()) F698_5967_5042_4;
	R5042[10] = (char *(*)()) F699_5967_5042_4;
	R5042[11] = (char *(*)()) F700_5967_5042_4;
	R5042[19] = (char *(*)()) F704_6010;
	R5042[20] = (char *(*)()) F705_6010_5042_4;
	{long i; for (i = 21; i < 25; i++) R5042[i] = (char *(*)()) F704_6010;}
	R5042[29] = (char *(*)()) F704_6010;
	{long i; for (i = 32; i < 34; i++) R5042[i] = (char *(*)()) F704_6010;}
	R5042[37] = (char *(*)()) F704_6010;
	{long i; for (i = 39; i < 43; i++) R5042[i] = (char *(*)()) F704_6010;}
}
static void F690_5967_5042_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F690_5967(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F691_5967_5042_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F691_5967(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F692_5967_5042_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F692_5967(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F693_5967_5042_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F693_5967(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F694_5967_5042_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F694_5967(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F695_5967_5042_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F695_5967(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F696_5967_5042_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F696_5967(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F697_5967_5042_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F697_5967(Current, *(EIF_BOOLEAN *)arg1);
}
static void F698_5967_5042_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F698_5967(Current, *(EIF_POINTER *)arg1);
}
static void F699_5967_5042_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F699_5967(Current, *(EIF_REAL_32 *)arg1);
}
static void F700_5967_5042_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F700_5967(Current, *(EIF_REAL_64 *)arg1);
}
static void F705_6010_5042_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F705_6010(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5047[8])();
void R5047_init () {
	R5047[0] = (char *(*)()) F662_5548;
	R5047[1] = (char *(*)()) F663_5548;
	R5047[2] = (char *(*)()) F664_5548;
	{long i; for (i = 3; i < 5; i++) R5047[i] = (char *(*)()) F662_5548;}
	R5047[5] = (char *(*)()) F663_5548;
	R5047[6] = (char *(*)()) F664_5548;
	R5047[7] = (char *(*)()) F669_5610;
}

char *(*R5052[8])();
void R5052_init () {
	R5052[0] = (char *(*)()) F662_5552;
	R5052[1] = (char *(*)()) F663_5552_5052_5;
	R5052[2] = (char *(*)()) F664_5552_5052_5;
	{long i; for (i = 3; i < 5; i++) R5052[i] = (char *(*)()) F662_5552;}
	R5052[5] = (char *(*)()) F663_5552_5052_5;
	R5052[6] = (char *(*)()) F664_5552_5052_5;
	R5052[7] = (char *(*)()) F669_5616;
}
static EIF_REFERENCE F663_5552_5052_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F663_5552(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F664_5552_5052_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F664_5552(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R5053[8])();
void R5053_init () {
	R5053[0] = (char *(*)()) F662_5553;
	R5053[1] = (char *(*)()) F663_5553;
	R5053[2] = (char *(*)()) F664_5553;
	{long i; for (i = 3; i < 5; i++) R5053[i] = (char *(*)()) F662_5553;}
	R5053[5] = (char *(*)()) F663_5553;
	R5053[6] = (char *(*)()) F664_5553;
	R5053[7] = (char *(*)()) F669_5617;
}

char *(*R5056[8])();
void R5056_init () {
	R5056[0] = (char *(*)()) F662_5556;
	R5056[1] = (char *(*)()) F663_5556;
	R5056[2] = (char *(*)()) F664_5556;
	{long i; for (i = 3; i < 5; i++) R5056[i] = (char *(*)()) F662_5556;}
	R5056[5] = (char *(*)()) F663_5556;
	R5056[6] = (char *(*)()) F664_5556;
	R5056[7] = (char *(*)()) F669_5593;
}

char *(*R5057[8])();
void R5057_init () {
	R5057[0] = (char *(*)()) F662_5557;
	R5057[1] = (char *(*)()) F663_5557;
	R5057[2] = (char *(*)()) F664_5557;
	{long i; for (i = 3; i < 5; i++) R5057[i] = (char *(*)()) F662_5557;}
	R5057[5] = (char *(*)()) F663_5557;
	R5057[6] = (char *(*)()) F664_5557;
	R5057[7] = (char *(*)()) F662_5557;
}

char *(*R5058[8])();
void R5058_init () {
	R5058[0] = (char *(*)()) F662_5558;
	R5058[1] = (char *(*)()) F663_5558;
	R5058[2] = (char *(*)()) F664_5558;
	{long i; for (i = 3; i < 5; i++) R5058[i] = (char *(*)()) F662_5558;}
	R5058[5] = (char *(*)()) F663_5558;
	R5058[6] = (char *(*)()) F664_5558;
	R5058[7] = (char *(*)()) F662_5558;
}

char *(*R5068[3])();
void R5068_init () {
	R5068[0] = (char *(*)()) F662_5515;
	R5068[1] = (char *(*)()) F663_5515_5068_1;
	R5068[2] = (char *(*)()) F664_5515_5068_1;
}
static EIF_REFERENCE F663_5515_5068_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F663_5515(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5515_5068_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F664_5515(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R5069[3])();
void R5069_init () {
	R5069[0] = (char *(*)()) F662_5546;
	R5069[1] = (char *(*)()) F663_5546;
	R5069[2] = (char *(*)()) F664_5546;
}

char *(*R5195[741])();
void R5195_init () {
	R5195[0] = (char *(*)()) F680_5853;
	R5195[1] = (char *(*)()) F681_5853;
	R5195[2] = (char *(*)()) F682_5853;
	R5195[3] = (char *(*)()) F683_5853;
	R5195[4] = (char *(*)()) F684_5853;
	R5195[5] = (char *(*)()) F685_5853;
	R5195[6] = (char *(*)()) F680_5853;
	R5195[7] = (char *(*)()) F681_5853;
	R5195[8] = (char *(*)()) F680_5853;
	R5195[9] = (char *(*)()) F689_5986;
	R5195[10] = (char *(*)()) F690_5986;
	R5195[11] = (char *(*)()) F691_5986;
	R5195[12] = (char *(*)()) F692_5986;
	R5195[13] = (char *(*)()) F693_5986;
	R5195[14] = (char *(*)()) F694_5986;
	R5195[15] = (char *(*)()) F695_5986;
	R5195[16] = (char *(*)()) F696_5986;
	R5195[17] = (char *(*)()) F697_5986;
	R5195[18] = (char *(*)()) F698_5986;
	R5195[19] = (char *(*)()) F699_5986;
	R5195[20] = (char *(*)()) F700_5986;
	R5195[28] = (char *(*)()) F689_5986;
	R5195[29] = (char *(*)()) F693_5986;
	{long i; for (i = 30; i < 34; i++) R5195[i] = (char *(*)()) F689_5986;}
	R5195[38] = (char *(*)()) F689_5986;
	{long i; for (i = 41; i < 43; i++) R5195[i] = (char *(*)()) F689_5986;}
	R5195[46] = (char *(*)()) F689_5986;
	{long i; for (i = 48; i < 52; i++) R5195[i] = (char *(*)()) F689_5986;}
	R5195[294] = (char *(*)()) F974_7642;
	{long i; for (i = 368; i < 374; i++) R5195[i] = (char *(*)()) F1047_8733;}
	R5195[379] = (char *(*)()) F1059_9060;
	R5195[382] = (char *(*)()) F1062_9138;
	R5195[383] = (char *(*)()) F1063_9229;
	R5195[735] = (char *(*)()) F679_5785;
	R5195[740] = (char *(*)()) F679_5785;
}

char *(*R5217[9])();
void R5217_init () {
	R5217[0] = (char *(*)()) F680_5794;
	R5217[1] = (char *(*)()) F681_5794;
	R5217[2] = (char *(*)()) F682_5794;
	R5217[3] = (char *(*)()) F683_5794;
	R5217[4] = (char *(*)()) F684_5794;
	R5217[5] = (char *(*)()) F685_5794;
	R5217[6] = (char *(*)()) F680_5794;
	R5217[7] = (char *(*)()) F681_5794;
	R5217[8] = (char *(*)()) F680_5794;
}

char *(*R5220[9])();
void R5220_init () {
	R5220[0] = (char *(*)()) F680_5797;
	R5220[1] = (char *(*)()) F681_5797;
	R5220[2] = (char *(*)()) F682_5797;
	R5220[3] = (char *(*)()) F683_5797;
	R5220[4] = (char *(*)()) F684_5797;
	R5220[5] = (char *(*)()) F685_5797;
	R5220[6] = (char *(*)()) F680_5797;
	R5220[7] = (char *(*)()) F681_5797;
	R5220[8] = (char *(*)()) F680_5797;
}

char *(*R5221[9])();
void R5221_init () {
	R5221[0] = (char *(*)()) F680_5798;
	R5221[1] = (char *(*)()) F681_5798_5221_1;
	R5221[2] = (char *(*)()) F682_5798_5221_1;
	R5221[3] = (char *(*)()) F683_5798;
	R5221[4] = (char *(*)()) F684_5798_5221_1;
	R5221[5] = (char *(*)()) F685_5798_5221_1;
	R5221[6] = (char *(*)()) F680_5798;
	R5221[7] = (char *(*)()) F681_5798_5221_1;
	R5221[8] = (char *(*)()) F680_5798;
}
static EIF_REFERENCE F681_5798_5221_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F681_5798(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F682_5798_5221_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F682_5798(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F684_5798_5221_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F684_5798(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F685_5798_5221_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F685_5798(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5226[9])();
void R5226_init () {
	R5226[0] = (char *(*)()) F680_5806;
	R5226[1] = (char *(*)()) F681_5806_5226_1;
	R5226[2] = (char *(*)()) F682_5806_5226_1;
	R5226[3] = (char *(*)()) F683_5806;
	R5226[4] = (char *(*)()) F684_5806_5226_1;
	R5226[5] = (char *(*)()) F685_5806_5226_1;
	R5226[6] = (char *(*)()) F680_5806;
	R5226[7] = (char *(*)()) F681_5806_5226_1;
	R5226[8] = (char *(*)()) F680_5806;
}
static EIF_REFERENCE F681_5806_5226_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F681_5806(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F682_5806_5226_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F682_5806(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F684_5806_5226_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F684_5806(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F685_5806_5226_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F685_5806(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5227[9])();
void R5227_init () {
	R5227[0] = (char *(*)()) F680_5807;
	R5227[1] = (char *(*)()) F681_5807;
	R5227[2] = (char *(*)()) F682_5807;
	R5227[3] = (char *(*)()) F683_5807_5227_1;
	R5227[4] = (char *(*)()) F684_5807_5227_1;
	R5227[5] = (char *(*)()) F685_5807_5227_1;
	R5227[6] = (char *(*)()) F680_5807;
	R5227[7] = (char *(*)()) F681_5807;
	R5227[8] = (char *(*)()) F680_5807;
}
static EIF_REFERENCE F683_5807_5227_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F683_5807(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F684_5807_5227_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F684_5807(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(979, 0x00).id, 979, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F685_5807_5227_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F685_5807(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5229[9])();
void R5229_init () {
	R5229[0] = (char *(*)()) F680_5811;
	R5229[1] = (char *(*)()) F681_5811;
	R5229[2] = (char *(*)()) F682_5811;
	R5229[3] = (char *(*)()) F683_5811_5229_79;
	R5229[4] = (char *(*)()) F684_5811_5229_79;
	R5229[5] = (char *(*)()) F685_5811_5229_79;
	R5229[6] = (char *(*)()) F686_5908;
	R5229[7] = (char *(*)()) F687_5908;
	R5229[8] = (char *(*)()) F680_5811;
}
static EIF_INTEGER_32 F683_5811_5229_79 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F683_5811(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F684_5811_5229_79 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F684_5811(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_INTEGER_32 F685_5811_5229_79 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F685_5811(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5231[9])();
void R5231_init () {
	R5231[0] = (char *(*)()) F680_5818;
	R5231[1] = (char *(*)()) F681_5818;
	R5231[2] = (char *(*)()) F682_5818;
	R5231[3] = (char *(*)()) F683_5818_5231_3;
	R5231[4] = (char *(*)()) F684_5818_5231_3;
	R5231[5] = (char *(*)()) F685_5818_5231_3;
	R5231[6] = (char *(*)()) F686_5910;
	R5231[7] = (char *(*)()) F687_5910;
	R5231[8] = (char *(*)()) F680_5818;
}
static EIF_BOOLEAN F683_5818_5231_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F683_5818(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F684_5818_5231_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F684_5818(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static EIF_BOOLEAN F685_5818_5231_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F685_5818(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R5237[9])();
void R5237_init () {
	R5237[0] = (char *(*)()) F680_5826;
	R5237[1] = (char *(*)()) F681_5826;
	R5237[2] = (char *(*)()) F682_5826;
	R5237[3] = (char *(*)()) F683_5826;
	R5237[4] = (char *(*)()) F684_5826;
	R5237[5] = (char *(*)()) F685_5826;
	R5237[6] = (char *(*)()) F680_5826;
	R5237[7] = (char *(*)()) F681_5826;
	R5237[8] = (char *(*)()) F680_5826;
}

char *(*R5238[9])();
void R5238_init () {
	R5238[0] = (char *(*)()) F680_5827;
	R5238[1] = (char *(*)()) F681_5827;
	R5238[2] = (char *(*)()) F682_5827;
	R5238[3] = (char *(*)()) F683_5827;
	R5238[4] = (char *(*)()) F684_5827;
	R5238[5] = (char *(*)()) F685_5827;
	R5238[6] = (char *(*)()) F680_5827;
	R5238[7] = (char *(*)()) F681_5827;
	R5238[8] = (char *(*)()) F680_5827;
}

char *(*R5239[9])();
void R5239_init () {
	R5239[0] = (char *(*)()) F680_5828;
	R5239[1] = (char *(*)()) F681_5828;
	R5239[2] = (char *(*)()) F682_5828;
	R5239[3] = (char *(*)()) F683_5828;
	R5239[4] = (char *(*)()) F684_5828;
	R5239[5] = (char *(*)()) F685_5828;
	R5239[6] = (char *(*)()) F680_5828;
	R5239[7] = (char *(*)()) F681_5828;
	R5239[8] = (char *(*)()) F680_5828;
}

char *(*R5240[9])();
void R5240_init () {
	R5240[0] = (char *(*)()) F680_5829;
	R5240[1] = (char *(*)()) F681_5829;
	R5240[2] = (char *(*)()) F682_5829;
	R5240[3] = (char *(*)()) F683_5829;
	R5240[4] = (char *(*)()) F684_5829;
	R5240[5] = (char *(*)()) F685_5829;
	R5240[6] = (char *(*)()) F680_5829;
	R5240[7] = (char *(*)()) F681_5829;
	R5240[8] = (char *(*)()) F680_5829;
}

char *(*R5243[9])();
void R5243_init () {
	R5243[0] = (char *(*)()) F680_5833;
	R5243[1] = (char *(*)()) F681_5833;
	R5243[2] = (char *(*)()) F682_5833;
	R5243[3] = (char *(*)()) F683_5833;
	R5243[4] = (char *(*)()) F684_5833;
	R5243[5] = (char *(*)()) F685_5833;
	R5243[6] = (char *(*)()) F680_5833;
	R5243[7] = (char *(*)()) F681_5833;
	R5243[8] = (char *(*)()) F680_5833;
}

char *(*R5244[9])();
void R5244_init () {
	R5244[0] = (char *(*)()) F680_5834;
	R5244[1] = (char *(*)()) F681_5834;
	R5244[2] = (char *(*)()) F682_5834;
	R5244[3] = (char *(*)()) F683_5834;
	R5244[4] = (char *(*)()) F684_5834;
	R5244[5] = (char *(*)()) F685_5834;
	R5244[6] = (char *(*)()) F680_5834;
	R5244[7] = (char *(*)()) F681_5834;
	R5244[8] = (char *(*)()) F680_5834;
}

char *(*R5246[9])();
void R5246_init () {
	R5246[0] = (char *(*)()) F680_5836;
	R5246[1] = (char *(*)()) F681_5836;
	R5246[2] = (char *(*)()) F682_5836;
	R5246[3] = (char *(*)()) F683_5836_5246_4;
	R5246[4] = (char *(*)()) F684_5836_5246_4;
	R5246[5] = (char *(*)()) F685_5836_5246_4;
	R5246[6] = (char *(*)()) F680_5836;
	R5246[7] = (char *(*)()) F681_5836;
	R5246[8] = (char *(*)()) F680_5836;
}
static void F683_5836_5246_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F683_5836(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F684_5836_5246_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F684_5836(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F685_5836_5246_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F685_5836(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5248[9])();
void R5248_init () {
	R5248[0] = (char *(*)()) F680_5838;
	R5248[1] = (char *(*)()) F681_5838;
	R5248[2] = (char *(*)()) F682_5838;
	R5248[3] = (char *(*)()) F683_5838;
	R5248[4] = (char *(*)()) F684_5838;
	R5248[5] = (char *(*)()) F685_5838;
	R5248[6] = (char *(*)()) F680_5838;
	R5248[7] = (char *(*)()) F681_5838;
	R5248[8] = (char *(*)()) F680_5838;
}

char *(*R5249[9])();
void R5249_init () {
	R5249[0] = (char *(*)()) F680_5839;
	R5249[1] = (char *(*)()) F681_5839;
	R5249[2] = (char *(*)()) F682_5839;
	R5249[3] = (char *(*)()) F683_5839;
	R5249[4] = (char *(*)()) F684_5839;
	R5249[5] = (char *(*)()) F685_5839;
	R5249[6] = (char *(*)()) F680_5839;
	R5249[7] = (char *(*)()) F681_5839;
	R5249[8] = (char *(*)()) F680_5839;
}

char *(*R5255[9])();
void R5255_init () {
	R5255[0] = (char *(*)()) F680_5852;
	R5255[1] = (char *(*)()) F681_5852;
	R5255[2] = (char *(*)()) F682_5852;
	R5255[3] = (char *(*)()) F683_5852;
	R5255[4] = (char *(*)()) F684_5852;
	R5255[5] = (char *(*)()) F685_5852;
	R5255[6] = (char *(*)()) F686_5912;
	R5255[7] = (char *(*)()) F687_5912;
	R5255[8] = (char *(*)()) F680_5852;
}

char *(*R5264[9])();
void R5264_init () {
	R5264[0] = (char *(*)()) F680_5862;
	R5264[1] = (char *(*)()) F681_5862;
	R5264[2] = (char *(*)()) F682_5862;
	R5264[3] = (char *(*)()) F683_5862;
	R5264[4] = (char *(*)()) F684_5862;
	R5264[5] = (char *(*)()) F685_5862;
	R5264[6] = (char *(*)()) F680_5862;
	R5264[7] = (char *(*)()) F681_5862;
	R5264[8] = (char *(*)()) F680_5862;
}

char *(*R5265[9])();
void R5265_init () {
	R5265[0] = (char *(*)()) F680_5863;
	R5265[1] = (char *(*)()) F681_5863;
	R5265[2] = (char *(*)()) F682_5863;
	R5265[3] = (char *(*)()) F683_5863;
	R5265[4] = (char *(*)()) F684_5863;
	R5265[5] = (char *(*)()) F685_5863;
	R5265[6] = (char *(*)()) F680_5863;
	R5265[7] = (char *(*)()) F681_5863;
	R5265[8] = (char *(*)()) F680_5863;
}

char *(*R5272[9])();
void R5272_init () {
	R5272[0] = (char *(*)()) F680_5870;
	R5272[1] = (char *(*)()) F681_5870_5272_1;
	R5272[2] = (char *(*)()) F682_5870_5272_1;
	R5272[3] = (char *(*)()) F683_5870;
	R5272[4] = (char *(*)()) F684_5870_5272_1;
	R5272[5] = (char *(*)()) F685_5870_5272_1;
	R5272[6] = (char *(*)()) F680_5870;
	R5272[7] = (char *(*)()) F681_5870_5272_1;
	R5272[8] = (char *(*)()) F680_5870;
}
static EIF_REFERENCE F681_5870_5272_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F681_5870(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F682_5870_5272_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F682_5870(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F684_5870_5272_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F684_5870(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F685_5870_5272_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F685_5870(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5273[9])();
void R5273_init () {
	R5273[0] = (char *(*)()) F680_5871;
	R5273[1] = (char *(*)()) F681_5871;
	R5273[2] = (char *(*)()) F682_5871;
	R5273[3] = (char *(*)()) F683_5871_5273_1;
	R5273[4] = (char *(*)()) F684_5871_5273_1;
	R5273[5] = (char *(*)()) F685_5871_5273_1;
	R5273[6] = (char *(*)()) F680_5871;
	R5273[7] = (char *(*)()) F681_5871;
	R5273[8] = (char *(*)()) F680_5871;
}
static EIF_REFERENCE F683_5871_5273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F683_5871(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F684_5871_5273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F684_5871(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(979, 0x00).id, 979, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F685_5871_5273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F685_5871(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5274[9])();
void R5274_init () {
	R5274[0] = (char *(*)()) F680_5872;
	R5274[1] = (char *(*)()) F681_5872;
	R5274[2] = (char *(*)()) F682_5872;
	R5274[3] = (char *(*)()) F683_5872;
	R5274[4] = (char *(*)()) F684_5872;
	R5274[5] = (char *(*)()) F685_5872;
	R5274[6] = (char *(*)()) F680_5872;
	R5274[7] = (char *(*)()) F681_5872;
	R5274[8] = (char *(*)()) F680_5872;
}

char *(*R5275[9])();
void R5275_init () {
	R5275[0] = (char *(*)()) F680_5873;
	R5275[1] = (char *(*)()) F681_5873;
	R5275[2] = (char *(*)()) F682_5873;
	R5275[3] = (char *(*)()) F683_5873;
	R5275[4] = (char *(*)()) F684_5873;
	R5275[5] = (char *(*)()) F685_5873;
	R5275[6] = (char *(*)()) F680_5873;
	R5275[7] = (char *(*)()) F681_5873;
	R5275[8] = (char *(*)()) F680_5873;
}

char *(*R5276[9])();
void R5276_init () {
	R5276[0] = (char *(*)()) F680_5874;
	R5276[1] = (char *(*)()) F681_5874;
	R5276[2] = (char *(*)()) F682_5874;
	R5276[3] = (char *(*)()) F683_5874;
	R5276[4] = (char *(*)()) F684_5874;
	R5276[5] = (char *(*)()) F685_5874;
	R5276[6] = (char *(*)()) F680_5874;
	R5276[7] = (char *(*)()) F681_5874;
	R5276[8] = (char *(*)()) F680_5874;
}

char *(*R5277[9])();
void R5277_init () {
	R5277[0] = (char *(*)()) F680_5875;
	R5277[1] = (char *(*)()) F681_5875;
	R5277[2] = (char *(*)()) F682_5875;
	R5277[3] = (char *(*)()) F683_5875;
	R5277[4] = (char *(*)()) F684_5875;
	R5277[5] = (char *(*)()) F685_5875;
	R5277[6] = (char *(*)()) F680_5875;
	R5277[7] = (char *(*)()) F681_5875;
	R5277[8] = (char *(*)()) F680_5875;
}

char *(*R5278[9])();
void R5278_init () {
	R5278[0] = (char *(*)()) F680_5876;
	R5278[1] = (char *(*)()) F681_5876;
	R5278[2] = (char *(*)()) F682_5876;
	R5278[3] = (char *(*)()) F683_5876;
	R5278[4] = (char *(*)()) F684_5876;
	R5278[5] = (char *(*)()) F685_5876;
	R5278[6] = (char *(*)()) F680_5876;
	R5278[7] = (char *(*)()) F681_5876;
	R5278[8] = (char *(*)()) F680_5876;
}

char *(*R5280[9])();
void R5280_init () {
	R5280[0] = (char *(*)()) F680_5878;
	R5280[1] = (char *(*)()) F681_5878;
	R5280[2] = (char *(*)()) F682_5878;
	R5280[3] = (char *(*)()) F683_5878;
	R5280[4] = (char *(*)()) F684_5878;
	R5280[5] = (char *(*)()) F685_5878;
	R5280[6] = (char *(*)()) F680_5878;
	R5280[7] = (char *(*)()) F681_5878;
	R5280[8] = (char *(*)()) F680_5878;
}

char *(*R5281[9])();
void R5281_init () {
	R5281[0] = (char *(*)()) F680_5879;
	R5281[1] = (char *(*)()) F681_5879;
	R5281[2] = (char *(*)()) F682_5879;
	R5281[3] = (char *(*)()) F683_5879;
	R5281[4] = (char *(*)()) F684_5879;
	R5281[5] = (char *(*)()) F685_5879;
	R5281[6] = (char *(*)()) F680_5879;
	R5281[7] = (char *(*)()) F681_5879;
	R5281[8] = (char *(*)()) F680_5879;
}

char *(*R5282[9])();
void R5282_init () {
	R5282[0] = (char *(*)()) F680_5880;
	R5282[1] = (char *(*)()) F681_5880;
	R5282[2] = (char *(*)()) F682_5880;
	R5282[3] = (char *(*)()) F683_5880;
	R5282[4] = (char *(*)()) F684_5880;
	R5282[5] = (char *(*)()) F685_5880;
	R5282[6] = (char *(*)()) F680_5880;
	R5282[7] = (char *(*)()) F681_5880;
	R5282[8] = (char *(*)()) F680_5880;
}

char *(*R5286[9])();
void R5286_init () {
	R5286[0] = (char *(*)()) F680_5884;
	R5286[1] = (char *(*)()) F681_5884;
	R5286[2] = (char *(*)()) F682_5884;
	R5286[3] = (char *(*)()) F683_5884_5286_4;
	R5286[4] = (char *(*)()) F684_5884_5286_4;
	R5286[5] = (char *(*)()) F685_5884_5286_4;
	R5286[6] = (char *(*)()) F680_5884;
	R5286[7] = (char *(*)()) F681_5884;
	R5286[8] = (char *(*)()) F680_5884;
}
static void F683_5884_5286_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F683_5884(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F684_5884_5286_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F684_5884(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F685_5884_5286_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F685_5884(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5292[9])();
void R5292_init () {
	R5292[0] = (char *(*)()) F680_5890;
	R5292[1] = (char *(*)()) F681_5890;
	R5292[2] = (char *(*)()) F682_5890;
	R5292[3] = (char *(*)()) F683_5890;
	R5292[4] = (char *(*)()) F684_5890;
	R5292[5] = (char *(*)()) F685_5890;
	R5292[6] = (char *(*)()) F680_5890;
	R5292[7] = (char *(*)()) F681_5890;
	R5292[8] = (char *(*)()) F680_5890;
}

char *(*R5305[9])();
void R5305_init () {
	R5305[0] = (char *(*)()) F680_5903;
	R5305[1] = (char *(*)()) F681_5903;
	R5305[2] = (char *(*)()) F682_5903;
	R5305[3] = (char *(*)()) F683_5903;
	R5305[4] = (char *(*)()) F684_5903;
	R5305[5] = (char *(*)()) F685_5903;
	R5305[6] = (char *(*)()) F680_5903;
	R5305[7] = (char *(*)()) F681_5903;
	R5305[8] = (char *(*)()) F680_5903;
}

char *(*R5308[2])();
void R5308_init () {
	R5308[0] = (char *(*)()) F686_5906;
	R5308[1] = (char *(*)()) F687_5906;
}

char *(*R5321[43])();
void R5321_init () {
	R5321[0] = (char *(*)()) F689_5925;
	R5321[1] = (char *(*)()) F690_5925;
	R5321[2] = (char *(*)()) F691_5925;
	R5321[3] = (char *(*)()) F692_5925;
	R5321[4] = (char *(*)()) F693_5925;
	R5321[5] = (char *(*)()) F694_5925;
	R5321[6] = (char *(*)()) F695_5925;
	R5321[7] = (char *(*)()) F696_5925;
	R5321[8] = (char *(*)()) F697_5925;
	R5321[9] = (char *(*)()) F698_5925;
	R5321[10] = (char *(*)()) F699_5925;
	R5321[11] = (char *(*)()) F700_5925;
	R5321[19] = (char *(*)()) F689_5925;
	R5321[20] = (char *(*)()) F693_5925;
	{long i; for (i = 21; i < 25; i++) R5321[i] = (char *(*)()) F689_5925;}
	R5321[29] = (char *(*)()) F689_5925;
	{long i; for (i = 32; i < 34; i++) R5321[i] = (char *(*)()) F689_5925;}
	R5321[37] = (char *(*)()) F689_5925;
	{long i; for (i = 39; i < 43; i++) R5321[i] = (char *(*)()) F689_5925;}
}

char *(*R5325[43])();
void R5325_init () {
	R5325[0] = (char *(*)()) F689_5929;
	R5325[1] = (char *(*)()) F690_5929;
	R5325[2] = (char *(*)()) F691_5929;
	R5325[3] = (char *(*)()) F692_5929;
	R5325[4] = (char *(*)()) F693_5929;
	R5325[5] = (char *(*)()) F694_5929;
	R5325[6] = (char *(*)()) F695_5929;
	R5325[7] = (char *(*)()) F696_5929;
	R5325[8] = (char *(*)()) F697_5929;
	R5325[9] = (char *(*)()) F698_5929;
	R5325[10] = (char *(*)()) F699_5929;
	R5325[11] = (char *(*)()) F700_5929;
	R5325[19] = (char *(*)()) F689_5929;
	R5325[20] = (char *(*)()) F693_5929;
	{long i; for (i = 21; i < 25; i++) R5325[i] = (char *(*)()) F689_5929;}
	R5325[29] = (char *(*)()) F689_5929;
	{long i; for (i = 32; i < 34; i++) R5325[i] = (char *(*)()) F689_5929;}
	R5325[37] = (char *(*)()) F689_5929;
	{long i; for (i = 39; i < 43; i++) R5325[i] = (char *(*)()) F689_5929;}
}

char *(*R5329[43])();
void R5329_init () {
	R5329[0] = (char *(*)()) F689_5948;
	R5329[1] = (char *(*)()) F690_5948;
	R5329[2] = (char *(*)()) F691_5948;
	R5329[3] = (char *(*)()) F692_5948;
	R5329[4] = (char *(*)()) F693_5948;
	R5329[5] = (char *(*)()) F694_5948;
	R5329[6] = (char *(*)()) F695_5948;
	R5329[7] = (char *(*)()) F696_5948;
	R5329[8] = (char *(*)()) F697_5948;
	R5329[9] = (char *(*)()) F698_5948;
	R5329[10] = (char *(*)()) F699_5948;
	R5329[11] = (char *(*)()) F700_5948;
	R5329[19] = (char *(*)()) F689_5948;
	R5329[20] = (char *(*)()) F693_5948;
	{long i; for (i = 21; i < 25; i++) R5329[i] = (char *(*)()) F689_5948;}
	R5329[29] = (char *(*)()) F689_5948;
	{long i; for (i = 32; i < 34; i++) R5329[i] = (char *(*)()) F689_5948;}
	R5329[37] = (char *(*)()) F689_5948;
	{long i; for (i = 39; i < 43; i++) R5329[i] = (char *(*)()) F689_5948;}
}

char *(*R5333[43])();
void R5333_init () {
	R5333[0] = (char *(*)()) F689_5989;
	R5333[1] = (char *(*)()) F690_5989_5333_242;
	R5333[2] = (char *(*)()) F691_5989_5333_242;
	R5333[3] = (char *(*)()) F692_5989_5333_242;
	R5333[4] = (char *(*)()) F693_5989_5333_242;
	R5333[5] = (char *(*)()) F694_5989_5333_242;
	R5333[6] = (char *(*)()) F695_5989_5333_242;
	R5333[7] = (char *(*)()) F696_5989_5333_242;
	R5333[8] = (char *(*)()) F697_5989_5333_242;
	R5333[9] = (char *(*)()) F698_5989_5333_242;
	R5333[10] = (char *(*)()) F699_5989_5333_242;
	R5333[11] = (char *(*)()) F700_5989_5333_242;
	R5333[19] = (char *(*)()) F689_5989;
	R5333[20] = (char *(*)()) F693_5989_5333_242;
	{long i; for (i = 21; i < 25; i++) R5333[i] = (char *(*)()) F689_5989;}
	R5333[29] = (char *(*)()) F689_5989;
	{long i; for (i = 32; i < 34; i++) R5333[i] = (char *(*)()) F689_5989;}
	R5333[37] = (char *(*)()) F689_5989;
	{long i; for (i = 39; i < 43; i++) R5333[i] = (char *(*)()) F689_5989;}
}
static void F690_5989_5333_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F690_5989(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F691_5989_5333_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F691_5989(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F692_5989_5333_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F692_5989(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F693_5989_5333_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F693_5989(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F694_5989_5333_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F694_5989(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F695_5989_5333_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F695_5989(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F696_5989_5333_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F696_5989(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F697_5989_5333_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F697_5989(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F698_5989_5333_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F698_5989(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F699_5989_5333_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F699_5989(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F700_5989_5333_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F700_5989(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5339[24])();
void R5339_init () {
	R5339[0] = (char *(*)()) F708_6034;
	R5339[1] = (char *(*)()) F709_6034_5339_242;
	R5339[2] = (char *(*)()) F708_6034;
	{long i; for (i = 3; i < 6; i++) R5339[i] = (char *(*)()) F711_6043;}
	R5339[10] = (char *(*)()) F711_6043;
	{long i; for (i = 13; i < 15; i++) R5339[i] = (char *(*)()) F711_6043;}
	R5339[18] = (char *(*)()) F711_6043;
	{long i; for (i = 20; i < 24; i++) R5339[i] = (char *(*)()) F711_6043;}
}
static void F709_6034_5339_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F709_6034(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R5340[24])();
void R5340_init () {
	R5340[0] = (char *(*)()) F708_6035;
	R5340[1] = (char *(*)()) F709_6035_5340_242;
	R5340[2] = (char *(*)()) F708_6035;
	{long i; for (i = 3; i < 6; i++) R5340[i] = (char *(*)()) F711_6044;}
	R5340[10] = (char *(*)()) F711_6044;
	{long i; for (i = 13; i < 15; i++) R5340[i] = (char *(*)()) F711_6044;}
	R5340[18] = (char *(*)()) F711_6044;
	{long i; for (i = 20; i < 24; i++) R5340[i] = (char *(*)()) F711_6044;}
}
static void F709_6035_5340_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F709_6035(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R5344[24])();
void R5344_init () {
	R5344[0] = (char *(*)()) F704_6023;
	R5344[1] = (char *(*)()) F705_6023_5344_242;
	{long i; for (i = 2; i < 6; i++) R5344[i] = (char *(*)()) F704_6023;}
	R5344[10] = (char *(*)()) F704_6023;
	{long i; for (i = 13; i < 15; i++) R5344[i] = (char *(*)()) F704_6023;}
	R5344[18] = (char *(*)()) F704_6023;
	{long i; for (i = 20; i < 24; i++) R5344[i] = (char *(*)()) F704_6023;}
}
static void F705_6023_5344_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F705_6023(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R5345[24])();
void R5345_init () {
	R5345[0] = (char *(*)()) F704_6024;
	R5345[1] = (char *(*)()) F705_6024_5345_242;
	{long i; for (i = 2; i < 6; i++) R5345[i] = (char *(*)()) F704_6024;}
	R5345[10] = (char *(*)()) F704_6024;
	{long i; for (i = 13; i < 15; i++) R5345[i] = (char *(*)()) F704_6024;}
	R5345[18] = (char *(*)()) F704_6024;
	{long i; for (i = 20; i < 24; i++) R5345[i] = (char *(*)()) F704_6024;}
}
static void F705_6024_5345_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F705_6024(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R5353[21])();
void R5353_init () {
	R5353[0] = (char *(*)()) F711_6045;
	R5353[1] = (char *(*)()) F712_6079;
	R5353[2] = (char *(*)()) F713_6080;
	R5353[7] = (char *(*)()) F712_6079;
	{long i; for (i = 10; i < 12; i++) R5353[i] = (char *(*)()) F712_6079;}
	R5353[15] = (char *(*)()) F712_6079;
	{long i; for (i = 17; i < 21; i++) R5353[i] = (char *(*)()) F712_6079;}
}

static EIF_TYPE_INDEX Y5385_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype2[] = {0xFFF9,1,973,0,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype4[] = {0xFFF9,1,973,1006,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype5[] = {0xFFF9,1,973,1177,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype6[] = {0xFFF9,1,973,1006,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype7[] = {0xFFF9,1,973,1182,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype8[] = {0xFFF9,1,973,1135,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype9[] = {0xFFF9,1,973,935,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype10[] = {0xFFF9,1,973,1110,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype11[] = {0xFFF9,1,973,1394,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype12[] = {0xFFF9,1,973,1006,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype13[] = {0xFFF9,5,973,979,1006,1006,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype14[] = {0xFFF9,1,973,1062,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype15[] = {0xFFF9,7,973,1006,1006,991,991,991,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype16[] = {0xFFF9,2,973,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype17[] = {0xFFF9,3,973,1006,1006,935,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype18[] = {0xFFF9,8,973,1006,1006,1006,991,991,991,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype19[] = {0xFFF9,0,973,0xFFFF};
static EIF_TYPE_INDEX Y5385_pgtype20[] = {0xFFF9,4,973,1006,1006,1006,1006,0xFFFF};
EIF_TYPE_INDEX *Y5385_gen_type [21];
EIF_TYPE_INDEX Y5385 [21];
void Y5385_init (void)
{
	egc_routines_types [5385] = Y5385;
	egc_routines_gen_types [5385] = Y5385_gen_type;
	egc_routines_offset [5385] = 710;
	Y5385_gen_type [0] = Y5385_pgtype0;
	Y5385_gen_type [1] = Y5385_pgtype1;
	Y5385_gen_type [2] = Y5385_pgtype2;
	Y5385_gen_type [3] = Y5385_pgtype3;
	Y5385_gen_type [4] = Y5385_pgtype4;
	Y5385_gen_type [5] = Y5385_pgtype5;
	Y5385_gen_type [6] = Y5385_pgtype6;
	Y5385_gen_type [7] = Y5385_pgtype7;
	Y5385_gen_type [8] = Y5385_pgtype8;
	Y5385_gen_type [9] = Y5385_pgtype9;
	Y5385_gen_type [10] = Y5385_pgtype10;
	Y5385_gen_type [11] = Y5385_pgtype11;
	Y5385_gen_type [12] = Y5385_pgtype12;
	Y5385_gen_type [13] = Y5385_pgtype13;
	Y5385_gen_type [14] = Y5385_pgtype14;
	Y5385_gen_type [15] = Y5385_pgtype15;
	Y5385_gen_type [16] = Y5385_pgtype16;
	Y5385_gen_type [17] = Y5385_pgtype17;
	Y5385_gen_type [18] = Y5385_pgtype18;
	Y5385_gen_type [19] = Y5385_pgtype19;
	Y5385_gen_type [20] = Y5385_pgtype20;
	Y5385[2] = 973;
	{long i; for (i = 4; i < 21; i++) Y5385[i] = 973;};
}

char *(*R5409[180])();
void R5409_init () {
	R5409[0] = (char *(*)()) F505_5249_5409_1;
	R5409[4] = (char *(*)()) F505_5249_5409_1;
	R5409[35] = (char *(*)()) F769_6243;
	R5409[36] = (char *(*)()) F770_6243_5409_1;
	R5409[37] = (char *(*)()) F771_6243_5409_1;
	R5409[38] = (char *(*)()) F772_6243_5409_1;
	R5409[39] = (char *(*)()) F773_6243_5409_1;
	R5409[40] = (char *(*)()) F774_6243_5409_1;
	R5409[41] = (char *(*)()) F775_6243_5409_1;
	R5409[42] = (char *(*)()) F776_6243_5409_1;
	R5409[43] = (char *(*)()) F777_6243_5409_1;
	R5409[44] = (char *(*)()) F778_6243_5409_1;
	R5409[45] = (char *(*)()) F779_6243_5409_1;
	R5409[46] = (char *(*)()) F780_6243_5409_1;
	R5409[47] = (char *(*)()) F793_6271;
	R5409[48] = (char *(*)()) F794_6271_5409_1;
	R5409[49] = (char *(*)()) F795_6271_5409_1;
	R5409[50] = (char *(*)()) F796_6271;
	R5409[51] = (char *(*)()) F797_6271_5409_1;
	R5409[52] = (char *(*)()) F798_6271_5409_1;
	R5409[53] = (char *(*)()) F799_6277;
	R5409[54] = (char *(*)()) F800_6277_5409_1;
	R5409[55] = (char *(*)()) F801_6277_5409_1;
	R5409[56] = (char *(*)()) F802_6283;
	R5409[69] = (char *(*)()) F803_6289;
	R5409[70] = (char *(*)()) F804_6289_5409_1;
	R5409[71] = (char *(*)()) F805_6289_5409_1;
	R5409[72] = (char *(*)()) F806_6289_5409_1;
	R5409[73] = (char *(*)()) F807_6289_5409_1;
	R5409[74] = (char *(*)()) F808_6289_5409_1;
	R5409[75] = (char *(*)()) F809_6289_5409_1;
	R5409[76] = (char *(*)()) F810_6289_5409_1;
	R5409[77] = (char *(*)()) F811_6289_5409_1;
	R5409[78] = (char *(*)()) F812_6289_5409_1;
	R5409[79] = (char *(*)()) F813_6289_5409_1;
	R5409[80] = (char *(*)()) F814_6289_5409_1;
	R5409[82] = (char *(*)()) F808_6289_5409_1;
	R5409[179] = (char *(*)()) F925_6731_5409_1;
}
static EIF_REFERENCE F505_5249_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F505_5249(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F770_6243_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F770_6243(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(976, 0x00).id, 976, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F771_6243_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F771_6243(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(985, 0x00).id, 985, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F772_6243_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F772_6243(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F773_6243_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F773_6243(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F774_6243_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F774_6243(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(979, 0x00).id, 979, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F775_6243_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F775_6243(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F776_6243_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F776_6243(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(982, 0x00).id, 982, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F777_6243_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F777_6243(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F778_6243_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F778_6243(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F779_6243_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F779_6243(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(988, 0x00).id, 988, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F780_6243_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F780_6243(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F794_6271_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F794_6271(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F795_6271_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F795_6271(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F797_6271_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F797_6271(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F798_6271_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F798_6271(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F800_6277_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F800_6277(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F801_6277_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F801_6277(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F804_6289_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F804_6289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(976, 0x00).id, 976, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F805_6289_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F805_6289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(985, 0x00).id, 985, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F806_6289_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F806_6289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(979, 0x00).id, 979, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F807_6289_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F807_6289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F808_6289_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F808_6289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F809_6289_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F809_6289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F810_6289_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F810_6289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(982, 0x00).id, 982, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F811_6289_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F811_6289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F812_6289_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F812_6289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F813_6289_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F813_6289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(988, 0x00).id, 988, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F814_6289_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F814_6289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F925_6731_5409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F925_6731(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R5410[180])();
void R5410_init () {
	R5410[0] = (char *(*)()) F505_5250;
	R5410[4] = (char *(*)()) F505_5250;
	R5410[35] = (char *(*)()) F781_6261;
	R5410[36] = (char *(*)()) F782_6261;
	R5410[37] = (char *(*)()) F783_6261;
	R5410[38] = (char *(*)()) F784_6261;
	R5410[39] = (char *(*)()) F785_6261;
	R5410[40] = (char *(*)()) F786_6261;
	R5410[41] = (char *(*)()) F787_6261;
	R5410[42] = (char *(*)()) F788_6261;
	R5410[43] = (char *(*)()) F789_6261;
	R5410[44] = (char *(*)()) F790_6261;
	R5410[45] = (char *(*)()) F791_6261;
	R5410[46] = (char *(*)()) F792_6261;
	R5410[47] = (char *(*)()) F793_6274;
	R5410[48] = (char *(*)()) F794_6274;
	R5410[49] = (char *(*)()) F795_6274;
	R5410[50] = (char *(*)()) F796_6274;
	R5410[51] = (char *(*)()) F797_6274;
	R5410[52] = (char *(*)()) F798_6274;
	R5410[53] = (char *(*)()) F799_6278;
	R5410[54] = (char *(*)()) F800_6278;
	R5410[55] = (char *(*)()) F801_6278;
	R5410[56] = (char *(*)()) F802_6284;
	R5410[69] = (char *(*)()) F803_6298;
	R5410[70] = (char *(*)()) F804_6298;
	R5410[71] = (char *(*)()) F805_6298;
	R5410[72] = (char *(*)()) F806_6298;
	R5410[73] = (char *(*)()) F807_6298;
	R5410[74] = (char *(*)()) F808_6298;
	R5410[75] = (char *(*)()) F809_6298;
	R5410[76] = (char *(*)()) F810_6298;
	R5410[77] = (char *(*)()) F811_6298;
	R5410[78] = (char *(*)()) F812_6298;
	R5410[79] = (char *(*)()) F813_6298;
	R5410[80] = (char *(*)()) F814_6298;
	R5410[82] = (char *(*)()) F808_6298;
	R5410[179] = (char *(*)()) F925_6733;
}

char *(*R5411[180])();
void R5411_init () {
	R5411[0] = (char *(*)()) F505_5256;
	R5411[4] = (char *(*)()) F505_5256;
	R5411[35] = (char *(*)()) F781_6269;
	R5411[36] = (char *(*)()) F782_6269;
	R5411[37] = (char *(*)()) F783_6269;
	R5411[38] = (char *(*)()) F784_6269;
	R5411[39] = (char *(*)()) F785_6269;
	R5411[40] = (char *(*)()) F786_6269;
	R5411[41] = (char *(*)()) F787_6269;
	R5411[42] = (char *(*)()) F788_6269;
	R5411[43] = (char *(*)()) F789_6269;
	R5411[44] = (char *(*)()) F790_6269;
	R5411[45] = (char *(*)()) F791_6269;
	R5411[46] = (char *(*)()) F792_6269;
	R5411[47] = (char *(*)()) F793_6275;
	R5411[48] = (char *(*)()) F794_6275;
	R5411[49] = (char *(*)()) F795_6275;
	R5411[50] = (char *(*)()) F796_6275;
	R5411[51] = (char *(*)()) F797_6275;
	R5411[52] = (char *(*)()) F798_6275;
	R5411[53] = (char *(*)()) F799_6280;
	R5411[54] = (char *(*)()) F800_6280;
	R5411[55] = (char *(*)()) F801_6280;
	R5411[56] = (char *(*)()) F802_6286;
	R5411[69] = (char *(*)()) F803_6304;
	R5411[70] = (char *(*)()) F804_6304;
	R5411[71] = (char *(*)()) F805_6304;
	R5411[72] = (char *(*)()) F806_6304;
	R5411[73] = (char *(*)()) F807_6304;
	R5411[74] = (char *(*)()) F808_6304;
	R5411[75] = (char *(*)()) F809_6304;
	R5411[76] = (char *(*)()) F810_6304;
	R5411[77] = (char *(*)()) F811_6304;
	R5411[78] = (char *(*)()) F812_6304;
	R5411[79] = (char *(*)()) F813_6304;
	R5411[80] = (char *(*)()) F814_6304;
	R5411[82] = (char *(*)()) F808_6304;
	R5411[179] = (char *(*)()) F925_6734;
}

char *(*R5469[6])();
void R5469_init () {
	R5469[0] = (char *(*)()) F793_6272;
	R5469[1] = (char *(*)()) F794_6272;
	R5469[2] = (char *(*)()) F795_6272;
	R5469[3] = (char *(*)()) F796_6272_5469_1;
	R5469[4] = (char *(*)()) F797_6272_5469_1;
	R5469[5] = (char *(*)()) F798_6272_5469_1;
}
static EIF_REFERENCE F796_6272_5469_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F796_6272(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F797_6272_5469_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F797_6272(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(979, 0x00).id, 979, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F798_6272_5469_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F798_6272(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5472[48])();
void R5472_init () {
	R5472[0] = (char *(*)()) F781_6251;
	R5472[1] = (char *(*)()) F782_6251;
	R5472[2] = (char *(*)()) F783_6251;
	R5472[3] = (char *(*)()) F784_6251;
	R5472[4] = (char *(*)()) F785_6251;
	R5472[5] = (char *(*)()) F786_6251;
	R5472[6] = (char *(*)()) F787_6251;
	R5472[7] = (char *(*)()) F788_6251;
	R5472[8] = (char *(*)()) F789_6251;
	R5472[9] = (char *(*)()) F790_6251;
	R5472[10] = (char *(*)()) F791_6251;
	R5472[11] = (char *(*)()) F792_6251;
	R5472[12] = (char *(*)()) F781_6251;
	R5472[13] = (char *(*)()) F785_6251;
	R5472[14] = (char *(*)()) F790_6251;
	R5472[15] = (char *(*)()) F781_6251;
	{long i; for (i = 16; i < 18; i++) R5472[i] = (char *(*)()) F785_6251;}
	R5472[18] = (char *(*)()) F781_6251;
	R5472[19] = (char *(*)()) F785_6251;
	R5472[20] = (char *(*)()) F789_6251;
	R5472[21] = (char *(*)()) F781_6251;
	R5472[34] = (char *(*)()) F803_6291;
	R5472[35] = (char *(*)()) F804_6291;
	R5472[36] = (char *(*)()) F805_6291;
	R5472[37] = (char *(*)()) F806_6291;
	R5472[38] = (char *(*)()) F807_6291;
	R5472[39] = (char *(*)()) F808_6291;
	R5472[40] = (char *(*)()) F809_6291;
	R5472[41] = (char *(*)()) F810_6291;
	R5472[42] = (char *(*)()) F811_6291;
	R5472[43] = (char *(*)()) F812_6291;
	R5472[44] = (char *(*)()) F813_6291;
	R5472[45] = (char *(*)()) F814_6291;
	R5472[47] = (char *(*)()) F808_6291;
}

char *(*R5473[48])();
void R5473_init () {
	R5473[0] = (char *(*)()) F781_6252;
	R5473[1] = (char *(*)()) F782_6252;
	R5473[2] = (char *(*)()) F783_6252;
	R5473[3] = (char *(*)()) F784_6252;
	R5473[4] = (char *(*)()) F785_6252;
	R5473[5] = (char *(*)()) F786_6252;
	R5473[6] = (char *(*)()) F787_6252;
	R5473[7] = (char *(*)()) F788_6252;
	R5473[8] = (char *(*)()) F789_6252;
	R5473[9] = (char *(*)()) F790_6252;
	R5473[10] = (char *(*)()) F791_6252;
	R5473[11] = (char *(*)()) F792_6252;
	R5473[12] = (char *(*)()) F781_6252;
	R5473[13] = (char *(*)()) F785_6252;
	R5473[14] = (char *(*)()) F790_6252;
	R5473[15] = (char *(*)()) F781_6252;
	{long i; for (i = 16; i < 18; i++) R5473[i] = (char *(*)()) F785_6252;}
	R5473[18] = (char *(*)()) F781_6252;
	R5473[19] = (char *(*)()) F785_6252;
	R5473[20] = (char *(*)()) F789_6252;
	R5473[21] = (char *(*)()) F781_6252;
	R5473[34] = (char *(*)()) F815_6310;
	R5473[35] = (char *(*)()) F816_6310;
	R5473[36] = (char *(*)()) F817_6310;
	R5473[37] = (char *(*)()) F818_6310;
	R5473[38] = (char *(*)()) F819_6310;
	R5473[39] = (char *(*)()) F820_6310;
	R5473[40] = (char *(*)()) F821_6310;
	R5473[41] = (char *(*)()) F822_6310;
	R5473[42] = (char *(*)()) F823_6310;
	R5473[43] = (char *(*)()) F824_6310;
	R5473[44] = (char *(*)()) F825_6310;
	R5473[45] = (char *(*)()) F826_6310;
	R5473[47] = (char *(*)()) F828_6322;
}

char *(*R5481[22])();
void R5481_init () {
	R5481[0] = (char *(*)()) F781_6263;
	R5481[1] = (char *(*)()) F782_6263;
	R5481[2] = (char *(*)()) F783_6263;
	R5481[3] = (char *(*)()) F784_6263;
	R5481[4] = (char *(*)()) F785_6263;
	R5481[5] = (char *(*)()) F786_6263;
	R5481[6] = (char *(*)()) F787_6263;
	R5481[7] = (char *(*)()) F788_6263;
	R5481[8] = (char *(*)()) F789_6263;
	R5481[9] = (char *(*)()) F790_6263;
	R5481[10] = (char *(*)()) F791_6263;
	R5481[11] = (char *(*)()) F792_6263;
	R5481[12] = (char *(*)()) F781_6263;
	R5481[13] = (char *(*)()) F785_6263;
	R5481[14] = (char *(*)()) F790_6263;
	R5481[15] = (char *(*)()) F781_6263;
	{long i; for (i = 16; i < 18; i++) R5481[i] = (char *(*)()) F785_6263;}
	R5481[18] = (char *(*)()) F781_6263;
	R5481[19] = (char *(*)()) F785_6263;
	R5481[20] = (char *(*)()) F789_6263;
	R5481[21] = (char *(*)()) F781_6263;
}

char *(*R5484[48])();
void R5484_init () {
	R5484[0] = (char *(*)()) F781_6268;
	R5484[1] = (char *(*)()) F782_6268;
	R5484[2] = (char *(*)()) F783_6268;
	R5484[3] = (char *(*)()) F784_6268;
	R5484[4] = (char *(*)()) F785_6268;
	R5484[5] = (char *(*)()) F786_6268;
	R5484[6] = (char *(*)()) F787_6268;
	R5484[7] = (char *(*)()) F788_6268;
	R5484[8] = (char *(*)()) F789_6268;
	R5484[9] = (char *(*)()) F790_6268;
	R5484[10] = (char *(*)()) F791_6268;
	R5484[11] = (char *(*)()) F792_6268;
	R5484[12] = (char *(*)()) F781_6268;
	R5484[13] = (char *(*)()) F785_6268;
	R5484[14] = (char *(*)()) F790_6268;
	R5484[15] = (char *(*)()) F781_6268;
	{long i; for (i = 16; i < 18; i++) R5484[i] = (char *(*)()) F785_6268;}
	R5484[18] = (char *(*)()) F799_6279;
	R5484[19] = (char *(*)()) F800_6279;
	R5484[20] = (char *(*)()) F801_6279;
	R5484[21] = (char *(*)()) F802_6285;
	R5484[34] = (char *(*)()) F803_6303;
	R5484[35] = (char *(*)()) F804_6303;
	R5484[36] = (char *(*)()) F805_6303;
	R5484[37] = (char *(*)()) F806_6303;
	R5484[38] = (char *(*)()) F807_6303;
	R5484[39] = (char *(*)()) F808_6303;
	R5484[40] = (char *(*)()) F809_6303;
	R5484[41] = (char *(*)()) F810_6303;
	R5484[42] = (char *(*)()) F811_6303;
	R5484[43] = (char *(*)()) F812_6303;
	R5484[44] = (char *(*)()) F813_6303;
	R5484[45] = (char *(*)()) F814_6303;
	R5484[47] = (char *(*)()) F808_6303;
}

char *(*R5485[48])();
void R5485_init () {
	R5485[0] = (char *(*)()) F781_6270;
	R5485[1] = (char *(*)()) F782_6270;
	R5485[2] = (char *(*)()) F783_6270;
	R5485[3] = (char *(*)()) F784_6270;
	R5485[4] = (char *(*)()) F785_6270;
	R5485[5] = (char *(*)()) F786_6270;
	R5485[6] = (char *(*)()) F787_6270;
	R5485[7] = (char *(*)()) F788_6270;
	R5485[8] = (char *(*)()) F789_6270;
	R5485[9] = (char *(*)()) F790_6270;
	R5485[10] = (char *(*)()) F791_6270;
	R5485[11] = (char *(*)()) F792_6270;
	R5485[12] = (char *(*)()) F793_6276;
	R5485[13] = (char *(*)()) F794_6276;
	R5485[14] = (char *(*)()) F795_6276;
	R5485[15] = (char *(*)()) F796_6276;
	R5485[16] = (char *(*)()) F797_6276;
	R5485[17] = (char *(*)()) F798_6276;
	R5485[18] = (char *(*)()) F799_6281;
	R5485[19] = (char *(*)()) F800_6281;
	R5485[20] = (char *(*)()) F801_6281;
	R5485[21] = (char *(*)()) F802_6287;
	R5485[34] = (char *(*)()) F815_6313;
	R5485[35] = (char *(*)()) F816_6313;
	R5485[36] = (char *(*)()) F817_6313;
	R5485[37] = (char *(*)()) F818_6313;
	R5485[38] = (char *(*)()) F819_6313;
	R5485[39] = (char *(*)()) F820_6313;
	R5485[40] = (char *(*)()) F821_6313;
	R5485[41] = (char *(*)()) F822_6313;
	R5485[42] = (char *(*)()) F823_6313;
	R5485[43] = (char *(*)()) F824_6313;
	R5485[44] = (char *(*)()) F825_6313;
	R5485[45] = (char *(*)()) F826_6313;
	R5485[47] = (char *(*)()) F828_6325;
}

char *(*R5487[22])();
void R5487_init () {
	R5487[0] = (char *(*)()) F781_6249;
	R5487[1] = (char *(*)()) F782_6249;
	R5487[2] = (char *(*)()) F783_6249;
	R5487[3] = (char *(*)()) F784_6249;
	R5487[4] = (char *(*)()) F785_6249;
	R5487[5] = (char *(*)()) F786_6249;
	R5487[6] = (char *(*)()) F787_6249;
	R5487[7] = (char *(*)()) F788_6249;
	R5487[8] = (char *(*)()) F789_6249;
	R5487[9] = (char *(*)()) F790_6249;
	R5487[10] = (char *(*)()) F791_6249;
	R5487[11] = (char *(*)()) F792_6249;
	R5487[12] = (char *(*)()) F781_6249;
	R5487[13] = (char *(*)()) F785_6249;
	R5487[14] = (char *(*)()) F790_6249;
	R5487[15] = (char *(*)()) F781_6249;
	{long i; for (i = 16; i < 18; i++) R5487[i] = (char *(*)()) F785_6249;}
	R5487[18] = (char *(*)()) F781_6249;
	R5487[19] = (char *(*)()) F785_6249;
	R5487[20] = (char *(*)()) F789_6249;
	R5487[21] = (char *(*)()) F781_6249;
}

char *(*R5500[14])();
void R5500_init () {
	R5500[0] = (char *(*)()) F815_6314;
	R5500[1] = (char *(*)()) F816_6314;
	R5500[2] = (char *(*)()) F817_6314;
	R5500[3] = (char *(*)()) F818_6314;
	R5500[4] = (char *(*)()) F819_6314;
	R5500[5] = (char *(*)()) F820_6314;
	R5500[6] = (char *(*)()) F821_6314;
	R5500[7] = (char *(*)()) F822_6314;
	R5500[8] = (char *(*)()) F823_6314;
	R5500[9] = (char *(*)()) F824_6314;
	R5500[10] = (char *(*)()) F825_6314;
	R5500[11] = (char *(*)()) F826_6314;
	R5500[13] = (char *(*)()) F828_6326;
}

char *(*R5502[12])();
void R5502_init () {
	R5502[0] = (char *(*)()) F815_6309;
	R5502[1] = (char *(*)()) F816_6309;
	R5502[2] = (char *(*)()) F817_6309;
	R5502[3] = (char *(*)()) F818_6309;
	R5502[4] = (char *(*)()) F819_6309;
	R5502[5] = (char *(*)()) F820_6309;
	R5502[6] = (char *(*)()) F821_6309;
	R5502[7] = (char *(*)()) F822_6309;
	R5502[8] = (char *(*)()) F823_6309;
	R5502[9] = (char *(*)()) F824_6309;
	R5502[10] = (char *(*)()) F825_6309;
	R5502[11] = (char *(*)()) F826_6309;
}

char *(*R5660[12])();
void R5660_init () {
	R5660[0] = (char *(*)()) F859_6505;
	R5660[1] = (char *(*)()) F860_6505;
	R5660[2] = (char *(*)()) F861_6505;
	R5660[3] = (char *(*)()) F862_6505;
	R5660[4] = (char *(*)()) F863_6505;
	R5660[5] = (char *(*)()) F864_6505;
	R5660[6] = (char *(*)()) F865_6505;
	R5660[7] = (char *(*)()) F866_6505;
	R5660[8] = (char *(*)()) F867_6505;
	R5660[9] = (char *(*)()) F868_6505;
	R5660[10] = (char *(*)()) F869_6505;
	R5660[11] = (char *(*)()) F870_6505;
}

char *(*R5661[12])();
void R5661_init () {
	R5661[0] = (char *(*)()) F859_6506;
	R5661[1] = (char *(*)()) F860_6506;
	R5661[2] = (char *(*)()) F861_6506;
	R5661[3] = (char *(*)()) F862_6506;
	R5661[4] = (char *(*)()) F863_6506;
	R5661[5] = (char *(*)()) F864_6506;
	R5661[6] = (char *(*)()) F865_6506;
	R5661[7] = (char *(*)()) F866_6506;
	R5661[8] = (char *(*)()) F867_6506;
	R5661[9] = (char *(*)()) F868_6506;
	R5661[10] = (char *(*)()) F869_6506;
	R5661[11] = (char *(*)()) F870_6506;
}

char *(*R5663[12])();
void R5663_init () {
	R5663[0] = (char *(*)()) F859_6492;
	R5663[1] = (char *(*)()) F860_6492;
	R5663[2] = (char *(*)()) F861_6492;
	R5663[3] = (char *(*)()) F862_6492;
	R5663[4] = (char *(*)()) F863_6492;
	R5663[5] = (char *(*)()) F864_6492;
	R5663[6] = (char *(*)()) F865_6492;
	R5663[7] = (char *(*)()) F866_6492;
	R5663[8] = (char *(*)()) F867_6492;
	R5663[9] = (char *(*)()) F868_6492;
	R5663[10] = (char *(*)()) F869_6492;
	R5663[11] = (char *(*)()) F870_6492;
}

char *(*R5664[12])();
void R5664_init () {
	R5664[0] = (char *(*)()) F859_6493;
	R5664[1] = (char *(*)()) F860_6493_5664_242;
	R5664[2] = (char *(*)()) F861_6493_5664_242;
	R5664[3] = (char *(*)()) F862_6493_5664_242;
	R5664[4] = (char *(*)()) F863_6493_5664_242;
	R5664[5] = (char *(*)()) F864_6493_5664_242;
	R5664[6] = (char *(*)()) F865_6493_5664_242;
	R5664[7] = (char *(*)()) F866_6493_5664_242;
	R5664[8] = (char *(*)()) F867_6493_5664_242;
	R5664[9] = (char *(*)()) F868_6493_5664_242;
	R5664[10] = (char *(*)()) F869_6493_5664_242;
	R5664[11] = (char *(*)()) F870_6493_5664_242;
}
static void F860_6493_5664_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F860_6493(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F861_6493_5664_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F861_6493(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F862_6493_5664_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F862_6493(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F863_6493_5664_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F863_6493(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F864_6493_5664_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F864_6493(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F865_6493_5664_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F865_6493(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F866_6493_5664_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F866_6493(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F867_6493_5664_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F867_6493(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F868_6493_5664_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F868_6493(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F869_6493_5664_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F869_6493(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F870_6493_5664_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F870_6493(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5673[12])();
void R5673_init () {
	R5673[0] = (char *(*)()) F859_6508;
	R5673[1] = (char *(*)()) F860_6508;
	R5673[2] = (char *(*)()) F861_6508;
	R5673[3] = (char *(*)()) F862_6508;
	R5673[4] = (char *(*)()) F863_6508;
	R5673[5] = (char *(*)()) F864_6508;
	R5673[6] = (char *(*)()) F865_6508;
	R5673[7] = (char *(*)()) F866_6508;
	R5673[8] = (char *(*)()) F867_6508;
	R5673[9] = (char *(*)()) F868_6508;
	R5673[10] = (char *(*)()) F869_6508;
	R5673[11] = (char *(*)()) F870_6508;
}

char *(*R5674[12])();
void R5674_init () {
	R5674[0] = (char *(*)()) F859_6510;
	R5674[1] = (char *(*)()) F860_6510_5674_242;
	R5674[2] = (char *(*)()) F861_6510_5674_242;
	R5674[3] = (char *(*)()) F862_6510_5674_242;
	R5674[4] = (char *(*)()) F863_6510_5674_242;
	R5674[5] = (char *(*)()) F864_6510_5674_242;
	R5674[6] = (char *(*)()) F865_6510_5674_242;
	R5674[7] = (char *(*)()) F866_6510_5674_242;
	R5674[8] = (char *(*)()) F867_6510_5674_242;
	R5674[9] = (char *(*)()) F868_6510_5674_242;
	R5674[10] = (char *(*)()) F869_6510_5674_242;
	R5674[11] = (char *(*)()) F870_6510_5674_242;
}
static void F860_6510_5674_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F860_6510(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F861_6510_5674_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F861_6510(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F862_6510_5674_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F862_6510(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F863_6510_5674_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F863_6510(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F864_6510_5674_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F864_6510(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F865_6510_5674_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F865_6510(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F866_6510_5674_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F866_6510(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F867_6510_5674_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F867_6510(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F868_6510_5674_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F868_6510(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F869_6510_5674_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F869_6510(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F870_6510_5674_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F870_6510(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5675[12])();
void R5675_init () {
	R5675[0] = (char *(*)()) F859_6511;
	R5675[1] = (char *(*)()) F860_6511_5675_242;
	R5675[2] = (char *(*)()) F861_6511_5675_242;
	R5675[3] = (char *(*)()) F862_6511_5675_242;
	R5675[4] = (char *(*)()) F863_6511_5675_242;
	R5675[5] = (char *(*)()) F864_6511_5675_242;
	R5675[6] = (char *(*)()) F865_6511_5675_242;
	R5675[7] = (char *(*)()) F866_6511_5675_242;
	R5675[8] = (char *(*)()) F867_6511_5675_242;
	R5675[9] = (char *(*)()) F868_6511_5675_242;
	R5675[10] = (char *(*)()) F869_6511_5675_242;
	R5675[11] = (char *(*)()) F870_6511_5675_242;
}
static void F860_6511_5675_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F860_6511(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F861_6511_5675_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F861_6511(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F862_6511_5675_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F862_6511(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F863_6511_5675_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F863_6511(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F864_6511_5675_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F864_6511(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F865_6511_5675_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F865_6511(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F866_6511_5675_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F866_6511(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F867_6511_5675_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F867_6511(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F868_6511_5675_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F868_6511(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F869_6511_5675_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F869_6511(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F870_6511_5675_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F870_6511(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5676[12])();
void R5676_init () {
	R5676[0] = (char *(*)()) F859_6512;
	R5676[1] = (char *(*)()) F860_6512_5676_4;
	R5676[2] = (char *(*)()) F861_6512_5676_4;
	R5676[3] = (char *(*)()) F862_6512_5676_4;
	R5676[4] = (char *(*)()) F863_6512_5676_4;
	R5676[5] = (char *(*)()) F864_6512_5676_4;
	R5676[6] = (char *(*)()) F865_6512_5676_4;
	R5676[7] = (char *(*)()) F866_6512_5676_4;
	R5676[8] = (char *(*)()) F867_6512_5676_4;
	R5676[9] = (char *(*)()) F868_6512_5676_4;
	R5676[10] = (char *(*)()) F869_6512_5676_4;
	R5676[11] = (char *(*)()) F870_6512_5676_4;
}
static void F860_6512_5676_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F860_6512(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F861_6512_5676_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F861_6512(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F862_6512_5676_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F862_6512(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F863_6512_5676_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F863_6512(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F864_6512_5676_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F864_6512(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F865_6512_5676_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F865_6512(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F866_6512_5676_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F866_6512(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F867_6512_5676_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F867_6512(Current, *(EIF_BOOLEAN *)arg1);
}
static void F868_6512_5676_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F868_6512(Current, *(EIF_POINTER *)arg1);
}
static void F869_6512_5676_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F869_6512(Current, *(EIF_REAL_32 *)arg1);
}
static void F870_6512_5676_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F870_6512(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R5678[12])();
void R5678_init () {
	R5678[0] = (char *(*)()) F859_6514;
	R5678[1] = (char *(*)()) F860_6514_5678_276;
	R5678[2] = (char *(*)()) F861_6514_5678_276;
	R5678[3] = (char *(*)()) F862_6514_5678_276;
	R5678[4] = (char *(*)()) F863_6514_5678_276;
	R5678[5] = (char *(*)()) F864_6514_5678_276;
	R5678[6] = (char *(*)()) F865_6514_5678_276;
	R5678[7] = (char *(*)()) F866_6514_5678_276;
	R5678[8] = (char *(*)()) F867_6514_5678_276;
	R5678[9] = (char *(*)()) F868_6514_5678_276;
	R5678[10] = (char *(*)()) F869_6514_5678_276;
	R5678[11] = (char *(*)()) F870_6514_5678_276;
}
static void F860_6514_5678_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F860_6514(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F861_6514_5678_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F861_6514(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F862_6514_5678_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F862_6514(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F863_6514_5678_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F863_6514(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F864_6514_5678_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F864_6514(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F865_6514_5678_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F865_6514(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F866_6514_5678_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F866_6514(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F867_6514_5678_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F867_6514(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F868_6514_5678_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F868_6514(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F869_6514_5678_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F869_6514(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F870_6514_5678_276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F870_6514(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R5681[12])();
void R5681_init () {
	R5681[0] = (char *(*)()) F859_6517;
	R5681[1] = (char *(*)()) F860_6517;
	R5681[2] = (char *(*)()) F861_6517;
	R5681[3] = (char *(*)()) F862_6517;
	R5681[4] = (char *(*)()) F863_6517;
	R5681[5] = (char *(*)()) F864_6517;
	R5681[6] = (char *(*)()) F865_6517;
	R5681[7] = (char *(*)()) F866_6517;
	R5681[8] = (char *(*)()) F867_6517;
	R5681[9] = (char *(*)()) F868_6517;
	R5681[10] = (char *(*)()) F869_6517;
	R5681[11] = (char *(*)()) F870_6517;
}

char *(*R5682[12])();
void R5682_init () {
	R5682[0] = (char *(*)()) F859_6518;
	R5682[1] = (char *(*)()) F860_6518;
	R5682[2] = (char *(*)()) F861_6518;
	R5682[3] = (char *(*)()) F862_6518;
	R5682[4] = (char *(*)()) F863_6518;
	R5682[5] = (char *(*)()) F864_6518;
	R5682[6] = (char *(*)()) F865_6518;
	R5682[7] = (char *(*)()) F866_6518;
	R5682[8] = (char *(*)()) F867_6518;
	R5682[9] = (char *(*)()) F868_6518;
	R5682[10] = (char *(*)()) F869_6518;
	R5682[11] = (char *(*)()) F870_6518;
}

char *(*R5683[12])();
void R5683_init () {
	R5683[0] = (char *(*)()) F859_6519;
	R5683[1] = (char *(*)()) F860_6519;
	R5683[2] = (char *(*)()) F861_6519;
	R5683[3] = (char *(*)()) F862_6519;
	R5683[4] = (char *(*)()) F863_6519;
	R5683[5] = (char *(*)()) F864_6519;
	R5683[6] = (char *(*)()) F865_6519;
	R5683[7] = (char *(*)()) F866_6519;
	R5683[8] = (char *(*)()) F867_6519;
	R5683[9] = (char *(*)()) F868_6519;
	R5683[10] = (char *(*)()) F869_6519;
	R5683[11] = (char *(*)()) F870_6519;
}

char *(*R5684[12])();
void R5684_init () {
	R5684[0] = (char *(*)()) F859_6520;
	R5684[1] = (char *(*)()) F860_6520;
	R5684[2] = (char *(*)()) F861_6520;
	R5684[3] = (char *(*)()) F862_6520;
	R5684[4] = (char *(*)()) F863_6520;
	R5684[5] = (char *(*)()) F864_6520;
	R5684[6] = (char *(*)()) F865_6520;
	R5684[7] = (char *(*)()) F866_6520;
	R5684[8] = (char *(*)()) F867_6520;
	R5684[9] = (char *(*)()) F868_6520;
	R5684[10] = (char *(*)()) F869_6520;
	R5684[11] = (char *(*)()) F870_6520;
}

char *(*R5685[12])();
void R5685_init () {
	R5685[0] = (char *(*)()) F859_6521;
	R5685[1] = (char *(*)()) F860_6521;
	R5685[2] = (char *(*)()) F861_6521;
	R5685[3] = (char *(*)()) F862_6521;
	R5685[4] = (char *(*)()) F863_6521;
	R5685[5] = (char *(*)()) F864_6521;
	R5685[6] = (char *(*)()) F865_6521;
	R5685[7] = (char *(*)()) F866_6521;
	R5685[8] = (char *(*)()) F867_6521;
	R5685[9] = (char *(*)()) F868_6521;
	R5685[10] = (char *(*)()) F869_6521;
	R5685[11] = (char *(*)()) F870_6521;
}

char *(*R5688[12])();
void R5688_init () {
	R5688[0] = (char *(*)()) F859_6524;
	R5688[1] = (char *(*)()) F860_6524;
	R5688[2] = (char *(*)()) F861_6524;
	R5688[3] = (char *(*)()) F862_6524;
	R5688[4] = (char *(*)()) F863_6524;
	R5688[5] = (char *(*)()) F864_6524;
	R5688[6] = (char *(*)()) F865_6524;
	R5688[7] = (char *(*)()) F866_6524;
	R5688[8] = (char *(*)()) F867_6524;
	R5688[9] = (char *(*)()) F868_6524;
	R5688[10] = (char *(*)()) F869_6524;
	R5688[11] = (char *(*)()) F870_6524;
}

char *(*R5691[12])();
void R5691_init () {
	R5691[0] = (char *(*)()) F859_6527;
	R5691[1] = (char *(*)()) F860_6527;
	R5691[2] = (char *(*)()) F861_6527;
	R5691[3] = (char *(*)()) F862_6527;
	R5691[4] = (char *(*)()) F863_6527;
	R5691[5] = (char *(*)()) F864_6527;
	R5691[6] = (char *(*)()) F865_6527;
	R5691[7] = (char *(*)()) F866_6527;
	R5691[8] = (char *(*)()) F867_6527;
	R5691[9] = (char *(*)()) F868_6527;
	R5691[10] = (char *(*)()) F869_6527;
	R5691[11] = (char *(*)()) F870_6527;
}

char *(*R5692[12])();
void R5692_init () {
	R5692[0] = (char *(*)()) F859_6528;
	R5692[1] = (char *(*)()) F860_6528_5692_11;
	R5692[2] = (char *(*)()) F861_6528_5692_11;
	R5692[3] = (char *(*)()) F862_6528_5692_11;
	R5692[4] = (char *(*)()) F863_6528_5692_11;
	R5692[5] = (char *(*)()) F864_6528_5692_11;
	R5692[6] = (char *(*)()) F865_6528_5692_11;
	R5692[7] = (char *(*)()) F866_6528_5692_11;
	R5692[8] = (char *(*)()) F867_6528_5692_11;
	R5692[9] = (char *(*)()) F868_6528_5692_11;
	R5692[10] = (char *(*)()) F869_6528_5692_11;
	R5692[11] = (char *(*)()) F870_6528_5692_11;
}
static EIF_REFERENCE F860_6528_5692_11 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F860_6528(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F861_6528_5692_11 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F861_6528(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F862_6528_5692_11 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F862_6528(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F863_6528_5692_11 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F863_6528(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F864_6528_5692_11 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F864_6528(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F865_6528_5692_11 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F865_6528(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F866_6528_5692_11 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F866_6528(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F867_6528_5692_11 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F867_6528(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F868_6528_5692_11 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F868_6528(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F869_6528_5692_11 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F869_6528(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F870_6528_5692_11 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F870_6528(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5694[12])();
void R5694_init () {
	R5694[0] = (char *(*)()) F859_6530;
	R5694[1] = (char *(*)()) F860_6530;
	R5694[2] = (char *(*)()) F861_6530;
	R5694[3] = (char *(*)()) F862_6530;
	R5694[4] = (char *(*)()) F863_6530;
	R5694[5] = (char *(*)()) F864_6530;
	R5694[6] = (char *(*)()) F865_6530;
	R5694[7] = (char *(*)()) F866_6530;
	R5694[8] = (char *(*)()) F867_6530;
	R5694[9] = (char *(*)()) F868_6530;
	R5694[10] = (char *(*)()) F869_6530;
	R5694[11] = (char *(*)()) F870_6530;
}

char *(*R5696[12])();
void R5696_init () {
	R5696[0] = (char *(*)()) F859_6532;
	R5696[1] = (char *(*)()) F860_6532;
	R5696[2] = (char *(*)()) F861_6532;
	R5696[3] = (char *(*)()) F862_6532;
	R5696[4] = (char *(*)()) F863_6532;
	R5696[5] = (char *(*)()) F864_6532;
	R5696[6] = (char *(*)()) F865_6532;
	R5696[7] = (char *(*)()) F866_6532;
	R5696[8] = (char *(*)()) F867_6532;
	R5696[9] = (char *(*)()) F868_6532;
	R5696[10] = (char *(*)()) F869_6532;
	R5696[11] = (char *(*)()) F870_6532;
}

char *(*R5703[12])();
void R5703_init () {
	R5703[0] = (char *(*)()) F859_6540;
	R5703[1] = (char *(*)()) F860_6540;
	R5703[2] = (char *(*)()) F861_6540;
	R5703[3] = (char *(*)()) F862_6540;
	R5703[4] = (char *(*)()) F863_6540;
	R5703[5] = (char *(*)()) F864_6540;
	R5703[6] = (char *(*)()) F865_6540;
	R5703[7] = (char *(*)()) F866_6540;
	R5703[8] = (char *(*)()) F867_6540;
	R5703[9] = (char *(*)()) F868_6540;
	R5703[10] = (char *(*)()) F869_6540;
	R5703[11] = (char *(*)()) F870_6540;
}

char *(*R5750[26])();
void R5750_init () {
	R5750[0] = (char *(*)()) F988_8101_5750_1;
	R5750[1] = (char *(*)()) F989_8101_5750_1;
	R5750[3] = (char *(*)()) F991_8167_5750_1;
	R5750[4] = (char *(*)()) F992_8167_5750_1;
	R5750[15] = (char *(*)()) F1003_8363_5750_1;
	R5750[16] = (char *(*)()) F1004_8363_5750_1;
	R5750[18] = (char *(*)()) F1006_8462_5750_1;
	R5750[19] = (char *(*)()) F1007_8462_5750_1;
	R5750[21] = (char *(*)()) F1009_8561_5750_1;
	R5750[22] = (char *(*)()) F1010_8561_5750_1;
	R5750[24] = (char *(*)()) F1012_8660_5750_1;
	R5750[25] = (char *(*)()) F1013_8660_5750_1;
}
static EIF_REFERENCE F988_8101_5750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F988_8101(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(988, 0x00).id, 988, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F989_8101_5750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F989_8101(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(988, 0x00).id, 988, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F991_8167_5750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F991_8167(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F992_8167_5750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F992_8167(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1003_8363_5750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1003_8363(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1003, 0x00).id, 1003, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1004_8363_5750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1004_8363(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1003, 0x00).id, 1003, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1006_8462_5750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1006_8462(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1007_8462_5750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1007_8462(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1009_8561_5750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1009_8561(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1009, 0x00).id, 1009, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1010_8561_5750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1010_8561(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1009, 0x00).id, 1009, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1012_8660_5750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1012_8660(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1012, 0x00).id, 1012, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1013_8660_5750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1013_8660(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1012, 0x00).id, 1012, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}

char *(*R6020[468])();
void R6020_init () {
	{long i; for (i = 0; i < 2; i++) R6020[i] = (char *(*)()) F929_7001;}
	R6020[467] = (char *(*)()) F1397_13905;
}

char *(*R6033[468])();
void R6033_init () {
	{long i; for (i = 0; i < 2; i++) R6033[i] = (char *(*)()) F929_7075;}
	R6033[467] = (char *(*)()) F1397_13928;
}

char *(*R6035[468])();
void R6035_init () {
	{long i; for (i = 0; i < 2; i++) R6035[i] = (char *(*)()) F929_7078;}
	R6035[467] = (char *(*)()) F1397_13926;
}

char *(*R6063[468])();
void R6063_init () {
	{long i; for (i = 0; i < 2; i++) R6063[i] = (char *(*)()) F929_7108;}
	R6063[467] = (char *(*)()) F1397_13923;
}

char *(*R6065[468])();
void R6065_init () {
	R6065[0] = (char *(*)()) F930_7215;
	R6065[1] = (char *(*)()) F931_7273;
	R6065[467] = (char *(*)()) F931_7273;
}

char *(*R6071[468])();
void R6071_init () {
	R6071[0] = (char *(*)()) F930_7221;
	R6071[1] = (char *(*)()) F931_7282;
	R6071[467] = (char *(*)()) F931_7282;
}

char *(*R6076[468])();
void R6076_init () {
	{long i; for (i = 0; i < 2; i++) R6076[i] = (char *(*)()) F929_7115;}
	R6076[467] = (char *(*)()) F1397_13917;
}

char *(*R6079[468])();
void R6079_init () {
	{long i; for (i = 0; i < 2; i++) R6079[i] = (char *(*)()) F929_7112;}
	R6079[467] = (char *(*)()) F1397_13914;
}

char *(*R6114[468])();
void R6114_init () {
	{long i; for (i = 0; i < 2; i++) R6114[i] = (char *(*)()) F929_7000;}
	R6114[467] = (char *(*)()) F1397_13904;
}

char *(*R6183[468])();
void R6183_init () {
	R6183[0] = (char *(*)()) F930_7241;
	R6183[1] = (char *(*)()) F929_7124;
	R6183[467] = (char *(*)()) F929_7124;
}

char *(*R6184[468])();
void R6184_init () {
	{long i; for (i = 0; i < 2; i++) R6184[i] = (char *(*)()) F929_7125;}
	R6184[467] = (char *(*)()) F1397_13960;
}

char *(*R6267[467])();
void R6267_init () {
	R6267[0] = (char *(*)()) F931_7293;
	R6267[466] = (char *(*)()) F1397_13902;
}


#ifdef __cplusplus
}
#endif
