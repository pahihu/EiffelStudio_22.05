#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O3365[1221];
void O3365_init () {
	O3365[0] =  + _REFACS_8_;
	{long i; for (i = 1107; i < 1109; i++) O3365[i] =  + _REFACS_17_;}
	{long i; for (i = 1109; i < 1112; i++) O3365[i] =  + _REFACS_18_;}
	O3365[1112] =  + _REFACS_19_;
	{long i; for (i = 1113; i < 1115; i++) O3365[i] =  + _REFACS_18_;}
	O3365[1115] =  + _REFACS_19_;
	O3365[1116] =  + _REFACS_18_;
	{long i; for (i = 1117; i < 1127; i++) O3365[i] =  + _REFACS_19_;}
	{long i; for (i = 1127; i < 1129; i++) O3365[i] =  + _REFACS_23_;}
	{long i; for (i = 1129; i < 1131; i++) O3365[i] =  + _REFACS_26_;}
	{long i; for (i = 1131; i < 1135; i++) O3365[i] =  + _REFACS_19_;}
	{long i; for (i = 1135; i < 1137; i++) O3365[i] =  + _REFACS_23_;}
	{long i; for (i = 1137; i < 1139; i++) O3365[i] =  + _REFACS_26_;}
	O3365[1139] =  + _REFACS_17_;
	O3365[1140] =  + _REFACS_21_;
	O3365[1141] =  + _REFACS_19_;
	O3365[1142] =  + _REFACS_18_;
	O3365[1143] =  + _REFACS_17_;
	{long i; for (i = 1144; i < 1147; i++) O3365[i] =  + _REFACS_18_;}
	{long i; for (i = 1147; i < 1149; i++) O3365[i] =  + _REFACS_19_;}
	{long i; for (i = 1149; i < 1151; i++) O3365[i] =  + _REFACS_18_;}
	O3365[1151] =  + _REFACS_21_;
	O3365[1152] =  + _REFACS_19_;
	O3365[1153] =  + _REFACS_23_;
	O3365[1154] =  + _REFACS_19_;
	{long i; for (i = 1155; i < 1158; i++) O3365[i] =  + _REFACS_17_;}
	{long i; for (i = 1158; i < 1162; i++) O3365[i] =  + _REFACS_18_;}
	O3365[1162] =  + _REFACS_17_;
	O3365[1163] =  + _REFACS_18_;
	O3365[1164] =  + _REFACS_21_;
	O3365[1165] =  + _REFACS_19_;
	O3365[1166] =  + _REFACS_17_;
	{long i; for (i = 1167; i < 1170; i++) O3365[i] =  + _REFACS_18_;}
	{long i; for (i = 1170; i < 1172; i++) O3365[i] =  + _REFACS_19_;}
	{long i; for (i = 1172; i < 1175; i++) O3365[i] =  + _REFACS_17_;}
	{long i; for (i = 1175; i < 1177; i++) O3365[i] =  + _REFACS_18_;}
	O3365[1177] =  + _REFACS_21_;
	O3365[1178] =  + _REFACS_19_;
	O3365[1179] =  + _REFACS_23_;
	O3365[1180] =  + _REFACS_19_;
	{long i; for (i = 1181; i < 1185; i++) O3365[i] =  + _REFACS_18_;}
	O3365[1212] =  + _REFACS_17_;
	O3365[1215] =  + _REFACS_17_;
	O3365[1217] =  + _REFACS_17_;
	O3365[1220] =  + _REFACS_17_;
}

long O3367[1221];
void O3367_init () {
	O3367[0] =  + _REFACS_9_;
	{long i; for (i = 1107; i < 1109; i++) O3367[i] =  + _REFACS_18_;}
	{long i; for (i = 1109; i < 1112; i++) O3367[i] =  + _REFACS_19_;}
	O3367[1112] =  + _REFACS_20_;
	{long i; for (i = 1113; i < 1115; i++) O3367[i] =  + _REFACS_19_;}
	O3367[1115] =  + _REFACS_20_;
	O3367[1116] =  + _REFACS_19_;
	{long i; for (i = 1117; i < 1127; i++) O3367[i] =  + _REFACS_20_;}
	{long i; for (i = 1127; i < 1129; i++) O3367[i] =  + _REFACS_24_;}
	{long i; for (i = 1129; i < 1131; i++) O3367[i] =  + _REFACS_27_;}
	{long i; for (i = 1131; i < 1135; i++) O3367[i] =  + _REFACS_20_;}
	{long i; for (i = 1135; i < 1137; i++) O3367[i] =  + _REFACS_24_;}
	{long i; for (i = 1137; i < 1139; i++) O3367[i] =  + _REFACS_27_;}
	O3367[1139] =  + _REFACS_18_;
	O3367[1140] =  + _REFACS_22_;
	O3367[1141] =  + _REFACS_20_;
	O3367[1142] =  + _REFACS_19_;
	O3367[1143] =  + _REFACS_18_;
	{long i; for (i = 1144; i < 1147; i++) O3367[i] =  + _REFACS_19_;}
	{long i; for (i = 1147; i < 1149; i++) O3367[i] =  + _REFACS_20_;}
	{long i; for (i = 1149; i < 1151; i++) O3367[i] =  + _REFACS_19_;}
	O3367[1151] =  + _REFACS_22_;
	O3367[1152] =  + _REFACS_20_;
	O3367[1153] =  + _REFACS_24_;
	O3367[1154] =  + _REFACS_20_;
	{long i; for (i = 1155; i < 1158; i++) O3367[i] =  + _REFACS_18_;}
	{long i; for (i = 1158; i < 1162; i++) O3367[i] =  + _REFACS_19_;}
	O3367[1162] =  + _REFACS_18_;
	O3367[1163] =  + _REFACS_19_;
	O3367[1164] =  + _REFACS_22_;
	O3367[1165] =  + _REFACS_20_;
	O3367[1166] =  + _REFACS_18_;
	{long i; for (i = 1167; i < 1170; i++) O3367[i] =  + _REFACS_19_;}
	{long i; for (i = 1170; i < 1172; i++) O3367[i] =  + _REFACS_20_;}
	{long i; for (i = 1172; i < 1175; i++) O3367[i] =  + _REFACS_18_;}
	{long i; for (i = 1175; i < 1177; i++) O3367[i] =  + _REFACS_19_;}
	O3367[1177] =  + _REFACS_22_;
	O3367[1178] =  + _REFACS_20_;
	O3367[1179] =  + _REFACS_24_;
	O3367[1180] =  + _REFACS_20_;
	{long i; for (i = 1181; i < 1185; i++) O3367[i] =  + _REFACS_19_;}
	O3367[1212] =  + _REFACS_18_;
	O3367[1215] =  + _REFACS_18_;
	O3367[1217] =  + _REFACS_18_;
	O3367[1220] =  + _REFACS_18_;
}

long O3369[1221];
void O3369_init () {
	O3369[0] =  + _REFACS_10_;
	{long i; for (i = 1107; i < 1109; i++) O3369[i] =  + _REFACS_19_;}
	{long i; for (i = 1109; i < 1112; i++) O3369[i] =  + _REFACS_20_;}
	O3369[1112] =  + _REFACS_21_;
	{long i; for (i = 1113; i < 1115; i++) O3369[i] =  + _REFACS_20_;}
	O3369[1115] =  + _REFACS_21_;
	O3369[1116] =  + _REFACS_20_;
	{long i; for (i = 1117; i < 1127; i++) O3369[i] =  + _REFACS_21_;}
	{long i; for (i = 1127; i < 1129; i++) O3369[i] =  + _REFACS_25_;}
	{long i; for (i = 1129; i < 1131; i++) O3369[i] =  + _REFACS_28_;}
	{long i; for (i = 1131; i < 1135; i++) O3369[i] =  + _REFACS_21_;}
	{long i; for (i = 1135; i < 1137; i++) O3369[i] =  + _REFACS_25_;}
	{long i; for (i = 1137; i < 1139; i++) O3369[i] =  + _REFACS_28_;}
	O3369[1139] =  + _REFACS_19_;
	O3369[1140] =  + _REFACS_23_;
	O3369[1141] =  + _REFACS_21_;
	O3369[1142] =  + _REFACS_20_;
	O3369[1143] =  + _REFACS_19_;
	{long i; for (i = 1144; i < 1147; i++) O3369[i] =  + _REFACS_20_;}
	{long i; for (i = 1147; i < 1149; i++) O3369[i] =  + _REFACS_21_;}
	{long i; for (i = 1149; i < 1151; i++) O3369[i] =  + _REFACS_20_;}
	O3369[1151] =  + _REFACS_23_;
	O3369[1152] =  + _REFACS_21_;
	O3369[1153] =  + _REFACS_25_;
	O3369[1154] =  + _REFACS_21_;
	{long i; for (i = 1155; i < 1158; i++) O3369[i] =  + _REFACS_19_;}
	{long i; for (i = 1158; i < 1162; i++) O3369[i] =  + _REFACS_20_;}
	O3369[1162] =  + _REFACS_19_;
	O3369[1163] =  + _REFACS_20_;
	O3369[1164] =  + _REFACS_23_;
	O3369[1165] =  + _REFACS_21_;
	O3369[1166] =  + _REFACS_19_;
	{long i; for (i = 1167; i < 1170; i++) O3369[i] =  + _REFACS_20_;}
	{long i; for (i = 1170; i < 1172; i++) O3369[i] =  + _REFACS_21_;}
	{long i; for (i = 1172; i < 1175; i++) O3369[i] =  + _REFACS_19_;}
	{long i; for (i = 1175; i < 1177; i++) O3369[i] =  + _REFACS_20_;}
	O3369[1177] =  + _REFACS_23_;
	O3369[1178] =  + _REFACS_21_;
	O3369[1179] =  + _REFACS_25_;
	O3369[1180] =  + _REFACS_21_;
	{long i; for (i = 1181; i < 1185; i++) O3369[i] =  + _REFACS_20_;}
	O3369[1212] =  + _REFACS_19_;
	O3369[1215] =  + _REFACS_19_;
	O3369[1217] =  + _REFACS_19_;
	O3369[1220] =  + _REFACS_19_;
}

long O3371[1221];
void O3371_init () {
	O3371[0] =  + _REFACS_11_;
	{long i; for (i = 1107; i < 1109; i++) O3371[i] =  + _REFACS_20_;}
	{long i; for (i = 1109; i < 1112; i++) O3371[i] =  + _REFACS_21_;}
	O3371[1112] =  + _REFACS_22_;
	{long i; for (i = 1113; i < 1115; i++) O3371[i] =  + _REFACS_21_;}
	O3371[1115] =  + _REFACS_22_;
	O3371[1116] =  + _REFACS_21_;
	{long i; for (i = 1117; i < 1127; i++) O3371[i] =  + _REFACS_22_;}
	{long i; for (i = 1127; i < 1129; i++) O3371[i] =  + _REFACS_26_;}
	{long i; for (i = 1129; i < 1131; i++) O3371[i] =  + _REFACS_29_;}
	{long i; for (i = 1131; i < 1135; i++) O3371[i] =  + _REFACS_22_;}
	{long i; for (i = 1135; i < 1137; i++) O3371[i] =  + _REFACS_26_;}
	{long i; for (i = 1137; i < 1139; i++) O3371[i] =  + _REFACS_29_;}
	O3371[1139] =  + _REFACS_20_;
	O3371[1140] =  + _REFACS_24_;
	O3371[1141] =  + _REFACS_22_;
	O3371[1142] =  + _REFACS_21_;
	O3371[1143] =  + _REFACS_20_;
	{long i; for (i = 1144; i < 1147; i++) O3371[i] =  + _REFACS_21_;}
	{long i; for (i = 1147; i < 1149; i++) O3371[i] =  + _REFACS_22_;}
	{long i; for (i = 1149; i < 1151; i++) O3371[i] =  + _REFACS_21_;}
	O3371[1151] =  + _REFACS_24_;
	O3371[1152] =  + _REFACS_22_;
	O3371[1153] =  + _REFACS_26_;
	O3371[1154] =  + _REFACS_22_;
	{long i; for (i = 1155; i < 1158; i++) O3371[i] =  + _REFACS_20_;}
	{long i; for (i = 1158; i < 1162; i++) O3371[i] =  + _REFACS_21_;}
	O3371[1162] =  + _REFACS_20_;
	O3371[1163] =  + _REFACS_21_;
	O3371[1164] =  + _REFACS_24_;
	O3371[1165] =  + _REFACS_22_;
	O3371[1166] =  + _REFACS_20_;
	{long i; for (i = 1167; i < 1170; i++) O3371[i] =  + _REFACS_21_;}
	{long i; for (i = 1170; i < 1172; i++) O3371[i] =  + _REFACS_22_;}
	{long i; for (i = 1172; i < 1175; i++) O3371[i] =  + _REFACS_20_;}
	{long i; for (i = 1175; i < 1177; i++) O3371[i] =  + _REFACS_21_;}
	O3371[1177] =  + _REFACS_24_;
	O3371[1178] =  + _REFACS_22_;
	O3371[1179] =  + _REFACS_26_;
	O3371[1180] =  + _REFACS_22_;
	{long i; for (i = 1181; i < 1185; i++) O3371[i] =  + _REFACS_21_;}
	O3371[1212] =  + _REFACS_20_;
	O3371[1215] =  + _REFACS_20_;
	O3371[1217] =  + _REFACS_20_;
	O3371[1220] =  + _REFACS_20_;
}

long O3373[1221];
void O3373_init () {
	O3373[0] =  + _REFACS_12_;
	{long i; for (i = 1107; i < 1109; i++) O3373[i] =  + _REFACS_21_;}
	{long i; for (i = 1109; i < 1112; i++) O3373[i] =  + _REFACS_22_;}
	O3373[1112] =  + _REFACS_23_;
	{long i; for (i = 1113; i < 1115; i++) O3373[i] =  + _REFACS_22_;}
	O3373[1115] =  + _REFACS_23_;
	O3373[1116] =  + _REFACS_22_;
	{long i; for (i = 1117; i < 1127; i++) O3373[i] =  + _REFACS_23_;}
	{long i; for (i = 1127; i < 1129; i++) O3373[i] =  + _REFACS_27_;}
	{long i; for (i = 1129; i < 1131; i++) O3373[i] =  + _REFACS_30_;}
	{long i; for (i = 1131; i < 1135; i++) O3373[i] =  + _REFACS_23_;}
	{long i; for (i = 1135; i < 1137; i++) O3373[i] =  + _REFACS_27_;}
	{long i; for (i = 1137; i < 1139; i++) O3373[i] =  + _REFACS_30_;}
	O3373[1139] =  + _REFACS_21_;
	O3373[1140] =  + _REFACS_25_;
	O3373[1141] =  + _REFACS_23_;
	O3373[1142] =  + _REFACS_22_;
	O3373[1143] =  + _REFACS_21_;
	{long i; for (i = 1144; i < 1147; i++) O3373[i] =  + _REFACS_22_;}
	{long i; for (i = 1147; i < 1149; i++) O3373[i] =  + _REFACS_23_;}
	{long i; for (i = 1149; i < 1151; i++) O3373[i] =  + _REFACS_22_;}
	O3373[1151] =  + _REFACS_25_;
	O3373[1152] =  + _REFACS_23_;
	O3373[1153] =  + _REFACS_27_;
	O3373[1154] =  + _REFACS_23_;
	{long i; for (i = 1155; i < 1158; i++) O3373[i] =  + _REFACS_21_;}
	{long i; for (i = 1158; i < 1162; i++) O3373[i] =  + _REFACS_22_;}
	O3373[1162] =  + _REFACS_21_;
	O3373[1163] =  + _REFACS_22_;
	O3373[1164] =  + _REFACS_25_;
	O3373[1165] =  + _REFACS_23_;
	O3373[1166] =  + _REFACS_21_;
	{long i; for (i = 1167; i < 1170; i++) O3373[i] =  + _REFACS_22_;}
	{long i; for (i = 1170; i < 1172; i++) O3373[i] =  + _REFACS_23_;}
	{long i; for (i = 1172; i < 1175; i++) O3373[i] =  + _REFACS_21_;}
	{long i; for (i = 1175; i < 1177; i++) O3373[i] =  + _REFACS_22_;}
	O3373[1177] =  + _REFACS_25_;
	O3373[1178] =  + _REFACS_23_;
	O3373[1179] =  + _REFACS_27_;
	O3373[1180] =  + _REFACS_23_;
	{long i; for (i = 1181; i < 1185; i++) O3373[i] =  + _REFACS_22_;}
	O3373[1212] =  + _REFACS_21_;
	O3373[1215] =  + _REFACS_21_;
	O3373[1217] =  + _REFACS_21_;
	O3373[1220] =  + _REFACS_21_;
}

long O3376[1221];
void O3376_init () {
	O3376[0] =  + _REFACS_13_;
	{long i; for (i = 1107; i < 1109; i++) O3376[i] =  + _REFACS_22_;}
	{long i; for (i = 1109; i < 1112; i++) O3376[i] =  + _REFACS_23_;}
	O3376[1112] =  + _REFACS_24_;
	{long i; for (i = 1113; i < 1115; i++) O3376[i] =  + _REFACS_23_;}
	O3376[1115] =  + _REFACS_24_;
	O3376[1116] =  + _REFACS_23_;
	{long i; for (i = 1117; i < 1127; i++) O3376[i] =  + _REFACS_24_;}
	{long i; for (i = 1127; i < 1129; i++) O3376[i] =  + _REFACS_28_;}
	{long i; for (i = 1129; i < 1131; i++) O3376[i] =  + _REFACS_31_;}
	{long i; for (i = 1131; i < 1135; i++) O3376[i] =  + _REFACS_24_;}
	{long i; for (i = 1135; i < 1137; i++) O3376[i] =  + _REFACS_28_;}
	{long i; for (i = 1137; i < 1139; i++) O3376[i] =  + _REFACS_31_;}
	O3376[1139] =  + _REFACS_22_;
	O3376[1140] =  + _REFACS_26_;
	O3376[1141] =  + _REFACS_24_;
	O3376[1142] =  + _REFACS_23_;
	O3376[1143] =  + _REFACS_22_;
	{long i; for (i = 1144; i < 1147; i++) O3376[i] =  + _REFACS_23_;}
	{long i; for (i = 1147; i < 1149; i++) O3376[i] =  + _REFACS_24_;}
	{long i; for (i = 1149; i < 1151; i++) O3376[i] =  + _REFACS_23_;}
	O3376[1151] =  + _REFACS_26_;
	O3376[1152] =  + _REFACS_24_;
	O3376[1153] =  + _REFACS_28_;
	O3376[1154] =  + _REFACS_24_;
	{long i; for (i = 1155; i < 1158; i++) O3376[i] =  + _REFACS_22_;}
	{long i; for (i = 1158; i < 1162; i++) O3376[i] =  + _REFACS_23_;}
	O3376[1162] =  + _REFACS_22_;
	O3376[1163] =  + _REFACS_23_;
	O3376[1164] =  + _REFACS_26_;
	O3376[1165] =  + _REFACS_24_;
	O3376[1166] =  + _REFACS_22_;
	{long i; for (i = 1167; i < 1170; i++) O3376[i] =  + _REFACS_23_;}
	{long i; for (i = 1170; i < 1172; i++) O3376[i] =  + _REFACS_24_;}
	{long i; for (i = 1172; i < 1175; i++) O3376[i] =  + _REFACS_22_;}
	{long i; for (i = 1175; i < 1177; i++) O3376[i] =  + _REFACS_23_;}
	O3376[1177] =  + _REFACS_26_;
	O3376[1178] =  + _REFACS_24_;
	O3376[1179] =  + _REFACS_28_;
	O3376[1180] =  + _REFACS_24_;
	{long i; for (i = 1181; i < 1185; i++) O3376[i] =  + _REFACS_23_;}
	O3376[1212] =  + _REFACS_22_;
	O3376[1215] =  + _REFACS_22_;
	O3376[1217] =  + _REFACS_22_;
	O3376[1220] =  + _REFACS_22_;
}

long O3429[1244];
void O3429_init () {
	O3429[0] = + _R64OFF_0_0_0_1_0_0_0_0_;
	{long i; for (i = 1239; i < 1241; i++) O3429[i] = + _R64OFF_0_0_0_1_0_0_0_0_;}
	O3429[1241] = + _R64OFF_0_0_0_2_0_0_0_0_;
	O3429[1242] = + _R64OFF_5_1_0_8_0_0_0_0_;
	O3429[1243] = + _R64OFF_2_0_0_2_0_0_0_0_;
}

long O3430[1244];
void O3430_init () {
	O3430[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 1239; i < 1242; i++) O3430[i] = + _LNGOFF_0_0_0_0_;}
	O3430[1242] = + _LNGOFF_5_1_0_0_;
	O3430[1243] = + _LNGOFF_2_0_0_0_;
}

EIF_TYPE_INDEX *Y3462_gen_type [1241];
EIF_TYPE_INDEX Y3462 [1241];
void Y3462_init (void)
{
	egc_routines_types [3462] = Y3462;
	egc_routines_gen_types [3462] = Y3462_gen_type;
	egc_routines_offset [3462] = 179;
	Y3462[0] = 176;
	Y3462[1240] = 1416;
}


#ifdef __cplusplus
}
#endif
