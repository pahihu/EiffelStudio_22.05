#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

EIF_TYPE_INDEX *Y3463_gen_type [1241];
EIF_TYPE_INDEX Y3463 [1241];
void Y3463_init (void)
{
	egc_routines_types [3463] = Y3463;
	egc_routines_gen_types [3463] = Y3463_gen_type;
	egc_routines_offset [3463] = 179;
	Y3463[0] = 678;
	Y3463[1240] = 1414;
}

long O3537[3];
void O3537_init () {
	O3537[0] = + _LNGOFF_1_0_0_0_;
	O3537[1] = + _LNGOFF_2_0_0_0_;
	O3537[2] = + _LNGOFF_1_0_0_0_;
}

long O3541[3];
void O3541_init () {
	O3541[0] = + _LNGOFF_1_0_0_1_;
	O3541[1] = + _LNGOFF_2_0_0_1_;
	O3541[2] = + _LNGOFF_1_0_0_1_;
}

long O3650[4];
void O3650_init () {
	O3650[0] = + _CHROFF_2_0_;
	O3650[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O3650[i] = + _CHROFF_2_0_;}
}

long O3651[4];
void O3651_init () {
	O3651[0] = + _CHROFF_2_1_;
	O3651[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O3651[i] = + _CHROFF_2_1_;}
}

long O3731[162];
void O3731_init () {
	O3731[0] = 0;
	O3731[1] = + _LNGOFF_0_0_0_0_;
	O3731[2] = + _CHROFF_0_0_;
	O3731[3] = + _LNGOFF_0_0_0_0_;
	O3731[4] = + _I64OFF_0_0_0_0_0_0_0_;
	O3731[5] = 0;
	O3731[6] = + _LNGOFF_1_0_0_0_;
	O3731[7] = + _CHROFF_1_0_;
	O3731[8] = 0;
	{long i; for (i = 160; i < 162; i++) O3731[i] = 0;}
}

long O3735[4];
void O3735_init () {
	O3735[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O3735[i] = 0;}
	O3735[3] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y4606_pgtype0[] = {858,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype1[] = {859,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype2[] = {860,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype3[] = {861,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype4[] = {862,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype5[] = {863,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype6[] = {864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype7[] = {865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype8[] = {866,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype9[] = {867,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype10[] = {868,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype11[] = {869,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype12[] = {858,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype13[] = {859,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype14[] = {860,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype15[] = {861,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype16[] = {862,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype17[] = {863,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype18[] = {864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype19[] = {865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype20[] = {866,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype21[] = {867,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype22[] = {868,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype23[] = {869,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype24[] = {860,985,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype25[] = {860,985,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype26[] = {860,985,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype27[] = {858,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype28[] = {859,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype29[] = {860,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype30[] = {861,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype31[] = {862,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype32[] = {863,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype33[] = {864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype34[] = {865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype35[] = {866,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype36[] = {867,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype37[] = {868,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype38[] = {869,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype39[] = {858,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype40[] = {862,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype41[] = {866,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype42[] = {858,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype43[] = {862,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype44[] = {858,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype45[] = {862,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype46[] = {858,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype47[] = {862,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype48[] = {858,1097,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype49[] = {858,1047,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype50[] = {858,1047,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype51[] = {858,1047,0xFFF9,1,973,0,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype52[] = {858,1047,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype53[] = {858,1047,0xFFF9,1,973,1006,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype54[] = {858,1047,0xFFF9,1,973,1177,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype55[] = {858,1047,0xFFF9,1,973,1006,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype56[] = {858,1047,0xFFF9,1,973,1182,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype57[] = {858,1047,0xFFF9,1,973,1135,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype58[] = {858,1047,0xFFF9,1,973,935,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype59[] = {858,1047,0xFFF9,1,973,1110,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype60[] = {858,1047,0xFFF9,1,973,1394,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype61[] = {858,1047,0xFFF9,1,973,1006,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype62[] = {858,1047,0xFFF9,5,973,979,1006,1006,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype63[] = {858,1047,0xFFF9,1,973,1062,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype64[] = {858,1047,0xFFF9,7,973,1006,1006,991,991,991,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype65[] = {858,1047,0xFFF9,2,973,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype66[] = {858,1047,0xFFF9,3,973,1006,1006,935,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype67[] = {858,1047,0xFFF9,8,973,1006,1006,1006,991,991,991,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype68[] = {858,1047,0xFFF9,0,973,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype69[] = {858,1047,0xFFF9,4,973,1006,1006,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype70[] = {864,997,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype71[] = {864,997,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype72[] = {863,994,0xFFFF};
static EIF_TYPE_INDEX Y4606_pgtype73[] = {858,1062,0xFFFF};
EIF_TYPE_INDEX *Y4606_gen_type [872];
EIF_TYPE_INDEX Y4606 [872];
void Y4606_init (void)
{
	egc_routines_types [4606] = Y4606;
	egc_routines_gen_types [4606] = Y4606_gen_type;
	egc_routines_offset [4606] = 306;
	Y4606_gen_type [0] = Y4606_pgtype0;
	Y4606_gen_type [1] = Y4606_pgtype1;
	Y4606_gen_type [2] = Y4606_pgtype2;
	Y4606_gen_type [3] = Y4606_pgtype3;
	Y4606_gen_type [4] = Y4606_pgtype4;
	Y4606_gen_type [5] = Y4606_pgtype5;
	Y4606_gen_type [6] = Y4606_pgtype6;
	Y4606_gen_type [7] = Y4606_pgtype7;
	Y4606_gen_type [8] = Y4606_pgtype8;
	Y4606_gen_type [9] = Y4606_pgtype9;
	Y4606_gen_type [10] = Y4606_pgtype10;
	Y4606_gen_type [11] = Y4606_pgtype11;
	Y4606_gen_type [294] = Y4606_pgtype12;
	Y4606_gen_type [295] = Y4606_pgtype13;
	Y4606_gen_type [296] = Y4606_pgtype14;
	Y4606_gen_type [297] = Y4606_pgtype15;
	Y4606_gen_type [298] = Y4606_pgtype16;
	Y4606_gen_type [299] = Y4606_pgtype17;
	Y4606_gen_type [300] = Y4606_pgtype18;
	Y4606_gen_type [301] = Y4606_pgtype19;
	Y4606_gen_type [302] = Y4606_pgtype20;
	Y4606_gen_type [303] = Y4606_pgtype21;
	Y4606_gen_type [304] = Y4606_pgtype22;
	Y4606_gen_type [305] = Y4606_pgtype23;
	Y4606_gen_type [306] = Y4606_pgtype24;
	Y4606_gen_type [365] = Y4606_pgtype25;
	Y4606_gen_type [366] = Y4606_pgtype26;
	Y4606_gen_type [382] = Y4606_pgtype27;
	Y4606_gen_type [383] = Y4606_pgtype28;
	Y4606_gen_type [384] = Y4606_pgtype29;
	Y4606_gen_type [385] = Y4606_pgtype30;
	Y4606_gen_type [386] = Y4606_pgtype31;
	Y4606_gen_type [387] = Y4606_pgtype32;
	Y4606_gen_type [388] = Y4606_pgtype33;
	Y4606_gen_type [389] = Y4606_pgtype34;
	Y4606_gen_type [390] = Y4606_pgtype35;
	Y4606_gen_type [391] = Y4606_pgtype36;
	Y4606_gen_type [392] = Y4606_pgtype37;
	Y4606_gen_type [393] = Y4606_pgtype38;
	Y4606_gen_type [394] = Y4606_pgtype39;
	Y4606_gen_type [395] = Y4606_pgtype40;
	Y4606_gen_type [396] = Y4606_pgtype41;
	Y4606_gen_type [397] = Y4606_pgtype42;
	Y4606_gen_type [398] = Y4606_pgtype43;
	Y4606_gen_type [399] = Y4606_pgtype44;
	Y4606_gen_type [400] = Y4606_pgtype45;
	Y4606_gen_type [401] = Y4606_pgtype46;
	Y4606_gen_type [402] = Y4606_pgtype47;
	Y4606_gen_type [403] = Y4606_pgtype48;
	Y4606_gen_type [404] = Y4606_pgtype49;
	Y4606_gen_type [405] = Y4606_pgtype50;
	Y4606_gen_type [406] = Y4606_pgtype51;
	Y4606_gen_type [407] = Y4606_pgtype52;
	Y4606_gen_type [408] = Y4606_pgtype53;
	Y4606_gen_type [409] = Y4606_pgtype54;
	Y4606_gen_type [410] = Y4606_pgtype55;
	Y4606_gen_type [411] = Y4606_pgtype56;
	Y4606_gen_type [412] = Y4606_pgtype57;
	Y4606_gen_type [413] = Y4606_pgtype58;
	Y4606_gen_type [414] = Y4606_pgtype59;
	Y4606_gen_type [415] = Y4606_pgtype60;
	Y4606_gen_type [416] = Y4606_pgtype61;
	Y4606_gen_type [417] = Y4606_pgtype62;
	Y4606_gen_type [418] = Y4606_pgtype63;
	Y4606_gen_type [419] = Y4606_pgtype64;
	Y4606_gen_type [420] = Y4606_pgtype65;
	Y4606_gen_type [421] = Y4606_pgtype66;
	Y4606_gen_type [422] = Y4606_pgtype67;
	Y4606_gen_type [423] = Y4606_pgtype68;
	Y4606_gen_type [424] = Y4606_pgtype69;
	Y4606_gen_type [752] = Y4606_pgtype70;
	Y4606_gen_type [753] = Y4606_pgtype71;
	Y4606_gen_type [756] = Y4606_pgtype72;
	Y4606_gen_type [871] = Y4606_pgtype73;
	Y4606[0] = 858;
	Y4606[1] = 859;
	Y4606[2] = 860;
	Y4606[3] = 861;
	Y4606[4] = 862;
	Y4606[5] = 863;
	Y4606[6] = 864;
	Y4606[7] = 865;
	Y4606[8] = 866;
	Y4606[9] = 867;
	Y4606[10] = 868;
	Y4606[11] = 869;
	Y4606[294] = 858;
	Y4606[295] = 859;
	Y4606[296] = 860;
	Y4606[297] = 861;
	Y4606[298] = 862;
	Y4606[299] = 863;
	Y4606[300] = 864;
	Y4606[301] = 865;
	Y4606[302] = 866;
	Y4606[303] = 867;
	Y4606[304] = 868;
	Y4606[305] = 869;
	Y4606[306] = 860;
	{long i; for (i = 365; i < 367; i++) Y4606[i] = 860;};
	Y4606[382] = 858;
	Y4606[383] = 859;
	Y4606[384] = 860;
	Y4606[385] = 861;
	Y4606[386] = 862;
	Y4606[387] = 863;
	Y4606[388] = 864;
	Y4606[389] = 865;
	Y4606[390] = 866;
	Y4606[391] = 867;
	Y4606[392] = 868;
	Y4606[393] = 869;
	Y4606[394] = 858;
	Y4606[395] = 862;
	Y4606[396] = 866;
	Y4606[397] = 858;
	Y4606[398] = 862;
	Y4606[399] = 858;
	Y4606[400] = 862;
	Y4606[401] = 858;
	Y4606[402] = 862;
	{long i; for (i = 403; i < 425; i++) Y4606[i] = 858;};
	{long i; for (i = 752; i < 754; i++) Y4606[i] = 864;};
	Y4606[756] = 863;
	Y4606[871] = 858;
}

long O4766[1039];
void O4766_init () {
	{long i; for (i = 0; i < 12; i++) O4766[i] = + _CHROFF_0_0_;}
	O4766[12] = + _CHROFF_1_0_;
	{long i; for (i = 13; i < 15; i++) O4766[i] = + _CHROFF_4_0_;}
	{long i; for (i = 15; i < 199; i++) O4766[i] = + _CHROFF_0_0_;}
	O4766[199] = + _CHROFF_1_0_;
	{long i; for (i = 200; i < 216; i++) O4766[i] = + _CHROFF_0_0_;}
	{long i; for (i = 228; i < 241; i++) O4766[i] = + _CHROFF_0_0_;}
	{long i; for (i = 241; i < 254; i++) O4766[i] = + _CHROFF_1_0_;}
	O4766[254] = + _CHROFF_2_0_;
	{long i; for (i = 255; i < 303; i++) O4766[i] = + _CHROFF_0_0_;}
	{long i; for (i = 303; i < 310; i++) O4766[i] = + _CHROFF_2_0_;}
	O4766[310] = + _CHROFF_4_0_;
	O4766[319] = + _CHROFF_1_0_;
	O4766[321] = + _CHROFF_7_0_;
	{long i; for (i = 322; i < 324; i++) O4766[i] = + _CHROFF_5_0_;}
	O4766[324] = + _CHROFF_6_0_;
	{long i; for (i = 325; i < 327; i++) O4766[i] = + _CHROFF_4_0_;}
	O4766[327] = + _CHROFF_7_0_;
	O4766[328] = + _CHROFF_5_0_;
	O4766[329] = + _CHROFF_9_0_;
	{long i; for (i = 330; i < 347; i++) O4766[i] = + _CHROFF_1_0_;}
	{long i; for (i = 347; i < 349; i++) O4766[i] = + _CHROFF_3_0_;}
	{long i; for (i = 349; i < 352; i++) O4766[i] = + _CHROFF_5_0_;}
	{long i; for (i = 352; i < 354; i++) O4766[i] = + _CHROFF_9_0_;}
	O4766[354] = + _CHROFF_10_0_;
	{long i; for (i = 355; i < 373; i++) O4766[i] = + _CHROFF_9_0_;}
	O4766[387] = + _CHROFF_0_0_;
	O4766[389] = + _CHROFF_2_0_;
	O4766[391] = + _CHROFF_0_0_;
	O4766[570] = + _CHROFF_3_2_;
	O4766[571] = + _CHROFF_4_2_;
	O4766[572] = + _CHROFF_5_2_;
	{long i; for (i = 700; i < 702; i++) O4766[i] = + _CHROFF_1_0_;}
	O4766[704] = + _CHROFF_1_0_;
	O4766[775] = + _CHROFF_3_0_;
	{long i; for (i = 778; i < 792; i++) O4766[i] = + _CHROFF_6_0_;}
	O4766[792] = + _CHROFF_13_1_;
	O4766[793] = + _CHROFF_6_0_;
	O4766[794] = + _CHROFF_7_0_;
	{long i; for (i = 795; i < 798; i++) O4766[i] = + _CHROFF_14_0_;}
	O4766[819] = + _CHROFF_7_0_;
	O4766[828] = + _CHROFF_3_0_;
	{long i; for (i = 829; i < 834; i++) O4766[i] = + _CHROFF_5_0_;}
	O4766[834] = + _CHROFF_3_0_;
	O4766[835] = + _CHROFF_5_0_;
	{long i; for (i = 836; i < 838; i++) O4766[i] = + _CHROFF_6_0_;}
	{long i; for (i = 838; i < 840; i++) O4766[i] = + _CHROFF_3_0_;}
	O4766[840] = + _CHROFF_6_0_;
	O4766[1038] = + _CHROFF_5_2_;
}

static EIF_TYPE_INDEX Y4834_pgtype0[] = {371,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4834_pgtype1[] = {372,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y4834_gen_type [2];
EIF_TYPE_INDEX Y4834 [2];
void Y4834_init (void)
{
	egc_routines_types [4834] = Y4834;
	egc_routines_gen_types [4834] = Y4834_gen_type;
	egc_routines_offset [4834] = 371;
	Y4834_gen_type [0] = Y4834_pgtype0;
	Y4834_gen_type [1] = Y4834_pgtype1;
	Y4834[0] = 371;
	Y4834[1] = 372;
}

long O5059[8];
void O5059_init () {
	{long i; for (i = 0; i < 7; i++) O5059[i] = + _CHROFF_2_1_;}
	O5059[7] = + _CHROFF_4_1_;
}

long O5060[8];
void O5060_init () {
	{long i; for (i = 0; i < 7; i++) O5060[i] = + _CHROFF_2_2_;}
	O5060[7] = + _CHROFF_4_2_;
}

long O5061[8];
void O5061_init () {
	{long i; for (i = 0; i < 7; i++) O5061[i] = + _LNGOFF_2_3_0_0_;}
	O5061[7] = + _LNGOFF_4_3_0_0_;
}

long O5170[549];
void O5170_init () {
	O5170[0] = + _LNGOFF_0_0_0_0_;
	O5170[1] = + _LNGOFF_8_3_0_2_;
	O5170[2] = + _LNGOFF_0_0_0_0_;
	O5170[259] = + _LNGOFF_1_0_0_0_;
	O5170[546] = + _LNGOFF_1_1_0_0_;
	O5170[548] = + _LNGOFF_49_16_0_2_;
}

EIF_TYPE_INDEX *Y5206_gen_type [1];
EIF_TYPE_INDEX Y5206 [1];
void Y5206_init (void)
{
	egc_routines_types [5206] = Y5206;
	egc_routines_gen_types [5206] = Y5206_gen_type;
	egc_routines_offset [5206] = 677;
	Y5206[0] = 1006;
}

long O5207[742];
void O5207_init () {
	O5207[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 735; i < 737; i++) O5207[i] = + _LNGOFF_0_0_0_0_;}
	O5207[739] = + _LNGOFF_0_0_0_1_;
	O5207[740] = + _LNGOFF_5_1_0_1_;
	O5207[741] = + _LNGOFF_2_0_0_1_;
}

long O5221[9];
void O5221_init () {
	O5221[0] = 0;
	O5221[1] = + _LNGOFF_5_3_0_0_;
	O5221[2] = + _PTROFF_5_3_0_7_0_0_;
	O5221[3] = 0;
	O5221[4] = + _LNGOFF_4_3_0_1_;
	O5221[5] = + _LNGOFF_4_3_0_0_;
	O5221[6] = 0;
	O5221[7] = + _LNGOFF_5_4_0_0_;
	O5221[8] = 0;
}

long O5230[9];
void O5230_init () {
	O5230[0] = + _LNGOFF_7_3_0_0_;
	O5230[1] = + _LNGOFF_5_3_0_1_;
	O5230[2] = + _LNGOFF_5_3_0_0_;
	O5230[3] = + _LNGOFF_6_3_0_0_;
	O5230[4] = + _LNGOFF_4_3_0_2_;
	O5230[5] = + _LNGOFF_4_3_0_1_;
	O5230[6] = + _LNGOFF_7_4_0_0_;
	O5230[7] = + _LNGOFF_5_4_0_1_;
	O5230[8] = + _LNGOFF_9_3_0_0_;
}

long O5257[9];
void O5257_init () {
	O5257[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O5257[i] = 0;}
	O5257[3] =  + _REFACS_1_;
	{long i; for (i = 4; i < 6; i++) O5257[i] = 0;}
	O5257[6] =  + _REFACS_1_;
	O5257[7] = 0;
	O5257[8] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y5257_pgtype0[] = {858,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5257_pgtype1[] = {862,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5257_pgtype2[] = {867,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5257_pgtype3[] = {858,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5257_pgtype4[] = {862,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5257_pgtype5[] = {862,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5257_pgtype6[] = {858,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5257_pgtype7[] = {862,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5257_pgtype8[] = {858,0,0xFFFF};
EIF_TYPE_INDEX *Y5257_gen_type [9];
EIF_TYPE_INDEX Y5257 [9];
void Y5257_init (void)
{
	egc_routines_types [5257] = Y5257;
	egc_routines_gen_types [5257] = Y5257_gen_type;
	egc_routines_offset [5257] = 679;
	Y5257_gen_type [0] = Y5257_pgtype0;
	Y5257_gen_type [1] = Y5257_pgtype1;
	Y5257_gen_type [2] = Y5257_pgtype2;
	Y5257_gen_type [3] = Y5257_pgtype3;
	Y5257_gen_type [4] = Y5257_pgtype4;
	Y5257_gen_type [5] = Y5257_pgtype5;
	Y5257_gen_type [6] = Y5257_pgtype6;
	Y5257_gen_type [7] = Y5257_pgtype7;
	Y5257_gen_type [8] = Y5257_pgtype8;
	Y5257[0] = 858;
	Y5257[1] = 862;
	Y5257[2] = 867;
	Y5257[3] = 858;
	{long i; for (i = 4; i < 6; i++) Y5257[i] = 862;};
	Y5257[6] = 858;
	Y5257[7] = 862;
	Y5257[8] = 858;
}

long O5258[9];
void O5258_init () {
	O5258[0] =  + _REFACS_2_;
	{long i; for (i = 1; i < 3; i++) O5258[i] =  + _REFACS_1_;}
	O5258[3] =  + _REFACS_2_;
	{long i; for (i = 4; i < 6; i++) O5258[i] =  + _REFACS_1_;}
	O5258[6] =  + _REFACS_2_;
	O5258[7] =  + _REFACS_1_;
	O5258[8] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y5258_pgtype0[] = {858,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5258_pgtype1[] = {858,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5258_pgtype2[] = {858,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5258_pgtype3[] = {862,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5258_pgtype4[] = {861,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5258_pgtype5[] = {862,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5258_pgtype6[] = {858,1053,0xFFFF};
static EIF_TYPE_INDEX Y5258_pgtype7[] = {858,1053,0xFFFF};
static EIF_TYPE_INDEX Y5258_pgtype8[] = {858,1058,0xFFFF};
EIF_TYPE_INDEX *Y5258_gen_type [9];
EIF_TYPE_INDEX Y5258 [9];
void Y5258_init (void)
{
	egc_routines_types [5258] = Y5258;
	egc_routines_gen_types [5258] = Y5258_gen_type;
	egc_routines_offset [5258] = 679;
	Y5258_gen_type [0] = Y5258_pgtype0;
	Y5258_gen_type [1] = Y5258_pgtype1;
	Y5258_gen_type [2] = Y5258_pgtype2;
	Y5258_gen_type [3] = Y5258_pgtype3;
	Y5258_gen_type [4] = Y5258_pgtype4;
	Y5258_gen_type [5] = Y5258_pgtype5;
	Y5258_gen_type [6] = Y5258_pgtype6;
	Y5258_gen_type [7] = Y5258_pgtype7;
	Y5258_gen_type [8] = Y5258_pgtype8;
	{long i; for (i = 0; i < 3; i++) Y5258[i] = 858;};
	Y5258[3] = 862;
	Y5258[4] = 861;
	Y5258[5] = 862;
	{long i; for (i = 6; i < 9; i++) Y5258[i] = 858;};
}

long O5259[9];
void O5259_init () {
	O5259[0] =  + _REFACS_3_;
	{long i; for (i = 1; i < 3; i++) O5259[i] =  + _REFACS_2_;}
	O5259[3] =  + _REFACS_3_;
	{long i; for (i = 4; i < 6; i++) O5259[i] =  + _REFACS_2_;}
	O5259[6] =  + _REFACS_3_;
	O5259[7] =  + _REFACS_2_;
	O5259[8] =  + _REFACS_3_;
}

long O5260[9];
void O5260_init () {
	O5260[0] =  + _REFACS_4_;
	{long i; for (i = 1; i < 3; i++) O5260[i] =  + _REFACS_3_;}
	O5260[3] =  + _REFACS_4_;
	{long i; for (i = 4; i < 6; i++) O5260[i] =  + _REFACS_3_;}
	O5260[6] =  + _REFACS_4_;
	O5260[7] =  + _REFACS_3_;
	O5260[8] =  + _REFACS_4_;
}

long O5261[9];
void O5261_init () {
	O5261[0] = + _LNGOFF_7_3_0_1_;
	O5261[1] = + _LNGOFF_5_3_0_2_;
	O5261[2] = + _LNGOFF_5_3_0_1_;
	O5261[3] = + _LNGOFF_6_3_0_1_;
	O5261[4] = + _LNGOFF_4_3_0_3_;
	O5261[5] = + _LNGOFF_4_3_0_2_;
	O5261[6] = + _LNGOFF_7_4_0_1_;
	O5261[7] = + _LNGOFF_5_4_0_2_;
	O5261[8] = + _LNGOFF_9_3_0_1_;
}

long O5262[9];
void O5262_init () {
	O5262[0] = + _CHROFF_7_2_;
	{long i; for (i = 1; i < 3; i++) O5262[i] = + _CHROFF_5_2_;}
	O5262[3] = + _CHROFF_6_2_;
	{long i; for (i = 4; i < 6; i++) O5262[i] = + _CHROFF_4_2_;}
	O5262[6] = + _CHROFF_7_2_;
	O5262[7] = + _CHROFF_5_2_;
	O5262[8] = + _CHROFF_9_2_;
}

long O5263[9];
void O5263_init () {
	O5263[0] = + _LNGOFF_7_3_0_2_;
	O5263[1] = + _LNGOFF_5_3_0_3_;
	O5263[2] = + _LNGOFF_5_3_0_2_;
	O5263[3] = + _LNGOFF_6_3_0_2_;
	O5263[4] = + _LNGOFF_4_3_0_4_;
	O5263[5] = + _LNGOFF_4_3_0_3_;
	O5263[6] = + _LNGOFF_7_4_0_2_;
	O5263[7] = + _LNGOFF_5_4_0_3_;
	O5263[8] = + _LNGOFF_9_3_0_2_;
}

long O5266[9];
void O5266_init () {
	O5266[0] = + _LNGOFF_7_3_0_3_;
	O5266[1] = + _LNGOFF_5_3_0_4_;
	O5266[2] = + _LNGOFF_5_3_0_3_;
	O5266[3] = + _LNGOFF_6_3_0_3_;
	O5266[4] = + _LNGOFF_4_3_0_5_;
	O5266[5] = + _LNGOFF_4_3_0_4_;
	O5266[6] = + _LNGOFF_7_4_0_3_;
	O5266[7] = + _LNGOFF_5_4_0_4_;
	O5266[8] = + _LNGOFF_9_3_0_3_;
}

long O5267[9];
void O5267_init () {
	O5267[0] = + _LNGOFF_7_3_0_4_;
	O5267[1] = + _LNGOFF_5_3_0_5_;
	O5267[2] = + _LNGOFF_5_3_0_4_;
	O5267[3] = + _LNGOFF_6_3_0_4_;
	O5267[4] = + _LNGOFF_4_3_0_6_;
	O5267[5] = + _LNGOFF_4_3_0_5_;
	O5267[6] = + _LNGOFF_7_4_0_4_;
	O5267[7] = + _LNGOFF_5_4_0_5_;
	O5267[8] = + _LNGOFF_9_3_0_4_;
}

long O5271[9];
void O5271_init () {
	O5271[0] = + _LNGOFF_7_3_0_5_;
	O5271[1] = + _LNGOFF_5_3_0_6_;
	O5271[2] = + _LNGOFF_5_3_0_5_;
	O5271[3] = + _LNGOFF_6_3_0_5_;
	O5271[4] = + _LNGOFF_4_3_0_7_;
	O5271[5] = + _LNGOFF_4_3_0_6_;
	O5271[6] = + _LNGOFF_7_4_0_5_;
	O5271[7] = + _LNGOFF_5_4_0_6_;
	O5271[8] = + _LNGOFF_9_3_0_5_;
}

long O5272[9];
void O5272_init () {
	O5272[0] =  + _REFACS_5_;
	O5272[1] = + _LNGOFF_5_3_0_7_;
	O5272[2] = + _PTROFF_5_3_0_7_0_1_;
	O5272[3] =  + _REFACS_5_;
	O5272[4] = + _LNGOFF_4_3_0_8_;
	O5272[5] = + _LNGOFF_4_3_0_7_;
	O5272[6] =  + _REFACS_5_;
	O5272[7] = + _LNGOFF_5_4_0_7_;
	O5272[8] =  + _REFACS_5_;
}

long O5273[9];
void O5273_init () {
	O5273[0] =  + _REFACS_6_;
	{long i; for (i = 1; i < 3; i++) O5273[i] =  + _REFACS_4_;}
	O5273[3] = + _LNGOFF_6_3_0_6_;
	O5273[4] = + _LNGOFF_4_3_0_0_;
	O5273[5] = + _LNGOFF_4_3_0_8_;
	O5273[6] =  + _REFACS_6_;
	O5273[7] =  + _REFACS_4_;
	O5273[8] =  + _REFACS_6_;
}

long O5307[9];
void O5307_init () {
	O5307[0] = + _LNGOFF_7_3_0_6_;
	O5307[1] = + _LNGOFF_5_3_0_8_;
	O5307[2] = + _LNGOFF_5_3_0_6_;
	O5307[3] = + _LNGOFF_6_3_0_7_;
	{long i; for (i = 4; i < 6; i++) O5307[i] = + _LNGOFF_4_3_0_9_;}
	O5307[6] = + _LNGOFF_7_4_0_6_;
	O5307[7] = + _LNGOFF_5_4_0_8_;
	O5307[8] = + _LNGOFF_9_3_0_6_;
}

long O5310[2];
void O5310_init () {
	O5310[0] = + _CHROFF_7_3_;
	O5310[1] = + _CHROFF_5_3_;
}

long O5335[490];
void O5335_init () {
	{long i; for (i = 0; i < 15; i++) O5335[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 15; i < 17; i++) O5335[i] = + _LNGOFF_1_2_0_0_;}
	{long i; for (i = 17; i < 19; i++) O5335[i] = + _LNGOFF_3_2_0_0_;}
	{long i; for (i = 19; i < 22; i++) O5335[i] = + _LNGOFF_5_2_0_0_;}
	{long i; for (i = 22; i < 24; i++) O5335[i] = + _LNGOFF_9_2_0_0_;}
	O5335[24] = + _LNGOFF_10_2_0_0_;
	{long i; for (i = 25; i < 43; i++) O5335[i] = + _LNGOFF_9_2_0_0_;}
	O5335[489] = + _LNGOFF_7_2_0_0_;
}

long O5343[475];
void O5343_init () {
	{long i; for (i = 0; i < 2; i++) O5343[i] = + _CHROFF_1_1_;}
	{long i; for (i = 2; i < 4; i++) O5343[i] = + _CHROFF_3_1_;}
	{long i; for (i = 4; i < 7; i++) O5343[i] = + _CHROFF_5_1_;}
	{long i; for (i = 7; i < 9; i++) O5343[i] = + _CHROFF_9_1_;}
	O5343[9] = + _CHROFF_10_1_;
	{long i; for (i = 10; i < 28; i++) O5343[i] = + _CHROFF_9_1_;}
	O5343[474] = + _CHROFF_7_1_;
}

static EIF_TYPE_INDEX Y5346_pgtype0[] = {710,0xFFF9,1,973,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype1[] = {710,0xFFF9,1,973,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype2[] = {710,0xFFF9,1,973,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype3[] = {710,0xFFF9,1,973,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype4[] = {710,0xFFF9,1,973,1097,0xFFFF};
EIF_TYPE_INDEX *Y5346_gen_type [5];
EIF_TYPE_INDEX Y5346 [5];
void Y5346_init (void)
{
	egc_routines_types [5346] = Y5346;
	egc_routines_gen_types [5346] = Y5346_gen_type;
	egc_routines_offset [5346] = 705;
	Y5346_gen_type [0] = Y5346_pgtype0;
	Y5346_gen_type [1] = Y5346_pgtype1;
	Y5346_gen_type [2] = Y5346_pgtype2;
	Y5346_gen_type [3] = Y5346_pgtype3;
	Y5346_gen_type [4] = Y5346_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y5346[i] = 710;};
}

static EIF_TYPE_INDEX Y5347_pgtype0[] = {710,0xFFF9,1,973,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype1[] = {710,0xFFF9,1,973,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype2[] = {710,0xFFF9,1,973,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype3[] = {710,0xFFF9,1,973,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype4[] = {710,0xFFF9,1,973,1097,0xFFFF};
EIF_TYPE_INDEX *Y5347_gen_type [5];
EIF_TYPE_INDEX Y5347 [5];
void Y5347_init (void)
{
	egc_routines_types [5347] = Y5347;
	egc_routines_gen_types [5347] = Y5347_gen_type;
	egc_routines_offset [5347] = 705;
	Y5347_gen_type [0] = Y5347_pgtype0;
	Y5347_gen_type [1] = Y5347_pgtype1;
	Y5347_gen_type [2] = Y5347_pgtype2;
	Y5347_gen_type [3] = Y5347_pgtype3;
	Y5347_gen_type [4] = Y5347_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y5347[i] = 710;};
}

static EIF_TYPE_INDEX Y5348_pgtype0[] = {711,0xFFF9,1,973,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5348_pgtype1[] = {711,0xFFF9,1,973,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5348_pgtype2[] = {711,0xFFF9,1,973,1097,0xFFFF};
EIF_TYPE_INDEX *Y5348_gen_type [3];
EIF_TYPE_INDEX Y5348 [3];
void Y5348_init (void)
{
	egc_routines_types [5348] = Y5348;
	egc_routines_gen_types [5348] = Y5348_gen_type;
	egc_routines_offset [5348] = 707;
	Y5348_gen_type [0] = Y5348_pgtype0;
	Y5348_gen_type [1] = Y5348_pgtype1;
	Y5348_gen_type [2] = Y5348_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y5348[i] = 711;};
}

static EIF_TYPE_INDEX Y5349_pgtype0[] = {711,0xFFF9,1,973,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5349_pgtype1[] = {711,0xFFF9,1,973,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5349_pgtype2[] = {711,0xFFF9,1,973,1097,0xFFFF};
EIF_TYPE_INDEX *Y5349_gen_type [3];
EIF_TYPE_INDEX Y5349 [3];
void Y5349_init (void)
{
	egc_routines_types [5349] = Y5349;
	egc_routines_gen_types [5349] = Y5349_gen_type;
	egc_routines_offset [5349] = 707;
	Y5349_gen_type [0] = Y5349_pgtype0;
	Y5349_gen_type [1] = Y5349_pgtype1;
	Y5349_gen_type [2] = Y5349_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y5349[i] = 711;};
}

long O5362[21];
void O5362_init () {
	{long i; for (i = 0; i < 2; i++) O5362[i] = + _LNGOFF_9_2_0_1_;}
	O5362[2] = + _LNGOFF_10_2_0_1_;
	{long i; for (i = 3; i < 21; i++) O5362[i] = + _LNGOFF_9_2_0_1_;}
}

long O5488[22];
void O5488_init () {
	{long i; for (i = 0; i < 18; i++) O5488[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 18; i < 22; i++) O5488[i] = + _LNGOFF_2_1_0_0_;}
}

long O5492[22];
void O5492_init () {
	{long i; for (i = 0; i < 18; i++) O5492[i] = + _CHROFF_1_0_;}
	{long i; for (i = 18; i < 22; i++) O5492[i] = + _CHROFF_2_0_;}
}

long O5493[22];
void O5493_init () {
	{long i; for (i = 0; i < 18; i++) O5493[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 18; i < 22; i++) O5493[i] = + _LNGOFF_2_1_0_1_;}
}

long O5494[22];
void O5494_init () {
	{long i; for (i = 0; i < 18; i++) O5494[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 18; i < 22; i++) O5494[i] = + _LNGOFF_2_1_0_2_;}
}

long O5495[22];
void O5495_init () {
	{long i; for (i = 0; i < 18; i++) O5495[i] = + _LNGOFF_1_1_0_3_;}
	{long i; for (i = 18; i < 22; i++) O5495[i] = + _LNGOFF_2_1_0_3_;}
}

long O5496[22];
void O5496_init () {
	{long i; for (i = 0; i < 18; i++) O5496[i] = + _LNGOFF_1_1_0_4_;}
	{long i; for (i = 18; i < 22; i++) O5496[i] = + _LNGOFF_2_1_0_4_;}
}

long O6003[470];
void O6003_init () {
	O6003[0] = + _CHROFF_1_0_;
	O6003[1] = + _CHROFF_3_0_;
	O6003[2] = + _CHROFF_4_0_;
	O6003[3] = + _CHROFF_5_0_;
	O6003[469] = + _CHROFF_5_0_;
}

long O6005[470];
void O6005_init () {
	O6005[0] = + _LNGOFF_1_3_2_1_;
	O6005[1] = + _LNGOFF_3_6_2_1_;
	O6005[2] = + _LNGOFF_4_6_2_1_;
	O6005[3] = + _LNGOFF_5_7_2_1_;
	O6005[469] = + _LNGOFF_5_7_2_1_;
}

long O6014[470];
void O6014_init () {
	O6014[0] = + _CHROFF_1_1_;
	O6014[1] = + _CHROFF_3_4_;
	O6014[2] = + _CHROFF_4_4_;
	O6014[3] = + _CHROFF_5_5_;
	O6014[469] = + _CHROFF_5_5_;
}

long O6102[469];
void O6102_init () {
	O6102[0] = + _PTROFF_3_6_2_4_1_0_;
	O6102[1] = + _PTROFF_4_6_2_4_1_0_;
	O6102[2] = + _PTROFF_5_7_2_4_1_0_;
	O6102[468] = + _PTROFF_5_7_2_4_1_0_;
}

long O6241[469];
void O6241_init () {
	O6241[0] = + _LNGOFF_3_6_2_3_;
	O6241[1] = + _LNGOFF_4_6_2_3_;
	O6241[2] = + _LNGOFF_5_7_2_3_;
	O6241[468] = + _LNGOFF_5_7_2_3_;
}

long O6250[469];
void O6250_init () {
	O6250[0] = + _CHROFF_3_3_;
	O6250[1] = + _CHROFF_4_3_;
	O6250[2] = + _CHROFF_5_3_;
	O6250[468] = + _CHROFF_5_3_;
}

long O6289[459];
void O6289_init () {
	O6289[0] = + _LNGOFF_0_0_0_0_;
	O6289[1] = + _LNGOFF_1_0_0_1_;
	{long i; for (i = 2; i < 4; i++) O6289[i] = + _LNGOFF_0_0_0_0_;}
	O6289[4] = + _LNGOFF_2_0_0_0_;
	O6289[5] = + _LNGOFF_0_1_0_0_;
	O6289[184] = + _LNGOFF_2_0_0_0_;
	O6289[200] = + _LNGOFF_4_0_0_0_;
	O6289[204] = + _LNGOFF_5_2_0_0_;
	{long i; for (i = 205; i < 217; i++) O6289[i] = + _LNGOFF_6_3_0_0_;}
	O6289[217] = + _LNGOFF_6_4_0_0_;
	O6289[218] = + _LNGOFF_6_3_0_0_;
	O6289[219] = + _LNGOFF_13_5_0_0_;
	O6289[220] = + _LNGOFF_6_3_0_0_;
	O6289[221] = + _LNGOFF_7_4_0_0_;
	{long i; for (i = 222; i < 225; i++) O6289[i] = + _LNGOFF_14_3_0_0_;}
	{long i; for (i = 225; i < 228; i++) O6289[i] = + _LNGOFF_5_2_0_0_;}
	O6289[228] = + _LNGOFF_6_3_0_0_;
	{long i; for (i = 229; i < 240; i++) O6289[i] = + _LNGOFF_5_2_0_0_;}
	{long i; for (i = 240; i < 244; i++) O6289[i] = + _LNGOFF_6_2_0_0_;}
	{long i; for (i = 244; i < 246; i++) O6289[i] = + _LNGOFF_6_0_0_0_;}
	O6289[246] = + _LNGOFF_7_2_0_1_;
	{long i; for (i = 247; i < 255; i++) O6289[i] = + _LNGOFF_6_0_0_0_;}
	{long i; for (i = 256; i < 261; i++) O6289[i] = + _LNGOFF_5_3_0_0_;}
	O6289[262] = + _LNGOFF_5_3_0_0_;
	{long i; for (i = 263; i < 265; i++) O6289[i] = + _LNGOFF_6_1_0_0_;}
	O6289[267] = + _LNGOFF_6_1_0_0_;
	O6289[273] = + _LNGOFF_2_4_0_0_;
	O6289[275] = + _LNGOFF_2_2_0_1_;
	O6289[290] = + _LNGOFF_49_16_0_3_;
	O6289[295] = + _LNGOFF_2_3_0_0_;
	O6289[296] = + _LNGOFF_4_3_0_0_;
	O6289[297] = + _LNGOFF_5_5_0_0_;
	O6289[298] = + _LNGOFF_10_10_0_0_;
	O6289[309] = + _LNGOFF_6_3_0_0_;
	O6289[339] = + _LNGOFF_8_5_0_0_;
	O6289[340] = + _LNGOFF_9_5_0_0_;
	O6289[341] = + _LNGOFF_11_5_0_0_;
	O6289[342] = + _LNGOFF_11_6_0_0_;
	O6289[344] = + _LNGOFF_16_7_6_0_;
	O6289[346] = + _LNGOFF_42_12_10_0_;
	O6289[348] = + _LNGOFF_46_12_10_0_;
	O6289[352] = + _LNGOFF_47_12_10_0_;
	O6289[353] = + _LNGOFF_49_12_10_0_;
	O6289[354] = + _LNGOFF_47_12_10_0_;
	{long i; for (i = 358; i < 361; i++) O6289[i] = + _LNGOFF_49_13_10_0_;}
	O6289[369] = + _LNGOFF_49_13_10_0_;
	O6289[370] = + _LNGOFF_51_13_10_0_;
	{long i; for (i = 371; i < 373; i++) O6289[i] = + _LNGOFF_49_14_10_0_;}
	O6289[373] = + _LNGOFF_59_21_10_0_;
	O6289[374] = + _LNGOFF_59_23_10_0_;
	O6289[375] = + _LNGOFF_65_25_10_0_;
	O6289[376] = + _LNGOFF_68_26_10_0_;
	O6289[400] = + _LNGOFF_42_13_10_0_;
	O6289[401] = + _LNGOFF_45_16_10_0_;
	O6289[402] = + _LNGOFF_58_14_10_0_;
	O6289[403] = + _LNGOFF_51_13_10_0_;
	{long i; for (i = 404; i < 406; i++) O6289[i] = + _LNGOFF_44_13_10_0_;}
	{long i; for (i = 406; i < 408; i++) O6289[i] = + _LNGOFF_44_14_10_0_;}
	O6289[408] = + _LNGOFF_50_13_10_0_;
	O6289[409] = + _LNGOFF_51_14_10_0_;
	{long i; for (i = 410; i < 413; i++) O6289[i] = + _LNGOFF_42_13_10_0_;}
	O6289[413] = + _LNGOFF_43_13_10_0_;
	O6289[414] = + _LNGOFF_44_15_10_0_;
	O6289[415] = + _LNGOFF_51_18_10_0_;
	O6289[416] = + _LNGOFF_46_14_10_0_;
	O6289[417] = + _LNGOFF_59_16_10_0_;
	{long i; for (i = 418; i < 423; i++) O6289[i] = + _LNGOFF_46_14_10_0_;}
	{long i; for (i = 431; i < 433; i++) O6289[i] = + _LNGOFF_21_7_6_0_;}
	O6289[438] = + _LNGOFF_23_8_6_0_;
	{long i; for (i = 439; i < 441; i++) O6289[i] = + _LNGOFF_23_9_6_0_;}
	O6289[441] = + _LNGOFF_24_9_6_0_;
	O6289[442] = + _LNGOFF_26_8_6_0_;
	{long i; for (i = 447; i < 449; i++) O6289[i] = + _LNGOFF_29_14_8_0_;}
	O6289[455] = + _LNGOFF_48_19_10_0_;
	O6289[458] = + _LNGOFF_48_18_10_0_;
}

long O6349[264];
void O6349_init () {
	O6349[0] =  + _REFACS_1_;
	O6349[196] =  + _REFACS_1_;
	{long i; for (i = 200; i < 215; i++) O6349[i] =  + _REFACS_1_;}
	O6349[215] =  + _REFACS_2_;
	{long i; for (i = 216; i < 242; i++) O6349[i] =  + _REFACS_1_;}
	O6349[242] =  + _REFACS_2_;
	{long i; for (i = 243; i < 251; i++) O6349[i] =  + _REFACS_1_;}
	{long i; for (i = 252; i < 257; i++) O6349[i] =  + _REFACS_1_;}
	{long i; for (i = 258; i < 261; i++) O6349[i] =  + _REFACS_1_;}
	O6349[263] =  + _REFACS_1_;
}

long O7237[7];
void O7237_init () {
	{long i; for (i = 0; i < 2; i++) O7237[i] = + _CHROFF_4_0_;}
	O7237[2] = + _CHROFF_5_0_;
	{long i; for (i = 3; i < 7; i++) O7237[i] = + _CHROFF_4_0_;}
}

long O7238[7];
void O7238_init () {
	{long i; for (i = 0; i < 2; i++) O7238[i] = + _LNGOFF_4_2_0_0_;}
	O7238[2] = + _LNGOFF_5_2_0_0_;
	O7238[3] = + _LNGOFF_4_3_0_0_;
	{long i; for (i = 4; i < 6; i++) O7238[i] = + _LNGOFF_4_2_0_0_;}
	O7238[6] = + _LNGOFF_4_3_0_0_;
}

long O7246[7];
void O7246_init () {
	{long i; for (i = 0; i < 2; i++) O7246[i] = + _PTROFF_4_2_0_3_0_0_;}
	O7246[2] = + _PTROFF_5_2_0_3_0_0_;
	O7246[3] = + _PTROFF_4_3_0_3_0_0_;
	O7246[4] = + _PTROFF_4_2_0_3_0_0_;
	O7246[5] = + _PTROFF_4_2_0_4_0_0_;
	O7246[6] = + _PTROFF_4_3_0_3_0_0_;
}

long O7247[7];
void O7247_init () {
	{long i; for (i = 0; i < 2; i++) O7247[i] = + _PTROFF_4_2_0_3_0_1_;}
	O7247[2] = + _PTROFF_5_2_0_3_0_1_;
	O7247[3] = + _PTROFF_4_3_0_3_0_1_;
	O7247[4] = + _PTROFF_4_2_0_3_0_1_;
	O7247[5] = + _PTROFF_4_2_0_4_0_1_;
	O7247[6] = + _PTROFF_4_3_0_3_0_1_;
}

long O7249[7];
void O7249_init () {
	{long i; for (i = 0; i < 2; i++) O7249[i] = + _PTROFF_4_2_0_3_0_2_;}
	O7249[2] = + _PTROFF_5_2_0_3_0_2_;
	O7249[3] = + _PTROFF_4_3_0_3_0_2_;
	O7249[4] = + _PTROFF_4_2_0_3_0_2_;
	O7249[5] = + _PTROFF_4_2_0_4_0_2_;
	O7249[6] = + _PTROFF_4_3_0_3_0_2_;
}

long O7250[7];
void O7250_init () {
	{long i; for (i = 0; i < 2; i++) O7250[i] = + _LNGOFF_4_2_0_1_;}
	O7250[2] = + _LNGOFF_5_2_0_1_;
	O7250[3] = + _LNGOFF_4_3_0_1_;
	{long i; for (i = 4; i < 6; i++) O7250[i] = + _LNGOFF_4_2_0_1_;}
	O7250[6] = + _LNGOFF_4_3_0_1_;
}

long O7251[7];
void O7251_init () {
	{long i; for (i = 0; i < 2; i++) O7251[i] = + _CHROFF_4_1_;}
	O7251[2] = + _CHROFF_5_1_;
	{long i; for (i = 3; i < 7; i++) O7251[i] = + _CHROFF_4_1_;}
}

long O7252[7];
void O7252_init () {
	{long i; for (i = 0; i < 2; i++) O7252[i] = + _LNGOFF_4_2_0_2_;}
	O7252[2] = + _LNGOFF_5_2_0_2_;
	O7252[3] = + _LNGOFF_4_3_0_2_;
	{long i; for (i = 4; i < 6; i++) O7252[i] = + _LNGOFF_4_2_0_2_;}
	O7252[6] = + _LNGOFF_4_3_0_2_;
}

long O7265[5];
void O7265_init () {
	O7265[0] =  + _REFACS_4_;
	O7265[1] = + _CHROFF_4_2_;
	O7265[2] = + _PTROFF_4_2_0_3_0_3_;
	O7265[3] = + _LNGOFF_4_2_0_3_;
	O7265[4] = + _CHROFF_4_2_;
}

long O7364[10];
void O7364_init () {
	{long i; for (i = 0; i < 3; i++) O7364[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O7364[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 5; i < 7; i++) O7364[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 7; i < 9; i++) O7364[i] = + _LNGOFF_1_0_0_0_;}
	O7364[9] = + _LNGOFF_1_1_0_0_;
}

long O7365[10];
void O7365_init () {
	{long i; for (i = 0; i < 3; i++) O7365[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O7365[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 5; i < 7; i++) O7365[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 7; i < 9; i++) O7365[i] = + _LNGOFF_1_0_0_1_;}
	O7365[9] = + _LNGOFF_1_1_0_1_;
}

long O7434[4];
void O7434_init () {
	{long i; for (i = 0; i < 2; i++) O7434[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 4; i++) O7434[i] = + _LNGOFF_1_1_0_2_;}
}

long O7509[3];
void O7509_init () {
	{long i; for (i = 0; i < 2; i++) O7509[i] = + _LNGOFF_1_0_0_2_;}
	O7509[2] = + _LNGOFF_1_1_0_2_;
}

long O7674[110];
void O7674_init () {
	{long i; for (i = 0; i < 41; i++) O7674[i] =  + _REFACS_1_;}
	O7674[41] =  + _REFACS_3_;
	{long i; for (i = 42; i < 45; i++) O7674[i] =  + _REFACS_1_;}
	{long i; for (i = 45; i < 60; i++) O7674[i] =  + _REFACS_3_;}
	O7674[60] =  + _REFACS_4_;
	{long i; for (i = 61; i < 87; i++) O7674[i] =  + _REFACS_3_;}
	O7674[87] =  + _REFACS_4_;
	{long i; for (i = 88; i < 96; i++) O7674[i] =  + _REFACS_3_;}
	O7674[96] =  + _REFACS_1_;
	{long i; for (i = 97; i < 102; i++) O7674[i] =  + _REFACS_3_;}
	O7674[102] =  + _REFACS_1_;
	{long i; for (i = 103; i < 106; i++) O7674[i] =  + _REFACS_3_;}
	{long i; for (i = 106; i < 108; i++) O7674[i] =  + _REFACS_1_;}
	O7674[108] =  + _REFACS_3_;
	O7674[109] =  + _REFACS_1_;
}

long O7865[96];
void O7865_init () {
	O7865[0] =  + _REFACS_2_;
	{long i; for (i = 29; i < 32; i++) O7865[i] =  + _REFACS_2_;}
	{long i; for (i = 32; i < 47; i++) O7865[i] =  + _REFACS_4_;}
	O7865[47] =  + _REFACS_5_;
	{long i; for (i = 48; i < 74; i++) O7865[i] =  + _REFACS_4_;}
	O7865[74] =  + _REFACS_5_;
	{long i; for (i = 75; i < 83; i++) O7865[i] =  + _REFACS_4_;}
	O7865[83] =  + _REFACS_2_;
	{long i; for (i = 84; i < 89; i++) O7865[i] =  + _REFACS_4_;}
	O7865[89] =  + _REFACS_2_;
	{long i; for (i = 90; i < 93; i++) O7865[i] =  + _REFACS_4_;}
	{long i; for (i = 93; i < 95; i++) O7865[i] =  + _REFACS_2_;}
	O7865[95] =  + _REFACS_4_;
}

long O8151[59];
void O8151_init () {
	O8151[0] = + _CHROFF_5_0_;
	{long i; for (i = 1; i < 15; i++) O8151[i] = + _CHROFF_6_1_;}
	O8151[15] = + _CHROFF_13_2_;
	O8151[16] = + _CHROFF_6_1_;
	O8151[17] = + _CHROFF_7_1_;
	{long i; for (i = 18; i < 21; i++) O8151[i] = + _CHROFF_14_1_;}
	{long i; for (i = 21; i < 24; i++) O8151[i] = + _CHROFF_5_0_;}
	O8151[24] = + _CHROFF_6_0_;
	{long i; for (i = 25; i < 36; i++) O8151[i] = + _CHROFF_5_0_;}
	{long i; for (i = 36; i < 40; i++) O8151[i] = + _CHROFF_6_0_;}
	{long i; for (i = 52; i < 57; i++) O8151[i] = + _CHROFF_5_1_;}
	O8151[58] = + _CHROFF_5_1_;
}

long O8152[59];
void O8152_init () {
	O8152[0] = + _CHROFF_5_1_;
	{long i; for (i = 1; i < 15; i++) O8152[i] = + _CHROFF_6_2_;}
	O8152[15] = + _CHROFF_13_3_;
	O8152[16] = + _CHROFF_6_2_;
	O8152[17] = + _CHROFF_7_2_;
	{long i; for (i = 18; i < 21; i++) O8152[i] = + _CHROFF_14_2_;}
	{long i; for (i = 21; i < 24; i++) O8152[i] = + _CHROFF_5_1_;}
	O8152[24] = + _CHROFF_6_1_;
	{long i; for (i = 25; i < 36; i++) O8152[i] = + _CHROFF_5_1_;}
	{long i; for (i = 36; i < 40; i++) O8152[i] = + _CHROFF_6_1_;}
	{long i; for (i = 52; i < 57; i++) O8152[i] = + _CHROFF_5_2_;}
	O8152[58] = + _CHROFF_5_2_;
}

long O8598[192];
void O8598_init () {
	{long i; for (i = 0; i < 20; i++) O8598[i] = 0;}
	O8598[20] =  + _REFACS_22_;
	O8598[21] =  + _REFACS_23_;
	{long i; for (i = 22; i < 35; i++) O8598[i] = 0;}
	O8598[35] =  + _REFACS_1_;
	O8598[36] = 0;
	O8598[37] =  + _REFACS_1_;
	O8598[38] = 0;
	{long i; for (i = 39; i < 41; i++) O8598[i] =  + _REFACS_1_;}
	O8598[41] = 0;
	{long i; for (i = 42; i < 44; i++) O8598[i] =  + _REFACS_5_;}
	{long i; for (i = 44; i < 51; i++) O8598[i] = 0;}
	{long i; for (i = 51; i < 53; i++) O8598[i] =  + _REFACS_1_;}
	{long i; for (i = 53; i < 66; i++) O8598[i] = 0;}
	{long i; for (i = 66; i < 74; i++) O8598[i] =  + _REFACS_2_;}
	{long i; for (i = 74; i < 76; i++) O8598[i] =  + _REFACS_7_;}
	{long i; for (i = 76; i < 78; i++) O8598[i] =  + _REFACS_24_;}
	{long i; for (i = 78; i < 81; i++) O8598[i] =  + _REFACS_25_;}
	O8598[81] =  + _REFACS_26_;
	{long i; for (i = 82; i < 84; i++) O8598[i] =  + _REFACS_25_;}
	O8598[84] =  + _REFACS_26_;
	O8598[85] =  + _REFACS_25_;
	{long i; for (i = 86; i < 96; i++) O8598[i] =  + _REFACS_26_;}
	{long i; for (i = 96; i < 98; i++) O8598[i] =  + _REFACS_30_;}
	{long i; for (i = 98; i < 100; i++) O8598[i] =  + _REFACS_33_;}
	{long i; for (i = 100; i < 104; i++) O8598[i] =  + _REFACS_26_;}
	{long i; for (i = 104; i < 106; i++) O8598[i] =  + _REFACS_30_;}
	{long i; for (i = 106; i < 108; i++) O8598[i] =  + _REFACS_33_;}
	O8598[108] =  + _REFACS_24_;
	O8598[109] =  + _REFACS_28_;
	O8598[110] =  + _REFACS_26_;
	O8598[111] =  + _REFACS_25_;
	O8598[112] =  + _REFACS_24_;
	{long i; for (i = 113; i < 116; i++) O8598[i] =  + _REFACS_25_;}
	{long i; for (i = 116; i < 118; i++) O8598[i] =  + _REFACS_26_;}
	{long i; for (i = 118; i < 120; i++) O8598[i] =  + _REFACS_25_;}
	O8598[120] =  + _REFACS_28_;
	O8598[121] =  + _REFACS_26_;
	O8598[122] =  + _REFACS_30_;
	O8598[123] =  + _REFACS_26_;
	{long i; for (i = 124; i < 127; i++) O8598[i] =  + _REFACS_24_;}
	{long i; for (i = 127; i < 131; i++) O8598[i] =  + _REFACS_25_;}
	O8598[131] =  + _REFACS_24_;
	O8598[132] =  + _REFACS_25_;
	O8598[133] =  + _REFACS_28_;
	O8598[134] =  + _REFACS_26_;
	O8598[135] =  + _REFACS_24_;
	{long i; for (i = 136; i < 139; i++) O8598[i] =  + _REFACS_25_;}
	{long i; for (i = 139; i < 141; i++) O8598[i] =  + _REFACS_26_;}
	{long i; for (i = 141; i < 144; i++) O8598[i] =  + _REFACS_24_;}
	{long i; for (i = 144; i < 146; i++) O8598[i] =  + _REFACS_25_;}
	O8598[146] =  + _REFACS_28_;
	O8598[147] =  + _REFACS_26_;
	O8598[148] =  + _REFACS_30_;
	O8598[149] =  + _REFACS_26_;
	{long i; for (i = 150; i < 154; i++) O8598[i] =  + _REFACS_25_;}
	O8598[154] =  + _REFACS_10_;
	{long i; for (i = 155; i < 157; i++) O8598[i] =  + _REFACS_12_;}
	O8598[157] =  + _REFACS_10_;
	{long i; for (i = 158; i < 162; i++) O8598[i] =  + _REFACS_14_;}
	{long i; for (i = 162; i < 164; i++) O8598[i] =  + _REFACS_10_;}
	{long i; for (i = 164; i < 168; i++) O8598[i] =  + _REFACS_11_;}
	O8598[168] =  + _REFACS_12_;
	{long i; for (i = 169; i < 173; i++) O8598[i] =  + _REFACS_11_;}
	{long i; for (i = 173; i < 176; i++) O8598[i] =  + _REFACS_12_;}
	{long i; for (i = 176; i < 180; i++) O8598[i] =  + _REFACS_14_;}
	O8598[180] = 0;
	O8598[181] =  + _REFACS_25_;
	{long i; for (i = 182; i < 184; i++) O8598[i] = 0;}
	O8598[184] =  + _REFACS_25_;
	O8598[185] = 0;
	O8598[186] =  + _REFACS_25_;
	{long i; for (i = 187; i < 189; i++) O8598[i] = 0;}
	O8598[189] =  + _REFACS_25_;
	{long i; for (i = 190; i < 192; i++) O8598[i] = 0;}
}


#ifdef __cplusplus
}
#endif
