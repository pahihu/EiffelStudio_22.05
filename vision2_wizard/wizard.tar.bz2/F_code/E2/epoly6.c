#include "epoly6.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4667[736])();
void R4667_init () {
	R4667[0] = (char *(*)()) F662_5520;
	R4667[1] = (char *(*)()) F663_5520;
	R4667[2] = (char *(*)()) F664_5520;
	{long i; for (i = 3; i < 5; i++) R4667[i] = (char *(*)()) F662_5520;}
	R4667[5] = (char *(*)()) F663_5520;
	R4667[6] = (char *(*)()) F664_5520;
	R4667[7] = (char *(*)()) F669_5596;
	R4667[18] = (char *(*)()) F680_5809;
	R4667[19] = (char *(*)()) F681_5809;
	R4667[20] = (char *(*)()) F682_5809;
	R4667[21] = (char *(*)()) F683_5809;
	R4667[22] = (char *(*)()) F684_5809;
	R4667[23] = (char *(*)()) F685_5809;
	R4667[24] = (char *(*)()) F680_5809;
	R4667[25] = (char *(*)()) F681_5809;
	R4667[26] = (char *(*)()) F680_5809;
	R4667[27] = (char *(*)()) F689_5939;
	R4667[28] = (char *(*)()) F690_5939;
	R4667[29] = (char *(*)()) F691_5939;
	R4667[30] = (char *(*)()) F692_5939;
	R4667[31] = (char *(*)()) F693_5939;
	R4667[32] = (char *(*)()) F694_5939;
	R4667[33] = (char *(*)()) F695_5939;
	R4667[34] = (char *(*)()) F696_5939;
	R4667[35] = (char *(*)()) F697_5939;
	R4667[36] = (char *(*)()) F698_5939;
	R4667[37] = (char *(*)()) F699_5939;
	R4667[38] = (char *(*)()) F700_5939;
	R4667[46] = (char *(*)()) F689_5939;
	R4667[47] = (char *(*)()) F693_5939;
	{long i; for (i = 48; i < 52; i++) R4667[i] = (char *(*)()) F689_5939;}
	R4667[56] = (char *(*)()) F689_5939;
	{long i; for (i = 59; i < 61; i++) R4667[i] = (char *(*)()) F689_5939;}
	R4667[64] = (char *(*)()) F689_5939;
	{long i; for (i = 66; i < 70; i++) R4667[i] = (char *(*)()) F689_5939;}
	R4667[84] = (char *(*)()) F746_6168;
	R4667[88] = (char *(*)()) F750_6222;
	{long i; for (i = 268; i < 270; i++) R4667[i] = (char *(*)()) F929_7062;}
	R4667[312] = (char *(*)()) F575_5329;
	{long i; for (i = 400; i < 402; i++) R4667[i] = (char *(*)()) F1061_9082;}
	{long i; for (i = 480; i < 482; i++) R4667[i] = (char *(*)()) F575_5329;}
	R4667[527] = (char *(*)()) F575_5329;
	R4667[537] = (char *(*)()) F575_5329;
	R4667[735] = (char *(*)()) F1397_13909;
}

static EIF_TYPE_INDEX Y4668_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype12[] = {1058,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype13[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype14[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype15[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype16[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype17[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype18[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype19[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype20[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype21[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype22[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype23[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype24[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype25[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype26[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype27[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype256[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype261[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype264[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype274[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype275[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype288[] = {985,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype319[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype320[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype321[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype345[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype355[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype358[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype362[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype363[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype364[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype365[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype366[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype367[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype368[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype369[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype370[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype371[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype372[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype373[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype374[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype375[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype376[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype377[] = {1097,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype378[] = {1047,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype379[] = {1047,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype380[] = {1047,0xFFF9,1,973,0,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype381[] = {1047,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype382[] = {1047,0xFFF9,1,973,1006,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype383[] = {1047,0xFFF9,1,973,1177,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype384[] = {1047,0xFFF9,1,973,1006,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype385[] = {1047,0xFFF9,1,973,1182,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype386[] = {1047,0xFFF9,1,973,1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype387[] = {1047,0xFFF9,1,973,935,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype388[] = {1047,0xFFF9,1,973,1110,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype389[] = {1047,0xFFF9,1,973,1394,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype390[] = {1047,0xFFF9,1,973,1006,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype391[] = {1047,0xFFF9,5,973,979,1006,1006,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype392[] = {1047,0xFFF9,1,973,1062,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype393[] = {1047,0xFFF9,7,973,1006,1006,991,991,991,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype394[] = {1047,0xFFF9,2,973,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype395[] = {1047,0xFFF9,3,973,1006,1006,935,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype396[] = {1047,0xFFF9,8,973,1006,1006,1006,991,991,991,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype397[] = {1047,0xFFF9,0,973,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype398[] = {1047,0xFFF9,4,973,1006,1006,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype399[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype400[] = {21,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype401[] = {994,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype402[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype447[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype448[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype449[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype450[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype451[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype452[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype453[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype454[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype455[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype456[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype457[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype458[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype459[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype460[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype461[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype462[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype463[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype464[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype465[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype466[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype467[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype468[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype469[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype470[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype471[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype472[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype473[] = {997,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype474[] = {994,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype475[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype476[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype477[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype478[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype479[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype480[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype481[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype482[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype483[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype484[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype485[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype486[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype487[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype488[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype489[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype490[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype491[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype492[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype493[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype494[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype495[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype496[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype497[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype498[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype499[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype500[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype501[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype502[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype503[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype504[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype505[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype506[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype507[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype508[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype509[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype510[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype511[] = {997,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype512[] = {997,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype513[] = {997,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype514[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype515[] = {997,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype516[] = {997,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype517[] = {997,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype518[] = {997,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype519[] = {994,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype520[] = {994,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype521[] = {994,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype522[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype523[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype524[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype525[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype526[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype527[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype528[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype529[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype530[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype531[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype532[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype533[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype534[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype535[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype536[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype537[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype538[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype539[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype540[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype541[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype542[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype543[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype544[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype545[] = {1062,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype546[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype547[] = {1177,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype548[] = {1178,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype549[] = {1176,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype550[] = {1176,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype551[] = {1176,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype552[] = {1194,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype553[] = {1194,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype554[] = {1194,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype555[] = {1194,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype556[] = {1182,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype557[] = {1182,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype558[] = {1182,0xFFFF};
static EIF_TYPE_INDEX Y4668_pgtype559[] = {997,0xFFFF};
EIF_TYPE_INDEX *Y4668_gen_type [1073];
EIF_TYPE_INDEX Y4668 [1073];
void Y4668_init (void)
{
	egc_routines_types [4668] = Y4668;
	egc_routines_gen_types [4668] = Y4668_gen_type;
	egc_routines_offset [4668] = 324;
	Y4668_gen_type [0] = Y4668_pgtype0;
	Y4668_gen_type [1] = Y4668_pgtype1;
	Y4668_gen_type [2] = Y4668_pgtype2;
	Y4668_gen_type [3] = Y4668_pgtype3;
	Y4668_gen_type [4] = Y4668_pgtype4;
	Y4668_gen_type [5] = Y4668_pgtype5;
	Y4668_gen_type [6] = Y4668_pgtype6;
	Y4668_gen_type [7] = Y4668_pgtype7;
	Y4668_gen_type [8] = Y4668_pgtype8;
	Y4668_gen_type [9] = Y4668_pgtype9;
	Y4668_gen_type [10] = Y4668_pgtype10;
	Y4668_gen_type [11] = Y4668_pgtype11;
	Y4668_gen_type [12] = Y4668_pgtype12;
	Y4668_gen_type [13] = Y4668_pgtype13;
	Y4668_gen_type [14] = Y4668_pgtype14;
	Y4668_gen_type [15] = Y4668_pgtype15;
	Y4668_gen_type [16] = Y4668_pgtype16;
	Y4668_gen_type [17] = Y4668_pgtype17;
	Y4668_gen_type [18] = Y4668_pgtype18;
	Y4668_gen_type [19] = Y4668_pgtype19;
	Y4668_gen_type [20] = Y4668_pgtype20;
	Y4668_gen_type [21] = Y4668_pgtype21;
	Y4668_gen_type [22] = Y4668_pgtype22;
	Y4668_gen_type [23] = Y4668_pgtype23;
	Y4668_gen_type [24] = Y4668_pgtype24;
	Y4668_gen_type [25] = Y4668_pgtype25;
	Y4668_gen_type [26] = Y4668_pgtype26;
	Y4668_gen_type [27] = Y4668_pgtype27;
	Y4668_gen_type [28] = Y4668_pgtype28;
	Y4668_gen_type [29] = Y4668_pgtype29;
	Y4668_gen_type [30] = Y4668_pgtype30;
	Y4668_gen_type [31] = Y4668_pgtype31;
	Y4668_gen_type [32] = Y4668_pgtype32;
	Y4668_gen_type [33] = Y4668_pgtype33;
	Y4668_gen_type [34] = Y4668_pgtype34;
	Y4668_gen_type [35] = Y4668_pgtype35;
	Y4668_gen_type [36] = Y4668_pgtype36;
	Y4668_gen_type [37] = Y4668_pgtype37;
	Y4668_gen_type [38] = Y4668_pgtype38;
	Y4668_gen_type [39] = Y4668_pgtype39;
	Y4668_gen_type [40] = Y4668_pgtype40;
	Y4668_gen_type [41] = Y4668_pgtype41;
	Y4668_gen_type [42] = Y4668_pgtype42;
	Y4668_gen_type [43] = Y4668_pgtype43;
	Y4668_gen_type [44] = Y4668_pgtype44;
	Y4668_gen_type [45] = Y4668_pgtype45;
	Y4668_gen_type [46] = Y4668_pgtype46;
	Y4668_gen_type [47] = Y4668_pgtype47;
	Y4668_gen_type [48] = Y4668_pgtype48;
	Y4668_gen_type [49] = Y4668_pgtype49;
	Y4668_gen_type [50] = Y4668_pgtype50;
	Y4668_gen_type [51] = Y4668_pgtype51;
	Y4668_gen_type [52] = Y4668_pgtype52;
	Y4668_gen_type [53] = Y4668_pgtype53;
	Y4668_gen_type [54] = Y4668_pgtype54;
	Y4668_gen_type [55] = Y4668_pgtype55;
	Y4668_gen_type [56] = Y4668_pgtype56;
	Y4668_gen_type [57] = Y4668_pgtype57;
	Y4668_gen_type [58] = Y4668_pgtype58;
	Y4668_gen_type [59] = Y4668_pgtype59;
	Y4668_gen_type [60] = Y4668_pgtype60;
	Y4668_gen_type [61] = Y4668_pgtype61;
	Y4668_gen_type [62] = Y4668_pgtype62;
	Y4668_gen_type [63] = Y4668_pgtype63;
	Y4668_gen_type [64] = Y4668_pgtype64;
	Y4668_gen_type [65] = Y4668_pgtype65;
	Y4668_gen_type [66] = Y4668_pgtype66;
	Y4668_gen_type [67] = Y4668_pgtype67;
	Y4668_gen_type [68] = Y4668_pgtype68;
	Y4668_gen_type [69] = Y4668_pgtype69;
	Y4668_gen_type [70] = Y4668_pgtype70;
	Y4668_gen_type [71] = Y4668_pgtype71;
	Y4668_gen_type [72] = Y4668_pgtype72;
	Y4668_gen_type [73] = Y4668_pgtype73;
	Y4668_gen_type [74] = Y4668_pgtype74;
	Y4668_gen_type [75] = Y4668_pgtype75;
	Y4668_gen_type [76] = Y4668_pgtype76;
	Y4668_gen_type [77] = Y4668_pgtype77;
	Y4668_gen_type [78] = Y4668_pgtype78;
	Y4668_gen_type [79] = Y4668_pgtype79;
	Y4668_gen_type [80] = Y4668_pgtype80;
	Y4668_gen_type [81] = Y4668_pgtype81;
	Y4668_gen_type [82] = Y4668_pgtype82;
	Y4668_gen_type [83] = Y4668_pgtype83;
	Y4668_gen_type [84] = Y4668_pgtype84;
	Y4668_gen_type [85] = Y4668_pgtype85;
	Y4668_gen_type [86] = Y4668_pgtype86;
	Y4668_gen_type [87] = Y4668_pgtype87;
	Y4668_gen_type [88] = Y4668_pgtype88;
	Y4668_gen_type [89] = Y4668_pgtype89;
	Y4668_gen_type [90] = Y4668_pgtype90;
	Y4668_gen_type [91] = Y4668_pgtype91;
	Y4668_gen_type [92] = Y4668_pgtype92;
	Y4668_gen_type [93] = Y4668_pgtype93;
	Y4668_gen_type [94] = Y4668_pgtype94;
	Y4668_gen_type [95] = Y4668_pgtype95;
	Y4668_gen_type [96] = Y4668_pgtype96;
	Y4668_gen_type [97] = Y4668_pgtype97;
	Y4668_gen_type [98] = Y4668_pgtype98;
	Y4668_gen_type [99] = Y4668_pgtype99;
	Y4668_gen_type [100] = Y4668_pgtype100;
	Y4668_gen_type [101] = Y4668_pgtype101;
	Y4668_gen_type [102] = Y4668_pgtype102;
	Y4668_gen_type [103] = Y4668_pgtype103;
	Y4668_gen_type [104] = Y4668_pgtype104;
	Y4668_gen_type [105] = Y4668_pgtype105;
	Y4668_gen_type [106] = Y4668_pgtype106;
	Y4668_gen_type [107] = Y4668_pgtype107;
	Y4668_gen_type [108] = Y4668_pgtype108;
	Y4668_gen_type [109] = Y4668_pgtype109;
	Y4668_gen_type [110] = Y4668_pgtype110;
	Y4668_gen_type [111] = Y4668_pgtype111;
	Y4668_gen_type [112] = Y4668_pgtype112;
	Y4668_gen_type [113] = Y4668_pgtype113;
	Y4668_gen_type [114] = Y4668_pgtype114;
	Y4668_gen_type [115] = Y4668_pgtype115;
	Y4668_gen_type [116] = Y4668_pgtype116;
	Y4668_gen_type [117] = Y4668_pgtype117;
	Y4668_gen_type [118] = Y4668_pgtype118;
	Y4668_gen_type [119] = Y4668_pgtype119;
	Y4668_gen_type [120] = Y4668_pgtype120;
	Y4668_gen_type [121] = Y4668_pgtype121;
	Y4668_gen_type [122] = Y4668_pgtype122;
	Y4668_gen_type [123] = Y4668_pgtype123;
	Y4668_gen_type [124] = Y4668_pgtype124;
	Y4668_gen_type [125] = Y4668_pgtype125;
	Y4668_gen_type [126] = Y4668_pgtype126;
	Y4668_gen_type [127] = Y4668_pgtype127;
	Y4668_gen_type [128] = Y4668_pgtype128;
	Y4668_gen_type [129] = Y4668_pgtype129;
	Y4668_gen_type [130] = Y4668_pgtype130;
	Y4668_gen_type [131] = Y4668_pgtype131;
	Y4668_gen_type [132] = Y4668_pgtype132;
	Y4668_gen_type [133] = Y4668_pgtype133;
	Y4668_gen_type [134] = Y4668_pgtype134;
	Y4668_gen_type [135] = Y4668_pgtype135;
	Y4668_gen_type [136] = Y4668_pgtype136;
	Y4668_gen_type [137] = Y4668_pgtype137;
	Y4668_gen_type [138] = Y4668_pgtype138;
	Y4668_gen_type [139] = Y4668_pgtype139;
	Y4668_gen_type [140] = Y4668_pgtype140;
	Y4668_gen_type [141] = Y4668_pgtype141;
	Y4668_gen_type [142] = Y4668_pgtype142;
	Y4668_gen_type [143] = Y4668_pgtype143;
	Y4668_gen_type [144] = Y4668_pgtype144;
	Y4668_gen_type [145] = Y4668_pgtype145;
	Y4668_gen_type [146] = Y4668_pgtype146;
	Y4668_gen_type [147] = Y4668_pgtype147;
	Y4668_gen_type [148] = Y4668_pgtype148;
	Y4668_gen_type [149] = Y4668_pgtype149;
	Y4668_gen_type [150] = Y4668_pgtype150;
	Y4668_gen_type [151] = Y4668_pgtype151;
	Y4668_gen_type [152] = Y4668_pgtype152;
	Y4668_gen_type [153] = Y4668_pgtype153;
	Y4668_gen_type [154] = Y4668_pgtype154;
	Y4668_gen_type [155] = Y4668_pgtype155;
	Y4668_gen_type [156] = Y4668_pgtype156;
	Y4668_gen_type [157] = Y4668_pgtype157;
	Y4668_gen_type [158] = Y4668_pgtype158;
	Y4668_gen_type [159] = Y4668_pgtype159;
	Y4668_gen_type [160] = Y4668_pgtype160;
	Y4668_gen_type [161] = Y4668_pgtype161;
	Y4668_gen_type [162] = Y4668_pgtype162;
	Y4668_gen_type [163] = Y4668_pgtype163;
	Y4668_gen_type [164] = Y4668_pgtype164;
	Y4668_gen_type [165] = Y4668_pgtype165;
	Y4668_gen_type [166] = Y4668_pgtype166;
	Y4668_gen_type [167] = Y4668_pgtype167;
	Y4668_gen_type [168] = Y4668_pgtype168;
	Y4668_gen_type [169] = Y4668_pgtype169;
	Y4668_gen_type [170] = Y4668_pgtype170;
	Y4668_gen_type [171] = Y4668_pgtype171;
	Y4668_gen_type [172] = Y4668_pgtype172;
	Y4668_gen_type [173] = Y4668_pgtype173;
	Y4668_gen_type [174] = Y4668_pgtype174;
	Y4668_gen_type [175] = Y4668_pgtype175;
	Y4668_gen_type [176] = Y4668_pgtype176;
	Y4668_gen_type [177] = Y4668_pgtype177;
	Y4668_gen_type [178] = Y4668_pgtype178;
	Y4668_gen_type [179] = Y4668_pgtype179;
	Y4668_gen_type [180] = Y4668_pgtype180;
	Y4668_gen_type [181] = Y4668_pgtype181;
	Y4668_gen_type [182] = Y4668_pgtype182;
	Y4668_gen_type [183] = Y4668_pgtype183;
	Y4668_gen_type [184] = Y4668_pgtype184;
	Y4668_gen_type [185] = Y4668_pgtype185;
	Y4668_gen_type [186] = Y4668_pgtype186;
	Y4668_gen_type [187] = Y4668_pgtype187;
	Y4668_gen_type [188] = Y4668_pgtype188;
	Y4668_gen_type [189] = Y4668_pgtype189;
	Y4668_gen_type [190] = Y4668_pgtype190;
	Y4668_gen_type [191] = Y4668_pgtype191;
	Y4668_gen_type [192] = Y4668_pgtype192;
	Y4668_gen_type [193] = Y4668_pgtype193;
	Y4668_gen_type [194] = Y4668_pgtype194;
	Y4668_gen_type [195] = Y4668_pgtype195;
	Y4668_gen_type [196] = Y4668_pgtype196;
	Y4668_gen_type [197] = Y4668_pgtype197;
	Y4668_gen_type [198] = Y4668_pgtype198;
	Y4668_gen_type [199] = Y4668_pgtype199;
	Y4668_gen_type [200] = Y4668_pgtype200;
	Y4668_gen_type [201] = Y4668_pgtype201;
	Y4668_gen_type [202] = Y4668_pgtype202;
	Y4668_gen_type [203] = Y4668_pgtype203;
	Y4668_gen_type [204] = Y4668_pgtype204;
	Y4668_gen_type [205] = Y4668_pgtype205;
	Y4668_gen_type [206] = Y4668_pgtype206;
	Y4668_gen_type [207] = Y4668_pgtype207;
	Y4668_gen_type [208] = Y4668_pgtype208;
	Y4668_gen_type [209] = Y4668_pgtype209;
	Y4668_gen_type [210] = Y4668_pgtype210;
	Y4668_gen_type [211] = Y4668_pgtype211;
	Y4668_gen_type [212] = Y4668_pgtype212;
	Y4668_gen_type [213] = Y4668_pgtype213;
	Y4668_gen_type [214] = Y4668_pgtype214;
	Y4668_gen_type [215] = Y4668_pgtype215;
	Y4668_gen_type [216] = Y4668_pgtype216;
	Y4668_gen_type [217] = Y4668_pgtype217;
	Y4668_gen_type [218] = Y4668_pgtype218;
	Y4668_gen_type [219] = Y4668_pgtype219;
	Y4668_gen_type [220] = Y4668_pgtype220;
	Y4668_gen_type [221] = Y4668_pgtype221;
	Y4668_gen_type [222] = Y4668_pgtype222;
	Y4668_gen_type [223] = Y4668_pgtype223;
	Y4668_gen_type [224] = Y4668_pgtype224;
	Y4668_gen_type [225] = Y4668_pgtype225;
	Y4668_gen_type [226] = Y4668_pgtype226;
	Y4668_gen_type [227] = Y4668_pgtype227;
	Y4668_gen_type [228] = Y4668_pgtype228;
	Y4668_gen_type [229] = Y4668_pgtype229;
	Y4668_gen_type [230] = Y4668_pgtype230;
	Y4668_gen_type [231] = Y4668_pgtype231;
	Y4668_gen_type [232] = Y4668_pgtype232;
	Y4668_gen_type [233] = Y4668_pgtype233;
	Y4668_gen_type [234] = Y4668_pgtype234;
	Y4668_gen_type [235] = Y4668_pgtype235;
	Y4668_gen_type [236] = Y4668_pgtype236;
	Y4668_gen_type [237] = Y4668_pgtype237;
	Y4668_gen_type [238] = Y4668_pgtype238;
	Y4668_gen_type [239] = Y4668_pgtype239;
	Y4668_gen_type [240] = Y4668_pgtype240;
	Y4668_gen_type [241] = Y4668_pgtype241;
	Y4668_gen_type [242] = Y4668_pgtype242;
	Y4668_gen_type [243] = Y4668_pgtype243;
	Y4668_gen_type [244] = Y4668_pgtype244;
	Y4668_gen_type [245] = Y4668_pgtype245;
	Y4668_gen_type [246] = Y4668_pgtype246;
	Y4668_gen_type [247] = Y4668_pgtype247;
	Y4668_gen_type [248] = Y4668_pgtype248;
	Y4668_gen_type [249] = Y4668_pgtype249;
	Y4668_gen_type [250] = Y4668_pgtype250;
	Y4668_gen_type [251] = Y4668_pgtype251;
	Y4668_gen_type [252] = Y4668_pgtype252;
	Y4668_gen_type [253] = Y4668_pgtype253;
	Y4668_gen_type [254] = Y4668_pgtype254;
	Y4668_gen_type [255] = Y4668_pgtype255;
	Y4668_gen_type [256] = Y4668_pgtype256;
	Y4668_gen_type [257] = Y4668_pgtype257;
	Y4668_gen_type [258] = Y4668_pgtype258;
	Y4668_gen_type [259] = Y4668_pgtype259;
	Y4668_gen_type [260] = Y4668_pgtype260;
	Y4668_gen_type [261] = Y4668_pgtype261;
	Y4668_gen_type [262] = Y4668_pgtype262;
	Y4668_gen_type [263] = Y4668_pgtype263;
	Y4668_gen_type [264] = Y4668_pgtype264;
	Y4668_gen_type [265] = Y4668_pgtype265;
	Y4668_gen_type [266] = Y4668_pgtype266;
	Y4668_gen_type [267] = Y4668_pgtype267;
	Y4668_gen_type [268] = Y4668_pgtype268;
	Y4668_gen_type [269] = Y4668_pgtype269;
	Y4668_gen_type [270] = Y4668_pgtype270;
	Y4668_gen_type [271] = Y4668_pgtype271;
	Y4668_gen_type [272] = Y4668_pgtype272;
	Y4668_gen_type [273] = Y4668_pgtype273;
	Y4668_gen_type [274] = Y4668_pgtype274;
	Y4668_gen_type [275] = Y4668_pgtype275;
	Y4668_gen_type [276] = Y4668_pgtype276;
	Y4668_gen_type [277] = Y4668_pgtype277;
	Y4668_gen_type [278] = Y4668_pgtype278;
	Y4668_gen_type [279] = Y4668_pgtype279;
	Y4668_gen_type [280] = Y4668_pgtype280;
	Y4668_gen_type [281] = Y4668_pgtype281;
	Y4668_gen_type [282] = Y4668_pgtype282;
	Y4668_gen_type [283] = Y4668_pgtype283;
	Y4668_gen_type [284] = Y4668_pgtype284;
	Y4668_gen_type [285] = Y4668_pgtype285;
	Y4668_gen_type [286] = Y4668_pgtype286;
	Y4668_gen_type [287] = Y4668_pgtype287;
	Y4668_gen_type [288] = Y4668_pgtype288;
	Y4668_gen_type [289] = Y4668_pgtype289;
	Y4668_gen_type [290] = Y4668_pgtype290;
	Y4668_gen_type [291] = Y4668_pgtype291;
	Y4668_gen_type [292] = Y4668_pgtype292;
	Y4668_gen_type [293] = Y4668_pgtype293;
	Y4668_gen_type [294] = Y4668_pgtype294;
	Y4668_gen_type [295] = Y4668_pgtype295;
	Y4668_gen_type [296] = Y4668_pgtype296;
	Y4668_gen_type [297] = Y4668_pgtype297;
	Y4668_gen_type [298] = Y4668_pgtype298;
	Y4668_gen_type [299] = Y4668_pgtype299;
	Y4668_gen_type [300] = Y4668_pgtype300;
	Y4668_gen_type [301] = Y4668_pgtype301;
	Y4668_gen_type [302] = Y4668_pgtype302;
	Y4668_gen_type [303] = Y4668_pgtype303;
	Y4668_gen_type [304] = Y4668_pgtype304;
	Y4668_gen_type [305] = Y4668_pgtype305;
	Y4668_gen_type [306] = Y4668_pgtype306;
	Y4668_gen_type [307] = Y4668_pgtype307;
	Y4668_gen_type [308] = Y4668_pgtype308;
	Y4668_gen_type [309] = Y4668_pgtype309;
	Y4668_gen_type [310] = Y4668_pgtype310;
	Y4668_gen_type [311] = Y4668_pgtype311;
	Y4668_gen_type [312] = Y4668_pgtype312;
	Y4668_gen_type [313] = Y4668_pgtype313;
	Y4668_gen_type [314] = Y4668_pgtype314;
	Y4668_gen_type [315] = Y4668_pgtype315;
	Y4668_gen_type [316] = Y4668_pgtype316;
	Y4668_gen_type [317] = Y4668_pgtype317;
	Y4668_gen_type [318] = Y4668_pgtype318;
	Y4668_gen_type [319] = Y4668_pgtype319;
	Y4668_gen_type [320] = Y4668_pgtype320;
	Y4668_gen_type [321] = Y4668_pgtype321;
	Y4668_gen_type [322] = Y4668_pgtype322;
	Y4668_gen_type [323] = Y4668_pgtype323;
	Y4668_gen_type [324] = Y4668_pgtype324;
	Y4668_gen_type [325] = Y4668_pgtype325;
	Y4668_gen_type [326] = Y4668_pgtype326;
	Y4668_gen_type [327] = Y4668_pgtype327;
	Y4668_gen_type [328] = Y4668_pgtype328;
	Y4668_gen_type [329] = Y4668_pgtype329;
	Y4668_gen_type [330] = Y4668_pgtype330;
	Y4668_gen_type [331] = Y4668_pgtype331;
	Y4668_gen_type [332] = Y4668_pgtype332;
	Y4668_gen_type [333] = Y4668_pgtype333;
	Y4668_gen_type [334] = Y4668_pgtype334;
	Y4668_gen_type [335] = Y4668_pgtype335;
	Y4668_gen_type [336] = Y4668_pgtype336;
	Y4668_gen_type [337] = Y4668_pgtype337;
	Y4668_gen_type [338] = Y4668_pgtype338;
	Y4668_gen_type [339] = Y4668_pgtype339;
	Y4668_gen_type [340] = Y4668_pgtype340;
	Y4668_gen_type [341] = Y4668_pgtype341;
	Y4668_gen_type [342] = Y4668_pgtype342;
	Y4668_gen_type [343] = Y4668_pgtype343;
	Y4668_gen_type [344] = Y4668_pgtype344;
	Y4668_gen_type [350] = Y4668_pgtype345;
	Y4668_gen_type [353] = Y4668_pgtype346;
	Y4668_gen_type [355] = Y4668_pgtype347;
	Y4668_gen_type [356] = Y4668_pgtype348;
	Y4668_gen_type [357] = Y4668_pgtype349;
	Y4668_gen_type [358] = Y4668_pgtype350;
	Y4668_gen_type [359] = Y4668_pgtype351;
	Y4668_gen_type [360] = Y4668_pgtype352;
	Y4668_gen_type [361] = Y4668_pgtype353;
	Y4668_gen_type [362] = Y4668_pgtype354;
	Y4668_gen_type [363] = Y4668_pgtype355;
	Y4668_gen_type [364] = Y4668_pgtype356;
	Y4668_gen_type [365] = Y4668_pgtype357;
	Y4668_gen_type [366] = Y4668_pgtype358;
	Y4668_gen_type [367] = Y4668_pgtype359;
	Y4668_gen_type [368] = Y4668_pgtype360;
	Y4668_gen_type [369] = Y4668_pgtype361;
	Y4668_gen_type [370] = Y4668_pgtype362;
	Y4668_gen_type [371] = Y4668_pgtype363;
	Y4668_gen_type [372] = Y4668_pgtype364;
	Y4668_gen_type [373] = Y4668_pgtype365;
	Y4668_gen_type [374] = Y4668_pgtype366;
	Y4668_gen_type [375] = Y4668_pgtype367;
	Y4668_gen_type [376] = Y4668_pgtype368;
	Y4668_gen_type [377] = Y4668_pgtype369;
	Y4668_gen_type [378] = Y4668_pgtype370;
	Y4668_gen_type [379] = Y4668_pgtype371;
	Y4668_gen_type [380] = Y4668_pgtype372;
	Y4668_gen_type [381] = Y4668_pgtype373;
	Y4668_gen_type [382] = Y4668_pgtype374;
	Y4668_gen_type [383] = Y4668_pgtype375;
	Y4668_gen_type [384] = Y4668_pgtype376;
	Y4668_gen_type [385] = Y4668_pgtype377;
	Y4668_gen_type [386] = Y4668_pgtype378;
	Y4668_gen_type [387] = Y4668_pgtype379;
	Y4668_gen_type [388] = Y4668_pgtype380;
	Y4668_gen_type [389] = Y4668_pgtype381;
	Y4668_gen_type [390] = Y4668_pgtype382;
	Y4668_gen_type [391] = Y4668_pgtype383;
	Y4668_gen_type [392] = Y4668_pgtype384;
	Y4668_gen_type [393] = Y4668_pgtype385;
	Y4668_gen_type [394] = Y4668_pgtype386;
	Y4668_gen_type [395] = Y4668_pgtype387;
	Y4668_gen_type [396] = Y4668_pgtype388;
	Y4668_gen_type [397] = Y4668_pgtype389;
	Y4668_gen_type [398] = Y4668_pgtype390;
	Y4668_gen_type [399] = Y4668_pgtype391;
	Y4668_gen_type [400] = Y4668_pgtype392;
	Y4668_gen_type [401] = Y4668_pgtype393;
	Y4668_gen_type [402] = Y4668_pgtype394;
	Y4668_gen_type [403] = Y4668_pgtype395;
	Y4668_gen_type [404] = Y4668_pgtype396;
	Y4668_gen_type [405] = Y4668_pgtype397;
	Y4668_gen_type [406] = Y4668_pgtype398;
	Y4668_gen_type [421] = Y4668_pgtype399;
	Y4668_gen_type [423] = Y4668_pgtype400;
	Y4668_gen_type [424] = Y4668_pgtype401;
	Y4668_gen_type [425] = Y4668_pgtype402;
	Y4668_gen_type [432] = Y4668_pgtype403;
	Y4668_gen_type [433] = Y4668_pgtype404;
	Y4668_gen_type [434] = Y4668_pgtype405;
	Y4668_gen_type [435] = Y4668_pgtype406;
	Y4668_gen_type [436] = Y4668_pgtype407;
	Y4668_gen_type [437] = Y4668_pgtype408;
	Y4668_gen_type [438] = Y4668_pgtype409;
	Y4668_gen_type [439] = Y4668_pgtype410;
	Y4668_gen_type [440] = Y4668_pgtype411;
	Y4668_gen_type [441] = Y4668_pgtype412;
	Y4668_gen_type [442] = Y4668_pgtype413;
	Y4668_gen_type [443] = Y4668_pgtype414;
	Y4668_gen_type [444] = Y4668_pgtype415;
	Y4668_gen_type [445] = Y4668_pgtype416;
	Y4668_gen_type [446] = Y4668_pgtype417;
	Y4668_gen_type [447] = Y4668_pgtype418;
	Y4668_gen_type [448] = Y4668_pgtype419;
	Y4668_gen_type [449] = Y4668_pgtype420;
	Y4668_gen_type [450] = Y4668_pgtype421;
	Y4668_gen_type [451] = Y4668_pgtype422;
	Y4668_gen_type [452] = Y4668_pgtype423;
	Y4668_gen_type [453] = Y4668_pgtype424;
	Y4668_gen_type [454] = Y4668_pgtype425;
	Y4668_gen_type [455] = Y4668_pgtype426;
	Y4668_gen_type [456] = Y4668_pgtype427;
	Y4668_gen_type [457] = Y4668_pgtype428;
	Y4668_gen_type [458] = Y4668_pgtype429;
	Y4668_gen_type [459] = Y4668_pgtype430;
	Y4668_gen_type [460] = Y4668_pgtype431;
	Y4668_gen_type [461] = Y4668_pgtype432;
	Y4668_gen_type [462] = Y4668_pgtype433;
	Y4668_gen_type [463] = Y4668_pgtype434;
	Y4668_gen_type [464] = Y4668_pgtype435;
	Y4668_gen_type [465] = Y4668_pgtype436;
	Y4668_gen_type [466] = Y4668_pgtype437;
	Y4668_gen_type [467] = Y4668_pgtype438;
	Y4668_gen_type [468] = Y4668_pgtype439;
	Y4668_gen_type [469] = Y4668_pgtype440;
	Y4668_gen_type [470] = Y4668_pgtype441;
	Y4668_gen_type [471] = Y4668_pgtype442;
	Y4668_gen_type [472] = Y4668_pgtype443;
	Y4668_gen_type [473] = Y4668_pgtype444;
	Y4668_gen_type [474] = Y4668_pgtype445;
	Y4668_gen_type [475] = Y4668_pgtype446;
	Y4668_gen_type [476] = Y4668_pgtype447;
	Y4668_gen_type [477] = Y4668_pgtype448;
	Y4668_gen_type [478] = Y4668_pgtype449;
	Y4668_gen_type [479] = Y4668_pgtype450;
	Y4668_gen_type [480] = Y4668_pgtype451;
	Y4668_gen_type [481] = Y4668_pgtype452;
	Y4668_gen_type [482] = Y4668_pgtype453;
	Y4668_gen_type [483] = Y4668_pgtype454;
	Y4668_gen_type [484] = Y4668_pgtype455;
	Y4668_gen_type [485] = Y4668_pgtype456;
	Y4668_gen_type [486] = Y4668_pgtype457;
	Y4668_gen_type [487] = Y4668_pgtype458;
	Y4668_gen_type [488] = Y4668_pgtype459;
	Y4668_gen_type [489] = Y4668_pgtype460;
	Y4668_gen_type [490] = Y4668_pgtype461;
	Y4668_gen_type [491] = Y4668_pgtype462;
	Y4668_gen_type [492] = Y4668_pgtype463;
	Y4668_gen_type [493] = Y4668_pgtype464;
	Y4668_gen_type [494] = Y4668_pgtype465;
	Y4668_gen_type [495] = Y4668_pgtype466;
	Y4668_gen_type [496] = Y4668_pgtype467;
	Y4668_gen_type [497] = Y4668_pgtype468;
	Y4668_gen_type [498] = Y4668_pgtype469;
	Y4668_gen_type [499] = Y4668_pgtype470;
	Y4668_gen_type [500] = Y4668_pgtype471;
	Y4668_gen_type [501] = Y4668_pgtype472;
	Y4668_gen_type [502] = Y4668_pgtype473;
	Y4668_gen_type [503] = Y4668_pgtype474;
	Y4668_gen_type [504] = Y4668_pgtype475;
	Y4668_gen_type [505] = Y4668_pgtype476;
	Y4668_gen_type [506] = Y4668_pgtype477;
	Y4668_gen_type [507] = Y4668_pgtype478;
	Y4668_gen_type [508] = Y4668_pgtype479;
	Y4668_gen_type [509] = Y4668_pgtype480;
	Y4668_gen_type [510] = Y4668_pgtype481;
	Y4668_gen_type [511] = Y4668_pgtype482;
	Y4668_gen_type [512] = Y4668_pgtype483;
	Y4668_gen_type [513] = Y4668_pgtype484;
	Y4668_gen_type [514] = Y4668_pgtype485;
	Y4668_gen_type [515] = Y4668_pgtype486;
	Y4668_gen_type [516] = Y4668_pgtype487;
	Y4668_gen_type [517] = Y4668_pgtype488;
	Y4668_gen_type [518] = Y4668_pgtype489;
	Y4668_gen_type [519] = Y4668_pgtype490;
	Y4668_gen_type [520] = Y4668_pgtype491;
	Y4668_gen_type [521] = Y4668_pgtype492;
	Y4668_gen_type [522] = Y4668_pgtype493;
	Y4668_gen_type [523] = Y4668_pgtype494;
	Y4668_gen_type [524] = Y4668_pgtype495;
	Y4668_gen_type [525] = Y4668_pgtype496;
	Y4668_gen_type [526] = Y4668_pgtype497;
	Y4668_gen_type [527] = Y4668_pgtype498;
	Y4668_gen_type [534] = Y4668_pgtype499;
	Y4668_gen_type [535] = Y4668_pgtype500;
	Y4668_gen_type [536] = Y4668_pgtype501;
	Y4668_gen_type [537] = Y4668_pgtype502;
	Y4668_gen_type [538] = Y4668_pgtype503;
	Y4668_gen_type [539] = Y4668_pgtype504;
	Y4668_gen_type [540] = Y4668_pgtype505;
	Y4668_gen_type [541] = Y4668_pgtype506;
	Y4668_gen_type [542] = Y4668_pgtype507;
	Y4668_gen_type [543] = Y4668_pgtype508;
	Y4668_gen_type [544] = Y4668_pgtype509;
	Y4668_gen_type [545] = Y4668_pgtype510;
	Y4668_gen_type [604] = Y4668_pgtype511;
	Y4668_gen_type [605] = Y4668_pgtype512;
	Y4668_gen_type [606] = Y4668_pgtype513;
	Y4668_gen_type [649] = Y4668_pgtype514;
	Y4668_gen_type [732] = Y4668_pgtype515;
	Y4668_gen_type [733] = Y4668_pgtype516;
	Y4668_gen_type [734] = Y4668_pgtype517;
	Y4668_gen_type [735] = Y4668_pgtype518;
	Y4668_gen_type [736] = Y4668_pgtype519;
	Y4668_gen_type [737] = Y4668_pgtype520;
	Y4668_gen_type [738] = Y4668_pgtype521;
	Y4668_gen_type [784] = Y4668_pgtype522;
	Y4668_gen_type [785] = Y4668_pgtype523;
	Y4668_gen_type [809] = Y4668_pgtype524;
	Y4668_gen_type [812] = Y4668_pgtype525;
	Y4668_gen_type [813] = Y4668_pgtype526;
	Y4668_gen_type [814] = Y4668_pgtype527;
	Y4668_gen_type [815] = Y4668_pgtype528;
	Y4668_gen_type [816] = Y4668_pgtype529;
	Y4668_gen_type [817] = Y4668_pgtype530;
	Y4668_gen_type [818] = Y4668_pgtype531;
	Y4668_gen_type [819] = Y4668_pgtype532;
	Y4668_gen_type [820] = Y4668_pgtype533;
	Y4668_gen_type [821] = Y4668_pgtype534;
	Y4668_gen_type [822] = Y4668_pgtype535;
	Y4668_gen_type [823] = Y4668_pgtype536;
	Y4668_gen_type [824] = Y4668_pgtype537;
	Y4668_gen_type [825] = Y4668_pgtype538;
	Y4668_gen_type [826] = Y4668_pgtype539;
	Y4668_gen_type [827] = Y4668_pgtype540;
	Y4668_gen_type [828] = Y4668_pgtype541;
	Y4668_gen_type [829] = Y4668_pgtype542;
	Y4668_gen_type [830] = Y4668_pgtype543;
	Y4668_gen_type [831] = Y4668_pgtype544;
	Y4668_gen_type [853] = Y4668_pgtype545;
	Y4668_gen_type [862] = Y4668_pgtype546;
	Y4668_gen_type [863] = Y4668_pgtype547;
	Y4668_gen_type [864] = Y4668_pgtype548;
	Y4668_gen_type [865] = Y4668_pgtype549;
	Y4668_gen_type [866] = Y4668_pgtype550;
	Y4668_gen_type [867] = Y4668_pgtype551;
	Y4668_gen_type [868] = Y4668_pgtype552;
	Y4668_gen_type [869] = Y4668_pgtype553;
	Y4668_gen_type [870] = Y4668_pgtype554;
	Y4668_gen_type [871] = Y4668_pgtype555;
	Y4668_gen_type [872] = Y4668_pgtype556;
	Y4668_gen_type [873] = Y4668_pgtype557;
	Y4668_gen_type [874] = Y4668_pgtype558;
	Y4668_gen_type [1072] = Y4668_pgtype559;
	Y4668[12] = 1058;
	{long i; for (i = 13; i < 28; i++) Y4668[i] = 1061;};
	{long i; for (i = 274; i < 276; i++) Y4668[i] = 1006;};
	Y4668[288] = 985;
	Y4668[350] = 1061;
	Y4668[363] = 0;
	Y4668[385] = 1097;
	{long i; for (i = 386; i < 407; i++) Y4668[i] = 1047;};
	Y4668[421] = 1006;
	Y4668[423] = 21;
	Y4668[424] = 994;
	Y4668[425] = 1006;
	Y4668[502] = 997;
	Y4668[503] = 994;
	{long i; for (i = 604; i < 607; i++) Y4668[i] = 997;};
	Y4668[649] = 0;
	{long i; for (i = 732; i < 736; i++) Y4668[i] = 997;};
	{long i; for (i = 736; i < 739; i++) Y4668[i] = 994;};
	{long i; for (i = 784; i < 786; i++) Y4668[i] = 1061;};
	{long i; for (i = 812; i < 832; i++) Y4668[i] = 1135;};
	Y4668[853] = 1062;
	Y4668[863] = 1177;
	Y4668[864] = 1178;
	{long i; for (i = 865; i < 868; i++) Y4668[i] = 1176;};
	{long i; for (i = 868; i < 872; i++) Y4668[i] = 1194;};
	{long i; for (i = 872; i < 875; i++) Y4668[i] = 1182;};
	Y4668[1072] = 997;
}

char *(*R4763[797])();
void R4763_init () {
	R4763[0] = (char *(*)()) F601_5391;
	R4763[1] = (char *(*)()) F602_5391_4763_2;
	R4763[2] = (char *(*)()) F603_5391_4763_2;
	R4763[3] = (char *(*)()) F604_5391_4763_2;
	R4763[4] = (char *(*)()) F605_5391_4763_2;
	R4763[5] = (char *(*)()) F606_5391_4763_2;
	R4763[6] = (char *(*)()) F607_5391_4763_2;
	R4763[7] = (char *(*)()) F608_5391_4763_2;
	R4763[8] = (char *(*)()) F609_5391_4763_2;
	R4763[9] = (char *(*)()) F610_5391_4763_2;
	R4763[10] = (char *(*)()) F611_5391_4763_2;
	R4763[11] = (char *(*)()) F612_5391_4763_2;
	R4763[61] = (char *(*)()) F614_5465;
	R4763[62] = (char *(*)()) F618_5465_4763_2;
	R4763[63] = (char *(*)()) F622_5465_4763_2;
	{long i; for (i = 64; i < 66; i++) R4763[i] = (char *(*)()) F614_5465;}
	R4763[66] = (char *(*)()) F618_5465_4763_2;
	R4763[67] = (char *(*)()) F622_5465_4763_2;
	R4763[68] = (char *(*)()) F614_5465;
	R4763[79] = (char *(*)()) F680_5804;
	R4763[80] = (char *(*)()) F681_5804_4763_2;
	R4763[81] = (char *(*)()) F682_5804_4763_2;
	R4763[82] = (char *(*)()) F683_5804;
	R4763[83] = (char *(*)()) F684_5804_4763_2;
	R4763[84] = (char *(*)()) F685_5804_4763_2;
	R4763[85] = (char *(*)()) F680_5804;
	R4763[86] = (char *(*)()) F681_5804_4763_2;
	R4763[87] = (char *(*)()) F680_5804;
	R4763[88] = (char *(*)()) F689_5937;
	R4763[89] = (char *(*)()) F690_5937_4763_2;
	R4763[90] = (char *(*)()) F691_5937_4763_2;
	R4763[91] = (char *(*)()) F692_5937_4763_2;
	R4763[92] = (char *(*)()) F693_5937_4763_2;
	R4763[93] = (char *(*)()) F694_5937_4763_2;
	R4763[94] = (char *(*)()) F695_5937_4763_2;
	R4763[95] = (char *(*)()) F696_5937_4763_2;
	R4763[96] = (char *(*)()) F697_5937_4763_2;
	R4763[97] = (char *(*)()) F698_5937_4763_2;
	R4763[98] = (char *(*)()) F699_5937_4763_2;
	R4763[99] = (char *(*)()) F700_5937_4763_2;
	R4763[107] = (char *(*)()) F689_5937;
	R4763[108] = (char *(*)()) F693_5937_4763_2;
	{long i; for (i = 109; i < 113; i++) R4763[i] = (char *(*)()) F689_5937;}
	R4763[117] = (char *(*)()) F689_5937;
	{long i; for (i = 120; i < 122; i++) R4763[i] = (char *(*)()) F689_5937;}
	R4763[125] = (char *(*)()) F689_5937;
	{long i; for (i = 127; i < 131; i++) R4763[i] = (char *(*)()) F689_5937;}
	R4763[145] = (char *(*)()) F746_6162_4763_2;
	R4763[149] = (char *(*)()) F750_6220_4763_2;
	{long i; for (i = 329; i < 331; i++) R4763[i] = (char *(*)()) F390_5191_4763_2;}
	R4763[458] = (char *(*)()) F1057_8932_4763_2;
	R4763[462] = (char *(*)()) F1061_9097_4763_2;
	{long i; for (i = 541; i < 543; i++) R4763[i] = (char *(*)()) F614_5465;}
	{long i; for (i = 543; i < 545; i++) R4763[i] = (char *(*)()) F1144_10091;}
	R4763[546] = (char *(*)()) F1144_10091;
	R4763[547] = (char *(*)()) F1148_10146;
	{long i; for (i = 550; i < 553; i++) R4763[i] = (char *(*)()) F1148_10146;}
	{long i; for (i = 554; i < 556; i++) R4763[i] = (char *(*)()) F1148_10146;}
	R4763[588] = (char *(*)()) F614_5465;
	R4763[598] = (char *(*)()) F614_5465;
	R4763[796] = (char *(*)()) F390_5191_4763_2;
}
static EIF_BOOLEAN F602_5391_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F602_5391(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F603_5391_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F603_5391(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F604_5391_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F604_5391(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F605_5391_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F605_5391(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F606_5391_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F606_5391(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F607_5391_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F607_5391(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F608_5391_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F608_5391(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F609_5391_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F609_5391(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F610_5391_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F610_5391(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F611_5391_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F611_5391(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F612_5391_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F612_5391(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F618_5465_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F618_5465(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F622_5465_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F622_5465(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F681_5804_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F681_5804(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F682_5804_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F682_5804(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F684_5804_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F684_5804(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F685_5804_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F685_5804(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F690_5937_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F690_5937(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F691_5937_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F691_5937(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F692_5937_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F692_5937(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F693_5937_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F693_5937(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F694_5937_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F694_5937(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F695_5937_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F695_5937(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F696_5937_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F696_5937(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F697_5937_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F697_5937(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F698_5937_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F698_5937(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F699_5937_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F699_5937(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F700_5937_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F700_5937(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F746_6162_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F746_6162(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F750_6220_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F750_6220(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F390_5191_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F390_5191(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1057_8932_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1057_8932(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1061_9097_4763_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1061_9097(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R4764[1025])();
void R4764_init () {
	R4764[0] = (char *(*)()) F371_5066;
	R4764[228] = (char *(*)()) F506_5267;
	R4764[229] = (char *(*)()) F507_5267;
	R4764[230] = (char *(*)()) F508_5267;
	R4764[231] = (char *(*)()) F511_5267;
	R4764[232] = (char *(*)()) F509_5267;
	R4764[233] = (char *(*)()) F512_5267;
	R4764[234] = (char *(*)()) F510_5267;
	R4764[235] = (char *(*)()) F513_5267;
	R4764[236] = (char *(*)()) F514_5267;
	R4764[237] = (char *(*)()) F515_5267;
	R4764[238] = (char *(*)()) F516_5267;
	R4764[239] = (char *(*)()) F517_5267;
	R4764[289] = (char *(*)()) F506_5267;
	R4764[290] = (char *(*)()) F509_5267;
	R4764[291] = (char *(*)()) F514_5267;
	{long i; for (i = 292; i < 294; i++) R4764[i] = (char *(*)()) F506_5267;}
	R4764[294] = (char *(*)()) F509_5267;
	R4764[295] = (char *(*)()) F514_5267;
	R4764[296] = (char *(*)()) F506_5267;
	R4764[307] = (char *(*)()) F506_5267;
	R4764[308] = (char *(*)()) F509_5267;
	R4764[309] = (char *(*)()) F515_5267;
	R4764[310] = (char *(*)()) F506_5267;
	{long i; for (i = 311; i < 313; i++) R4764[i] = (char *(*)()) F509_5267;}
	R4764[313] = (char *(*)()) F506_5267;
	R4764[314] = (char *(*)()) F509_5267;
	{long i; for (i = 315; i < 317; i++) R4764[i] = (char *(*)()) F506_5267;}
	R4764[317] = (char *(*)()) F507_5267;
	R4764[318] = (char *(*)()) F508_5267;
	R4764[319] = (char *(*)()) F511_5267;
	R4764[320] = (char *(*)()) F509_5267;
	R4764[321] = (char *(*)()) F512_5267;
	R4764[322] = (char *(*)()) F510_5267;
	R4764[323] = (char *(*)()) F513_5267;
	R4764[324] = (char *(*)()) F514_5267;
	R4764[325] = (char *(*)()) F515_5267;
	R4764[326] = (char *(*)()) F516_5267;
	R4764[327] = (char *(*)()) F517_5267;
	R4764[335] = (char *(*)()) F506_5267;
	R4764[336] = (char *(*)()) F509_5267;
	{long i; for (i = 337; i < 341; i++) R4764[i] = (char *(*)()) F506_5267;}
	R4764[345] = (char *(*)()) F506_5267;
	{long i; for (i = 348; i < 350; i++) R4764[i] = (char *(*)()) F506_5267;}
	R4764[353] = (char *(*)()) F506_5267;
	{long i; for (i = 355; i < 359; i++) R4764[i] = (char *(*)()) F506_5267;}
	R4764[373] = (char *(*)()) F503_5245;
	R4764[377] = (char *(*)()) F503_5245;
	{long i; for (i = 557; i < 559; i++) R4764[i] = (char *(*)()) F510_5267;}
	R4764[686] = (char *(*)()) F510_5267;
	R4764[690] = (char *(*)()) F512_5267;
	{long i; for (i = 769; i < 771; i++) R4764[i] = (char *(*)()) F506_5267;}
	{long i; for (i = 771; i < 773; i++) R4764[i] = (char *(*)()) F1144_10092;}
	{long i; for (i = 774; i < 776; i++) R4764[i] = (char *(*)()) F1144_10092;}
	{long i; for (i = 778; i < 781; i++) R4764[i] = (char *(*)()) F1144_10092;}
	{long i; for (i = 782; i < 784; i++) R4764[i] = (char *(*)()) F1144_10092;}
	R4764[816] = (char *(*)()) F506_5267;
	R4764[826] = (char *(*)()) F506_5267;
	R4764[1024] = (char *(*)()) F1397_13938;
}

char *(*R4768[1025])();
void R4768_init () {
	R4768[0] = (char *(*)()) F359_5038;
	R4768[228] = (char *(*)()) F359_5038;
	R4768[229] = (char *(*)()) F360_5038;
	R4768[230] = (char *(*)()) F361_5038;
	R4768[231] = (char *(*)()) F364_5038;
	R4768[232] = (char *(*)()) F362_5038;
	R4768[233] = (char *(*)()) F365_5038;
	R4768[234] = (char *(*)()) F363_5038;
	R4768[235] = (char *(*)()) F366_5038;
	R4768[236] = (char *(*)()) F367_5038;
	R4768[237] = (char *(*)()) F368_5038;
	R4768[238] = (char *(*)()) F369_5038;
	R4768[239] = (char *(*)()) F370_5038;
	R4768[289] = (char *(*)()) F359_5038;
	R4768[290] = (char *(*)()) F362_5038;
	R4768[291] = (char *(*)()) F367_5038;
	{long i; for (i = 292; i < 294; i++) R4768[i] = (char *(*)()) F359_5038;}
	R4768[294] = (char *(*)()) F362_5038;
	R4768[295] = (char *(*)()) F367_5038;
	R4768[296] = (char *(*)()) F359_5038;
	R4768[307] = (char *(*)()) F359_5038;
	R4768[308] = (char *(*)()) F362_5038;
	R4768[309] = (char *(*)()) F368_5038;
	R4768[310] = (char *(*)()) F359_5038;
	{long i; for (i = 311; i < 313; i++) R4768[i] = (char *(*)()) F362_5038;}
	R4768[313] = (char *(*)()) F359_5038;
	R4768[314] = (char *(*)()) F362_5038;
	{long i; for (i = 315; i < 317; i++) R4768[i] = (char *(*)()) F359_5038;}
	R4768[317] = (char *(*)()) F360_5038;
	R4768[318] = (char *(*)()) F361_5038;
	R4768[319] = (char *(*)()) F364_5038;
	R4768[320] = (char *(*)()) F362_5038;
	R4768[321] = (char *(*)()) F365_5038;
	R4768[322] = (char *(*)()) F363_5038;
	R4768[323] = (char *(*)()) F366_5038;
	R4768[324] = (char *(*)()) F367_5038;
	R4768[325] = (char *(*)()) F368_5038;
	R4768[326] = (char *(*)()) F369_5038;
	R4768[327] = (char *(*)()) F370_5038;
	R4768[335] = (char *(*)()) F359_5038;
	R4768[336] = (char *(*)()) F362_5038;
	{long i; for (i = 337; i < 341; i++) R4768[i] = (char *(*)()) F359_5038;}
	R4768[345] = (char *(*)()) F359_5038;
	{long i; for (i = 348; i < 350; i++) R4768[i] = (char *(*)()) F359_5038;}
	R4768[353] = (char *(*)()) F359_5038;
	{long i; for (i = 355; i < 359; i++) R4768[i] = (char *(*)()) F359_5038;}
	R4768[373] = (char *(*)()) F362_5038;
	R4768[377] = (char *(*)()) F362_5038;
	{long i; for (i = 557; i < 559; i++) R4768[i] = (char *(*)()) F363_5038;}
	R4768[686] = (char *(*)()) F363_5038;
	R4768[690] = (char *(*)()) F365_5038;
	{long i; for (i = 769; i < 773; i++) R4768[i] = (char *(*)()) F359_5038;}
	{long i; for (i = 774; i < 776; i++) R4768[i] = (char *(*)()) F359_5038;}
	{long i; for (i = 778; i < 781; i++) R4768[i] = (char *(*)()) F359_5038;}
	{long i; for (i = 782; i < 784; i++) R4768[i] = (char *(*)()) F359_5038;}
	R4768[816] = (char *(*)()) F359_5038;
	R4768[826] = (char *(*)()) F359_5038;
	R4768[1024] = (char *(*)()) F363_5038;
}

char *(*R4770[1025])();
void R4770_init () {
	R4770[0] = (char *(*)()) F371_5093;
	R4770[228] = (char *(*)()) F601_5435;
	R4770[229] = (char *(*)()) F602_5435;
	R4770[230] = (char *(*)()) F603_5435;
	R4770[231] = (char *(*)()) F604_5435;
	R4770[232] = (char *(*)()) F605_5435;
	R4770[233] = (char *(*)()) F606_5435;
	R4770[234] = (char *(*)()) F607_5435;
	R4770[235] = (char *(*)()) F608_5435;
	R4770[236] = (char *(*)()) F609_5435;
	R4770[237] = (char *(*)()) F610_5435;
	R4770[238] = (char *(*)()) F611_5435;
	R4770[239] = (char *(*)()) F612_5435;
	R4770[289] = (char *(*)()) F386_5206;
	R4770[290] = (char *(*)()) F389_5206;
	R4770[291] = (char *(*)()) F394_5206;
	R4770[292] = (char *(*)()) F665_5565;
	R4770[293] = (char *(*)()) F666_5584;
	R4770[294] = (char *(*)()) F667_5584;
	R4770[295] = (char *(*)()) F668_5584;
	R4770[296] = (char *(*)()) F386_5206;
	R4770[307] = (char *(*)()) F680_5850;
	R4770[308] = (char *(*)()) F681_5850;
	R4770[309] = (char *(*)()) F682_5850;
	R4770[310] = (char *(*)()) F683_5850;
	R4770[311] = (char *(*)()) F684_5850;
	R4770[312] = (char *(*)()) F685_5850;
	R4770[313] = (char *(*)()) F680_5850;
	R4770[314] = (char *(*)()) F681_5850;
	R4770[315] = (char *(*)()) F680_5850;
	R4770[316] = (char *(*)()) F386_5206;
	R4770[317] = (char *(*)()) F387_5206;
	R4770[318] = (char *(*)()) F388_5206;
	R4770[319] = (char *(*)()) F391_5206;
	R4770[320] = (char *(*)()) F389_5206;
	R4770[321] = (char *(*)()) F392_5206;
	R4770[322] = (char *(*)()) F390_5206;
	R4770[323] = (char *(*)()) F393_5206;
	R4770[324] = (char *(*)()) F394_5206;
	R4770[325] = (char *(*)()) F395_5206;
	R4770[326] = (char *(*)()) F396_5206;
	R4770[327] = (char *(*)()) F397_5206;
	R4770[335] = (char *(*)()) F386_5206;
	R4770[336] = (char *(*)()) F389_5206;
	{long i; for (i = 337; i < 341; i++) R4770[i] = (char *(*)()) F386_5206;}
	R4770[345] = (char *(*)()) F386_5206;
	{long i; for (i = 348; i < 350; i++) R4770[i] = (char *(*)()) F386_5206;}
	R4770[353] = (char *(*)()) F386_5206;
	{long i; for (i = 355; i < 359; i++) R4770[i] = (char *(*)()) F386_5206;}
	R4770[373] = (char *(*)()) F505_5260;
	R4770[377] = (char *(*)()) F505_5260;
	{long i; for (i = 557; i < 559; i++) R4770[i] = (char *(*)()) F390_5206;}
	R4770[686] = (char *(*)()) F1059_9053;
	R4770[690] = (char *(*)()) F1063_9221;
	{long i; for (i = 769; i < 771; i++) R4770[i] = (char *(*)()) F386_5206;}
	{long i; for (i = 771; i < 773; i++) R4770[i] = (char *(*)()) F1144_10101;}
	{long i; for (i = 774; i < 776; i++) R4770[i] = (char *(*)()) F1144_10101;}
	{long i; for (i = 778; i < 781; i++) R4770[i] = (char *(*)()) F1144_10101;}
	{long i; for (i = 782; i < 784; i++) R4770[i] = (char *(*)()) F1144_10101;}
	R4770[816] = (char *(*)()) F386_5206;
	R4770[826] = (char *(*)()) F386_5206;
	R4770[1024] = (char *(*)()) F390_5206;
}

EIF_TYPE_INDEX *Y4777_gen_type [3];
EIF_TYPE_INDEX Y4777 [3];
void Y4777_init (void)
{
	egc_routines_types [4777] = Y4777;
	egc_routines_gen_types [4777] = Y4777_gen_type;
	egc_routines_offset [4777] = 370;
	{long i; for (i = 0; i < 3; i++) Y4777[i] = 1006;};
}

char *(*R4873[736])();
void R4873_init () {
	R4873[0] = (char *(*)()) F662_5515;
	R4873[1] = (char *(*)()) F663_5515_4873_1;
	R4873[2] = (char *(*)()) F664_5515_4873_1;
	{long i; for (i = 3; i < 5; i++) R4873[i] = (char *(*)()) F662_5515;}
	R4873[5] = (char *(*)()) F663_5515_4873_1;
	R4873[6] = (char *(*)()) F664_5515_4873_1;
	R4873[7] = (char *(*)()) F662_5515;
	R4873[27] = (char *(*)()) F689_5930;
	R4873[28] = (char *(*)()) F690_5930_4873_1;
	R4873[29] = (char *(*)()) F691_5930_4873_1;
	R4873[30] = (char *(*)()) F692_5930_4873_1;
	R4873[31] = (char *(*)()) F693_5930_4873_1;
	R4873[32] = (char *(*)()) F694_5930_4873_1;
	R4873[33] = (char *(*)()) F695_5930_4873_1;
	R4873[34] = (char *(*)()) F696_5930_4873_1;
	R4873[35] = (char *(*)()) F697_5930_4873_1;
	R4873[36] = (char *(*)()) F698_5930_4873_1;
	R4873[37] = (char *(*)()) F699_5930_4873_1;
	R4873[38] = (char *(*)()) F700_5930_4873_1;
	R4873[46] = (char *(*)()) F689_5930;
	R4873[47] = (char *(*)()) F693_5930_4873_1;
	{long i; for (i = 48; i < 52; i++) R4873[i] = (char *(*)()) F689_5930;}
	R4873[56] = (char *(*)()) F689_5930;
	{long i; for (i = 59; i < 61; i++) R4873[i] = (char *(*)()) F689_5930;}
	R4873[64] = (char *(*)()) F689_5930;
	{long i; for (i = 66; i < 70; i++) R4873[i] = (char *(*)()) F689_5930;}
	R4873[84] = (char *(*)()) F505_5249_4873_1;
	R4873[88] = (char *(*)()) F505_5249_4873_1;
	{long i; for (i = 268; i < 270; i++) R4873[i] = (char *(*)()) F929_6978_4873_1;}
	{long i; for (i = 480; i < 482; i++) R4873[i] = (char *(*)()) F1134_9920;}
	R4873[527] = (char *(*)()) F1134_9920;
	R4873[537] = (char *(*)()) F1134_9920;
	R4873[735] = (char *(*)()) F929_6978_4873_1;
}
static EIF_REFERENCE F663_5515_4873_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F663_5515(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5515_4873_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F664_5515(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F690_5930_4873_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F690_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(976, 0x00).id, 976, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F691_5930_4873_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F691_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(985, 0x00).id, 985, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F692_5930_4873_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F692_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(979, 0x00).id, 979, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F693_5930_4873_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F693_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F694_5930_4873_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F694_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F695_5930_4873_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F695_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F696_5930_4873_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F696_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(982, 0x00).id, 982, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F697_5930_4873_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F697_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F698_5930_4873_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F698_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F699_5930_4873_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F699_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(988, 0x00).id, 988, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F700_5930_4873_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F700_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F505_5249_4873_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F505_5249(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F929_6978_4873_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F929_6978(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4874[736])();
void R4874_init () {
	R4874[0] = (char *(*)()) F662_5526;
	R4874[1] = (char *(*)()) F663_5526;
	R4874[2] = (char *(*)()) F664_5526;
	{long i; for (i = 3; i < 5; i++) R4874[i] = (char *(*)()) F662_5526;}
	R4874[5] = (char *(*)()) F663_5526;
	R4874[6] = (char *(*)()) F664_5526;
	R4874[7] = (char *(*)()) F662_5526;
	R4874[27] = (char *(*)()) F614_5478;
	R4874[28] = (char *(*)()) F615_5478;
	R4874[29] = (char *(*)()) F616_5478;
	R4874[30] = (char *(*)()) F617_5478;
	R4874[31] = (char *(*)()) F618_5478;
	R4874[32] = (char *(*)()) F619_5478;
	R4874[33] = (char *(*)()) F620_5478;
	R4874[34] = (char *(*)()) F621_5478;
	R4874[35] = (char *(*)()) F622_5478;
	R4874[36] = (char *(*)()) F623_5478;
	R4874[37] = (char *(*)()) F624_5478;
	R4874[38] = (char *(*)()) F625_5478;
	R4874[46] = (char *(*)()) F614_5478;
	R4874[47] = (char *(*)()) F618_5478;
	{long i; for (i = 48; i < 52; i++) R4874[i] = (char *(*)()) F614_5478;}
	R4874[56] = (char *(*)()) F614_5478;
	{long i; for (i = 59; i < 61; i++) R4874[i] = (char *(*)()) F614_5478;}
	R4874[64] = (char *(*)()) F614_5478;
	{long i; for (i = 66; i < 70; i++) R4874[i] = (char *(*)()) F614_5478;}
	R4874[84] = (char *(*)()) F389_5199;
	R4874[88] = (char *(*)()) F389_5199;
	{long i; for (i = 268; i < 270; i++) R4874[i] = (char *(*)()) F929_6999;}
	{long i; for (i = 480; i < 482; i++) R4874[i] = (char *(*)()) F614_5478;}
	R4874[527] = (char *(*)()) F614_5478;
	R4874[537] = (char *(*)()) F614_5478;
	R4874[735] = (char *(*)()) F929_6999;
}

char *(*R4875[736])();
void R4875_init () {
	R4875[0] = (char *(*)()) F662_5532;
	R4875[1] = (char *(*)()) F663_5532;
	R4875[2] = (char *(*)()) F664_5532;
	{long i; for (i = 3; i < 5; i++) R4875[i] = (char *(*)()) F662_5532;}
	R4875[5] = (char *(*)()) F663_5532;
	R4875[6] = (char *(*)()) F664_5532;
	R4875[7] = (char *(*)()) F662_5532;
	R4875[27] = (char *(*)()) F689_5956;
	R4875[28] = (char *(*)()) F690_5956;
	R4875[29] = (char *(*)()) F691_5956;
	R4875[30] = (char *(*)()) F692_5956;
	R4875[31] = (char *(*)()) F693_5956;
	R4875[32] = (char *(*)()) F694_5956;
	R4875[33] = (char *(*)()) F695_5956;
	R4875[34] = (char *(*)()) F696_5956;
	R4875[35] = (char *(*)()) F697_5956;
	R4875[36] = (char *(*)()) F698_5956;
	R4875[37] = (char *(*)()) F699_5956;
	R4875[38] = (char *(*)()) F700_5956;
	R4875[46] = (char *(*)()) F689_5956;
	R4875[47] = (char *(*)()) F693_5956;
	{long i; for (i = 48; i < 52; i++) R4875[i] = (char *(*)()) F689_5956;}
	R4875[56] = (char *(*)()) F689_5956;
	{long i; for (i = 59; i < 61; i++) R4875[i] = (char *(*)()) F689_5956;}
	R4875[64] = (char *(*)()) F689_5956;
	{long i; for (i = 66; i < 70; i++) R4875[i] = (char *(*)()) F689_5956;}
	R4875[84] = (char *(*)()) F505_5257;
	R4875[88] = (char *(*)()) F505_5257;
	{long i; for (i = 268; i < 270; i++) R4875[i] = (char *(*)()) F929_7054;}
	{long i; for (i = 480; i < 482; i++) R4875[i] = (char *(*)()) F1134_9930;}
	R4875[527] = (char *(*)()) F1134_9930;
	R4875[537] = (char *(*)()) F1134_9930;
	R4875[735] = (char *(*)()) F929_7054;
}

char *(*R4876[736])();
void R4876_init () {
	R4876[0] = (char *(*)()) F386_5202;
	R4876[1] = (char *(*)()) F389_5202;
	R4876[2] = (char *(*)()) F394_5202;
	{long i; for (i = 3; i < 5; i++) R4876[i] = (char *(*)()) F386_5202;}
	R4876[5] = (char *(*)()) F389_5202;
	R4876[6] = (char *(*)()) F394_5202;
	R4876[7] = (char *(*)()) F386_5202;
	R4876[27] = (char *(*)()) F689_5940;
	R4876[28] = (char *(*)()) F690_5940;
	R4876[29] = (char *(*)()) F691_5940;
	R4876[30] = (char *(*)()) F692_5940;
	R4876[31] = (char *(*)()) F693_5940;
	R4876[32] = (char *(*)()) F694_5940;
	R4876[33] = (char *(*)()) F695_5940;
	R4876[34] = (char *(*)()) F696_5940;
	R4876[35] = (char *(*)()) F697_5940;
	R4876[36] = (char *(*)()) F698_5940;
	R4876[37] = (char *(*)()) F699_5940;
	R4876[38] = (char *(*)()) F700_5940;
	R4876[46] = (char *(*)()) F689_5940;
	R4876[47] = (char *(*)()) F693_5940;
	{long i; for (i = 48; i < 52; i++) R4876[i] = (char *(*)()) F689_5940;}
	R4876[56] = (char *(*)()) F689_5940;
	{long i; for (i = 59; i < 61; i++) R4876[i] = (char *(*)()) F689_5940;}
	R4876[64] = (char *(*)()) F689_5940;
	{long i; for (i = 66; i < 70; i++) R4876[i] = (char *(*)()) F689_5940;}
	R4876[84] = (char *(*)()) F389_5202;
	R4876[88] = (char *(*)()) F389_5202;
	{long i; for (i = 268; i < 270; i++) R4876[i] = (char *(*)()) F390_5202;}
	{long i; for (i = 480; i < 482; i++) R4876[i] = (char *(*)()) F386_5202;}
	R4876[527] = (char *(*)()) F386_5202;
	R4876[537] = (char *(*)()) F386_5202;
	R4876[735] = (char *(*)()) F390_5202;
}

char *(*R4881[736])();
void R4881_init () {
	R4881[0] = (char *(*)()) F398_5210;
	R4881[1] = (char *(*)()) F402_5210_4881_4;
	R4881[2] = (char *(*)()) F406_5210_4881_4;
	{long i; for (i = 3; i < 5; i++) R4881[i] = (char *(*)()) F398_5210;}
	R4881[5] = (char *(*)()) F402_5210_4881_4;
	R4881[6] = (char *(*)()) F406_5210_4881_4;
	R4881[7] = (char *(*)()) F398_5210;
	R4881[27] = (char *(*)()) F689_5962;
	R4881[28] = (char *(*)()) F690_5962_4881_4;
	R4881[29] = (char *(*)()) F691_5962_4881_4;
	R4881[30] = (char *(*)()) F692_5962_4881_4;
	R4881[31] = (char *(*)()) F693_5962_4881_4;
	R4881[32] = (char *(*)()) F694_5962_4881_4;
	R4881[33] = (char *(*)()) F695_5962_4881_4;
	R4881[34] = (char *(*)()) F696_5962_4881_4;
	R4881[35] = (char *(*)()) F697_5962_4881_4;
	R4881[36] = (char *(*)()) F698_5962_4881_4;
	R4881[37] = (char *(*)()) F699_5962_4881_4;
	R4881[38] = (char *(*)()) F700_5962_4881_4;
	R4881[46] = (char *(*)()) F689_5962;
	R4881[47] = (char *(*)()) F693_5962_4881_4;
	{long i; for (i = 48; i < 52; i++) R4881[i] = (char *(*)()) F689_5962;}
	R4881[56] = (char *(*)()) F689_5962;
	{long i; for (i = 59; i < 61; i++) R4881[i] = (char *(*)()) F689_5962;}
	R4881[64] = (char *(*)()) F689_5962;
	{long i; for (i = 66; i < 70; i++) R4881[i] = (char *(*)()) F689_5962;}
	R4881[84] = (char *(*)()) F389_5193_4881_4;
	R4881[88] = (char *(*)()) F389_5193_4881_4;
	{long i; for (i = 268; i < 270; i++) R4881[i] = (char *(*)()) F404_5210_4881_4;}
	{long i; for (i = 480; i < 482; i++) R4881[i] = (char *(*)()) F398_5210;}
	R4881[527] = (char *(*)()) F398_5210;
	R4881[537] = (char *(*)()) F398_5210;
	R4881[735] = (char *(*)()) F404_5210_4881_4;
}
static void F402_5210_4881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F402_5210(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F406_5210_4881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F406_5210(Current, *(EIF_BOOLEAN *)arg1);
}
static void F690_5962_4881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F690_5962(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F691_5962_4881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F691_5962(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F692_5962_4881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F692_5962(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F693_5962_4881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F693_5962(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F694_5962_4881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F694_5962(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F695_5962_4881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F695_5962(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F696_5962_4881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F696_5962(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F697_5962_4881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F697_5962(Current, *(EIF_BOOLEAN *)arg1);
}
static void F698_5962_4881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F698_5962(Current, *(EIF_POINTER *)arg1);
}
static void F699_5962_4881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F699_5962(Current, *(EIF_REAL_32 *)arg1);
}
static void F700_5962_4881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F700_5962(Current, *(EIF_REAL_64 *)arg1);
}
static void F389_5193_4881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F389_5193(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F404_5210_4881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F404_5210(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4882[736])();
void R4882_init () {
	R4882[0] = (char *(*)()) F662_5518;
	R4882[1] = (char *(*)()) F663_5518;
	R4882[2] = (char *(*)()) F664_5518;
	{long i; for (i = 3; i < 5; i++) R4882[i] = (char *(*)()) F662_5518;}
	R4882[5] = (char *(*)()) F663_5518;
	R4882[6] = (char *(*)()) F664_5518;
	R4882[7] = (char *(*)()) F662_5518;
	R4882[27] = (char *(*)()) F689_5935;
	R4882[28] = (char *(*)()) F690_5935;
	R4882[29] = (char *(*)()) F691_5935;
	R4882[30] = (char *(*)()) F692_5935;
	R4882[31] = (char *(*)()) F693_5935;
	R4882[32] = (char *(*)()) F694_5935;
	R4882[33] = (char *(*)()) F695_5935;
	R4882[34] = (char *(*)()) F696_5935;
	R4882[35] = (char *(*)()) F697_5935;
	R4882[36] = (char *(*)()) F698_5935;
	R4882[37] = (char *(*)()) F699_5935;
	R4882[38] = (char *(*)()) F700_5935;
	R4882[46] = (char *(*)()) F689_5935;
	R4882[47] = (char *(*)()) F693_5935;
	{long i; for (i = 48; i < 52; i++) R4882[i] = (char *(*)()) F689_5935;}
	R4882[56] = (char *(*)()) F689_5935;
	{long i; for (i = 59; i < 61; i++) R4882[i] = (char *(*)()) F689_5935;}
	R4882[64] = (char *(*)()) F689_5935;
	{long i; for (i = 66; i < 70; i++) R4882[i] = (char *(*)()) F689_5935;}
	R4882[84] = (char *(*)()) F505_5248;
	R4882[88] = (char *(*)()) F505_5248;
	{long i; for (i = 268; i < 270; i++) R4882[i] = (char *(*)()) F929_6979;}
	{long i; for (i = 480; i < 482; i++) R4882[i] = (char *(*)()) F1134_9921;}
	R4882[527] = (char *(*)()) F1134_9921;
	R4882[537] = (char *(*)()) F1134_9921;
	R4882[735] = (char *(*)()) F929_6979;
}


#ifdef __cplusplus
}
#endif
