#include "epoly8.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4908[384])();
void R4908_init () {
	R4908[0] = (char *(*)()) F680_5846;
	R4908[1] = (char *(*)()) F681_5846;
	R4908[2] = (char *(*)()) F682_5846;
	R4908[3] = (char *(*)()) F683_5846_4908_4;
	R4908[4] = (char *(*)()) F684_5846_4908_4;
	R4908[5] = (char *(*)()) F685_5846_4908_4;
	R4908[6] = (char *(*)()) F680_5846;
	R4908[7] = (char *(*)()) F681_5846;
	R4908[8] = (char *(*)()) F680_5846;
	R4908[379] = (char *(*)()) F1059_9031_4908_4;
	R4908[383] = (char *(*)()) F1063_9199_4908_4;
}
static void F683_5846_4908_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F683_5846(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F684_5846_4908_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F684_5846(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F685_5846_4908_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F685_5846(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1059_9031_4908_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1059_9031(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1063_9199_4908_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1063_9199(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4909[736])();
void R4909_init () {
	R4909[0] = (char *(*)()) F662_5515;
	R4909[1] = (char *(*)()) F663_5515_4909_1;
	R4909[2] = (char *(*)()) F664_5515_4909_1;
	R4909[3] = (char *(*)()) F665_5561;
	R4909[4] = (char *(*)()) F666_5579;
	R4909[5] = (char *(*)()) F667_5579_4909_1;
	R4909[6] = (char *(*)()) F668_5579_4909_1;
	R4909[7] = (char *(*)()) F662_5515;
	R4909[27] = (char *(*)()) F689_5930;
	R4909[28] = (char *(*)()) F690_5930_4909_1;
	R4909[29] = (char *(*)()) F691_5930_4909_1;
	R4909[30] = (char *(*)()) F692_5930_4909_1;
	R4909[31] = (char *(*)()) F693_5930_4909_1;
	R4909[32] = (char *(*)()) F694_5930_4909_1;
	R4909[33] = (char *(*)()) F695_5930_4909_1;
	R4909[34] = (char *(*)()) F696_5930_4909_1;
	R4909[35] = (char *(*)()) F697_5930_4909_1;
	R4909[36] = (char *(*)()) F698_5930_4909_1;
	R4909[37] = (char *(*)()) F699_5930_4909_1;
	R4909[38] = (char *(*)()) F700_5930_4909_1;
	R4909[46] = (char *(*)()) F689_5930;
	R4909[47] = (char *(*)()) F693_5930_4909_1;
	{long i; for (i = 48; i < 52; i++) R4909[i] = (char *(*)()) F689_5930;}
	R4909[56] = (char *(*)()) F689_5930;
	{long i; for (i = 59; i < 61; i++) R4909[i] = (char *(*)()) F689_5930;}
	R4909[64] = (char *(*)()) F689_5930;
	{long i; for (i = 66; i < 70; i++) R4909[i] = (char *(*)()) F689_5930;}
	R4909[84] = (char *(*)()) F505_5249_4909_1;
	R4909[88] = (char *(*)()) F505_5249_4909_1;
	{long i; for (i = 268; i < 270; i++) R4909[i] = (char *(*)()) F929_6978_4909_1;}
	{long i; for (i = 480; i < 482; i++) R4909[i] = (char *(*)()) F1134_9920;}
	R4909[527] = (char *(*)()) F1134_9920;
	R4909[537] = (char *(*)()) F1134_9920;
	R4909[735] = (char *(*)()) F929_6978_4909_1;
}
static EIF_REFERENCE F663_5515_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F663_5515(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5515_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F664_5515(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5579_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F667_5579(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5579_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F668_5579(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F690_5930_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F690_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(976, 0x00).id, 976, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F691_5930_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F691_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(985, 0x00).id, 985, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F692_5930_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F692_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(979, 0x00).id, 979, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F693_5930_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F693_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F694_5930_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F694_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F695_5930_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F695_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F696_5930_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F696_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(982, 0x00).id, 982, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F697_5930_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F697_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F698_5930_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F698_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F699_5930_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F699_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(988, 0x00).id, 988, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F700_5930_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F700_5930(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F505_5249_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F505_5249(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F929_6978_4909_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F929_6978(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y4909_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype124[] = {1047,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype125[] = {1047,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype126[] = {1047,0xFFF9,1,973,0,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype127[] = {1047,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype128[] = {1047,0xFFF9,1,973,1006,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype129[] = {1047,0xFFF9,1,973,1177,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype130[] = {1047,0xFFF9,1,973,1006,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype131[] = {1047,0xFFF9,1,973,1182,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype132[] = {1047,0xFFF9,1,973,1135,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype133[] = {1047,0xFFF9,1,973,935,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype134[] = {1047,0xFFF9,1,973,1110,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype135[] = {1047,0xFFF9,1,973,1394,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype136[] = {1047,0xFFF9,1,973,1006,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype137[] = {1047,0xFFF9,5,973,979,1006,1006,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype138[] = {1047,0xFFF9,1,973,1062,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype139[] = {1047,0xFFF9,7,973,1006,1006,991,991,991,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype140[] = {1047,0xFFF9,2,973,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype141[] = {1047,0xFFF9,3,973,1006,1006,935,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype142[] = {1047,0xFFF9,8,973,1006,1006,1006,991,991,991,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype143[] = {1047,0xFFF9,0,973,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype144[] = {1047,0xFFF9,4,973,1006,1006,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4909_pgtype146[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y4909_gen_type [931];
EIF_TYPE_INDEX Y4909 [931];
void Y4909_init (void)
{
	egc_routines_types [4909] = Y4909;
	egc_routines_gen_types [4909] = Y4909_gen_type;
	egc_routines_offset [4909] = 466;
	Y4909_gen_type [0] = Y4909_pgtype0;
	Y4909_gen_type [1] = Y4909_pgtype1;
	Y4909_gen_type [2] = Y4909_pgtype2;
	Y4909_gen_type [3] = Y4909_pgtype3;
	Y4909_gen_type [4] = Y4909_pgtype4;
	Y4909_gen_type [5] = Y4909_pgtype5;
	Y4909_gen_type [6] = Y4909_pgtype6;
	Y4909_gen_type [7] = Y4909_pgtype7;
	Y4909_gen_type [8] = Y4909_pgtype8;
	Y4909_gen_type [9] = Y4909_pgtype9;
	Y4909_gen_type [10] = Y4909_pgtype10;
	Y4909_gen_type [11] = Y4909_pgtype11;
	Y4909_gen_type [12] = Y4909_pgtype12;
	Y4909_gen_type [13] = Y4909_pgtype13;
	Y4909_gen_type [14] = Y4909_pgtype14;
	Y4909_gen_type [15] = Y4909_pgtype15;
	Y4909_gen_type [16] = Y4909_pgtype16;
	Y4909_gen_type [17] = Y4909_pgtype17;
	Y4909_gen_type [18] = Y4909_pgtype18;
	Y4909_gen_type [19] = Y4909_pgtype19;
	Y4909_gen_type [20] = Y4909_pgtype20;
	Y4909_gen_type [21] = Y4909_pgtype21;
	Y4909_gen_type [22] = Y4909_pgtype22;
	Y4909_gen_type [23] = Y4909_pgtype23;
	Y4909_gen_type [38] = Y4909_pgtype24;
	Y4909_gen_type [75] = Y4909_pgtype25;
	Y4909_gen_type [76] = Y4909_pgtype26;
	Y4909_gen_type [77] = Y4909_pgtype27;
	Y4909_gen_type [78] = Y4909_pgtype28;
	Y4909_gen_type [79] = Y4909_pgtype29;
	Y4909_gen_type [80] = Y4909_pgtype30;
	Y4909_gen_type [81] = Y4909_pgtype31;
	Y4909_gen_type [82] = Y4909_pgtype32;
	Y4909_gen_type [83] = Y4909_pgtype33;
	Y4909_gen_type [84] = Y4909_pgtype34;
	Y4909_gen_type [85] = Y4909_pgtype35;
	Y4909_gen_type [86] = Y4909_pgtype36;
	Y4909_gen_type [87] = Y4909_pgtype37;
	Y4909_gen_type [88] = Y4909_pgtype38;
	Y4909_gen_type [89] = Y4909_pgtype39;
	Y4909_gen_type [90] = Y4909_pgtype40;
	Y4909_gen_type [91] = Y4909_pgtype41;
	Y4909_gen_type [92] = Y4909_pgtype42;
	Y4909_gen_type [93] = Y4909_pgtype43;
	Y4909_gen_type [94] = Y4909_pgtype44;
	Y4909_gen_type [95] = Y4909_pgtype45;
	Y4909_gen_type [147] = Y4909_pgtype46;
	Y4909_gen_type [148] = Y4909_pgtype47;
	Y4909_gen_type [149] = Y4909_pgtype48;
	Y4909_gen_type [150] = Y4909_pgtype49;
	Y4909_gen_type [151] = Y4909_pgtype50;
	Y4909_gen_type [152] = Y4909_pgtype51;
	Y4909_gen_type [153] = Y4909_pgtype52;
	Y4909_gen_type [154] = Y4909_pgtype53;
	Y4909_gen_type [155] = Y4909_pgtype54;
	Y4909_gen_type [156] = Y4909_pgtype55;
	Y4909_gen_type [157] = Y4909_pgtype56;
	Y4909_gen_type [158] = Y4909_pgtype57;
	Y4909_gen_type [159] = Y4909_pgtype58;
	Y4909_gen_type [160] = Y4909_pgtype59;
	Y4909_gen_type [161] = Y4909_pgtype60;
	Y4909_gen_type [162] = Y4909_pgtype61;
	Y4909_gen_type [163] = Y4909_pgtype62;
	Y4909_gen_type [164] = Y4909_pgtype63;
	Y4909_gen_type [165] = Y4909_pgtype64;
	Y4909_gen_type [166] = Y4909_pgtype65;
	Y4909_gen_type [167] = Y4909_pgtype66;
	Y4909_gen_type [168] = Y4909_pgtype67;
	Y4909_gen_type [169] = Y4909_pgtype68;
	Y4909_gen_type [170] = Y4909_pgtype69;
	Y4909_gen_type [171] = Y4909_pgtype70;
	Y4909_gen_type [172] = Y4909_pgtype71;
	Y4909_gen_type [173] = Y4909_pgtype72;
	Y4909_gen_type [174] = Y4909_pgtype73;
	Y4909_gen_type [175] = Y4909_pgtype74;
	Y4909_gen_type [176] = Y4909_pgtype75;
	Y4909_gen_type [177] = Y4909_pgtype76;
	Y4909_gen_type [178] = Y4909_pgtype77;
	Y4909_gen_type [179] = Y4909_pgtype78;
	Y4909_gen_type [180] = Y4909_pgtype79;
	Y4909_gen_type [181] = Y4909_pgtype80;
	Y4909_gen_type [182] = Y4909_pgtype81;
	Y4909_gen_type [183] = Y4909_pgtype82;
	Y4909_gen_type [184] = Y4909_pgtype83;
	Y4909_gen_type [185] = Y4909_pgtype84;
	Y4909_gen_type [186] = Y4909_pgtype85;
	Y4909_gen_type [187] = Y4909_pgtype86;
	Y4909_gen_type [188] = Y4909_pgtype87;
	Y4909_gen_type [189] = Y4909_pgtype88;
	Y4909_gen_type [190] = Y4909_pgtype89;
	Y4909_gen_type [191] = Y4909_pgtype90;
	Y4909_gen_type [192] = Y4909_pgtype91;
	Y4909_gen_type [193] = Y4909_pgtype92;
	Y4909_gen_type [194] = Y4909_pgtype93;
	Y4909_gen_type [195] = Y4909_pgtype94;
	Y4909_gen_type [196] = Y4909_pgtype95;
	Y4909_gen_type [197] = Y4909_pgtype96;
	Y4909_gen_type [198] = Y4909_pgtype97;
	Y4909_gen_type [199] = Y4909_pgtype98;
	Y4909_gen_type [200] = Y4909_pgtype99;
	Y4909_gen_type [201] = Y4909_pgtype100;
	Y4909_gen_type [202] = Y4909_pgtype101;
	Y4909_gen_type [211] = Y4909_pgtype102;
	Y4909_gen_type [222] = Y4909_pgtype103;
	Y4909_gen_type [223] = Y4909_pgtype104;
	Y4909_gen_type [224] = Y4909_pgtype105;
	Y4909_gen_type [225] = Y4909_pgtype106;
	Y4909_gen_type [226] = Y4909_pgtype107;
	Y4909_gen_type [227] = Y4909_pgtype108;
	Y4909_gen_type [228] = Y4909_pgtype109;
	Y4909_gen_type [229] = Y4909_pgtype110;
	Y4909_gen_type [230] = Y4909_pgtype111;
	Y4909_gen_type [231] = Y4909_pgtype112;
	Y4909_gen_type [232] = Y4909_pgtype113;
	Y4909_gen_type [233] = Y4909_pgtype114;
	Y4909_gen_type [234] = Y4909_pgtype115;
	Y4909_gen_type [235] = Y4909_pgtype116;
	Y4909_gen_type [236] = Y4909_pgtype117;
	Y4909_gen_type [237] = Y4909_pgtype118;
	Y4909_gen_type [238] = Y4909_pgtype119;
	Y4909_gen_type [239] = Y4909_pgtype120;
	Y4909_gen_type [240] = Y4909_pgtype121;
	Y4909_gen_type [241] = Y4909_pgtype122;
	Y4909_gen_type [242] = Y4909_pgtype123;
	Y4909_gen_type [244] = Y4909_pgtype124;
	Y4909_gen_type [245] = Y4909_pgtype125;
	Y4909_gen_type [246] = Y4909_pgtype126;
	Y4909_gen_type [247] = Y4909_pgtype127;
	Y4909_gen_type [248] = Y4909_pgtype128;
	Y4909_gen_type [249] = Y4909_pgtype129;
	Y4909_gen_type [250] = Y4909_pgtype130;
	Y4909_gen_type [251] = Y4909_pgtype131;
	Y4909_gen_type [252] = Y4909_pgtype132;
	Y4909_gen_type [253] = Y4909_pgtype133;
	Y4909_gen_type [254] = Y4909_pgtype134;
	Y4909_gen_type [255] = Y4909_pgtype135;
	Y4909_gen_type [256] = Y4909_pgtype136;
	Y4909_gen_type [257] = Y4909_pgtype137;
	Y4909_gen_type [258] = Y4909_pgtype138;
	Y4909_gen_type [259] = Y4909_pgtype139;
	Y4909_gen_type [260] = Y4909_pgtype140;
	Y4909_gen_type [261] = Y4909_pgtype141;
	Y4909_gen_type [262] = Y4909_pgtype142;
	Y4909_gen_type [263] = Y4909_pgtype143;
	Y4909_gen_type [264] = Y4909_pgtype144;
	Y4909_gen_type [667] = Y4909_pgtype145;
	Y4909_gen_type [720] = Y4909_pgtype146;
	Y4909[243] = 1097;
	{long i; for (i = 244; i < 265; i++) Y4909[i] = 1047;};
	Y4909[279] = 1006;
	Y4909[283] = 1006;
	{long i; for (i = 462; i < 465; i++) Y4909[i] = 997;};
	{long i; for (i = 671; i < 677; i++) Y4909[i] = 1135;};
	Y4909[711] = 1062;
	Y4909[721] = 1177;
	Y4909[722] = 1178;
	{long i; for (i = 723; i < 726; i++) Y4909[i] = 1176;};
	{long i; for (i = 726; i < 730; i++) Y4909[i] = 1194;};
	{long i; for (i = 730; i < 733; i++) Y4909[i] = 1182;};
	Y4909[930] = 997;
}

char *(*R4913[538])();
void R4913_init () {
	R4913[0] = (char *(*)()) F662_5543;
	R4913[1] = (char *(*)()) F663_5543_4913_4;
	R4913[2] = (char *(*)()) F664_5543_4913_4;
	{long i; for (i = 3; i < 5; i++) R4913[i] = (char *(*)()) F662_5543;}
	R4913[5] = (char *(*)()) F663_5543_4913_4;
	R4913[6] = (char *(*)()) F664_5543_4913_4;
	R4913[7] = (char *(*)()) F662_5543;
	R4913[27] = (char *(*)()) F689_5969;
	R4913[28] = (char *(*)()) F690_5969_4913_4;
	R4913[29] = (char *(*)()) F691_5969_4913_4;
	R4913[30] = (char *(*)()) F692_5969_4913_4;
	R4913[31] = (char *(*)()) F693_5969_4913_4;
	R4913[32] = (char *(*)()) F694_5969_4913_4;
	R4913[33] = (char *(*)()) F695_5969_4913_4;
	R4913[34] = (char *(*)()) F696_5969_4913_4;
	R4913[35] = (char *(*)()) F697_5969_4913_4;
	R4913[36] = (char *(*)()) F698_5969_4913_4;
	R4913[37] = (char *(*)()) F699_5969_4913_4;
	R4913[38] = (char *(*)()) F700_5969_4913_4;
	R4913[46] = (char *(*)()) F704_6013;
	R4913[47] = (char *(*)()) F705_6013_4913_4;
	{long i; for (i = 48; i < 52; i++) R4913[i] = (char *(*)()) F704_6013;}
	R4913[56] = (char *(*)()) F704_6013;
	{long i; for (i = 59; i < 61; i++) R4913[i] = (char *(*)()) F704_6013;}
	R4913[64] = (char *(*)()) F704_6013;
	{long i; for (i = 66; i < 70; i++) R4913[i] = (char *(*)()) F704_6013;}
	{long i; for (i = 480; i < 482; i++) R4913[i] = (char *(*)()) F1134_9957;}
	R4913[527] = (char *(*)()) F1134_9957;
	R4913[537] = (char *(*)()) F1134_9957;
}
static void F663_5543_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_5543(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F664_5543_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5543(Current, *(EIF_BOOLEAN *)arg1);
}
static void F690_5969_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F690_5969(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F691_5969_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F691_5969(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F692_5969_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F692_5969(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F693_5969_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F693_5969(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F694_5969_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F694_5969(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F695_5969_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F695_5969(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F696_5969_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F696_5969(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F697_5969_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F697_5969(Current, *(EIF_BOOLEAN *)arg1);
}
static void F698_5969_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F698_5969(Current, *(EIF_POINTER *)arg1);
}
static void F699_5969_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F699_5969(Current, *(EIF_REAL_32 *)arg1);
}
static void F700_5969_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F700_5969(Current, *(EIF_REAL_64 *)arg1);
}
static void F705_6013_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F705_6013(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4914[538])();
void R4914_init () {
	R4914[0] = (char *(*)()) F662_5546;
	R4914[1] = (char *(*)()) F663_5546;
	R4914[2] = (char *(*)()) F664_5546;
	R4914[3] = (char *(*)()) F662_5547;
	R4914[4] = (char *(*)()) F666_5583;
	R4914[5] = (char *(*)()) F667_5583;
	R4914[6] = (char *(*)()) F668_5583;
	R4914[7] = (char *(*)()) F669_5608;
	R4914[27] = (char *(*)()) F689_5979;
	R4914[28] = (char *(*)()) F690_5979;
	R4914[29] = (char *(*)()) F691_5979;
	R4914[30] = (char *(*)()) F692_5979;
	R4914[31] = (char *(*)()) F693_5979;
	R4914[32] = (char *(*)()) F694_5979;
	R4914[33] = (char *(*)()) F695_5979;
	R4914[34] = (char *(*)()) F696_5979;
	R4914[35] = (char *(*)()) F697_5979;
	R4914[36] = (char *(*)()) F698_5979;
	R4914[37] = (char *(*)()) F699_5979;
	R4914[38] = (char *(*)()) F700_5979;
	R4914[46] = (char *(*)()) F704_6014;
	R4914[47] = (char *(*)()) F705_6014;
	{long i; for (i = 48; i < 52; i++) R4914[i] = (char *(*)()) F704_6014;}
	R4914[56] = (char *(*)()) F704_6014;
	{long i; for (i = 59; i < 61; i++) R4914[i] = (char *(*)()) F704_6014;}
	R4914[64] = (char *(*)()) F704_6014;
	{long i; for (i = 66; i < 70; i++) R4914[i] = (char *(*)()) F704_6014;}
	{long i; for (i = 480; i < 482; i++) R4914[i] = (char *(*)()) F1134_9948;}
	R4914[527] = (char *(*)()) F1134_9948;
	R4914[537] = (char *(*)()) F1134_9948;
}

char *(*R4915[538])();
void R4915_init () {
	R4915[0] = (char *(*)()) F662_5519;
	R4915[1] = (char *(*)()) F663_5519;
	R4915[2] = (char *(*)()) F664_5519;
	{long i; for (i = 3; i < 5; i++) R4915[i] = (char *(*)()) F662_5519;}
	R4915[5] = (char *(*)()) F663_5519;
	R4915[6] = (char *(*)()) F664_5519;
	R4915[7] = (char *(*)()) F669_5595;
	R4915[27] = (char *(*)()) F689_5936;
	R4915[28] = (char *(*)()) F690_5936;
	R4915[29] = (char *(*)()) F691_5936;
	R4915[30] = (char *(*)()) F692_5936;
	R4915[31] = (char *(*)()) F693_5936;
	R4915[32] = (char *(*)()) F694_5936;
	R4915[33] = (char *(*)()) F695_5936;
	R4915[34] = (char *(*)()) F696_5936;
	R4915[35] = (char *(*)()) F697_5936;
	R4915[36] = (char *(*)()) F698_5936;
	R4915[37] = (char *(*)()) F699_5936;
	R4915[38] = (char *(*)()) F700_5936;
	R4915[46] = (char *(*)()) F689_5936;
	R4915[47] = (char *(*)()) F693_5936;
	{long i; for (i = 48; i < 52; i++) R4915[i] = (char *(*)()) F689_5936;}
	R4915[56] = (char *(*)()) F689_5936;
	{long i; for (i = 59; i < 61; i++) R4915[i] = (char *(*)()) F689_5936;}
	R4915[64] = (char *(*)()) F689_5936;
	{long i; for (i = 66; i < 70; i++) R4915[i] = (char *(*)()) F689_5936;}
	{long i; for (i = 480; i < 482; i++) R4915[i] = (char *(*)()) F1134_9922;}
	R4915[527] = (char *(*)()) F1134_9922;
	R4915[537] = (char *(*)()) F1134_9922;
}

static EIF_TYPE_INDEX Y4915_pgtype0[] = {278,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype1[] = {279,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype2[] = {280,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype3[] = {278,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype4[] = {278,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype5[] = {279,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype6[] = {280,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype7[] = {281,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype8[] = {275,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype9[] = {275,1135,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype10[] = {275,1135,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype11[] = {275,1135,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype12[] = {275,1135,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype13[] = {275,1135,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype14[] = {275,1135,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype15[] = {275,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype16[] = {275,1177,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype17[] = {275,1178,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype18[] = {275,1176,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype19[] = {275,1176,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype20[] = {275,1176,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype21[] = {275,1194,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype22[] = {275,1194,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype23[] = {275,1194,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype24[] = {275,1194,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype25[] = {275,1182,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype26[] = {275,1182,0xFFFF};
static EIF_TYPE_INDEX Y4915_pgtype27[] = {275,1182,0xFFFF};
EIF_TYPE_INDEX *Y4915_gen_type [721];
EIF_TYPE_INDEX Y4915 [721];
void Y4915_init (void)
{
	egc_routines_types [4915] = Y4915;
	egc_routines_gen_types [4915] = Y4915_gen_type;
	egc_routines_offset [4915] = 478;
	Y4915_gen_type [183] = Y4915_pgtype0;
	Y4915_gen_type [184] = Y4915_pgtype1;
	Y4915_gen_type [185] = Y4915_pgtype2;
	Y4915_gen_type [186] = Y4915_pgtype3;
	Y4915_gen_type [187] = Y4915_pgtype4;
	Y4915_gen_type [188] = Y4915_pgtype5;
	Y4915_gen_type [189] = Y4915_pgtype6;
	Y4915_gen_type [190] = Y4915_pgtype7;
	Y4915_gen_type [655] = Y4915_pgtype8;
	Y4915_gen_type [659] = Y4915_pgtype9;
	Y4915_gen_type [660] = Y4915_pgtype10;
	Y4915_gen_type [661] = Y4915_pgtype11;
	Y4915_gen_type [662] = Y4915_pgtype12;
	Y4915_gen_type [663] = Y4915_pgtype13;
	Y4915_gen_type [664] = Y4915_pgtype14;
	Y4915_gen_type [708] = Y4915_pgtype15;
	Y4915_gen_type [709] = Y4915_pgtype16;
	Y4915_gen_type [710] = Y4915_pgtype17;
	Y4915_gen_type [711] = Y4915_pgtype18;
	Y4915_gen_type [712] = Y4915_pgtype19;
	Y4915_gen_type [713] = Y4915_pgtype20;
	Y4915_gen_type [714] = Y4915_pgtype21;
	Y4915_gen_type [715] = Y4915_pgtype22;
	Y4915_gen_type [716] = Y4915_pgtype23;
	Y4915_gen_type [717] = Y4915_pgtype24;
	Y4915_gen_type [718] = Y4915_pgtype25;
	Y4915_gen_type [719] = Y4915_pgtype26;
	Y4915_gen_type [720] = Y4915_pgtype27;
	{long i; for (i = 0; i < 12; i++) Y4915[i] = 274;};
	{long i; for (i = 135; i < 183; i++) Y4915[i] = 274;};
	Y4915[183] = 278;
	Y4915[184] = 279;
	Y4915[185] = 280;
	{long i; for (i = 186; i < 188; i++) Y4915[i] = 278;};
	Y4915[188] = 279;
	Y4915[189] = 280;
	Y4915[190] = 281;
	{long i; for (i = 210; i < 253; i++) Y4915[i] = 277;};
	Y4915[655] = 275;
	{long i; for (i = 659; i < 665; i++) Y4915[i] = 275;};
	Y4915[699] = 277;
	{long i; for (i = 708; i < 721; i++) Y4915[i] = 275;};
}

char *(*R4917[538])();
void R4917_init () {
	R4917[0] = (char *(*)()) F662_5538;
	R4917[1] = (char *(*)()) F663_5538;
	R4917[2] = (char *(*)()) F664_5538;
	{long i; for (i = 3; i < 5; i++) R4917[i] = (char *(*)()) F662_5538;}
	R4917[5] = (char *(*)()) F663_5538;
	R4917[6] = (char *(*)()) F664_5538;
	R4917[7] = (char *(*)()) F662_5538;
	R4917[27] = (char *(*)()) F689_5961;
	R4917[28] = (char *(*)()) F690_5961;
	R4917[29] = (char *(*)()) F691_5961;
	R4917[30] = (char *(*)()) F692_5961;
	R4917[31] = (char *(*)()) F693_5961;
	R4917[32] = (char *(*)()) F694_5961;
	R4917[33] = (char *(*)()) F695_5961;
	R4917[34] = (char *(*)()) F696_5961;
	R4917[35] = (char *(*)()) F697_5961;
	R4917[36] = (char *(*)()) F698_5961;
	R4917[37] = (char *(*)()) F699_5961;
	R4917[38] = (char *(*)()) F700_5961;
	R4917[46] = (char *(*)()) F689_5961;
	R4917[47] = (char *(*)()) F693_5961;
	{long i; for (i = 48; i < 52; i++) R4917[i] = (char *(*)()) F689_5961;}
	R4917[56] = (char *(*)()) F689_5961;
	{long i; for (i = 59; i < 61; i++) R4917[i] = (char *(*)()) F689_5961;}
	R4917[64] = (char *(*)()) F689_5961;
	{long i; for (i = 66; i < 70; i++) R4917[i] = (char *(*)()) F689_5961;}
	{long i; for (i = 480; i < 482; i++) R4917[i] = (char *(*)()) F1134_9934;}
	R4917[527] = (char *(*)()) F1134_9934;
	R4917[537] = (char *(*)()) F1134_9934;
}

char *(*R4919[5])();
void R4919_init () {
	R4919[0] = (char *(*)()) F746_6163;
	R4919[4] = (char *(*)()) F750_6221;
}

char *(*R4921[797])();
void R4921_init () {
	R4921[0] = (char *(*)()) F601_5395;
	R4921[1] = (char *(*)()) F602_5395;
	R4921[2] = (char *(*)()) F603_5395;
	R4921[3] = (char *(*)()) F604_5395;
	R4921[4] = (char *(*)()) F605_5395;
	R4921[5] = (char *(*)()) F606_5395;
	R4921[6] = (char *(*)()) F607_5395;
	R4921[7] = (char *(*)()) F608_5395;
	R4921[8] = (char *(*)()) F609_5395;
	R4921[9] = (char *(*)()) F610_5395;
	R4921[10] = (char *(*)()) F611_5395;
	R4921[11] = (char *(*)()) F612_5395;
	R4921[61] = (char *(*)()) F662_5522;
	R4921[62] = (char *(*)()) F663_5522;
	R4921[63] = (char *(*)()) F664_5522;
	{long i; for (i = 64; i < 66; i++) R4921[i] = (char *(*)()) F662_5522;}
	R4921[66] = (char *(*)()) F663_5522;
	R4921[67] = (char *(*)()) F664_5522;
	R4921[68] = (char *(*)()) F662_5522;
	R4921[79] = (char *(*)()) F680_5812;
	R4921[80] = (char *(*)()) F681_5812;
	R4921[81] = (char *(*)()) F682_5812;
	R4921[82] = (char *(*)()) F683_5812;
	R4921[83] = (char *(*)()) F684_5812;
	R4921[84] = (char *(*)()) F685_5812;
	R4921[85] = (char *(*)()) F680_5812;
	R4921[86] = (char *(*)()) F681_5812;
	R4921[87] = (char *(*)()) F680_5812;
	R4921[88] = (char *(*)()) F689_5946;
	R4921[89] = (char *(*)()) F690_5946;
	R4921[90] = (char *(*)()) F691_5946;
	R4921[91] = (char *(*)()) F692_5946;
	R4921[92] = (char *(*)()) F693_5946;
	R4921[93] = (char *(*)()) F694_5946;
	R4921[94] = (char *(*)()) F695_5946;
	R4921[95] = (char *(*)()) F696_5946;
	R4921[96] = (char *(*)()) F697_5946;
	R4921[97] = (char *(*)()) F698_5946;
	R4921[98] = (char *(*)()) F699_5946;
	R4921[99] = (char *(*)()) F700_5946;
	R4921[107] = (char *(*)()) F689_5946;
	R4921[108] = (char *(*)()) F693_5946;
	{long i; for (i = 109; i < 113; i++) R4921[i] = (char *(*)()) F689_5946;}
	R4921[117] = (char *(*)()) F689_5946;
	{long i; for (i = 120; i < 122; i++) R4921[i] = (char *(*)()) F689_5946;}
	R4921[125] = (char *(*)()) F689_5946;
	{long i; for (i = 127; i < 131; i++) R4921[i] = (char *(*)()) F689_5946;}
	{long i; for (i = 329; i < 331; i++) R4921[i] = (char *(*)()) F929_6996;}
	R4921[458] = (char *(*)()) F1057_8919;
	R4921[462] = (char *(*)()) F1061_9084;
	{long i; for (i = 541; i < 543; i++) R4921[i] = (char *(*)()) F1134_9927;}
	R4921[588] = (char *(*)()) F1134_9927;
	R4921[598] = (char *(*)()) F1134_9927;
	R4921[796] = (char *(*)()) F1397_13906;
}

char *(*R4922[463])();
void R4922_init () {
	R4922[0] = (char *(*)()) F601_5396;
	R4922[1] = (char *(*)()) F602_5396;
	R4922[2] = (char *(*)()) F603_5396;
	R4922[3] = (char *(*)()) F604_5396;
	R4922[4] = (char *(*)()) F605_5396;
	R4922[5] = (char *(*)()) F606_5396;
	R4922[6] = (char *(*)()) F607_5396;
	R4922[7] = (char *(*)()) F608_5396;
	R4922[8] = (char *(*)()) F609_5396;
	R4922[9] = (char *(*)()) F610_5396;
	R4922[10] = (char *(*)()) F611_5396;
	R4922[11] = (char *(*)()) F612_5396;
	R4922[88] = (char *(*)()) F689_5947;
	R4922[89] = (char *(*)()) F690_5947;
	R4922[90] = (char *(*)()) F691_5947;
	R4922[91] = (char *(*)()) F692_5947;
	R4922[92] = (char *(*)()) F693_5947;
	R4922[93] = (char *(*)()) F694_5947;
	R4922[94] = (char *(*)()) F695_5947;
	R4922[95] = (char *(*)()) F696_5947;
	R4922[96] = (char *(*)()) F697_5947;
	R4922[97] = (char *(*)()) F698_5947;
	R4922[98] = (char *(*)()) F699_5947;
	R4922[99] = (char *(*)()) F700_5947;
	R4922[107] = (char *(*)()) F689_5947;
	R4922[108] = (char *(*)()) F693_5947;
	{long i; for (i = 109; i < 113; i++) R4922[i] = (char *(*)()) F689_5947;}
	R4922[117] = (char *(*)()) F689_5947;
	{long i; for (i = 120; i < 122; i++) R4922[i] = (char *(*)()) F689_5947;}
	R4922[125] = (char *(*)()) F689_5947;
	{long i; for (i = 127; i < 131; i++) R4922[i] = (char *(*)()) F689_5947;}
	R4922[458] = (char *(*)()) F1057_8918;
	R4922[462] = (char *(*)()) F1061_9083;
}

char *(*R4926[463])();
void R4926_init () {
	R4926[0] = (char *(*)()) F530_5273;
	R4926[1] = (char *(*)()) F531_5273;
	R4926[2] = (char *(*)()) F532_5273;
	R4926[3] = (char *(*)()) F533_5273;
	R4926[4] = (char *(*)()) F534_5273;
	R4926[5] = (char *(*)()) F535_5273;
	R4926[6] = (char *(*)()) F536_5273;
	R4926[7] = (char *(*)()) F537_5273;
	R4926[8] = (char *(*)()) F538_5273;
	R4926[9] = (char *(*)()) F539_5273;
	R4926[10] = (char *(*)()) F540_5273;
	R4926[11] = (char *(*)()) F541_5273;
	R4926[88] = (char *(*)()) F530_5273;
	R4926[89] = (char *(*)()) F531_5273;
	R4926[90] = (char *(*)()) F532_5273;
	R4926[91] = (char *(*)()) F533_5273;
	R4926[92] = (char *(*)()) F534_5273;
	R4926[93] = (char *(*)()) F535_5273;
	R4926[94] = (char *(*)()) F536_5273;
	R4926[95] = (char *(*)()) F537_5273;
	R4926[96] = (char *(*)()) F538_5273;
	R4926[97] = (char *(*)()) F539_5273;
	R4926[98] = (char *(*)()) F540_5273;
	R4926[99] = (char *(*)()) F541_5273;
	R4926[107] = (char *(*)()) F530_5273;
	R4926[108] = (char *(*)()) F534_5273;
	{long i; for (i = 109; i < 113; i++) R4926[i] = (char *(*)()) F530_5273;}
	R4926[117] = (char *(*)()) F530_5273;
	{long i; for (i = 120; i < 122; i++) R4926[i] = (char *(*)()) F530_5273;}
	R4926[125] = (char *(*)()) F530_5273;
	{long i; for (i = 127; i < 131; i++) R4926[i] = (char *(*)()) F530_5273;}
	R4926[458] = (char *(*)()) F536_5273;
	R4926[462] = (char *(*)()) F535_5273;
}

char *(*R4928[463])();
void R4928_init () {
	R4928[0] = (char *(*)()) F601_5426;
	R4928[1] = (char *(*)()) F602_5426;
	R4928[2] = (char *(*)()) F603_5426;
	R4928[3] = (char *(*)()) F604_5426;
	R4928[4] = (char *(*)()) F605_5426;
	R4928[5] = (char *(*)()) F606_5426;
	R4928[6] = (char *(*)()) F607_5426;
	R4928[7] = (char *(*)()) F608_5426;
	R4928[8] = (char *(*)()) F609_5426;
	R4928[9] = (char *(*)()) F610_5426;
	R4928[10] = (char *(*)()) F611_5426;
	R4928[11] = (char *(*)()) F612_5426;
	R4928[88] = (char *(*)()) F689_5973;
	R4928[89] = (char *(*)()) F690_5973;
	R4928[90] = (char *(*)()) F691_5973;
	R4928[91] = (char *(*)()) F692_5973;
	R4928[92] = (char *(*)()) F693_5973;
	R4928[93] = (char *(*)()) F694_5973;
	R4928[94] = (char *(*)()) F695_5973;
	R4928[95] = (char *(*)()) F696_5973;
	R4928[96] = (char *(*)()) F697_5973;
	R4928[97] = (char *(*)()) F698_5973;
	R4928[98] = (char *(*)()) F699_5973;
	R4928[99] = (char *(*)()) F700_5973;
	R4928[107] = (char *(*)()) F689_5973;
	R4928[108] = (char *(*)()) F693_5973;
	{long i; for (i = 109; i < 113; i++) R4928[i] = (char *(*)()) F689_5973;}
	R4928[117] = (char *(*)()) F689_5973;
	{long i; for (i = 120; i < 122; i++) R4928[i] = (char *(*)()) F689_5973;}
	R4928[125] = (char *(*)()) F689_5973;
	{long i; for (i = 127; i < 131; i++) R4928[i] = (char *(*)()) F689_5973;}
	R4928[458] = (char *(*)()) F1059_9043;
	R4928[462] = (char *(*)()) F1063_9211;
}

char *(*R4930[736])();
void R4930_init () {
	R4930[0] = (char *(*)()) F542_5280;
	R4930[1] = (char *(*)()) F546_5280_4930_4;
	R4930[2] = (char *(*)()) F550_5280_4930_4;
	R4930[3] = (char *(*)()) F665_5564;
	R4930[4] = (char *(*)()) F666_5580;
	R4930[5] = (char *(*)()) F667_5580_4930_4;
	R4930[6] = (char *(*)()) F668_5580_4930_4;
	R4930[7] = (char *(*)()) F542_5280;
	R4930[27] = (char *(*)()) F689_5965;
	R4930[28] = (char *(*)()) F690_5965_4930_4;
	R4930[29] = (char *(*)()) F691_5965_4930_4;
	R4930[30] = (char *(*)()) F692_5965_4930_4;
	R4930[31] = (char *(*)()) F693_5965_4930_4;
	R4930[32] = (char *(*)()) F694_5965_4930_4;
	R4930[33] = (char *(*)()) F695_5965_4930_4;
	R4930[34] = (char *(*)()) F696_5965_4930_4;
	R4930[35] = (char *(*)()) F697_5965_4930_4;
	R4930[36] = (char *(*)()) F698_5965_4930_4;
	R4930[37] = (char *(*)()) F699_5965_4930_4;
	R4930[38] = (char *(*)()) F700_5965_4930_4;
	R4930[46] = (char *(*)()) F689_5965;
	R4930[47] = (char *(*)()) F693_5965_4930_4;
	{long i; for (i = 48; i < 52; i++) R4930[i] = (char *(*)()) F689_5965;}
	R4930[56] = (char *(*)()) F689_5965;
	{long i; for (i = 59; i < 61; i++) R4930[i] = (char *(*)()) F689_5965;}
	R4930[64] = (char *(*)()) F689_5965;
	{long i; for (i = 66; i < 70; i++) R4930[i] = (char *(*)()) F689_5965;}
	{long i; for (i = 268; i < 270; i++) R4930[i] = (char *(*)()) F548_5280_4930_4;}
	{long i; for (i = 480; i < 482; i++) R4930[i] = (char *(*)()) F542_5280;}
	R4930[527] = (char *(*)()) F542_5280;
	R4930[537] = (char *(*)()) F542_5280;
	R4930[735] = (char *(*)()) F548_5280_4930_4;
}
static void F546_5280_4930_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F546_5280(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F550_5280_4930_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F550_5280(Current, *(EIF_BOOLEAN *)arg1);
}
static void F667_5580_4930_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5580(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F668_5580_4930_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5580(Current, *(EIF_BOOLEAN *)arg1);
}
static void F690_5965_4930_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F690_5965(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F691_5965_4930_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F691_5965(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F692_5965_4930_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F692_5965(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F693_5965_4930_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F693_5965(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F694_5965_4930_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F694_5965(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F695_5965_4930_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F695_5965(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F696_5965_4930_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F696_5965(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F697_5965_4930_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F697_5965(Current, *(EIF_BOOLEAN *)arg1);
}
static void F698_5965_4930_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F698_5965(Current, *(EIF_POINTER *)arg1);
}
static void F699_5965_4930_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F699_5965(Current, *(EIF_REAL_32 *)arg1);
}
static void F700_5965_4930_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F700_5965(Current, *(EIF_REAL_64 *)arg1);
}
static void F548_5280_4930_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F548_5280(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4944[599])();
void R4944_init () {
	R4944[0] = (char *(*)()) F601_5388;
	R4944[1] = (char *(*)()) F602_5388_4944_46;
	R4944[2] = (char *(*)()) F603_5388_4944_46;
	R4944[3] = (char *(*)()) F604_5388_4944_46;
	R4944[4] = (char *(*)()) F605_5388_4944_46;
	R4944[5] = (char *(*)()) F606_5388_4944_46;
	R4944[6] = (char *(*)()) F607_5388_4944_46;
	R4944[7] = (char *(*)()) F608_5388_4944_46;
	R4944[8] = (char *(*)()) F609_5388_4944_46;
	R4944[9] = (char *(*)()) F610_5388_4944_46;
	R4944[10] = (char *(*)()) F611_5388_4944_46;
	R4944[11] = (char *(*)()) F612_5388_4944_46;
	R4944[61] = (char *(*)()) F614_5467;
	R4944[62] = (char *(*)()) F618_5467_4944_46;
	R4944[63] = (char *(*)()) F622_5467_4944_46;
	{long i; for (i = 64; i < 66; i++) R4944[i] = (char *(*)()) F614_5467;}
	R4944[66] = (char *(*)()) F618_5467_4944_46;
	R4944[67] = (char *(*)()) F622_5467_4944_46;
	R4944[68] = (char *(*)()) F614_5467;
	R4944[79] = (char *(*)()) F680_5810;
	R4944[80] = (char *(*)()) F681_5810_4944_46;
	R4944[81] = (char *(*)()) F682_5810_4944_46;
	R4944[82] = (char *(*)()) F683_5810;
	R4944[83] = (char *(*)()) F684_5810_4944_46;
	R4944[84] = (char *(*)()) F685_5810_4944_46;
	R4944[85] = (char *(*)()) F680_5810;
	R4944[86] = (char *(*)()) F681_5810_4944_46;
	R4944[87] = (char *(*)()) F680_5810;
	R4944[88] = (char *(*)()) F689_5931;
	R4944[89] = (char *(*)()) F690_5931_4944_46;
	R4944[90] = (char *(*)()) F691_5931_4944_46;
	R4944[91] = (char *(*)()) F692_5931_4944_46;
	R4944[92] = (char *(*)()) F693_5931_4944_46;
	R4944[93] = (char *(*)()) F694_5931_4944_46;
	R4944[94] = (char *(*)()) F695_5931_4944_46;
	R4944[95] = (char *(*)()) F696_5931_4944_46;
	R4944[96] = (char *(*)()) F697_5931_4944_46;
	R4944[97] = (char *(*)()) F698_5931_4944_46;
	R4944[98] = (char *(*)()) F699_5931_4944_46;
	R4944[99] = (char *(*)()) F700_5931_4944_46;
	R4944[107] = (char *(*)()) F689_5931;
	R4944[108] = (char *(*)()) F693_5931_4944_46;
	{long i; for (i = 109; i < 113; i++) R4944[i] = (char *(*)()) F689_5931;}
	R4944[117] = (char *(*)()) F689_5931;
	{long i; for (i = 120; i < 122; i++) R4944[i] = (char *(*)()) F689_5931;}
	R4944[125] = (char *(*)()) F689_5931;
	{long i; for (i = 127; i < 131; i++) R4944[i] = (char *(*)()) F689_5931;}
	R4944[258] = (char *(*)()) F859_6495;
	R4944[259] = (char *(*)()) F860_6495_4944_46;
	R4944[260] = (char *(*)()) F861_6495_4944_46;
	R4944[261] = (char *(*)()) F862_6495_4944_46;
	R4944[262] = (char *(*)()) F863_6495_4944_46;
	R4944[263] = (char *(*)()) F864_6495_4944_46;
	R4944[264] = (char *(*)()) F865_6495_4944_46;
	R4944[265] = (char *(*)()) F866_6495_4944_46;
	R4944[266] = (char *(*)()) F867_6495_4944_46;
	R4944[267] = (char *(*)()) F868_6495_4944_46;
	R4944[268] = (char *(*)()) F869_6495_4944_46;
	R4944[269] = (char *(*)()) F870_6495_4944_46;
	R4944[373] = (char *(*)()) F974_7534;
	R4944[457] = (char *(*)()) F1058_8954_4944_46;
	R4944[458] = (char *(*)()) F1059_8976_4944_46;
	R4944[461] = (char *(*)()) F1062_9122_4944_46;
	R4944[462] = (char *(*)()) F1063_9145_4944_46;
	{long i; for (i = 541; i < 543; i++) R4944[i] = (char *(*)()) F1134_9923;}
	R4944[588] = (char *(*)()) F1134_9923;
	R4944[598] = (char *(*)()) F1134_9923;
}
static EIF_REFERENCE F602_5388_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F602_5388(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(976, 0x00).id, 976, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F603_5388_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F603_5388(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(985, 0x00).id, 985, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F604_5388_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F604_5388(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(979, 0x00).id, 979, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F605_5388_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F605_5388(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F606_5388_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F606_5388(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F607_5388_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F607_5388(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F608_5388_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F608_5388(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(982, 0x00).id, 982, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F609_5388_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F609_5388(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F610_5388_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F610_5388(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F611_5388_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F611_5388(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(988, 0x00).id, 988, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F612_5388_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F612_5388(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F618_5467_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F618_5467(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F622_5467_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F622_5467(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F681_5810_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F681_5810(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F682_5810_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F682_5810(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F684_5810_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F684_5810(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F685_5810_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F685_5810(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F690_5931_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F690_5931(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(976, 0x00).id, 976, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F691_5931_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F691_5931(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(985, 0x00).id, 985, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F692_5931_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F692_5931(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(979, 0x00).id, 979, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F693_5931_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F693_5931(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F694_5931_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F694_5931(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F695_5931_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F695_5931(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F696_5931_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F696_5931(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(982, 0x00).id, 982, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F697_5931_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F697_5931(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F698_5931_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F698_5931(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F699_5931_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F699_5931(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(988, 0x00).id, 988, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F700_5931_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F700_5931(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F860_6495_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F860_6495(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(976, 0x00).id, 976, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F861_6495_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F861_6495(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(985, 0x00).id, 985, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F862_6495_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F862_6495(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(979, 0x00).id, 979, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F863_6495_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F863_6495(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F864_6495_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F864_6495(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F865_6495_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F865_6495(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F866_6495_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F866_6495(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(982, 0x00).id, 982, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F867_6495_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F867_6495(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F868_6495_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F868_6495(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F869_6495_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F869_6495(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(988, 0x00).id, 988, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F870_6495_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F870_6495(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1058_8954_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1058_8954(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1059_8976_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1059_8976(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1062_9122_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1062_9122(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1063_9145_4944_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1063_9145(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R4945[599])();
void R4945_init () {
	R4945[0] = (char *(*)()) F601_5393;
	R4945[1] = (char *(*)()) F602_5393;
	R4945[2] = (char *(*)()) F603_5393;
	R4945[3] = (char *(*)()) F604_5393;
	R4945[4] = (char *(*)()) F605_5393;
	R4945[5] = (char *(*)()) F606_5393;
	R4945[6] = (char *(*)()) F607_5393;
	R4945[7] = (char *(*)()) F608_5393;
	R4945[8] = (char *(*)()) F609_5393;
	R4945[9] = (char *(*)()) F610_5393;
	R4945[10] = (char *(*)()) F611_5393;
	R4945[11] = (char *(*)()) F612_5393;
	R4945[61] = (char *(*)()) F614_5470;
	R4945[62] = (char *(*)()) F618_5470;
	R4945[63] = (char *(*)()) F622_5470;
	{long i; for (i = 64; i < 66; i++) R4945[i] = (char *(*)()) F614_5470;}
	R4945[66] = (char *(*)()) F618_5470;
	R4945[67] = (char *(*)()) F622_5470;
	R4945[68] = (char *(*)()) F614_5470;
	R4945[79] = (char *(*)()) F680_5815;
	R4945[80] = (char *(*)()) F681_5815;
	R4945[81] = (char *(*)()) F682_5815;
	R4945[82] = (char *(*)()) F683_5815;
	R4945[83] = (char *(*)()) F684_5815;
	R4945[84] = (char *(*)()) F685_5815;
	R4945[85] = (char *(*)()) F680_5815;
	R4945[86] = (char *(*)()) F681_5815;
	R4945[87] = (char *(*)()) F680_5815;
	R4945[88] = (char *(*)()) F614_5470;
	R4945[89] = (char *(*)()) F615_5470;
	R4945[90] = (char *(*)()) F616_5470;
	R4945[91] = (char *(*)()) F617_5470;
	R4945[92] = (char *(*)()) F618_5470;
	R4945[93] = (char *(*)()) F619_5470;
	R4945[94] = (char *(*)()) F620_5470;
	R4945[95] = (char *(*)()) F621_5470;
	R4945[96] = (char *(*)()) F622_5470;
	R4945[97] = (char *(*)()) F623_5470;
	R4945[98] = (char *(*)()) F624_5470;
	R4945[99] = (char *(*)()) F625_5470;
	R4945[107] = (char *(*)()) F614_5470;
	R4945[108] = (char *(*)()) F618_5470;
	{long i; for (i = 109; i < 113; i++) R4945[i] = (char *(*)()) F614_5470;}
	R4945[117] = (char *(*)()) F614_5470;
	{long i; for (i = 120; i < 122; i++) R4945[i] = (char *(*)()) F614_5470;}
	R4945[125] = (char *(*)()) F614_5470;
	{long i; for (i = 127; i < 131; i++) R4945[i] = (char *(*)()) F614_5470;}
	R4945[258] = (char *(*)()) F859_6503;
	R4945[259] = (char *(*)()) F860_6503;
	R4945[260] = (char *(*)()) F861_6503;
	R4945[261] = (char *(*)()) F862_6503;
	R4945[262] = (char *(*)()) F863_6503;
	R4945[263] = (char *(*)()) F864_6503;
	R4945[264] = (char *(*)()) F865_6503;
	R4945[265] = (char *(*)()) F866_6503;
	R4945[266] = (char *(*)()) F867_6503;
	R4945[267] = (char *(*)()) F868_6503;
	R4945[268] = (char *(*)()) F869_6503;
	R4945[269] = (char *(*)()) F870_6503;
	R4945[373] = (char *(*)()) F974_7564;
	{long i; for (i = 457; i < 459; i++) R4945[i] = (char *(*)()) F1057_8921;}
	{long i; for (i = 461; i < 463; i++) R4945[i] = (char *(*)()) F1061_9086;}
	{long i; for (i = 541; i < 543; i++) R4945[i] = (char *(*)()) F614_5470;}
	R4945[588] = (char *(*)()) F614_5470;
	R4945[598] = (char *(*)()) F614_5470;
}

EIF_TYPE_INDEX *Y4945_gen_type [625];
EIF_TYPE_INDEX Y4945 [625];
void Y4945_init (void)
{
	egc_routines_types [4945] = Y4945;
	egc_routines_gen_types [4945] = Y4945_gen_type;
	egc_routines_offset [4945] = 574;
	{long i; for (i = 0; i < 95; i++) Y4945[i] = 1006;};
	{long i; for (i = 105; i < 157; i++) Y4945[i] = 1006;};
	{long i; for (i = 284; i < 296; i++) Y4945[i] = 1006;};
	Y4945[399] = 1006;
	{long i; for (i = 482; i < 489; i++) Y4945[i] = 1006;};
	Y4945[559] = 1006;
	{long i; for (i = 563; i < 569; i++) Y4945[i] = 1006;};
	Y4945[603] = 1006;
	{long i; for (i = 612; i < 625; i++) Y4945[i] = 1006;};
}

char *(*R4946[599])();
void R4946_init () {
	R4946[0] = (char *(*)()) F601_5394;
	R4946[1] = (char *(*)()) F602_5394;
	R4946[2] = (char *(*)()) F603_5394;
	R4946[3] = (char *(*)()) F604_5394;
	R4946[4] = (char *(*)()) F605_5394;
	R4946[5] = (char *(*)()) F606_5394;
	R4946[6] = (char *(*)()) F607_5394;
	R4946[7] = (char *(*)()) F608_5394;
	R4946[8] = (char *(*)()) F609_5394;
	R4946[9] = (char *(*)()) F610_5394;
	R4946[10] = (char *(*)()) F611_5394;
	R4946[11] = (char *(*)()) F612_5394;
	R4946[61] = (char *(*)()) F662_5522;
	R4946[62] = (char *(*)()) F663_5522;
	R4946[63] = (char *(*)()) F664_5522;
	{long i; for (i = 64; i < 66; i++) R4946[i] = (char *(*)()) F662_5522;}
	R4946[66] = (char *(*)()) F663_5522;
	R4946[67] = (char *(*)()) F664_5522;
	R4946[68] = (char *(*)()) F662_5522;
	R4946[79] = (char *(*)()) F680_5816;
	R4946[80] = (char *(*)()) F681_5816;
	R4946[81] = (char *(*)()) F682_5816;
	R4946[82] = (char *(*)()) F683_5816;
	R4946[83] = (char *(*)()) F684_5816;
	R4946[84] = (char *(*)()) F685_5816;
	R4946[85] = (char *(*)()) F680_5816;
	R4946[86] = (char *(*)()) F681_5816;
	R4946[87] = (char *(*)()) F680_5816;
	R4946[88] = (char *(*)()) F689_5946;
	R4946[89] = (char *(*)()) F690_5946;
	R4946[90] = (char *(*)()) F691_5946;
	R4946[91] = (char *(*)()) F692_5946;
	R4946[92] = (char *(*)()) F693_5946;
	R4946[93] = (char *(*)()) F694_5946;
	R4946[94] = (char *(*)()) F695_5946;
	R4946[95] = (char *(*)()) F696_5946;
	R4946[96] = (char *(*)()) F697_5946;
	R4946[97] = (char *(*)()) F698_5946;
	R4946[98] = (char *(*)()) F699_5946;
	R4946[99] = (char *(*)()) F700_5946;
	R4946[107] = (char *(*)()) F689_5946;
	R4946[108] = (char *(*)()) F693_5946;
	{long i; for (i = 109; i < 113; i++) R4946[i] = (char *(*)()) F689_5946;}
	R4946[117] = (char *(*)()) F689_5946;
	{long i; for (i = 120; i < 122; i++) R4946[i] = (char *(*)()) F689_5946;}
	R4946[125] = (char *(*)()) F689_5946;
	{long i; for (i = 127; i < 131; i++) R4946[i] = (char *(*)()) F689_5946;}
	R4946[258] = (char *(*)()) F859_6504;
	R4946[259] = (char *(*)()) F860_6504;
	R4946[260] = (char *(*)()) F861_6504;
	R4946[261] = (char *(*)()) F862_6504;
	R4946[262] = (char *(*)()) F863_6504;
	R4946[263] = (char *(*)()) F864_6504;
	R4946[264] = (char *(*)()) F865_6504;
	R4946[265] = (char *(*)()) F866_6504;
	R4946[266] = (char *(*)()) F867_6504;
	R4946[267] = (char *(*)()) F868_6504;
	R4946[268] = (char *(*)()) F869_6504;
	R4946[269] = (char *(*)()) F870_6504;
	R4946[373] = (char *(*)()) F974_7563;
	{long i; for (i = 457; i < 459; i++) R4946[i] = (char *(*)()) F1057_8919;}
	{long i; for (i = 461; i < 463; i++) R4946[i] = (char *(*)()) F1061_9084;}
	{long i; for (i = 541; i < 543; i++) R4946[i] = (char *(*)()) F1134_9927;}
	R4946[588] = (char *(*)()) F1134_9927;
	R4946[598] = (char *(*)()) F1134_9927;
}


#ifdef __cplusplus
}
#endif
