#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O1278[1299];
void O1278_init () {
	O1278[0] = 0;
	O1278[1273] = 0;
	{long i; for (i = 1274; i < 1276; i++) O1278[i] =  + _REFACS_2_;}
	O1278[1276] = 0;
	{long i; for (i = 1277; i < 1281; i++) O1278[i] =  + _REFACS_4_;}
	{long i; for (i = 1281; i < 1287; i++) O1278[i] = 0;}
	O1278[1287] =  + _REFACS_1_;
	{long i; for (i = 1288; i < 1292; i++) O1278[i] = 0;}
	O1278[1292] =  + _REFACS_1_;
	{long i; for (i = 1293; i < 1299; i++) O1278[i] =  + _REFACS_2_;}
}

long O1280[1299];
void O1280_init () {
	O1280[0] =  + _REFACS_1_;
	O1280[1273] =  + _REFACS_1_;
	{long i; for (i = 1274; i < 1276; i++) O1280[i] =  + _REFACS_3_;}
	O1280[1276] =  + _REFACS_1_;
	{long i; for (i = 1277; i < 1281; i++) O1280[i] =  + _REFACS_5_;}
	{long i; for (i = 1281; i < 1287; i++) O1280[i] =  + _REFACS_1_;}
	O1280[1287] =  + _REFACS_2_;
	{long i; for (i = 1288; i < 1292; i++) O1280[i] =  + _REFACS_1_;}
	O1280[1292] =  + _REFACS_2_;
	{long i; for (i = 1293; i < 1299; i++) O1280[i] =  + _REFACS_3_;}
}

long O1282[1299];
void O1282_init () {
	O1282[0] =  + _REFACS_2_;
	O1282[1273] =  + _REFACS_2_;
	{long i; for (i = 1274; i < 1276; i++) O1282[i] =  + _REFACS_4_;}
	O1282[1276] =  + _REFACS_2_;
	{long i; for (i = 1277; i < 1281; i++) O1282[i] =  + _REFACS_6_;}
	{long i; for (i = 1281; i < 1287; i++) O1282[i] =  + _REFACS_2_;}
	O1282[1287] =  + _REFACS_3_;
	{long i; for (i = 1288; i < 1292; i++) O1282[i] =  + _REFACS_2_;}
	O1282[1292] =  + _REFACS_3_;
	{long i; for (i = 1293; i < 1299; i++) O1282[i] =  + _REFACS_4_;}
}

long O1322[1285];
void O1322_init () {
	O1322[0] = 0;
	{long i; for (i = 1275; i < 1279; i++) O1322[i] =  + _REFACS_3_;}
	O1322[1279] =  + _REFACS_4_;
	{long i; for (i = 1280; i < 1284; i++) O1322[i] =  + _REFACS_3_;}
	O1322[1284] =  + _REFACS_4_;
}

long O1325[1300];
void O1325_init () {
	O1325[0] = 0;
	{long i; for (i = 1152; i < 1154; i++) O1325[i] = 0;}
	{long i; for (i = 1186; i < 1191; i++) O1325[i] = 0;}
	O1325[1191] =  + _REFACS_1_;
	{long i; for (i = 1192; i < 1194; i++) O1325[i] = 0;}
	O1325[1194] =  + _REFACS_1_;
	{long i; for (i = 1195; i < 1219; i++) O1325[i] = 0;}
	O1325[1219] =  + _REFACS_4_;
	O1325[1220] =  + _REFACS_2_;
	{long i; for (i = 1221; i < 1223; i++) O1325[i] = 0;}
	{long i; for (i = 1223; i < 1226; i++) O1325[i] =  + _REFACS_1_;}
	{long i; for (i = 1226; i < 1228; i++) O1325[i] =  + _REFACS_2_;}
	{long i; for (i = 1228; i < 1230; i++) O1325[i] =  + _REFACS_1_;}
	O1325[1230] =  + _REFACS_4_;
	O1325[1231] =  + _REFACS_1_;
	O1325[1232] =  + _REFACS_5_;
	O1325[1233] =  + _REFACS_1_;
	{long i; for (i = 1234; i < 1243; i++) O1325[i] = 0;}
	O1325[1243] =  + _REFACS_4_;
	O1325[1244] =  + _REFACS_2_;
	O1325[1245] = 0;
	{long i; for (i = 1246; i < 1249; i++) O1325[i] =  + _REFACS_1_;}
	{long i; for (i = 1249; i < 1251; i++) O1325[i] =  + _REFACS_2_;}
	{long i; for (i = 1251; i < 1254; i++) O1325[i] = 0;}
	{long i; for (i = 1254; i < 1256; i++) O1325[i] =  + _REFACS_1_;}
	O1325[1256] =  + _REFACS_4_;
	O1325[1257] =  + _REFACS_1_;
	O1325[1258] =  + _REFACS_5_;
	O1325[1259] =  + _REFACS_1_;
	{long i; for (i = 1260; i < 1264; i++) O1325[i] = 0;}
	{long i; for (i = 1286; i < 1290; i++) O1325[i] =  + _REFACS_5_;}
	O1325[1291] = 0;
	O1325[1294] = 0;
	O1325[1296] = 0;
	O1325[1299] = 0;
}

long O1326[1300];
void O1326_init () {
	O1326[0] =  + _REFACS_1_;
	{long i; for (i = 1152; i < 1154; i++) O1326[i] =  + _REFACS_1_;}
	{long i; for (i = 1186; i < 1191; i++) O1326[i] =  + _REFACS_1_;}
	O1326[1191] =  + _REFACS_2_;
	{long i; for (i = 1192; i < 1194; i++) O1326[i] =  + _REFACS_1_;}
	O1326[1194] =  + _REFACS_2_;
	{long i; for (i = 1195; i < 1219; i++) O1326[i] =  + _REFACS_1_;}
	O1326[1219] =  + _REFACS_5_;
	O1326[1220] =  + _REFACS_3_;
	{long i; for (i = 1221; i < 1223; i++) O1326[i] =  + _REFACS_1_;}
	{long i; for (i = 1223; i < 1226; i++) O1326[i] =  + _REFACS_2_;}
	{long i; for (i = 1226; i < 1228; i++) O1326[i] =  + _REFACS_3_;}
	{long i; for (i = 1228; i < 1230; i++) O1326[i] =  + _REFACS_2_;}
	O1326[1230] =  + _REFACS_5_;
	O1326[1231] =  + _REFACS_2_;
	O1326[1232] =  + _REFACS_6_;
	O1326[1233] =  + _REFACS_2_;
	{long i; for (i = 1234; i < 1243; i++) O1326[i] =  + _REFACS_1_;}
	O1326[1243] =  + _REFACS_5_;
	O1326[1244] =  + _REFACS_3_;
	O1326[1245] =  + _REFACS_1_;
	{long i; for (i = 1246; i < 1249; i++) O1326[i] =  + _REFACS_2_;}
	{long i; for (i = 1249; i < 1251; i++) O1326[i] =  + _REFACS_3_;}
	{long i; for (i = 1251; i < 1254; i++) O1326[i] =  + _REFACS_1_;}
	{long i; for (i = 1254; i < 1256; i++) O1326[i] =  + _REFACS_2_;}
	O1326[1256] =  + _REFACS_5_;
	O1326[1257] =  + _REFACS_2_;
	O1326[1258] =  + _REFACS_6_;
	O1326[1259] =  + _REFACS_2_;
	{long i; for (i = 1260; i < 1264; i++) O1326[i] =  + _REFACS_1_;}
	{long i; for (i = 1286; i < 1290; i++) O1326[i] =  + _REFACS_6_;}
	O1326[1291] =  + _REFACS_1_;
	O1326[1294] =  + _REFACS_1_;
	O1326[1296] =  + _REFACS_1_;
	O1326[1299] =  + _REFACS_1_;
}

long O1352[1292];
void O1352_init () {
	O1352[0] = 0;
	{long i; for (i = 1176; i < 1178; i++) O1352[i] = 0;}
	{long i; for (i = 1178; i < 1180; i++) O1352[i] =  + _REFACS_2_;}
	{long i; for (i = 1180; i < 1183; i++) O1352[i] =  + _REFACS_3_;}
	O1352[1183] =  + _REFACS_4_;
	{long i; for (i = 1184; i < 1186; i++) O1352[i] =  + _REFACS_3_;}
	O1352[1186] =  + _REFACS_4_;
	O1352[1187] =  + _REFACS_3_;
	{long i; for (i = 1188; i < 1198; i++) O1352[i] =  + _REFACS_4_;}
	{long i; for (i = 1198; i < 1202; i++) O1352[i] =  + _REFACS_8_;}
	{long i; for (i = 1202; i < 1206; i++) O1352[i] =  + _REFACS_4_;}
	{long i; for (i = 1206; i < 1210; i++) O1352[i] =  + _REFACS_8_;}
	O1352[1210] =  + _REFACS_2_;
	O1352[1211] =  + _REFACS_6_;
	O1352[1212] =  + _REFACS_4_;
	O1352[1213] =  + _REFACS_3_;
	O1352[1214] =  + _REFACS_2_;
	{long i; for (i = 1215; i < 1218; i++) O1352[i] =  + _REFACS_3_;}
	{long i; for (i = 1218; i < 1220; i++) O1352[i] =  + _REFACS_4_;}
	{long i; for (i = 1220; i < 1222; i++) O1352[i] =  + _REFACS_3_;}
	O1352[1222] =  + _REFACS_6_;
	O1352[1223] =  + _REFACS_4_;
	O1352[1224] =  + _REFACS_8_;
	O1352[1225] =  + _REFACS_4_;
	{long i; for (i = 1226; i < 1234; i++) O1352[i] =  + _REFACS_2_;}
	O1352[1234] =  + _REFACS_3_;
	O1352[1235] =  + _REFACS_6_;
	O1352[1236] =  + _REFACS_4_;
	O1352[1237] =  + _REFACS_2_;
	{long i; for (i = 1238; i < 1241; i++) O1352[i] =  + _REFACS_3_;}
	{long i; for (i = 1241; i < 1243; i++) O1352[i] =  + _REFACS_4_;}
	{long i; for (i = 1243; i < 1246; i++) O1352[i] =  + _REFACS_2_;}
	{long i; for (i = 1246; i < 1248; i++) O1352[i] =  + _REFACS_3_;}
	O1352[1248] =  + _REFACS_6_;
	O1352[1249] =  + _REFACS_4_;
	O1352[1250] =  + _REFACS_8_;
	O1352[1251] =  + _REFACS_4_;
	{long i; for (i = 1252; i < 1256; i++) O1352[i] =  + _REFACS_2_;}
	O1352[1256] =  + _REFACS_3_;
	{long i; for (i = 1257; i < 1259; i++) O1352[i] =  + _REFACS_5_;}
	O1352[1259] =  + _REFACS_3_;
	{long i; for (i = 1260; i < 1264; i++) O1352[i] =  + _REFACS_7_;}
	{long i; for (i = 1264; i < 1266; i++) O1352[i] =  + _REFACS_3_;}
	{long i; for (i = 1266; i < 1270; i++) O1352[i] =  + _REFACS_4_;}
	O1352[1270] =  + _REFACS_5_;
	{long i; for (i = 1271; i < 1275; i++) O1352[i] =  + _REFACS_4_;}
	{long i; for (i = 1275; i < 1278; i++) O1352[i] =  + _REFACS_5_;}
	{long i; for (i = 1278; i < 1282; i++) O1352[i] =  + _REFACS_7_;}
	O1352[1283] =  + _REFACS_2_;
	O1352[1286] =  + _REFACS_2_;
	O1352[1288] =  + _REFACS_2_;
	O1352[1291] =  + _REFACS_2_;
}

long O1354[1292];
void O1354_init () {
	O1354[0] =  + _REFACS_1_;
	{long i; for (i = 1176; i < 1178; i++) O1354[i] =  + _REFACS_1_;}
	{long i; for (i = 1178; i < 1180; i++) O1354[i] =  + _REFACS_3_;}
	{long i; for (i = 1180; i < 1183; i++) O1354[i] =  + _REFACS_4_;}
	O1354[1183] =  + _REFACS_5_;
	{long i; for (i = 1184; i < 1186; i++) O1354[i] =  + _REFACS_4_;}
	O1354[1186] =  + _REFACS_5_;
	O1354[1187] =  + _REFACS_4_;
	{long i; for (i = 1188; i < 1198; i++) O1354[i] =  + _REFACS_5_;}
	{long i; for (i = 1198; i < 1202; i++) O1354[i] =  + _REFACS_9_;}
	{long i; for (i = 1202; i < 1206; i++) O1354[i] =  + _REFACS_5_;}
	{long i; for (i = 1206; i < 1210; i++) O1354[i] =  + _REFACS_9_;}
	O1354[1210] =  + _REFACS_3_;
	O1354[1211] =  + _REFACS_7_;
	O1354[1212] =  + _REFACS_5_;
	O1354[1213] =  + _REFACS_4_;
	O1354[1214] =  + _REFACS_3_;
	{long i; for (i = 1215; i < 1218; i++) O1354[i] =  + _REFACS_4_;}
	{long i; for (i = 1218; i < 1220; i++) O1354[i] =  + _REFACS_5_;}
	{long i; for (i = 1220; i < 1222; i++) O1354[i] =  + _REFACS_4_;}
	O1354[1222] =  + _REFACS_7_;
	O1354[1223] =  + _REFACS_5_;
	O1354[1224] =  + _REFACS_9_;
	O1354[1225] =  + _REFACS_5_;
	{long i; for (i = 1226; i < 1234; i++) O1354[i] =  + _REFACS_3_;}
	O1354[1234] =  + _REFACS_4_;
	O1354[1235] =  + _REFACS_7_;
	O1354[1236] =  + _REFACS_5_;
	O1354[1237] =  + _REFACS_3_;
	{long i; for (i = 1238; i < 1241; i++) O1354[i] =  + _REFACS_4_;}
	{long i; for (i = 1241; i < 1243; i++) O1354[i] =  + _REFACS_5_;}
	{long i; for (i = 1243; i < 1246; i++) O1354[i] =  + _REFACS_3_;}
	{long i; for (i = 1246; i < 1248; i++) O1354[i] =  + _REFACS_4_;}
	O1354[1248] =  + _REFACS_7_;
	O1354[1249] =  + _REFACS_5_;
	O1354[1250] =  + _REFACS_9_;
	O1354[1251] =  + _REFACS_5_;
	{long i; for (i = 1252; i < 1256; i++) O1354[i] =  + _REFACS_3_;}
	O1354[1256] =  + _REFACS_4_;
	{long i; for (i = 1257; i < 1259; i++) O1354[i] =  + _REFACS_6_;}
	O1354[1259] =  + _REFACS_4_;
	{long i; for (i = 1260; i < 1264; i++) O1354[i] =  + _REFACS_8_;}
	{long i; for (i = 1264; i < 1266; i++) O1354[i] =  + _REFACS_4_;}
	{long i; for (i = 1266; i < 1270; i++) O1354[i] =  + _REFACS_5_;}
	O1354[1270] =  + _REFACS_6_;
	{long i; for (i = 1271; i < 1275; i++) O1354[i] =  + _REFACS_5_;}
	{long i; for (i = 1275; i < 1278; i++) O1354[i] =  + _REFACS_6_;}
	{long i; for (i = 1278; i < 1282; i++) O1354[i] =  + _REFACS_8_;}
	O1354[1283] =  + _REFACS_3_;
	O1354[1286] =  + _REFACS_3_;
	O1354[1288] =  + _REFACS_3_;
	O1354[1291] =  + _REFACS_3_;
}


#ifdef __cplusplus
}
#endif
