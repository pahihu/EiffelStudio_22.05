#include "epoly11.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R6273[467])();
void R6273_init () {
	R6273[0] = (char *(*)()) F931_7299;
	R6273[466] = (char *(*)()) F1397_13940;
}

char *(*R6277[467])();
void R6277_init () {
	R6277[0] = (char *(*)()) F931_7303;
	R6277[466] = (char *(*)()) F1397_13941;
}

char *(*R6389[461])();
void R6389_init () {
	R6389[0] = (char *(*)()) F939_7429;
	R6389[1] = (char *(*)()) F940_7466;
	R6389[2] = (char *(*)()) F941_7508;
	R6389[3] = (char *(*)()) F942_7508;
	R6389[4] = (char *(*)()) F943_7508;
	R6389[5] = (char *(*)()) F944_7508;
	R6389[6] = (char *(*)()) F945_7508;
	R6389[7] = (char *(*)()) F946_7508;
	R6389[8] = (char *(*)()) F947_7508;
	R6389[9] = (char *(*)()) F948_7508;
	R6389[10] = (char *(*)()) F949_7508;
	R6389[11] = (char *(*)()) F950_7508;
	R6389[12] = (char *(*)()) F951_7508;
	R6389[13] = (char *(*)()) F952_7508;
	R6389[14] = (char *(*)()) F953_7508;
	R6389[15] = (char *(*)()) F954_7508;
	R6389[16] = (char *(*)()) F955_7508;
	R6389[17] = (char *(*)()) F956_7508;
	R6389[18] = (char *(*)()) F957_7508;
	R6389[19] = (char *(*)()) F958_7508;
	R6389[20] = (char *(*)()) F959_7508;
	R6389[21] = (char *(*)()) F960_7508;
	R6389[22] = (char *(*)()) F961_7508;
	R6389[23] = (char *(*)()) F962_7508;
	R6389[24] = (char *(*)()) F963_7508;
	R6389[25] = (char *(*)()) F964_7508;
	R6389[26] = (char *(*)()) F965_7508;
	R6389[27] = (char *(*)()) F966_7508;
	R6389[28] = (char *(*)()) F967_7508;
	R6389[29] = (char *(*)()) F968_7508;
	R6389[30] = (char *(*)()) F969_7508;
	R6389[31] = (char *(*)()) F970_7508;
	R6389[32] = (char *(*)()) F971_7508;
	R6389[33] = (char *(*)()) F972_7508;
	R6389[34] = (char *(*)()) F973_7508;
	R6389[35] = (char *(*)()) F974_7560;
	{long i; for (i = 37; i < 39; i++) R6389[i] = (char *(*)()) F975_7667;}
	{long i; for (i = 40; i < 42; i++) R6389[i] = (char *(*)()) F978_7761;}
	{long i; for (i = 43; i < 45; i++) R6389[i] = (char *(*)()) F981_7855;}
	{long i; for (i = 46; i < 48; i++) R6389[i] = (char *(*)()) F984_7950;}
	{long i; for (i = 49; i < 51; i++) R6389[i] = (char *(*)()) F987_8045;}
	{long i; for (i = 52; i < 54; i++) R6389[i] = (char *(*)()) F990_8111;}
	{long i; for (i = 55; i < 57; i++) R6389[i] = (char *(*)()) F993_8178;}
	{long i; for (i = 58; i < 60; i++) R6389[i] = (char *(*)()) F996_8219;}
	{long i; for (i = 61; i < 63; i++) R6389[i] = (char *(*)()) F999_8267;}
	{long i; for (i = 64; i < 66; i++) R6389[i] = (char *(*)()) F1002_8288;}
	{long i; for (i = 67; i < 69; i++) R6389[i] = (char *(*)()) F1005_8386;}
	{long i; for (i = 70; i < 72; i++) R6389[i] = (char *(*)()) F1008_8485;}
	{long i; for (i = 73; i < 75; i++) R6389[i] = (char *(*)()) F1011_8584;}
	{long i; for (i = 75; i < 106; i++) R6389[i] = (char *(*)()) F1014_8683;}
	R6389[106] = (char *(*)()) F1045_8709;
	R6389[107] = (char *(*)()) F1046_8709;
	{long i; for (i = 109; i < 115; i++) R6389[i] = (char *(*)()) F1047_8717;}
	{long i; for (i = 119; i < 121; i++) R6389[i] = (char *(*)()) F1054_8776;}
	{long i; for (i = 123; i < 125; i++) R6389[i] = (char *(*)()) F1054_8776;}
	R6389[157] = (char *(*)()) F1096_9454;
	R6389[457] = (char *(*)()) F1396_13898;
	R6389[460] = (char *(*)()) F1399_13979;
}

char *(*R6464[33])();
void R6464_init () {
	R6464[0] = (char *(*)()) F941_7504;
	R6464[1] = (char *(*)()) F942_7504;
	R6464[2] = (char *(*)()) F943_7504;
	R6464[3] = (char *(*)()) F944_7504;
	R6464[4] = (char *(*)()) F945_7504;
	R6464[5] = (char *(*)()) F946_7504;
	R6464[6] = (char *(*)()) F947_7504;
	R6464[7] = (char *(*)()) F948_7504;
	R6464[8] = (char *(*)()) F949_7504;
	R6464[9] = (char *(*)()) F950_7504;
	R6464[10] = (char *(*)()) F951_7504;
	R6464[11] = (char *(*)()) F952_7504;
	R6464[12] = (char *(*)()) F953_7504;
	R6464[13] = (char *(*)()) F954_7504;
	R6464[14] = (char *(*)()) F955_7504;
	R6464[15] = (char *(*)()) F956_7504;
	R6464[16] = (char *(*)()) F957_7504;
	R6464[17] = (char *(*)()) F958_7504;
	R6464[18] = (char *(*)()) F959_7504;
	R6464[19] = (char *(*)()) F960_7504;
	R6464[20] = (char *(*)()) F961_7504;
	R6464[21] = (char *(*)()) F962_7504;
	R6464[22] = (char *(*)()) F963_7504;
	R6464[23] = (char *(*)()) F964_7504;
	R6464[24] = (char *(*)()) F965_7504;
	R6464[25] = (char *(*)()) F966_7504;
	R6464[26] = (char *(*)()) F967_7504;
	R6464[27] = (char *(*)()) F968_7504;
	R6464[28] = (char *(*)()) F969_7504;
	R6464[29] = (char *(*)()) F970_7504;
	R6464[30] = (char *(*)()) F971_7504;
	R6464[31] = (char *(*)()) F972_7504;
	R6464[32] = (char *(*)()) F973_7504;
}

char *(*R6465[33])();
void R6465_init () {
	R6465[0] = (char *(*)()) F941_7505;
	R6465[1] = (char *(*)()) F942_7505;
	R6465[2] = (char *(*)()) F943_7505;
	R6465[3] = (char *(*)()) F944_7505;
	R6465[4] = (char *(*)()) F945_7505;
	R6465[5] = (char *(*)()) F946_7505;
	R6465[6] = (char *(*)()) F947_7505;
	R6465[7] = (char *(*)()) F948_7505;
	R6465[8] = (char *(*)()) F949_7505;
	R6465[9] = (char *(*)()) F950_7505;
	R6465[10] = (char *(*)()) F951_7505;
	R6465[11] = (char *(*)()) F952_7505;
	R6465[12] = (char *(*)()) F953_7505;
	R6465[13] = (char *(*)()) F954_7505;
	R6465[14] = (char *(*)()) F955_7505;
	R6465[15] = (char *(*)()) F956_7505;
	R6465[16] = (char *(*)()) F957_7505;
	R6465[17] = (char *(*)()) F958_7505;
	R6465[18] = (char *(*)()) F959_7505;
	R6465[19] = (char *(*)()) F960_7505;
	R6465[20] = (char *(*)()) F961_7505;
	R6465[21] = (char *(*)()) F962_7505;
	R6465[22] = (char *(*)()) F963_7505;
	R6465[23] = (char *(*)()) F964_7505;
	R6465[24] = (char *(*)()) F965_7505;
	R6465[25] = (char *(*)()) F966_7505;
	R6465[26] = (char *(*)()) F967_7505;
	R6465[27] = (char *(*)()) F968_7505;
	R6465[28] = (char *(*)()) F969_7505;
	R6465[29] = (char *(*)()) F970_7505;
	R6465[30] = (char *(*)()) F971_7505;
	R6465[31] = (char *(*)()) F972_7505;
	R6465[32] = (char *(*)()) F973_7505;
}

char *(*R6466[33])();
void R6466_init () {
	R6466[0] = (char *(*)()) F941_7506;
	R6466[1] = (char *(*)()) F942_7506;
	R6466[2] = (char *(*)()) F943_7506;
	R6466[3] = (char *(*)()) F944_7506;
	R6466[4] = (char *(*)()) F945_7506;
	R6466[5] = (char *(*)()) F946_7506;
	R6466[6] = (char *(*)()) F947_7506;
	R6466[7] = (char *(*)()) F948_7506;
	R6466[8] = (char *(*)()) F949_7506;
	R6466[9] = (char *(*)()) F950_7506;
	R6466[10] = (char *(*)()) F951_7506;
	R6466[11] = (char *(*)()) F952_7506;
	R6466[12] = (char *(*)()) F953_7506;
	R6466[13] = (char *(*)()) F954_7506;
	R6466[14] = (char *(*)()) F955_7506;
	R6466[15] = (char *(*)()) F956_7506;
	R6466[16] = (char *(*)()) F957_7506;
	R6466[17] = (char *(*)()) F958_7506;
	R6466[18] = (char *(*)()) F959_7506;
	R6466[19] = (char *(*)()) F960_7506;
	R6466[20] = (char *(*)()) F961_7506;
	R6466[21] = (char *(*)()) F962_7506;
	R6466[22] = (char *(*)()) F963_7506;
	R6466[23] = (char *(*)()) F964_7506;
	R6466[24] = (char *(*)()) F965_7506;
	R6466[25] = (char *(*)()) F966_7506;
	R6466[26] = (char *(*)()) F967_7506;
	R6466[27] = (char *(*)()) F968_7506;
	R6466[28] = (char *(*)()) F969_7506;
	R6466[29] = (char *(*)()) F970_7506;
	R6466[30] = (char *(*)()) F971_7506;
	R6466[31] = (char *(*)()) F972_7506;
	R6466[32] = (char *(*)()) F973_7506;
}

char *(*R6467[33])();
void R6467_init () {
	R6467[0] = (char *(*)()) F941_7507;
	R6467[1] = (char *(*)()) F942_7507;
	R6467[2] = (char *(*)()) F943_7507;
	R6467[3] = (char *(*)()) F944_7507;
	R6467[4] = (char *(*)()) F945_7507;
	R6467[5] = (char *(*)()) F946_7507;
	R6467[6] = (char *(*)()) F947_7507;
	R6467[7] = (char *(*)()) F948_7507;
	R6467[8] = (char *(*)()) F949_7507;
	R6467[9] = (char *(*)()) F950_7507;
	R6467[10] = (char *(*)()) F951_7507;
	R6467[11] = (char *(*)()) F952_7507;
	R6467[12] = (char *(*)()) F953_7507;
	R6467[13] = (char *(*)()) F954_7507;
	R6467[14] = (char *(*)()) F955_7507;
	R6467[15] = (char *(*)()) F956_7507;
	R6467[16] = (char *(*)()) F957_7507;
	R6467[17] = (char *(*)()) F958_7507;
	R6467[18] = (char *(*)()) F959_7507;
	R6467[19] = (char *(*)()) F960_7507;
	R6467[20] = (char *(*)()) F961_7507;
	R6467[21] = (char *(*)()) F962_7507;
	R6467[22] = (char *(*)()) F963_7507;
	R6467[23] = (char *(*)()) F964_7507;
	R6467[24] = (char *(*)()) F965_7507;
	R6467[25] = (char *(*)()) F966_7507;
	R6467[26] = (char *(*)()) F967_7507;
	R6467[27] = (char *(*)()) F968_7507;
	R6467[28] = (char *(*)()) F969_7507;
	R6467[29] = (char *(*)()) F970_7507;
	R6467[30] = (char *(*)()) F971_7507;
	R6467[31] = (char *(*)()) F972_7507;
	R6467[32] = (char *(*)()) F973_7507;
}

char *(*R6472[33])();
void R6472_init () {
	R6472[0] = (char *(*)()) F941_7513;
	R6472[1] = (char *(*)()) F942_7513;
	R6472[2] = (char *(*)()) F943_7513;
	R6472[3] = (char *(*)()) F944_7513;
	R6472[4] = (char *(*)()) F945_7513;
	R6472[5] = (char *(*)()) F946_7513;
	R6472[6] = (char *(*)()) F947_7513;
	R6472[7] = (char *(*)()) F948_7513;
	R6472[8] = (char *(*)()) F949_7513;
	R6472[9] = (char *(*)()) F950_7513;
	R6472[10] = (char *(*)()) F951_7513;
	R6472[11] = (char *(*)()) F952_7513;
	R6472[12] = (char *(*)()) F953_7513;
	R6472[13] = (char *(*)()) F954_7513;
	R6472[14] = (char *(*)()) F955_7513;
	R6472[15] = (char *(*)()) F956_7513;
	R6472[16] = (char *(*)()) F957_7513;
	R6472[17] = (char *(*)()) F958_7513;
	R6472[18] = (char *(*)()) F959_7513;
	R6472[19] = (char *(*)()) F960_7513;
	R6472[20] = (char *(*)()) F961_7513;
	R6472[21] = (char *(*)()) F962_7513;
	R6472[22] = (char *(*)()) F963_7513;
	R6472[23] = (char *(*)()) F964_7513;
	R6472[24] = (char *(*)()) F965_7513;
	R6472[25] = (char *(*)()) F966_7513;
	R6472[26] = (char *(*)()) F967_7513;
	R6472[27] = (char *(*)()) F968_7513;
	R6472[28] = (char *(*)()) F969_7513;
	R6472[29] = (char *(*)()) F970_7513;
	R6472[30] = (char *(*)()) F971_7513;
	R6472[31] = (char *(*)()) F972_7513;
	R6472[32] = (char *(*)()) F973_7513;
}

char *(*R6477[33])();
void R6477_init () {
	R6477[0] = (char *(*)()) F941_7521;
	R6477[1] = (char *(*)()) F942_7521_6477_1;
	R6477[2] = (char *(*)()) F943_7521_6477_1;
	R6477[3] = (char *(*)()) F944_7521_6477_1;
	R6477[4] = (char *(*)()) F945_7521_6477_1;
	R6477[5] = (char *(*)()) F946_7521_6477_1;
	R6477[6] = (char *(*)()) F947_7521_6477_1;
	R6477[7] = (char *(*)()) F948_7521_6477_1;
	R6477[8] = (char *(*)()) F949_7521_6477_1;
	R6477[9] = (char *(*)()) F950_7521_6477_1;
	R6477[10] = (char *(*)()) F951_7521_6477_1;
	R6477[11] = (char *(*)()) F952_7521_6477_1;
	R6477[12] = (char *(*)()) F953_7521_6477_1;
	R6477[13] = (char *(*)()) F954_7521_6477_1;
	R6477[14] = (char *(*)()) F955_7521_6477_1;
	R6477[15] = (char *(*)()) F956_7521_6477_1;
	R6477[16] = (char *(*)()) F957_7521;
	R6477[17] = (char *(*)()) F958_7521;
	R6477[18] = (char *(*)()) F959_7521;
	R6477[19] = (char *(*)()) F960_7521_6477_1;
	R6477[20] = (char *(*)()) F961_7521_6477_1;
	R6477[21] = (char *(*)()) F962_7521_6477_1;
	R6477[22] = (char *(*)()) F963_7521_6477_1;
	R6477[23] = (char *(*)()) F964_7521_6477_1;
	R6477[24] = (char *(*)()) F965_7521_6477_1;
	R6477[25] = (char *(*)()) F966_7521_6477_1;
	R6477[26] = (char *(*)()) F967_7521_6477_1;
	R6477[27] = (char *(*)()) F968_7521_6477_1;
	R6477[28] = (char *(*)()) F969_7521_6477_1;
	R6477[29] = (char *(*)()) F970_7521_6477_1;
	R6477[30] = (char *(*)()) F971_7521_6477_1;
	R6477[31] = (char *(*)()) F972_7521_6477_1;
	R6477[32] = (char *(*)()) F973_7521_6477_1;
}
static EIF_REFERENCE F942_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F942_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1015,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1015, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F943_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F943_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F944_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F944_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F945_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F945_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(988, 0x00).id, 988, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F946_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F946_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(985, 0x00).id, 985, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F947_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F947_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(982, 0x00).id, 982, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F948_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F948_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(979, 0x00).id, 979, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F949_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F949_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(976, 0x00).id, 976, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F950_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F950_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1012, 0x00).id, 1012, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F951_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F951_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1009, 0x00).id, 1009, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F952_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F952_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F953_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F953_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1003, 0x00).id, 1003, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F954_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F954_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F955_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F955_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F956_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F956_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F960_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F960_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1017,1000,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1017, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F961_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F961_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1019,1009,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1019, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F962_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F962_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1021,1006,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1021, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F963_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F963_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1023,979,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1023, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F964_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F964_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1025,982,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1025, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F965_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F965_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1027,994,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1027, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F966_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F966_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1029,997,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1029, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F967_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F967_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1031,1003,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1031, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F968_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F968_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1033,1012,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1033, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F969_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F969_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1035,976,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1035, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F970_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F970_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1037,985,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1037, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F971_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F971_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1039,988,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1039, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F972_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F972_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1041,991,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F973_7521_6477_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F973_7521(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1043,1045,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1043, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}

char *(*R6487[33])();
void R6487_init () {
	R6487[0] = (char *(*)()) F941_7533;
	R6487[1] = (char *(*)()) F942_7533;
	R6487[2] = (char *(*)()) F943_7533;
	R6487[3] = (char *(*)()) F944_7533;
	R6487[4] = (char *(*)()) F945_7533;
	R6487[5] = (char *(*)()) F946_7533;
	R6487[6] = (char *(*)()) F947_7533;
	R6487[7] = (char *(*)()) F948_7533;
	R6487[8] = (char *(*)()) F949_7533;
	R6487[9] = (char *(*)()) F950_7533;
	R6487[10] = (char *(*)()) F951_7533;
	R6487[11] = (char *(*)()) F952_7533;
	R6487[12] = (char *(*)()) F953_7533;
	R6487[13] = (char *(*)()) F954_7533;
	R6487[14] = (char *(*)()) F955_7533;
	R6487[15] = (char *(*)()) F956_7533;
	R6487[16] = (char *(*)()) F957_7533;
	R6487[17] = (char *(*)()) F958_7533;
	R6487[18] = (char *(*)()) F959_7533;
	R6487[19] = (char *(*)()) F960_7533;
	R6487[20] = (char *(*)()) F961_7533;
	R6487[21] = (char *(*)()) F962_7533;
	R6487[22] = (char *(*)()) F963_7533;
	R6487[23] = (char *(*)()) F964_7533;
	R6487[24] = (char *(*)()) F965_7533;
	R6487[25] = (char *(*)()) F966_7533;
	R6487[26] = (char *(*)()) F967_7533;
	R6487[27] = (char *(*)()) F968_7533;
	R6487[28] = (char *(*)()) F969_7533;
	R6487[29] = (char *(*)()) F970_7533;
	R6487[30] = (char *(*)()) F971_7533;
	R6487[31] = (char *(*)()) F972_7533;
	R6487[32] = (char *(*)()) F973_7533;
}

char *(*R6635[2])();
void R6635_init () {
	R6635[0] = (char *(*)()) F976_7748;
	R6635[1] = (char *(*)()) F977_7748;
}

char *(*R6681[2])();
void R6681_init () {
	R6681[0] = (char *(*)()) F979_7836;
	R6681[1] = (char *(*)()) F980_7836;
}

char *(*R6682[2])();
void R6682_init () {
	R6682[0] = (char *(*)()) F979_7837;
	R6682[1] = (char *(*)()) F980_7837;
}

char *(*R6684[2])();
void R6684_init () {
	R6684[0] = (char *(*)()) F979_7839;
	R6684[1] = (char *(*)()) F980_7839;
}

char *(*R6687[2])();
void R6687_init () {
	R6687[0] = (char *(*)()) F979_7842;
	R6687[1] = (char *(*)()) F980_7842;
}

char *(*R6688[2])();
void R6688_init () {
	R6688[0] = (char *(*)()) F979_7843;
	R6688[1] = (char *(*)()) F980_7843;
}

char *(*R6736[2])();
void R6736_init () {
	R6736[0] = (char *(*)()) F982_7933;
	R6736[1] = (char *(*)()) F983_7933;
}

char *(*R6737[2])();
void R6737_init () {
	R6737[0] = (char *(*)()) F982_7934;
	R6737[1] = (char *(*)()) F983_7934;
}

char *(*R6740[2])();
void R6740_init () {
	R6740[0] = (char *(*)()) F982_7937;
	R6740[1] = (char *(*)()) F983_7937;
}

char *(*R6788[2])();
void R6788_init () {
	R6788[0] = (char *(*)()) F985_8027;
	R6788[1] = (char *(*)()) F986_8027;
}

char *(*R6789[2])();
void R6789_init () {
	R6789[0] = (char *(*)()) F985_8028;
	R6789[1] = (char *(*)()) F986_8028;
}

char *(*R6790[2])();
void R6790_init () {
	R6790[0] = (char *(*)()) F985_8029;
	R6790[1] = (char *(*)()) F986_8029;
}

char *(*R6791[2])();
void R6791_init () {
	R6791[0] = (char *(*)()) F985_8030;
	R6791[1] = (char *(*)()) F986_8030;
}

char *(*R6793[2])();
void R6793_init () {
	R6793[0] = (char *(*)()) F985_8032;
	R6793[1] = (char *(*)()) F986_8032;
}

char *(*R6839[2])();
void R6839_init () {
	R6839[0] = (char *(*)()) F988_8090;
	R6839[1] = (char *(*)()) F989_8090;
}

char *(*R6846[2])();
void R6846_init () {
	R6846[0] = (char *(*)()) F988_8094;
	R6846[1] = (char *(*)()) F989_8094;
}

char *(*R6873[2])();
void R6873_init () {
	R6873[0] = (char *(*)()) F991_8156;
	R6873[1] = (char *(*)()) F992_8156;
}

char *(*R6880[2])();
void R6880_init () {
	R6880[0] = (char *(*)()) F991_8160;
	R6880[1] = (char *(*)()) F992_8160;
}

char *(*R6894[2])();
void R6894_init () {
	R6894[0] = (char *(*)()) F994_8214;
	R6894[1] = (char *(*)()) F995_8214;
}

char *(*R7000[2])();
void R7000_init () {
	R7000[0] = (char *(*)()) F1003_8370;
	R7000[1] = (char *(*)()) F1004_8370;
}

char *(*R7003[2])();
void R7003_init () {
	R7003[0] = (char *(*)()) F1003_8373;
	R7003[1] = (char *(*)()) F1004_8373;
}

char *(*R7055[2])();
void R7055_init () {
	R7055[0] = (char *(*)()) F1006_8468;
	R7055[1] = (char *(*)()) F1007_8468;
}

char *(*R7056[2])();
void R7056_init () {
	R7056[0] = (char *(*)()) F1006_8469;
	R7056[1] = (char *(*)()) F1007_8469;
}

char *(*R7058[2])();
void R7058_init () {
	R7058[0] = (char *(*)()) F1006_8471;
	R7058[1] = (char *(*)()) F1007_8471;
}

char *(*R7060[2])();
void R7060_init () {
	R7060[0] = (char *(*)()) F1006_8473;
	R7060[1] = (char *(*)()) F1007_8473;
}

char *(*R7112[2])();
void R7112_init () {
	R7112[0] = (char *(*)()) F1009_8568;
	R7112[1] = (char *(*)()) F1010_8568;
}

char *(*R7115[2])();
void R7115_init () {
	R7115[0] = (char *(*)()) F1009_8571;
	R7115[1] = (char *(*)()) F1010_8571;
}

char *(*R7165[2])();
void R7165_init () {
	R7165[0] = (char *(*)()) F1012_8664;
	R7165[1] = (char *(*)()) F1013_8664;
}

char *(*R7168[2])();
void R7168_init () {
	R7168[0] = (char *(*)()) F1012_8667;
	R7168[1] = (char *(*)()) F1013_8667;
}

char *(*R7171[2])();
void R7171_init () {
	R7171[0] = (char *(*)()) F1012_8670;
	R7171[1] = (char *(*)()) F1013_8670;
}

char *(*R7241[6])();
void R7241_init () {
	R7241[0] = (char *(*)()) F1048_8754;
	R7241[1] = (char *(*)()) F1049_8757;
	R7241[2] = (char *(*)()) F1050_8757;
	R7241[3] = (char *(*)()) F1051_8757;
	R7241[4] = (char *(*)()) F1052_8757;
	R7241[5] = (char *(*)()) F1050_8757;
}

char *(*R7265[5])();
void R7265_init () {
	R7265[0] = (char *(*)()) F1049_8756;
	R7265[1] = (char *(*)()) F1050_8756_7265_1;
	R7265[2] = (char *(*)()) F1051_8756_7265_1;
	R7265[3] = (char *(*)()) F1052_8756_7265_1;
	R7265[4] = (char *(*)()) F1050_8756_7265_1;
}
static EIF_REFERENCE F1050_8756_7265_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1050_8756(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1051_8756_7265_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1051_8756(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1052_8756_7265_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1052_8756(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R7266[5])();
void R7266_init () {
	R7266[0] = (char *(*)()) F1049_8758;
	R7266[1] = (char *(*)()) F1050_8758_7266_5;
	R7266[2] = (char *(*)()) F1051_8758_7266_5;
	R7266[3] = (char *(*)()) F1052_8758_7266_5;
	R7266[4] = (char *(*)()) F1050_8758_7266_5;
}
static EIF_REFERENCE F1050_8758_7266_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1050_8758(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1051_8758_7266_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1051_8758(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1052_8758_7266_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1052_8758(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R7270[5])();
void R7270_init () {
	R7270[0] = (char *(*)()) F1049_8765;
	R7270[1] = (char *(*)()) F1050_8765_7270_611;
	R7270[2] = (char *(*)()) F1051_8765_7270_611;
	R7270[3] = (char *(*)()) F1052_8765_7270_611;
	R7270[4] = (char *(*)()) F1050_8765_7270_611;
}
static EIF_REFERENCE F1050_8765_7270_611 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1050_8765(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1051_8765_7270_611 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1051_8765(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1052_8765_7270_611 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1052_8765(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y7271_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7271_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7271_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7271_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7271_pgtype4[] = {1000,0xFFFF};
EIF_TYPE_INDEX *Y7271_gen_type [5];
EIF_TYPE_INDEX Y7271 [5];
void Y7271_init (void)
{
	egc_routines_types [7271] = Y7271;
	egc_routines_gen_types [7271] = Y7271_gen_type;
	egc_routines_offset [7271] = 1048;
	Y7271_gen_type [0] = Y7271_pgtype0;
	Y7271_gen_type [1] = Y7271_pgtype1;
	Y7271_gen_type [2] = Y7271_pgtype2;
	Y7271_gen_type [3] = Y7271_pgtype3;
	Y7271_gen_type [4] = Y7271_pgtype4;
	Y7271[4] = 1000;
}

char *(*R7272[6])();
void R7272_init () {
	{long i; for (i = 0; i < 2; i++) R7272[i] = (char *(*)()) F1057_8897;}
	{long i; for (i = 4; i < 6; i++) R7272[i] = (char *(*)()) F1061_9063;}
}

char *(*R7274[6])();
void R7274_init () {
	R7274[0] = (char *(*)()) F1058_8957;
	R7274[1] = (char *(*)()) F1059_8979;
	R7274[4] = (char *(*)()) F1062_9124;
	R7274[5] = (char *(*)()) F1063_9147;
}

char *(*R7275[6])();
void R7275_init () {
	R7275[0] = (char *(*)()) F1058_8956;
	R7275[1] = (char *(*)()) F1059_8978;
	R7275[4] = (char *(*)()) F1062_9122;
	R7275[5] = (char *(*)()) F1063_9145;
}

char *(*R7276[6])();
void R7276_init () {
	{long i; for (i = 0; i < 2; i++) R7276[i] = (char *(*)()) F1054_8770;}
	{long i; for (i = 4; i < 6; i++) R7276[i] = (char *(*)()) F1061_9075;}
}

char *(*R7286[6])();
void R7286_init () {
	{long i; for (i = 0; i < 2; i++) R7286[i] = (char *(*)()) F1057_8928;}
	{long i; for (i = 4; i < 6; i++) R7286[i] = (char *(*)()) F1061_9093;}
}

char *(*R7288[6])();
void R7288_init () {
	{long i; for (i = 0; i < 2; i++) R7288[i] = (char *(*)()) F1057_8930;}
	{long i; for (i = 4; i < 6; i++) R7288[i] = (char *(*)()) F1061_9095;}
}

char *(*R7289[6])();
void R7289_init () {
	R7289[0] = (char *(*)()) F1058_8966;
	R7289[1] = (char *(*)()) F510_5267;
	R7289[4] = (char *(*)()) F1062_9134;
	R7289[5] = (char *(*)()) F512_5267;
}

char *(*R7291[6])();
void R7291_init () {
	{long i; for (i = 0; i < 2; i++) R7291[i] = (char *(*)()) F1057_8931;}
	{long i; for (i = 4; i < 6; i++) R7291[i] = (char *(*)()) F1061_9096;}
}

char *(*R7292[6])();
void R7292_init () {
	{long i; for (i = 0; i < 2; i++) R7292[i] = (char *(*)()) F1054_8787;}
	{long i; for (i = 4; i < 6; i++) R7292[i] = (char *(*)()) F1061_9097;}
}

char *(*R7311[6])();
void R7311_init () {
	{long i; for (i = 0; i < 2; i++) R7311[i] = (char *(*)()) F1057_8919;}
	{long i; for (i = 4; i < 6; i++) R7311[i] = (char *(*)()) F1061_9084;}
}

char *(*R7312[6])();
void R7312_init () {
	{long i; for (i = 0; i < 2; i++) R7312[i] = (char *(*)()) F1057_8918;}
	{long i; for (i = 4; i < 6; i++) R7312[i] = (char *(*)()) F1061_9083;}
}

char *(*R7322[6])();
void R7322_init () {
	{long i; for (i = 0; i < 2; i++) R7322[i] = (char *(*)()) F1057_8915;}
	{long i; for (i = 4; i < 6; i++) R7322[i] = (char *(*)()) F1061_9080;}
}

char *(*R7333[6])();
void R7333_init () {
	R7333[0] = (char *(*)()) F1058_8962;
	R7333[1] = (char *(*)()) F1059_9045;
	R7333[4] = (char *(*)()) F1062_9129;
	R7333[5] = (char *(*)()) F1063_9213;
}

char *(*R7352[6])();
void R7352_init () {
	R7352[0] = (char *(*)()) F1058_8964;
	R7352[1] = (char *(*)()) F1059_9057;
	R7352[4] = (char *(*)()) F1062_9131;
	R7352[5] = (char *(*)()) F1063_9225;
}

char *(*R7356[6])();
void R7356_init () {
	R7356[0] = (char *(*)()) F1058_8968;
	R7356[1] = (char *(*)()) F1059_9061;
	R7356[4] = (char *(*)()) F1062_9135;
	R7356[5] = (char *(*)()) F1063_9228;
}

char *(*R7367[5])();
void R7367_init () {
	R7367[0] = (char *(*)()) F1059_9059;
	R7367[4] = (char *(*)()) F1063_9227;
}

char *(*R7370[5])();
void R7370_init () {
	R7370[0] = (char *(*)()) F1059_8998;
	R7370[4] = (char *(*)()) F1063_9166;
}

char *(*R7382[5])();
void R7382_init () {
	R7382[0] = (char *(*)()) F1059_9009;
	R7382[4] = (char *(*)()) F1063_9177;
}

char *(*R7390[5])();
void R7390_init () {
	R7390[0] = (char *(*)()) F1059_8992;
	R7390[4] = (char *(*)()) F1063_9160;
}

char *(*R7400[5])();
void R7400_init () {
	R7400[0] = (char *(*)()) F1059_9042;
	R7400[4] = (char *(*)()) F1063_9210;
}

char *(*R7424[2])();
void R7424_init () {
	R7424[0] = (char *(*)()) F1058_8959;
	R7424[1] = (char *(*)()) F1059_9029;
}

char *(*R7432[2])();
void R7432_init () {
	R7432[0] = (char *(*)()) F1058_8970;
	R7432[1] = (char *(*)()) F1057_8949;
}

char *(*R7499[2])();
void R7499_init () {
	R7499[0] = (char *(*)()) F1062_9126;
	R7499[1] = (char *(*)()) F1063_9197;
}

char *(*R7507[2])();
void R7507_init () {
	R7507[0] = (char *(*)()) F1062_9137;
	R7507[1] = (char *(*)()) F1061_9114;
}

char *(*R7600[4])();
void R7600_init () {
	R7600[0] = (char *(*)()) F1165_10397;
	R7600[2] = (char *(*)()) F1167_10435;
	R7600[3] = (char *(*)()) F1168_10437;
}

char *(*R7605[17])();
void R7605_init () {
	R7605[0] = (char *(*)()) F1183_10504;
	R7605[16] = (char *(*)()) F1199_10628;
}

char *(*R7610[58])();
void R7610_init () {
	R7610[0] = (char *(*)()) F1142_10087;
	R7610[1] = (char *(*)()) F1143_10089;
	R7610[2] = (char *(*)()) F1144_10102;
	R7610[3] = (char *(*)()) F1145_10110;
	R7610[5] = (char *(*)()) F1147_10134;
	R7610[6] = (char *(*)()) F1148_10167;
	R7610[9] = (char *(*)()) F1150_10193;
	{long i; for (i = 10; i < 12; i++) R7610[i] = (char *(*)()) F1152_10236;}
	{long i; for (i = 13; i < 15; i++) R7610[i] = (char *(*)()) F1152_10236;}
	R7610[16] = (char *(*)()) F1158_10291;
	R7610[17] = (char *(*)()) F1159_10298;
	R7610[18] = (char *(*)()) F1160_10321;
	R7610[23] = (char *(*)()) F1165_10397;
	R7610[25] = (char *(*)()) F1167_10435;
	R7610[26] = (char *(*)()) F1168_10437;
	R7610[28] = (char *(*)()) F1170_10441;
	R7610[29] = (char *(*)()) F1171_10443;
	R7610[30] = (char *(*)()) F1172_10451;
	R7610[33] = (char *(*)()) F1175_10459;
	R7610[38] = (char *(*)()) F1180_10483;
	R7610[41] = (char *(*)()) F1183_10504;
	R7610[47] = (char *(*)()) F1189_10564;
	R7610[57] = (char *(*)()) F1199_10628;
}

char *(*R7616[48])();
void R7616_init () {
	R7616[0] = (char *(*)()) F1142_10087;
	R7616[1] = (char *(*)()) F1143_10089;
	R7616[2] = (char *(*)()) F1144_10102;
	R7616[3] = (char *(*)()) F1145_10110;
	R7616[5] = (char *(*)()) F1147_10134;
	R7616[6] = (char *(*)()) F1148_10167;
	R7616[9] = (char *(*)()) F1150_10193;
	{long i; for (i = 10; i < 12; i++) R7616[i] = (char *(*)()) F1152_10236;}
	{long i; for (i = 13; i < 15; i++) R7616[i] = (char *(*)()) F1152_10236;}
	R7616[47] = (char *(*)()) F1189_10564;
}

char *(*R7618[2])();
void R7618_init () {
	R7618[0] = (char *(*)()) F1167_10435;
	R7618[1] = (char *(*)()) F1168_10437;
}

char *(*R7620[9])();
void R7620_init () {
	R7620[0] = (char *(*)()) F1148_10167;
	R7620[3] = (char *(*)()) F1150_10193;
	{long i; for (i = 4; i < 6; i++) R7620[i] = (char *(*)()) F1152_10236;}
	{long i; for (i = 7; i < 9; i++) R7620[i] = (char *(*)()) F1152_10236;}
}

char *(*R7629[4])();
void R7629_init () {
	R7629[0] = (char *(*)()) F1172_10451;
	R7629[3] = (char *(*)()) F1175_10459;
}

char *(*R7631[48])();
void R7631_init () {
	R7631[0] = (char *(*)()) F1142_10087;
	R7631[1] = (char *(*)()) F1143_10089;
	R7631[2] = (char *(*)()) F1144_10102;
	R7631[3] = (char *(*)()) F1145_10110;
	R7631[5] = (char *(*)()) F1147_10134;
	R7631[6] = (char *(*)()) F1148_10167;
	R7631[9] = (char *(*)()) F1150_10193;
	{long i; for (i = 10; i < 12; i++) R7631[i] = (char *(*)()) F1152_10236;}
	{long i; for (i = 13; i < 15; i++) R7631[i] = (char *(*)()) F1152_10236;}
	R7631[16] = (char *(*)()) F1158_10291;
	R7631[17] = (char *(*)()) F1159_10298;
	R7631[18] = (char *(*)()) F1160_10321;
	R7631[23] = (char *(*)()) F1165_10397;
	R7631[25] = (char *(*)()) F1167_10435;
	R7631[26] = (char *(*)()) F1168_10437;
	R7631[28] = (char *(*)()) F1170_10441;
	R7631[29] = (char *(*)()) F1171_10443;
	R7631[30] = (char *(*)()) F1172_10451;
	R7631[33] = (char *(*)()) F1175_10459;
	R7631[47] = (char *(*)()) F1189_10564;
}

char *(*R7676[108])();
void R7676_init () {
	R7676[0] = (char *(*)()) F1092_9370;
	R7676[3] = (char *(*)()) F1095_9419;
	R7676[4] = (char *(*)()) F1096_9461;
	R7676[6] = (char *(*)()) F1098_9488;
	R7676[7] = (char *(*)()) F1099_9503;
	R7676[9] = (char *(*)()) F1101_9548;
	R7676[10] = (char *(*)()) F1102_9571;
	R7676[11] = (char *(*)()) F1103_9587;
	R7676[18] = (char *(*)()) F1107_9650;
	R7676[34] = (char *(*)()) F1126_9840;
	R7676[37] = (char *(*)()) F1129_9865;
	R7676[50] = (char *(*)()) F1142_10088;
	R7676[51] = (char *(*)()) F1143_10090;
	R7676[52] = (char *(*)()) F1144_10103;
	R7676[53] = (char *(*)()) F1145_10111;
	R7676[55] = (char *(*)()) F1147_10135;
	R7676[56] = (char *(*)()) F1148_10171;
	R7676[59] = (char *(*)()) F1150_10194;
	{long i; for (i = 60; i < 62; i++) R7676[i] = (char *(*)()) F1152_10237;}
	{long i; for (i = 63; i < 65; i++) R7676[i] = (char *(*)()) F1152_10237;}
	R7676[66] = (char *(*)()) F1158_10292;
	R7676[67] = (char *(*)()) F1159_10299;
	R7676[68] = (char *(*)()) F1160_10322;
	R7676[73] = (char *(*)()) F1165_10398;
	R7676[75] = (char *(*)()) F1167_10436;
	R7676[76] = (char *(*)()) F1168_10438;
	R7676[78] = (char *(*)()) F1170_10442;
	R7676[79] = (char *(*)()) F1171_10444;
	R7676[80] = (char *(*)()) F1172_10452;
	R7676[83] = (char *(*)()) F1175_10460;
	R7676[88] = (char *(*)()) F1180_10484;
	R7676[91] = (char *(*)()) F1183_10505;
	R7676[97] = (char *(*)()) F1189_10554;
	R7676[107] = (char *(*)()) F1199_10629;
}

char *(*R7677[108])();
void R7677_init () {
	R7677[0] = (char *(*)()) F1092_9369;
	R7677[3] = (char *(*)()) F1095_9420;
	R7677[4] = (char *(*)()) F1096_9460;
	R7677[6] = (char *(*)()) F1098_9487;
	R7677[7] = (char *(*)()) F1099_9502;
	R7677[9] = (char *(*)()) F1101_9547;
	R7677[10] = (char *(*)()) F1102_9570;
	R7677[11] = (char *(*)()) F1103_9586;
	R7677[18] = (char *(*)()) F1107_9649;
	R7677[34] = (char *(*)()) F1126_9839;
	R7677[37] = (char *(*)()) F1128_9856;
	{long i; for (i = 50; i < 54; i++) R7677[i] = (char *(*)()) F936_7394;}
	{long i; for (i = 55; i < 57; i++) R7677[i] = (char *(*)()) F936_7394;}
	R7677[59] = (char *(*)()) F1151_10196;
	{long i; for (i = 60; i < 62; i++) R7677[i] = (char *(*)()) F936_7394;}
	{long i; for (i = 63; i < 65; i++) R7677[i] = (char *(*)()) F1154_10246;}
	{long i; for (i = 66; i < 69; i++) R7677[i] = (char *(*)()) F936_7394;}
	R7677[73] = (char *(*)()) F936_7394;
	{long i; for (i = 75; i < 77; i++) R7677[i] = (char *(*)()) F936_7394;}
	{long i; for (i = 78; i < 81; i++) R7677[i] = (char *(*)()) F936_7394;}
	R7677[83] = (char *(*)()) F936_7394;
	R7677[88] = (char *(*)()) F936_7394;
	R7677[91] = (char *(*)()) F936_7394;
	R7677[97] = (char *(*)()) F936_7394;
	R7677[107] = (char *(*)()) F936_7394;
}

char *(*R7678[108])();
void R7678_init () {
	R7678[0] = (char *(*)()) F1091_9353;
	{long i; for (i = 3; i < 5; i++) R7678[i] = (char *(*)()) F1091_9353;}
	{long i; for (i = 6; i < 8; i++) R7678[i] = (char *(*)()) F1091_9353;}
	{long i; for (i = 9; i < 12; i++) R7678[i] = (char *(*)()) F1091_9353;}
	R7678[18] = (char *(*)()) F1107_9611;
	R7678[34] = (char *(*)()) F1091_9353;
	R7678[37] = (char *(*)()) F1091_9353;
	{long i; for (i = 50; i < 54; i++) R7678[i] = (char *(*)()) F1091_9353;}
	R7678[55] = (char *(*)()) F1091_9353;
	R7678[56] = (char *(*)()) F1148_10137;
	R7678[59] = (char *(*)()) F1151_10197;
	{long i; for (i = 60; i < 62; i++) R7678[i] = (char *(*)()) F1152_10223;}
	R7678[63] = (char *(*)()) F1155_10278;
	R7678[64] = (char *(*)()) F1156_10279;
	{long i; for (i = 66; i < 69; i++) R7678[i] = (char *(*)()) F1091_9353;}
	R7678[73] = (char *(*)()) F1091_9353;
	{long i; for (i = 75; i < 77; i++) R7678[i] = (char *(*)()) F1091_9353;}
	{long i; for (i = 78; i < 81; i++) R7678[i] = (char *(*)()) F1091_9353;}
	R7678[83] = (char *(*)()) F1091_9353;
	R7678[88] = (char *(*)()) F1091_9353;
	R7678[91] = (char *(*)()) F1091_9353;
	R7678[97] = (char *(*)()) F1091_9353;
	R7678[107] = (char *(*)()) F1091_9353;
}

char *(*R7857[58])();
void R7857_init () {
	{long i; for (i = 0; i < 4; i++) R7857[i] = (char *(*)()) F1136_9973;}
	{long i; for (i = 5; i < 7; i++) R7857[i] = (char *(*)()) F1136_9973;}
	{long i; for (i = 9; i < 12; i++) R7857[i] = (char *(*)()) F1136_9973;}
	{long i; for (i = 13; i < 15; i++) R7857[i] = (char *(*)()) F1136_9973;}
	{long i; for (i = 16; i < 19; i++) R7857[i] = (char *(*)()) F1136_9973;}
	R7857[23] = (char *(*)()) F1136_9973;
	{long i; for (i = 25; i < 27; i++) R7857[i] = (char *(*)()) F1136_9973;}
	{long i; for (i = 28; i < 31; i++) R7857[i] = (char *(*)()) F1136_9973;}
	R7857[33] = (char *(*)()) F1136_9973;
	R7857[38] = (char *(*)()) F1179_10482;
	R7857[41] = (char *(*)()) F1176_10461;
	R7857[47] = (char *(*)()) F1136_9973;
	R7857[57] = (char *(*)()) F1199_10623;
}

char *(*R7859[58])();
void R7859_init () {
	{long i; for (i = 0; i < 3; i++) R7859[i] = (char *(*)()) F1104_9591;}
	R7859[3] = (char *(*)()) F1145_10105;
	{long i; for (i = 5; i < 7; i++) R7859[i] = (char *(*)()) F1104_9591;}
	{long i; for (i = 9; i < 12; i++) R7859[i] = (char *(*)()) F1104_9591;}
	{long i; for (i = 13; i < 15; i++) R7859[i] = (char *(*)()) F1154_10252;}
	{long i; for (i = 16; i < 19; i++) R7859[i] = (char *(*)()) F1104_9591;}
	R7859[23] = (char *(*)()) F1104_9591;
	{long i; for (i = 25; i < 27; i++) R7859[i] = (char *(*)()) F1104_9591;}
	{long i; for (i = 28; i < 30; i++) R7859[i] = (char *(*)()) F1104_9591;}
	R7859[30] = (char *(*)()) F1172_10446;
	R7859[33] = (char *(*)()) F1172_10446;
	R7859[38] = (char *(*)()) F1104_9591;
	R7859[41] = (char *(*)()) F1183_10499;
	R7859[47] = (char *(*)()) F1104_9591;
	R7859[57] = (char *(*)()) F1183_10499;
}

char *(*R7933[64])();
void R7933_init () {
	R7933[0] = (char *(*)()) F1112_9678;
	{long i; for (i = 16; i < 20; i++) R7933[i] = (char *(*)()) F1112_9678;}
	{long i; for (i = 21; i < 23; i++) R7933[i] = (char *(*)()) F1112_9678;}
	{long i; for (i = 25; i < 28; i++) R7933[i] = (char *(*)()) F1112_9678;}
	{long i; for (i = 29; i < 31; i++) R7933[i] = (char *(*)()) F1154_10250;}
	{long i; for (i = 32; i < 35; i++) R7933[i] = (char *(*)()) F1112_9678;}
	R7933[39] = (char *(*)()) F1112_9678;
	{long i; for (i = 41; i < 43; i++) R7933[i] = (char *(*)()) F1112_9678;}
	{long i; for (i = 44; i < 47; i++) R7933[i] = (char *(*)()) F1112_9678;}
	R7933[49] = (char *(*)()) F1112_9678;
	R7933[63] = (char *(*)()) F1112_9678;
}

char *(*R7934[64])();
void R7934_init () {
	R7934[0] = (char *(*)()) F1112_9679;
	{long i; for (i = 16; i < 20; i++) R7934[i] = (char *(*)()) F1112_9679;}
	{long i; for (i = 21; i < 23; i++) R7934[i] = (char *(*)()) F1112_9679;}
	{long i; for (i = 25; i < 28; i++) R7934[i] = (char *(*)()) F1112_9679;}
	{long i; for (i = 29; i < 31; i++) R7934[i] = (char *(*)()) F1154_10251;}
	{long i; for (i = 32; i < 35; i++) R7934[i] = (char *(*)()) F1112_9679;}
	R7934[39] = (char *(*)()) F1112_9679;
	{long i; for (i = 41; i < 43; i++) R7934[i] = (char *(*)()) F1112_9679;}
	{long i; for (i = 44; i < 47; i++) R7934[i] = (char *(*)()) F1112_9679;}
	R7934[49] = (char *(*)()) F1112_9679;
	R7934[63] = (char *(*)()) F1112_9679;
}

char *(*R7936[64])();
void R7936_init () {
	R7936[0] = (char *(*)()) F1112_9681;
	{long i; for (i = 16; i < 20; i++) R7936[i] = (char *(*)()) F1112_9681;}
	{long i; for (i = 21; i < 23; i++) R7936[i] = (char *(*)()) F1112_9681;}
	{long i; for (i = 25; i < 28; i++) R7936[i] = (char *(*)()) F1112_9681;}
	{long i; for (i = 29; i < 31; i++) R7936[i] = (char *(*)()) F1154_10253;}
	{long i; for (i = 32; i < 35; i++) R7936[i] = (char *(*)()) F1112_9681;}
	R7936[39] = (char *(*)()) F1112_9681;
	{long i; for (i = 41; i < 43; i++) R7936[i] = (char *(*)()) F1112_9681;}
	{long i; for (i = 44; i < 47; i++) R7936[i] = (char *(*)()) F1112_9681;}
	R7936[49] = (char *(*)()) F1112_9681;
	R7936[63] = (char *(*)()) F1112_9681;
}

char *(*R8183[15])();
void R8183_init () {
	{long i; for (i = 0; i < 2; i++) R8183[i] = (char *(*)()) F1134_9938;}
	{long i; for (i = 2; i < 4; i++) R8183[i] = (char *(*)()) F1137_10014;}
	{long i; for (i = 5; i < 7; i++) R8183[i] = (char *(*)()) F1137_10014;}
	{long i; for (i = 9; i < 12; i++) R8183[i] = (char *(*)()) F1137_10014;}
	{long i; for (i = 13; i < 15; i++) R8183[i] = (char *(*)()) F1137_10014;}
}

char *(*R8186[15])();
void R8186_init () {
	{long i; for (i = 0; i < 2; i++) R8186[i] = (char *(*)()) F1134_9947;}
	{long i; for (i = 2; i < 4; i++) R8186[i] = (char *(*)()) F1144_10099;}
	{long i; for (i = 5; i < 7; i++) R8186[i] = (char *(*)()) F1144_10099;}
	{long i; for (i = 9; i < 12; i++) R8186[i] = (char *(*)()) F1144_10099;}
	{long i; for (i = 13; i < 15; i++) R8186[i] = (char *(*)()) F1144_10099;}
}

char *(*R8595[184])();
void R8595_init () {
	R8595[0] = (char *(*)()) F1207_10771;
	R8595[4] = (char *(*)()) F1211_10837;
	R8595[7] = (char *(*)()) F1214_10876;
	R8595[11] = (char *(*)()) F1218_10980;
	R8595[13] = (char *(*)()) F1219_10998;
	R8595[15] = (char *(*)()) F1222_11212;
	R8595[17] = (char *(*)()) F1224_11307;
	R8595[19] = (char *(*)()) F1226_11328;
	R8595[23] = (char *(*)()) F1227_11347;
	R8595[65] = (char *(*)()) F1227_11347;
	{long i; for (i = 84; i < 86; i++) R8595[i] = (char *(*)()) F1280_12079;}
	{long i; for (i = 94; i < 96; i++) R8595[i] = (char *(*)()) F1280_12079;}
	R8595[97] = (char *(*)()) F1280_12079;
	R8595[98] = (char *(*)()) F1305_12412;
	{long i; for (i = 100; i < 102; i++) R8595[i] = (char *(*)()) F1305_12412;}
	R8595[126] = (char *(*)()) F1278_12020;
	R8595[129] = (char *(*)()) F1278_12020;
	{long i; for (i = 136; i < 138; i++) R8595[i] = (char *(*)()) F1278_12020;}
	R8595[139] = (char *(*)()) F1278_12020;
	R8595[141] = (char *(*)()) F1278_12020;
	{long i; for (i = 143; i < 145; i++) R8595[i] = (char *(*)()) F1278_12020;}
	R8595[147] = (char *(*)()) F1278_12020;
	R8595[157] = (char *(*)()) F1363_13321;
	R8595[163] = (char *(*)()) F1363_13321;
	R8595[167] = (char *(*)()) F1374_13394;
	R8595[180] = (char *(*)()) F1387_13679;
	R8595[181] = (char *(*)()) F1388_13789;
	R8595[183] = (char *(*)()) F1390_13846;
}

char *(*R9137[161])();
void R9137_init () {
	R9137[0] = (char *(*)()) F1227_11356;
	R9137[42] = (char *(*)()) F1227_11356;
	{long i; for (i = 61; i < 63; i++) R9137[i] = (char *(*)()) F1290_12191;}
	R9137[71] = (char *(*)()) F1227_11356;
	R9137[72] = (char *(*)()) F1302_12311;
	R9137[74] = (char *(*)()) F1304_12355;
	R9137[75] = (char *(*)()) F1227_11356;
	{long i; for (i = 77; i < 79; i++) R9137[i] = (char *(*)()) F1227_11356;}
	R9137[103] = (char *(*)()) F1333_12708;
	R9137[106] = (char *(*)()) F1336_12854;
	{long i; for (i = 113; i < 115; i++) R9137[i] = (char *(*)()) F1227_11356;}
	R9137[116] = (char *(*)()) F1227_11356;
	R9137[118] = (char *(*)()) F1348_13089;
	R9137[120] = (char *(*)()) F1348_13089;
	R9137[121] = (char *(*)()) F1351_13163;
	R9137[124] = (char *(*)()) F1351_13163;
	R9137[134] = (char *(*)()) F1364_13326;
	R9137[140] = (char *(*)()) F1370_13342;
	R9137[144] = (char *(*)()) F1370_13342;
	R9137[157] = (char *(*)()) F1227_11356;
	R9137[160] = (char *(*)()) F1227_11356;
}

char *(*R9139[161])();
void R9139_init () {
	R9139[0] = (char *(*)()) F1227_11359;
	R9139[42] = (char *(*)()) F1227_11359;
	{long i; for (i = 61; i < 63; i++) R9139[i] = (char *(*)()) F1227_11359;}
	{long i; for (i = 71; i < 73; i++) R9139[i] = (char *(*)()) F1227_11359;}
	{long i; for (i = 74; i < 76; i++) R9139[i] = (char *(*)()) F1227_11359;}
	{long i; for (i = 77; i < 79; i++) R9139[i] = (char *(*)()) F1227_11359;}
	R9139[103] = (char *(*)()) F1227_11359;
	R9139[106] = (char *(*)()) F1227_11359;
	{long i; for (i = 113; i < 115; i++) R9139[i] = (char *(*)()) F1227_11359;}
	R9139[116] = (char *(*)()) F1346_13008;
	R9139[118] = (char *(*)()) F1227_11359;
	{long i; for (i = 120; i < 122; i++) R9139[i] = (char *(*)()) F1227_11359;}
	R9139[124] = (char *(*)()) F1227_11359;
	R9139[134] = (char *(*)()) F1227_11359;
	R9139[140] = (char *(*)()) F1227_11359;
	R9139[144] = (char *(*)()) F1227_11359;
	R9139[157] = (char *(*)()) F1387_13680;
	R9139[160] = (char *(*)()) F1390_13847;
}

char *(*R9140[161])();
void R9140_init () {
	R9140[0] = (char *(*)()) F1227_11360;
	R9140[42] = (char *(*)()) F1227_11360;
	{long i; for (i = 61; i < 63; i++) R9140[i] = (char *(*)()) F1227_11360;}
	{long i; for (i = 71; i < 73; i++) R9140[i] = (char *(*)()) F1227_11360;}
	{long i; for (i = 74; i < 76; i++) R9140[i] = (char *(*)()) F1227_11360;}
	{long i; for (i = 77; i < 79; i++) R9140[i] = (char *(*)()) F1227_11360;}
	R9140[103] = (char *(*)()) F1227_11360;
	R9140[106] = (char *(*)()) F1227_11360;
	{long i; for (i = 113; i < 115; i++) R9140[i] = (char *(*)()) F1227_11360;}
	R9140[116] = (char *(*)()) F1227_11360;
	R9140[118] = (char *(*)()) F1227_11360;
	{long i; for (i = 120; i < 122; i++) R9140[i] = (char *(*)()) F1227_11360;}
	R9140[124] = (char *(*)()) F1227_11360;
	R9140[134] = (char *(*)()) F1227_11360;
	R9140[140] = (char *(*)()) F1227_11360;
	R9140[144] = (char *(*)()) F1227_11360;
	R9140[157] = (char *(*)()) F1387_13693;
	R9140[160] = (char *(*)()) F1390_13831;
}

char *(*R9142[161])();
void R9142_init () {
	R9142[0] = (char *(*)()) F1227_11362;
	R9142[42] = (char *(*)()) F1227_11362;
	{long i; for (i = 61; i < 63; i++) R9142[i] = (char *(*)()) F1227_11362;}
	{long i; for (i = 71; i < 73; i++) R9142[i] = (char *(*)()) F1227_11362;}
	{long i; for (i = 74; i < 76; i++) R9142[i] = (char *(*)()) F1227_11362;}
	{long i; for (i = 77; i < 79; i++) R9142[i] = (char *(*)()) F1227_11362;}
	R9142[103] = (char *(*)()) F1227_11362;
	R9142[106] = (char *(*)()) F1227_11362;
	{long i; for (i = 113; i < 115; i++) R9142[i] = (char *(*)()) F1227_11362;}
	R9142[116] = (char *(*)()) F1227_11362;
	R9142[118] = (char *(*)()) F1227_11362;
	{long i; for (i = 120; i < 122; i++) R9142[i] = (char *(*)()) F1227_11362;}
	R9142[124] = (char *(*)()) F1227_11362;
	R9142[134] = (char *(*)()) F1227_11362;
	R9142[140] = (char *(*)()) F1227_11362;
	R9142[144] = (char *(*)()) F1227_11362;
	R9142[157] = (char *(*)()) F1387_13694;
	R9142[160] = (char *(*)()) F1227_11362;
}

char *(*R9145[161])();
void R9145_init () {
	R9145[0] = (char *(*)()) F1227_11365;
	R9145[42] = (char *(*)()) F1227_11365;
	{long i; for (i = 61; i < 63; i++) R9145[i] = (char *(*)()) F1227_11365;}
	{long i; for (i = 71; i < 73; i++) R9145[i] = (char *(*)()) F1227_11365;}
	{long i; for (i = 74; i < 76; i++) R9145[i] = (char *(*)()) F1227_11365;}
	{long i; for (i = 77; i < 79; i++) R9145[i] = (char *(*)()) F1227_11365;}
	R9145[103] = (char *(*)()) F1227_11365;
	R9145[106] = (char *(*)()) F1227_11365;
	{long i; for (i = 113; i < 115; i++) R9145[i] = (char *(*)()) F1227_11365;}
	R9145[116] = (char *(*)()) F1227_11365;
	R9145[118] = (char *(*)()) F1227_11365;
	{long i; for (i = 120; i < 122; i++) R9145[i] = (char *(*)()) F1227_11365;}
	R9145[124] = (char *(*)()) F1227_11365;
	R9145[134] = (char *(*)()) F1227_11365;
	R9145[140] = (char *(*)()) F1227_11365;
	R9145[144] = (char *(*)()) F1227_11365;
	R9145[157] = (char *(*)()) F1387_13695;
	R9145[160] = (char *(*)()) F1227_11365;
}

char *(*R9147[161])();
void R9147_init () {
	R9147[0] = (char *(*)()) F1227_11367;
	R9147[42] = (char *(*)()) F1227_11367;
	{long i; for (i = 61; i < 63; i++) R9147[i] = (char *(*)()) F1227_11367;}
	{long i; for (i = 71; i < 73; i++) R9147[i] = (char *(*)()) F1227_11367;}
	{long i; for (i = 74; i < 76; i++) R9147[i] = (char *(*)()) F1227_11367;}
	{long i; for (i = 77; i < 79; i++) R9147[i] = (char *(*)()) F1227_11367;}
	R9147[103] = (char *(*)()) F1227_11367;
	R9147[106] = (char *(*)()) F1227_11367;
	{long i; for (i = 113; i < 115; i++) R9147[i] = (char *(*)()) F1227_11367;}
	R9147[116] = (char *(*)()) F1227_11367;
	R9147[118] = (char *(*)()) F1227_11367;
	{long i; for (i = 120; i < 122; i++) R9147[i] = (char *(*)()) F1227_11367;}
	R9147[124] = (char *(*)()) F1227_11367;
	R9147[134] = (char *(*)()) F1227_11367;
	R9147[140] = (char *(*)()) F1227_11367;
	R9147[144] = (char *(*)()) F1227_11367;
	R9147[157] = (char *(*)()) F1387_13696;
	R9147[160] = (char *(*)()) F1227_11367;
}

char *(*R9148[161])();
void R9148_init () {
	R9148[0] = (char *(*)()) F1227_11368;
	R9148[42] = (char *(*)()) F1227_11368;
	{long i; for (i = 61; i < 63; i++) R9148[i] = (char *(*)()) F1227_11368;}
	{long i; for (i = 71; i < 73; i++) R9148[i] = (char *(*)()) F1227_11368;}
	R9148[74] = (char *(*)()) F1303_12346;
	R9148[75] = (char *(*)()) F1227_11368;
	{long i; for (i = 77; i < 79; i++) R9148[i] = (char *(*)()) F1227_11368;}
	R9148[103] = (char *(*)()) F1227_11368;
	R9148[106] = (char *(*)()) F1227_11368;
	{long i; for (i = 113; i < 115; i++) R9148[i] = (char *(*)()) F1227_11368;}
	R9148[116] = (char *(*)()) F1346_13007;
	R9148[118] = (char *(*)()) F1348_13129;
	R9148[120] = (char *(*)()) F1348_13129;
	R9148[121] = (char *(*)()) F1227_11368;
	R9148[124] = (char *(*)()) F1227_11368;
	R9148[134] = (char *(*)()) F1227_11368;
	R9148[140] = (char *(*)()) F1227_11368;
	R9148[144] = (char *(*)()) F1227_11368;
	R9148[157] = (char *(*)()) F1227_11368;
	R9148[160] = (char *(*)()) F1227_11368;
}

char *(*R9158[161])();
void R9158_init () {
	R9158[0] = (char *(*)()) F1228_11379;
	R9158[42] = (char *(*)()) F1228_11379;
	{long i; for (i = 61; i < 63; i++) R9158[i] = (char *(*)()) F1278_12005;}
	{long i; for (i = 71; i < 73; i++) R9158[i] = (char *(*)()) F1278_12005;}
	R9158[74] = (char *(*)()) F1278_12005;
	R9158[75] = (char *(*)()) F1228_11379;
	{long i; for (i = 77; i < 79; i++) R9158[i] = (char *(*)()) F1228_11379;}
	R9158[103] = (char *(*)()) F1278_12005;
	R9158[106] = (char *(*)()) F1278_12005;
	{long i; for (i = 113; i < 115; i++) R9158[i] = (char *(*)()) F1278_12005;}
	R9158[116] = (char *(*)()) F1278_12005;
	R9158[118] = (char *(*)()) F1278_12005;
	{long i; for (i = 120; i < 122; i++) R9158[i] = (char *(*)()) F1278_12005;}
	R9158[124] = (char *(*)()) F1278_12005;
	R9158[134] = (char *(*)()) F1228_11379;
	R9158[140] = (char *(*)()) F1228_11379;
	R9158[144] = (char *(*)()) F1228_11379;
	R9158[157] = (char *(*)()) F1278_12005;
	R9158[160] = (char *(*)()) F1278_12005;
}

char *(*R9159[161])();
void R9159_init () {
	R9159[0] = (char *(*)()) F1228_11380;
	R9159[42] = (char *(*)()) F1228_11380;
	{long i; for (i = 61; i < 63; i++) R9159[i] = (char *(*)()) F1278_12006;}
	{long i; for (i = 71; i < 73; i++) R9159[i] = (char *(*)()) F1278_12006;}
	R9159[74] = (char *(*)()) F1278_12006;
	R9159[75] = (char *(*)()) F1228_11380;
	{long i; for (i = 77; i < 79; i++) R9159[i] = (char *(*)()) F1228_11380;}
	R9159[103] = (char *(*)()) F1278_12006;
	R9159[106] = (char *(*)()) F1278_12006;
	{long i; for (i = 113; i < 115; i++) R9159[i] = (char *(*)()) F1278_12006;}
	R9159[116] = (char *(*)()) F1278_12006;
	R9159[118] = (char *(*)()) F1278_12006;
	{long i; for (i = 120; i < 122; i++) R9159[i] = (char *(*)()) F1278_12006;}
	R9159[124] = (char *(*)()) F1278_12006;
	R9159[134] = (char *(*)()) F1228_11380;
	R9159[140] = (char *(*)()) F1228_11380;
	R9159[144] = (char *(*)()) F1228_11380;
	R9159[157] = (char *(*)()) F1278_12006;
	R9159[160] = (char *(*)()) F1278_12006;
}

char *(*R9167[161])();
void R9167_init () {
	R9167[0] = (char *(*)()) F1228_11388;
	R9167[42] = (char *(*)()) F1228_11388;
	{long i; for (i = 61; i < 63; i++) R9167[i] = (char *(*)()) F1228_11388;}
	{long i; for (i = 71; i < 73; i++) R9167[i] = (char *(*)()) F1228_11388;}
	{long i; for (i = 74; i < 76; i++) R9167[i] = (char *(*)()) F1228_11388;}
	{long i; for (i = 77; i < 79; i++) R9167[i] = (char *(*)()) F1228_11388;}
	R9167[103] = (char *(*)()) F1228_11388;
	R9167[106] = (char *(*)()) F1228_11388;
	{long i; for (i = 113; i < 115; i++) R9167[i] = (char *(*)()) F1228_11388;}
	R9167[116] = (char *(*)()) F1228_11388;
	R9167[118] = (char *(*)()) F1228_11388;
	R9167[120] = (char *(*)()) F1228_11388;
	R9167[121] = (char *(*)()) F1351_13162;
	R9167[124] = (char *(*)()) F1351_13162;
	R9167[134] = (char *(*)()) F1228_11388;
	R9167[140] = (char *(*)()) F1228_11388;
	R9167[144] = (char *(*)()) F1228_11388;
	R9167[157] = (char *(*)()) F1228_11388;
	R9167[160] = (char *(*)()) F1228_11388;
}

char *(*R9173[161])();
void R9173_init () {
	R9173[0] = (char *(*)()) F1228_11394;
	R9173[42] = (char *(*)()) F1228_11394;
	{long i; for (i = 61; i < 63; i++) R9173[i] = (char *(*)()) F1228_11394;}
	{long i; for (i = 71; i < 73; i++) R9173[i] = (char *(*)()) F1228_11394;}
	{long i; for (i = 74; i < 76; i++) R9173[i] = (char *(*)()) F1228_11394;}
	{long i; for (i = 77; i < 79; i++) R9173[i] = (char *(*)()) F1228_11394;}
	R9173[103] = (char *(*)()) F1228_11394;
	R9173[106] = (char *(*)()) F1228_11394;
	{long i; for (i = 113; i < 115; i++) R9173[i] = (char *(*)()) F1228_11394;}
	R9173[116] = (char *(*)()) F1228_11394;
	R9173[118] = (char *(*)()) F1228_11394;
	{long i; for (i = 120; i < 122; i++) R9173[i] = (char *(*)()) F1228_11394;}
	R9173[124] = (char *(*)()) F1228_11394;
	R9173[134] = (char *(*)()) F1228_11394;
	R9173[140] = (char *(*)()) F1228_11394;
	R9173[144] = (char *(*)()) F1228_11394;
	R9173[157] = (char *(*)()) F1387_13705;
	R9173[160] = (char *(*)()) F1228_11394;
}

char *(*R9174[161])();
void R9174_init () {
	R9174[0] = (char *(*)()) F1228_11395;
	R9174[42] = (char *(*)()) F1228_11395;
	{long i; for (i = 61; i < 63; i++) R9174[i] = (char *(*)()) F1228_11395;}
	{long i; for (i = 71; i < 73; i++) R9174[i] = (char *(*)()) F1228_11395;}
	R9174[74] = (char *(*)()) F1228_11395;
	R9174[75] = (char *(*)()) F1305_12388;
	{long i; for (i = 77; i < 79; i++) R9174[i] = (char *(*)()) F1305_12388;}
	R9174[103] = (char *(*)()) F1228_11395;
	R9174[106] = (char *(*)()) F1228_11395;
	{long i; for (i = 113; i < 115; i++) R9174[i] = (char *(*)()) F1228_11395;}
	R9174[116] = (char *(*)()) F1228_11395;
	R9174[118] = (char *(*)()) F1228_11395;
	{long i; for (i = 120; i < 122; i++) R9174[i] = (char *(*)()) F1228_11395;}
	R9174[124] = (char *(*)()) F1228_11395;
	R9174[134] = (char *(*)()) F1228_11395;
	R9174[140] = (char *(*)()) F1228_11395;
	R9174[144] = (char *(*)()) F1228_11395;
	R9174[157] = (char *(*)()) F1228_11395;
	R9174[160] = (char *(*)()) F1228_11395;
}

char *(*R9178[161])();
void R9178_init () {
	R9178[0] = (char *(*)()) F1229_11429;
	R9178[42] = (char *(*)()) F1229_11429;
	{long i; for (i = 61; i < 63; i++) R9178[i] = (char *(*)()) F1228_11399;}
	{long i; for (i = 71; i < 73; i++) R9178[i] = (char *(*)()) F1228_11399;}
	R9178[74] = (char *(*)()) F1228_11399;
	R9178[75] = (char *(*)()) F1305_12401;
	{long i; for (i = 77; i < 79; i++) R9178[i] = (char *(*)()) F1305_12401;}
	R9178[103] = (char *(*)()) F1228_11399;
	R9178[106] = (char *(*)()) F1228_11399;
	{long i; for (i = 113; i < 115; i++) R9178[i] = (char *(*)()) F1228_11399;}
	R9178[116] = (char *(*)()) F1228_11399;
	R9178[118] = (char *(*)()) F1228_11399;
	{long i; for (i = 120; i < 122; i++) R9178[i] = (char *(*)()) F1228_11399;}
	R9178[124] = (char *(*)()) F1228_11399;
	R9178[134] = (char *(*)()) F1228_11399;
	R9178[140] = (char *(*)()) F1228_11399;
	R9178[157] = (char *(*)()) F1228_11399;
	R9178[160] = (char *(*)()) F1228_11399;
}

char *(*R9180[161])();
void R9180_init () {
	R9180[0] = (char *(*)()) F1228_11401;
	R9180[42] = (char *(*)()) F1228_11401;
	{long i; for (i = 61; i < 63; i++) R9180[i] = (char *(*)()) F1228_11401;}
	{long i; for (i = 71; i < 73; i++) R9180[i] = (char *(*)()) F1228_11401;}
	{long i; for (i = 74; i < 76; i++) R9180[i] = (char *(*)()) F1228_11401;}
	{long i; for (i = 77; i < 79; i++) R9180[i] = (char *(*)()) F1307_12476;}
	R9180[103] = (char *(*)()) F1228_11401;
	R9180[106] = (char *(*)()) F1228_11401;
	{long i; for (i = 113; i < 115; i++) R9180[i] = (char *(*)()) F1228_11401;}
	R9180[116] = (char *(*)()) F1228_11401;
	R9180[118] = (char *(*)()) F1228_11401;
	{long i; for (i = 120; i < 122; i++) R9180[i] = (char *(*)()) F1228_11401;}
	R9180[124] = (char *(*)()) F1228_11401;
	R9180[134] = (char *(*)()) F1228_11401;
	R9180[140] = (char *(*)()) F1228_11401;
	R9180[144] = (char *(*)()) F1228_11401;
	R9180[157] = (char *(*)()) F1228_11401;
	R9180[160] = (char *(*)()) F1228_11401;
}

char *(*R9190[79])();
void R9190_init () {
	R9190[0] = (char *(*)()) F1229_11411;
	R9190[42] = (char *(*)()) F1229_11411;
	R9190[75] = (char *(*)()) F1229_11411;
	R9190[77] = (char *(*)()) F1229_11411;
	R9190[78] = (char *(*)()) F1308_12494;
}

char *(*R9201[79])();
void R9201_init () {
	R9201[0] = (char *(*)()) F1229_11428;
	R9201[75] = (char *(*)()) F1229_11428;
	{long i; for (i = 77; i < 79; i++) R9201[i] = (char *(*)()) F1307_12484;}
}

char *(*R9202[79])();
void R9202_init () {
	R9202[0] = (char *(*)()) F1229_11430;
	R9202[42] = (char *(*)()) F1229_11430;
	R9202[75] = (char *(*)()) F1305_12404;
	{long i; for (i = 77; i < 79; i++) R9202[i] = (char *(*)()) F1305_12404;}
}

char *(*R9208[79])();
void R9208_init () {
	R9208[0] = (char *(*)()) F1229_11436;
	R9208[42] = (char *(*)()) F1271_11828;
	R9208[75] = (char *(*)()) F1229_11436;
	{long i; for (i = 77; i < 79; i++) R9208[i] = (char *(*)()) F1229_11436;}
}

char *(*R9209[79])();
void R9209_init () {
	R9209[0] = (char *(*)()) F1230_11468;
	R9209[42] = (char *(*)()) F1271_11827;
	R9209[75] = (char *(*)()) F1297_12235;
	{long i; for (i = 77; i < 79; i++) R9209[i] = (char *(*)()) F1297_12235;}
}

char *(*R9210[79])();
void R9210_init () {
	R9210[0] = (char *(*)()) F1230_11469;
	R9210[42] = (char *(*)()) F1271_11826;
	R9210[75] = (char *(*)()) F1278_11992;
	{long i; for (i = 77; i < 79; i++) R9210[i] = (char *(*)()) F1278_11992;}
}

char *(*R9212[79])();
void R9212_init () {
	R9212[0] = (char *(*)()) F1230_11470;
	R9212[42] = (char *(*)()) F1271_11830;
	R9212[75] = (char *(*)()) F1305_12444;
	R9212[77] = (char *(*)()) F1305_12444;
	R9212[78] = (char *(*)()) F1308_12497;
}

char *(*R9213[79])();
void R9213_init () {
	R9213[0] = (char *(*)()) F1229_11441;
	R9213[42] = (char *(*)()) F1229_11441;
	R9213[75] = (char *(*)()) F1305_12424;
	{long i; for (i = 77; i < 79; i++) R9213[i] = (char *(*)()) F1307_12467;}
}

char *(*R9285[84])();
void R9285_init () {
	{long i; for (i = 0; i < 2; i++) R9285[i] = (char *(*)()) F1284_12112;}
	R9285[42] = (char *(*)()) F1333_12723;
	R9285[83] = (char *(*)()) F1238_11542;
}

char *(*R9286[84])();
void R9286_init () {
	{long i; for (i = 0; i < 2; i++) R9286[i] = (char *(*)()) F1284_12113;}
	R9286[42] = (char *(*)()) F1333_12724;
	R9286[83] = (char *(*)()) F1238_11546;
}

static EIF_TYPE_INDEX Y9287_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype3[] = {1194,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype4[] = {1182,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype6[] = {1182,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype7[] = {1182,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype8[] = {1182,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype9[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype10[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype11[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype12[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype13[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype14[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype15[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype16[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype17[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype18[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype19[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype20[] = {1135,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype21[] = {1177,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype22[] = {1194,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype23[] = {1178,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype24[] = {1176,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype25[] = {1176,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype26[] = {1176,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype27[] = {1178,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype28[] = {1177,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype29[] = {1194,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype30[] = {1176,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype31[] = {1176,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype32[] = {1176,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype33[] = {1194,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype34[] = {1194,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype35[] = {1194,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype36[] = {1194,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype37[] = {1182,0xFFFF};
static EIF_TYPE_INDEX Y9287_pgtype38[] = {1182,0xFFFF};
EIF_TYPE_INDEX *Y9287_gen_type [143];
EIF_TYPE_INDEX Y9287 [143];
void Y9287_init (void)
{
	egc_routines_types [9287] = Y9287;
	egc_routines_gen_types [9287] = Y9287_gen_type;
	egc_routines_offset [9287] = 1231;
	Y9287_gen_type [0] = Y9287_pgtype0;
	Y9287_gen_type [1] = Y9287_pgtype1;
	Y9287_gen_type [2] = Y9287_pgtype2;
	Y9287_gen_type [3] = Y9287_pgtype3;
	Y9287_gen_type [4] = Y9287_pgtype4;
	Y9287_gen_type [5] = Y9287_pgtype5;
	Y9287_gen_type [6] = Y9287_pgtype6;
	Y9287_gen_type [8] = Y9287_pgtype7;
	Y9287_gen_type [9] = Y9287_pgtype8;
	Y9287_gen_type [49] = Y9287_pgtype9;
	Y9287_gen_type [50] = Y9287_pgtype10;
	Y9287_gen_type [51] = Y9287_pgtype11;
	Y9287_gen_type [52] = Y9287_pgtype12;
	Y9287_gen_type [53] = Y9287_pgtype13;
	Y9287_gen_type [54] = Y9287_pgtype14;
	Y9287_gen_type [55] = Y9287_pgtype15;
	Y9287_gen_type [56] = Y9287_pgtype16;
	Y9287_gen_type [57] = Y9287_pgtype17;
	Y9287_gen_type [58] = Y9287_pgtype18;
	Y9287_gen_type [59] = Y9287_pgtype19;
	Y9287_gen_type [60] = Y9287_pgtype20;
	Y9287_gen_type [78] = Y9287_pgtype21;
	Y9287_gen_type [79] = Y9287_pgtype22;
	Y9287_gen_type [80] = Y9287_pgtype23;
	Y9287_gen_type [85] = Y9287_pgtype24;
	Y9287_gen_type [86] = Y9287_pgtype25;
	Y9287_gen_type [91] = Y9287_pgtype26;
	Y9287_gen_type [101] = Y9287_pgtype27;
	Y9287_gen_type [102] = Y9287_pgtype28;
	Y9287_gen_type [103] = Y9287_pgtype29;
	Y9287_gen_type [108] = Y9287_pgtype30;
	Y9287_gen_type [109] = Y9287_pgtype31;
	Y9287_gen_type [117] = Y9287_pgtype32;
	Y9287_gen_type [127] = Y9287_pgtype33;
	Y9287_gen_type [128] = Y9287_pgtype34;
	Y9287_gen_type [129] = Y9287_pgtype35;
	Y9287_gen_type [130] = Y9287_pgtype36;
	Y9287_gen_type [137] = Y9287_pgtype37;
	Y9287_gen_type [142] = Y9287_pgtype38;
	Y9287[3] = 1194;
	Y9287[4] = 1182;
	Y9287[6] = 1182;
	{long i; for (i = 8; i < 10; i++) Y9287[i] = 1182;};
	{long i; for (i = 49; i < 61; i++) Y9287[i] = 1135;};
	Y9287[78] = 1177;
	Y9287[79] = 1194;
	Y9287[80] = 1178;
	{long i; for (i = 85; i < 87; i++) Y9287[i] = 1176;};
	Y9287[91] = 1176;
	Y9287[101] = 1178;
	Y9287[102] = 1177;
	Y9287[103] = 1194;
	{long i; for (i = 108; i < 110; i++) Y9287[i] = 1176;};
	Y9287[117] = 1176;
	{long i; for (i = 127; i < 131; i++) Y9287[i] = 1194;};
	Y9287[137] = 1182;
	Y9287[142] = 1182;
}

char *(*R9307[119])();
void R9307_init () {
	R9307[0] = (char *(*)()) F1229_11425;
	{long i; for (i = 19; i < 21; i++) R9307[i] = (char *(*)()) F1228_11372;}
	{long i; for (i = 29; i < 31; i++) R9307[i] = (char *(*)()) F1228_11372;}
	R9307[32] = (char *(*)()) F1228_11372;
	R9307[33] = (char *(*)()) F1229_11425;
	{long i; for (i = 35; i < 37; i++) R9307[i] = (char *(*)()) F1229_11425;}
	R9307[61] = (char *(*)()) F1228_11372;
	R9307[64] = (char *(*)()) F1228_11372;
	{long i; for (i = 71; i < 73; i++) R9307[i] = (char *(*)()) F1228_11372;}
	R9307[74] = (char *(*)()) F1228_11372;
	R9307[76] = (char *(*)()) F1228_11372;
	{long i; for (i = 78; i < 80; i++) R9307[i] = (char *(*)()) F1228_11372;}
	R9307[82] = (char *(*)()) F1228_11372;
	R9307[92] = (char *(*)()) F1228_11372;
	R9307[98] = (char *(*)()) F1228_11372;
	R9307[102] = (char *(*)()) F1228_11372;
	R9307[115] = (char *(*)()) F1228_11372;
	R9307[118] = (char *(*)()) F1228_11372;
}

char *(*R9308[119])();
void R9308_init () {
	R9308[0] = (char *(*)()) F1229_11427;
	{long i; for (i = 19; i < 21; i++) R9308[i] = (char *(*)()) F1228_11373;}
	{long i; for (i = 29; i < 31; i++) R9308[i] = (char *(*)()) F1228_11373;}
	R9308[32] = (char *(*)()) F1228_11373;
	R9308[33] = (char *(*)()) F1229_11427;
	{long i; for (i = 35; i < 37; i++) R9308[i] = (char *(*)()) F1229_11427;}
	R9308[61] = (char *(*)()) F1228_11373;
	R9308[64] = (char *(*)()) F1228_11373;
	{long i; for (i = 71; i < 73; i++) R9308[i] = (char *(*)()) F1228_11373;}
	R9308[74] = (char *(*)()) F1228_11373;
	R9308[76] = (char *(*)()) F1228_11373;
	{long i; for (i = 78; i < 80; i++) R9308[i] = (char *(*)()) F1228_11373;}
	R9308[82] = (char *(*)()) F1228_11373;
	R9308[92] = (char *(*)()) F1228_11373;
	R9308[98] = (char *(*)()) F1228_11373;
	R9308[102] = (char *(*)()) F1228_11373;
	R9308[115] = (char *(*)()) F1228_11373;
	R9308[118] = (char *(*)()) F1228_11373;
}

char *(*R9309[119])();
void R9309_init () {
	R9309[0] = (char *(*)()) F1229_11416;
	{long i; for (i = 19; i < 21; i++) R9309[i] = (char *(*)()) F1278_12003;}
	{long i; for (i = 29; i < 31; i++) R9309[i] = (char *(*)()) F1278_12003;}
	R9309[32] = (char *(*)()) F1278_12003;
	R9309[33] = (char *(*)()) F1229_11416;
	{long i; for (i = 35; i < 37; i++) R9309[i] = (char *(*)()) F1229_11416;}
	R9309[61] = (char *(*)()) F1278_12003;
	R9309[64] = (char *(*)()) F1278_12003;
	{long i; for (i = 71; i < 73; i++) R9309[i] = (char *(*)()) F1278_12003;}
	R9309[74] = (char *(*)()) F1278_12003;
	R9309[76] = (char *(*)()) F1278_12003;
	{long i; for (i = 78; i < 80; i++) R9309[i] = (char *(*)()) F1278_12003;}
	R9309[82] = (char *(*)()) F1278_12003;
	R9309[92] = (char *(*)()) F1228_11396;
	R9309[98] = (char *(*)()) F1228_11396;
	R9309[102] = (char *(*)()) F1228_11396;
	R9309[115] = (char *(*)()) F1278_12003;
	R9309[118] = (char *(*)()) F1390_13820;
}

char *(*R9310[119])();
void R9310_init () {
	R9310[0] = (char *(*)()) F1229_11417;
	{long i; for (i = 19; i < 21; i++) R9310[i] = (char *(*)()) F1278_12004;}
	{long i; for (i = 29; i < 31; i++) R9310[i] = (char *(*)()) F1278_12004;}
	R9310[32] = (char *(*)()) F1278_12004;
	R9310[33] = (char *(*)()) F1229_11417;
	{long i; for (i = 35; i < 37; i++) R9310[i] = (char *(*)()) F1229_11417;}
	R9310[61] = (char *(*)()) F1278_12004;
	R9310[64] = (char *(*)()) F1278_12004;
	{long i; for (i = 71; i < 73; i++) R9310[i] = (char *(*)()) F1278_12004;}
	R9310[74] = (char *(*)()) F1278_12004;
	R9310[76] = (char *(*)()) F1278_12004;
	{long i; for (i = 78; i < 80; i++) R9310[i] = (char *(*)()) F1278_12004;}
	R9310[82] = (char *(*)()) F1278_12004;
	R9310[92] = (char *(*)()) F1228_11397;
	R9310[98] = (char *(*)()) F1228_11397;
	R9310[102] = (char *(*)()) F1228_11397;
	R9310[115] = (char *(*)()) F1278_12004;
	R9310[118] = (char *(*)()) F1390_13821;
}

char *(*R9377[100])();
void R9377_init () {
	{long i; for (i = 0; i < 2; i++) R9377[i] = (char *(*)()) F1246_11653;}
	{long i; for (i = 10; i < 12; i++) R9377[i] = (char *(*)()) F1246_11653;}
	{long i; for (i = 13; i < 15; i++) R9377[i] = (char *(*)()) F1246_11653;}
	{long i; for (i = 16; i < 18; i++) R9377[i] = (char *(*)()) F1246_11653;}
	R9377[42] = (char *(*)()) F1246_11653;
	R9377[45] = (char *(*)()) F1246_11653;
	{long i; for (i = 52; i < 54; i++) R9377[i] = (char *(*)()) F1246_11653;}
	R9377[55] = (char *(*)()) F1246_11653;
	R9377[57] = (char *(*)()) F1246_11653;
	{long i; for (i = 59; i < 61; i++) R9377[i] = (char *(*)()) F1246_11653;}
	R9377[63] = (char *(*)()) F1246_11653;
	{long i; for (i = 96; i < 98; i++) R9377[i] = (char *(*)()) F1386_13603;}
	R9377[99] = (char *(*)()) F1386_13603;
}

char *(*R9378[100])();
void R9378_init () {
	{long i; for (i = 0; i < 2; i++) R9378[i] = (char *(*)()) F1246_11652;}
	{long i; for (i = 10; i < 12; i++) R9378[i] = (char *(*)()) F1246_11652;}
	{long i; for (i = 13; i < 15; i++) R9378[i] = (char *(*)()) F1246_11652;}
	{long i; for (i = 16; i < 18; i++) R9378[i] = (char *(*)()) F1246_11652;}
	R9378[42] = (char *(*)()) F1246_11652;
	R9378[45] = (char *(*)()) F1246_11652;
	{long i; for (i = 52; i < 54; i++) R9378[i] = (char *(*)()) F1246_11652;}
	R9378[55] = (char *(*)()) F1246_11652;
	R9378[57] = (char *(*)()) F1246_11652;
	{long i; for (i = 59; i < 61; i++) R9378[i] = (char *(*)()) F1246_11652;}
	R9378[63] = (char *(*)()) F1246_11652;
	{long i; for (i = 96; i < 98; i++) R9378[i] = (char *(*)()) F1386_13604;}
	R9378[99] = (char *(*)()) F1386_13604;
}

char *(*R9379[100])();
void R9379_init () {
	{long i; for (i = 0; i < 2; i++) R9379[i] = (char *(*)()) F1246_11657;}
	{long i; for (i = 10; i < 12; i++) R9379[i] = (char *(*)()) F1246_11657;}
	{long i; for (i = 13; i < 15; i++) R9379[i] = (char *(*)()) F1246_11657;}
	{long i; for (i = 16; i < 18; i++) R9379[i] = (char *(*)()) F1246_11657;}
	R9379[42] = (char *(*)()) F1246_11657;
	R9379[45] = (char *(*)()) F1246_11657;
	{long i; for (i = 52; i < 54; i++) R9379[i] = (char *(*)()) F1246_11657;}
	R9379[55] = (char *(*)()) F1246_11657;
	R9379[57] = (char *(*)()) F1246_11657;
	R9379[59] = (char *(*)()) F1246_11657;
	R9379[60] = (char *(*)()) F1351_13171;
	R9379[63] = (char *(*)()) F1351_13171;
	{long i; for (i = 96; i < 98; i++) R9379[i] = (char *(*)()) F1386_13614;}
	R9379[99] = (char *(*)()) F1386_13614;
}

char *(*R9380[100])();
void R9380_init () {
	{long i; for (i = 0; i < 2; i++) R9380[i] = (char *(*)()) F1246_11654;}
	{long i; for (i = 10; i < 12; i++) R9380[i] = (char *(*)()) F1246_11654;}
	{long i; for (i = 13; i < 15; i++) R9380[i] = (char *(*)()) F1246_11654;}
	{long i; for (i = 16; i < 18; i++) R9380[i] = (char *(*)()) F1246_11654;}
	R9380[42] = (char *(*)()) F1246_11654;
	R9380[45] = (char *(*)()) F1246_11654;
	{long i; for (i = 52; i < 54; i++) R9380[i] = (char *(*)()) F1246_11654;}
	R9380[55] = (char *(*)()) F1246_11654;
	R9380[57] = (char *(*)()) F1246_11654;
	{long i; for (i = 59; i < 61; i++) R9380[i] = (char *(*)()) F1246_11654;}
	R9380[63] = (char *(*)()) F1246_11654;
	{long i; for (i = 96; i < 98; i++) R9380[i] = (char *(*)()) F1386_13613;}
	R9380[99] = (char *(*)()) F1386_13613;
}

char *(*R9385[100])();
void R9385_init () {
	{long i; for (i = 0; i < 2; i++) R9385[i] = (char *(*)()) F1290_12190;}
	R9385[10] = (char *(*)()) F1246_11660;
	R9385[11] = (char *(*)()) F1302_12323;
	{long i; for (i = 13; i < 15; i++) R9385[i] = (char *(*)()) F1246_11660;}
	{long i; for (i = 16; i < 18; i++) R9385[i] = (char *(*)()) F1246_11660;}
	R9385[42] = (char *(*)()) F1246_11660;
	R9385[45] = (char *(*)()) F1336_12853;
	{long i; for (i = 52; i < 54; i++) R9385[i] = (char *(*)()) F1246_11660;}
	R9385[55] = (char *(*)()) F1246_11660;
	R9385[57] = (char *(*)()) F1348_13126;
	R9385[59] = (char *(*)()) F1348_13126;
	R9385[60] = (char *(*)()) F1246_11660;
	R9385[63] = (char *(*)()) F1246_11660;
	R9385[96] = (char *(*)()) F1246_11660;
	R9385[99] = (char *(*)()) F1246_11660;
}

char *(*R9386[100])();
void R9386_init () {
	{long i; for (i = 0; i < 2; i++) R9386[i] = (char *(*)()) F1246_11661;}
	{long i; for (i = 10; i < 12; i++) R9386[i] = (char *(*)()) F1246_11661;}
	{long i; for (i = 13; i < 15; i++) R9386[i] = (char *(*)()) F1246_11661;}
	{long i; for (i = 16; i < 18; i++) R9386[i] = (char *(*)()) F1246_11661;}
	R9386[42] = (char *(*)()) F1246_11661;
	R9386[45] = (char *(*)()) F1246_11661;
	{long i; for (i = 52; i < 54; i++) R9386[i] = (char *(*)()) F1246_11661;}
	R9386[55] = (char *(*)()) F1345_12966;
	R9386[57] = (char *(*)()) F1345_12966;
	R9386[59] = (char *(*)()) F1345_12966;
	R9386[60] = (char *(*)()) F1246_11661;
	R9386[63] = (char *(*)()) F1246_11661;
	R9386[96] = (char *(*)()) F1246_11661;
	R9386[99] = (char *(*)()) F1246_11661;
}

char *(*R9387[100])();
void R9387_init () {
	{long i; for (i = 0; i < 2; i++) R9387[i] = (char *(*)()) F1246_11662;}
	{long i; for (i = 10; i < 12; i++) R9387[i] = (char *(*)()) F1246_11662;}
	{long i; for (i = 13; i < 15; i++) R9387[i] = (char *(*)()) F1246_11662;}
	{long i; for (i = 16; i < 18; i++) R9387[i] = (char *(*)()) F1246_11662;}
	R9387[42] = (char *(*)()) F1246_11662;
	R9387[45] = (char *(*)()) F1246_11662;
	{long i; for (i = 52; i < 54; i++) R9387[i] = (char *(*)()) F1246_11662;}
	R9387[55] = (char *(*)()) F1345_12967;
	R9387[57] = (char *(*)()) F1345_12967;
	R9387[59] = (char *(*)()) F1345_12967;
	R9387[60] = (char *(*)()) F1246_11662;
	R9387[63] = (char *(*)()) F1246_11662;
	R9387[96] = (char *(*)()) F1246_11662;
	R9387[99] = (char *(*)()) F1246_11662;
}

char *(*R9392[100])();
void R9392_init () {
	{long i; for (i = 0; i < 2; i++) R9392[i] = (char *(*)()) F1227_11368;}
	{long i; for (i = 10; i < 12; i++) R9392[i] = (char *(*)()) F1227_11368;}
	R9392[13] = (char *(*)()) F1303_12346;
	R9392[14] = (char *(*)()) F1227_11368;
	{long i; for (i = 16; i < 18; i++) R9392[i] = (char *(*)()) F1227_11368;}
	R9392[42] = (char *(*)()) F1227_11368;
	R9392[45] = (char *(*)()) F1227_11368;
	{long i; for (i = 52; i < 54; i++) R9392[i] = (char *(*)()) F1227_11368;}
	R9392[55] = (char *(*)()) F1346_13007;
	R9392[57] = (char *(*)()) F1348_13129;
	R9392[59] = (char *(*)()) F1348_13129;
	R9392[60] = (char *(*)()) F1227_11368;
	R9392[63] = (char *(*)()) F1227_11368;
	R9392[96] = (char *(*)()) F1227_11368;
	R9392[99] = (char *(*)()) F1227_11368;
}

char *(*R9394[100])();
void R9394_init () {
	{long i; for (i = 0; i < 2; i++) R9394[i] = (char *(*)()) F1290_12191;}
	R9394[10] = (char *(*)()) F1227_11356;
	R9394[11] = (char *(*)()) F1302_12311;
	R9394[13] = (char *(*)()) F1304_12355;
	R9394[14] = (char *(*)()) F1227_11356;
	{long i; for (i = 16; i < 18; i++) R9394[i] = (char *(*)()) F1227_11356;}
	R9394[42] = (char *(*)()) F1333_12708;
	R9394[45] = (char *(*)()) F1336_12854;
	{long i; for (i = 52; i < 54; i++) R9394[i] = (char *(*)()) F1227_11356;}
	R9394[55] = (char *(*)()) F1227_11356;
	R9394[57] = (char *(*)()) F1348_13089;
	R9394[59] = (char *(*)()) F1348_13089;
	R9394[60] = (char *(*)()) F1351_13163;
	R9394[63] = (char *(*)()) F1351_13163;
	R9394[96] = (char *(*)()) F1227_11356;
	R9394[99] = (char *(*)()) F1227_11356;
}

char *(*R9398[100])();
void R9398_init () {
	{long i; for (i = 0; i < 2; i++) R9398[i] = (char *(*)()) F1246_11673;}
	{long i; for (i = 10; i < 12; i++) R9398[i] = (char *(*)()) F1246_11673;}
	{long i; for (i = 13; i < 15; i++) R9398[i] = (char *(*)()) F1246_11673;}
	{long i; for (i = 16; i < 18; i++) R9398[i] = (char *(*)()) F1246_11673;}
	R9398[42] = (char *(*)()) F1246_11673;
	R9398[45] = (char *(*)()) F1246_11673;
	{long i; for (i = 52; i < 54; i++) R9398[i] = (char *(*)()) F1246_11673;}
	R9398[55] = (char *(*)()) F1246_11673;
	R9398[57] = (char *(*)()) F1246_11673;
	R9398[59] = (char *(*)()) F1246_11673;
	R9398[60] = (char *(*)()) F1351_13173;
	R9398[63] = (char *(*)()) F1351_13173;
	R9398[96] = (char *(*)()) F1246_11673;
	R9398[99] = (char *(*)()) F1246_11673;
}

char *(*R9428[100])();
void R9428_init () {
	{long i; for (i = 0; i < 2; i++) R9428[i] = (char *(*)()) F1278_11997;}
	{long i; for (i = 10; i < 12; i++) R9428[i] = (char *(*)()) F1278_11997;}
	{long i; for (i = 13; i < 15; i++) R9428[i] = (char *(*)()) F1278_11997;}
	{long i; for (i = 16; i < 18; i++) R9428[i] = (char *(*)()) F1278_11997;}
	R9428[42] = (char *(*)()) F1278_11997;
	R9428[45] = (char *(*)()) F1278_11997;
	{long i; for (i = 52; i < 54; i++) R9428[i] = (char *(*)()) F1278_11997;}
	R9428[55] = (char *(*)()) F1278_11997;
	R9428[57] = (char *(*)()) F1278_11997;
	{long i; for (i = 59; i < 61; i++) R9428[i] = (char *(*)()) F1278_11997;}
	R9428[63] = (char *(*)()) F1278_11997;
	R9428[79] = (char *(*)()) F1355_13196;
	R9428[83] = (char *(*)()) F1369_13334;
	R9428[96] = (char *(*)()) F1278_11997;
	R9428[99] = (char *(*)()) F1278_11997;
}

char *(*R9441[58])();
void R9441_init () {
	R9441[0] = (char *(*)()) F1227_11368;
	R9441[3] = (char *(*)()) F1227_11368;
	{long i; for (i = 10; i < 12; i++) R9441[i] = (char *(*)()) F1227_11368;}
	R9441[13] = (char *(*)()) F1346_13007;
	R9441[15] = (char *(*)()) F1348_13129;
	R9441[17] = (char *(*)()) F1348_13129;
	R9441[18] = (char *(*)()) F1227_11368;
	R9441[21] = (char *(*)()) F1227_11368;
	R9441[54] = (char *(*)()) F1227_11368;
	R9441[57] = (char *(*)()) F1227_11368;
}

char *(*R9445[84])();
void R9445_init () {
	{long i; for (i = 0; i < 2; i++) R9445[i] = (char *(*)()) F1280_12075;}
	{long i; for (i = 10; i < 12; i++) R9445[i] = (char *(*)()) F1280_12075;}
	{long i; for (i = 13; i < 15; i++) R9445[i] = (char *(*)()) F1280_12075;}
	{long i; for (i = 16; i < 18; i++) R9445[i] = (char *(*)()) F1280_12075;}
	R9445[60] = (char *(*)()) F1260_11747;
	R9445[63] = (char *(*)()) F1260_11747;
	R9445[73] = (char *(*)()) F1260_11747;
	R9445[79] = (char *(*)()) F1260_11747;
	R9445[83] = (char *(*)()) F1260_11747;
}

char *(*R9455[89])();
void R9455_init () {
	R9455[0] = (char *(*)()) F1262_11759;
	R9455[34] = (char *(*)()) F1262_11759;
	R9455[44] = (char *(*)()) F1262_11759;
	R9455[46] = (char *(*)()) F1262_11759;
	{long i; for (i = 48; i < 50; i++) R9455[i] = (char *(*)()) F1262_11759;}
	R9455[52] = (char *(*)()) F1262_11759;
	{long i; for (i = 85; i < 87; i++) R9455[i] = (char *(*)()) F1386_13612;}
	R9455[88] = (char *(*)()) F1386_13612;
}

char *(*R9456[53])();
void R9456_init () {
	R9456[0] = (char *(*)()) F1227_11368;
	R9456[34] = (char *(*)()) F1227_11368;
	R9456[44] = (char *(*)()) F1346_13007;
	R9456[46] = (char *(*)()) F1348_13129;
	R9456[48] = (char *(*)()) F1348_13129;
	R9456[49] = (char *(*)()) F1227_11368;
	R9456[52] = (char *(*)()) F1227_11368;
}

char *(*R9457[53])();
void R9457_init () {
	R9457[0] = (char *(*)()) F1262_11761;
	R9457[34] = (char *(*)()) F1262_11761;
	R9457[44] = (char *(*)()) F1262_11761;
	R9457[46] = (char *(*)()) F1262_11761;
	R9457[48] = (char *(*)()) F1262_11761;
	R9457[49] = (char *(*)()) F1351_13161;
	R9457[52] = (char *(*)()) F1351_13161;
}

char *(*R9459[73])();
void R9459_init () {
	R9459[0] = (char *(*)()) F1302_12320;
	R9459[34] = (char *(*)()) F1264_11768;
	R9459[44] = (char *(*)()) F1346_12989;
	R9459[46] = (char *(*)()) F1348_13092;
	R9459[48] = (char *(*)()) F1348_13092;
	R9459[49] = (char *(*)()) F1264_11768;
	R9459[52] = (char *(*)()) F1264_11768;
	R9459[68] = (char *(*)()) F1264_11768;
	R9459[72] = (char *(*)()) F1264_11768;
}

char *(*R9460[73])();
void R9460_init () {
	R9460[0] = (char *(*)()) F1302_12321;
	R9460[34] = (char *(*)()) F1264_11773;
	R9460[44] = (char *(*)()) F1346_12999;
	R9460[46] = (char *(*)()) F1348_13094;
	R9460[48] = (char *(*)()) F1348_13094;
	R9460[49] = (char *(*)()) F1264_11773;
	R9460[52] = (char *(*)()) F1354_13194;
	R9460[68] = (char *(*)()) F1370_13345;
	R9460[72] = (char *(*)()) F1370_13345;
}

char *(*R9468[39])();
void R9468_init () {
	R9468[0] = (char *(*)()) F1264_11776;
	R9468[15] = (char *(*)()) F1264_11776;
	R9468[18] = (char *(*)()) F1264_11776;
	R9468[34] = (char *(*)()) F1370_13349;
	R9468[38] = (char *(*)()) F1370_13349;
}

char *(*R9472[53])();
void R9472_init () {
	R9472[0] = (char *(*)()) F1302_12318;
	R9472[34] = (char *(*)()) F1264_11770;
	R9472[46] = (char *(*)()) F1348_13100;
	R9472[48] = (char *(*)()) F1348_13100;
	R9472[49] = (char *(*)()) F1351_13165;
	R9472[52] = (char *(*)()) F1351_13165;
}

char *(*R9473[53])();
void R9473_init () {
	R9473[0] = (char *(*)()) F1302_12316;
	R9473[34] = (char *(*)()) F1264_11771;
	R9473[46] = (char *(*)()) F1348_13098;
	R9473[48] = (char *(*)()) F1348_13098;
	R9473[49] = (char *(*)()) F1351_13166;
	R9473[52] = (char *(*)()) F1351_13166;
}

char *(*R9569[100])();
void R9569_init () {
	{long i; for (i = 0; i < 2; i++) R9569[i] = (char *(*)()) F1276_11923;}
	{long i; for (i = 10; i < 12; i++) R9569[i] = (char *(*)()) F1276_11923;}
	{long i; for (i = 13; i < 15; i++) R9569[i] = (char *(*)()) F1276_11923;}
	{long i; for (i = 16; i < 18; i++) R9569[i] = (char *(*)()) F1276_11923;}
	R9569[42] = (char *(*)()) F1276_11923;
	R9569[45] = (char *(*)()) F1276_11923;
	{long i; for (i = 52; i < 54; i++) R9569[i] = (char *(*)()) F1276_11923;}
	R9569[55] = (char *(*)()) F1276_11923;
	R9569[57] = (char *(*)()) F1276_11923;
	{long i; for (i = 59; i < 61; i++) R9569[i] = (char *(*)()) F1276_11923;}
	R9569[63] = (char *(*)()) F1276_11923;
	R9569[73] = (char *(*)()) F1276_11923;
	R9569[79] = (char *(*)()) F1276_11923;
	R9569[83] = (char *(*)()) F1276_11923;
	R9569[96] = (char *(*)()) F1387_13697;
	R9569[99] = (char *(*)()) F1276_11923;
}

char *(*R9571[100])();
void R9571_init () {
	{long i; for (i = 0; i < 2; i++) R9571[i] = (char *(*)()) F170_3403;}
	{long i; for (i = 10; i < 12; i++) R9571[i] = (char *(*)()) F170_3403;}
	{long i; for (i = 13; i < 15; i++) R9571[i] = (char *(*)()) F170_3403;}
	{long i; for (i = 16; i < 18; i++) R9571[i] = (char *(*)()) F170_3403;}
	R9571[42] = (char *(*)()) F170_3403;
	R9571[45] = (char *(*)()) F170_3403;
	{long i; for (i = 52; i < 54; i++) R9571[i] = (char *(*)()) F170_3403;}
	R9571[55] = (char *(*)()) F170_3403;
	R9571[57] = (char *(*)()) F170_3403;
	{long i; for (i = 59; i < 61; i++) R9571[i] = (char *(*)()) F170_3403;}
	R9571[63] = (char *(*)()) F170_3403;
	R9571[73] = (char *(*)()) F82_1280;
	R9571[79] = (char *(*)()) F82_1280;
	R9571[83] = (char *(*)()) F82_1280;
	R9571[96] = (char *(*)()) F170_3403;
	R9571[99] = (char *(*)()) F170_3403;
}

char *(*R9572[100])();
void R9572_init () {
	{long i; for (i = 0; i < 2; i++) R9572[i] = (char *(*)()) F1278_11996;}
	{long i; for (i = 10; i < 12; i++) R9572[i] = (char *(*)()) F1278_11996;}
	{long i; for (i = 13; i < 15; i++) R9572[i] = (char *(*)()) F1278_11996;}
	{long i; for (i = 16; i < 18; i++) R9572[i] = (char *(*)()) F1278_11996;}
	R9572[42] = (char *(*)()) F1278_11996;
	R9572[45] = (char *(*)()) F1278_11996;
	{long i; for (i = 52; i < 54; i++) R9572[i] = (char *(*)()) F1278_11996;}
	R9572[55] = (char *(*)()) F1278_11996;
	R9572[57] = (char *(*)()) F1278_11996;
	{long i; for (i = 59; i < 61; i++) R9572[i] = (char *(*)()) F1278_11996;}
	R9572[63] = (char *(*)()) F1278_11996;
	R9572[73] = (char *(*)()) F1363_13319;
	R9572[79] = (char *(*)()) F1363_13319;
	R9572[83] = (char *(*)()) F1363_13319;
	R9572[96] = (char *(*)()) F1387_13706;
	R9572[99] = (char *(*)()) F1278_11996;
}

char *(*R9579[100])();
void R9579_init () {
	{long i; for (i = 0; i < 2; i++) R9579[i] = (char *(*)()) F1243_11591;}
	{long i; for (i = 10; i < 12; i++) R9579[i] = (char *(*)()) F1243_11591;}
	{long i; for (i = 13; i < 15; i++) R9579[i] = (char *(*)()) F1243_11591;}
	{long i; for (i = 16; i < 18; i++) R9579[i] = (char *(*)()) F1243_11591;}
	R9579[42] = (char *(*)()) F1243_11591;
	R9579[45] = (char *(*)()) F1243_11591;
	{long i; for (i = 52; i < 54; i++) R9579[i] = (char *(*)()) F1243_11591;}
	R9579[55] = (char *(*)()) F1243_11591;
	R9579[57] = (char *(*)()) F1243_11591;
	{long i; for (i = 59; i < 61; i++) R9579[i] = (char *(*)()) F1243_11591;}
	R9579[63] = (char *(*)()) F1243_11591;
	R9579[73] = (char *(*)()) F1364_13327;
	R9579[79] = (char *(*)()) F1370_13343;
	R9579[83] = (char *(*)()) F1370_13343;
	R9579[96] = (char *(*)()) F1243_11591;
	R9579[99] = (char *(*)()) F1243_11591;
}

char *(*R9596[100])();
void R9596_init () {
	{long i; for (i = 0; i < 2; i++) R9596[i] = (char *(*)()) F1228_11401;}
	{long i; for (i = 10; i < 12; i++) R9596[i] = (char *(*)()) F1228_11401;}
	{long i; for (i = 13; i < 15; i++) R9596[i] = (char *(*)()) F1228_11401;}
	{long i; for (i = 16; i < 18; i++) R9596[i] = (char *(*)()) F1307_12476;}
	R9596[42] = (char *(*)()) F1228_11401;
	R9596[45] = (char *(*)()) F1228_11401;
	{long i; for (i = 52; i < 54; i++) R9596[i] = (char *(*)()) F1228_11401;}
	R9596[55] = (char *(*)()) F1228_11401;
	R9596[57] = (char *(*)()) F1228_11401;
	{long i; for (i = 59; i < 61; i++) R9596[i] = (char *(*)()) F1228_11401;}
	R9596[63] = (char *(*)()) F1228_11401;
	R9596[96] = (char *(*)()) F1228_11401;
	R9596[99] = (char *(*)()) F1228_11401;
}

char *(*R9597[100])();
void R9597_init () {
	{long i; for (i = 0; i < 2; i++) R9597[i] = (char *(*)()) F1228_11395;}
	{long i; for (i = 10; i < 12; i++) R9597[i] = (char *(*)()) F1228_11395;}
	R9597[13] = (char *(*)()) F1228_11395;
	R9597[14] = (char *(*)()) F1305_12388;
	{long i; for (i = 16; i < 18; i++) R9597[i] = (char *(*)()) F1305_12388;}
	R9597[42] = (char *(*)()) F1228_11395;
	R9597[45] = (char *(*)()) F1228_11395;
	{long i; for (i = 52; i < 54; i++) R9597[i] = (char *(*)()) F1228_11395;}
	R9597[55] = (char *(*)()) F1228_11395;
	R9597[57] = (char *(*)()) F1228_11395;
	{long i; for (i = 59; i < 61; i++) R9597[i] = (char *(*)()) F1228_11395;}
	R9597[63] = (char *(*)()) F1228_11395;
	R9597[96] = (char *(*)()) F1228_11395;
	R9597[99] = (char *(*)()) F1228_11395;
}

char *(*R9599[100])();
void R9599_init () {
	{long i; for (i = 0; i < 2; i++) R9599[i] = (char *(*)()) F1278_11998;}
	{long i; for (i = 10; i < 12; i++) R9599[i] = (char *(*)()) F1278_11998;}
	R9599[13] = (char *(*)()) F1278_11998;
	R9599[14] = (char *(*)()) F1305_12404;
	{long i; for (i = 16; i < 18; i++) R9599[i] = (char *(*)()) F1305_12404;}
	R9599[42] = (char *(*)()) F1278_11998;
	R9599[45] = (char *(*)()) F1278_11998;
	{long i; for (i = 52; i < 54; i++) R9599[i] = (char *(*)()) F1278_11998;}
	R9599[55] = (char *(*)()) F1278_11998;
	R9599[57] = (char *(*)()) F1278_11998;
	{long i; for (i = 59; i < 61; i++) R9599[i] = (char *(*)()) F1278_11998;}
	R9599[63] = (char *(*)()) F1278_11998;
	R9599[96] = (char *(*)()) F1278_11998;
	R9599[99] = (char *(*)()) F1278_11998;
}

char *(*R9600[100])();
void R9600_init () {
	{long i; for (i = 0; i < 2; i++) R9600[i] = (char *(*)()) F1228_11399;}
	{long i; for (i = 10; i < 12; i++) R9600[i] = (char *(*)()) F1228_11399;}
	R9600[13] = (char *(*)()) F1228_11399;
	R9600[14] = (char *(*)()) F1305_12401;
	{long i; for (i = 16; i < 18; i++) R9600[i] = (char *(*)()) F1305_12401;}
	R9600[42] = (char *(*)()) F1228_11399;
	R9600[45] = (char *(*)()) F1228_11399;
	{long i; for (i = 52; i < 54; i++) R9600[i] = (char *(*)()) F1228_11399;}
	R9600[55] = (char *(*)()) F1228_11399;
	R9600[57] = (char *(*)()) F1228_11399;
	{long i; for (i = 59; i < 61; i++) R9600[i] = (char *(*)()) F1228_11399;}
	R9600[63] = (char *(*)()) F1228_11399;
	R9600[96] = (char *(*)()) F1228_11399;
	R9600[99] = (char *(*)()) F1228_11399;
}

char *(*R9616[100])();
void R9616_init () {
	{long i; for (i = 0; i < 2; i++) R9616[i] = (char *(*)()) F1281_12089;}
	{long i; for (i = 10; i < 12; i++) R9616[i] = (char *(*)()) F1293_12202;}
	R9616[13] = (char *(*)()) F1293_12202;
	R9616[14] = (char *(*)()) F1297_12262;
	{long i; for (i = 16; i < 18; i++) R9616[i] = (char *(*)()) F1297_12262;}
	R9616[42] = (char *(*)()) F1312_12556;
	R9616[45] = (char *(*)()) F1332_12700;
	{long i; for (i = 52; i < 54; i++) R9616[i] = (char *(*)()) F1332_12700;}
	R9616[55] = (char *(*)()) F1332_12700;
	R9616[57] = (char *(*)()) F1332_12700;
	{long i; for (i = 59; i < 61; i++) R9616[i] = (char *(*)()) F1332_12700;}
	R9616[63] = (char *(*)()) F1332_12700;
	R9616[96] = (char *(*)()) F1332_12700;
	R9616[99] = (char *(*)()) F1332_12700;
}

char *(*R9620[100])();
void R9620_init () {
	{long i; for (i = 0; i < 2; i++) R9620[i] = (char *(*)()) F1278_11992;}
	{long i; for (i = 10; i < 12; i++) R9620[i] = (char *(*)()) F1278_11992;}
	{long i; for (i = 13; i < 15; i++) R9620[i] = (char *(*)()) F1278_11992;}
	{long i; for (i = 16; i < 18; i++) R9620[i] = (char *(*)()) F1278_11992;}
	R9620[42] = (char *(*)()) F1278_11992;
	R9620[45] = (char *(*)()) F1278_11992;
	{long i; for (i = 52; i < 54; i++) R9620[i] = (char *(*)()) F1278_11992;}
	R9620[55] = (char *(*)()) F1278_11992;
	R9620[57] = (char *(*)()) F1348_13104;
	R9620[59] = (char *(*)()) F1348_13104;
	R9620[60] = (char *(*)()) F1278_11992;
	R9620[63] = (char *(*)()) F1278_11992;
	R9620[96] = (char *(*)()) F1278_11992;
	R9620[99] = (char *(*)()) F1278_11992;
}

char *(*R9621[100])();
void R9621_init () {
	{long i; for (i = 0; i < 2; i++) R9621[i] = (char *(*)()) F1278_11993;}
	{long i; for (i = 10; i < 12; i++) R9621[i] = (char *(*)()) F1278_11993;}
	R9621[13] = (char *(*)()) F1304_12375;
	R9621[14] = (char *(*)()) F1305_12424;
	{long i; for (i = 16; i < 18; i++) R9621[i] = (char *(*)()) F1307_12467;}
	R9621[42] = (char *(*)()) F1278_11993;
	R9621[45] = (char *(*)()) F1278_11993;
	{long i; for (i = 52; i < 54; i++) R9621[i] = (char *(*)()) F1278_11993;}
	R9621[55] = (char *(*)()) F1278_11993;
	R9621[57] = (char *(*)()) F1278_11993;
	{long i; for (i = 59; i < 61; i++) R9621[i] = (char *(*)()) F1278_11993;}
	R9621[63] = (char *(*)()) F1278_11993;
	R9621[96] = (char *(*)()) F1387_13698;
	R9621[99] = (char *(*)()) F1278_11993;
}

char *(*R9622[100])();
void R9622_init () {
	{long i; for (i = 0; i < 2; i++) R9622[i] = (char *(*)()) F1278_11994;}
	{long i; for (i = 10; i < 12; i++) R9622[i] = (char *(*)()) F1278_11994;}
	R9622[13] = (char *(*)()) F1278_11994;
	R9622[14] = (char *(*)()) F1305_12442;
	{long i; for (i = 16; i < 18; i++) R9622[i] = (char *(*)()) F1305_12442;}
	R9622[42] = (char *(*)()) F1278_11994;
	R9622[45] = (char *(*)()) F1278_11994;
	{long i; for (i = 52; i < 54; i++) R9622[i] = (char *(*)()) F1278_11994;}
	R9622[55] = (char *(*)()) F1278_11994;
	R9622[57] = (char *(*)()) F1278_11994;
	R9622[59] = (char *(*)()) F1278_11994;
	R9622[60] = (char *(*)()) F1351_13172;
	R9622[63] = (char *(*)()) F1351_13172;
	R9622[96] = (char *(*)()) F1278_11994;
	R9622[99] = (char *(*)()) F1278_11994;
}

char *(*R9631[100])();
void R9631_init () {
	{long i; for (i = 0; i < 2; i++) R9631[i] = (char *(*)()) F1280_12083;}
	{long i; for (i = 10; i < 12; i++) R9631[i] = (char *(*)()) F1280_12083;}
	{long i; for (i = 13; i < 15; i++) R9631[i] = (char *(*)()) F1280_12083;}
	{long i; for (i = 16; i < 18; i++) R9631[i] = (char *(*)()) F1280_12083;}
	R9631[42] = (char *(*)()) F1333_12712;
	R9631[45] = (char *(*)()) F1278_12019;
	{long i; for (i = 52; i < 54; i++) R9631[i] = (char *(*)()) F1278_12019;}
	R9631[55] = (char *(*)()) F1278_12019;
	R9631[57] = (char *(*)()) F1278_12019;
	{long i; for (i = 59; i < 61; i++) R9631[i] = (char *(*)()) F1278_12019;}
	R9631[63] = (char *(*)()) F1278_12019;
	R9631[96] = (char *(*)()) F1278_12019;
	R9631[99] = (char *(*)()) F1278_12019;
}

char *(*R9633[100])();
void R9633_init () {
	{long i; for (i = 0; i < 2; i++) R9633[i] = (char *(*)()) F1278_12022;}
	{long i; for (i = 10; i < 12; i++) R9633[i] = (char *(*)()) F1278_12022;}
	R9633[13] = (char *(*)()) F1278_12022;
	R9633[14] = (char *(*)()) F1305_12413;
	{long i; for (i = 16; i < 18; i++) R9633[i] = (char *(*)()) F1305_12413;}
	R9633[42] = (char *(*)()) F1278_12022;
	R9633[45] = (char *(*)()) F1278_12022;
	{long i; for (i = 52; i < 54; i++) R9633[i] = (char *(*)()) F1278_12022;}
	R9633[55] = (char *(*)()) F1278_12022;
	R9633[57] = (char *(*)()) F1278_12022;
	{long i; for (i = 59; i < 61; i++) R9633[i] = (char *(*)()) F1278_12022;}
	R9633[63] = (char *(*)()) F1278_12022;
	R9633[96] = (char *(*)()) F1278_12022;
	R9633[99] = (char *(*)()) F1278_12022;
}

char *(*R9635[100])();
void R9635_init () {
	{long i; for (i = 0; i < 2; i++) R9635[i] = (char *(*)()) F1278_12024;}
	{long i; for (i = 10; i < 12; i++) R9635[i] = (char *(*)()) F1278_12024;}
	R9635[13] = (char *(*)()) F1278_12024;
	R9635[14] = (char *(*)()) F1305_12415;
	{long i; for (i = 16; i < 18; i++) R9635[i] = (char *(*)()) F1305_12415;}
	R9635[42] = (char *(*)()) F1278_12024;
	R9635[45] = (char *(*)()) F1278_12024;
	{long i; for (i = 52; i < 54; i++) R9635[i] = (char *(*)()) F1278_12024;}
	R9635[55] = (char *(*)()) F1278_12024;
	R9635[57] = (char *(*)()) F1278_12024;
	{long i; for (i = 59; i < 61; i++) R9635[i] = (char *(*)()) F1278_12024;}
	R9635[63] = (char *(*)()) F1278_12024;
	R9635[96] = (char *(*)()) F1278_12024;
	R9635[99] = (char *(*)()) F1278_12024;
}

char *(*R9636[100])();
void R9636_init () {
	{long i; for (i = 0; i < 2; i++) R9636[i] = (char *(*)()) F1278_12025;}
	{long i; for (i = 10; i < 12; i++) R9636[i] = (char *(*)()) F1278_12025;}
	R9636[13] = (char *(*)()) F1303_12341;
	R9636[14] = (char *(*)()) F1278_12025;
	{long i; for (i = 16; i < 18; i++) R9636[i] = (char *(*)()) F1278_12025;}
	R9636[42] = (char *(*)()) F1278_12025;
	R9636[45] = (char *(*)()) F1278_12025;
	{long i; for (i = 52; i < 54; i++) R9636[i] = (char *(*)()) F1278_12025;}
	R9636[55] = (char *(*)()) F1278_12025;
	R9636[57] = (char *(*)()) F1278_12025;
	{long i; for (i = 59; i < 61; i++) R9636[i] = (char *(*)()) F1278_12025;}
	R9636[63] = (char *(*)()) F1278_12025;
	R9636[96] = (char *(*)()) F1278_12025;
	R9636[99] = (char *(*)()) F1278_12025;
}

char *(*R9643[18])();
void R9643_init () {
	{long i; for (i = 0; i < 2; i++) R9643[i] = (char *(*)()) F1232_11490;}
	{long i; for (i = 10; i < 12; i++) R9643[i] = (char *(*)()) F1279_12033;}
	{long i; for (i = 13; i < 15; i++) R9643[i] = (char *(*)()) F1279_12033;}
	{long i; for (i = 16; i < 18; i++) R9643[i] = (char *(*)()) F1279_12033;}
}

char *(*R9646[18])();
void R9646_init () {
	{long i; for (i = 0; i < 2; i++) R9646[i] = (char *(*)()) F1232_11491;}
	{long i; for (i = 10; i < 12; i++) R9646[i] = (char *(*)()) F1301_12307;}
	{long i; for (i = 13; i < 15; i++) R9646[i] = (char *(*)()) F1301_12307;}
	{long i; for (i = 16; i < 18; i++) R9646[i] = (char *(*)()) F1301_12307;}
}

char *(*R9647[18])();
void R9647_init () {
	{long i; for (i = 0; i < 2; i++) R9647[i] = (char *(*)()) F1280_12062;}
	{long i; for (i = 10; i < 12; i++) R9647[i] = (char *(*)()) F1280_12062;}
	R9647[13] = (char *(*)()) F1280_12062;
	R9647[14] = (char *(*)()) F1229_11422;
	{long i; for (i = 16; i < 18; i++) R9647[i] = (char *(*)()) F1229_11422;}
}

char *(*R9648[18])();
void R9648_init () {
	{long i; for (i = 0; i < 2; i++) R9648[i] = (char *(*)()) F1280_12063;}
	{long i; for (i = 10; i < 12; i++) R9648[i] = (char *(*)()) F1280_12063;}
	R9648[13] = (char *(*)()) F1280_12063;
	R9648[14] = (char *(*)()) F1229_11423;
	{long i; for (i = 16; i < 18; i++) R9648[i] = (char *(*)()) F1229_11423;}
}

char *(*R9650[18])();
void R9650_init () {
	{long i; for (i = 0; i < 2; i++) R9650[i] = (char *(*)()) F1232_11510;}
	{long i; for (i = 10; i < 12; i++) R9650[i] = (char *(*)()) F1293_12201;}
	{long i; for (i = 13; i < 15; i++) R9650[i] = (char *(*)()) F1293_12201;}
	{long i; for (i = 16; i < 18; i++) R9650[i] = (char *(*)()) F1293_12201;}
}

char *(*R9651[18])();
void R9651_init () {
	{long i; for (i = 0; i < 2; i++) R9651[i] = (char *(*)()) F1232_11511;}
	{long i; for (i = 10; i < 12; i++) R9651[i] = (char *(*)()) F1301_12309;}
	{long i; for (i = 13; i < 15; i++) R9651[i] = (char *(*)()) F1301_12309;}
	{long i; for (i = 16; i < 18; i++) R9651[i] = (char *(*)()) F1301_12309;}
}

char *(*R9669[18])();
void R9669_init () {
	{long i; for (i = 0; i < 2; i++) R9669[i] = (char *(*)()) F1280_12061;}
	{long i; for (i = 10; i < 12; i++) R9669[i] = (char *(*)()) F1280_12061;}
	R9669[13] = (char *(*)()) F1303_12345;
	R9669[14] = (char *(*)()) F1305_12445;
	{long i; for (i = 16; i < 18; i++) R9669[i] = (char *(*)()) F1305_12445;}
}

char *(*R9679[18])();
void R9679_init () {
	{long i; for (i = 0; i < 2; i++) R9679[i] = (char *(*)()) F1280_12082;}
	{long i; for (i = 10; i < 12; i++) R9679[i] = (char *(*)()) F1280_12082;}
	R9679[13] = (char *(*)()) F1304_12377;
	R9679[14] = (char *(*)()) F1280_12082;
	{long i; for (i = 16; i < 18; i++) R9679[i] = (char *(*)()) F1280_12082;}
}


#ifdef __cplusplus
}
#endif
