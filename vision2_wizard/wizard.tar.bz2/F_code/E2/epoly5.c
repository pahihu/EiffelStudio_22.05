#include "epoly5.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R11[1421])();
void R11_init () {
	{long i; for (i = 0; i < 2; i++) R11[i] = (char *(*)()) F1_8;}
	R11[3] = (char *(*)()) F1_8;
	{long i; for (i = 5; i < 17; i++) R11[i] = (char *(*)()) F1_8;}
	R11[18] = (char *(*)()) F1_8;
	{long i; for (i = 20; i < 37; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 38; i < 41; i++) R11[i] = (char *(*)()) F1_8;}
	R11[42] = (char *(*)()) F1_8;
	{long i; for (i = 45; i < 48; i++) R11[i] = (char *(*)()) F1_8;}
	R11[60] = (char *(*)()) F1_8;
	R11[77] = (char *(*)()) F1_8;
	R11[90] = (char *(*)()) F1_8;
	R11[104] = (char *(*)()) F1_8;
	R11[107] = (char *(*)()) F1_8;
	{long i; for (i = 110; i < 116; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 121; i < 125; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 132; i < 135; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 141; i < 143; i++) R11[i] = (char *(*)()) F1_8;}
	R11[145] = (char *(*)()) F1_8;
	R11[151] = (char *(*)()) F1_8;
	R11[153] = (char *(*)()) F1_8;
	R11[155] = (char *(*)()) F1_8;
	{long i; for (i = 157; i < 160; i++) R11[i] = (char *(*)()) F1_8;}
	R11[170] = (char *(*)()) F1_8;
	R11[175] = (char *(*)()) F1_8;
	R11[180] = (char *(*)()) F1_8;
	{long i; for (i = 182; i < 184; i++) R11[i] = (char *(*)()) F1_8;}
	R11[189] = (char *(*)()) F1_8;
	{long i; for (i = 191; i < 193; i++) R11[i] = (char *(*)()) F1_8;}
	R11[195] = (char *(*)()) F1_8;
	{long i; for (i = 200; i < 202; i++) R11[i] = (char *(*)()) F1_8;}
	R11[203] = (char *(*)()) F1_8;
	R11[205] = (char *(*)()) F1_8;
	{long i; for (i = 207; i < 218; i++) R11[i] = (char *(*)()) F1_8;}
	R11[220] = (char *(*)()) F1_8;
	{long i; for (i = 222; i < 226; i++) R11[i] = (char *(*)()) F1_8;}
	R11[228] = (char *(*)()) F1_8;
	{long i; for (i = 230; i < 233; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 234; i < 237; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 238; i < 240; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 242; i < 244; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 245; i < 248; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 249; i < 253; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 254; i < 256; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 257; i < 264; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 266; i < 272; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 273; i < 280; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 289; i < 291; i++) R11[i] = (char *(*)()) F291_4525;}
	R11[294] = (char *(*)()) F1_8;
	R11[296] = (char *(*)()) F1_8;
	R11[299] = (char *(*)()) F1_8;
	{long i; for (i = 317; i < 319; i++) R11[i] = (char *(*)()) F1_8;}
	R11[321] = (char *(*)()) F1_8;
	R11[335] = (char *(*)()) F1_8;
	R11[339] = (char *(*)()) F1_8;
	{long i; for (i = 341; i < 343; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 344; i < 346; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 347; i < 350; i++) R11[i] = (char *(*)()) F1_8;}
	R11[370] = (char *(*)()) F371_5055;
	R11[598] = (char *(*)()) F601_5398;
	R11[599] = (char *(*)()) F602_5398;
	R11[600] = (char *(*)()) F603_5398;
	R11[601] = (char *(*)()) F604_5398;
	R11[602] = (char *(*)()) F605_5398;
	R11[603] = (char *(*)()) F606_5398;
	R11[604] = (char *(*)()) F607_5398;
	R11[605] = (char *(*)()) F608_5398;
	R11[606] = (char *(*)()) F609_5398;
	R11[607] = (char *(*)()) F610_5398;
	R11[608] = (char *(*)()) F611_5398;
	R11[609] = (char *(*)()) F612_5398;
	R11[659] = (char *(*)()) F638_5501;
	R11[660] = (char *(*)()) F642_5501;
	R11[661] = (char *(*)()) F646_5501;
	{long i; for (i = 662; i < 664; i++) R11[i] = (char *(*)()) F638_5501;}
	R11[664] = (char *(*)()) F642_5501;
	R11[665] = (char *(*)()) F646_5501;
	R11[666] = (char *(*)()) F638_5501;
	R11[668] = (char *(*)()) F671_5634;
	R11[669] = (char *(*)()) F672_5683;
	{long i; for (i = 671; i < 674; i++) R11[i] = (char *(*)()) F1_8;}
	R11[677] = (char *(*)()) F680_5817;
	R11[678] = (char *(*)()) F681_5817;
	R11[679] = (char *(*)()) F682_5817;
	R11[680] = (char *(*)()) F683_5817;
	R11[681] = (char *(*)()) F684_5817;
	R11[682] = (char *(*)()) F685_5817;
	R11[683] = (char *(*)()) F686_5911;
	R11[684] = (char *(*)()) F687_5911;
	R11[685] = (char *(*)()) F680_5817;
	R11[686] = (char *(*)()) F689_5949;
	R11[687] = (char *(*)()) F690_5949;
	R11[688] = (char *(*)()) F691_5949;
	R11[689] = (char *(*)()) F692_5949;
	R11[690] = (char *(*)()) F693_5949;
	R11[691] = (char *(*)()) F694_5949;
	R11[692] = (char *(*)()) F695_5949;
	R11[693] = (char *(*)()) F696_5949;
	R11[694] = (char *(*)()) F697_5949;
	R11[695] = (char *(*)()) F698_5949;
	R11[696] = (char *(*)()) F699_5949;
	R11[697] = (char *(*)()) F700_5949;
	R11[705] = (char *(*)()) F689_5949;
	R11[706] = (char *(*)()) F693_5949;
	{long i; for (i = 707; i < 711; i++) R11[i] = (char *(*)()) F689_5949;}
	R11[715] = (char *(*)()) F689_5949;
	{long i; for (i = 718; i < 720; i++) R11[i] = (char *(*)()) F689_5949;}
	R11[723] = (char *(*)()) F689_5949;
	{long i; for (i = 725; i < 729; i++) R11[i] = (char *(*)()) F689_5949;}
	R11[743] = (char *(*)()) F1_8;
	R11[747] = (char *(*)()) F1_8;
	{long i; for (i = 778; i < 800; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 812; i < 824; i++) R11[i] = (char *(*)()) F1_8;}
	R11[825] = (char *(*)()) F1_8;
	{long i; for (i = 851; i < 854; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 856; i < 868; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 916; i < 918; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 919; i < 923; i++) R11[i] = (char *(*)()) F1_8;}
	R11[923] = (char *(*)()) F926_6746;
	{long i; for (i = 927; i < 929; i++) R11[i] = (char *(*)()) F1_8;}
	R11[929] = (char *(*)()) F932_7315;
	R11[931] = (char *(*)()) F1_8;
	R11[934] = (char *(*)()) F1_8;
	R11[936] = (char *(*)()) F1_8;
	R11[937] = (char *(*)()) F940_7477;
	R11[938] = (char *(*)()) F941_7514;
	R11[939] = (char *(*)()) F942_7514;
	R11[940] = (char *(*)()) F943_7514;
	R11[941] = (char *(*)()) F944_7514;
	R11[942] = (char *(*)()) F945_7514;
	R11[943] = (char *(*)()) F946_7514;
	R11[944] = (char *(*)()) F947_7514;
	R11[945] = (char *(*)()) F948_7514;
	R11[946] = (char *(*)()) F949_7514;
	R11[947] = (char *(*)()) F950_7514;
	R11[948] = (char *(*)()) F951_7514;
	R11[949] = (char *(*)()) F952_7514;
	R11[950] = (char *(*)()) F953_7514;
	R11[951] = (char *(*)()) F954_7514;
	R11[952] = (char *(*)()) F955_7514;
	R11[953] = (char *(*)()) F956_7514;
	R11[954] = (char *(*)()) F957_7514;
	R11[955] = (char *(*)()) F958_7514;
	R11[956] = (char *(*)()) F959_7514;
	R11[957] = (char *(*)()) F960_7514;
	R11[958] = (char *(*)()) F961_7514;
	R11[959] = (char *(*)()) F962_7514;
	R11[960] = (char *(*)()) F963_7514;
	R11[961] = (char *(*)()) F964_7514;
	R11[962] = (char *(*)()) F965_7514;
	R11[963] = (char *(*)()) F966_7514;
	R11[964] = (char *(*)()) F967_7514;
	R11[965] = (char *(*)()) F968_7514;
	R11[966] = (char *(*)()) F969_7514;
	R11[967] = (char *(*)()) F970_7514;
	R11[968] = (char *(*)()) F971_7514;
	R11[969] = (char *(*)()) F972_7514;
	R11[970] = (char *(*)()) F973_7514;
	R11[971] = (char *(*)()) F974_7557;
	{long i; for (i = 973; i < 975; i++) R11[i] = (char *(*)()) F975_7675;}
	{long i; for (i = 976; i < 978; i++) R11[i] = (char *(*)()) F978_7769;}
	{long i; for (i = 979; i < 981; i++) R11[i] = (char *(*)()) F981_7863;}
	{long i; for (i = 982; i < 984; i++) R11[i] = (char *(*)()) F984_7958;}
	{long i; for (i = 985; i < 987; i++) R11[i] = (char *(*)()) F987_8057;}
	{long i; for (i = 988; i < 990; i++) R11[i] = (char *(*)()) F990_8123;}
	{long i; for (i = 991; i < 993; i++) R11[i] = (char *(*)()) F993_8184;}
	{long i; for (i = 994; i < 996; i++) R11[i] = (char *(*)()) F996_8224;}
	{long i; for (i = 997; i < 999; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1000; i < 1002; i++) R11[i] = (char *(*)()) F1002_8296;}
	{long i; for (i = 1003; i < 1005; i++) R11[i] = (char *(*)()) F1005_8394;}
	{long i; for (i = 1006; i < 1008; i++) R11[i] = (char *(*)()) F1008_8493;}
	{long i; for (i = 1009; i < 1011; i++) R11[i] = (char *(*)()) F1011_8592;}
	{long i; for (i = 1011; i < 1044; i++) R11[i] = (char *(*)()) F1014_8685;}
	R11[1045] = (char *(*)()) F1047_8722;
	R11[1046] = (char *(*)()) F1049_8760;
	R11[1047] = (char *(*)()) F1050_8760;
	R11[1048] = (char *(*)()) F1051_8760;
	R11[1049] = (char *(*)()) F1052_8760;
	R11[1050] = (char *(*)()) F1050_8760;
	{long i; for (i = 1055; i < 1057; i++) R11[i] = (char *(*)()) F1057_8922;}
	{long i; for (i = 1059; i < 1061; i++) R11[i] = (char *(*)()) F1061_9087;}
	R11[1089] = (char *(*)()) F1_8;
	R11[1092] = (char *(*)()) F1_8;
	R11[1093] = (char *(*)()) F1096_9452;
	R11[1095] = (char *(*)()) F1098_9483;
	R11[1096] = (char *(*)()) F1_8;
	R11[1098] = (char *(*)()) F1101_9543;
	R11[1099] = (char *(*)()) F1_8;
	R11[1100] = (char *(*)()) F1103_9585;
	R11[1107] = (char *(*)()) F1_8;
	R11[1123] = (char *(*)()) F1_8;
	R11[1126] = (char *(*)()) F1_8;
	{long i; for (i = 1139; i < 1141; i++) R11[i] = (char *(*)()) F638_5501;}
	{long i; for (i = 1141; i < 1143; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1144; i < 1146; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1148; i < 1151; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1152; i < 1154; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1155; i < 1157; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1157] = (char *(*)()) F1160_10304;
	R11[1162] = (char *(*)()) F1_8;
	{long i; for (i = 1164; i < 1166; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1167; i < 1170; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1172] = (char *(*)()) F1_8;
	R11[1177] = (char *(*)()) F1_8;
	R11[1180] = (char *(*)()) F1_8;
	R11[1186] = (char *(*)()) F638_5501;
	R11[1196] = (char *(*)()) F638_5501;
	R11[1204] = (char *(*)()) F1_8;
	R11[1208] = (char *(*)()) F1_8;
	R11[1211] = (char *(*)()) F1_8;
	R11[1215] = (char *(*)()) F1_8;
	R11[1217] = (char *(*)()) F1_8;
	R11[1219] = (char *(*)()) F1_8;
	R11[1221] = (char *(*)()) F1_8;
	R11[1223] = (char *(*)()) F1_8;
	R11[1227] = (char *(*)()) F1_8;
	R11[1269] = (char *(*)()) F1_8;
	{long i; for (i = 1288; i < 1290; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1298; i < 1300; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1301; i < 1303; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1304; i < 1306; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1330] = (char *(*)()) F1_8;
	R11[1333] = (char *(*)()) F1_8;
	{long i; for (i = 1340; i < 1342; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1343] = (char *(*)()) F1_8;
	R11[1345] = (char *(*)()) F1_8;
	{long i; for (i = 1347; i < 1349; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1351] = (char *(*)()) F1_8;
	R11[1361] = (char *(*)()) F1_8;
	R11[1367] = (char *(*)()) F1_8;
	R11[1371] = (char *(*)()) F1_8;
	{long i; for (i = 1384; i < 1386; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1387] = (char *(*)()) F1_8;
	R11[1392] = (char *(*)()) F1_8;
	R11[1393] = (char *(*)()) F1396_13897;
	{long i; for (i = 1394; i < 1396; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1396] = (char *(*)()) F1399_13980;
	R11[1400] = (char *(*)()) F1_8;
	{long i; for (i = 1402; i < 1405; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1408; i < 1410; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1412] = (char *(*)()) F291_4525;
	R11[1414] = (char *(*)()) F291_4525;
	R11[1417] = (char *(*)()) F1420_14487;
	{long i; for (i = 1419; i < 1421; i++) R11[i] = (char *(*)()) F1_8;}
}

char *(*R28[1421])();
void R28_init () {
	{long i; for (i = 0; i < 2; i++) R28[i] = (char *(*)()) F1_25;}
	R28[3] = (char *(*)()) F1_25;
	{long i; for (i = 5; i < 17; i++) R28[i] = (char *(*)()) F1_25;}
	R28[18] = (char *(*)()) F1_25;
	{long i; for (i = 20; i < 37; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 38; i < 41; i++) R28[i] = (char *(*)()) F1_25;}
	R28[42] = (char *(*)()) F1_25;
	{long i; for (i = 45; i < 48; i++) R28[i] = (char *(*)()) F1_25;}
	R28[60] = (char *(*)()) F1_25;
	R28[77] = (char *(*)()) F1_25;
	R28[90] = (char *(*)()) F1_25;
	R28[104] = (char *(*)()) F1_25;
	R28[107] = (char *(*)()) F1_25;
	{long i; for (i = 110; i < 116; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 121; i < 125; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 132; i < 135; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 141; i < 143; i++) R28[i] = (char *(*)()) F1_25;}
	R28[145] = (char *(*)()) F1_25;
	R28[151] = (char *(*)()) F1_25;
	R28[153] = (char *(*)()) F1_25;
	R28[155] = (char *(*)()) F1_25;
	{long i; for (i = 157; i < 160; i++) R28[i] = (char *(*)()) F1_25;}
	R28[170] = (char *(*)()) F1_25;
	R28[175] = (char *(*)()) F1_25;
	R28[180] = (char *(*)()) F1_25;
	{long i; for (i = 182; i < 184; i++) R28[i] = (char *(*)()) F1_25;}
	R28[189] = (char *(*)()) F1_25;
	{long i; for (i = 191; i < 193; i++) R28[i] = (char *(*)()) F1_25;}
	R28[195] = (char *(*)()) F1_25;
	{long i; for (i = 200; i < 202; i++) R28[i] = (char *(*)()) F1_25;}
	R28[203] = (char *(*)()) F1_25;
	R28[205] = (char *(*)()) F1_25;
	{long i; for (i = 207; i < 218; i++) R28[i] = (char *(*)()) F1_25;}
	R28[220] = (char *(*)()) F1_25;
	R28[222] = (char *(*)()) F1_25;
	{long i; for (i = 223; i < 226; i++) R28[i] = (char *(*)()) F226_3936;}
	R28[228] = (char *(*)()) F226_3936;
	{long i; for (i = 230; i < 233; i++) R28[i] = (char *(*)()) F226_3936;}
	{long i; for (i = 234; i < 237; i++) R28[i] = (char *(*)()) F226_3936;}
	{long i; for (i = 238; i < 240; i++) R28[i] = (char *(*)()) F226_3936;}
	{long i; for (i = 242; i < 244; i++) R28[i] = (char *(*)()) F226_3936;}
	{long i; for (i = 245; i < 248; i++) R28[i] = (char *(*)()) F226_3936;}
	{long i; for (i = 249; i < 253; i++) R28[i] = (char *(*)()) F226_3936;}
	{long i; for (i = 254; i < 256; i++) R28[i] = (char *(*)()) F226_3936;}
	{long i; for (i = 257; i < 263; i++) R28[i] = (char *(*)()) F226_3936;}
	R28[263] = (char *(*)()) F1_25;
	{long i; for (i = 266; i < 272; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 273; i < 280; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 289; i < 291; i++) R28[i] = (char *(*)()) F1_25;}
	R28[294] = (char *(*)()) F1_25;
	R28[296] = (char *(*)()) F1_25;
	R28[299] = (char *(*)()) F1_25;
	{long i; for (i = 317; i < 319; i++) R28[i] = (char *(*)()) F1_25;}
	R28[321] = (char *(*)()) F1_25;
	R28[335] = (char *(*)()) F1_25;
	R28[339] = (char *(*)()) F1_25;
	{long i; for (i = 341; i < 343; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 344; i < 346; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 347; i < 350; i++) R28[i] = (char *(*)()) F1_25;}
	R28[370] = (char *(*)()) F1_25;
	{long i; for (i = 598; i < 610; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 659; i < 667; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 668; i < 670; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 671; i < 674; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 677; i < 685; i++) R28[i] = (char *(*)()) F1_25;}
	R28[685] = (char *(*)()) F688_5920;
	{long i; for (i = 686; i < 698; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 705; i < 711; i++) R28[i] = (char *(*)()) F1_25;}
	R28[715] = (char *(*)()) F1_25;
	{long i; for (i = 718; i < 720; i++) R28[i] = (char *(*)()) F1_25;}
	R28[723] = (char *(*)()) F1_25;
	{long i; for (i = 725; i < 729; i++) R28[i] = (char *(*)()) F1_25;}
	R28[743] = (char *(*)()) F1_25;
	R28[747] = (char *(*)()) F1_25;
	{long i; for (i = 778; i < 800; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 812; i < 824; i++) R28[i] = (char *(*)()) F1_25;}
	R28[825] = (char *(*)()) F1_25;
	R28[851] = (char *(*)()) F1_25;
	R28[852] = (char *(*)()) F855_6414;
	R28[853] = (char *(*)()) F1_25;
	{long i; for (i = 856; i < 868; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 916; i < 918; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 919; i < 924; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 927; i < 930; i++) R28[i] = (char *(*)()) F1_25;}
	R28[931] = (char *(*)()) F1_25;
	R28[934] = (char *(*)()) F1_25;
	R28[936] = (char *(*)()) F939_7434;
	R28[937] = (char *(*)()) F940_7481;
	R28[938] = (char *(*)()) F941_7522;
	R28[939] = (char *(*)()) F942_7522;
	R28[940] = (char *(*)()) F943_7522;
	R28[941] = (char *(*)()) F944_7522;
	R28[942] = (char *(*)()) F945_7522;
	R28[943] = (char *(*)()) F946_7522;
	R28[944] = (char *(*)()) F947_7522;
	R28[945] = (char *(*)()) F948_7522;
	R28[946] = (char *(*)()) F949_7522;
	R28[947] = (char *(*)()) F950_7522;
	R28[948] = (char *(*)()) F951_7522;
	R28[949] = (char *(*)()) F952_7522;
	R28[950] = (char *(*)()) F953_7522;
	R28[951] = (char *(*)()) F954_7522;
	R28[952] = (char *(*)()) F955_7522;
	R28[953] = (char *(*)()) F956_7522;
	R28[954] = (char *(*)()) F957_7522;
	R28[955] = (char *(*)()) F958_7522;
	R28[956] = (char *(*)()) F959_7522;
	R28[957] = (char *(*)()) F960_7522;
	R28[958] = (char *(*)()) F961_7522;
	R28[959] = (char *(*)()) F962_7522;
	R28[960] = (char *(*)()) F963_7522;
	R28[961] = (char *(*)()) F964_7522;
	R28[962] = (char *(*)()) F965_7522;
	R28[963] = (char *(*)()) F966_7522;
	R28[964] = (char *(*)()) F967_7522;
	R28[965] = (char *(*)()) F968_7522;
	R28[966] = (char *(*)()) F969_7522;
	R28[967] = (char *(*)()) F970_7522;
	R28[968] = (char *(*)()) F971_7522;
	R28[969] = (char *(*)()) F972_7522;
	R28[970] = (char *(*)()) F973_7522;
	R28[971] = (char *(*)()) F1_25;
	{long i; for (i = 973; i < 975; i++) R28[i] = (char *(*)()) F975_7732;}
	{long i; for (i = 976; i < 978; i++) R28[i] = (char *(*)()) F978_7826;}
	{long i; for (i = 979; i < 981; i++) R28[i] = (char *(*)()) F981_7921;}
	{long i; for (i = 982; i < 984; i++) R28[i] = (char *(*)()) F984_8016;}
	R28[985] = (char *(*)()) F988_8109;
	R28[986] = (char *(*)()) F989_8109;
	R28[988] = (char *(*)()) F991_8175;
	R28[989] = (char *(*)()) F992_8175;
	{long i; for (i = 991; i < 993; i++) R28[i] = (char *(*)()) F993_8191;}
	{long i; for (i = 994; i < 996; i++) R28[i] = (char *(*)()) F996_8231;}
	{long i; for (i = 997; i < 999; i++) R28[i] = (char *(*)()) F999_8279;}
	{long i; for (i = 1000; i < 1002; i++) R28[i] = (char *(*)()) F1002_8355;}
	{long i; for (i = 1003; i < 1005; i++) R28[i] = (char *(*)()) F1005_8454;}
	{long i; for (i = 1006; i < 1008; i++) R28[i] = (char *(*)()) F1008_8553;}
	{long i; for (i = 1009; i < 1011; i++) R28[i] = (char *(*)()) F1011_8652;}
	{long i; for (i = 1011; i < 1042; i++) R28[i] = (char *(*)()) F1014_8700;}
	R28[1042] = (char *(*)()) F1045_8713;
	R28[1043] = (char *(*)()) F1046_8713;
	{long i; for (i = 1045; i < 1051; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1055; i < 1057; i++) R28[i] = (char *(*)()) F1057_8942;}
	{long i; for (i = 1059; i < 1061; i++) R28[i] = (char *(*)()) F1061_9107;}
	R28[1089] = (char *(*)()) F1_25;
	R28[1092] = (char *(*)()) F1_25;
	R28[1093] = (char *(*)()) F1096_9451;
	R28[1095] = (char *(*)()) F1098_9485;
	R28[1096] = (char *(*)()) F1_25;
	{long i; for (i = 1098; i < 1101; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1107] = (char *(*)()) F1_25;
	R28[1123] = (char *(*)()) F1_25;
	R28[1126] = (char *(*)()) F1_25;
	{long i; for (i = 1139; i < 1143; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1144; i < 1146; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1148; i < 1151; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1152; i < 1154; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1155; i < 1158; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1162] = (char *(*)()) F1_25;
	{long i; for (i = 1164; i < 1166; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1167; i < 1170; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1172] = (char *(*)()) F1_25;
	R28[1177] = (char *(*)()) F1_25;
	R28[1180] = (char *(*)()) F1_25;
	R28[1186] = (char *(*)()) F1_25;
	R28[1196] = (char *(*)()) F1_25;
	R28[1204] = (char *(*)()) F1_25;
	R28[1208] = (char *(*)()) F1_25;
	R28[1211] = (char *(*)()) F1_25;
	R28[1215] = (char *(*)()) F1_25;
	R28[1217] = (char *(*)()) F1_25;
	R28[1219] = (char *(*)()) F1_25;
	R28[1221] = (char *(*)()) F1_25;
	R28[1223] = (char *(*)()) F1_25;
	R28[1227] = (char *(*)()) F1_25;
	R28[1269] = (char *(*)()) F1_25;
	{long i; for (i = 1288; i < 1290; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1298; i < 1300; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1301; i < 1303; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1304; i < 1306; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1330] = (char *(*)()) F1_25;
	R28[1333] = (char *(*)()) F1_25;
	{long i; for (i = 1340; i < 1342; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1343] = (char *(*)()) F1_25;
	R28[1345] = (char *(*)()) F1_25;
	{long i; for (i = 1347; i < 1349; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1351] = (char *(*)()) F1_25;
	R28[1361] = (char *(*)()) F1_25;
	R28[1367] = (char *(*)()) F1_25;
	R28[1371] = (char *(*)()) F1_25;
	{long i; for (i = 1384; i < 1386; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1387] = (char *(*)()) F1_25;
	R28[1392] = (char *(*)()) F1395_13894;
	{long i; for (i = 1393; i < 1397; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1400] = (char *(*)()) F1_25;
	{long i; for (i = 1402; i < 1405; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1408; i < 1410; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1412] = (char *(*)()) F1415_14399;
	R28[1414] = (char *(*)()) F1417_14432;
	R28[1417] = (char *(*)()) F1420_14502;
	{long i; for (i = 1419; i < 1421; i++) R28[i] = (char *(*)()) F1_25;}
}

char *(*R2831[332])();
void R2831_init () {
	{long i; for (i = 0; i < 2; i++) R2831[i] = (char *(*)()) F131_2879;}
	{long i; for (i = 3; i < 5; i++) R2831[i] = (char *(*)()) F130_2874;}
	{long i; for (i = 6; i < 9; i++) R2831[i] = (char *(*)()) F131_2879;}
	R2831[331] = (char *(*)()) F131_2879;
}

char *(*R2834[332])();
void R2834_init () {
	{long i; for (i = 0; i < 2; i++) R2834[i] = (char *(*)()) F132_2885;}
	{long i; for (i = 3; i < 5; i++) R2834[i] = (char *(*)()) F130_2871;}
	{long i; for (i = 6; i < 9; i++) R2834[i] = (char *(*)()) F131_2877;}
	R2834[331] = (char *(*)()) F132_2885;
}

char *(*R2835[332])();
void R2835_init () {
	R2835[0] = (char *(*)()) F344_4994;
	R2835[1] = (char *(*)()) F345_4995;
	R2835[3] = (char *(*)()) F347_5002;
	R2835[4] = (char *(*)()) F348_5015;
	R2835[6] = (char *(*)()) F350_5024;
	R2835[7] = (char *(*)()) F351_5027;
	R2835[8] = (char *(*)()) F352_5031;
	R2835[331] = (char *(*)()) F675_5737;
}

char *(*R2836[332])();
void R2836_init () {
	{long i; for (i = 0; i < 2; i++) R2836[i] = (char *(*)()) F131_2882;}
	{long i; for (i = 3; i < 5; i++) R2836[i] = (char *(*)()) F129_2854;}
	{long i; for (i = 6; i < 9; i++) R2836[i] = (char *(*)()) F131_2882;}
	R2836[331] = (char *(*)()) F131_2882;
}

char *(*R2837[332])();
void R2837_init () {
	{long i; for (i = 0; i < 2; i++) R2837[i] = (char *(*)()) F133_2894;}
	R2837[3] = (char *(*)()) F347_5000;
	R2837[4] = (char *(*)()) F348_5010;
	R2837[6] = (char *(*)()) F350_5025;
	R2837[7] = (char *(*)()) F351_5028;
	R2837[8] = (char *(*)()) F352_5030;
	R2837[331] = (char *(*)()) F340_4959;
}

char *(*R2838[332])();
void R2838_init () {
	{long i; for (i = 0; i < 2; i++) R2838[i] = (char *(*)()) F129_2856;}
	R2838[3] = (char *(*)()) F347_5001;
	R2838[4] = (char *(*)()) F348_5011;
	{long i; for (i = 6; i < 9; i++) R2838[i] = (char *(*)()) F129_2856;}
	R2838[331] = (char *(*)()) F129_2856;
}

char *(*R2839[332])();
void R2839_init () {
	{long i; for (i = 0; i < 2; i++) R2839[i] = (char *(*)()) F343_4993;}
	{long i; for (i = 3; i < 5; i++) R2839[i] = (char *(*)()) F346_4997;}
	R2839[6] = (char *(*)()) F350_5026;
	R2839[7] = (char *(*)()) F351_5029;
	R2839[8] = (char *(*)()) F349_5021;
	R2839[331] = (char *(*)()) F340_4960;
}

char *(*R2840[332])();
void R2840_init () {
	{long i; for (i = 0; i < 2; i++) R2840[i] = (char *(*)()) F133_2893;}
	R2840[3] = (char *(*)()) F347_4998;
	R2840[4] = (char *(*)()) F348_5009;
	{long i; for (i = 6; i < 9; i++) R2840[i] = (char *(*)()) F131_2878;}
	R2840[331] = (char *(*)()) F131_2878;
}

char *(*R2848[332])();
void R2848_init () {
	{long i; for (i = 0; i < 2; i++) R2848[i] = (char *(*)()) F131_2883;}
	{long i; for (i = 3; i < 5; i++) R2848[i] = (char *(*)()) F130_2873;}
	{long i; for (i = 6; i < 9; i++) R2848[i] = (char *(*)()) F131_2883;}
	R2848[331] = (char *(*)()) F131_2883;
}

char *(*R3420[4])();
void R3420_init () {
	R3420[0] = (char *(*)()) F177_3484;
	R3420[3] = (char *(*)()) F179_3521;
}

char *(*R3421[4])();
void R3421_init () {
	R3421[0] = (char *(*)()) F177_3485;
	R3421[3] = (char *(*)()) F179_3522;
}

char *(*R3422[4])();
void R3422_init () {
	R3422[0] = (char *(*)()) F177_3486;
	R3422[3] = (char *(*)()) F179_3523;
}

char *(*R3464[6])();
void R3464_init () {
	R3464[0] = (char *(*)()) F679_5776;
	R3464[5] = (char *(*)()) F179_3520;
}

char *(*R3465[6])();
void R3465_init () {
	R3465[0] = (char *(*)()) F679_5777;
	R3465[5] = (char *(*)()) F179_3519;
}

char *(*R3466[6])();
void R3466_init () {
	R3466[0] = (char *(*)()) F679_5778;
	R3466[5] = (char *(*)()) F179_3518;
}

char *(*R3474[2])();
void R3474_init () {
	R3474[0] = (char *(*)()) F185_3540;
	R3474[1] = (char *(*)()) F186_3544;
}

char *(*R3528[2])();
void R3528_init () {
	R3528[0] = (char *(*)()) F194_3621;
	R3528[1] = (char *(*)()) F195_3632;
}

char *(*R3535[2])();
void R3535_init () {
	R3535[0] = (char *(*)()) F194_3625;
	R3535[1] = (char *(*)()) F195_3634;
}

char *(*R3658[3])();
void R3658_init () {
	R3658[0] = (char *(*)()) F206_3761;
	R3658[2] = (char *(*)()) F208_3811;
}

char *(*R3660[3])();
void R3660_init () {
	R3660[0] = (char *(*)()) F206_3762;
	R3660[2] = (char *(*)()) F208_3807;
}

char *(*R3666[3])();
void R3666_init () {
	R3666[0] = (char *(*)()) F206_3764;
	R3666[2] = (char *(*)()) F208_3816;
}

char *(*R3722[2])();
void R3722_init () {
	R3722[0] = (char *(*)()) F210_3844;
	R3722[1] = (char *(*)()) F211_3848;
}

char *(*R3724[2])();
void R3724_init () {
	R3724[0] = (char *(*)()) F210_3845;
	R3724[1] = (char *(*)()) F211_3849;
}

char *(*R3731[162])();
void R3731_init () {
	R3731[0] = (char *(*)()) F212_3851;
	R3731[1] = (char *(*)()) F213_3851_3731_1;
	R3731[2] = (char *(*)()) F214_3851_3731_1;
	R3731[3] = (char *(*)()) F215_3851_3731_1;
	R3731[4] = (char *(*)()) F216_3851_3731_1;
	R3731[5] = (char *(*)()) F212_3851;
	R3731[6] = (char *(*)()) F213_3851_3731_1;
	R3731[7] = (char *(*)()) F214_3851_3731_1;
	R3731[8] = (char *(*)()) F212_3851;
	R3731[161] = (char *(*)()) F212_3851;
}
static EIF_REFERENCE F213_3851_3731_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F213_3851(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F214_3851_3731_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F214_3851(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F215_3851_3731_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F215_3851(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F216_3851_3731_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F216_3851(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(976, 0x00).id, 976, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

char *(*R3732[162])();
void R3732_init () {
	R3732[0] = (char *(*)()) F212_3852;
	R3732[1] = (char *(*)()) F213_3852_3732_4;
	R3732[2] = (char *(*)()) F214_3852_3732_4;
	R3732[3] = (char *(*)()) F215_3852_3732_4;
	R3732[4] = (char *(*)()) F216_3852_3732_4;
	R3732[5] = (char *(*)()) F212_3852;
	R3732[6] = (char *(*)()) F213_3852_3732_4;
	R3732[7] = (char *(*)()) F214_3852_3732_4;
	R3732[8] = (char *(*)()) F212_3852;
	R3732[161] = (char *(*)()) F212_3852;
}
static void F213_3852_3732_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F213_3852(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F214_3852_3732_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F214_3852(Current, *(EIF_BOOLEAN *)arg1);
}
static void F215_3852_3732_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F215_3852(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F216_3852_3732_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F216_3852(Current, *(EIF_NATURAL_64 *)arg1);
}

char *(*R3736[4])();
void R3736_init () {
	R3736[0] = (char *(*)()) F217_3855;
	R3736[1] = (char *(*)()) F218_3855;
	R3736[2] = (char *(*)()) F219_3855;
	R3736[3] = (char *(*)()) F220_3858;
}

char *(*R3737[4])();
void R3737_init () {
	R3737[0] = (char *(*)()) F217_3856;
	R3737[1] = (char *(*)()) F218_3856;
	R3737[2] = (char *(*)()) F219_3856;
	R3737[3] = (char *(*)()) F220_3860;
}

char *(*R3802[40])();
void R3802_init () {
	R3802[0] = (char *(*)()) F226_3923;
	{long i; for (i = 1; i < 3; i++) R3802[i] = (char *(*)()) F227_3947;}
	R3802[5] = (char *(*)()) F231_3950;
	R3802[7] = (char *(*)()) F233_3952;
	R3802[8] = (char *(*)()) F234_3956;
	R3802[9] = (char *(*)()) F235_3962;
	R3802[11] = (char *(*)()) F237_3979;
	R3802[12] = (char *(*)()) F238_3981;
	R3802[13] = (char *(*)()) F239_3983;
	R3802[15] = (char *(*)()) F241_3985;
	R3802[16] = (char *(*)()) F242_3989;
	R3802[19] = (char *(*)()) F245_3991;
	R3802[20] = (char *(*)()) F246_3993;
	R3802[22] = (char *(*)()) F248_3997;
	R3802[23] = (char *(*)()) F249_3999;
	R3802[24] = (char *(*)()) F250_4005;
	R3802[26] = (char *(*)()) F252_4007;
	R3802[27] = (char *(*)()) F253_4009;
	R3802[28] = (char *(*)()) F254_4013;
	R3802[29] = (char *(*)()) F255_4017;
	R3802[31] = (char *(*)()) F257_4019;
	R3802[32] = (char *(*)()) F258_4021;
	R3802[34] = (char *(*)()) F260_4023;
	R3802[35] = (char *(*)()) F261_4025;
	R3802[36] = (char *(*)()) F262_4027;
	R3802[37] = (char *(*)()) F263_4029;
	R3802[38] = (char *(*)()) F264_4033;
	R3802[39] = (char *(*)()) F265_4035;
}

char *(*R4202[4])();
void R4202_init () {
	R4202[0] = (char *(*)()) F279_4381;
	R4202[1] = (char *(*)()) F280_4381;
	R4202[2] = (char *(*)()) F281_4381;
	R4202[3] = (char *(*)()) F279_4381;
}

char *(*R4212[1129])();
void R4212_init () {
	R4212[0] = (char *(*)()) F292_4532;
	R4212[1] = (char *(*)()) F293_4543;
	R4212[647] = (char *(*)()) F939_7432;
	R4212[648] = (char *(*)()) F940_7476;
	R4212[684] = (char *(*)()) F976_7733_4212_2;
	R4212[685] = (char *(*)()) F977_7733_4212_2;
	R4212[687] = (char *(*)()) F979_7827_4212_2;
	R4212[688] = (char *(*)()) F980_7827_4212_2;
	R4212[690] = (char *(*)()) F982_7922_4212_2;
	R4212[691] = (char *(*)()) F983_7922_4212_2;
	R4212[693] = (char *(*)()) F985_8017_4212_2;
	R4212[694] = (char *(*)()) F986_8017_4212_2;
	R4212[696] = (char *(*)()) F988_8086_4212_2;
	R4212[697] = (char *(*)()) F989_8086_4212_2;
	R4212[699] = (char *(*)()) F991_8152_4212_2;
	R4212[700] = (char *(*)()) F992_8152_4212_2;
	{long i; for (i = 702; i < 704; i++) R4212[i] = (char *(*)()) F993_8183;}
	{long i; for (i = 705; i < 707; i++) R4212[i] = (char *(*)()) F996_8223;}
	R4212[711] = (char *(*)()) F1003_8357_4212_2;
	R4212[712] = (char *(*)()) F1004_8357_4212_2;
	R4212[714] = (char *(*)()) F1006_8456_4212_2;
	R4212[715] = (char *(*)()) F1007_8456_4212_2;
	R4212[717] = (char *(*)()) F1009_8555_4212_2;
	R4212[718] = (char *(*)()) F1010_8555_4212_2;
	R4212[720] = (char *(*)()) F1012_8654_4212_2;
	R4212[721] = (char *(*)()) F1013_8654_4212_2;
	{long i; for (i = 766; i < 768; i++) R4212[i] = (char *(*)()) F1057_8927;}
	{long i; for (i = 770; i < 772; i++) R4212[i] = (char *(*)()) F1061_9092;}
	R4212[1123] = (char *(*)()) F1415_14373;
	R4212[1125] = (char *(*)()) F1417_14415;
	R4212[1128] = (char *(*)()) F1420_14486;
}
static EIF_BOOLEAN F976_7733_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F976_7733(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F977_7733_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F977_7733(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F979_7827_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F979_7827(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F980_7827_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F980_7827(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F982_7922_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F982_7922(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F983_7922_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F983_7922(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F985_8017_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F985_8017(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F986_8017_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F986_8017(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F988_8086_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F988_8086(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F989_8086_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F989_8086(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F991_8152_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F991_8152(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F992_8152_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F992_8152(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1003_8357_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1003_8357(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1004_8357_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1004_8357(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1006_8456_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1006_8456(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1007_8456_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1007_8456(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1009_8555_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1009_8555(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1010_8555_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1010_8555(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1012_8654_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1012_8654(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1013_8654_4212_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1013_8654(Current, *(EIF_INTEGER_8 *)arg1);
}

char *(*R4326[626])();
void R4326_init () {
	R4326[0] = (char *(*)()) F297_4559;
	R4326[625] = (char *(*)()) F922_6645;
}

char *(*R4604[463])();
void R4604_init () {
	R4604[0] = (char *(*)()) F307_4843;
	R4604[1] = (char *(*)()) F308_4843;
	R4604[2] = (char *(*)()) F309_4843;
	R4604[3] = (char *(*)()) F310_4843;
	R4604[4] = (char *(*)()) F311_4843;
	R4604[5] = (char *(*)()) F312_4843;
	R4604[6] = (char *(*)()) F313_4843;
	R4604[7] = (char *(*)()) F314_4843;
	R4604[8] = (char *(*)()) F315_4843;
	R4604[9] = (char *(*)()) F316_4843;
	R4604[10] = (char *(*)()) F317_4843;
	R4604[11] = (char *(*)()) F318_4843;
	R4604[71] = (char *(*)()) F309_4843;
	R4604[88] = (char *(*)()) F307_4843;
	R4604[89] = (char *(*)()) F308_4843;
	R4604[90] = (char *(*)()) F309_4843;
	R4604[91] = (char *(*)()) F310_4843;
	R4604[92] = (char *(*)()) F311_4843;
	R4604[93] = (char *(*)()) F312_4843;
	R4604[94] = (char *(*)()) F313_4843;
	R4604[95] = (char *(*)()) F314_4843;
	R4604[96] = (char *(*)()) F315_4843;
	R4604[97] = (char *(*)()) F316_4843;
	R4604[98] = (char *(*)()) F317_4843;
	R4604[99] = (char *(*)()) F318_4843;
	R4604[107] = (char *(*)()) F307_4843;
	R4604[108] = (char *(*)()) F311_4843;
	{long i; for (i = 109; i < 113; i++) R4604[i] = (char *(*)()) F307_4843;}
	R4604[117] = (char *(*)()) F307_4843;
	{long i; for (i = 120; i < 122; i++) R4604[i] = (char *(*)()) F307_4843;}
	R4604[125] = (char *(*)()) F307_4843;
	{long i; for (i = 127; i < 131; i++) R4604[i] = (char *(*)()) F307_4843;}
	R4604[458] = (char *(*)()) F313_4843;
	R4604[462] = (char *(*)()) F312_4843;
}

char *(*R4605[463])();
void R4605_init () {
	R4605[0] = (char *(*)()) F307_4844;
	R4605[1] = (char *(*)()) F308_4844_4605_242;
	R4605[2] = (char *(*)()) F309_4844_4605_242;
	R4605[3] = (char *(*)()) F310_4844_4605_242;
	R4605[4] = (char *(*)()) F311_4844_4605_242;
	R4605[5] = (char *(*)()) F312_4844_4605_242;
	R4605[6] = (char *(*)()) F313_4844_4605_242;
	R4605[7] = (char *(*)()) F314_4844_4605_242;
	R4605[8] = (char *(*)()) F315_4844_4605_242;
	R4605[9] = (char *(*)()) F316_4844_4605_242;
	R4605[10] = (char *(*)()) F317_4844_4605_242;
	R4605[11] = (char *(*)()) F318_4844_4605_242;
	R4605[71] = (char *(*)()) F309_4844_4605_242;
	R4605[88] = (char *(*)()) F307_4844;
	R4605[89] = (char *(*)()) F308_4844_4605_242;
	R4605[90] = (char *(*)()) F309_4844_4605_242;
	R4605[91] = (char *(*)()) F310_4844_4605_242;
	R4605[92] = (char *(*)()) F311_4844_4605_242;
	R4605[93] = (char *(*)()) F312_4844_4605_242;
	R4605[94] = (char *(*)()) F313_4844_4605_242;
	R4605[95] = (char *(*)()) F314_4844_4605_242;
	R4605[96] = (char *(*)()) F315_4844_4605_242;
	R4605[97] = (char *(*)()) F316_4844_4605_242;
	R4605[98] = (char *(*)()) F317_4844_4605_242;
	R4605[99] = (char *(*)()) F318_4844_4605_242;
	R4605[107] = (char *(*)()) F307_4844;
	R4605[108] = (char *(*)()) F311_4844_4605_242;
	{long i; for (i = 109; i < 113; i++) R4605[i] = (char *(*)()) F307_4844;}
	R4605[117] = (char *(*)()) F307_4844;
	{long i; for (i = 120; i < 122; i++) R4605[i] = (char *(*)()) F307_4844;}
	R4605[125] = (char *(*)()) F307_4844;
	{long i; for (i = 127; i < 131; i++) R4605[i] = (char *(*)()) F307_4844;}
	R4605[458] = (char *(*)()) F313_4844_4605_242;
	R4605[462] = (char *(*)()) F312_4844_4605_242;
}
static void F308_4844_4605_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F308_4844(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F309_4844_4605_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F309_4844(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F310_4844_4605_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F310_4844(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F311_4844_4605_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F311_4844(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F312_4844_4605_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F312_4844(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F313_4844_4605_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F313_4844(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F314_4844_4605_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F314_4844(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F315_4844_4605_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F315_4844(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F316_4844_4605_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F316_4844(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F317_4844_4605_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F317_4844(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F318_4844_4605_242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F318_4844(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4611[463])();
void R4611_init () {
	R4611[0] = (char *(*)()) F307_4850;
	R4611[1] = (char *(*)()) F308_4850;
	R4611[2] = (char *(*)()) F309_4850;
	R4611[3] = (char *(*)()) F310_4850;
	R4611[4] = (char *(*)()) F311_4850;
	R4611[5] = (char *(*)()) F312_4850;
	R4611[6] = (char *(*)()) F313_4850;
	R4611[7] = (char *(*)()) F314_4850;
	R4611[8] = (char *(*)()) F315_4850;
	R4611[9] = (char *(*)()) F316_4850;
	R4611[10] = (char *(*)()) F317_4850;
	R4611[11] = (char *(*)()) F318_4850;
	R4611[71] = (char *(*)()) F309_4850;
	R4611[88] = (char *(*)()) F307_4850;
	R4611[89] = (char *(*)()) F308_4850;
	R4611[90] = (char *(*)()) F309_4850;
	R4611[91] = (char *(*)()) F310_4850;
	R4611[92] = (char *(*)()) F311_4850;
	R4611[93] = (char *(*)()) F312_4850;
	R4611[94] = (char *(*)()) F313_4850;
	R4611[95] = (char *(*)()) F314_4850;
	R4611[96] = (char *(*)()) F315_4850;
	R4611[97] = (char *(*)()) F316_4850;
	R4611[98] = (char *(*)()) F317_4850;
	R4611[99] = (char *(*)()) F318_4850;
	R4611[107] = (char *(*)()) F307_4850;
	R4611[108] = (char *(*)()) F311_4850;
	{long i; for (i = 109; i < 113; i++) R4611[i] = (char *(*)()) F307_4850;}
	R4611[117] = (char *(*)()) F307_4850;
	{long i; for (i = 120; i < 122; i++) R4611[i] = (char *(*)()) F307_4850;}
	R4611[125] = (char *(*)()) F307_4850;
	{long i; for (i = 127; i < 131; i++) R4611[i] = (char *(*)()) F307_4850;}
	R4611[458] = (char *(*)()) F313_4850;
	R4611[462] = (char *(*)()) F312_4850;
}

static EIF_TYPE_INDEX Y4612_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype24[] = {985,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype25[] = {985,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype26[] = {985,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype48[] = {1097,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype49[] = {1047,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype50[] = {1047,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype51[] = {1047,0xFFF9,1,973,0,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype52[] = {1047,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype53[] = {1047,0xFFF9,1,973,1006,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype54[] = {1047,0xFFF9,1,973,1177,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype55[] = {1047,0xFFF9,1,973,1006,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype56[] = {1047,0xFFF9,1,973,1182,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype57[] = {1047,0xFFF9,1,973,1135,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype58[] = {1047,0xFFF9,1,973,935,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype59[] = {1047,0xFFF9,1,973,1110,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype60[] = {1047,0xFFF9,1,973,1394,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype61[] = {1047,0xFFF9,1,973,1006,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype62[] = {1047,0xFFF9,5,973,979,1006,1006,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype63[] = {1047,0xFFF9,1,973,1062,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype64[] = {1047,0xFFF9,7,973,1006,1006,991,991,991,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype65[] = {1047,0xFFF9,2,973,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype66[] = {1047,0xFFF9,3,973,1006,1006,935,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype67[] = {1047,0xFFF9,8,973,1006,1006,1006,991,991,991,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype68[] = {1047,0xFFF9,0,973,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype69[] = {1047,0xFFF9,4,973,1006,1006,1006,1006,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype70[] = {997,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype71[] = {997,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype72[] = {994,0xFFFF};
static EIF_TYPE_INDEX Y4612_pgtype73[] = {1062,0xFFFF};
EIF_TYPE_INDEX *Y4612_gen_type [872];
EIF_TYPE_INDEX Y4612 [872];
void Y4612_init (void)
{
	egc_routines_types [4612] = Y4612;
	egc_routines_gen_types [4612] = Y4612_gen_type;
	egc_routines_offset [4612] = 306;
	Y4612_gen_type [0] = Y4612_pgtype0;
	Y4612_gen_type [1] = Y4612_pgtype1;
	Y4612_gen_type [2] = Y4612_pgtype2;
	Y4612_gen_type [3] = Y4612_pgtype3;
	Y4612_gen_type [4] = Y4612_pgtype4;
	Y4612_gen_type [5] = Y4612_pgtype5;
	Y4612_gen_type [6] = Y4612_pgtype6;
	Y4612_gen_type [7] = Y4612_pgtype7;
	Y4612_gen_type [8] = Y4612_pgtype8;
	Y4612_gen_type [9] = Y4612_pgtype9;
	Y4612_gen_type [10] = Y4612_pgtype10;
	Y4612_gen_type [11] = Y4612_pgtype11;
	Y4612_gen_type [294] = Y4612_pgtype12;
	Y4612_gen_type [295] = Y4612_pgtype13;
	Y4612_gen_type [296] = Y4612_pgtype14;
	Y4612_gen_type [297] = Y4612_pgtype15;
	Y4612_gen_type [298] = Y4612_pgtype16;
	Y4612_gen_type [299] = Y4612_pgtype17;
	Y4612_gen_type [300] = Y4612_pgtype18;
	Y4612_gen_type [301] = Y4612_pgtype19;
	Y4612_gen_type [302] = Y4612_pgtype20;
	Y4612_gen_type [303] = Y4612_pgtype21;
	Y4612_gen_type [304] = Y4612_pgtype22;
	Y4612_gen_type [305] = Y4612_pgtype23;
	Y4612_gen_type [306] = Y4612_pgtype24;
	Y4612_gen_type [365] = Y4612_pgtype25;
	Y4612_gen_type [366] = Y4612_pgtype26;
	Y4612_gen_type [382] = Y4612_pgtype27;
	Y4612_gen_type [383] = Y4612_pgtype28;
	Y4612_gen_type [384] = Y4612_pgtype29;
	Y4612_gen_type [385] = Y4612_pgtype30;
	Y4612_gen_type [386] = Y4612_pgtype31;
	Y4612_gen_type [387] = Y4612_pgtype32;
	Y4612_gen_type [388] = Y4612_pgtype33;
	Y4612_gen_type [389] = Y4612_pgtype34;
	Y4612_gen_type [390] = Y4612_pgtype35;
	Y4612_gen_type [391] = Y4612_pgtype36;
	Y4612_gen_type [392] = Y4612_pgtype37;
	Y4612_gen_type [393] = Y4612_pgtype38;
	Y4612_gen_type [394] = Y4612_pgtype39;
	Y4612_gen_type [395] = Y4612_pgtype40;
	Y4612_gen_type [396] = Y4612_pgtype41;
	Y4612_gen_type [397] = Y4612_pgtype42;
	Y4612_gen_type [398] = Y4612_pgtype43;
	Y4612_gen_type [399] = Y4612_pgtype44;
	Y4612_gen_type [400] = Y4612_pgtype45;
	Y4612_gen_type [401] = Y4612_pgtype46;
	Y4612_gen_type [402] = Y4612_pgtype47;
	Y4612_gen_type [403] = Y4612_pgtype48;
	Y4612_gen_type [404] = Y4612_pgtype49;
	Y4612_gen_type [405] = Y4612_pgtype50;
	Y4612_gen_type [406] = Y4612_pgtype51;
	Y4612_gen_type [407] = Y4612_pgtype52;
	Y4612_gen_type [408] = Y4612_pgtype53;
	Y4612_gen_type [409] = Y4612_pgtype54;
	Y4612_gen_type [410] = Y4612_pgtype55;
	Y4612_gen_type [411] = Y4612_pgtype56;
	Y4612_gen_type [412] = Y4612_pgtype57;
	Y4612_gen_type [413] = Y4612_pgtype58;
	Y4612_gen_type [414] = Y4612_pgtype59;
	Y4612_gen_type [415] = Y4612_pgtype60;
	Y4612_gen_type [416] = Y4612_pgtype61;
	Y4612_gen_type [417] = Y4612_pgtype62;
	Y4612_gen_type [418] = Y4612_pgtype63;
	Y4612_gen_type [419] = Y4612_pgtype64;
	Y4612_gen_type [420] = Y4612_pgtype65;
	Y4612_gen_type [421] = Y4612_pgtype66;
	Y4612_gen_type [422] = Y4612_pgtype67;
	Y4612_gen_type [423] = Y4612_pgtype68;
	Y4612_gen_type [424] = Y4612_pgtype69;
	Y4612_gen_type [752] = Y4612_pgtype70;
	Y4612_gen_type [753] = Y4612_pgtype71;
	Y4612_gen_type [756] = Y4612_pgtype72;
	Y4612_gen_type [871] = Y4612_pgtype73;
	Y4612[306] = 985;
	{long i; for (i = 365; i < 367; i++) Y4612[i] = 985;};
	Y4612[403] = 1097;
	{long i; for (i = 404; i < 425; i++) Y4612[i] = 1047;};
	{long i; for (i = 752; i < 754; i++) Y4612[i] = 997;};
	Y4612[756] = 994;
	Y4612[871] = 1062;
}


#ifdef __cplusplus
}
#endif
