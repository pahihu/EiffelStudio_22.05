#include "epoly7.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4885[736])();
void R4885_init () {
	R4885[0] = (char *(*)()) F386_5197;
	R4885[1] = (char *(*)()) F389_5197;
	R4885[2] = (char *(*)()) F394_5197;
	{long i; for (i = 3; i < 5; i++) R4885[i] = (char *(*)()) F386_5197;}
	R4885[5] = (char *(*)()) F389_5197;
	R4885[6] = (char *(*)()) F394_5197;
	R4885[7] = (char *(*)()) F386_5197;
	R4885[27] = (char *(*)()) F386_5197;
	R4885[28] = (char *(*)()) F387_5197;
	R4885[29] = (char *(*)()) F388_5197;
	R4885[30] = (char *(*)()) F391_5197;
	R4885[31] = (char *(*)()) F389_5197;
	R4885[32] = (char *(*)()) F392_5197;
	R4885[33] = (char *(*)()) F390_5197;
	R4885[34] = (char *(*)()) F393_5197;
	R4885[35] = (char *(*)()) F394_5197;
	R4885[36] = (char *(*)()) F395_5197;
	R4885[37] = (char *(*)()) F396_5197;
	R4885[38] = (char *(*)()) F397_5197;
	R4885[46] = (char *(*)()) F386_5197;
	R4885[47] = (char *(*)()) F389_5197;
	{long i; for (i = 48; i < 52; i++) R4885[i] = (char *(*)()) F386_5197;}
	R4885[56] = (char *(*)()) F386_5197;
	{long i; for (i = 59; i < 61; i++) R4885[i] = (char *(*)()) F386_5197;}
	R4885[64] = (char *(*)()) F386_5197;
	{long i; for (i = 66; i < 70; i++) R4885[i] = (char *(*)()) F386_5197;}
	R4885[84] = (char *(*)()) F389_5197;
	R4885[88] = (char *(*)()) F389_5197;
	{long i; for (i = 268; i < 270; i++) R4885[i] = (char *(*)()) F390_5197;}
	{long i; for (i = 480; i < 482; i++) R4885[i] = (char *(*)()) F386_5197;}
	R4885[527] = (char *(*)()) F386_5197;
	R4885[537] = (char *(*)()) F386_5197;
	R4885[735] = (char *(*)()) F390_5197;
}

char *(*R4886[736])();
void R4886_init () {
	R4886[0] = (char *(*)()) F662_5524;
	R4886[1] = (char *(*)()) F663_5524;
	R4886[2] = (char *(*)()) F664_5524;
	{long i; for (i = 3; i < 5; i++) R4886[i] = (char *(*)()) F662_5524;}
	R4886[5] = (char *(*)()) F663_5524;
	R4886[6] = (char *(*)()) F664_5524;
	R4886[7] = (char *(*)()) F662_5524;
	R4886[27] = (char *(*)()) F638_5502;
	R4886[28] = (char *(*)()) F639_5502;
	R4886[29] = (char *(*)()) F640_5502;
	R4886[30] = (char *(*)()) F641_5502;
	R4886[31] = (char *(*)()) F642_5502;
	R4886[32] = (char *(*)()) F643_5502;
	R4886[33] = (char *(*)()) F644_5502;
	R4886[34] = (char *(*)()) F645_5502;
	R4886[35] = (char *(*)()) F646_5502;
	R4886[36] = (char *(*)()) F647_5502;
	R4886[37] = (char *(*)()) F648_5502;
	R4886[38] = (char *(*)()) F649_5502;
	R4886[46] = (char *(*)()) F638_5502;
	R4886[47] = (char *(*)()) F642_5502;
	{long i; for (i = 48; i < 52; i++) R4886[i] = (char *(*)()) F638_5502;}
	R4886[56] = (char *(*)()) F638_5502;
	{long i; for (i = 59; i < 61; i++) R4886[i] = (char *(*)()) F638_5502;}
	R4886[64] = (char *(*)()) F638_5502;
	{long i; for (i = 66; i < 70; i++) R4886[i] = (char *(*)()) F638_5502;}
	R4886[84] = (char *(*)()) F505_5250;
	R4886[88] = (char *(*)()) F505_5250;
	{long i; for (i = 268; i < 270; i++) R4886[i] = (char *(*)()) F929_6997;}
	{long i; for (i = 480; i < 482; i++) R4886[i] = (char *(*)()) F638_5502;}
	R4886[527] = (char *(*)()) F638_5502;
	R4886[537] = (char *(*)()) F638_5502;
	R4886[735] = (char *(*)()) F929_6997;
}

char *(*R4887[538])();
void R4887_init () {
	R4887[0] = (char *(*)()) F662_5533;
	R4887[1] = (char *(*)()) F663_5533;
	R4887[2] = (char *(*)()) F664_5533;
	{long i; for (i = 3; i < 5; i++) R4887[i] = (char *(*)()) F662_5533;}
	R4887[5] = (char *(*)()) F663_5533;
	R4887[6] = (char *(*)()) F664_5533;
	R4887[7] = (char *(*)()) F669_5600;
	R4887[27] = (char *(*)()) F689_5957;
	R4887[28] = (char *(*)()) F690_5957;
	R4887[29] = (char *(*)()) F691_5957;
	R4887[30] = (char *(*)()) F692_5957;
	R4887[31] = (char *(*)()) F693_5957;
	R4887[32] = (char *(*)()) F694_5957;
	R4887[33] = (char *(*)()) F695_5957;
	R4887[34] = (char *(*)()) F696_5957;
	R4887[35] = (char *(*)()) F697_5957;
	R4887[36] = (char *(*)()) F698_5957;
	R4887[37] = (char *(*)()) F699_5957;
	R4887[38] = (char *(*)()) F700_5957;
	R4887[46] = (char *(*)()) F689_5957;
	R4887[47] = (char *(*)()) F693_5957;
	{long i; for (i = 48; i < 52; i++) R4887[i] = (char *(*)()) F689_5957;}
	R4887[56] = (char *(*)()) F689_5957;
	{long i; for (i = 59; i < 61; i++) R4887[i] = (char *(*)()) F689_5957;}
	R4887[64] = (char *(*)()) F689_5957;
	{long i; for (i = 66; i < 70; i++) R4887[i] = (char *(*)()) F689_5957;}
	{long i; for (i = 480; i < 482; i++) R4887[i] = (char *(*)()) F614_5472;}
	R4887[527] = (char *(*)()) F614_5472;
	R4887[537] = (char *(*)()) F614_5472;
}

char *(*R4888[736])();
void R4888_init () {
	R4888[0] = (char *(*)()) F662_5534;
	R4888[1] = (char *(*)()) F663_5534;
	R4888[2] = (char *(*)()) F664_5534;
	{long i; for (i = 3; i < 5; i++) R4888[i] = (char *(*)()) F662_5534;}
	R4888[5] = (char *(*)()) F663_5534;
	R4888[6] = (char *(*)()) F664_5534;
	R4888[7] = (char *(*)()) F669_5598;
	R4888[27] = (char *(*)()) F689_5958;
	R4888[28] = (char *(*)()) F690_5958;
	R4888[29] = (char *(*)()) F691_5958;
	R4888[30] = (char *(*)()) F692_5958;
	R4888[31] = (char *(*)()) F693_5958;
	R4888[32] = (char *(*)()) F694_5958;
	R4888[33] = (char *(*)()) F695_5958;
	R4888[34] = (char *(*)()) F696_5958;
	R4888[35] = (char *(*)()) F697_5958;
	R4888[36] = (char *(*)()) F698_5958;
	R4888[37] = (char *(*)()) F699_5958;
	R4888[38] = (char *(*)()) F700_5958;
	R4888[46] = (char *(*)()) F689_5958;
	R4888[47] = (char *(*)()) F693_5958;
	{long i; for (i = 48; i < 52; i++) R4888[i] = (char *(*)()) F689_5958;}
	R4888[56] = (char *(*)()) F689_5958;
	{long i; for (i = 59; i < 61; i++) R4888[i] = (char *(*)()) F689_5958;}
	R4888[64] = (char *(*)()) F689_5958;
	{long i; for (i = 66; i < 70; i++) R4888[i] = (char *(*)()) F689_5958;}
	R4888[84] = (char *(*)()) F505_5256;
	R4888[88] = (char *(*)()) F505_5256;
	{long i; for (i = 268; i < 270; i++) R4888[i] = (char *(*)()) F929_7056;}
	{long i; for (i = 480; i < 482; i++) R4888[i] = (char *(*)()) F1134_9932;}
	R4888[527] = (char *(*)()) F1134_9932;
	R4888[537] = (char *(*)()) F1134_9932;
	R4888[735] = (char *(*)()) F929_7056;
}

char *(*R4889[736])();
void R4889_init () {
	R4889[0] = (char *(*)()) F662_5525;
	R4889[1] = (char *(*)()) F663_5525;
	R4889[2] = (char *(*)()) F664_5525;
	{long i; for (i = 3; i < 5; i++) R4889[i] = (char *(*)()) F662_5525;}
	R4889[5] = (char *(*)()) F663_5525;
	R4889[6] = (char *(*)()) F664_5525;
	R4889[7] = (char *(*)()) F662_5525;
	R4889[27] = (char *(*)()) F638_5503;
	R4889[28] = (char *(*)()) F639_5503;
	R4889[29] = (char *(*)()) F640_5503;
	R4889[30] = (char *(*)()) F641_5503;
	R4889[31] = (char *(*)()) F642_5503;
	R4889[32] = (char *(*)()) F643_5503;
	R4889[33] = (char *(*)()) F644_5503;
	R4889[34] = (char *(*)()) F645_5503;
	R4889[35] = (char *(*)()) F646_5503;
	R4889[36] = (char *(*)()) F647_5503;
	R4889[37] = (char *(*)()) F648_5503;
	R4889[38] = (char *(*)()) F649_5503;
	R4889[46] = (char *(*)()) F638_5503;
	R4889[47] = (char *(*)()) F642_5503;
	{long i; for (i = 48; i < 52; i++) R4889[i] = (char *(*)()) F638_5503;}
	R4889[56] = (char *(*)()) F638_5503;
	{long i; for (i = 59; i < 61; i++) R4889[i] = (char *(*)()) F638_5503;}
	R4889[64] = (char *(*)()) F638_5503;
	{long i; for (i = 66; i < 70; i++) R4889[i] = (char *(*)()) F638_5503;}
	{long i; for (i = 268; i < 270; i++) R4889[i] = (char *(*)()) F929_6998;}
	{long i; for (i = 480; i < 482; i++) R4889[i] = (char *(*)()) F638_5503;}
	R4889[527] = (char *(*)()) F638_5503;
	R4889[537] = (char *(*)()) F638_5503;
	R4889[735] = (char *(*)()) F929_6998;
}

char *(*R4890[729])();
void R4890_init () {
	R4890[0] = (char *(*)()) F669_5599;
	R4890[20] = (char *(*)()) F689_5959;
	R4890[21] = (char *(*)()) F690_5959;
	R4890[22] = (char *(*)()) F691_5959;
	R4890[23] = (char *(*)()) F692_5959;
	R4890[24] = (char *(*)()) F693_5959;
	R4890[25] = (char *(*)()) F694_5959;
	R4890[26] = (char *(*)()) F695_5959;
	R4890[27] = (char *(*)()) F696_5959;
	R4890[28] = (char *(*)()) F697_5959;
	R4890[29] = (char *(*)()) F698_5959;
	R4890[30] = (char *(*)()) F699_5959;
	R4890[31] = (char *(*)()) F700_5959;
	R4890[39] = (char *(*)()) F689_5959;
	R4890[40] = (char *(*)()) F693_5959;
	{long i; for (i = 41; i < 45; i++) R4890[i] = (char *(*)()) F689_5959;}
	R4890[49] = (char *(*)()) F689_5959;
	{long i; for (i = 52; i < 54; i++) R4890[i] = (char *(*)()) F689_5959;}
	R4890[57] = (char *(*)()) F689_5959;
	{long i; for (i = 59; i < 63; i++) R4890[i] = (char *(*)()) F689_5959;}
	{long i; for (i = 261; i < 263; i++) R4890[i] = (char *(*)()) F929_7057;}
	{long i; for (i = 473; i < 475; i++) R4890[i] = (char *(*)()) F1134_9931;}
	R4890[520] = (char *(*)()) F1134_9931;
	R4890[530] = (char *(*)()) F1134_9931;
	R4890[728] = (char *(*)()) F1397_13908;
}

char *(*R4891[538])();
void R4891_init () {
	R4891[0] = (char *(*)()) F626_5487;
	R4891[1] = (char *(*)()) F630_5487;
	R4891[2] = (char *(*)()) F634_5487;
	{long i; for (i = 3; i < 5; i++) R4891[i] = (char *(*)()) F626_5487;}
	R4891[5] = (char *(*)()) F630_5487;
	R4891[6] = (char *(*)()) F634_5487;
	R4891[7] = (char *(*)()) F626_5487;
	R4891[27] = (char *(*)()) F626_5487;
	R4891[28] = (char *(*)()) F627_5487;
	R4891[29] = (char *(*)()) F628_5487;
	R4891[30] = (char *(*)()) F629_5487;
	R4891[31] = (char *(*)()) F630_5487;
	R4891[32] = (char *(*)()) F631_5487;
	R4891[33] = (char *(*)()) F632_5487;
	R4891[34] = (char *(*)()) F633_5487;
	R4891[35] = (char *(*)()) F634_5487;
	R4891[36] = (char *(*)()) F635_5487;
	R4891[37] = (char *(*)()) F636_5487;
	R4891[38] = (char *(*)()) F637_5487;
	R4891[46] = (char *(*)()) F626_5487;
	R4891[47] = (char *(*)()) F630_5487;
	{long i; for (i = 48; i < 52; i++) R4891[i] = (char *(*)()) F626_5487;}
	R4891[56] = (char *(*)()) F626_5487;
	{long i; for (i = 59; i < 61; i++) R4891[i] = (char *(*)()) F626_5487;}
	R4891[64] = (char *(*)()) F626_5487;
	{long i; for (i = 66; i < 70; i++) R4891[i] = (char *(*)()) F626_5487;}
	{long i; for (i = 480; i < 482; i++) R4891[i] = (char *(*)()) F626_5487;}
	R4891[527] = (char *(*)()) F626_5487;
	R4891[537] = (char *(*)()) F626_5487;
}

char *(*R4892[538])();
void R4892_init () {
	R4892[0] = (char *(*)()) F452_5233;
	R4892[1] = (char *(*)()) F457_5233;
	R4892[2] = (char *(*)()) F461_5233;
	{long i; for (i = 3; i < 5; i++) R4892[i] = (char *(*)()) F452_5233;}
	R4892[5] = (char *(*)()) F457_5233;
	R4892[6] = (char *(*)()) F461_5233;
	R4892[7] = (char *(*)()) F452_5233;
	R4892[18] = (char *(*)()) F451_5233;
	R4892[19] = (char *(*)()) F456_5233;
	R4892[20] = (char *(*)()) F462_5233;
	R4892[21] = (char *(*)()) F452_5233;
	R4892[22] = (char *(*)()) F466_5233;
	R4892[23] = (char *(*)()) F457_5233;
	R4892[24] = (char *(*)()) F451_5233;
	R4892[25] = (char *(*)()) F456_5233;
	R4892[26] = (char *(*)()) F451_5233;
	R4892[397] = (char *(*)()) F459_5233;
	R4892[401] = (char *(*)()) F458_5233;
	{long i; for (i = 480; i < 482; i++) R4892[i] = (char *(*)()) F452_5233;}
	{long i; for (i = 482; i < 484; i++) R4892[i] = (char *(*)()) F1144_10095;}
	{long i; for (i = 485; i < 487; i++) R4892[i] = (char *(*)()) F1144_10095;}
	{long i; for (i = 489; i < 492; i++) R4892[i] = (char *(*)()) F1144_10095;}
	{long i; for (i = 493; i < 495; i++) R4892[i] = (char *(*)()) F1144_10095;}
	R4892[527] = (char *(*)()) F452_5233;
	R4892[537] = (char *(*)()) F452_5233;
}

char *(*R4895[736])();
void R4895_init () {
	R4895[0] = (char *(*)()) F662_5540;
	R4895[1] = (char *(*)()) F663_5540_4895_4;
	R4895[2] = (char *(*)()) F664_5540_4895_4;
	R4895[3] = (char *(*)()) F665_5563;
	R4895[4] = (char *(*)()) F666_5581;
	R4895[5] = (char *(*)()) F667_5581_4895_4;
	R4895[6] = (char *(*)()) F668_5581_4895_4;
	R4895[7] = (char *(*)()) F669_5603;
	R4895[27] = (char *(*)()) F689_5966;
	R4895[28] = (char *(*)()) F690_5966_4895_4;
	R4895[29] = (char *(*)()) F691_5966_4895_4;
	R4895[30] = (char *(*)()) F692_5966_4895_4;
	R4895[31] = (char *(*)()) F693_5966_4895_4;
	R4895[32] = (char *(*)()) F694_5966_4895_4;
	R4895[33] = (char *(*)()) F695_5966_4895_4;
	R4895[34] = (char *(*)()) F696_5966_4895_4;
	R4895[35] = (char *(*)()) F697_5966_4895_4;
	R4895[36] = (char *(*)()) F698_5966_4895_4;
	R4895[37] = (char *(*)()) F699_5966_4895_4;
	R4895[38] = (char *(*)()) F700_5966_4895_4;
	R4895[46] = (char *(*)()) F704_6008;
	R4895[47] = (char *(*)()) F705_6008_4895_4;
	{long i; for (i = 48; i < 52; i++) R4895[i] = (char *(*)()) F704_6008;}
	R4895[56] = (char *(*)()) F704_6008;
	{long i; for (i = 59; i < 61; i++) R4895[i] = (char *(*)()) F704_6008;}
	R4895[64] = (char *(*)()) F704_6008;
	{long i; for (i = 66; i < 70; i++) R4895[i] = (char *(*)()) F704_6008;}
	{long i; for (i = 268; i < 270; i++) R4895[i] = (char *(*)()) F929_7063_4895_4;}
	R4895[397] = (char *(*)()) F1059_9024_4895_4;
	R4895[401] = (char *(*)()) F1063_9192_4895_4;
	{long i; for (i = 480; i < 484; i++) R4895[i] = (char *(*)()) F1137_10037;}
	{long i; for (i = 485; i < 487; i++) R4895[i] = (char *(*)()) F1137_10037;}
	{long i; for (i = 489; i < 492; i++) R4895[i] = (char *(*)()) F1137_10037;}
	{long i; for (i = 493; i < 495; i++) R4895[i] = (char *(*)()) F1137_10037;}
	R4895[527] = (char *(*)()) F1134_9956;
	R4895[537] = (char *(*)()) F1134_9956;
	R4895[735] = (char *(*)()) F929_7063_4895_4;
}
static void F663_5540_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_5540(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F664_5540_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5540(Current, *(EIF_BOOLEAN *)arg1);
}
static void F667_5581_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5581(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F668_5581_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5581(Current, *(EIF_BOOLEAN *)arg1);
}
static void F690_5966_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F690_5966(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F691_5966_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F691_5966(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F692_5966_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F692_5966(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F693_5966_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F693_5966(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F694_5966_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F694_5966(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F695_5966_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F695_5966(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F696_5966_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F696_5966(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F697_5966_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F697_5966(Current, *(EIF_BOOLEAN *)arg1);
}
static void F698_5966_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F698_5966(Current, *(EIF_POINTER *)arg1);
}
static void F699_5966_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F699_5966(Current, *(EIF_REAL_32 *)arg1);
}
static void F700_5966_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F700_5966(Current, *(EIF_REAL_64 *)arg1);
}
static void F705_6008_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F705_6008(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F929_7063_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F929_7063(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1059_9024_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1059_9024(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1063_9192_4895_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1063_9192(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R4897[797])();
void R4897_init () {
	R4897[0] = (char *(*)()) F601_5438;
	R4897[1] = (char *(*)()) F602_5438_4897_4;
	R4897[2] = (char *(*)()) F603_5438_4897_4;
	R4897[3] = (char *(*)()) F604_5438_4897_4;
	R4897[4] = (char *(*)()) F605_5438_4897_4;
	R4897[5] = (char *(*)()) F606_5438_4897_4;
	R4897[6] = (char *(*)()) F607_5438_4897_4;
	R4897[7] = (char *(*)()) F608_5438_4897_4;
	R4897[8] = (char *(*)()) F609_5438_4897_4;
	R4897[9] = (char *(*)()) F610_5438_4897_4;
	R4897[10] = (char *(*)()) F611_5438_4897_4;
	R4897[11] = (char *(*)()) F612_5438_4897_4;
	R4897[61] = (char *(*)()) F626_5493;
	R4897[62] = (char *(*)()) F630_5493_4897_4;
	R4897[63] = (char *(*)()) F634_5493_4897_4;
	R4897[64] = (char *(*)()) F665_5568;
	R4897[65] = (char *(*)()) F626_5493;
	R4897[66] = (char *(*)()) F630_5493_4897_4;
	R4897[67] = (char *(*)()) F634_5493_4897_4;
	R4897[68] = (char *(*)()) F626_5493;
	R4897[79] = (char *(*)()) F680_5847;
	R4897[80] = (char *(*)()) F681_5847_4897_4;
	R4897[81] = (char *(*)()) F682_5847_4897_4;
	R4897[82] = (char *(*)()) F683_5847;
	R4897[83] = (char *(*)()) F684_5847_4897_4;
	R4897[84] = (char *(*)()) F685_5847_4897_4;
	R4897[85] = (char *(*)()) F680_5847;
	R4897[86] = (char *(*)()) F681_5847_4897_4;
	R4897[87] = (char *(*)()) F680_5847;
	R4897[88] = (char *(*)()) F689_5978;
	R4897[89] = (char *(*)()) F690_5978_4897_4;
	R4897[90] = (char *(*)()) F691_5978_4897_4;
	R4897[91] = (char *(*)()) F692_5978_4897_4;
	R4897[92] = (char *(*)()) F693_5978_4897_4;
	R4897[93] = (char *(*)()) F694_5978_4897_4;
	R4897[94] = (char *(*)()) F695_5978_4897_4;
	R4897[95] = (char *(*)()) F696_5978_4897_4;
	R4897[96] = (char *(*)()) F697_5978_4897_4;
	R4897[97] = (char *(*)()) F698_5978_4897_4;
	R4897[98] = (char *(*)()) F699_5978_4897_4;
	R4897[99] = (char *(*)()) F700_5978_4897_4;
	R4897[107] = (char *(*)()) F689_5978;
	R4897[108] = (char *(*)()) F693_5978_4897_4;
	R4897[109] = (char *(*)()) F689_5978;
	{long i; for (i = 110; i < 113; i++) R4897[i] = (char *(*)()) F711_6059;}
	R4897[117] = (char *(*)()) F711_6059;
	{long i; for (i = 120; i < 122; i++) R4897[i] = (char *(*)()) F711_6059;}
	R4897[125] = (char *(*)()) F711_6059;
	{long i; for (i = 127; i < 131; i++) R4897[i] = (char *(*)()) F711_6059;}
	R4897[145] = (char *(*)()) F505_5261_4897_4;
	R4897[149] = (char *(*)()) F505_5261_4897_4;
	{long i; for (i = 329; i < 331; i++) R4897[i] = (char *(*)()) F929_7184_4897_4;}
	R4897[458] = (char *(*)()) F1059_9035_4897_4;
	R4897[462] = (char *(*)()) F1063_9203_4897_4;
	{long i; for (i = 541; i < 545; i++) R4897[i] = (char *(*)()) F1137_10038;}
	{long i; for (i = 546; i < 548; i++) R4897[i] = (char *(*)()) F1137_10038;}
	{long i; for (i = 550; i < 553; i++) R4897[i] = (char *(*)()) F1137_10038;}
	{long i; for (i = 554; i < 556; i++) R4897[i] = (char *(*)()) F1137_10038;}
	R4897[588] = (char *(*)()) F626_5493;
	R4897[598] = (char *(*)()) F626_5493;
	R4897[796] = (char *(*)()) F929_7184_4897_4;
}
static void F602_5438_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F602_5438(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F603_5438_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F603_5438(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F604_5438_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F604_5438(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F605_5438_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F605_5438(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F606_5438_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F606_5438(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F607_5438_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F607_5438(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F608_5438_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F608_5438(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F609_5438_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F609_5438(Current, *(EIF_BOOLEAN *)arg1);
}
static void F610_5438_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F610_5438(Current, *(EIF_POINTER *)arg1);
}
static void F611_5438_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F611_5438(Current, *(EIF_REAL_32 *)arg1);
}
static void F612_5438_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F612_5438(Current, *(EIF_REAL_64 *)arg1);
}
static void F630_5493_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F630_5493(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F634_5493_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F634_5493(Current, *(EIF_BOOLEAN *)arg1);
}
static void F681_5847_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F681_5847(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F682_5847_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F682_5847(Current, *(EIF_POINTER *)arg1);
}
static void F684_5847_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F684_5847(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F685_5847_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F685_5847(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F690_5978_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F690_5978(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F691_5978_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F691_5978(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F692_5978_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F692_5978(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F693_5978_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F693_5978(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F694_5978_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F694_5978(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F695_5978_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F695_5978(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F696_5978_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F696_5978(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F697_5978_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F697_5978(Current, *(EIF_BOOLEAN *)arg1);
}
static void F698_5978_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F698_5978(Current, *(EIF_POINTER *)arg1);
}
static void F699_5978_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F699_5978(Current, *(EIF_REAL_32 *)arg1);
}
static void F700_5978_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F700_5978(Current, *(EIF_REAL_64 *)arg1);
}
static void F505_5261_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F505_5261(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F929_7184_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F929_7184(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1059_9035_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1059_9035(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1063_9203_4897_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1063_9203(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R4898[599])();
void R4898_init () {
	R4898[0] = (char *(*)()) F410_5218;
	R4898[1] = (char *(*)()) F411_5218_4898_4;
	R4898[2] = (char *(*)()) F412_5218_4898_4;
	R4898[3] = (char *(*)()) F415_5218_4898_4;
	R4898[4] = (char *(*)()) F413_5218_4898_4;
	R4898[5] = (char *(*)()) F416_5218_4898_4;
	R4898[6] = (char *(*)()) F414_5218_4898_4;
	R4898[7] = (char *(*)()) F417_5218_4898_4;
	R4898[8] = (char *(*)()) F418_5218_4898_4;
	R4898[9] = (char *(*)()) F419_5218_4898_4;
	R4898[10] = (char *(*)()) F420_5218_4898_4;
	R4898[11] = (char *(*)()) F421_5218_4898_4;
	R4898[61] = (char *(*)()) F626_5494;
	R4898[62] = (char *(*)()) F630_5494_4898_4;
	R4898[63] = (char *(*)()) F634_5494_4898_4;
	R4898[64] = (char *(*)()) F665_5569;
	R4898[65] = (char *(*)()) F410_5218;
	R4898[66] = (char *(*)()) F413_5218_4898_4;
	R4898[67] = (char *(*)()) F418_5218_4898_4;
	R4898[68] = (char *(*)()) F626_5494;
	R4898[79] = (char *(*)()) F410_5218;
	R4898[80] = (char *(*)()) F413_5218_4898_4;
	R4898[81] = (char *(*)()) F419_5218_4898_4;
	R4898[82] = (char *(*)()) F410_5218;
	{long i; for (i = 83; i < 85; i++) R4898[i] = (char *(*)()) F413_5218_4898_4;}
	R4898[85] = (char *(*)()) F410_5218;
	R4898[86] = (char *(*)()) F413_5218_4898_4;
	R4898[87] = (char *(*)()) F410_5218;
	R4898[107] = (char *(*)()) F704_6018;
	R4898[108] = (char *(*)()) F705_6018_4898_4;
	{long i; for (i = 109; i < 113; i++) R4898[i] = (char *(*)()) F704_6018;}
	R4898[117] = (char *(*)()) F704_6018;
	{long i; for (i = 120; i < 122; i++) R4898[i] = (char *(*)()) F704_6018;}
	R4898[125] = (char *(*)()) F704_6018;
	{long i; for (i = 127; i < 131; i++) R4898[i] = (char *(*)()) F704_6018;}
	R4898[145] = (char *(*)()) F413_5218_4898_4;
	R4898[149] = (char *(*)()) F413_5218_4898_4;
	R4898[462] = (char *(*)()) F1063_9204_4898_4;
	{long i; for (i = 541; i < 543; i++) R4898[i] = (char *(*)()) F626_5494;}
	{long i; for (i = 543; i < 545; i++) R4898[i] = (char *(*)()) F410_5218;}
	{long i; for (i = 546; i < 548; i++) R4898[i] = (char *(*)()) F410_5218;}
	{long i; for (i = 550; i < 553; i++) R4898[i] = (char *(*)()) F410_5218;}
	{long i; for (i = 554; i < 556; i++) R4898[i] = (char *(*)()) F410_5218;}
	R4898[588] = (char *(*)()) F626_5494;
	R4898[598] = (char *(*)()) F626_5494;
}
static void F411_5218_4898_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F411_5218(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F412_5218_4898_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F412_5218(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F415_5218_4898_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F415_5218(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F413_5218_4898_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F413_5218(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F416_5218_4898_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F416_5218(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F414_5218_4898_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F414_5218(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F417_5218_4898_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F417_5218(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F418_5218_4898_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F418_5218(Current, *(EIF_BOOLEAN *)arg1);
}
static void F419_5218_4898_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F419_5218(Current, *(EIF_POINTER *)arg1);
}
static void F420_5218_4898_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F420_5218(Current, *(EIF_REAL_32 *)arg1);
}
static void F421_5218_4898_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F421_5218(Current, *(EIF_REAL_64 *)arg1);
}
static void F630_5494_4898_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F630_5494(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F634_5494_4898_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F634_5494(Current, *(EIF_BOOLEAN *)arg1);
}
static void F705_6018_4898_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F705_6018(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1063_9204_4898_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1063_9204(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R4899[538])();
void R4899_init () {
	R4899[0] = (char *(*)()) F662_5549;
	R4899[1] = (char *(*)()) F663_5549;
	R4899[2] = (char *(*)()) F664_5549;
	{long i; for (i = 3; i < 5; i++) R4899[i] = (char *(*)()) F662_5549;}
	R4899[5] = (char *(*)()) F663_5549;
	R4899[6] = (char *(*)()) F664_5549;
	R4899[7] = (char *(*)()) F669_5611;
	R4899[18] = (char *(*)()) F680_5848;
	R4899[19] = (char *(*)()) F681_5848;
	R4899[20] = (char *(*)()) F682_5848;
	R4899[21] = (char *(*)()) F683_5848;
	R4899[22] = (char *(*)()) F684_5848;
	R4899[23] = (char *(*)()) F685_5848;
	R4899[24] = (char *(*)()) F680_5848;
	R4899[25] = (char *(*)()) F681_5848;
	R4899[26] = (char *(*)()) F680_5848;
	R4899[27] = (char *(*)()) F689_5984;
	R4899[28] = (char *(*)()) F690_5984;
	R4899[29] = (char *(*)()) F691_5984;
	R4899[30] = (char *(*)()) F692_5984;
	R4899[31] = (char *(*)()) F693_5984;
	R4899[32] = (char *(*)()) F694_5984;
	R4899[33] = (char *(*)()) F695_5984;
	R4899[34] = (char *(*)()) F696_5984;
	R4899[35] = (char *(*)()) F697_5984;
	R4899[36] = (char *(*)()) F698_5984;
	R4899[37] = (char *(*)()) F699_5984;
	R4899[38] = (char *(*)()) F700_5984;
	R4899[46] = (char *(*)()) F704_6020;
	R4899[47] = (char *(*)()) F705_6020;
	{long i; for (i = 48; i < 52; i++) R4899[i] = (char *(*)()) F704_6020;}
	R4899[56] = (char *(*)()) F704_6020;
	{long i; for (i = 59; i < 61; i++) R4899[i] = (char *(*)()) F704_6020;}
	R4899[64] = (char *(*)()) F704_6020;
	{long i; for (i = 66; i < 70; i++) R4899[i] = (char *(*)()) F704_6020;}
	R4899[397] = (char *(*)()) F1059_9039;
	R4899[401] = (char *(*)()) F1063_9207;
	{long i; for (i = 480; i < 482; i++) R4899[i] = (char *(*)()) F1134_9951;}
	{long i; for (i = 482; i < 484; i++) R4899[i] = (char *(*)()) F1144_10100;}
	{long i; for (i = 485; i < 487; i++) R4899[i] = (char *(*)()) F1144_10100;}
	{long i; for (i = 489; i < 492; i++) R4899[i] = (char *(*)()) F1144_10100;}
	{long i; for (i = 493; i < 495; i++) R4899[i] = (char *(*)()) F1144_10100;}
	R4899[527] = (char *(*)()) F1134_9951;
	R4899[537] = (char *(*)()) F1134_9951;
}

char *(*R4902[599])();
void R4902_init () {
	R4902[0] = (char *(*)()) F601_5388_4902_5;
	R4902[1] = (char *(*)()) F602_5388_4902_5;
	R4902[2] = (char *(*)()) F603_5388_4902_5;
	R4902[3] = (char *(*)()) F604_5388_4902_5;
	R4902[4] = (char *(*)()) F605_5388_4902_5;
	R4902[5] = (char *(*)()) F606_5388_4902_5;
	R4902[6] = (char *(*)()) F607_5388_4902_5;
	R4902[7] = (char *(*)()) F608_5388_4902_5;
	R4902[8] = (char *(*)()) F609_5388_4902_5;
	R4902[9] = (char *(*)()) F610_5388_4902_5;
	R4902[10] = (char *(*)()) F611_5388_4902_5;
	R4902[11] = (char *(*)()) F612_5388_4902_5;
	R4902[61] = (char *(*)()) F614_5467_4902_5;
	R4902[62] = (char *(*)()) F618_5467_4902_5;
	R4902[63] = (char *(*)()) F622_5467_4902_5;
	{long i; for (i = 64; i < 66; i++) R4902[i] = (char *(*)()) F614_5467_4902_5;}
	R4902[66] = (char *(*)()) F618_5467_4902_5;
	R4902[67] = (char *(*)()) F622_5467_4902_5;
	R4902[68] = (char *(*)()) F614_5467_4902_5;
	R4902[88] = (char *(*)()) F689_5931_4902_5;
	R4902[89] = (char *(*)()) F690_5931_4902_5;
	R4902[90] = (char *(*)()) F691_5931_4902_5;
	R4902[91] = (char *(*)()) F692_5931_4902_5;
	R4902[92] = (char *(*)()) F693_5931_4902_5;
	R4902[93] = (char *(*)()) F694_5931_4902_5;
	R4902[94] = (char *(*)()) F695_5931_4902_5;
	R4902[95] = (char *(*)()) F696_5931_4902_5;
	R4902[96] = (char *(*)()) F697_5931_4902_5;
	R4902[97] = (char *(*)()) F698_5931_4902_5;
	R4902[98] = (char *(*)()) F699_5931_4902_5;
	R4902[99] = (char *(*)()) F700_5931_4902_5;
	R4902[107] = (char *(*)()) F689_5931_4902_5;
	R4902[108] = (char *(*)()) F693_5931_4902_5;
	{long i; for (i = 109; i < 113; i++) R4902[i] = (char *(*)()) F689_5931_4902_5;}
	R4902[117] = (char *(*)()) F689_5931_4902_5;
	{long i; for (i = 120; i < 122; i++) R4902[i] = (char *(*)()) F689_5931_4902_5;}
	R4902[125] = (char *(*)()) F689_5931_4902_5;
	{long i; for (i = 127; i < 131; i++) R4902[i] = (char *(*)()) F689_5931_4902_5;}
	R4902[458] = (char *(*)()) F1059_8976_4902_5;
	R4902[462] = (char *(*)()) F1063_9145_4902_5;
	{long i; for (i = 541; i < 543; i++) R4902[i] = (char *(*)()) F1134_9923_4902_5;}
	R4902[588] = (char *(*)()) F1134_9923_4902_5;
	R4902[598] = (char *(*)()) F1134_9923_4902_5;
}
static EIF_REFERENCE F601_5388_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F601_5388(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F602_5388_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F602_5388(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(976, 0x00).id, 976, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F603_5388_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F603_5388(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(985, 0x00).id, 985, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F604_5388_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F604_5388(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(979, 0x00).id, 979, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F605_5388_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F605_5388(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F606_5388_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F606_5388(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F607_5388_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F607_5388(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F608_5388_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F608_5388(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(982, 0x00).id, 982, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F609_5388_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F609_5388(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F610_5388_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F610_5388(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F611_5388_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F611_5388(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(988, 0x00).id, 988, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F612_5388_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F612_5388(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F614_5467_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F614_5467(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F618_5467_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F618_5467(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F622_5467_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F622_5467(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F689_5931_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F689_5931(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F690_5931_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F690_5931(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(976, 0x00).id, 976, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F691_5931_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F691_5931(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(985, 0x00).id, 985, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F692_5931_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F692_5931(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(979, 0x00).id, 979, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F693_5931_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F693_5931(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F694_5931_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F694_5931(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F695_5931_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F695_5931(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F696_5931_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F696_5931(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(982, 0x00).id, 982, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F697_5931_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F697_5931(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F698_5931_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F698_5931(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F699_5931_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F699_5931(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(988, 0x00).id, 988, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F700_5931_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F700_5931(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1059_8976_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1059_8976(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1063_9145_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1063_9145(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1134_9923_4902_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1134_9923(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4903[599])();
void R4903_init () {
	R4903[0] = (char *(*)()) F601_5389_4903_5;
	R4903[1] = (char *(*)()) F602_5389_4903_5;
	R4903[2] = (char *(*)()) F603_5389_4903_5;
	R4903[3] = (char *(*)()) F604_5389_4903_5;
	R4903[4] = (char *(*)()) F605_5389_4903_5;
	R4903[5] = (char *(*)()) F606_5389_4903_5;
	R4903[6] = (char *(*)()) F607_5389_4903_5;
	R4903[7] = (char *(*)()) F608_5389_4903_5;
	R4903[8] = (char *(*)()) F609_5389_4903_5;
	R4903[9] = (char *(*)()) F610_5389_4903_5;
	R4903[10] = (char *(*)()) F611_5389_4903_5;
	R4903[11] = (char *(*)()) F612_5389_4903_5;
	R4903[61] = (char *(*)()) F614_5468_4903_5;
	R4903[62] = (char *(*)()) F618_5468_4903_5;
	R4903[63] = (char *(*)()) F622_5468_4903_5;
	{long i; for (i = 64; i < 66; i++) R4903[i] = (char *(*)()) F614_5468_4903_5;}
	R4903[66] = (char *(*)()) F618_5468_4903_5;
	R4903[67] = (char *(*)()) F622_5468_4903_5;
	R4903[68] = (char *(*)()) F614_5468_4903_5;
	R4903[88] = (char *(*)()) F689_5932_4903_5;
	R4903[89] = (char *(*)()) F690_5932_4903_5;
	R4903[90] = (char *(*)()) F691_5932_4903_5;
	R4903[91] = (char *(*)()) F692_5932_4903_5;
	R4903[92] = (char *(*)()) F693_5932_4903_5;
	R4903[93] = (char *(*)()) F694_5932_4903_5;
	R4903[94] = (char *(*)()) F695_5932_4903_5;
	R4903[95] = (char *(*)()) F696_5932_4903_5;
	R4903[96] = (char *(*)()) F697_5932_4903_5;
	R4903[97] = (char *(*)()) F698_5932_4903_5;
	R4903[98] = (char *(*)()) F699_5932_4903_5;
	R4903[99] = (char *(*)()) F700_5932_4903_5;
	R4903[107] = (char *(*)()) F689_5932_4903_5;
	R4903[108] = (char *(*)()) F693_5932_4903_5;
	{long i; for (i = 109; i < 113; i++) R4903[i] = (char *(*)()) F689_5932_4903_5;}
	R4903[117] = (char *(*)()) F689_5932_4903_5;
	{long i; for (i = 120; i < 122; i++) R4903[i] = (char *(*)()) F689_5932_4903_5;}
	R4903[125] = (char *(*)()) F689_5932_4903_5;
	{long i; for (i = 127; i < 131; i++) R4903[i] = (char *(*)()) F689_5932_4903_5;}
	R4903[462] = (char *(*)()) F1063_9146_4903_5;
	{long i; for (i = 541; i < 543; i++) R4903[i] = (char *(*)()) F614_5468_4903_5;}
	R4903[588] = (char *(*)()) F614_5468_4903_5;
	R4903[598] = (char *(*)()) F614_5468_4903_5;
}
static EIF_REFERENCE F601_5389_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F601_5389(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F602_5389_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F602_5389(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(976, 0x00).id, 976, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F603_5389_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F603_5389(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(985, 0x00).id, 985, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F604_5389_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F604_5389(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(979, 0x00).id, 979, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F605_5389_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F605_5389(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F606_5389_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F606_5389(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F607_5389_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F607_5389(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F608_5389_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F608_5389(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(982, 0x00).id, 982, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F609_5389_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F609_5389(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F610_5389_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F610_5389(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F611_5389_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F611_5389(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(988, 0x00).id, 988, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F612_5389_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F612_5389(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F614_5468_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F614_5468(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F618_5468_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F618_5468(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F622_5468_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F622_5468(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F689_5932_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F689_5932(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F690_5932_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F690_5932(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(976, 0x00).id, 976, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F691_5932_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F691_5932(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(985, 0x00).id, 985, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F692_5932_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F692_5932(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(979, 0x00).id, 979, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F693_5932_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F693_5932(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F694_5932_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F694_5932(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F695_5932_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F695_5932(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(997, 0x00).id, 997, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F696_5932_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F696_5932(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(982, 0x00).id, 982, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F697_5932_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F697_5932(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1000, 0x00).id, 1000, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F698_5932_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F698_5932(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F699_5932_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F699_5932(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(988, 0x00).id, 988, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F700_5932_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F700_5932(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1063_9146_4903_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1063_9146(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(994, 0x00).id, 994, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R4905[463])();
void R4905_init () {
	R4905[0] = (char *(*)()) F601_5407_4905_12;
	R4905[1] = (char *(*)()) F602_5407_4905_12;
	R4905[2] = (char *(*)()) F603_5407_4905_12;
	R4905[3] = (char *(*)()) F604_5407_4905_12;
	R4905[4] = (char *(*)()) F605_5407_4905_12;
	R4905[5] = (char *(*)()) F606_5407_4905_12;
	R4905[6] = (char *(*)()) F607_5407_4905_12;
	R4905[7] = (char *(*)()) F608_5407_4905_12;
	R4905[8] = (char *(*)()) F609_5407_4905_12;
	R4905[9] = (char *(*)()) F610_5407_4905_12;
	R4905[10] = (char *(*)()) F611_5407_4905_12;
	R4905[11] = (char *(*)()) F612_5407_4905_12;
	R4905[79] = (char *(*)()) F680_5840;
	R4905[80] = (char *(*)()) F681_5840_4905_12;
	R4905[81] = (char *(*)()) F682_5840_4905_12;
	R4905[82] = (char *(*)()) F683_5840_4905_12;
	R4905[83] = (char *(*)()) F684_5840_4905_12;
	R4905[84] = (char *(*)()) F685_5840_4905_12;
	R4905[85] = (char *(*)()) F680_5840;
	R4905[86] = (char *(*)()) F681_5840_4905_12;
	R4905[87] = (char *(*)()) F680_5840;
	R4905[88] = (char *(*)()) F689_5964_4905_12;
	R4905[89] = (char *(*)()) F690_5964_4905_12;
	R4905[90] = (char *(*)()) F691_5964_4905_12;
	R4905[91] = (char *(*)()) F692_5964_4905_12;
	R4905[92] = (char *(*)()) F693_5964_4905_12;
	R4905[93] = (char *(*)()) F694_5964_4905_12;
	R4905[94] = (char *(*)()) F695_5964_4905_12;
	R4905[95] = (char *(*)()) F696_5964_4905_12;
	R4905[96] = (char *(*)()) F697_5964_4905_12;
	R4905[97] = (char *(*)()) F698_5964_4905_12;
	R4905[98] = (char *(*)()) F699_5964_4905_12;
	R4905[99] = (char *(*)()) F700_5964_4905_12;
	R4905[107] = (char *(*)()) F704_6012_4905_12;
	R4905[108] = (char *(*)()) F705_6012_4905_12;
	{long i; for (i = 109; i < 113; i++) R4905[i] = (char *(*)()) F704_6012_4905_12;}
	R4905[117] = (char *(*)()) F704_6012_4905_12;
	{long i; for (i = 120; i < 122; i++) R4905[i] = (char *(*)()) F704_6012_4905_12;}
	R4905[125] = (char *(*)()) F704_6012_4905_12;
	{long i; for (i = 127; i < 131; i++) R4905[i] = (char *(*)()) F704_6012_4905_12;}
	R4905[458] = (char *(*)()) F1059_8997_4905_12;
	R4905[462] = (char *(*)()) F1063_9165_4905_12;
}
static void F601_5407_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F601_5407(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F602_5407_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F602_5407(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F603_5407_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F603_5407(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F604_5407_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F604_5407(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F605_5407_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F605_5407(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F606_5407_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F606_5407(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F607_5407_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F607_5407(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F608_5407_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F608_5407(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F609_5407_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F609_5407(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F610_5407_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F610_5407(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F611_5407_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F611_5407(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F612_5407_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F612_5407(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F681_5840_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F681_5840(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F682_5840_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F682_5840(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F683_5840_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F683_5840(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F684_5840_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F684_5840(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static void F685_5840_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F685_5840(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F689_5964_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F689_5964(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F690_5964_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F690_5964(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F691_5964_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F691_5964(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F692_5964_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F692_5964(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F693_5964_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F693_5964(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F694_5964_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F694_5964(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F695_5964_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F695_5964(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F696_5964_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F696_5964(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F697_5964_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F697_5964(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F698_5964_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F698_5964(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F699_5964_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F699_5964(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F700_5964_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F700_5964(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F704_6012_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F704_6012(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F705_6012_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F705_6012(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1059_8997_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1059_8997(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1063_9165_4905_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1063_9165(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y4907_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype32[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype33[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype34[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype35[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype36[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype37[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype38[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype39[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype40[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype41[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype42[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype43[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype44[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype45[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype46[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype47[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype48[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype49[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype50[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype51[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype52[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype53[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype54[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype55[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype56[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype57[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype58[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype59[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype60[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype61[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype62[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype63[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype64[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype65[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype66[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype67[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype68[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype69[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype70[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype71[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype72[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype73[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype74[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype75[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype76[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype77[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype78[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype79[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype80[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype81[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype82[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype83[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype84[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype85[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype86[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype87[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype88[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype89[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype90[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype91[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype92[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype93[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype94[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype95[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype96[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype97[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype98[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype99[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype100[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype101[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype102[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype103[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype104[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype105[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype106[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype107[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype108[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype109[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype110[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype111[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype112[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype113[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype114[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype115[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype116[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype117[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype118[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype119[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype120[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype121[] = {1053,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype122[] = {1053,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype123[] = {1058,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype124[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype125[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype126[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype127[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype128[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype129[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype130[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype131[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype132[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype133[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype134[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype135[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype136[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype137[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype138[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype139[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype140[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype141[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype142[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype143[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype144[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype145[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype146[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype147[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype148[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype149[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype150[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype151[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype152[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype153[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype154[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype155[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype156[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype157[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype158[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype159[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype160[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype161[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype162[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype163[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype164[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype165[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype166[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype167[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype168[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype169[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype170[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype171[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype172[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype173[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype174[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype175[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype176[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype177[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype178[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype179[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype180[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype181[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype182[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype183[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype184[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype185[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype186[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype187[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype188[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype189[] = {1006,0xFFFF};
static EIF_TYPE_INDEX Y4907_pgtype190[] = {1006,0xFFFF};
EIF_TYPE_INDEX *Y4907_gen_type [765];
EIF_TYPE_INDEX Y4907 [765];
void Y4907_init (void)
{
	egc_routines_types [4907] = Y4907;
	egc_routines_gen_types [4907] = Y4907_gen_type;
	egc_routines_offset [4907] = 434;
	Y4907_gen_type [0] = Y4907_pgtype0;
	Y4907_gen_type [1] = Y4907_pgtype1;
	Y4907_gen_type [2] = Y4907_pgtype2;
	Y4907_gen_type [3] = Y4907_pgtype3;
	Y4907_gen_type [4] = Y4907_pgtype4;
	Y4907_gen_type [5] = Y4907_pgtype5;
	Y4907_gen_type [6] = Y4907_pgtype6;
	Y4907_gen_type [7] = Y4907_pgtype7;
	Y4907_gen_type [8] = Y4907_pgtype8;
	Y4907_gen_type [9] = Y4907_pgtype9;
	Y4907_gen_type [10] = Y4907_pgtype10;
	Y4907_gen_type [11] = Y4907_pgtype11;
	Y4907_gen_type [12] = Y4907_pgtype12;
	Y4907_gen_type [13] = Y4907_pgtype13;
	Y4907_gen_type [14] = Y4907_pgtype14;
	Y4907_gen_type [15] = Y4907_pgtype15;
	Y4907_gen_type [16] = Y4907_pgtype16;
	Y4907_gen_type [17] = Y4907_pgtype17;
	Y4907_gen_type [18] = Y4907_pgtype18;
	Y4907_gen_type [19] = Y4907_pgtype19;
	Y4907_gen_type [20] = Y4907_pgtype20;
	Y4907_gen_type [21] = Y4907_pgtype21;
	Y4907_gen_type [22] = Y4907_pgtype22;
	Y4907_gen_type [23] = Y4907_pgtype23;
	Y4907_gen_type [24] = Y4907_pgtype24;
	Y4907_gen_type [25] = Y4907_pgtype25;
	Y4907_gen_type [26] = Y4907_pgtype26;
	Y4907_gen_type [27] = Y4907_pgtype27;
	Y4907_gen_type [28] = Y4907_pgtype28;
	Y4907_gen_type [29] = Y4907_pgtype29;
	Y4907_gen_type [30] = Y4907_pgtype30;
	Y4907_gen_type [31] = Y4907_pgtype31;
	Y4907_gen_type [152] = Y4907_pgtype32;
	Y4907_gen_type [153] = Y4907_pgtype33;
	Y4907_gen_type [154] = Y4907_pgtype34;
	Y4907_gen_type [155] = Y4907_pgtype35;
	Y4907_gen_type [156] = Y4907_pgtype36;
	Y4907_gen_type [157] = Y4907_pgtype37;
	Y4907_gen_type [158] = Y4907_pgtype38;
	Y4907_gen_type [159] = Y4907_pgtype39;
	Y4907_gen_type [160] = Y4907_pgtype40;
	Y4907_gen_type [161] = Y4907_pgtype41;
	Y4907_gen_type [162] = Y4907_pgtype42;
	Y4907_gen_type [163] = Y4907_pgtype43;
	Y4907_gen_type [164] = Y4907_pgtype44;
	Y4907_gen_type [165] = Y4907_pgtype45;
	Y4907_gen_type [166] = Y4907_pgtype46;
	Y4907_gen_type [167] = Y4907_pgtype47;
	Y4907_gen_type [168] = Y4907_pgtype48;
	Y4907_gen_type [169] = Y4907_pgtype49;
	Y4907_gen_type [170] = Y4907_pgtype50;
	Y4907_gen_type [171] = Y4907_pgtype51;
	Y4907_gen_type [172] = Y4907_pgtype52;
	Y4907_gen_type [173] = Y4907_pgtype53;
	Y4907_gen_type [174] = Y4907_pgtype54;
	Y4907_gen_type [175] = Y4907_pgtype55;
	Y4907_gen_type [176] = Y4907_pgtype56;
	Y4907_gen_type [177] = Y4907_pgtype57;
	Y4907_gen_type [178] = Y4907_pgtype58;
	Y4907_gen_type [179] = Y4907_pgtype59;
	Y4907_gen_type [180] = Y4907_pgtype60;
	Y4907_gen_type [181] = Y4907_pgtype61;
	Y4907_gen_type [182] = Y4907_pgtype62;
	Y4907_gen_type [183] = Y4907_pgtype63;
	Y4907_gen_type [184] = Y4907_pgtype64;
	Y4907_gen_type [185] = Y4907_pgtype65;
	Y4907_gen_type [186] = Y4907_pgtype66;
	Y4907_gen_type [187] = Y4907_pgtype67;
	Y4907_gen_type [188] = Y4907_pgtype68;
	Y4907_gen_type [189] = Y4907_pgtype69;
	Y4907_gen_type [190] = Y4907_pgtype70;
	Y4907_gen_type [191] = Y4907_pgtype71;
	Y4907_gen_type [192] = Y4907_pgtype72;
	Y4907_gen_type [193] = Y4907_pgtype73;
	Y4907_gen_type [194] = Y4907_pgtype74;
	Y4907_gen_type [195] = Y4907_pgtype75;
	Y4907_gen_type [196] = Y4907_pgtype76;
	Y4907_gen_type [197] = Y4907_pgtype77;
	Y4907_gen_type [198] = Y4907_pgtype78;
	Y4907_gen_type [199] = Y4907_pgtype79;
	Y4907_gen_type [200] = Y4907_pgtype80;
	Y4907_gen_type [201] = Y4907_pgtype81;
	Y4907_gen_type [202] = Y4907_pgtype82;
	Y4907_gen_type [203] = Y4907_pgtype83;
	Y4907_gen_type [204] = Y4907_pgtype84;
	Y4907_gen_type [205] = Y4907_pgtype85;
	Y4907_gen_type [206] = Y4907_pgtype86;
	Y4907_gen_type [207] = Y4907_pgtype87;
	Y4907_gen_type [208] = Y4907_pgtype88;
	Y4907_gen_type [209] = Y4907_pgtype89;
	Y4907_gen_type [210] = Y4907_pgtype90;
	Y4907_gen_type [211] = Y4907_pgtype91;
	Y4907_gen_type [212] = Y4907_pgtype92;
	Y4907_gen_type [213] = Y4907_pgtype93;
	Y4907_gen_type [214] = Y4907_pgtype94;
	Y4907_gen_type [215] = Y4907_pgtype95;
	Y4907_gen_type [216] = Y4907_pgtype96;
	Y4907_gen_type [217] = Y4907_pgtype97;
	Y4907_gen_type [218] = Y4907_pgtype98;
	Y4907_gen_type [219] = Y4907_pgtype99;
	Y4907_gen_type [220] = Y4907_pgtype100;
	Y4907_gen_type [221] = Y4907_pgtype101;
	Y4907_gen_type [222] = Y4907_pgtype102;
	Y4907_gen_type [223] = Y4907_pgtype103;
	Y4907_gen_type [224] = Y4907_pgtype104;
	Y4907_gen_type [225] = Y4907_pgtype105;
	Y4907_gen_type [226] = Y4907_pgtype106;
	Y4907_gen_type [227] = Y4907_pgtype107;
	Y4907_gen_type [228] = Y4907_pgtype108;
	Y4907_gen_type [229] = Y4907_pgtype109;
	Y4907_gen_type [230] = Y4907_pgtype110;
	Y4907_gen_type [231] = Y4907_pgtype111;
	Y4907_gen_type [232] = Y4907_pgtype112;
	Y4907_gen_type [233] = Y4907_pgtype113;
	Y4907_gen_type [234] = Y4907_pgtype114;
	Y4907_gen_type [245] = Y4907_pgtype115;
	Y4907_gen_type [246] = Y4907_pgtype116;
	Y4907_gen_type [247] = Y4907_pgtype117;
	Y4907_gen_type [248] = Y4907_pgtype118;
	Y4907_gen_type [249] = Y4907_pgtype119;
	Y4907_gen_type [250] = Y4907_pgtype120;
	Y4907_gen_type [251] = Y4907_pgtype121;
	Y4907_gen_type [252] = Y4907_pgtype122;
	Y4907_gen_type [253] = Y4907_pgtype123;
	Y4907_gen_type [254] = Y4907_pgtype124;
	Y4907_gen_type [255] = Y4907_pgtype125;
	Y4907_gen_type [256] = Y4907_pgtype126;
	Y4907_gen_type [257] = Y4907_pgtype127;
	Y4907_gen_type [258] = Y4907_pgtype128;
	Y4907_gen_type [259] = Y4907_pgtype129;
	Y4907_gen_type [260] = Y4907_pgtype130;
	Y4907_gen_type [261] = Y4907_pgtype131;
	Y4907_gen_type [262] = Y4907_pgtype132;
	Y4907_gen_type [263] = Y4907_pgtype133;
	Y4907_gen_type [264] = Y4907_pgtype134;
	Y4907_gen_type [265] = Y4907_pgtype135;
	Y4907_gen_type [266] = Y4907_pgtype136;
	Y4907_gen_type [267] = Y4907_pgtype137;
	Y4907_gen_type [268] = Y4907_pgtype138;
	Y4907_gen_type [269] = Y4907_pgtype139;
	Y4907_gen_type [270] = Y4907_pgtype140;
	Y4907_gen_type [271] = Y4907_pgtype141;
	Y4907_gen_type [272] = Y4907_pgtype142;
	Y4907_gen_type [273] = Y4907_pgtype143;
	Y4907_gen_type [274] = Y4907_pgtype144;
	Y4907_gen_type [275] = Y4907_pgtype145;
	Y4907_gen_type [276] = Y4907_pgtype146;
	Y4907_gen_type [277] = Y4907_pgtype147;
	Y4907_gen_type [278] = Y4907_pgtype148;
	Y4907_gen_type [279] = Y4907_pgtype149;
	Y4907_gen_type [280] = Y4907_pgtype150;
	Y4907_gen_type [281] = Y4907_pgtype151;
	Y4907_gen_type [282] = Y4907_pgtype152;
	Y4907_gen_type [283] = Y4907_pgtype153;
	Y4907_gen_type [284] = Y4907_pgtype154;
	Y4907_gen_type [285] = Y4907_pgtype155;
	Y4907_gen_type [286] = Y4907_pgtype156;
	Y4907_gen_type [287] = Y4907_pgtype157;
	Y4907_gen_type [288] = Y4907_pgtype158;
	Y4907_gen_type [289] = Y4907_pgtype159;
	Y4907_gen_type [290] = Y4907_pgtype160;
	Y4907_gen_type [291] = Y4907_pgtype161;
	Y4907_gen_type [292] = Y4907_pgtype162;
	Y4907_gen_type [293] = Y4907_pgtype163;
	Y4907_gen_type [294] = Y4907_pgtype164;
	Y4907_gen_type [295] = Y4907_pgtype165;
	Y4907_gen_type [296] = Y4907_pgtype166;
	Y4907_gen_type [624] = Y4907_pgtype167;
	Y4907_gen_type [625] = Y4907_pgtype168;
	Y4907_gen_type [628] = Y4907_pgtype169;
	Y4907_gen_type [699] = Y4907_pgtype170;
	Y4907_gen_type [703] = Y4907_pgtype171;
	Y4907_gen_type [704] = Y4907_pgtype172;
	Y4907_gen_type [705] = Y4907_pgtype173;
	Y4907_gen_type [706] = Y4907_pgtype174;
	Y4907_gen_type [707] = Y4907_pgtype175;
	Y4907_gen_type [708] = Y4907_pgtype176;
	Y4907_gen_type [743] = Y4907_pgtype177;
	Y4907_gen_type [752] = Y4907_pgtype178;
	Y4907_gen_type [753] = Y4907_pgtype179;
	Y4907_gen_type [754] = Y4907_pgtype180;
	Y4907_gen_type [755] = Y4907_pgtype181;
	Y4907_gen_type [756] = Y4907_pgtype182;
	Y4907_gen_type [757] = Y4907_pgtype183;
	Y4907_gen_type [758] = Y4907_pgtype184;
	Y4907_gen_type [759] = Y4907_pgtype185;
	Y4907_gen_type [760] = Y4907_pgtype186;
	Y4907_gen_type [761] = Y4907_pgtype187;
	Y4907_gen_type [762] = Y4907_pgtype188;
	Y4907_gen_type [763] = Y4907_pgtype189;
	Y4907_gen_type [764] = Y4907_pgtype190;
	{long i; for (i = 152; i < 235; i++) Y4907[i] = 1006;};
	{long i; for (i = 251; i < 253; i++) Y4907[i] = 1053;};
	Y4907[253] = 1058;
	{long i; for (i = 254; i < 297; i++) Y4907[i] = 1006;};
	{long i; for (i = 624; i < 626; i++) Y4907[i] = 1006;};
	Y4907[628] = 1006;
	Y4907[699] = 1006;
	{long i; for (i = 703; i < 709; i++) Y4907[i] = 1006;};
	Y4907[743] = 1006;
	{long i; for (i = 752; i < 765; i++) Y4907[i] = 1006;};
}


#ifdef __cplusplus
}
#endif
