#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O3346[1222];
void O3346_init () {
	O3346[0] = + _I16OFF_3_1_3_;
	O3346[1074] = + _I16OFF_7_5_3_;
	O3346[1075] = + _I16OFF_8_6_3_;
	O3346[1106] = + _I16OFF_13_5_3_;
	O3346[1107] = + _I16OFF_16_7_3_;
	O3346[1108] = + _I16OFF_35_9_3_;
	O3346[1109] = + _I16OFF_42_12_3_;
	O3346[1110] = + _I16OFF_37_9_3_;
	O3346[1111] = + _I16OFF_46_12_3_;
	O3346[1112] = + _I16OFF_37_9_3_;
	O3346[1113] = + _I16OFF_38_9_3_;
	O3346[1114] = + _I16OFF_37_9_3_;
	O3346[1115] = + _I16OFF_47_12_3_;
	O3346[1116] = + _I16OFF_49_12_3_;
	O3346[1117] = + _I16OFF_47_12_3_;
	{long i; for (i = 1118; i < 1121; i++) O3346[i] = + _I16OFF_39_10_3_;}
	{long i; for (i = 1121; i < 1124; i++) O3346[i] = + _I16OFF_49_13_3_;}
	{long i; for (i = 1124; i < 1128; i++) O3346[i] = + _I16OFF_39_10_3_;}
	O3346[1128] = + _I16OFF_47_12_3_;
	O3346[1129] = + _I16OFF_47_14_3_;
	O3346[1130] = + _I16OFF_50_13_3_;
	O3346[1131] = + _I16OFF_53_13_3_;
	O3346[1132] = + _I16OFF_49_13_3_;
	O3346[1133] = + _I16OFF_51_13_3_;
	{long i; for (i = 1134; i < 1136; i++) O3346[i] = + _I16OFF_49_14_3_;}
	O3346[1136] = + _I16OFF_59_21_3_;
	O3346[1137] = + _I16OFF_59_23_3_;
	O3346[1138] = + _I16OFF_65_25_3_;
	O3346[1139] = + _I16OFF_68_26_3_;
	O3346[1140] = + _I16OFF_35_9_3_;
	O3346[1141] = + _I16OFF_43_9_3_;
	O3346[1142] = + _I16OFF_37_9_3_;
	O3346[1143] = + _I16OFF_37_10_3_;
	O3346[1144] = + _I16OFF_35_9_3_;
	{long i; for (i = 1145; i < 1149; i++) O3346[i] = + _I16OFF_37_9_3_;}
	O3346[1149] = + _I16OFF_37_10_3_;
	{long i; for (i = 1150; i < 1152; i++) O3346[i] = + _I16OFF_36_9_3_;}
	O3346[1152] = + _I16OFF_40_12_3_;
	O3346[1153] = + _I16OFF_37_9_3_;
	O3346[1154] = + _I16OFF_41_9_3_;
	O3346[1155] = + _I16OFF_37_9_3_;
	{long i; for (i = 1156; i < 1159; i++) O3346[i] = + _I16OFF_35_9_3_;}
	{long i; for (i = 1159; i < 1163; i++) O3346[i] = + _I16OFF_36_9_3_;}
	O3346[1163] = + _I16OFF_42_13_3_;
	O3346[1164] = + _I16OFF_45_16_3_;
	O3346[1165] = + _I16OFF_58_14_3_;
	O3346[1166] = + _I16OFF_51_13_3_;
	{long i; for (i = 1167; i < 1169; i++) O3346[i] = + _I16OFF_44_13_3_;}
	{long i; for (i = 1169; i < 1171; i++) O3346[i] = + _I16OFF_44_14_3_;}
	O3346[1171] = + _I16OFF_50_13_3_;
	O3346[1172] = + _I16OFF_51_14_3_;
	{long i; for (i = 1173; i < 1176; i++) O3346[i] = + _I16OFF_42_13_3_;}
	O3346[1176] = + _I16OFF_43_13_3_;
	O3346[1177] = + _I16OFF_44_15_3_;
	O3346[1178] = + _I16OFF_51_18_3_;
	O3346[1179] = + _I16OFF_46_14_3_;
	O3346[1180] = + _I16OFF_59_16_3_;
	{long i; for (i = 1181; i < 1186; i++) O3346[i] = + _I16OFF_46_14_3_;}
	O3346[1186] = + _I16OFF_16_5_3_;
	O3346[1187] = + _I16OFF_18_5_3_;
	O3346[1188] = + _I16OFF_23_5_3_;
	O3346[1189] = + _I16OFF_16_5_3_;
	{long i; for (i = 1190; i < 1192; i++) O3346[i] = + _I16OFF_20_5_3_;}
	{long i; for (i = 1192; i < 1194; i++) O3346[i] = + _I16OFF_25_6_3_;}
	{long i; for (i = 1194; i < 1196; i++) O3346[i] = + _I16OFF_21_7_3_;}
	{long i; for (i = 1196; i < 1200; i++) O3346[i] = + _I16OFF_17_6_3_;}
	O3346[1200] = + _I16OFF_18_6_3_;
	O3346[1201] = + _I16OFF_23_8_3_;
	{long i; for (i = 1202; i < 1204; i++) O3346[i] = + _I16OFF_23_9_3_;}
	O3346[1204] = + _I16OFF_24_9_3_;
	O3346[1205] = + _I16OFF_26_8_3_;
	O3346[1206] = + _I16OFF_19_5_3_;
	O3346[1207] = + _I16OFF_22_5_3_;
	{long i; for (i = 1208; i < 1210; i++) O3346[i] = + _I16OFF_21_10_3_;}
	{long i; for (i = 1210; i < 1212; i++) O3346[i] = + _I16OFF_29_14_3_;}
	O3346[1213] = + _I16OFF_36_10_3_;
	O3346[1216] = + _I16OFF_36_9_3_;
	O3346[1218] = + _I16OFF_48_19_3_;
	O3346[1221] = + _I16OFF_48_18_3_;
}

long O3348[1221];
void O3348_init () {
	O3348[0] = 0;
	{long i; for (i = 1107; i < 1109; i++) O3348[i] =  + _REFACS_9_;}
	{long i; for (i = 1109; i < 1112; i++) O3348[i] =  + _REFACS_10_;}
	O3348[1112] =  + _REFACS_11_;
	{long i; for (i = 1113; i < 1115; i++) O3348[i] =  + _REFACS_10_;}
	O3348[1115] =  + _REFACS_11_;
	O3348[1116] =  + _REFACS_10_;
	{long i; for (i = 1117; i < 1127; i++) O3348[i] =  + _REFACS_11_;}
	{long i; for (i = 1127; i < 1129; i++) O3348[i] =  + _REFACS_15_;}
	{long i; for (i = 1129; i < 1131; i++) O3348[i] =  + _REFACS_18_;}
	{long i; for (i = 1131; i < 1135; i++) O3348[i] =  + _REFACS_11_;}
	{long i; for (i = 1135; i < 1137; i++) O3348[i] =  + _REFACS_15_;}
	{long i; for (i = 1137; i < 1139; i++) O3348[i] =  + _REFACS_18_;}
	O3348[1139] =  + _REFACS_9_;
	O3348[1140] =  + _REFACS_13_;
	O3348[1141] =  + _REFACS_11_;
	O3348[1142] =  + _REFACS_10_;
	O3348[1143] =  + _REFACS_9_;
	{long i; for (i = 1144; i < 1147; i++) O3348[i] =  + _REFACS_10_;}
	{long i; for (i = 1147; i < 1149; i++) O3348[i] =  + _REFACS_11_;}
	{long i; for (i = 1149; i < 1151; i++) O3348[i] =  + _REFACS_10_;}
	O3348[1151] =  + _REFACS_13_;
	O3348[1152] =  + _REFACS_11_;
	O3348[1153] =  + _REFACS_15_;
	O3348[1154] =  + _REFACS_11_;
	{long i; for (i = 1155; i < 1158; i++) O3348[i] =  + _REFACS_9_;}
	{long i; for (i = 1158; i < 1162; i++) O3348[i] =  + _REFACS_10_;}
	O3348[1162] =  + _REFACS_9_;
	O3348[1163] =  + _REFACS_10_;
	O3348[1164] =  + _REFACS_13_;
	O3348[1165] =  + _REFACS_11_;
	O3348[1166] =  + _REFACS_9_;
	{long i; for (i = 1167; i < 1170; i++) O3348[i] =  + _REFACS_10_;}
	{long i; for (i = 1170; i < 1172; i++) O3348[i] =  + _REFACS_11_;}
	{long i; for (i = 1172; i < 1175; i++) O3348[i] =  + _REFACS_9_;}
	{long i; for (i = 1175; i < 1177; i++) O3348[i] =  + _REFACS_10_;}
	O3348[1177] =  + _REFACS_13_;
	O3348[1178] =  + _REFACS_11_;
	O3348[1179] =  + _REFACS_15_;
	O3348[1180] =  + _REFACS_11_;
	{long i; for (i = 1181; i < 1185; i++) O3348[i] =  + _REFACS_10_;}
	O3348[1212] =  + _REFACS_9_;
	O3348[1215] =  + _REFACS_9_;
	O3348[1217] =  + _REFACS_9_;
	O3348[1220] =  + _REFACS_9_;
}

long O3351[1221];
void O3351_init () {
	O3351[0] =  + _REFACS_1_;
	{long i; for (i = 1107; i < 1109; i++) O3351[i] =  + _REFACS_10_;}
	{long i; for (i = 1109; i < 1112; i++) O3351[i] =  + _REFACS_11_;}
	O3351[1112] =  + _REFACS_12_;
	{long i; for (i = 1113; i < 1115; i++) O3351[i] =  + _REFACS_11_;}
	O3351[1115] =  + _REFACS_12_;
	O3351[1116] =  + _REFACS_11_;
	{long i; for (i = 1117; i < 1127; i++) O3351[i] =  + _REFACS_12_;}
	{long i; for (i = 1127; i < 1129; i++) O3351[i] =  + _REFACS_16_;}
	{long i; for (i = 1129; i < 1131; i++) O3351[i] =  + _REFACS_19_;}
	{long i; for (i = 1131; i < 1135; i++) O3351[i] =  + _REFACS_12_;}
	{long i; for (i = 1135; i < 1137; i++) O3351[i] =  + _REFACS_16_;}
	{long i; for (i = 1137; i < 1139; i++) O3351[i] =  + _REFACS_19_;}
	O3351[1139] =  + _REFACS_10_;
	O3351[1140] =  + _REFACS_14_;
	O3351[1141] =  + _REFACS_12_;
	O3351[1142] =  + _REFACS_11_;
	O3351[1143] =  + _REFACS_10_;
	{long i; for (i = 1144; i < 1147; i++) O3351[i] =  + _REFACS_11_;}
	{long i; for (i = 1147; i < 1149; i++) O3351[i] =  + _REFACS_12_;}
	{long i; for (i = 1149; i < 1151; i++) O3351[i] =  + _REFACS_11_;}
	O3351[1151] =  + _REFACS_14_;
	O3351[1152] =  + _REFACS_12_;
	O3351[1153] =  + _REFACS_16_;
	O3351[1154] =  + _REFACS_12_;
	{long i; for (i = 1155; i < 1158; i++) O3351[i] =  + _REFACS_10_;}
	{long i; for (i = 1158; i < 1162; i++) O3351[i] =  + _REFACS_11_;}
	O3351[1162] =  + _REFACS_10_;
	O3351[1163] =  + _REFACS_11_;
	O3351[1164] =  + _REFACS_14_;
	O3351[1165] =  + _REFACS_12_;
	O3351[1166] =  + _REFACS_10_;
	{long i; for (i = 1167; i < 1170; i++) O3351[i] =  + _REFACS_11_;}
	{long i; for (i = 1170; i < 1172; i++) O3351[i] =  + _REFACS_12_;}
	{long i; for (i = 1172; i < 1175; i++) O3351[i] =  + _REFACS_10_;}
	{long i; for (i = 1175; i < 1177; i++) O3351[i] =  + _REFACS_11_;}
	O3351[1177] =  + _REFACS_14_;
	O3351[1178] =  + _REFACS_12_;
	O3351[1179] =  + _REFACS_16_;
	O3351[1180] =  + _REFACS_12_;
	{long i; for (i = 1181; i < 1185; i++) O3351[i] =  + _REFACS_11_;}
	O3351[1212] =  + _REFACS_10_;
	O3351[1215] =  + _REFACS_10_;
	O3351[1217] =  + _REFACS_10_;
	O3351[1220] =  + _REFACS_10_;
}

long O3353[1221];
void O3353_init () {
	O3353[0] =  + _REFACS_2_;
	{long i; for (i = 1107; i < 1109; i++) O3353[i] =  + _REFACS_11_;}
	{long i; for (i = 1109; i < 1112; i++) O3353[i] =  + _REFACS_12_;}
	O3353[1112] =  + _REFACS_13_;
	{long i; for (i = 1113; i < 1115; i++) O3353[i] =  + _REFACS_12_;}
	O3353[1115] =  + _REFACS_13_;
	O3353[1116] =  + _REFACS_12_;
	{long i; for (i = 1117; i < 1127; i++) O3353[i] =  + _REFACS_13_;}
	{long i; for (i = 1127; i < 1129; i++) O3353[i] =  + _REFACS_17_;}
	{long i; for (i = 1129; i < 1131; i++) O3353[i] =  + _REFACS_20_;}
	{long i; for (i = 1131; i < 1135; i++) O3353[i] =  + _REFACS_13_;}
	{long i; for (i = 1135; i < 1137; i++) O3353[i] =  + _REFACS_17_;}
	{long i; for (i = 1137; i < 1139; i++) O3353[i] =  + _REFACS_20_;}
	O3353[1139] =  + _REFACS_11_;
	O3353[1140] =  + _REFACS_15_;
	O3353[1141] =  + _REFACS_13_;
	O3353[1142] =  + _REFACS_12_;
	O3353[1143] =  + _REFACS_11_;
	{long i; for (i = 1144; i < 1147; i++) O3353[i] =  + _REFACS_12_;}
	{long i; for (i = 1147; i < 1149; i++) O3353[i] =  + _REFACS_13_;}
	{long i; for (i = 1149; i < 1151; i++) O3353[i] =  + _REFACS_12_;}
	O3353[1151] =  + _REFACS_15_;
	O3353[1152] =  + _REFACS_13_;
	O3353[1153] =  + _REFACS_17_;
	O3353[1154] =  + _REFACS_13_;
	{long i; for (i = 1155; i < 1158; i++) O3353[i] =  + _REFACS_11_;}
	{long i; for (i = 1158; i < 1162; i++) O3353[i] =  + _REFACS_12_;}
	O3353[1162] =  + _REFACS_11_;
	O3353[1163] =  + _REFACS_12_;
	O3353[1164] =  + _REFACS_15_;
	O3353[1165] =  + _REFACS_13_;
	O3353[1166] =  + _REFACS_11_;
	{long i; for (i = 1167; i < 1170; i++) O3353[i] =  + _REFACS_12_;}
	{long i; for (i = 1170; i < 1172; i++) O3353[i] =  + _REFACS_13_;}
	{long i; for (i = 1172; i < 1175; i++) O3353[i] =  + _REFACS_11_;}
	{long i; for (i = 1175; i < 1177; i++) O3353[i] =  + _REFACS_12_;}
	O3353[1177] =  + _REFACS_15_;
	O3353[1178] =  + _REFACS_13_;
	O3353[1179] =  + _REFACS_17_;
	O3353[1180] =  + _REFACS_13_;
	{long i; for (i = 1181; i < 1185; i++) O3353[i] =  + _REFACS_12_;}
	O3353[1212] =  + _REFACS_11_;
	O3353[1215] =  + _REFACS_11_;
	O3353[1217] =  + _REFACS_11_;
	O3353[1220] =  + _REFACS_11_;
}

long O3355[1221];
void O3355_init () {
	O3355[0] =  + _REFACS_3_;
	{long i; for (i = 1107; i < 1109; i++) O3355[i] =  + _REFACS_12_;}
	{long i; for (i = 1109; i < 1112; i++) O3355[i] =  + _REFACS_13_;}
	O3355[1112] =  + _REFACS_14_;
	{long i; for (i = 1113; i < 1115; i++) O3355[i] =  + _REFACS_13_;}
	O3355[1115] =  + _REFACS_14_;
	O3355[1116] =  + _REFACS_13_;
	{long i; for (i = 1117; i < 1127; i++) O3355[i] =  + _REFACS_14_;}
	{long i; for (i = 1127; i < 1129; i++) O3355[i] =  + _REFACS_18_;}
	{long i; for (i = 1129; i < 1131; i++) O3355[i] =  + _REFACS_21_;}
	{long i; for (i = 1131; i < 1135; i++) O3355[i] =  + _REFACS_14_;}
	{long i; for (i = 1135; i < 1137; i++) O3355[i] =  + _REFACS_18_;}
	{long i; for (i = 1137; i < 1139; i++) O3355[i] =  + _REFACS_21_;}
	O3355[1139] =  + _REFACS_12_;
	O3355[1140] =  + _REFACS_16_;
	O3355[1141] =  + _REFACS_14_;
	O3355[1142] =  + _REFACS_13_;
	O3355[1143] =  + _REFACS_12_;
	{long i; for (i = 1144; i < 1147; i++) O3355[i] =  + _REFACS_13_;}
	{long i; for (i = 1147; i < 1149; i++) O3355[i] =  + _REFACS_14_;}
	{long i; for (i = 1149; i < 1151; i++) O3355[i] =  + _REFACS_13_;}
	O3355[1151] =  + _REFACS_16_;
	O3355[1152] =  + _REFACS_14_;
	O3355[1153] =  + _REFACS_18_;
	O3355[1154] =  + _REFACS_14_;
	{long i; for (i = 1155; i < 1158; i++) O3355[i] =  + _REFACS_12_;}
	{long i; for (i = 1158; i < 1162; i++) O3355[i] =  + _REFACS_13_;}
	O3355[1162] =  + _REFACS_12_;
	O3355[1163] =  + _REFACS_13_;
	O3355[1164] =  + _REFACS_16_;
	O3355[1165] =  + _REFACS_14_;
	O3355[1166] =  + _REFACS_12_;
	{long i; for (i = 1167; i < 1170; i++) O3355[i] =  + _REFACS_13_;}
	{long i; for (i = 1170; i < 1172; i++) O3355[i] =  + _REFACS_14_;}
	{long i; for (i = 1172; i < 1175; i++) O3355[i] =  + _REFACS_12_;}
	{long i; for (i = 1175; i < 1177; i++) O3355[i] =  + _REFACS_13_;}
	O3355[1177] =  + _REFACS_16_;
	O3355[1178] =  + _REFACS_14_;
	O3355[1179] =  + _REFACS_18_;
	O3355[1180] =  + _REFACS_14_;
	{long i; for (i = 1181; i < 1185; i++) O3355[i] =  + _REFACS_13_;}
	O3355[1212] =  + _REFACS_12_;
	O3355[1215] =  + _REFACS_12_;
	O3355[1217] =  + _REFACS_12_;
	O3355[1220] =  + _REFACS_12_;
}

long O3357[1221];
void O3357_init () {
	O3357[0] =  + _REFACS_4_;
	{long i; for (i = 1107; i < 1109; i++) O3357[i] =  + _REFACS_13_;}
	{long i; for (i = 1109; i < 1112; i++) O3357[i] =  + _REFACS_14_;}
	O3357[1112] =  + _REFACS_15_;
	{long i; for (i = 1113; i < 1115; i++) O3357[i] =  + _REFACS_14_;}
	O3357[1115] =  + _REFACS_15_;
	O3357[1116] =  + _REFACS_14_;
	{long i; for (i = 1117; i < 1127; i++) O3357[i] =  + _REFACS_15_;}
	{long i; for (i = 1127; i < 1129; i++) O3357[i] =  + _REFACS_19_;}
	{long i; for (i = 1129; i < 1131; i++) O3357[i] =  + _REFACS_22_;}
	{long i; for (i = 1131; i < 1135; i++) O3357[i] =  + _REFACS_15_;}
	{long i; for (i = 1135; i < 1137; i++) O3357[i] =  + _REFACS_19_;}
	{long i; for (i = 1137; i < 1139; i++) O3357[i] =  + _REFACS_22_;}
	O3357[1139] =  + _REFACS_13_;
	O3357[1140] =  + _REFACS_17_;
	O3357[1141] =  + _REFACS_15_;
	O3357[1142] =  + _REFACS_14_;
	O3357[1143] =  + _REFACS_13_;
	{long i; for (i = 1144; i < 1147; i++) O3357[i] =  + _REFACS_14_;}
	{long i; for (i = 1147; i < 1149; i++) O3357[i] =  + _REFACS_15_;}
	{long i; for (i = 1149; i < 1151; i++) O3357[i] =  + _REFACS_14_;}
	O3357[1151] =  + _REFACS_17_;
	O3357[1152] =  + _REFACS_15_;
	O3357[1153] =  + _REFACS_19_;
	O3357[1154] =  + _REFACS_15_;
	{long i; for (i = 1155; i < 1158; i++) O3357[i] =  + _REFACS_13_;}
	{long i; for (i = 1158; i < 1162; i++) O3357[i] =  + _REFACS_14_;}
	O3357[1162] =  + _REFACS_13_;
	O3357[1163] =  + _REFACS_14_;
	O3357[1164] =  + _REFACS_17_;
	O3357[1165] =  + _REFACS_15_;
	O3357[1166] =  + _REFACS_13_;
	{long i; for (i = 1167; i < 1170; i++) O3357[i] =  + _REFACS_14_;}
	{long i; for (i = 1170; i < 1172; i++) O3357[i] =  + _REFACS_15_;}
	{long i; for (i = 1172; i < 1175; i++) O3357[i] =  + _REFACS_13_;}
	{long i; for (i = 1175; i < 1177; i++) O3357[i] =  + _REFACS_14_;}
	O3357[1177] =  + _REFACS_17_;
	O3357[1178] =  + _REFACS_15_;
	O3357[1179] =  + _REFACS_19_;
	O3357[1180] =  + _REFACS_15_;
	{long i; for (i = 1181; i < 1185; i++) O3357[i] =  + _REFACS_14_;}
	O3357[1212] =  + _REFACS_13_;
	O3357[1215] =  + _REFACS_13_;
	O3357[1217] =  + _REFACS_13_;
	O3357[1220] =  + _REFACS_13_;
}

long O3359[1221];
void O3359_init () {
	O3359[0] =  + _REFACS_5_;
	{long i; for (i = 1107; i < 1109; i++) O3359[i] =  + _REFACS_14_;}
	{long i; for (i = 1109; i < 1112; i++) O3359[i] =  + _REFACS_15_;}
	O3359[1112] =  + _REFACS_16_;
	{long i; for (i = 1113; i < 1115; i++) O3359[i] =  + _REFACS_15_;}
	O3359[1115] =  + _REFACS_16_;
	O3359[1116] =  + _REFACS_15_;
	{long i; for (i = 1117; i < 1127; i++) O3359[i] =  + _REFACS_16_;}
	{long i; for (i = 1127; i < 1129; i++) O3359[i] =  + _REFACS_20_;}
	{long i; for (i = 1129; i < 1131; i++) O3359[i] =  + _REFACS_23_;}
	{long i; for (i = 1131; i < 1135; i++) O3359[i] =  + _REFACS_16_;}
	{long i; for (i = 1135; i < 1137; i++) O3359[i] =  + _REFACS_20_;}
	{long i; for (i = 1137; i < 1139; i++) O3359[i] =  + _REFACS_23_;}
	O3359[1139] =  + _REFACS_14_;
	O3359[1140] =  + _REFACS_18_;
	O3359[1141] =  + _REFACS_16_;
	O3359[1142] =  + _REFACS_15_;
	O3359[1143] =  + _REFACS_14_;
	{long i; for (i = 1144; i < 1147; i++) O3359[i] =  + _REFACS_15_;}
	{long i; for (i = 1147; i < 1149; i++) O3359[i] =  + _REFACS_16_;}
	{long i; for (i = 1149; i < 1151; i++) O3359[i] =  + _REFACS_15_;}
	O3359[1151] =  + _REFACS_18_;
	O3359[1152] =  + _REFACS_16_;
	O3359[1153] =  + _REFACS_20_;
	O3359[1154] =  + _REFACS_16_;
	{long i; for (i = 1155; i < 1158; i++) O3359[i] =  + _REFACS_14_;}
	{long i; for (i = 1158; i < 1162; i++) O3359[i] =  + _REFACS_15_;}
	O3359[1162] =  + _REFACS_14_;
	O3359[1163] =  + _REFACS_15_;
	O3359[1164] =  + _REFACS_18_;
	O3359[1165] =  + _REFACS_16_;
	O3359[1166] =  + _REFACS_14_;
	{long i; for (i = 1167; i < 1170; i++) O3359[i] =  + _REFACS_15_;}
	{long i; for (i = 1170; i < 1172; i++) O3359[i] =  + _REFACS_16_;}
	{long i; for (i = 1172; i < 1175; i++) O3359[i] =  + _REFACS_14_;}
	{long i; for (i = 1175; i < 1177; i++) O3359[i] =  + _REFACS_15_;}
	O3359[1177] =  + _REFACS_18_;
	O3359[1178] =  + _REFACS_16_;
	O3359[1179] =  + _REFACS_20_;
	O3359[1180] =  + _REFACS_16_;
	{long i; for (i = 1181; i < 1185; i++) O3359[i] =  + _REFACS_15_;}
	O3359[1212] =  + _REFACS_14_;
	O3359[1215] =  + _REFACS_14_;
	O3359[1217] =  + _REFACS_14_;
	O3359[1220] =  + _REFACS_14_;
}

long O3361[1221];
void O3361_init () {
	O3361[0] =  + _REFACS_6_;
	{long i; for (i = 1107; i < 1109; i++) O3361[i] =  + _REFACS_15_;}
	{long i; for (i = 1109; i < 1112; i++) O3361[i] =  + _REFACS_16_;}
	O3361[1112] =  + _REFACS_17_;
	{long i; for (i = 1113; i < 1115; i++) O3361[i] =  + _REFACS_16_;}
	O3361[1115] =  + _REFACS_17_;
	O3361[1116] =  + _REFACS_16_;
	{long i; for (i = 1117; i < 1127; i++) O3361[i] =  + _REFACS_17_;}
	{long i; for (i = 1127; i < 1129; i++) O3361[i] =  + _REFACS_21_;}
	{long i; for (i = 1129; i < 1131; i++) O3361[i] =  + _REFACS_24_;}
	{long i; for (i = 1131; i < 1135; i++) O3361[i] =  + _REFACS_17_;}
	{long i; for (i = 1135; i < 1137; i++) O3361[i] =  + _REFACS_21_;}
	{long i; for (i = 1137; i < 1139; i++) O3361[i] =  + _REFACS_24_;}
	O3361[1139] =  + _REFACS_15_;
	O3361[1140] =  + _REFACS_19_;
	O3361[1141] =  + _REFACS_17_;
	O3361[1142] =  + _REFACS_16_;
	O3361[1143] =  + _REFACS_15_;
	{long i; for (i = 1144; i < 1147; i++) O3361[i] =  + _REFACS_16_;}
	{long i; for (i = 1147; i < 1149; i++) O3361[i] =  + _REFACS_17_;}
	{long i; for (i = 1149; i < 1151; i++) O3361[i] =  + _REFACS_16_;}
	O3361[1151] =  + _REFACS_19_;
	O3361[1152] =  + _REFACS_17_;
	O3361[1153] =  + _REFACS_21_;
	O3361[1154] =  + _REFACS_17_;
	{long i; for (i = 1155; i < 1158; i++) O3361[i] =  + _REFACS_15_;}
	{long i; for (i = 1158; i < 1162; i++) O3361[i] =  + _REFACS_16_;}
	O3361[1162] =  + _REFACS_15_;
	O3361[1163] =  + _REFACS_16_;
	O3361[1164] =  + _REFACS_19_;
	O3361[1165] =  + _REFACS_17_;
	O3361[1166] =  + _REFACS_15_;
	{long i; for (i = 1167; i < 1170; i++) O3361[i] =  + _REFACS_16_;}
	{long i; for (i = 1170; i < 1172; i++) O3361[i] =  + _REFACS_17_;}
	{long i; for (i = 1172; i < 1175; i++) O3361[i] =  + _REFACS_15_;}
	{long i; for (i = 1175; i < 1177; i++) O3361[i] =  + _REFACS_16_;}
	O3361[1177] =  + _REFACS_19_;
	O3361[1178] =  + _REFACS_17_;
	O3361[1179] =  + _REFACS_21_;
	O3361[1180] =  + _REFACS_17_;
	{long i; for (i = 1181; i < 1185; i++) O3361[i] =  + _REFACS_16_;}
	O3361[1212] =  + _REFACS_15_;
	O3361[1215] =  + _REFACS_15_;
	O3361[1217] =  + _REFACS_15_;
	O3361[1220] =  + _REFACS_15_;
}

long O3363[1221];
void O3363_init () {
	O3363[0] =  + _REFACS_7_;
	{long i; for (i = 1107; i < 1109; i++) O3363[i] =  + _REFACS_16_;}
	{long i; for (i = 1109; i < 1112; i++) O3363[i] =  + _REFACS_17_;}
	O3363[1112] =  + _REFACS_18_;
	{long i; for (i = 1113; i < 1115; i++) O3363[i] =  + _REFACS_17_;}
	O3363[1115] =  + _REFACS_18_;
	O3363[1116] =  + _REFACS_17_;
	{long i; for (i = 1117; i < 1127; i++) O3363[i] =  + _REFACS_18_;}
	{long i; for (i = 1127; i < 1129; i++) O3363[i] =  + _REFACS_22_;}
	{long i; for (i = 1129; i < 1131; i++) O3363[i] =  + _REFACS_25_;}
	{long i; for (i = 1131; i < 1135; i++) O3363[i] =  + _REFACS_18_;}
	{long i; for (i = 1135; i < 1137; i++) O3363[i] =  + _REFACS_22_;}
	{long i; for (i = 1137; i < 1139; i++) O3363[i] =  + _REFACS_25_;}
	O3363[1139] =  + _REFACS_16_;
	O3363[1140] =  + _REFACS_20_;
	O3363[1141] =  + _REFACS_18_;
	O3363[1142] =  + _REFACS_17_;
	O3363[1143] =  + _REFACS_16_;
	{long i; for (i = 1144; i < 1147; i++) O3363[i] =  + _REFACS_17_;}
	{long i; for (i = 1147; i < 1149; i++) O3363[i] =  + _REFACS_18_;}
	{long i; for (i = 1149; i < 1151; i++) O3363[i] =  + _REFACS_17_;}
	O3363[1151] =  + _REFACS_20_;
	O3363[1152] =  + _REFACS_18_;
	O3363[1153] =  + _REFACS_22_;
	O3363[1154] =  + _REFACS_18_;
	{long i; for (i = 1155; i < 1158; i++) O3363[i] =  + _REFACS_16_;}
	{long i; for (i = 1158; i < 1162; i++) O3363[i] =  + _REFACS_17_;}
	O3363[1162] =  + _REFACS_16_;
	O3363[1163] =  + _REFACS_17_;
	O3363[1164] =  + _REFACS_20_;
	O3363[1165] =  + _REFACS_18_;
	O3363[1166] =  + _REFACS_16_;
	{long i; for (i = 1167; i < 1170; i++) O3363[i] =  + _REFACS_17_;}
	{long i; for (i = 1170; i < 1172; i++) O3363[i] =  + _REFACS_18_;}
	{long i; for (i = 1172; i < 1175; i++) O3363[i] =  + _REFACS_16_;}
	{long i; for (i = 1175; i < 1177; i++) O3363[i] =  + _REFACS_17_;}
	O3363[1177] =  + _REFACS_20_;
	O3363[1178] =  + _REFACS_18_;
	O3363[1179] =  + _REFACS_22_;
	O3363[1180] =  + _REFACS_18_;
	{long i; for (i = 1181; i < 1185; i++) O3363[i] =  + _REFACS_17_;}
	O3363[1212] =  + _REFACS_16_;
	O3363[1215] =  + _REFACS_16_;
	O3363[1217] =  + _REFACS_16_;
	O3363[1220] =  + _REFACS_16_;
}


#ifdef __cplusplus
}
#endif
