
#ifndef _C15_ev707_
#define _C15_ev707_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1355_13196(EIF_REFERENCE);
extern void EIF_Minit707(void);
extern EIF_REFERENCE F1363_13320(EIF_REFERENCE);
extern long O8598[];

#ifdef __cplusplus
}
#endif

#endif
