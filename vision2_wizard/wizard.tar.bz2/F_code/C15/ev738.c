/*
 * Code for class EV_DRAWABLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev738.h"
#include <ev_gtk.h>
#include <cairo.h>
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F35_637
static void inline_F35_637 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	double len = 2.0;
if (arg2) {
	cairo_set_dash ((cairo_t *) arg1, &len, 1, 0.0);
} else {
	cairo_set_dash ((cairo_t *) arg1, NULL, 0, 0.0);
}
	;
}
#define INLINE_F35_637
#endif
#ifndef INLINE_F35_588
static EIF_NATURAL_32 inline_F35_588 (EIF_POINTER arg1)
{
	return (EIF_NATURAL_32) (cairo_get_reference_count((cairo_t*) arg1))
	;
}
#define INLINE_F35_588
#endif
#ifndef INLINE_F114_1764
static EIF_POINTER inline_F114_1764 (EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_new ((GdkColorspace) arg1, (gboolean) arg2, (int) arg3, (int) arg4, (int) arg5);
	;
}
#define INLINE_F114_1764
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DRAWABLE_IMP}.init_default_values */
void F1386_13589 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("init_default_values", 1385, Current, 1, 0, 19247);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10327[dtype-1386])(Current);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R10319[dtype-1386])(Current, ((EIF_INTEGER_32) 1L));
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R10320[dtype-1386])(Current, ((EIF_INTEGER_32) 0L));
	RTHOOK(4);
	loc1 = *(EIF_POINTER *)(Current + O10407[dtype-1385]);
	RTHOOK(5);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		RTHOOK(6);
		cairo_set_antialias((cairo_t*) loc1, (cairo_antialias_t) ((EIF_INTEGER_8) 1L));
		RTHOOK(7);
		cairo_set_line_cap((cairo_t*) loc1, (cairo_line_cap_t) ((EIF_INTEGER_8) 0L));
	}
	RTHOOK(8);
	*(EIF_INTEGER_8 *)(Current + O10415[dtype-1385]) = (EIF_INTEGER_8) ((EIF_INTEGER_8) 1L);
	RTHOOK(9);
	*(EIF_INTEGER_8 *)(Current + O10416[dtype-1385]) = (EIF_INTEGER_8) ((EIF_INTEGER_8) 0L);
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.get_new_cairo_context */
void F1386_13594 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_new_cairo_context", 1385, Current, 0, 0, 19252);
	RTGC;
	RTHOOK(1);
	F1386_13660(Current);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10410[Dtype(Current)-1386])(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.foreground_color_internal */
EIF_REFERENCE F1386_13603 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("foreground_color_internal", 1385, Current, 4, 0, 19255);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O10440[Dtype(Current)-1385]);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTHOOK(2);
		loc1 = F1096_9438(loc4);
		RTHOOK(3);
		loc2 = F1096_9439(loc4);
		RTHOOK(4);
		loc3 = F1096_9440(loc4);
	}
	RTHOOK(5);
	tr1 = RTLNS(eif_new_type(1095, 0x00).id, 1095, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1096_9421(RTCW(tr1), loc1, loc2, loc3);
	RTHOOK(6);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {EV_DRAWABLE_IMP}.background_color_internal */
EIF_REFERENCE F1386_13604 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("background_color_internal", 1385, Current, 4, 0, 19256);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O10441[Dtype(Current)-1385]);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTHOOK(2);
		loc1 = F1096_9438(loc4);
		RTHOOK(3);
		loc2 = F1096_9439(loc4);
		RTHOOK(4);
		loc3 = F1096_9440(loc4);
	} else {
		RTHOOK(5);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 255L);
		RTHOOK(6);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 255L);
		RTHOOK(7);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 255L);
	}
	RTHOOK(8);
	tr1 = RTLNS(eif_new_type(1095, 0x00).id, 1095, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1096_9421(RTCW(tr1), loc1, loc2, loc3);
	RTHOOK(9);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {EV_DRAWABLE_IMP}.line_width */
EIF_INTEGER_32 F1386_13605 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O10449[Dtype(Current)-1385]);
}


/* {EV_DRAWABLE_IMP}.drawing_mode */
EIF_INTEGER_32 F1386_13606 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O10448[Dtype(Current)-1385]);
}


/* {EV_DRAWABLE_IMP}.tile */
EIF_REFERENCE F1386_13610 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O10447[Dtype(Current)-1385]);
}


/* {EV_DRAWABLE_IMP}.dashed_line_style */
EIF_BOOLEAN F1386_13611 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O10446[Dtype(Current)-1385]);
}


/* {EV_DRAWABLE_IMP}.set_font */
void F1386_13612 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("set_font", 1385, Current, 1, 1, 19264);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1217, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O10445[Dtype(Current)-1385]) = (EIF_REFERENCE) loc1;
	} else {
		
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.set_background_color */
void F1386_13613 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("set_background_color", 1385, Current, 1, 1, 19265);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O10441[dtype-1385]);
	loc1 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = RTLNSMART(eif_new_type(1095, 0).id);
		ti4_1 = F1096_9438(RTCW(arg1));
		ti4_2 = F1096_9439(RTCW(arg1));
		ti4_3 = F1096_9440(RTCW(arg1));
		F1096_9421(RTCW(tr1), ti4_1, ti4_2, ti4_3);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O10441[dtype-1385]) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(3);
		tb1 = F1096_9452(loc1, arg1);
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(4);
			ti4_1 = F1096_9438(RTCW(arg1));
			F1096_9441(loc1, ti4_1);
			RTHOOK(5);
			ti4_1 = F1096_9439(RTCW(arg1));
			F1096_9442(loc1, ti4_1);
			RTHOOK(6);
			ti4_1 = F1096_9440(RTCW(arg1));
			F1096_9443(loc1, ti4_1);
		}
	}
	RTHOOK(7);
	tr4_1 = F1096_9423(RTCW(arg1));
	tr8_1 = (EIF_REAL_64) (tr4_1);
	tr4_1 = F1096_9424(RTCW(arg1));
	tr8_2 = (EIF_REAL_64) (tr4_1);
	tr4_1 = F1096_9425(RTCW(arg1));
	tr8_3 = (EIF_REAL_64) (tr4_1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64)) R10437[dtype-1386])(Current, (EIF_BOOLEAN) 0, tr8_1, tr8_2, tr8_3);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.set_foreground_color */
void F1386_13614 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("set_foreground_color", 1385, Current, 1, 1, 19266);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O10440[dtype-1385]);
	loc1 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = RTLNSMART(eif_new_type(1095, 0).id);
		ti4_1 = F1096_9438(RTCW(arg1));
		ti4_2 = F1096_9439(RTCW(arg1));
		ti4_3 = F1096_9440(RTCW(arg1));
		F1096_9421(RTCW(tr1), ti4_1, ti4_2, ti4_3);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O10440[dtype-1385]) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(3);
		tb1 = F1096_9452(loc1, arg1);
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(4);
			ti4_1 = F1096_9438(RTCW(arg1));
			F1096_9441(loc1, ti4_1);
			RTHOOK(5);
			ti4_1 = F1096_9439(RTCW(arg1));
			F1096_9442(loc1, ti4_1);
			RTHOOK(6);
			ti4_1 = F1096_9440(RTCW(arg1));
			F1096_9443(loc1, ti4_1);
		}
	}
	RTHOOK(7);
	tr4_1 = F1096_9423(RTCW(arg1));
	tr8_1 = (EIF_REAL_64) (tr4_1);
	tr4_1 = F1096_9424(RTCW(arg1));
	tr8_2 = (EIF_REAL_64) (tr4_1);
	tr4_1 = F1096_9425(RTCW(arg1));
	tr8_3 = (EIF_REAL_64) (tr4_1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64)) R10437[dtype-1386])(Current, (EIF_BOOLEAN) 1, tr8_1, tr8_2, tr8_3);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.set_line_width */
void F1386_13615 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REAL_64 tr8_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_line_width", 1385, Current, 0, 1, 19267);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O10407[dtype-1385]) != tp1)) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current + O10407[dtype-1385]);
		tr8_1 = (EIF_REAL_64) (arg1);
		cairo_set_line_width((cairo_t*) tp1, (double) tr8_1);
	}
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current + O10449[dtype-1385]) = (EIF_INTEGER_32) arg1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.set_drawing_mode */
void F1386_13616 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_8 ti1_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_drawing_mode", 1385, Current, 0, 1, 19268);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O10407[dtype-1385]) != tp1)) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current + O10407[dtype-1385]);
		ti1_1 = F1386_13617(Current, arg1);
		cairo_set_operator((cairo_t*) tp1, (cairo_operator_t) ti1_1);
	}
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current + O10448[dtype-1385]) = (EIF_INTEGER_32) arg1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.cairo_drawing_mode */
EIF_INTEGER_8 F1386_13617 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("cairo_drawing_mode", 1385, Current, 0, 1, 19269);
	RTGC;
	RTHOOK(1);
	switch (arg1) {
		case 0L:
			RTHOOK(2);
			Result = (EIF_INTEGER_8) CAIRO_OPERATOR_OVER;
			break;
		case 3L:
			RTHOOK(3);
			Result = (EIF_INTEGER_8) CAIRO_OPERATOR_MULTIPLY;
			break;
		case 1L:
			RTHOOK(4);
			Result = (EIF_INTEGER_8) CAIRO_OPERATOR_DIFFERENCE;
			break;
		case 2L:
			RTHOOK(5);
			Result = (EIF_INTEGER_8) CAIRO_OPERATOR_EXCLUSION;
			break;
		case 4L:
			RTHOOK(6);
			Result = (EIF_INTEGER_8) CAIRO_OPERATOR_ATOP;
			break;
		default:
			
			break;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DRAWABLE_IMP}.enable_dashed_line_style */
void F1386_13623 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("enable_dashed_line_style", 1385, Current, 0, 0, 19275);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O10446[dtype-1385]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O10407[dtype-1385]) != tp1)) {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current + O10407[dtype-1385]);
		inline_F35_637(tp1, (EIF_BOOLEAN) 1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.disable_dashed_line_style */
void F1386_13624 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("disable_dashed_line_style", 1385, Current, 0, 0, 19276);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O10446[dtype-1385]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O10407[dtype-1385]) != tp1)) {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current + O10407[dtype-1385]);
		inline_F35_637(tp1, (EIF_BOOLEAN) 0);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.set_background_transparency */
void F1386_13626 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_background_transparency", 1385, Current, 0, 1, 19278);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O10420[dtype-1385]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	*(EIF_REAL_64 *)(Current + O10421[dtype-1385]) = (EIF_REAL_64) arg1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.clear */
void F1386_13630 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("clear", 1385, Current, 0, 0, 19282);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10311[dtype-1386])(Current);
	ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10312[dtype-1386])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R10336[dtype-1386])(Current, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.clear_rectangle */
void F1386_13631 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_64 tr8_4;
	EIF_REAL_32 tr4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("clear_rectangle", 1385, Current, 3, 4, 19283);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg3 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg4 > ((EIF_INTEGER_32) 0L)))) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10412[dtype-1386])(Current);
		RTHOOK(3);
		loc1 = *(EIF_POINTER *)(Current + O10407[dtype-1385]);
		RTHOOK(4);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc1 != tp1)) {
			RTHOOK(5);
			loc2 = F1245_11644(Current);
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current + O10441[dtype-1385]);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				RTHOOK(7);
				if (*(EIF_BOOLEAN *)(Current + O10420[dtype-1385])) {
					RTHOOK(8);
					tr4_1 = F1096_9423(loc3);
					tr8_1 = (EIF_REAL_64) (tr4_1);
					tr4_1 = F1096_9424(loc3);
					tr8_2 = (EIF_REAL_64) (tr4_1);
					tr4_1 = F1096_9425(loc3);
					tr8_3 = (EIF_REAL_64) (tr4_1);
					tr8_4 = *(EIF_REAL_64 *)(Current + O10421[dtype-1385]);
					cairo_set_source_rgba((cairo_t*) loc1, (double) tr8_1, (double) tr8_2, (double) tr8_3, (double) tr8_4);
				} else {
					RTHOOK(9);
					tr4_1 = F1096_9423(loc3);
					tr8_1 = (EIF_REAL_64) (tr4_1);
					tr4_1 = F1096_9424(loc3);
					tr8_2 = (EIF_REAL_64) (tr4_1);
					tr4_1 = F1096_9425(loc3);
					tr8_3 = (EIF_REAL_64) (tr4_1);
					cairo_set_source_rgb((cairo_t*) loc1, (double) tr8_1, (double) tr8_2, (double) tr8_3);
				}
			} else {
				RTHOOK(10);
				if (*(EIF_BOOLEAN *)(Current + O10420[dtype-1385])) {
					RTHOOK(11);
					tr8_1 = *(EIF_REAL_64 *)(Current + O10421[dtype-1385]);
					cairo_set_source_rgba((cairo_t*) loc1, (double) (EIF_REAL_64) 1.0, (double) (EIF_REAL_64) 1.0, (double) (EIF_REAL_64) 1.0, (double) tr8_1);
				} else {
					RTHOOK(12);
					cairo_set_source_rgb((cairo_t*) loc1, (double) (EIF_REAL_64) 1.0, (double) (EIF_REAL_64) 1.0, (double) (EIF_REAL_64) 1.0);
				}
			}
			RTHOOK(13);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R10353[dtype-1386])(Current, arg1, arg2, arg3, arg4);
			RTHOOK(14);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTHOOK(15);
				tr4_1 = F1096_9423(RTCW(loc2));
				tr8_1 = (EIF_REAL_64) (tr4_1);
				tr4_1 = F1096_9424(RTCW(loc2));
				tr8_2 = (EIF_REAL_64) (tr4_1);
				tr4_1 = F1096_9425(RTCW(loc2));
				tr8_3 = (EIF_REAL_64) (tr4_1);
				cairo_set_source_rgb((cairo_t*) loc1, (double) tr8_1, (double) tr8_2, (double) tr8_3);
			}
			
		}
		RTHOOK(17);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10413[dtype-1386])(Current);
	}
	RTHOOK(18);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.draw_point */
void F1386_13632 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	
	
	RTEAA("draw_point", 1385, Current, 0, 2, 19284);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R10343[Dtype(Current)-1386])(Current, arg1, arg2, (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
	RTHOOK(2);
	RTEE;
}

/* {EV_DRAWABLE_IMP}.draw_segment */
void F1386_13640 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("draw_segment", 1385, Current, 1, 4, 19292);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10412[dtype-1386])(Current);
	RTHOOK(2);
	loc1 = *(EIF_POINTER *)(Current + O10407[dtype-1385]);
	RTHOOK(3);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		RTHOOK(4);
		tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg1 + (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10435[dtype-1386])(Current)));
		tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg2 + (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10436[dtype-1386])(Current)));
		cairo_move_to((cairo_t*) loc1, (double) (EIF_REAL_64) (tr8_1 + (EIF_REAL_64) 0.5), (double) (EIF_REAL_64) (tr8_2 + (EIF_REAL_64) 0.5));
		RTHOOK(5);
		tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg3 + (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10435[dtype-1386])(Current)));
		tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg4 + (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10436[dtype-1386])(Current)));
		cairo_line_to((cairo_t*) loc1, (double) (EIF_REAL_64) (tr8_1 + (EIF_REAL_64) 0.5), (double) (EIF_REAL_64) (tr8_2 + (EIF_REAL_64) 0.5));
		RTHOOK(6);
		cairo_stroke((cairo_t*) loc1);
	}
	RTHOOK(7);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10413[dtype-1386])(Current);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.draw_pixmap */
void F1386_13644 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg3);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("draw_pixmap", 1385, Current, 0, 3, 19296);
	RTGC;
	RTHOOK(1);
	ti4_1 = F1114_9697(RTCW(arg3));
	ti4_2 = F1114_9698(RTCW(arg3));
	F1386_13645(Current, arg1, arg2, arg3, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.draw_full_pixmap */
void F1386_13645 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_64 tr8_4;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("draw_full_pixmap", 1385, Current, 2, 7, 19297);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_3_);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1389, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10412[dtype-1386])(Current);
		RTHOOK(3);
		loc1 = *(EIF_POINTER *)(Current + O10407[dtype-1385]);
		RTHOOK(4);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc1 != tp1)) {
			RTHOOK(5);
			tp1 = *(EIF_POINTER *)(Current + O10407[dtype-1385]);
			cairo_save((cairo_t*) tp1);
			RTHOOK(6);
			tp1 = *(EIF_POINTER *)(loc2+ _PTROFF_48_18_10_9_0_2_);
			tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg1 - arg4));
			tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg2 - arg5));
			cairo_set_source_surface((cairo_t*) loc1, (cairo_surface_t*) tp1, (double) tr8_1, (double) tr8_2);
			RTHOOK(7);
			tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg1 + (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10435[dtype-1386])(Current)));
			tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg2 + (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10436[dtype-1386])(Current)));
			tr8_3 = (EIF_REAL_64) (arg6);
			tr8_4 = (EIF_REAL_64) (arg7);
			cairo_rectangle((cairo_t*) loc1, (double) (EIF_REAL_64) (tr8_1 + (EIF_REAL_64) 0.5), (double) (EIF_REAL_64) (tr8_2 + (EIF_REAL_64) 0.5), (double) tr8_3, (double) tr8_4);
			RTHOOK(8);
			tr1 = RTLNS(eif_new_type(34, 0x00).id, 34, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F35_640(RTCW(tr1), loc1);
			RTHOOK(9);
			tp1 = *(EIF_POINTER *)(Current + O10407[dtype-1385]);
			cairo_restore((cairo_t*) tp1);
		}
		RTHOOK(10);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10413[dtype-1386])(Current);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.draw_ellipse */
void F1386_13649 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("draw_ellipse", 1385, Current, 0, 4, 19301);
	RTGC;
	RTHOOK(1);
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
	tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 2L));
	F1386_13650(Current, arg1, arg2, arg3, arg4, tr8_1, (EIF_REAL_64) (tr8_2 * 3.1415926535897931), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.draw_ellipse_internal */
void F1386_13650 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_BOOLEAN arg7, EIF_BOOLEAN arg8)
{
	GTCX
	RTEX;
	EIF_REAL_64 loc1 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc2 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc3 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc4 = (EIF_REAL_64) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_POINTER loc6 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("draw_ellipse_internal", 1385, Current, 6, 8, 19302);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg3 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg4 > ((EIF_INTEGER_32) 0L)))) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10412[dtype-1386])(Current);
		RTHOOK(3);
		loc6 = *(EIF_POINTER *)(Current + O10407[dtype-1385]);
		RTHOOK(4);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc6 != tp1)) {
			RTHOOK(5);
			loc5 = '\0';
			if (arg7) {
				tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 2L));
				loc5 = (EIF_BOOLEAN) !eif_is_equal_real_64 (arg6, (EIF_REAL_64) (tr8_1 * 3.1415926535897931));
			}
			RTHOOK(6);
			loc1 = (EIF_REAL_64) (arg1);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10435[dtype-1386])(Current);
			tr8_1 = (EIF_REAL_64) (ti4_1);
			loc1 = (EIF_REAL_64) (EIF_REAL_64) ((EIF_REAL_64) (loc1 + (EIF_REAL_64) ((EIF_REAL_64) (arg3) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L)))) + tr8_1);
			RTHOOK(7);
			loc2 = (EIF_REAL_64) (arg2);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10436[dtype-1386])(Current);
			tr8_1 = (EIF_REAL_64) (ti4_1);
			loc2 = (EIF_REAL_64) (EIF_REAL_64) ((EIF_REAL_64) (loc2 + (EIF_REAL_64) ((EIF_REAL_64) (arg4) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L)))) + tr8_1);
			RTHOOK(8);
			loc3 = (EIF_REAL_64) (EIF_REAL_64) ((EIF_REAL_64) (arg3) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L)));
			RTHOOK(9);
			if ((EIF_BOOLEAN)(arg3 != arg4)) {
				RTHOOK(10);
				loc4 = (EIF_REAL_64) (EIF_REAL_64) ((EIF_REAL_64) (arg4) /  (EIF_REAL_64) (arg3));
				RTHOOK(11);
				cairo_scale((cairo_t*) loc6, (double) (EIF_REAL_64) 1.0, (double) loc4);
				RTHOOK(12);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10436[dtype-1386])(Current);
				tr8_1 = (EIF_REAL_64) (ti4_1);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10436[dtype-1386])(Current);
				tr8_2 = (EIF_REAL_64) (ti4_1);
				loc2 = (EIF_REAL_64) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (loc2 - tr8_1)) /  (EIF_REAL_64) (loc4)) + tr8_2);
			}
			RTHOOK(13);
			if (loc5) {
				RTHOOK(14);
				cairo_move_to((cairo_t*) loc6, (double) loc1, (double) loc2);
			}
			RTHOOK(15);
			cairo_arc_negative((cairo_t*) loc6, (double) loc1, (double) loc2, (double) loc3, (double) (EIF_REAL_64) -arg5, (double) (EIF_REAL_64) -(EIF_REAL_64) (arg5 + arg6));
			RTHOOK(16);
			if (arg8) {
				RTHOOK(17);
				cairo_stroke_preserve((cairo_t*) loc6);
				RTHOOK(18);
				tr1 = RTLNS(eif_new_type(34, 0x00).id, 34, _OBJSIZ_0_0_0_0_0_0_0_0_);
				F35_640(RTCW(tr1), loc6);
			}
			RTHOOK(19);
			if (loc5) {
				RTHOOK(20);
				cairo_close_path((cairo_t*) loc6);
			}
			RTHOOK(21);
			cairo_stroke((cairo_t*) loc6);
			RTHOOK(22);
			if ((EIF_BOOLEAN)(arg3 != arg4)) {
				RTHOOK(23);
				cairo_scale((cairo_t*) loc6, (double) (EIF_REAL_64) 1.0, (double) (EIF_REAL_64) 1.0);
			}
		}
		RTHOOK(24);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10413[dtype-1386])(Current);
	}
	RTHOOK(25);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.fill_rectangle */
void F1386_13654 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	
	
	RTEAA("fill_rectangle", 1385, Current, 0, 4, 19306);
	RTHOOK(1);
	F1386_13655(Current, arg1, arg2, arg3, arg4, (EIF_BOOLEAN) 1);
	RTHOOK(2);
	RTEE;
}

/* {EV_DRAWABLE_IMP}.draw_rectangle_internal */
void F1386_13655 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_BOOLEAN arg5)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_64 tr8_4;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("draw_rectangle_internal", 1385, Current, 1, 5, 19307);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg3 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg4 > ((EIF_INTEGER_32) 0L)))) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10412[dtype-1386])(Current);
		RTHOOK(3);
		loc1 = *(EIF_POINTER *)(Current + O10407[dtype-1385]);
		RTHOOK(4);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc1 != tp1)) {
			RTHOOK(5);
			tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg1 + (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10435[dtype-1386])(Current)));
			tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg2 + (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10436[dtype-1386])(Current)));
			tr8_3 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg3 - *(EIF_INTEGER_32 *)(Current + O10449[dtype-1385])));
			tr8_4 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg4 - *(EIF_INTEGER_32 *)(Current + O10449[dtype-1385])));
			cairo_rectangle((cairo_t*) loc1, (double) (EIF_REAL_64) (tr8_1 + (EIF_REAL_64) 0.5), (double) (EIF_REAL_64) (tr8_2 + (EIF_REAL_64) 0.5), (double) tr8_3, (double) tr8_4);
			RTHOOK(6);
			if (arg5) {
				RTHOOK(7);
				cairo_stroke_preserve((cairo_t*) loc1);
				RTHOOK(8);
				tr1 = RTLNS(eif_new_type(34, 0x00).id, 34, _OBJSIZ_0_0_0_0_0_0_0_0_);
				F35_640(RTCW(tr1), loc1);
			}
			RTHOOK(9);
			cairo_stroke((cairo_t*) loc1);
		}
		RTHOOK(10);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10413[dtype-1386])(Current);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.fill_ellipse */
void F1386_13656 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("fill_ellipse", 1385, Current, 0, 4, 19308);
	RTGC;
	RTHOOK(1);
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
	tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 2L));
	F1386_13650(Current, arg1, arg2, arg3, arg4, tr8_1, (EIF_REAL_64) (tr8_2 * 3.1415926535897931), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.release_cairo_context */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1386_13659 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_NATURAL_32 EIF_VOLATILE loc2 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	RTLD;
	RTXD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,saved_except);
	RTLIU(2);
	RTXSLS;
	
	RTEAA("release_cairo_context", 1385, Current, 2, 1, 19311);
	RTGC;
	RTE_T
	RTHOOK(1);
	tb1 = '\0';
	if ((EIF_BOOLEAN) !loc1) {
		tb2 = !arg1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		loc2 = inline_F35_588(arg1);
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc2 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
			RTHOOK(4);
			if ((EIF_BOOLEAN) (loc2 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 10000L))) {
				
			}
			RTHOOK(6);
			cairo_destroy((cairo_t*) arg1);
		} else {
		}
	}
	RTE_E
	RTXSC;
	RTHOOK(7);
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(8);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(9);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_DRAWABLE_IMP}.clear_cairo_context */
void F1386_13660 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("clear_cairo_context", 1385, Current, 2, 0, 19312);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_POINTER *)(Current + O10407[dtype-1385]);
	RTHOOK(2);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		loc2 = inline_F35_588(loc1);
		RTHOOK(4);
		F1386_13659(Current, loc1);
		RTHOOK(5);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current + O10407[dtype-1385]) = (EIF_POINTER) tp2;
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc2 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L))) {
			
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE_IMP}.pixbuf_from_drawable */
EIF_POINTER F1386_13662 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pixbuf_from_drawable", 1385, Current, 0, 0, 19314);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10311[dtype-1386])(Current);
	ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10312[dtype-1386])(Current);
	Result = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R10433[dtype-1386])(Current, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DRAWABLE_IMP}.pixbuf_from_drawable_at_position */
EIF_POINTER F1386_13663 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6)
{
	GTCX
	RTEX;
	
	
	RTEAA("pixbuf_from_drawable_at_position", 1385, Current, 0, 6, 19315);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_POINTER) inline_F114_1764(((EIF_INTEGER_32) 0L), (EIF_BOOLEAN) 1, ((EIF_INTEGER_32) 8L), arg5, arg6);
}

/* {EV_DRAWABLE_IMP}.device_x_offset */
EIF_INTEGER_32 F1386_13665 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("device_x_offset", 1385, Current, 0, 0, 19317);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_DRAWABLE_IMP}.device_y_offset */
EIF_INTEGER_32 F1386_13666 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("device_y_offset", 1385, Current, 0, 0, 19318);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_DRAWABLE_IMP}.internal_set_color */
void F1386_13667 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("internal_set_color", 1385, Current, 0, 4, 19319);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tp1 = *(EIF_POINTER *)(Current + O10407[dtype-1385]);
	tb2 = !tp1;
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = arg1;
	}
	if (tb1) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current + O10407[dtype-1385]);
		cairo_set_source_rgb((cairo_t*) tp1, (double) arg2, (double) arg3, (double) arg4);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit738 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
