
#ifndef _C15_ev733_
#define _C15_ev733_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1381_13508(EIF_REFERENCE);
extern EIF_BOOLEAN F1381_13509(EIF_REFERENCE);
extern void F1381_13511(EIF_REFERENCE);
extern void F1381_13512(EIF_REFERENCE);
extern void EIF_Minit733(void);
extern long O10331[];

#ifdef __cplusplus
}
#endif

#endif
