/*
 * Code for class EV_MENU_ITEM_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev722.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F10_92
static EIF_NATURAL_8 inline_F10_92 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F10_92
#endif
#ifndef INLINE_F116_2321
static EIF_POINTER inline_F116_2321 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F116_2321
#endif
#ifndef INLINE_F117_2537
static void inline_F117_2537 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_xalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F117_2537
#endif
#ifndef INLINE_F117_2538
static void inline_F117_2538 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_yalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F117_2538
#endif
#ifndef INLINE_F117_2345
static EIF_POINTER inline_F117_2345 (void)
{
	return gtk_settings_get_default();
	;
}
#define INLINE_F117_2345
#endif
#ifndef INLINE_F12_130
static EIF_POINTER inline_F12_130 (void)
{
	static char *v = "gtk-menu-images";
return (EIF_POINTER) v;
	;
}
#define INLINE_F12_130
#endif
#ifndef INLINE_F115_2198
static void inline_F115_2198 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	g_object_set((gpointer) arg1, (gchar*) arg2, arg3 ? TRUE : FALSE, NULL)
	;
}
#define INLINE_F115_2198
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MENU_ITEM_IMP}.make */
RTEOMS(13339,1);
void F1370_13340 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("make", 1369, Current, 1, 0, 19078);
	RTGC;
	RTHOOK(1);
	F1370_13341(Current);
	RTHOOK(2);
	F1228_11371(Current);
	RTHOOK(3);
	tp1 = F1370_13346(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,973,936,1045,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	tr2 = *(EIF_REFERENCE *)(RTCV(RTOSCF(11369,F1227_11369, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
	RTAR(tr1,tr2);
	tp2 = *(EIF_POINTER *)(Current + O9124[dtype-1226]);
	((EIF_TYPED_VALUE *)tr1+2)->it_p = tp2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,0,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2= RTLNRF(typres0.id, (EIF_POINTER) __A365_338, (EIF_POINTER) _A365_338, (EIF_POINTER)(F935_7374),tr1, 1, 0);
	}
	F1227_11349(Current, tp1, RTOMS(13339,0), tr2);
	RTHOOK(4);
	F1264_11767(Current);
	RTHOOK(5);
	tu1_1 = inline_F10_92();
	loc1 = inline_F116_2321(tu1_1, ((EIF_INTEGER_32) 0L));
	RTHOOK(6);
	tp1 = F1370_13346(Current);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) loc1);
	RTHOOK(7);
	gtk_widget_show((GtkWidget*) loc1);
	RTHOOK(8);
	tp1 = *(EIF_POINTER *)(Current + O9453[dtype-1259]);
	tb1 = !tp1;
	if (tb1) {
		RTHOOK(9);
		F1260_11745(Current);
		RTHOOK(10);
		tp1 = *(EIF_POINTER *)(Current + O9453[dtype-1259]);
		gtk_box_pack_start((GtkBox*) loc1, (GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	}
	RTHOOK(11);
	tp1 = *(EIF_POINTER *)(Current + O9467[dtype-1263]);
	gtk_box_pack_start((GtkBox*) loc1, (GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	RTHOOK(12);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	tp1 = (EIF_POINTER) gtk_label_new((gchar*) tp2);
	*(EIF_POINTER *)(Current + O10269[dtype-1369]) = (EIF_POINTER) tp1;
	RTHOOK(13);
	tp1 = *(EIF_POINTER *)(Current + O10269[dtype-1369]);
	inline_F117_2537(tp1, (EIF_REAL_32) 1.0);
	RTHOOK(14);
	tp1 = *(EIF_POINTER *)(Current + O10269[dtype-1369]);
	inline_F117_2538(tp1, (EIF_REAL_32) 0.5);
	RTHOOK(15);
	tp1 = *(EIF_POINTER *)(Current + O10269[dtype-1369]);
	gtk_box_pack_start((GtkBox*) loc1, (GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 1, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 2L));
	RTHOOK(16);
	tp1 = *(EIF_POINTER *)(Current + O10269[dtype-1369]);
	ti4_1 = (EIF_INTEGER_32) GTK_JUSTIFY_RIGHT;
	gtk_label_set_justify((GtkLabel*) tp1, (GtkJustification) ti4_1);
	RTHOOK(17);
	tp1 = inline_F117_2345();
	tp2 = inline_F12_130();
	inline_F115_2198(tp1, tp2, (EIF_BOOLEAN) 1);
	RTHOOK(18);
	RTLE;
	RTEE;
}

/* {EV_MENU_ITEM_IMP}.initialize_menu_item */
void F1370_13341 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("initialize_menu_item", 1369, Current, 0, 0, 19079);
	RTGC;
	RTHOOK(1);
	tp1 = (EIF_POINTER) gtk_menu_item_new();
	F1227_11344(Current, tp1);
	RTHOOK(2);
	F1260_11745(Current);
	RTHOOK(3);
	F1370_13347(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_MENU_ITEM_IMP}.needs_event_box */
EIF_BOOLEAN F1370_13342 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

/* {EV_MENU_ITEM_IMP}.is_dockable */
EIF_BOOLEAN F1370_13343 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

/* {EV_MENU_ITEM_IMP}.set_text */
void F1370_13345 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTEAA("set_text", 1369, Current, 3, 1, 19083);
	RTGC;
	RTHOOK(1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\011';
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_CHARACTER_32)) R7292[Dtype(RTCW(arg1))-1057])(arg1, tw1);
	if (tb1) {
		RTHOOK(2);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\011';
		loc1 = F1054_8845(RTCW(arg1), tw1);
	}
	RTHOOK(3);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4921[Dtype(RTCW(loc1))-600])(loc1);
		tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L));
	}
	if (tb1) {
		RTHOOK(4);
		ti4_1 = ((EIF_INTEGER_32) 1L);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4903[Dtype(RTCW(loc1))-600])(loc1, (EIF_REFERENCE) &ti4_1);
		F1264_11773(Current, tr1);
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + O9469[dtype-1263]);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(6);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\011';
			F1063_9191(loc3, tw1);
			RTHOOK(7);
			ti4_1 = ((EIF_INTEGER_32) 2L);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4903[Dtype(RTCW(loc1))-600])(loc1, (EIF_REFERENCE) &ti4_1);
			F1063_9177(loc3, tr1);
		} else {
			
		}
		RTHOOK(9);
		loc2 = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_1_0_1_0_1_0_0_);
		tr1 = RTMS32_EX_H(" \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000 \000\000\000",12,286432288);
		ti4_1 = ((EIF_INTEGER_32) 2L);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4903[Dtype(RTCW(loc1))-600])(loc1, (EIF_REFERENCE) &ti4_1);
		tr2 = F1054_8826(RTCW(tr2));
		tr1 = F1063_9197(tr1, tr2);
		F923_6661(RTCW(loc2), tr1);
		RTHOOK(10);
		tp1 = *(EIF_POINTER *)(Current + O10269[dtype-1369]);
		tp2 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_0_1_0_1_0_0_);
		gtk_label_set_text((GtkLabel*) tp1, (gchar*) tp2);
		RTHOOK(11);
		tp1 = *(EIF_POINTER *)(Current + O10269[dtype-1369]);
		gtk_widget_show((GtkWidget*) tp1);
	} else {
		RTHOOK(12);
		F1264_11773(Current, arg1);
		RTHOOK(13);
		tp1 = *(EIF_POINTER *)(Current + O10269[dtype-1369]);
		gtk_widget_hide((GtkWidget*) tp1);
	}
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {EV_MENU_ITEM_IMP}.menu_item */
EIF_POINTER F1370_13346 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("menu_item", 1369, Current, 0, 0, 19084);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_POINTER) *(EIF_POINTER *)(Current + O9124[Dtype(Current)-1226]);
}

/* {EV_MENU_ITEM_IMP}.image_menu_item_new */
void F1370_13347 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("image_menu_item_new", 1369, Current, 0, 0, 19085);
	RTGC;
	RTHOOK(1);
	tp1 = F1370_13346(Current);
	gtk_widget_show((GtkWidget*) tp1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_MENU_ITEM_IMP}.allow_on_activate */
EIF_BOOLEAN F1370_13348 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("allow_on_activate", 1369, Current, 0, 0, 19086);
	RTGC;
	RTHOOK(1);
	tr1 = F1363_13320(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != NULL);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_MENU_ITEM_IMP}.accelerators_enabled */
EIF_BOOLEAN F1370_13349 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {EV_MENU_ITEM_IMP}.on_activate */
void F1370_13350 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("on_activate", 1369, Current, 1, 0, 19088);
	RTGC;
	RTHOOK(1);
	tr1 = F1363_13320(Current);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1237, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(loc1);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			RTHOOK(3);
			tr1 = F75_1251(loc1);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y8598,Y8598_gen_type,Dftype(Current),1200);
					typarr0[3] = l_type.annotations | 0xFF00;
					typarr0[4] = l_type.id;
				}
				
				typres0 = eif_compound_id(Dftype(Current), typarr0);
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F1201_10644(Current);
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			F712_6079(RTCW(tr1), tr2);
		}
		RTHOOK(4);
		tp1 = *(EIF_POINTER *)(loc1+ _PTROFF_26_8_6_2_0_4_);
		gtk_menu_shell_deactivate((GtkMenuShell*) tp1);
	}
	RTHOOK(5);
	tp1 = F1370_13346(Current);
	gtk_menu_item_deselect((GtkMenuItem*) tp1);
	RTHOOK(6);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O1322[dtype-89]) != NULL)) {
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current + O1322[dtype-89]);
		F712_6079(RTCW(tr1), NULL);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

void EIF_Minit722 (void)
{
	GTCX
	RTPOMS(13339,0,"activate",8,526134885);
}


#ifdef __cplusplus
}
#endif
