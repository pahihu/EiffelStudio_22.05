/*
 * Code for class EV_CHECK_BUTTON_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev706.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F117_2537
static void inline_F117_2537 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_xalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F117_2537
#endif
#ifndef INLINE_F117_2538
static void inline_F117_2538 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_yalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F117_2538
#endif
#ifndef INLINE_F14_137
static EIF_INTEGER_32 inline_F14_137 (void)
{
	return GTK_ALIGN_END
	;
}
#define INLINE_F14_137
#endif
#ifndef INLINE_F116_2308
static void inline_F116_2308 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return gtk_widget_set_halign ((GtkWidget *)arg1, (GtkAlign)arg2)
	;
}
#define INLINE_F116_2308
#endif
#ifndef INLINE_F14_138
static EIF_INTEGER_32 inline_F14_138 (void)
{
	return GTK_ALIGN_CENTER
	;
}
#define INLINE_F14_138
#endif
#ifndef INLINE_F116_2311
static void inline_F116_2311 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return gtk_widget_set_valign ((GtkWidget *)arg1, (GtkAlign)arg2)
	;
}
#define INLINE_F116_2311
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CHECK_BUTTON_IMP}.new_gtk_button */
EIF_POINTER F1354_13192 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("new_gtk_button", 1353, Current, 0, 0, 18938);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_POINTER) (EIF_POINTER) gtk_check_button_new();
}

/* {EV_CHECK_BUTTON_IMP}.make */
void F1354_13193 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	struct eif_ex_1037 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(17, 0x00).id);
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("make", 1353, Current, 1, 0, 18939);
	RTGC;
	RTHOOK(1);
	F1351_13159(Current);
	RTHOOK(2);
	F1351_13166(Current);
	RTHOOK(3);
	tr1 = F18_202(RTCW(loc1));
	F1246_11654(Current, tr1);
	RTHOOK(4);
	tr1 = F18_203(RTCW(loc1));
	F1351_13171(Current, tr1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_CHECK_BUTTON_IMP}.set_text */
void F1354_13194 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_text", 1353, Current, 0, 1, 18940);
	RTGC;
	RTHOOK(1);
	F1264_11773(Current, arg1);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
	inline_F117_2537(tp1, (EIF_REAL_32) 0.0);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
	inline_F117_2538(tp1, (EIF_REAL_32) 0.5);
	RTHOOK(4);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(F1260_11752(Current) != tp1)) {
		RTHOOK(5);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_1_);
		ti4_1 = inline_F14_137();
		inline_F116_2308(tp1, ti4_1);
		RTHOOK(6);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_1_);
		ti4_1 = inline_F14_138();
		inline_F116_2311(tp1, ti4_1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

void EIF_Minit706 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
