/*
 * Code for class EV_TOGGLE_BUTTON_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev705.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TOGGLE_BUTTON_IMP}.enable_select */
void F1353_13187 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("enable_select", 1352, Current, 0, 0, 18933);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1353_13189(Current)) {
		RTHOOK(2);
		tp1 = F1227_11368(Current);
		gtk_toggle_button_set_active((GtkToggleButton*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_TOGGLE_BUTTON_IMP}.disable_select */
void F1353_13188 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("disable_select", 1352, Current, 0, 0, 18934);
	RTGC;
	RTHOOK(1);
	if (F1353_13189(Current)) {
		RTHOOK(2);
		tp1 = F1227_11368(Current);
		gtk_toggle_button_set_active((GtkToggleButton*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_TOGGLE_BUTTON_IMP}.is_selected */
EIF_BOOLEAN F1353_13189 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_selected", 1352, Current, 0, 0, 18935);
	RTGC;
	RTHOOK(1);
	tp1 = F1227_11368(Current);
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_toggle_button_get_active((GtkToggleButton*) tp1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit705 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
