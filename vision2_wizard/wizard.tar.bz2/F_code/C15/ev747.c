/*
 * Code for class EV_KEY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev747.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_KEY}.default_create */
void F1395_13883 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_create", 1394, Current, 0, 0, 19541);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_create) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 41L);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_KEY}.make_with_code */
void F1395_13884 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_with_code", 1394, Current, 0, 1, 19542);
	RTGC;
	RTHOOK(1);
	F1395_13883(Current);
	RTHOOK(2);
	F1395_13886(Current, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_KEY}.set_code */
void F1395_13886 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_code", 1394, Current, 0, 1, 19544);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_KEY}.is_numpad */
EIF_BOOLEAN F1395_13888 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_numpad", 1394, Current, 0, 0, 19533);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) >= ((EIF_INTEGER_32) 11L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) <= ((EIF_INTEGER_32) 26L)));
}

/* {EV_KEY}.is_arrow */
EIF_BOOLEAN F1395_13891 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_arrow", 1394, Current, 0, 0, 19536);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) >= ((EIF_INTEGER_32) 58L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) <= ((EIF_INTEGER_32) 61L)));
}

/* {EV_KEY}.text */
EIF_REFERENCE F1395_13893 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("text", 1394, Current, 0, 0, 19538);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(4203,F273_4203, (Current));
	Result = F601_5389(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_KEY}.out */
EIF_REFERENCE F1395_13894 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("out", 1394, Current, 0, 0, 19539);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(4203,F273_4203, (Current));
	tr1 = F601_5389(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_));
	Result = F1054_8821(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit747 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
