
#ifndef _C15_ev715_
#define _C15_ev715_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1363_13319(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F1363_13320(EIF_REFERENCE);
extern void F1363_13321(EIF_REFERENCE);
extern void F1363_13323(EIF_REFERENCE, EIF_REFERENCE);
extern void F1363_13324(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit715(void);
extern void F712_6079(EIF_REFERENCE, EIF_REFERENCE);
extern void F1227_11347(EIF_REFERENCE);
extern void F1232_11518(EIF_REFERENCE, EIF_REFERENCE);
extern long O10263[];
extern long O8598[];
extern long O1280[];
extern long O1282[];

#ifdef __cplusplus
}
#endif

#endif
