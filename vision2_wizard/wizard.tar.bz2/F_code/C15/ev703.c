/*
 * Code for class EV_BUTTON_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev703.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F10_92
static EIF_NATURAL_8 inline_F10_92 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F10_92
#endif
#ifndef INLINE_F116_2321
static EIF_POINTER inline_F116_2321 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F116_2321
#endif
#ifndef INLINE_F14_136
static EIF_INTEGER_32 inline_F14_136 (void)
{
	return GTK_ALIGN_START
	;
}
#define INLINE_F14_136
#endif
#ifndef INLINE_F116_2308
static void inline_F116_2308 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return gtk_widget_set_halign ((GtkWidget *)arg1, (GtkAlign)arg2)
	;
}
#define INLINE_F116_2308
#endif
#ifndef INLINE_F116_2311
static void inline_F116_2311 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return gtk_widget_set_valign ((GtkWidget *)arg1, (GtkAlign)arg2)
	;
}
#define INLINE_F116_2311
#endif
#ifndef INLINE_F116_2313
static void inline_F116_2313 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_widget_set_margin_start ((GtkWidget *)arg1, (gint)arg2)
	;
}
#define INLINE_F116_2313
#endif
#ifndef INLINE_F116_2315
static void inline_F116_2315 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_widget_set_margin_end ((GtkWidget *)arg1, (gint)arg2)
	;
}
#define INLINE_F116_2315
#endif
#ifndef INLINE_F14_138
static EIF_INTEGER_32 inline_F14_138 (void)
{
	return GTK_ALIGN_CENTER
	;
}
#define INLINE_F14_138
#endif
#ifndef INLINE_F117_2405
static void inline_F117_2405 (EIF_POINTER arg1)
{
	gtk_widget_queue_draw ((GtkWidget *)arg1)
	;
}
#define INLINE_F117_2405
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_BUTTON_IMP}.new_gtk_button */
EIF_POINTER F1351_13158 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("new_gtk_button", 1350, Current, 0, 0, 18906);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_POINTER) (EIF_POINTER) gtk_button_new();
}

/* {EV_BUTTON_IMP}.make */
void F1351_13159 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 1350, Current, 0, 0, 18907);
	RTGC;
	RTHOOK(1);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R10223[Dtype(Current)-1350])(Current);
	F1227_11344(Current, tp1);
	RTHOOK(2);
	F1260_11745(Current);
	RTHOOK(3);
	F1264_11767(Current);
	RTHOOK(4);
	F1351_13160(Current);
	RTHOOK(5);
	F1351_13165(Current);
	RTHOOK(6);
	F1332_12698(Current);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_BUTTON_IMP}.initialize_button_box */
void F1351_13160 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("initialize_button_box", 1350, Current, 1, 0, 18908);
	RTGC;
	RTHOOK(1);
	tu1_1 = inline_F10_92();
	loc1 = inline_F116_2321(tu1_1, ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	tp1 = F1227_11368(Current);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) loc1);
	RTHOOK(3);
	ti4_1 = inline_F14_136();
	inline_F116_2308(loc1, ti4_1);
	RTHOOK(4);
	ti4_1 = inline_F14_136();
	inline_F116_2311(loc1, ti4_1);
	RTHOOK(5);
	gtk_widget_set_hexpand((GtkWidget*) loc1, (gboolean) (EIF_BOOLEAN) 0);
	RTHOOK(6);
	gtk_widget_set_vexpand((GtkWidget*) loc1, (gboolean) (EIF_BOOLEAN) 0);
	RTHOOK(7);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_1_);
	gtk_container_add((GtkContainer*) loc1, (GtkWidget*) tp1);
	RTHOOK(8);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
	ti4_1 = inline_F14_136();
	inline_F116_2308(tp1, ti4_1);
	RTHOOK(9);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
	inline_F116_2313(tp1, ((EIF_INTEGER_32) 4L));
	RTHOOK(10);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
	inline_F116_2315(tp1, ((EIF_INTEGER_32) 4L));
	RTHOOK(11);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
	gtk_container_add((GtkContainer*) loc1, (GtkWidget*) tp1);
	RTHOOK(12);
	gtk_widget_show((GtkWidget*) loc1);
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {EV_BUTTON_IMP}.fontable_widget */
EIF_POINTER F1351_13161 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("fontable_widget", 1350, Current, 0, 0, 18909);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_POINTER) *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
}

/* {EV_BUTTON_IMP}.event_widget */
EIF_POINTER F1351_13162 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("event_widget", 1350, Current, 0, 0, 18910);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_POINTER) F1227_11368(Current);
}

/* {EV_BUTTON_IMP}.needs_event_box */
EIF_BOOLEAN F1351_13163 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("needs_event_box", 1350, Current, 0, 0, 18911);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_BUTTON_IMP}.is_default_push_button */
EIF_BOOLEAN F1351_13164 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_46_11_);
}


/* {EV_BUTTON_IMP}.align_text_center */
void F1351_13165 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("align_text_center", 1350, Current, 0, 0, 18913);
	RTGC;
	RTHOOK(1);
	F1264_11770(Current);
	RTHOOK(2);
	tp1 = F1351_13174(Current);
	ti4_1 = inline_F14_138();
	inline_F116_2308(tp1, ti4_1);
	RTHOOK(3);
	tp1 = F1351_13174(Current);
	ti4_1 = inline_F14_138();
	inline_F116_2311(tp1, ti4_1);
	RTHOOK(4);
	tp1 = F1351_13174(Current);
	gtk_widget_set_hexpand((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	RTHOOK(5);
	tp1 = F1351_13174(Current);
	gtk_widget_set_vexpand((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_BUTTON_IMP}.align_text_left */
void F1351_13166 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("align_text_left", 1350, Current, 0, 0, 18914);
	RTGC;
	RTHOOK(1);
	F1264_11771(Current);
	RTHOOK(2);
	tp1 = F1351_13174(Current);
	ti4_1 = inline_F14_136();
	inline_F116_2308(tp1, ti4_1);
	RTHOOK(3);
	tp1 = F1351_13174(Current);
	ti4_1 = inline_F14_138();
	inline_F116_2311(tp1, ti4_1);
	RTHOOK(4);
	tp1 = F1351_13174(Current);
	gtk_widget_set_hexpand((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	RTHOOK(5);
	tp1 = F1351_13174(Current);
	gtk_widget_set_vexpand((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_BUTTON_IMP}.enable_default_push_button */
void F1351_13168 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("enable_default_push_button", 1350, Current, 0, 0, 18916);
	RTHOOK(1);
	F1351_13170(Current);
	RTHOOK(2);
	RTEE;
}

/* {EV_BUTTON_IMP}.disable_default_push_button */
void F1351_13169 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("disable_default_push_button", 1350, Current, 0, 0, 18917);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_46_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	tp1 = F1227_11368(Current);
	gtk_widget_set_can_default((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	RTHOOK(3);
	tp1 = F1227_11368(Current);
	inline_F117_2405(tp1);
	RTHOOK(4);
	F1278_12018(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_BUTTON_IMP}.enable_can_default */
void F1351_13170 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("enable_can_default", 1350, Current, 0, 0, 18918);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_46_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	tp1 = F1227_11368(Current);
	gtk_widget_set_can_default((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	RTHOOK(3);
	tp1 = F1227_11368(Current);
	inline_F117_2405(tp1);
	RTHOOK(4);
	F1278_12018(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_BUTTON_IMP}.set_foreground_color */
void F1351_13171 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_foreground_color", 1350, Current, 0, 1, 18919);
	RTGC;
	RTHOOK(1);
	F1246_11657(Current, arg1);
	RTHOOK(2);
	F1246_11658(Current, *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_BUTTON_IMP}.on_focus_changed */
void F1351_13172 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("on_focus_changed", 1350, Current, 2, 1, 18920);
	RTGC;
	RTHOOK(1);
	F1278_11994(Current, arg1);
	RTHOOK(2);
	loc1 = F1228_11403(Current);
	loc1 = RTRV(eif_new_type(1307, 0x00), loc1);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(4);
		if (arg1) {
			RTHOOK(5);
			loc2 = Current;
			loc2 = RTRV(eif_new_type(1351, 0x00), loc2);
			RTHOOK(6);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				RTHOOK(7);
				F1300_12302(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_25_));
			}
		} else {
			RTHOOK(8);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_62_);
			if ((EIF_BOOLEAN)(tr1 == *(EIF_REFERENCE *)(Current + _REFACS_25_))) {
				RTHOOK(9);
				F1300_12302(RTCW(loc1), NULL);
			}
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_BUTTON_IMP}.foreground_color_style_context */
EIF_POINTER F1351_13173 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("foreground_color_style_context", 1350, Current, 0, 0, 18921);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_2_);
	RTHOOK(2);
	RTEE;
	return (EIF_POINTER) (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) tp1);
}

/* {EV_BUTTON_IMP}.button_box */
EIF_POINTER F1351_13174 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("button_box", 1350, Current, 0, 0, 18922);
	RTGC;
	RTHOOK(1);
	tp1 = F1227_11368(Current);
	Result = (EIF_POINTER) gtk_bin_get_child((GtkBin*) tp1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_BUTTON_IMP}.init_select_actions */
void F1351_13175 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("init_select_actions", 1350, Current, 1, 1, 18902);
	RTGC;
	RTHOOK(1);
	loc1 = RTOSCF(11369,F1227_11369, (Current));
	RTHOOK(2);
	tp1 = F1227_11368(Current);
	tr1 = RTOSCF(520,F34_520, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,973,936,1045,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_6_0_0_);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = tp2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,0,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A365_337, (EIF_POINTER) _A365_337, (EIF_POINTER)(F935_7373),tr2, 1, 0);
	}
	F1227_11348(Current, tp1, tr1, tr3);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit703 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
