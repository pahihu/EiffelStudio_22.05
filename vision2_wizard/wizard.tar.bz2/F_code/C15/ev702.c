/*
 * Code for class EV_PASSWORD_FIELD_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev702.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PASSWORD_FIELD_IMP}.make */
void F1350_13155 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 1349, Current, 0, 0, 18900);
	RTGC;
	RTHOOK(1);
	F1348_13091(Current);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	gtk_entry_set_visibility((GtkEntry*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit702 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
