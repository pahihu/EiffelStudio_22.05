/*
 * Code for class EV_SCREEN_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev740.h"
#include <ev_gtk.h>
#include "ev_any_imp.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F114_1773
static EIF_POINTER inline_F114_1773 (void)
{
	return gdk_screen_get_default()
	;
}
#define INLINE_F114_1773
#endif
#ifndef INLINE_F114_1775
static EIF_POINTER inline_F114_1775 (EIF_POINTER arg1)
{
	return gdk_screen_get_root_window ((GdkScreen *)arg1);;
	;
}
#define INLINE_F114_1775
#endif
#ifndef INLINE_F113_1524
static EIF_POINTER inline_F113_1524 (EIF_POINTER arg1)
{
	#ifdef GDK_WINDOWING_X11 
		/* Declarations */
	GC gc;									/* handle of newly created GC.  */
	unsigned long valuemask = 0;			/* which values in 'values' to  */
	Window win =  gdk_x11_window_get_xid ((GdkWindow *)arg1);
	Display* display = GDK_SCREEN_XDISPLAY(gdk_window_get_screen ((GdkWindow *)arg1));
		/* Define properties/values for the GC.  */
	XGCValues values;						/* initial values for the GC.   */
	unsigned int line_width = 1;			/* line width for the GC.       */
	int line_style = LineSolid;				/* style for lines drawing and  */
	int cap_style = CapButt;				/* style of the line's edje and */
	int join_style = JoinBevel;				/* joined lines.		*/
	values.function = GXcopy;               /* src */
	values.subwindow_mode = ClipByChildren; /* GCSubwindowMode */
	values.line_width = line_width;
	values.fill_style = FillSolid;
	values.arc_mode = ArcPieSlice;
	values.graphics_exposures = False;
	valuemask = GCFunction | GCFillStyle | GCArcMode | GCSubwindowMode | GCGraphicsExposures;
		/* Create the GC object */
	gc = XCreateGC(display, win, valuemask, &values);
	if (gc < 0) {
		fprintf(stderr, "XCreateGC: \n");
	}
	return gc;
#endif
	;
}
#define INLINE_F113_1524
#endif
#ifndef INLINE_F113_1528
static EIF_POINTER inline_F113_1528 (EIF_POINTER arg1)
{
	#ifdef GDK_WINDOWING_X11 
	return (EIF_POINTER) GDK_SCREEN_XDISPLAY(gdk_window_get_screen ((GdkWindow *)arg1));
#endif
	;
}
#define INLINE_F113_1528
#endif
#ifndef INLINE_F113_1547
static EIF_INTEGER_32 inline_F113_1547 (void)
{
	#ifdef GDK_WINDOWING_X11 
return IncludeInferiors;
#endif
	;
}
#define INLINE_F113_1547
#endif
#ifndef INLINE_F113_1531
static void inline_F113_1531 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	#ifdef GDK_WINDOWING_X11 
XSetSubwindowMode((Display *)arg1, (GC)arg2, (int)arg3);
#endif
	;
}
#define INLINE_F113_1531
#endif
#ifndef INLINE_F114_1768
static EIF_INTEGER_32 inline_F114_1768 (EIF_POINTER arg1)
{
	return gdk_screen_get_resolution ((GdkScreen*)arg1);
	;
}
#define INLINE_F114_1768
#endif
#ifndef INLINE_F113_1571
static void inline_F113_1571 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_BOOLEAN arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	#ifdef GDK_WINDOWING_X11 
					Window win = (Window) arg1;
					if (arg7 < 0 || arg8 < 0)
					{
						gint real_width;
						gint real_height;
						
						XWindowAttributes wa;
						XGetWindowAttributes((Display*) arg2, win, &wa);
						real_width = wa.width;
						real_height = wa.height;
					   
					   	if (arg7 < 0)
							arg7 = real_width;
						if (arg8 < 0)
							arg8 = real_height;
					}

					if (arg4)
					    XFillRectangle ((Display*) arg2, win, arg3, arg5, arg6, arg7, arg8);
					else
					    XDrawRectangle ((Display*) arg2, win, arg3, arg5, arg6, arg7, arg8);

				#endif
	;
}
#define INLINE_F113_1571
#endif
#ifndef INLINE_F113_1568
static void inline_F113_1568 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7)
{
	#ifdef GDK_WINDOWING_X11 
	Window win = (Window) arg1;
	/*
	 * TODO check Gdkgc-x11 _gdk_x11_gc_flush implementation 
	 * that's used before
	 * for example gdk_x11_draw_segments the usage of
	 * GDK_GC_GET_XGC (gc),
	 * https://github.com/coapp-packages/gtk/blob/master/gdk/x11/gdkdrawable-x11.c
	 */
						
	XDrawLine((Display*) arg2, win, arg3, arg4, arg5, arg6, arg7);
	
#endif
	;
}
#define INLINE_F113_1568
#endif
#ifndef INLINE_F113_1570
static void inline_F113_1570 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_BOOLEAN arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_INTEGER_32 arg10)
{
	#ifdef GDK_WINDOWING_X11 
					Window win = (Window) arg1;
					if (arg7 < 0 || arg8 < 0)
					{
						gint real_width;
						gint real_height;
						XWindowAttributes wa;
						XGetWindowAttributes((Display*) arg2, win, &wa);
						real_width = wa.width;
						real_height = wa.height;

						if (arg7 < 0)
							arg7 = real_width;
						if (arg8 < 0)
							arg8 = real_height;
					}

					if (arg4)
					    XFillArc ((Display*) arg2, win, arg3, arg5, arg6, arg7, arg8, arg9, arg10);
					else
					    XDrawArc ((Display*) arg2, win, arg3, arg5, arg6, arg7, arg8, arg9, arg10);	
	
				#endif
	;
}
#define INLINE_F113_1570
#endif
#ifndef INLINE_F113_1569
static void inline_F113_1569 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	#ifdef GDK_WINDOWING_X11 
	XDrawPoint ((Display*) arg2, (Drawable) arg1, arg3, arg4, arg5);
#endif
	;
}
#define INLINE_F113_1569
#endif
#ifndef INLINE_F113_1538
static EIF_INTEGER_32 inline_F113_1538 (void)
{
	#ifdef GDK_WINDOWING_X11
return FillTiled;
#endif
	;
}
#define INLINE_F113_1538
#endif
#ifndef INLINE_F113_1534
static void inline_F113_1534 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	#ifdef GDK_WINDOWING_X11 
XSetFillStyle((Display*)arg1, (GC) arg2, (int)arg3);	
#endif
	;
}
#define INLINE_F113_1534
#endif
#ifndef INLINE_F113_1537
static EIF_INTEGER_32 inline_F113_1537 (void)
{
	#ifdef GDK_WINDOWING_X11
return FillSolid;
#endif
	;
}
#define INLINE_F113_1537
#endif
#ifndef INLINE_F113_1536
static void inline_F113_1536 (EIF_POINTER arg1)
{
	#ifdef GDK_WINDOWING_X11 
	XFlush((Display*) arg1);
#endif
	;
}
#define INLINE_F113_1536
#endif
#ifndef INLINE_F113_1529
static EIF_POINTER inline_F113_1529 (EIF_POINTER arg1)
{
	#ifdef GDK_WINDOWING_X11 
	return (EIF_POINTER) gdk_x11_window_get_xid ((GdkWindow *) arg1);
#endif
	;
}
#define INLINE_F113_1529
#endif
#ifndef INLINE_F113_1555
static EIF_INTEGER_32 inline_F113_1555 (void)
{
	#ifdef GDK_WINDOWING_X11
return GXcopy;
#endif
	;
}
#define INLINE_F113_1555
#endif
#ifndef INLINE_F113_1530
static void inline_F113_1530 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	#ifdef GDK_WINDOWING_X11 
XSetFunction((Display*) arg1, (GC) arg2, (int) arg3);
#endif
	;
}
#define INLINE_F113_1530
#endif
#ifndef INLINE_F113_1553
static EIF_INTEGER_32 inline_F113_1553 (void)
{
	#ifdef GDK_WINDOWING_X11
return GXand;
#endif
	;
}
#define INLINE_F113_1553
#endif
#ifndef INLINE_F113_1558
static EIF_INTEGER_32 inline_F113_1558 (void)
{
	#ifdef GDK_WINDOWING_X11
return GXxor;
#endif
	;
}
#define INLINE_F113_1558
#endif
#ifndef INLINE_F113_1562
static EIF_INTEGER_32 inline_F113_1562 (void)
{
	#ifdef GDK_WINDOWING_X11
return GXinvert;
#endif
	;
}
#define INLINE_F113_1562
#endif
#ifndef INLINE_F113_1559
static EIF_INTEGER_32 inline_F113_1559 (void)
{
	#ifdef GDK_WINDOWING_X11
return GXor;
#endif
	;
}
#define INLINE_F113_1559
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SCREEN_IMP}.make */
void F1388_13709 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_16 ti2_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 1387, Current, 0, 0, 19359);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.do_nothing) */
		tr1 = RTOSCF(13788,F1388_13788, (Current));
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	RTHOOK(2);
	tb1 = RTOSCF(11122,F1222_11122, (RTCV(RTOSCF(13788,F1388_13788, (Current)))));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_) = (EIF_BOOLEAN) tb1;
	RTHOOK(3);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(13788,F1388_13788, (Current)))+ _LNGOFF_49_16_0_11_);
	ti2_1 = (EIF_INTEGER_16) ti4_1;
	ti4_1 = (EIF_INTEGER_32) (EIF_INTEGER_16) -ti2_1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(4);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(13788,F1388_13788, (Current)))+ _LNGOFF_49_16_0_12_);
	ti2_1 = (EIF_INTEGER_16) ti4_1;
	ti4_1 = (EIF_INTEGER_32) (EIF_INTEGER_16) -ti2_1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(5);
	F1201_10658(Current, (EIF_BOOLEAN) 1);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.prepare_drawing */
void F1388_13711 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("prepare_drawing", 1387, Current, 0, 0, 19361);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_6_3_)) {
		RTHOOK(2);
		F1388_13712(Current);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.initialize_drawing */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1388_13712 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_POINTER  EIF_VOLATILE tp1;
	EIF_POINTER  EIF_VOLATILE tp2;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	RTLD;
	RTXD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,saved_except);
	RTLIU(2);
	RTXSLS;
	
	RTEAA("initialize_drawing", 1387, Current, 0, 0, 19362);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_6_3_)) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(3);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
			RTHOOK(4);
			tp1 = inline_F114_1773();
			tp1 = inline_F114_1775(tp1);
			*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_) = (EIF_POINTER) tp1;
			RTHOOK(5);
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
			tp1 = inline_F113_1524(tp1);
			*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_) = (EIF_POINTER) tp1;
			RTHOOK(6);
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
			tp1 = inline_F113_1528(tp1);
			tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
			ti4_1 = inline_F113_1547();
			inline_F113_1531(tp1, tp2, ti4_1);
		}
		RTHOOK(7);
		F1388_13713(Current);
	}
	RTE_E
	RTXSC;
	RTHOOK(8);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(9);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(10);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(11);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_SCREEN_IMP}.init_default_values */
void F1388_13713 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("init_default_values", 1387, Current, 0, 0, 19363);
	RTGC;
	RTHOOK(1);
	F1388_13783(Current);
	RTHOOK(2);
	F1388_13781(Current, ((EIF_INTEGER_32) 0L));
	RTHOOK(3);
	F1388_13782(Current, ((EIF_INTEGER_32) 1L));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.get_cairo_context */
void F1388_13717 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("get_cairo_context", 1387, Current, 0, 0, 19367);
	RTHOOK(1);
	*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_0_) = (EIF_POINTER) *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
	RTHOOK(2);
	RTEE;
}

/* {EV_SCREEN_IMP}.pointer_position */
EIF_REFERENCE F1388_13718 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("pointer_position", 1387, Current, 1, 0, 19368);
	RTGC;
	RTHOOK(1);
	loc1 = F1222_11228(RTCV(RTOSCF(13788,F1388_13788, (Current))));
	RTHOOK(2);
	Result = RTLNS(eif_new_type(855, 0x00).id, 855, _OBJSIZ_0_0_0_0_0_0_0_2_);
	ti4_1 = eif_integer_32_item(RTCW(loc1),2);
	ti4_2 = eif_integer_32_item(RTCW(loc1),3);
	F856_6416(RTCW(Result), ti4_1, ti4_2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_SCREEN_IMP}.widget_at_mouse_pointer */
EIF_REFERENCE F1388_13720 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("widget_at_mouse_pointer", 1387, Current, 1, 0, 19370);
	RTGC;
	RTHOOK(1);
	loc1 = F1388_13721(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O8598[Dtype(loc1)-1200]);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EV_SCREEN_IMP}.widget_imp_at_pointer_position */
EIF_REFERENCE F1388_13721 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("widget_imp_at_pointer_position", 1387, Current, 4, 0, 19371);
	RTGC;
	RTHOOK(1);
	loc3 = F1222_11228(RTCV(RTOSCF(13788,F1388_13788, (Current))));
	RTHOOK(2);
	loc1 = eif_pointer_item(RTCW(loc3),1);
	RTHOOK(3);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(4);
		gdk_window_get_user_data((GdkWindow*) loc1, (gpointer*) (EIF_POINTER *) &(loc2));
		for (;;) {
			RTHOOK(5);
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(Result != NULL)) {
				tb2 = !loc2;
				tb1 = tb2;
			}
			if (tb1) break;
			RTHOOK(6);
			tr1 = (EIF_REFERENCE) c_ev_any_imp_get_eif_reference_from_object_id((GtkWidget*) loc2);
			loc4 = tr1;
			loc4 = RTRV(eif_new_type(1277, 0x00),loc4);
			if (EIF_TEST(loc4)) {
				RTHOOK(7);
				Result = (EIF_REFERENCE) loc4;
			} else {
				RTHOOK(8);
				tp1 = (EIF_POINTER) gtk_widget_get_parent((GtkWidget*) loc2);
				loc2 = (EIF_POINTER) tp1;
			}
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_SCREEN_IMP}.horizontal_resolution */
EIF_INTEGER_32 F1388_13735 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("horizontal_resolution", 1387, Current, 0, 0, 19385);
	RTGC;
	RTHOOK(1);
	tp1 = inline_F114_1773();
	Result = inline_F114_1768(tp1);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) -1L))) {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 96L);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_SCREEN_IMP}.height */
EIF_INTEGER_32 F1388_13737 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("height", 1387, Current, 0, 0, 19387);
	RTGC;
	RTHOOK(1);
	Result = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(13788,F1388_13788, (Current)))+ _LNGOFF_49_16_0_16_);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_SCREEN_IMP}.width */
EIF_INTEGER_32 F1388_13738 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("width", 1387, Current, 0, 0, 19388);
	RTGC;
	RTHOOK(1);
	Result = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(13788,F1388_13788, (Current)))+ _LNGOFF_49_16_0_15_);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_SCREEN_IMP}.device_x_offset */
EIF_INTEGER_32 F1388_13743 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_);
}


/* {EV_SCREEN_IMP}.device_y_offset */
EIF_INTEGER_32 F1388_13744 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_);
}


/* {EV_SCREEN_IMP}.update_if_needed */
void F1388_13761 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_16 ti2_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("update_if_needed", 1387, Current, 0, 0, 19411);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(13788,F1388_13788, (Current)))+ _LNGOFF_49_16_0_11_);
	ti2_1 = (EIF_INTEGER_16) ti4_1;
	ti4_1 = (EIF_INTEGER_32) (EIF_INTEGER_16) -ti2_1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(13788,F1388_13788, (Current)))+ _LNGOFF_49_16_0_12_);
	ti2_1 = (EIF_INTEGER_16) ti4_1;
	ti4_1 = (EIF_INTEGER_32) (EIF_INTEGER_16) -ti2_1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.clear_rectangle */
void F1388_13762 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTEAA("clear_rectangle", 1387, Current, 2, 4, 19412);
	RTGC;
	RTHOOK(1);
	F1388_13778(Current);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gdk_window_invalidate_rect((GdkWindow*) tp1, (GdkRectangle*) tp3, (gboolean) (EIF_BOOLEAN) 1);
		RTHOOK(4);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		RTHOOK(5);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			RTHOOK(6);
			loc1 = F1245_11644(Current);
		}
		RTHOOK(7);
		loc2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		RTHOOK(8);
		if ((EIF_BOOLEAN)(loc2 == NULL)) {
			RTHOOK(9);
			loc2 = F1245_11645(Current);
		}
		RTHOOK(10);
		tr4_1 = F1096_9423(RTCW(loc2));
		tr8_1 = (EIF_REAL_64) (tr4_1);
		tr4_1 = F1096_9424(RTCW(loc2));
		tr8_2 = (EIF_REAL_64) (tr4_1);
		tr4_1 = F1096_9425(RTCW(loc2));
		tr8_3 = (EIF_REAL_64) (tr4_1);
		F1388_13787(Current, (EIF_BOOLEAN) 1, tr8_1, tr8_2, tr8_3);
		RTHOOK(11);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tp3 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (arg1 + ti4_1),ti4_2);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_1 = eif_min_int32 (ti4_1,ti4_2);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_2 = eif_max_int32 ((EIF_INTEGER_32) (arg2 + ti4_2),ti4_3);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_2 = eif_min_int32 (ti4_2,ti4_3);
		inline_F113_1571(tp1, tp2, tp3, (EIF_BOOLEAN) 1, ti4_1, ti4_2, arg3, arg4);
		RTHOOK(12);
		tr4_1 = F1096_9423(RTCW(loc1));
		tr8_1 = (EIF_REAL_64) (tr4_1);
		tr4_1 = F1096_9424(RTCW(loc1));
		tr8_2 = (EIF_REAL_64) (tr4_1);
		tr4_1 = F1096_9425(RTCW(loc1));
		tr8_3 = (EIF_REAL_64) (tr4_1);
		F1388_13787(Current, (EIF_BOOLEAN) 1, tr8_1, tr8_2, tr8_3);
		RTHOOK(13);
		F1388_13761(Current);
	}
	RTHOOK(14);
	{
		/* INLINED CODE (EV_SCREEN_IMP.post_drawing) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.draw_segment */
void F1388_13763 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_32 ti4_5;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("draw_segment", 1387, Current, 0, 4, 19413);
	RTGC;
	RTHOOK(1);
	F1388_13778(Current);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gdk_window_invalidate_rect((GdkWindow*) tp1, (GdkRectangle*) tp3, (gboolean) (EIF_BOOLEAN) 1);
		RTHOOK(4);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tp3 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (arg1 + ti4_1),ti4_2);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_1 = eif_min_int32 (ti4_1,ti4_2);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_2 = eif_max_int32 ((EIF_INTEGER_32) (arg2 + ti4_2),ti4_3);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_2 = eif_min_int32 (ti4_2,ti4_3);
		ti4_3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_);
		ti4_4 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_3 = eif_max_int32 ((EIF_INTEGER_32) (arg3 + ti4_3),ti4_4);
		ti4_4 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_3 = eif_min_int32 (ti4_3,ti4_4);
		ti4_4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_);
		ti4_5 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_4 = eif_max_int32 ((EIF_INTEGER_32) (arg4 + ti4_4),ti4_5);
		ti4_5 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_4 = eif_min_int32 (ti4_4,ti4_5);
		inline_F113_1568(tp1, tp2, tp3, ti4_1, ti4_2, ti4_3, ti4_4);
		RTHOOK(5);
		F1388_13761(Current);
	}
	RTHOOK(6);
	{
		/* INLINED CODE (EV_SCREEN_IMP.post_drawing) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.draw_ellipse */
void F1388_13764 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("draw_ellipse", 1387, Current, 0, 4, 19414);
	RTGC;
	RTHOOK(1);
	F1388_13778(Current);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	tb4 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tb5 = !tp1;
		tb4 = (EIF_BOOLEAN) !tb5;
	}
	if (tb4) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tb4 = !tp1;
		tb3 = (EIF_BOOLEAN) !tb4;
	}
	if (tb3) {
		tb2 = (EIF_BOOLEAN) (arg3 > ((EIF_INTEGER_32) 0L));
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) (arg4 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gdk_window_invalidate_rect((GdkWindow*) tp1, (GdkRectangle*) tp3, (gboolean) (EIF_BOOLEAN) 1);
		RTHOOK(4);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tp3 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (arg1 + ti4_1),ti4_2);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_1 = eif_min_int32 (ti4_1,ti4_2);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_2 = eif_max_int32 ((EIF_INTEGER_32) (arg2 + ti4_2),ti4_3);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_2 = eif_min_int32 (ti4_2,ti4_3);
		inline_F113_1570(tp1, tp2, tp3, (EIF_BOOLEAN) 0, ti4_1, ti4_2, (EIF_INTEGER_32) (arg3 - ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (arg4 - ((EIF_INTEGER_32) 1L)), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 23040L));
		RTHOOK(5);
		F1388_13761(Current);
	}
	RTHOOK(6);
	{
		/* INLINED CODE (EV_SCREEN_IMP.post_drawing) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.draw_point */
void F1388_13765 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("draw_point", 1387, Current, 0, 2, 19415);
	RTGC;
	RTHOOK(1);
	F1388_13778(Current);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gdk_window_invalidate_rect((GdkWindow*) tp1, (GdkRectangle*) tp3, (gboolean) (EIF_BOOLEAN) 1);
		RTHOOK(4);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tp3 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (arg1 + ti4_1),ti4_2);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_1 = eif_min_int32 (ti4_1,ti4_2);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_2 = eif_max_int32 ((EIF_INTEGER_32) (arg2 + ti4_2),ti4_3);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_2 = eif_min_int32 (ti4_2,ti4_3);
		inline_F113_1569(tp1, tp2, tp3, ti4_1, ti4_2);
		RTHOOK(5);
		F1388_13761(Current);
	}
	RTHOOK(6);
	{
		/* INLINED CODE (EV_SCREEN_IMP.post_drawing) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.fill_rectangle */
void F1388_13769 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("fill_rectangle", 1387, Current, 0, 4, 19419);
	RTGC;
	RTHOOK(1);
	F1388_13778(Current);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gdk_window_invalidate_rect((GdkWindow*) tp1, (GdkRectangle*) tp3, (gboolean) (EIF_BOOLEAN) 1);
		RTHOOK(4);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL)) {
			RTHOOK(5);
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
			tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
			ti4_1 = inline_F113_1538();
			inline_F113_1534(tp1, tp2, ti4_1);
		}
		RTHOOK(6);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tp3 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (arg1 + ti4_1),ti4_2);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_1 = eif_min_int32 (ti4_1,ti4_2);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_2 = eif_max_int32 ((EIF_INTEGER_32) (arg2 + ti4_2),ti4_3);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_2 = eif_min_int32 (ti4_2,ti4_3);
		inline_F113_1571(tp1, tp2, tp3, (EIF_BOOLEAN) 1, ti4_1, ti4_2, arg3, arg4);
		RTHOOK(7);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		ti4_1 = inline_F113_1537();
		inline_F113_1534(tp1, tp2, ti4_1);
		RTHOOK(8);
		F1388_13761(Current);
	}
	RTHOOK(9);
	{
		/* INLINED CODE (EV_SCREEN_IMP.post_drawing) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.fill_ellipse */
void F1388_13770 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("fill_ellipse", 1387, Current, 0, 4, 19420);
	RTGC;
	RTHOOK(1);
	F1388_13778(Current);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gdk_window_invalidate_rect((GdkWindow*) tp1, (GdkRectangle*) tp3, (gboolean) (EIF_BOOLEAN) 1);
		RTHOOK(4);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL)) {
			RTHOOK(5);
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
			tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
			ti4_1 = inline_F113_1538();
			inline_F113_1534(tp1, tp2, ti4_1);
		}
		RTHOOK(6);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tp3 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (arg1 + ti4_1),ti4_2);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_1 = eif_min_int32 (ti4_1,ti4_2);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_2 = eif_max_int32 ((EIF_INTEGER_32) (arg2 + ti4_2),ti4_3);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_2 = eif_min_int32 (ti4_2,ti4_3);
		inline_F113_1570(tp1, tp2, tp3, (EIF_BOOLEAN) 1, ti4_1, ti4_2, arg3, arg4, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 23040L));
		RTHOOK(7);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		ti4_1 = inline_F113_1537();
		inline_F113_1534(tp1, tp2, ti4_1);
		RTHOOK(8);
		F1388_13761(Current);
	}
	RTHOOK(9);
	{
		/* INLINED CODE (EV_SCREEN_IMP.post_drawing) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.start_drawing_session */
void F1388_13773 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("start_drawing_session", 1387, Current, 0, 0, 19423);
	RTGC;
	RTHOOK(1);
	F1388_13711(Current);
	RTHOOK(2);
	F1381_13511(Current);
	RTHOOK(3);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_) = (EIF_POINTER) tp2;
	RTHOOK(4);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_) = (EIF_POINTER) tp2;
	RTHOOK(5);
	F1388_13775(Current);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.end_drawing_session */
void F1388_13774 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("end_drawing_session", 1387, Current, 0, 0, 19424);
	RTGC;
	
	RTHOOK(2);
	F1388_13711(Current);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(4);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		inline_F113_1536(tp1);
	}
	RTHOOK(5);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_) = (EIF_POINTER) tp2;
	RTHOOK(6);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_) = (EIF_POINTER) tp2;
	RTHOOK(7);
	F1381_13512(Current);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.get_drawable_x_display_and_window */
void F1388_13775 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_drawable_x_display_and_window", 1387, Current, 0, 0, 19425);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb2 = '\01';
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tb3 = !tp1;
		if (!tb3) {
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
			tb3 = !tp1;
			tb2 = tb3;
		}
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		tp1 = inline_F113_1529(tp1);
		*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_) = (EIF_POINTER) tp1;
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		tp1 = inline_F113_1528(tp1);
		*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_) = (EIF_POINTER) tp1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.pre_drawing */
void F1388_13778 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pre_drawing", 1387, Current, 0, 0, 19428);
	RTGC;
	RTHOOK(1);
	F1388_13711(Current);
	RTHOOK(2);
	F1388_13775(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.post_drawing */
void F1388_13779 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("post_drawing", 1387, Current, 0, 0, 19429);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.set_drawing_mode */
void F1388_13781 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_drawing_mode", 1387, Current, 3, 1, 19431);
	RTGC;
	RTHOOK(1);
	F1388_13711(Current);
	RTHOOK(2);
	F1386_13616(Current, arg1);
	RTHOOK(3);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		RTHOOK(4);
		loc1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		RTHOOK(5);
		loc2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		RTHOOK(6);
		tb1 = '\0';
		tb2 = !loc1;
		if ((EIF_BOOLEAN) !tb2) {
			tb2 = !loc2;
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			RTHOOK(7);
			loc3 = inline_F113_1528(loc2);
			RTHOOK(8);
			switch (arg1) {
				case 0L:
					RTHOOK(9);
					ti4_1 = inline_F113_1555();
					inline_F113_1530(loc3, loc1, ti4_1);
					break;
				case 3L:
					RTHOOK(10);
					ti4_1 = inline_F113_1553();
					inline_F113_1530(loc3, loc1, ti4_1);
					break;
				case 1L:
					RTHOOK(11);
					ti4_1 = inline_F113_1558();
					inline_F113_1530(loc3, loc1, ti4_1);
					break;
				case 2L:
					RTHOOK(12);
					ti4_1 = inline_F113_1562();
					inline_F113_1530(loc3, loc1, ti4_1);
					break;
				case 4L:
					RTHOOK(13);
					ti4_1 = inline_F113_1559();
					inline_F113_1530(loc3, loc1, ti4_1);
					break;
				default:
					
					RTHOOK(15);
					ti4_1 = inline_F113_1555();
					inline_F113_1530(loc3, loc1, ti4_1);
					break;
			}
		}
	}
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.set_line_width */
void F1388_13782 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_line_width", 1387, Current, 0, 1, 19432);
	RTGC;
	RTHOOK(1);
	F1388_13711(Current);
	RTHOOK(2);
	F1386_13615(Current, arg1);
	RTHOOK(3);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(4);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_)) {
			RTHOOK(5);
			tr1 = RTLNS(eif_new_type(112, 0x00).id, 112, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F113_1526(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_), arg1);
		} else {
			RTHOOK(6);
			tr1 = RTLNS(eif_new_type(112, 0x00).id, 112, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F113_1525(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_), arg1);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.enable_dashed_line_style */
void F1388_13783 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_dashed_line_style", 1387, Current, 0, 0, 19433);
	RTGC;
	RTHOOK(1);
	F1388_13711(Current);
	RTHOOK(2);
	F1386_13623(Current);
	RTHOOK(3);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(4);
		tr1 = RTLNS(eif_new_type(112, 0x00).id, 112, _OBJSIZ_0_0_0_0_0_0_0_0_);
		F113_1526(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_2_));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.disable_dashed_line_style */
void F1388_13784 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("disable_dashed_line_style", 1387, Current, 0, 0, 19434);
	RTGC;
	RTHOOK(1);
	F1388_13711(Current);
	RTHOOK(2);
	F1386_13624(Current);
	RTHOOK(3);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(4);
		tr1 = RTLNS(eif_new_type(112, 0x00).id, 112, _OBJSIZ_0_0_0_0_0_0_0_0_);
		F113_1525(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_2_));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.internal_set_color */
void F1388_13787 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("internal_set_color", 1387, Current, 3, 4, 19437);
	RTGC;
	RTHOOK(1);
	F1388_13711(Current);
	RTHOOK(2);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		RTHOOK(3);
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 65535L));
		tr1 = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)tr1 = (EIF_REAL_64) (arg2 * tr8_1);
		loc1 = F990_8138(RTCW(tr1));
		RTHOOK(4);
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 65535L));
		tr1 = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)tr1 = (EIF_REAL_64) (arg3 * tr8_1);
		loc2 = F990_8138(RTCW(tr1));
		RTHOOK(5);
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 65535L));
		tr1 = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)tr1 = (EIF_REAL_64) (arg4 * tr8_1);
		loc3 = F990_8138(RTCW(tr1));
		RTHOOK(6);
		if (arg1) {
			RTHOOK(7);
			tr1 = RTLNS(eif_new_type(112, 0x00).id, 112, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F113_1549(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_), loc1, loc2, loc3);
		} else {
			RTHOOK(8);
			tr1 = RTLNS(eif_new_type(112, 0x00).id, 112, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F113_1548(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_), loc1, loc2, loc3);
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_SCREEN_IMP}.app_implementation */
static EIF_REFERENCE F1388_13788_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("app_implementation", 1387, Current, 1, 0, 19438);
	RTGC;
	RTOSP (13788);
#define Result RTOSR(13788)
	RTOC_NEW(Result);
	RTHOOK(1);
	RTCT0("attached {EV_APPLICATION_IMP} (create {EV_ENVIRONMENT}).implementation.application_i as l_result", EX_CHECK);
	tr1 = RTLNS(eif_new_type(1098, 0x00).id, 1098, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1091_9344(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	tr1 = F1219_10984(RTCW(tr1));
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1221, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	Result = (EIF_REFERENCE) loc1;
	RTOSE (13788);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1388_13788 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13788,F1388_13788_body,(Current));
}

/* {EV_SCREEN_IMP}.destroy */
void F1388_13789 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("destroy", 1387, Current, 0, 0, 19439);
	RTHOOK(1);
	F1201_10659(Current, (EIF_BOOLEAN) 1);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit740 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
