
#ifndef _C15_ev721_
#define _C15_ev721_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1369_13334(EIF_REFERENCE);
extern void EIF_Minit721(void);
extern EIF_REFERENCE F1363_13320(EIF_REFERENCE);
extern long O8598[];

#ifdef __cplusplus
}
#endif

#endif
