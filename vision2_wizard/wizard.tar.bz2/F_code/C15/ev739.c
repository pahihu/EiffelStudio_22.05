/*
 * Code for class EV_DRAWING_AREA_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev739.h"
#include <ev_gtk.h>
#include <cairo.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F115_2025
static void inline_F115_2025 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	gtk_widget_set_size_request ((GtkWidget*) arg1, (gint) arg2, (gint) arg3)
	;
}
#define INLINE_F115_2025
#endif
#ifndef INLINE_F35_594
static void inline_F35_594 (EIF_POINTER arg1)
{
	cairo_surface_destroy((cairo_surface_t*) arg1)
	;
}
#define INLINE_F35_594
#endif
#ifndef INLINE_F114_1649
static EIF_POINTER inline_F114_1649 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	return gdk_window_create_similar_surface ((GdkWindow *)arg1,
                                   (cairo_content_t)arg2,
                                   (int)arg3,
                                   (int)arg4);
	;
}
#define INLINE_F114_1649
#endif
#ifndef INLINE_F35_637
static void inline_F35_637 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	double len = 2.0;
if (arg2) {
	cairo_set_dash ((cairo_t *) arg1, &len, 1, 0.0);
} else {
	cairo_set_dash ((cairo_t *) arg1, NULL, 0, 0.0);
}
	;
}
#define INLINE_F35_637
#endif
#ifndef INLINE_F35_652
static void inline_F35_652 (EIF_POINTER arg1)
{
	cairo_paint ((cairo_t*)arg1)
	;
}
#define INLINE_F35_652
#endif
#ifndef INLINE_F117_2405
static void inline_F117_2405 (EIF_POINTER arg1)
{
	gtk_widget_queue_draw ((GtkWidget *)arg1)
	;
}
#define INLINE_F117_2405
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DRAWING_AREA_IMP}.make */
void F1387_13678 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTEAA("make", 1386, Current, 4, 0, 19333);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_POINTER) gtk_drawing_area_new();
	RTHOOK(2);
	inline_F115_2025(loc1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	RTHOOK(3);
	F1227_11344(Current, loc1);
	RTHOOK(4);
	loc2 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_0_);
	RTHOOK(5);
	gtk_widget_set_redraw_on_allocate((GtkWidget*) loc2, (gboolean) (EIF_BOOLEAN) 0);
	RTHOOK(6);
	gtk_widget_set_app_paintable((GtkWidget*) loc2, (gboolean) (EIF_BOOLEAN) 1);
	RTHOOK(7);
	loc3 = RTOSCF(11369,F1227_11369, (Current));
	RTHOOK(8);
	tr1 = RTOSCF(508,F34_508, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,973,936,1045,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = loc2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1052,0xFFF9,1,973,1045,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A365_330_3, (EIF_POINTER) _A365_330_3, (EIF_POINTER)(F935_7366),tr2, 1, 1);
	}
	F1227_11348(Current, loc2, tr1, tr5);
	RTHOOK(9);
	tr1 = RTOSCF(534,F34_534, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,973,936,1045,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = loc1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1052,0xFFF9,1,973,1045,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A365_331_3, (EIF_POINTER) _A365_331_3, (EIF_POINTER)(F935_7367),tr2, 1, 1);
	}
	F1227_11348(Current, loc2, tr1, tr5);
	RTHOOK(10);
	tr1 = RTOSCF(522,F34_522, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,973,936,1045,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = loc2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1052,0xFFF9,1,973,1045,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A365_329_3, (EIF_POINTER) _A365_329_3, (EIF_POINTER)(F935_7365),tr2, 1, 1);
	}
	F1227_11349(Current, loc2, tr1, tr5);
	
	RTHOOK(12);
	F1386_13589(Current);
	RTHOOK(13);
	tr1 = F1245_11645(Current);
	F1246_11656(Current, loc2, tr1);
	RTHOOK(14);
	tb1 = '\0';
	tb2 = '\0';
	loc4 = F1227_11368(Current);
	if ((EIF_TRUE)) {
		tb3 = !loc4;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN)(loc4 != loc2);
	}
	if (tb1) {
		RTHOOK(15);
		tr1 = F1245_11645(Current);
		F1246_11656(Current, loc4, tr1);
	}
	RTHOOK(16);
	F1332_12698(Current);
	RTHOOK(17);
	F1332_12704(Current);
	RTHOOK(18);
	F1332_12706(Current);
	RTHOOK(19);
	RTLE;
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.destroy */
void F1387_13679 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("destroy", 1386, Current, 0, 0, 19334);
	RTGC;
	RTHOOK(1);
	F1386_13660(Current);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		F1387_13690(Current, *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_));
		RTHOOK(4);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_) = (EIF_POINTER) tp2;
	}
	RTHOOK(5);
	F1278_12020(Current);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.c_object_dispose */
void F1387_13680 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_object_dispose", 1386, Current, 0, 0, 19335);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_);
		cairo_destroy((cairo_t*) tp1);
		RTHOOK(3);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_) = (EIF_POINTER) tp2;
	}
	RTHOOK(4);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(5);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
		inline_F35_594(tp1);
		RTHOOK(6);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_) = (EIF_POINTER) tp2;
	}
	RTHOOK(7);
	F1227_11359(Current);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.start_transparency */
void F1387_13681 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("start_transparency", 1386, Current, 1, 1, 19336);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_);
	RTHOOK(2);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		F1386_13626(Current, arg1);
		RTHOOK(4);
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 1L));
		tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 1L));
		tr8_3 = (EIF_REAL_64) (((EIF_INTEGER_32) 1L));
		cairo_set_source_rgba((cairo_t*) loc1, (double) tr8_1, (double) tr8_2, (double) tr8_3, (double) arg1);
		RTHOOK(5);
		ti1_1 = (EIF_INTEGER_8) CAIRO_OPERATOR_SOURCE;
		cairo_set_operator((cairo_t*) loc1, (cairo_operator_t) ti1_1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.stop_transparency */
void F1387_13682 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("stop_transparency", 1386, Current, 1, 0, 19337);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_);
	RTHOOK(2);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		ti1_1 = (EIF_INTEGER_8) CAIRO_OPERATOR_OVER;
		cairo_set_operator((cairo_t*) loc1, (cairo_operator_t) ti1_1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.pre_drawing */
void F1387_13683 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pre_drawing", 1386, Current, 1, 0, 19338);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1381_13508(Current)) {
		RTHOOK(2);
		F1387_13689(Current);
		RTHOOK(3);
		loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_);
		RTHOOK(4);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(5);
			cairo_save((cairo_t*) loc1);
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.post_drawing */
void F1387_13684 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("post_drawing", 1386, Current, 1, 0, 19339);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1381_13508(Current)) {
		RTHOOK(2);
		loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_);
		RTHOOK(3);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(4);
			cairo_restore((cairo_t*) loc1);
		}
		RTHOOK(5);
		F1387_13704(Current);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.start_drawing_session */
void F1387_13685 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("start_drawing_session", 1386, Current, 0, 0, 19340);
	RTGC;
	RTHOOK(1);
	F1381_13511(Current);
	RTHOOK(2);
	if (F1381_13509(Current)) {
		RTHOOK(3);
		F1386_13594(Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.end_drawing_session */
void F1387_13686 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("end_drawing_session", 1386, Current, 0, 0, 19341);
	RTGC;
	RTHOOK(1);
	if (F1381_13509(Current)) {
		RTHOOK(2);
		F1386_13660(Current);
		RTHOOK(3);
		F1387_13704(Current);
	}
	RTHOOK(4);
	F1381_13512(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.get_new_cairo_surface */
void F1387_13688 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_new_cairo_surface", 1386, Current, 5, 2, 19343);
	RTGC;
	
	RTHOOK(2);
	loc2 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_0_);
	RTHOOK(3);
	loc3 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) loc2);
	RTHOOK(4);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc3 != tp1)) {
		RTHOOK(5);
		loc4 = (EIF_INTEGER_32) gtk_widget_get_allocated_width((GtkWidget*) loc2);
		RTHOOK(6);
		loc5 = (EIF_INTEGER_32) gtk_widget_get_allocated_height((GtkWidget*) loc2);
		
		
		RTHOOK(9);
		ti4_1 = (EIF_INTEGER_32) CAIRO_CONTENT_COLOR_ALPHA;
		loc1 = inline_F114_1649(loc3, ti4_1, loc4, loc5);
		RTHOOK(10);
		*(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_) = (EIF_POINTER) loc1;
	} else {
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.get_cairo_context */
void F1387_13689 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_cairo_context", 1386, Current, 2, 0, 19344);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_);
	RTHOOK(2);
	tb1 = !loc2;
	if (tb1) {
		RTHOOK(3);
		loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
		RTHOOK(4);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(5);
			loc2 = (EIF_POINTER) cairo_create((cairo_surface_t*) loc1);
			RTHOOK(6);
			F1387_13691(Current, loc2);
			RTHOOK(7);
			*(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_) = (EIF_POINTER) loc2;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.release_cairo_surface */
void F1387_13690 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("release_cairo_surface", 1386, Current, 0, 1, 19345);
	RTGC;
	RTHOOK(1);
	tb1 = !arg1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(2);
		inline_F35_594(arg1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.initialize_cairo_context */
void F1387_13691 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("initialize_cairo_context", 1386, Current, 1, 1, 19346);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current+ _CHROFF_48_17_);
	cairo_set_antialias((cairo_t*) arg1, (cairo_antialias_t) ti1_1);
	RTHOOK(2);
	ti1_1 = *(EIF_INTEGER_8 *)(Current+ _CHROFF_48_18_);
	cairo_set_line_cap((cairo_t*) arg1, (cairo_line_cap_t) ti1_1);
	RTHOOK(3);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_48_19_10_8_);
	tr8_1 = (EIF_REAL_64) (ti4_1);
	cairo_set_line_width((cairo_t*) arg1, (double) tr8_1);
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(5);
		tr4_1 = F1096_9423(loc1);
		tr8_1 = (EIF_REAL_64) (tr4_1);
		tr4_1 = F1096_9424(loc1);
		tr8_2 = (EIF_REAL_64) (tr4_1);
		tr4_1 = F1096_9425(loc1);
		tr8_3 = (EIF_REAL_64) (tr4_1);
		cairo_set_source_rgb((cairo_t*) arg1, (double) tr8_1, (double) tr8_2, (double) tr8_3);
	} else {
		RTHOOK(6);
		cairo_set_source_rgb((cairo_t*) arg1, (double) (EIF_REAL_64) 0.0, (double) (EIF_REAL_64) 0.0, (double) (EIF_REAL_64) 0.0);
	}
	RTHOOK(7);
	ti1_1 = F1386_13617(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_48_19_10_7_));
	cairo_set_operator((cairo_t*) arg1, (cairo_operator_t) ti1_1);
	RTHOOK(8);
	tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_48_13_);
	inline_F35_637(arg1, tb1);
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.process_draw_event */
EIF_BOOLEAN F1387_13693 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 loc1 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc2 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc3 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc4 = (EIF_REAL_64) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc6);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("process_draw_event", 1386, Current, 6, 1, 19348);
	RTGC;
	
	RTHOOK(2);
	loc5 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
	RTHOOK(3);
	tb1 = !loc5;
	if (tb1) {
		
	} else {
		RTHOOK(5);
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		cairo_set_source_surface((cairo_t*) arg1, (cairo_surface_t*) loc5, (double) tr8_1, (double) tr8_2);
		RTHOOK(6);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			tb2 = F506_5267(loc6);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			RTHOOK(7);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_48_14_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(8);
			cairo_clip_extents((cairo_t*) arg1, (double*) (EIF_REAL_64 *) &(loc1), (double*) (EIF_REAL_64 *) &(loc2), (double*) (EIF_REAL_64 *) &(loc3), (double*) (EIF_REAL_64 *) &(loc4));
			RTHOOK(9);
			F1387_13685(Current);
			RTHOOK(10);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,973,1006,1006,1006,1006,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				tr1 = RTLNTS(typres0.id, 5, 1);
			}
			ti4_1 = (EIF_INTEGER_32) loc1;
			((EIF_TYPED_VALUE *)tr1+1)->it_i4 = ti4_1;
			ti4_1 = (EIF_INTEGER_32) loc2;
			((EIF_TYPED_VALUE *)tr1+2)->it_i4 = ti4_1;
			ti4_1 = (EIF_INTEGER_32) loc3;
			((EIF_TYPED_VALUE *)tr1+3)->it_i4 = ti4_1;
			ti4_1 = (EIF_INTEGER_32) loc4;
			((EIF_TYPED_VALUE *)tr1+4)->it_i4 = ti4_1;
			F712_6079(loc6, tr1);
			RTHOOK(11);
			F1387_13686(Current);
			RTHOOK(12);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_48_14_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		RTHOOK(13);
		inline_F35_652(arg1);
	}
	RTHOOK(14);
	RTHOOK(15);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_DRAWING_AREA_IMP}.process_configure_event */
EIF_BOOLEAN F1387_13694 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_16 ti2_1;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("process_configure_event", 1386, Current, 3, 4, 19349);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	tb2 = '\01';
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
	tb3 = !tp1;
	if (!tb3) {
		ti2_1 = *(EIF_INTEGER_16 *)(Current+ _I16OFF_48_19_8_);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		tb2 = (EIF_BOOLEAN)(arg3 != ti4_1);
	}
	if (!tb2) {
		ti2_1 = *(EIF_INTEGER_16 *)(Current+ _I16OFF_48_19_9_);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		tb1 = (EIF_BOOLEAN)(arg4 != ti4_1);
	}
	if (tb1) {
		RTHOOK(2);
		F1386_13660(Current);
		RTHOOK(3);
		loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
		RTHOOK(4);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(5);
			cairo_surface_flush((cairo_surface_t*) loc1);
			RTHOOK(6);
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			tp2 = tp1;
			*(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_) = (EIF_POINTER) tp2;
			RTHOOK(7);
			F1387_13688(Current, arg3, arg4);
			RTHOOK(8);
			loc2 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
			RTHOOK(9);
			loc3 = (EIF_POINTER) cairo_create((cairo_surface_t*) loc2);
			RTHOOK(10);
			tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
			tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
			cairo_set_source_surface((cairo_t*) loc3, (cairo_surface_t*) loc1, (double) tr8_1, (double) tr8_2);
			RTHOOK(11);
			ti1_1 = (EIF_INTEGER_8) CAIRO_OPERATOR_SOURCE;
			cairo_set_operator((cairo_t*) loc3, (cairo_operator_t) ti1_1);
			RTHOOK(12);
			inline_F35_652(loc3);
			RTHOOK(13);
			F1386_13659(Current, loc3);
			RTHOOK(14);
			F1387_13690(Current, loc1);
		}
		RTHOOK(15);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
		tb1 = !tp1;
		if (tb1) {
			RTHOOK(16);
			F1387_13688(Current, arg3, arg4);
		}
	}
	RTHOOK(17);
	RTHOOK(18);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_DRAWING_AREA_IMP}.process_button_event */
void F1387_13695 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("process_button_event", 1386, Current, 3, 2, 19350);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(11369,F1227_11369, (Current));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(2);
		tr8_1 = (EIF_REAL_64) (((GdkEventButton *)arg1)->x_root);
		loc1 = (EIF_INTEGER_32) tr8_1;
		ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_49_16_0_11_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ti4_1);
		RTHOOK(3);
		tr8_1 = (EIF_REAL_64) (((GdkEventButton *)arg1)->y_root);
		loc2 = (EIF_INTEGER_32) tr8_1;
		ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_49_16_0_12_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ti4_1);
		RTHOOK(4);
		ti4_1 = (EIF_INTEGER_32) (((GdkEventButton *)arg1)->type);
		tr8_1 = (EIF_REAL_64) (((GdkEventButton *)arg1)->x);
		ti4_2 = (EIF_INTEGER_32) tr8_1;
		tr8_1 = (EIF_REAL_64) (((GdkEventButton *)arg1)->y);
		ti4_3 = (EIF_INTEGER_32) tr8_1;
		ti4_4 = (EIF_INTEGER_32) (((GdkEventButton *)arg1)->button);
		F1276_11942(Current, ti4_1, ti4_2, ti4_3, ti4_4, (EIF_REAL_64) 0.5, (EIF_REAL_64) 0.5, (EIF_REAL_64) 0.5, loc1, loc2);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.process_scroll_event */
EIF_BOOLEAN F1387_13696 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("process_scroll_event", 1386, Current, 1, 1, 19351);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkEventScroll *)arg1)->direction) == (EIF_INTEGER_32) GDK_SCROLL_UP)) {
		RTHOOK(2);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	} else {
		RTHOOK(3);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	}
	RTHOOK(4);
	ti4_1 = (EIF_INTEGER_32) GDK_BUTTON_PRESS;
	F1387_13706(Current, ti4_1, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc1, (EIF_REAL_64) 0.5, (EIF_REAL_64) 0.5, (EIF_REAL_64) 0.5, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	RTHOOK(5);
	RTHOOK(6);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_DRAWING_AREA_IMP}.button_actions_handled_by_signals */
EIF_BOOLEAN F1387_13697 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("button_actions_handled_by_signals", 1386, Current, 0, 0, 19352);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_DRAWING_AREA_IMP}.on_size_allocate */
void F1387_13698 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	
	
	RTEAA("on_size_allocate", 1386, Current, 0, 4, 19353);
	RTHOOK(1);
	F1278_11993(Current, arg1, arg2, arg3, arg4);
	RTHOOK(2);
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.update_if_needed */
void F1387_13704 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("update_if_needed", 1386, Current, 0, 0, 19328);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_48_14_)) {
		RTHOOK(2);
		tp1 = F1227_11368(Current);
		inline_F117_2405(tp1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.internal_set_focus */
void F1387_13705 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("internal_set_focus", 1386, Current, 1, 0, 19329);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_0_);
	loc1 = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_can_focus((GtkWidget*) tp1));
	RTHOOK(2);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_0_);
		gtk_widget_set_can_focus((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	}
	RTHOOK(4);
	F1228_11394(Current);
	RTHOOK(5);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(6);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_0_);
		gtk_widget_set_can_focus((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_DRAWING_AREA_IMP}.call_button_event_actions */
void F1387_13706 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("call_button_event_actions", 1386, Current, 0, 9, 19330);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_PRESS)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_0_);
		tb3 = (EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_widget_has_focus((GtkWidget*) tp1));
	}
	if (tb3) {
		tb2 = (EIF_BOOLEAN) ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN) (arg4 <= ((EIF_INTEGER_32) 3L)));
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_48_11_);
	}
	if (tb1) {
		RTHOOK(2);
		F1228_11393(Current);
	}
	RTHOOK(3);
	F1278_11996(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit739 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
