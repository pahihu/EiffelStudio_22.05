/*
 * Code for class EV_TOOL_BAR_SEPARATOR_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev716.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TOOL_BAR_SEPARATOR_IMP}.needs_event_box */
EIF_BOOLEAN F1364_13326 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("needs_event_box", 1363, Current, 0, 0, 19067);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_TOOL_BAR_SEPARATOR_IMP}.is_dockable */
EIF_BOOLEAN F1364_13327 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

/* {EV_TOOL_BAR_SEPARATOR_IMP}.make */
void F1364_13329 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 1363, Current, 0, 0, 19070);
	RTGC;
	RTHOOK(1);
	tp1 = (EIF_POINTER) gtk_separator_tool_item_new();
	F1227_11344(Current, tp1);
	RTHOOK(2);
	F1228_11371(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit716 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
