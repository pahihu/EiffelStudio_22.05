
#ifndef _C15_ev716_
#define _C15_ev716_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1364_13326(EIF_REFERENCE);
extern EIF_BOOLEAN F1364_13327(EIF_REFERENCE);
extern void F1364_13329(EIF_REFERENCE);
extern void EIF_Minit716(void);
extern void F1228_11371(EIF_REFERENCE);
extern void F1227_11344(EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif

#endif
