/*
 * Code for class EV_MENU_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev726.h"
#include <ev_gtk.h>
#include "ev_any_imp.h"
#include "ev_c_util.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1374_13389
static void inline_F1374_13389 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	g_object_set_data (
    G_OBJECT (arg1),
    "eif_oid",
    (gpointer) (rt_int_ptr) arg2
);
	;
}
#define INLINE_F1374_13389
#endif
#ifndef INLINE_F1374_13390
static void inline_F1374_13390 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_NATURAL_32 arg5)
{
	{
     /* From: https://git.eclipse.org/c/platform/eclipse.platform.swt.git/commit/?id=7714fdbf1ce0110744da9c164486c12254d5bd6f
	 *  GTK Feature: gtk_menu_popup is deprecated as of GTK3.22 and the new method gtk_menu_popup_at_pointer
	 *  requires an event to hook on to. This requires the popup & events related to the menu be handled
	 *  immediately and not as a post event in display, requiring the current event.
	 */
	GdkEvent *event_ptr = gtk_get_current_event();
	if (event_ptr == NULL) {
		GdkEvent *event = gdk_event_new (GDK_BUTTON_PRESS);
		((GdkEventButton*)event)->time = (guint32) arg5;
		((GdkEventButton*)event)->x = (gdouble) arg2;
		((GdkEventButton*)event)->y = (gdouble) arg3;
		((GdkEventButton*)event)->type = GDK_BUTTON_PRESS;
		((GdkEventButton*)event)->button = (guint) arg4;
		gtk_widget_realize (arg1);
		((GdkEventButton*)event)->window = g_object_ref((GdkWindow*) gtk_widget_get_window ((GtkWidget*) arg1));
		((GdkEventButton*)event)->device = (GdkDevice*) gdk_seat_get_pointer ((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default ()));
		gtk_menu_popup_at_pointer ((GtkMenu*) arg1, event);
		gdk_event_free (event);
	} else {
		gtk_menu_popup_at_pointer ((GtkMenu*) arg1, event_ptr);
		gdk_event_free (event_ptr);
	}	
}
	;
}
#define INLINE_F1374_13390
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MENU_IMP}.make */
void F1374_13386 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 1373, Current, 0, 0, 19127);
	RTGC;
	RTHOOK(1);
	F1370_13340(Current);
	RTHOOK(2);
	tp1 = (EIF_POINTER) gtk_menu_new();
	*(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_) = (EIF_POINTER) tp1;
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
	gtk_widget_show((GtkWidget*) tp1);
	RTHOOK(4);
	tp1 = F1370_13346(Current);
	gtk_widget_show((GtkWidget*) tp1);
	RTHOOK(5);
	tp1 = F1370_13346(Current);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
	gtk_menu_item_set_submenu((GtkMenuItem*) tp1, (GtkWidget*) tp2);
	RTHOOK(6);
	F1233_11526(Current);
	RTHOOK(7);
	F1260_11745(Current);
	RTHOOK(8);
	F1370_13347(Current);
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_MENU_IMP}.show_at */
void F1374_13388 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("show_at", 1373, Current, 2, 3, 19129);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (F1233_11528(Current) > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			RTHOOK(3);
			loc1 = F1114_9695(RTCW(arg1));
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + arg2);
			RTHOOK(4);
			loc2 = F1114_9696(RTCW(arg1));
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + arg3);
		} else {
			RTHOOK(5);
			loc1 = (EIF_INTEGER_32) arg2;
			RTHOOK(6);
			loc2 = (EIF_INTEGER_32) arg3;
		}
		RTHOOK(7);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(11369,F1227_11369, (Current)))+ _LNGOFF_49_16_0_11_);
		loc1 -= ti4_1;
		RTHOOK(8);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(11369,F1227_11369, (Current)))+ _LNGOFF_49_16_0_12_);
		loc2 -= ti4_1;
		RTHOOK(9);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
		ti4_1 = F932_7311(Current);
		inline_F1374_13389(tp1, ti4_1);
		RTHOOK(10);
		tr1 = RTOSCF(11369,F1227_11369, (Current));
		F1222_11136(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_12_));
		RTHOOK(11);
		tr1 = RTOSCF(11369,F1227_11369, (Current));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,6,973,0,1045,1006,1006,1006,979,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 7, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
		((EIF_TYPED_VALUE *)tr2+2)->it_p = tp1;
		((EIF_TYPED_VALUE *)tr2+3)->it_i4 = loc1;
		((EIF_TYPED_VALUE *)tr2+4)->it_i4 = loc2;
		((EIF_TYPED_VALUE *)tr2+5)->it_i4 = ((EIF_INTEGER_32) 0L);
		tu4_1 = (EIF_NATURAL_32) gtk_get_current_event_time();
		((EIF_TYPED_VALUE *)tr2+6)->it_n4 = tu4_1;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,0,973,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3= RTLNRF(typres0.id, (EIF_POINTER) __A726_326, (EIF_POINTER) _A726_326, (EIF_POINTER)(F1374_13390),tr2, 1, 0);
		}
		F1221_11061(RTCW(tr1), tr3);
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {EV_MENU_IMP}.couple_object_id_with_gtk_object */
void F1374_13389 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("couple_object_id_with_gtk_object", 1373, Current, 0, 2, 19130);
	inline_F1374_13389 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_MENU_IMP}.c_gtk_menu_popup_at_pointer */
void F1374_13390 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_NATURAL_32 arg5)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_gtk_menu_popup_at_pointer", 1373, Current, 0, 5, 19131);
	inline_F1374_13390 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4, (EIF_NATURAL_32) arg5);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_MENU_IMP}.on_activate */
void F1374_13391 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("on_activate", 1373, Current, 1, 0, 19132);
	RTGC;
	RTHOOK(1);
	loc1 = F1363_13320(Current);
	loc1 = RTRV(eif_new_type(1237, 0x00), loc1);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			RTHOOK(4);
			tr1 = F75_1251(RTCW(loc1));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y8598,Y8598_gen_type,Dftype(Current),1200);
					typarr0[3] = l_type.annotations | 0xFF00;
					typarr0[4] = l_type.id;
				}
				
				typres0 = eif_compound_id(Dftype(Current), typarr0);
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F1201_10644(Current);
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			F712_6079(RTCW(tr1), tr2);
		}
	}
	RTHOOK(5);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F712_6079(RTCW(tr1), NULL);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_MENU_IMP}.list_widget */
EIF_POINTER F1374_13393 (EIF_REFERENCE Current)
{
	return *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
}


/* {EV_MENU_IMP}.destroy */
void F1374_13394 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("destroy", 1373, Current, 0, 0, 19125);
	RTGC;
	RTHOOK(1);
	F1232_11522(Current);
	RTHOOK(2);
	F1363_13321(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit726 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
