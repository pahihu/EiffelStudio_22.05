
#ifndef _C15_ev702_
#define _C15_ev702_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1350_13155(EIF_REFERENCE);
extern void EIF_Minit702(void);
extern void F1348_13091(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
