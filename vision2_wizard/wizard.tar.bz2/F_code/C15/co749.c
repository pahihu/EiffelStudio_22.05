/*
 * Code for class CONSOLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co749.h"
#include "eif_console.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONSOLE}.make_open_stdout */
void F1397_13900 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("make_open_stdout", 1396, Current, 0, 1, 19551);
	RTGC;
	RTHOOK(1);
	F931_7247(Current, arg1);
	RTHOOK(2);
	tp1 = (EIF_POINTER) console_def(((EIF_INTEGER_32) 1L));
	*(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_) = (EIF_POINTER) tp1;
	RTHOOK(3);
	F929_7193(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONSOLE}.make_open_stderr */
void F1397_13901 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("make_open_stderr", 1396, Current, 0, 1, 19552);
	RTGC;
	RTHOOK(1);
	F931_7247(Current, arg1);
	RTHOOK(2);
	tp1 = (EIF_POINTER) console_def(((EIF_INTEGER_32) 2L));
	*(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_) = (EIF_POINTER) tp1;
	RTHOOK(3);
	F929_7193(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONSOLE}.default_encoding */
static EIF_REFERENCE F1397_13902_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	

	
	RTEAA("default_encoding", 1396, Current, 0, 0, 19553);
	RTOSP (13902);
#define Result RTOSR(13902)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(147, 0x00).id, 147, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = RTOSCF(3135,F148_3135, (RTCW(tr1)));
	RTOSE (13902);
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1397_13902 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13902,F1397_13902_body,(Current));
}

/* {CONSOLE}.end_of_file */
EIF_BOOLEAN F1397_13904 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("end_of_file", 1396, Current, 0, 0, 19555);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) EIF_TEST(console_eof((FILE*) tp1));
}

/* {CONSOLE}.exists */
EIF_BOOLEAN F1397_13905 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("exists", 1396, Current, 0, 0, 19556);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {CONSOLE}.count */
EIF_INTEGER_32 F1397_13906 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
}

/* {CONSOLE}.dispose */
void F1397_13907 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dispose", 1396, Current, 0, 0, 19558);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CONSOLE}.back */
void F1397_13908 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("back", 1396, Current, 0, 0, 19559);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CONSOLE}.new_cursor */
EIF_REFERENCE F1397_13909 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("new_cursor", 1396, Current, 0, 0, 19560);
	RTGC;
	RTHOOK(1);
	if (F929_7026(Current)) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(924, 0x00).id, 924, _OBJSIZ_0_1_0_0_0_1_0_0_);
		F925_6730(RTCW(tr1));
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		tr1 = RTLNS(eif_new_type(924, 0x00).id, 924, _OBJSIZ_0_1_0_0_0_1_0_0_);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {CONSOLE}.read_line */
void F1397_13914 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("read_line", 1396, Current, 0, 0, 19565);
	RTHOOK(1);
	F1397_13916(Current);
	RTHOOK(2);
	RTEE;
}

/* {CONSOLE}.read_line_thread_aware */
void F1397_13916 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc7);
	RTLIU(3);
	
	RTEAA("read_line_thread_aware", 1396, Current, 7, 0, 19567);
	RTGC;
	RTHOOK(1);
	loc4 = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	loc7 = RTOSCF(7136,F929_7136, (Current));
	RTHOOK(3);
	F1059_9039(RTCW(loc4));
	RTHOOK(4);
	loc1 = F299_4584(RTCW(loc7));
	for (;;) {
		RTHOOK(5);
		if (loc3) break;
		RTHOOK(6);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
		tp2 = F299_4582(RTCW(loc7));
		loc2 = (EIF_INTEGER_32) console_readline((FILE*) tp1, (char*) tp2, (EIF_INTEGER) loc1, (EIF_INTEGER) ((EIF_INTEGER_32) 0L));
		RTHOOK(7);
		loc5 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
		RTHOOK(8);
		loc6 = eif_min_int32 (loc2,loc1);
		loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + loc6);
		RTHOOK(9);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 <= loc1);
		RTHOOK(10);
		F1059_9043(RTCW(loc4), loc6);
		RTHOOK(11);
		F1059_9059(RTCW(loc4), loc6);
		RTHOOK(12);
		ti4_1 = eif_min_int32 (loc2,loc1);
		F299_4576(RTCW(loc7), loc4, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L)), ti4_1);
	}
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {CONSOLE}.read_stream */
void F1397_13917 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("read_stream", 1396, Current, 0, 1, 19568);
	RTHOOK(1);
	F1397_13919(Current, arg1);
	RTHOOK(2);
	RTEE;
}

/* {CONSOLE}.read_stream_thread_aware */
void F1397_13919 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTEAA("read_stream_thread_aware", 1396, Current, 3, 1, 19570);
	RTGC;
	RTHOOK(1);
	loc3 = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	loc2 = RTOSCF(7136,F929_7136, (Current));
	RTHOOK(3);
	F299_4590(RTCW(loc2), arg1);
	RTHOOK(4);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
	tp2 = F299_4582(RTCW(loc2));
	loc1 = (EIF_INTEGER_32) console_readstream((FILE*) tp1, (char*) tp2, (EIF_INTEGER) arg1);
	RTHOOK(5);
	F299_4590(RTCW(loc2), loc1);
	RTHOOK(6);
	F1059_9043(RTCW(loc3), loc1);
	RTHOOK(7);
	F1059_9059(RTCW(loc3), loc1);
	RTHOOK(8);
	F299_4578(RTCW(loc2), loc3);
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {CONSOLE}.read_character */
void F1397_13923 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("read_character", 1396, Current, 0, 0, 19574);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
	tc1 = (EIF_CHARACTER_8) console_readchar((FILE*) tp1);
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_5_0_) = (EIF_CHARACTER_8) tc1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {CONSOLE}.put_character */
void F1397_13926 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("put_character", 1396, Current, 0, 1, 19577);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
	console_pc((FILE*) tp1, (EIF_CHARACTER) arg1);
	RTHOOK(2);
	RTEE;
}

/* {CONSOLE}.put_string */
void F1397_13928 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("put_string", 1396, Current, 2, 1, 19579);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7434[Dtype(arg1)-1056]);
	RTHOOK(2);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(3);
		loc2 = *(EIF_REFERENCE *)(RTCW(arg1));
		RTHOOK(4);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
		console_ps((FILE*) tp1, (char*) loc2, (EIF_INTEGER) loc1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONSOLE}.put_new_line */
void F1397_13936 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("put_new_line", 1396, Current, 0, 0, 19587);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
	console_tnwl((FILE*) tp1);
	RTHOOK(2);
	RTEE;
}

/* {CONSOLE}.is_empty */
EIF_BOOLEAN F1397_13938 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

/* {CONSOLE}.console_def */
EIF_POINTER F1397_13939 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("console_def", 1396, Current, 0, 1, 19590);Result = (EIF_POINTER) console_def(arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CONSOLE}.ctoi_convertor */
static EIF_REFERENCE F1397_13940_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("ctoi_convertor", 1396, Current, 0, 0, 19591);
	RTGC;
	RTOSP (13940);
#define Result RTOSR(13940)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(207, 0x00).id, 207, _OBJSIZ_2_3_0_3_0_0_2_0_);
	F208_3806(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(7300,F931_7300, (Current));
	F205_3751(RTCW(Result), tr1);
	RTHOOK(3);
	F205_3750(RTCW(Result), (EIF_BOOLEAN) 1);
	RTHOOK(4);
	F205_3749(RTCW(Result), (EIF_BOOLEAN) 0);
	RTOSE (13940);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1397_13940 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13940,F1397_13940_body,(Current));
}

/* {CONSOLE}.read_integer_with_no_type */
void F1397_13941 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("read_integer_with_no_type", 1396, Current, 0, 0, 19592);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(13940,F1397_13940, (Current));
	F931_7302(Current, tr1, ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	F1397_13942(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONSOLE}.consume_characters */
void F1397_13942 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("consume_characters", 1396, Current, 0, 0, 19593);
	RTGC;
	for (;;) {
		RTHOOK(1);
		tb1 = '\01';
		if (!F1397_13904(Current)) {
			tb1 = (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_5_0_) == (EIF_CHARACTER_8) '\012');
		}
		if (tb1) break;
		RTHOOK(2);
		F1397_13923(Current);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONSOLE}.console_eof */
EIF_BOOLEAN F1397_13944 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("console_eof", 1396, Current, 0, 1, 19595);Result = (EIF_BOOLEAN) EIF_TEST(console_eof((FILE*) arg1));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CONSOLE}.console_ps */
void F1397_13946 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("console_ps", 1396, Current, 0, 3, 19597);console_ps((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CONSOLE}.console_pc */
void F1397_13948 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("console_pc", 1396, Current, 0, 2, 19599);console_pc((FILE*) arg1, (EIF_CHARACTER) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CONSOLE}.console_tnwl */
void F1397_13951 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("console_tnwl", 1396, Current, 0, 1, 19602);console_tnwl((FILE*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CONSOLE}.console_readchar */
EIF_CHARACTER_8 F1397_13953 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("console_readchar", 1396, Current, 0, 1, 19604);
	EIF_ENTER_C;Result = (EIF_CHARACTER_8) console_readchar((FILE*) arg1);
	
	EIF_EXIT_C;
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CONSOLE}.console_readline */
EIF_INTEGER_32 F1397_13957 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("console_readline", 1396, Current, 0, 4, 19608);
	EIF_ENTER_C;Result = (EIF_INTEGER_32) console_readline((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3, (EIF_INTEGER) arg4);
	
	EIF_EXIT_C;
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CONSOLE}.console_readstream */
EIF_INTEGER_32 F1397_13959 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("console_readstream", 1396, Current, 0, 3, 19610);
	EIF_ENTER_C;Result = (EIF_INTEGER_32) console_readstream((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3);
	
	EIF_EXIT_C;
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CONSOLE}.file_close */
void F1397_13960 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("file_close", 1396, Current, 0, 1, 19611);console_file_close((FILE*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit749 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
