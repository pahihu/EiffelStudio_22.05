/*
 * Code for class EV_PIXMAP_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev742.h"
#include <ev_gtk.h>
#include "ev_gtk.h"
#include <cairo.h>
#include "ev_c_util.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F117_2405
static void inline_F117_2405 (EIF_POINTER arg1)
{
	gtk_widget_queue_draw ((GtkWidget *)arg1)
	;
}
#define INLINE_F117_2405
#endif
#ifndef INLINE_F114_1760
static EIF_POINTER inline_F114_1760 (EIF_POINTER arg1, EIF_POINTER* arg2)
{
	return gdk_pixbuf_new_from_file ((char*) arg1, (GError**) arg2);
	;
}
#define INLINE_F114_1760
#endif
#ifndef INLINE_F114_1602
static void inline_F114_1602 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F114_1602
#endif
#ifndef INLINE_F114_1751
static EIF_POINTER inline_F114_1751 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_get_from_surface ((cairo_surface_t *) arg1, (gint) arg2, (gint) arg3, (gint) arg4, (gint) arg5);
	;
}
#define INLINE_F114_1751
#endif
#ifndef INLINE_F114_1742
static EIF_POINTER inline_F114_1742 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	return (EIF_POINTER) (gdk_pixbuf_scale_simple ((GdkPixbuf*) arg1, (int) arg2, (int) arg3, (int) arg4))
	;
}
#define INLINE_F114_1742
#endif
#ifndef INLINE_F35_652
static void inline_F35_652 (EIF_POINTER arg1)
{
	cairo_paint ((cairo_t*)arg1)
	;
}
#define INLINE_F35_652
#endif
#ifndef INLINE_F114_1755
static EIF_INTEGER_32 inline_F114_1755 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_width ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F114_1755
#endif
#ifndef INLINE_F114_1756
static EIF_INTEGER_32 inline_F114_1756 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_height ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F114_1756
#endif
#ifndef INLINE_F35_594
static void inline_F35_594 (EIF_POINTER arg1)
{
	cairo_surface_destroy((cairo_surface_t*) arg1)
	;
}
#define INLINE_F35_594
#endif
#ifndef INLINE_F114_1762
static EIF_POINTER inline_F114_1762 (EIF_POINTER arg1)
{
	return gdk_pixbuf_new_from_xpm_data ((const char**) arg1);
	;
}
#define INLINE_F114_1762
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PIXMAP_IMP}.make */
void F1390_13813 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLR(7,loc2);
	RTLIU(8);
	
	RTEAA("make", 1389, Current, 2, 0, 19469);
	RTGC;
	RTHOOK(1);
	tp1 = (EIF_POINTER) gtk_drawing_area_new();
	F1227_11344(Current, tp1);
	RTHOOK(2);
	F1332_12698(Current);
	RTHOOK(3);
	loc1 = RTOSCF(11369,F1227_11369, (Current));
	RTHOOK(4);
	tp1 = F1227_11368(Current);
	tr1 = RTOSCF(522,F34_522, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,973,936,1045,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_0_);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = tp2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1052,0xFFF9,1,973,1045,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A365_329_3, (EIF_POINTER) _A365_329_3, (EIF_POINTER)(F935_7365),tr2, 1, 1);
	}
	F1227_11349(Current, tp1, tr1, tr5);
	RTHOOK(5);
	F1390_13826(Current, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	RTHOOK(6);
	F1386_13589(Current);
	RTHOOK(7);
	F1386_13631(Current, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	RTHOOK(8);
	loc2 = F188_3552(Current);
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.init_from_pixel_buffer */
void F1390_13815 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("init_from_pixel_buffer", 1389, Current, 1, 1, 19471);
	RTGC;
	RTHOOK(1);
	RTCT0("attached {EV_PIXEL_BUFFER_IMP} a_pixel_buffer.implementation as l_pixel_buffer_imp", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1223, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(loc1+ _PTROFF_4_2_0_0_0_0_);
	F1390_13834(Current, tp1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.update_if_needed */
void F1390_13816 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("update_if_needed", 1389, Current, 0, 0, 19472);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_48_13_)) {
		RTHOOK(2);
		tp1 = F1227_11368(Current);
		inline_F117_2405(tp1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.width */
EIF_INTEGER_32 F1390_13820 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("width", 1389, Current, 0, 0, 19476);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_) != tp1)) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) cairo_image_surface_get_width((cairo_surface_t*) tp1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_PIXMAP_IMP}.height */
EIF_INTEGER_32 F1390_13821 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("height", 1389, Current, 0, 0, 19477);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_) != tp1)) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) cairo_image_surface_get_height((cairo_surface_t*) tp1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_PIXMAP_IMP}.read_from_named_path */
void F1390_13822 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc4);
	RTLR(4,loc5);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTEAA("read_from_named_path", 1389, Current, 5, 1, 19478);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F923_6656(RTCW(loc1), arg1);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	loc3 = inline_F114_1760(tp1, (EIF_POINTER *) &(loc2));
	RTHOOK(3);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc2 != tp1)) {
		RTHOOK(4);
		loc4 = RTLNS(eif_new_type(921, 0x00).id, 921, _OBJSIZ_1_1_0_0_0_1_0_0_);
		F295_4551(RTCW(loc4), loc2);
		RTHOOK(5);
		loc5 = F922_6648(RTCW(loc4));
		RTHOOK(6);
		F922_6650(RTCW(loc4));
		RTHOOK(7);
		tr1 = RTLNS(eif_new_type(224, 0x00).id, 224, _OBJSIZ_0_0_0_0_0_0_0_0_);
		F225_3908(RTCW(tr1), loc5);
	}
	RTHOOK(8);
	F1390_13834(Current, loc3);
	RTHOOK(9);
	inline_F114_1602(loc3);
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.pixbuf */
EIF_POINTER F1390_13823 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pixbuf", 1389, Current, 0, 0, 19479);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
	ti4_1 = F1390_13820(Current);
	ti4_2 = F1390_13821(Current);
	Result = inline_F114_1751(tp1, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_PIXMAP_IMP}.set_with_default */
void F1390_13824 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_with_default", 1389, Current, 0, 0, 19480);
	RTGC;
	RTHOOK(1);
	tp1 = (EIF_POINTER) default_pixmap_xpm();
	F1390_13843(Current, tp1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.stretch */
void F1390_13825 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("stretch", 1389, Current, 5, 2, 19481);
	RTGC;
	RTHOOK(1);
	loc4 = F1390_13820(Current);
	RTHOOK(2);
	loc5 = F1390_13821(Current);
	RTHOOK(3);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 != arg1) || (EIF_BOOLEAN)(loc5 != arg2))) {
		RTHOOK(4);
		loc1 = F1386_13662(Current);
		RTHOOK(5);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 <= ((EIF_INTEGER_32) 16L)) && (EIF_BOOLEAN) (loc5 <= ((EIF_INTEGER_32) 16L)))) {
			RTHOOK(6);
			loc3 = (EIF_INTEGER_32) GDK_INTERP_NEAREST;
		} else {
			RTHOOK(7);
			loc3 = (EIF_INTEGER_32) GDK_INTERP_BILINEAR;
		}
		RTHOOK(8);
		loc2 = inline_F114_1742(loc1, arg1, arg2, loc3);
		RTHOOK(9);
		inline_F114_1602(loc1);
		RTHOOK(10);
		F1390_13834(Current, loc2);
		RTHOOK(11);
		inline_F114_1602(loc2);
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.set_size */
void F1390_13826 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_size", 1389, Current, 0, 2, 19482);
	RTGC;
	RTHOOK(1);
	F1390_13841(Current);
	RTHOOK(2);
	tp1 = (EIF_POINTER) cairo_image_surface_create((cairo_format_t) ((EIF_INTEGER_8) 0L), (int) arg1, (int) arg2);
	*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_) = (EIF_POINTER) tp1;
	RTHOOK(3);
	F1386_13594(Current);
	RTHOOK(4);
	F1386_13589(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.pixbuf_from_drawable_at_position */
EIF_POINTER F1390_13829 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("pixbuf_from_drawable_at_position", 1389, Current, 0, 6, 19485);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
	RTHOOK(2);
	RTEE;
	return (EIF_POINTER) inline_F114_1751(tp1, arg1, arg2, arg5, arg6);
}

/* {EV_PIXMAP_IMP}.process_draw_event */
EIF_BOOLEAN F1390_13831 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("process_draw_event", 1389, Current, 3, 1, 19487);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_0_);
	loc1 = (EIF_INTEGER_32) gtk_widget_get_allocated_width((GtkWidget*) tp1);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_0_);
	loc2 = (EIF_INTEGER_32) gtk_widget_get_allocated_height((GtkWidget*) tp1);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
	ti4_1 = F1390_13820(Current);
	ti4_2 = F1390_13821(Current);
	cairo_set_source_surface((cairo_t*) arg1, (cairo_surface_t*) tp1, (double) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc1 - ti4_1)) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L))), (double) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc2 - ti4_2)) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L))));
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(5);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_48_13_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(6);
		F1381_13511(Current);
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(11369,F1227_11369, (Current))) + _REFACS_42_);
		tr1 = F937_7399(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc1, loc2);
		F712_6079(loc3, tr1);
		RTHOOK(8);
		F1390_13837(Current);
		RTHOOK(9);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_48_13_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(10);
	inline_F35_652(arg1);
	RTHOOK(11);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_PIXMAP_IMP}.copy_pixmap */
void F1390_13833 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc4);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("copy_pixmap", 1389, Current, 4, 1, 19489);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc4 = tr1;
	loc4 = RTRV(eif_new_type(1389, 0x00),loc4);
	if (EIF_TEST(loc4)) {
		RTHOOK(2);
		loc1 = F1390_13820(loc4);
		RTHOOK(3);
		loc2 = F1390_13821(loc4);
		RTHOOK(4);
		F1390_13841(Current);
		RTHOOK(5);
		tp1 = (EIF_POINTER) cairo_image_surface_create((cairo_format_t) ((EIF_INTEGER_8) 0L), (int) loc1, (int) loc2);
		*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_) = (EIF_POINTER) tp1;
		RTHOOK(6);
		F1386_13594(Current);
		RTHOOK(7);
		loc3 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_);
		RTHOOK(8);
		F1386_13589(Current);
		RTHOOK(9);
		tp1 = *(EIF_POINTER *)(loc4+ _PTROFF_48_18_10_9_0_2_);
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		cairo_set_source_surface((cairo_t*) loc3, (cairo_surface_t*) tp1, (double) tr8_1, (double) tr8_2);
		RTHOOK(10);
		inline_F35_652(loc3);
		RTHOOK(11);
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		tr8_3 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		cairo_set_source_rgb((cairo_t*) loc3, (double) tr8_1, (double) tr8_2, (double) tr8_3);
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.set_pixmap_from_pixbuf */
void F1390_13834 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_pixmap_from_pixbuf", 1389, Current, 1, 1, 19490);
	RTGC;
	RTHOOK(1);
	F1390_13841(Current);
	RTHOOK(2);
	ti4_1 = inline_F114_1755(arg1);
	ti4_2 = inline_F114_1756(arg1);
	tp1 = (EIF_POINTER) cairo_image_surface_create((cairo_format_t) ((EIF_INTEGER_8) 0L), (int) ti4_1, (int) ti4_2);
	*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_) = (EIF_POINTER) tp1;
	RTHOOK(3);
	F1386_13594(Current);
	RTHOOK(4);
	loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_);
	RTHOOK(5);
	F1386_13616(Current, ((EIF_INTEGER_32) 0L));
	RTHOOK(6);
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
	tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
	gdk_cairo_set_source_pixbuf((cairo_t*) loc1, (GdkPixbuf*) arg1, (double) tr8_1, (double) tr8_2);
	RTHOOK(7);
	inline_F35_652(loc1);
	RTHOOK(8);
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
	tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
	tr8_3 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
	cairo_set_source_rgb((cairo_t*) loc1, (double) tr8_1, (double) tr8_2, (double) tr8_3);
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.pre_drawing */
void F1390_13835 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pre_drawing", 1389, Current, 1, 0, 19491);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1381_13508(Current)) {
		RTHOOK(2);
		F1390_13839(Current);
		RTHOOK(3);
		loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_);
		RTHOOK(4);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(5);
			cairo_save((cairo_t*) loc1);
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.post_drawing */
void F1390_13836 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("post_drawing", 1389, Current, 1, 0, 19492);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1381_13508(Current)) {
		RTHOOK(2);
		loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_);
		RTHOOK(3);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(4);
			cairo_restore((cairo_t*) loc1);
		}
		RTHOOK(5);
		F1390_13816(Current);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.end_drawing_session */
void F1390_13837 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("end_drawing_session", 1389, Current, 0, 0, 19493);
	RTGC;
	RTHOOK(1);
	if (F1381_13509(Current)) {
		RTHOOK(2);
		F1390_13816(Current);
	}
	RTHOOK(3);
	F1381_13512(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.get_cairo_context */
void F1390_13839 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_cairo_context", 1389, Current, 1, 0, 19495);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_);
	tb1 = !tp1;
	if (tb1) {
		RTHOOK(2);
		loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
		RTHOOK(3);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(4);
			tp1 = (EIF_POINTER) cairo_create((cairo_surface_t*) loc1);
			*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_) = (EIF_POINTER) tp1;
		}
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.release_cairo_surface */
void F1390_13840 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("release_cairo_surface", 1389, Current, 0, 1, 19496);
	RTGC;
	RTHOOK(1);
	tb1 = !arg1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(2);
		inline_F35_594(arg1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.release_previous_cairo_surface */
void F1390_13841 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("release_previous_cairo_surface", 1389, Current, 0, 0, 19497);
	RTGC;
	RTHOOK(1);
	F1386_13660(Current);
	RTHOOK(2);
	F1390_13840(Current, *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_));
	RTHOOK(3);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_) = (EIF_POINTER) tp2;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.set_from_xpm_data */
void F1390_13843 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_from_xpm_data", 1389, Current, 1, 1, 19499);
	RTGC;
	RTHOOK(1);
	*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_3_) = (EIF_POINTER) arg1;
	RTHOOK(2);
	loc1 = inline_F114_1762(arg1);
	RTHOOK(3);
	F1390_13834(Current, loc1);
	RTHOOK(4);
	inline_F114_1602(loc1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.destroy */
void F1390_13846 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("destroy", 1389, Current, 0, 0, 19463);
	RTGC;
	RTHOOK(1);
	F1386_13660(Current);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		F1390_13840(Current, *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_));
		RTHOOK(4);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_) = (EIF_POINTER) tp2;
	}
	RTHOOK(5);
	F1278_12020(Current);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.c_object_dispose */
void F1390_13847 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_object_dispose", 1389, Current, 0, 0, 19464);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_);
		cairo_destroy((cairo_t*) tp1);
		RTHOOK(3);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_1_) = (EIF_POINTER) tp2;
	}
	RTHOOK(4);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(5);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_);
		inline_F35_594(tp1);
		RTHOOK(6);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_48_18_10_9_0_2_) = (EIF_POINTER) tp2;
	}
	RTHOOK(7);
	F1227_11359(Current);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP_IMP}.default_pixmap_xpm */
EIF_POINTER F1390_13848 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_pixmap_xpm", 1389, Current, 0, 0, 19465);Result = (EIF_POINTER) default_pixmap_xpm();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit742 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
