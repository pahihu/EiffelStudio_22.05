/*
 * Code for class EV_ITEM_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev715.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ITEM_IMP}.call_button_event_actions */
void F1363_13319 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("call_button_event_actions", 1362, Current, 1, 9, 19059);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,8,973,1006,1006,1006,991,991,991,1006,1006,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNTS(typres0.id, 9, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg2;
	((EIF_TYPED_VALUE *)tr1+2)->it_i4 = arg3;
	((EIF_TYPED_VALUE *)tr1+3)->it_i4 = arg4;
	((EIF_TYPED_VALUE *)tr1+4)->it_r8 = arg5;
	((EIF_TYPED_VALUE *)tr1+5)->it_r8 = arg6;
	((EIF_TYPED_VALUE *)tr1+6)->it_r8 = arg7;
	((EIF_TYPED_VALUE *)tr1+7)->it_i4 = arg8;
	((EIF_TYPED_VALUE *)tr1+8)->it_i4 = arg9;
	loc1 = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_PRESS)) {
		RTHOOK(3);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O1280[dtype-81]) != NULL)) {
			RTHOOK(4);
			tr1 = *(EIF_REFERENCE *)(Current + O1280[dtype-81]);
			F712_6079(RTCW(tr1), loc1);
		}
	} else {
		RTHOOK(5);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O1282[dtype-81]) != NULL)) {
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current + O1282[dtype-81]);
			F712_6079(RTCW(tr1), loc1);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_ITEM_IMP}.parent_imp */
EIF_REFERENCE F1363_13320 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("parent_imp", 1362, Current, 0, 0, 19060);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + O10263[Dtype(Current)-1362]);
}

/* {EV_ITEM_IMP}.destroy */
void F1363_13321 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("destroy", 1362, Current, 1, 0, 19061);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = F1363_13320(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8598[dtype-1200]) != NULL);
	}
	if (tb1) {
		RTHOOK(2);
		F1232_11518(loc1, *(EIF_REFERENCE *)(Current + O8598[dtype-1200]));
	}
	RTHOOK(3);
	F1227_11347(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_ITEM_IMP}.set_item_parent_imp */
void F1363_13323 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_item_parent_imp", 1362, Current, 0, 1, 19063);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O10263[Dtype(Current)-1362]) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EV_ITEM_IMP}.update_for_pick_and_drop */
void F1363_13324 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("update_for_pick_and_drop", 1362, Current, 0, 1, 19064);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit715 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
