/*
 * Code for class EV_TEXT_FIELD_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev700.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F10_93
static EIF_NATURAL_8 inline_F10_93 (void)
{
	return GTK_ORIENTATION_VERTICAL
	;
}
#define INLINE_F10_93
#endif
#ifndef INLINE_F116_2321
static EIF_POINTER inline_F116_2321 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F116_2321
#endif
#ifndef INLINE_F117_2512
static void inline_F117_2512 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_entry_set_width_chars ((GtkEntry *)arg1, (gint)arg2)
	;
}
#define INLINE_F117_2512
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TEXT_FIELD_IMP}.needs_event_box */
EIF_BOOLEAN F1348_13089 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("needs_event_box", 1347, Current, 0, 0, 18834);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_TEXT_FIELD_IMP}.make */
void F1348_13091 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 1347, Current, 1, 0, 18836);
	RTGC;
	RTHOOK(1);
	tu1_1 = inline_F10_93();
	loc1 = inline_F116_2321(tu1_1, ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	F1227_11344(Current, loc1);
	RTHOOK(3);
	tp1 = F1348_13127(Current);
	*(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_) = (EIF_POINTER) tp1;
	RTHOOK(4);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	gtk_widget_show((GtkWidget*) tp1);
	RTHOOK(5);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	gtk_box_pack_start((GtkBox*) loc1, (GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 1, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	RTHOOK(6);
	F1348_13098(Current);
	RTHOOK(7);
	F1345_12960(Current);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_TEXT_FIELD_IMP}.text */
EIF_REFERENCE F1348_13092 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("text", 1347, Current, 1, 0, 18837);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	tp1 = (EIF_POINTER) gtk_entry_get_text((GtkEntry*) tp1);
	F923_6663(RTCW(loc1), tp1);
	RTHOOK(2);
	tr1 = F923_6659(RTCW(loc1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {EV_TEXT_FIELD_IMP}.set_minimum_width_in_characters */
void F1348_13093 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_minimum_width_in_characters", 1347, Current, 0, 1, 18838);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	ti4_1 = F1345_12963(Current);
	tr1 = RTLNS(eif_new_type(114, 0x00).id, 114, _OBJSIZ_0_0_0_0_0_0_0_0_);
	F115_2021(RTCW(tr1), tp1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)) * ti4_1), ((EIF_INTEGER_32) -1L));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_TEXT_FIELD_IMP}.set_text */
void F1348_13094 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("set_text", 1347, Current, 1, 1, 18839);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F923_6661(RTCW(loc1), arg1);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	inline_F117_2512(tp1, ((EIF_INTEGER_32) 1L));
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	gtk_entry_set_text((GtkEntry*) tp1, (gchar*) tp2);
	RTHOOK(4);
	F1348_13124(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_TEXT_FIELD_IMP}.set_capacity */
void F1348_13097 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("set_capacity", 1347, Current, 0, 1, 18842);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	gtk_entry_set_max_length((GtkEntry*) tp1, (gint) arg1);
	RTHOOK(2);
	RTEE;
}

/* {EV_TEXT_FIELD_IMP}.align_text_left */
void F1348_13098 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("align_text_left", 1347, Current, 0, 0, 18843);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_46_14_10_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	gtk_entry_set_alignment((GtkEntry*) tp1, (gfloat) (EIF_REAL_32) 0.0);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_TEXT_FIELD_IMP}.align_text_center */
void F1348_13100 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("align_text_center", 1347, Current, 0, 0, 18845);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_46_14_10_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	gtk_entry_set_alignment((GtkEntry*) tp1, (gfloat) (EIF_REAL_32) 0.5);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_TEXT_FIELD_IMP}.text_alignment */
EIF_INTEGER_32 F1348_13101 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_46_14_10_6_);
}


/* {EV_TEXT_FIELD_IMP}.on_key_event */
void F1348_13104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("on_key_event", 1347, Current, 0, 3, 18849);
	RTGC;
	RTHOOK(1);
	F1278_11992(Current, arg1, arg2, arg3);
	RTHOOK(2);
	tb1 = '\0';
	if ((EIF_BOOLEAN) !F1201_10643(Current)) {
		tb1 = arg3;
	}
	if (tb1) {
		RTHOOK(3);
		F1348_13124(Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_TEXT_FIELD_IMP}.return_actions */
RTEOMS(13104,1);
EIF_REFERENCE F1348_13105 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("return_actions", 1347, Current, 1, 0, 18850);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc1;
	} else {
		RTHOOK(4);
		Result = RTLNS(eif_new_type(729, 0x00).id, 729, _OBJSIZ_9_2_0_2_0_0_0_0_);
		F711_6042(RTCW(Result));
		RTHOOK(5);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,973,936,1045,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = *(EIF_REFERENCE *)(RTCV(RTOSCF(11369,F1227_11369, (Current))) + _REFACS_42_);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_0_);
		((EIF_TYPED_VALUE *)tr1+2)->it_p = tp2;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,0,973,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2= RTLNRF(typres0.id, (EIF_POINTER) __A365_336, (EIF_POINTER) _A365_336, (EIF_POINTER)(F935_7372),tr1, 1, 0);
		}
		F1227_11349(Current, tp1, RTOMS(13104,0), tr2);
		RTHOOK(6);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) Result;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_TEXT_FIELD_IMP}.set_editable */
void F1348_13112 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("set_editable", 1347, Current, 0, 1, 18857);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
	gtk_editable_set_editable((GtkEditable*) tp1, (gboolean) arg1);
	RTHOOK(2);
	RTEE;
}

/* {EV_TEXT_FIELD_IMP}.on_change_actions */
void F1348_13124 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("on_change_actions", 1347, Current, 3, 0, 18869);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tb3 = F506_5267(loc2);
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !F1201_10643(Current);
	}
	if (tb1) {
		RTHOOK(2);
		loc1 = F1348_13092(Current);
		RTHOOK(3);
		tb1 = '\01';
		tb2 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_45_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tb3 = F1061_9087(RTCW(loc1), loc3);
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (!tb2) {
			tb1 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_45_) == NULL);
		}
		if (tb1) {
			RTHOOK(4);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_46_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(5);
			F712_6079(loc2, NULL);
			RTHOOK(6);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_46_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			RTHOOK(7);
			tr1 = F1348_13092(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_45_) = (EIF_REFERENCE) tr1;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_TEXT_FIELD_IMP}.style_element_name */
EIF_REFERENCE F1348_13126 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("style_element_name", 1347, Current, 0, 0, 18871);
	RTGC;
	RTHOOK(1);
	Result = RTMS_EX_H("entry",5,1853900921);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_TEXT_FIELD_IMP}.new_entry_widget */
EIF_POINTER F1348_13127 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("new_entry_widget", 1347, Current, 0, 0, 18872);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_POINTER) (EIF_POINTER) gtk_entry_new();
}

/* {EV_TEXT_FIELD_IMP}.visual_widget */
EIF_POINTER F1348_13129 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("visual_widget", 1347, Current, 0, 0, 18874);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_POINTER) *(EIF_POINTER *)(Current+ _PTROFF_46_14_10_7_0_1_);
}

void EIF_Minit700 (void)
{
	GTCX
	RTPOMS(13104,0,"activate",8,526134885);
}


#ifdef __cplusplus
}
#endif
