/*
 * Code for class EV_DRAWABLE_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev733.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DRAWABLE_I}.is_in_drawing_session */
EIF_BOOLEAN F1381_13508 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_in_drawing_session", 1380, Current, 0, 0, 19217);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O10331[Dtype(Current)-1380]) > ((EIF_INTEGER_32) 0L));
}

/* {EV_DRAWABLE_I}.is_in_top_drawing_session */
EIF_BOOLEAN F1381_13509 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_in_top_drawing_session", 1380, Current, 0, 0, 19218);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O10331[Dtype(Current)-1380]) == ((EIF_INTEGER_32) 1L));
}

/* {EV_DRAWABLE_I}.start_drawing_session */
void F1381_13511 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	
	
	RTEAA("start_drawing_session", 1380, Current, 0, 0, 19220);
	RTHOOK(1);
	(*(EIF_INTEGER_32 *)(Current + O10331[dtype-1380]))++;
	RTHOOK(3);
	RTEE;
}

/* {EV_DRAWABLE_I}.end_drawing_session */
void F1381_13512 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	
	
	RTEAA("end_drawing_session", 1380, Current, 0, 0, 19221);
	RTHOOK(1);
	(*(EIF_INTEGER_32 *)(Current + O10331[dtype-1380]))--;
	RTHOOK(2);
	RTEE;
}

void EIF_Minit733 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
