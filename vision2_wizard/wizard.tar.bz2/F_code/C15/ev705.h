
#ifndef _C15_ev705_
#define _C15_ev705_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1353_13187(EIF_REFERENCE);
extern void F1353_13188(EIF_REFERENCE);
extern EIF_BOOLEAN F1353_13189(EIF_REFERENCE);
extern void EIF_Minit705(void);
extern EIF_POINTER F1227_11368(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
