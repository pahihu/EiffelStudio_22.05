
#ifndef _C3_i1124_
#define _C3_i1124_

#ifdef __cplusplus
extern "C" {
#endif

extern void F137_2932(EIF_REFERENCE, EIF_REFERENCE);
extern void F137_2933(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit124(void);
extern long O3052[];
extern long O3053[];
extern long O3054[];
extern long O3056[];
extern long O3057[];
extern long O3058[];

#ifdef __cplusplus
}
#endif

#endif
