/*
 * Code for class I18N_NUMERIC_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1130.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_NUMERIC_INFO}.make */
void F143_3056 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 142, Current, 0, 0, 3170);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(3064,F143_3064, (Current));
	F143_3071(Current, tr1);
	RTHOOK(2);
	F143_3072(Current, ((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	tr1 = RTOSCF(3066,F143_3066, (Current));
	F143_3073(Current, tr1);
	RTHOOK(4);
	tr1 = RTOSCF(3067,F143_3067, (Current));
	F143_3074(Current, tr1);
	RTHOOK(5);
	tr1 = RTOSCF(3070,F143_3070, (Current));
	F143_3077(Current, tr1);
	RTHOOK(6);
	tr1 = RTOSCF(3068,F143_3068, (Current));
	F143_3075(Current, tr1);
	RTHOOK(7);
	tr1 = RTOSCF(3069,F143_3069, (Current));
	F143_3076(Current, tr1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.default_value_decimal_separator */
static EIF_REFERENCE F143_3064_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_value_decimal_separator", 142, Current, 0, 0, 3178);
	RTGC;
	RTOSP (3064);
#define Result RTOSR(3064)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H(".\000\000\000",1,46);
	RTOSE (3064);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F143_3064 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3064,F143_3064_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_group_separator */
static EIF_REFERENCE F143_3066_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_value_group_separator", 142, Current, 0, 0, 3180);
	RTGC;
	RTOSP (3066);
#define Result RTOSR(3066)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H(",\000\000\000",1,44);
	RTOSE (3066);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F143_3066 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3066,F143_3066_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_number_list_separator */
static EIF_REFERENCE F143_3067_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_value_number_list_separator", 142, Current, 0, 0, 3181);
	RTGC;
	RTOSP (3067);
#define Result RTOSR(3067)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H(";\000\000\000",1,59);
	RTOSE (3067);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F143_3067 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3067,F143_3067_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_positive_sign */
static EIF_REFERENCE F143_3068_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_positive_sign", 142, Current, 0, 0, 3182);
	RTGC;
	RTOSP (3068);
#define Result RTOSR(3068)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H("",0,0);
	RTOSE (3068);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F143_3068 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3068,F143_3068_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_negative_sign */
static EIF_REFERENCE F143_3069_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_negative_sign", 142, Current, 0, 0, 3161);
	RTGC;
	RTOSP (3069);
#define Result RTOSR(3069)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H("-\000\000\000",1,45);
	RTOSE (3069);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F143_3069 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3069,F143_3069_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_grouping */
static EIF_REFERENCE F143_3070_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("default_value_grouping", 142, Current, 0, 0, 3162);
	RTGC;
	RTOSP (3070);
#define Result RTOSR(3070)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {862,1006,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 3L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 3L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F863_6501)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3070);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F143_3070 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3070,F143_3070_body,(Current));
}

/* {I18N_NUMERIC_INFO}.set_value_decimal_separator */
void F143_3071 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_value_decimal_separator", 142, Current, 0, 1, 3163);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8826(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_numbers_after_decimal_separator */
void F143_3072 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_value_numbers_after_decimal_separator", 142, Current, 0, 1, 3164);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_35_0_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_group_separator */
void F143_3073 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_value_group_separator", 142, Current, 0, 1, 3165);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8826(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_number_list_separator */
void F143_3074 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_value_number_list_separator", 142, Current, 0, 1, 3166);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8826(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_positive_sign */
void F143_3075 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_value_positive_sign", 142, Current, 0, 1, 3167);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8826(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_negative_sign */
void F143_3076 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_value_negative_sign", 142, Current, 0, 1, 3168);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8826(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_grouping */
void F143_3077 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_value_grouping", 142, Current, 0, 1, 3169);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit130 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
