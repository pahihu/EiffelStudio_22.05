/*
 * Code for class WIZARD_INTERMEDIARY_STATE_WINDOW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi117.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_INTERMEDIARY_STATE_WINDOW}.display */
void F130_2871 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("display", 129, Current, 0, 0, 2976);
	RTGC;
	RTHOOK(1);
	F130_2872(Current);
	RTHOOK(2);
	F1151_10210(RTCV(F124_2731(Current)));
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2840[Dtype(Current)-343])(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {WIZARD_INTERMEDIARY_STATE_WINDOW}.build_frame */
void F130_2872 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,tr2);
	RTLR(5,loc9);
	RTLR(6,loc8);
	RTLR(7,loc7);
	RTLR(8,loc4);
	RTLR(9,loc5);
	RTLR(10,loc2);
	RTLR(11,loc3);
	RTLR(12,loc10);
	RTLR(13,tr3);
	RTLIU(14);
	
	RTEAA("build_frame", 129, Current, 10, 0, 2977);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1141, 0x00).id, 1141, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc1));
	RTHOOK(2);
	ti4_1 = F123_2729(Current, ((EIF_INTEGER_32) 5L));
	F1141_10080(RTCW(loc1), ti4_1);
	RTHOOK(3);
	tr1 = RTOSCF(2748,F124_2748, (Current));
	F1112_9681(RTCW(loc1), tr1);
	RTHOOK(4);
	ti4_1 = F123_2729(Current, ((EIF_INTEGER_32) 58L));
	F1136_9998(RTCW(loc1), ti4_1);
	RTHOOK(5);
	loc6 = RTLNS(eif_new_type(1143, 0x00).id, 1143, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc6));
	RTHOOK(6);
	tr1 = RTOSCF(2748,F124_2748, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7936[Dtype(RTCW(loc6))-1125])(loc6, tr1);
	RTHOOK(7);
	ti4_1 = RTOSCF(2755,F124_2755, (Current));
	F1136_9997(RTCW(loc6), ti4_1);
	RTHOOK(8);
	F1134_9938(RTCW(loc1), loc6);
	RTHOOK(9);
	F1141_10084(RTCW(loc1), loc6);
	RTHOOK(10);
	tr1 = RTLNSMART(eif_new_type(1158, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(11);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTOSCF(2748,F124_2748, (Current));
	F1112_9681(RTCW(tr1), tr2);
	RTHOOK(12);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1123_9755(RTCW(tr1));
	RTHOOK(13);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTOSCF(2753,F124_2753, (Current));
	F1124_9758(RTCW(tr1), tr2);
	RTHOOK(14);
	loc9 = RTLNS(eif_new_type(1141, 0x00).id, 1141, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc9));
	RTHOOK(15);
	loc6 = RTLNS(eif_new_type(1143, 0x00).id, 1143, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc6));
	RTHOOK(16);
	ti4_1 = RTOSCF(2757,F124_2757, (Current));
	F1136_9997(RTCW(loc6), ti4_1);
	RTHOOK(17);
	tr1 = RTOSCF(2748,F124_2748, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7936[Dtype(RTCW(loc6))-1125])(loc6, tr1);
	RTHOOK(18);
	F1134_9938(RTCW(loc9), loc6);
	RTHOOK(19);
	F1141_10084(RTCW(loc9), loc6);
	RTHOOK(20);
	tr1 = RTLNSMART(eif_new_type(1158, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(21);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1123_9755(RTCW(tr1));
	RTHOOK(22);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = RTOSCF(2748,F124_2748, (Current));
	F1112_9681(RTCW(tr1), tr2);
	RTHOOK(23);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = RTOSCF(2754,F124_2754, (Current));
	F1124_9758(RTCW(tr1), tr2);
	RTHOOK(24);
	F1134_9938(RTCW(loc9), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	RTHOOK(25);
	loc8 = RTLNS(eif_new_type(1142, 0x00).id, 1142, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc8));
	RTHOOK(26);
	tr1 = RTOSCF(2748,F124_2748, (Current));
	F1112_9681(RTCW(loc8), tr1);
	RTHOOK(27);
	ti4_1 = F123_2729(Current, ((EIF_INTEGER_32) 3L));
	F1141_10082(RTCW(loc8), ti4_1);
	RTHOOK(28);
	F1134_9938(RTCW(loc8), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	RTHOOK(29);
	F1141_10084(RTCW(loc8), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	RTHOOK(30);
	F1134_9938(RTCW(loc8), loc9);
	RTHOOK(31);
	F1141_10084(RTCW(loc8), loc9);
	RTHOOK(32);
	loc6 = RTLNS(eif_new_type(1143, 0x00).id, 1143, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc6));
	RTHOOK(33);
	tr1 = RTOSCF(2748,F124_2748, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7936[Dtype(RTCW(loc6))-1125])(loc6, tr1);
	RTHOOK(34);
	F1134_9938(RTCW(loc8), loc6);
	RTHOOK(35);
	F1134_9938(RTCW(loc1), loc8);
	RTHOOK(36);
	loc6 = RTLNS(eif_new_type(1143, 0x00).id, 1143, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc6));
	RTHOOK(37);
	ti4_1 = RTOSCF(2756,F124_2756, (Current));
	F1136_9997(RTCW(loc6), ti4_1);
	RTHOOK(38);
	tr1 = RTOSCF(2748,F124_2748, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7936[Dtype(RTCW(loc6))-1125])(loc6, tr1);
	RTHOOK(39);
	F1134_9938(RTCW(loc1), loc6);
	RTHOOK(40);
	loc7 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (RTOSCF(2740,F124_2740, (Current)));
	RTHOOK(41);
	ti4_1 = F123_2729(Current, ((EIF_INTEGER_32) 48L));
	F1136_9997(RTCW(loc7), ti4_1);
	RTHOOK(42);
	ti4_1 = F123_2729(Current, ((EIF_INTEGER_32) 48L));
	F1136_9998(RTCW(loc7), ti4_1);
	RTHOOK(43);
	F1134_9938(RTCW(loc1), loc7);
	RTHOOK(44);
	F1141_10084(RTCW(loc1), loc7);
	RTHOOK(45);
	loc4 = RTLNS(eif_new_type(1170, 0x00).id, 1170, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc4));
	RTHOOK(46);
	tr1 = RTLNSMART(eif_new_type(1141, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTHOOK(47);
	loc6 = RTLNS(eif_new_type(1143, 0x00).id, 1143, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc6));
	RTHOOK(48);
	ti4_1 = RTOSCF(2758,F124_2758, (Current));
	F1136_9997(RTCW(loc6), ti4_1);
	RTHOOK(49);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1134_9938(RTCW(tr1), loc6);
	RTHOOK(50);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1141_10084(RTCW(tr1), loc6);
	RTHOOK(51);
	tr1 = RTLNSMART(eif_new_type(1158, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(52);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1123_9755(RTCW(tr1));
	RTHOOK(53);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1134_9938(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTHOOK(54);
	loc6 = RTLNS(eif_new_type(1143, 0x00).id, 1143, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc6));
	RTHOOK(55);
	ti4_1 = RTOSCF(2758,F124_2758, (Current));
	F1136_9997(RTCW(loc6), ti4_1);
	RTHOOK(56);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1134_9938(RTCW(tr1), loc6);
	RTHOOK(57);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1141_10084(RTCW(tr1), loc6);
	RTHOOK(58);
	loc5 = RTLNS(eif_new_type(1143, 0x00).id, 1143, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc5));
	RTHOOK(59);
	ti4_1 = F123_2729(Current, ((EIF_INTEGER_32) 2L));
	F1136_9998(RTCW(loc5), ti4_1);
	RTHOOK(60);
	loc2 = RTLNS(eif_new_type(1141, 0x00).id, 1141, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc2));
	RTHOOK(61);
	loc6 = RTLNS(eif_new_type(1143, 0x00).id, 1143, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc6));
	RTHOOK(62);
	ti4_1 = RTOSCF(2758,F124_2758, (Current));
	F1136_9997(RTCW(loc6), ti4_1);
	RTHOOK(63);
	F1134_9938(RTCW(loc2), loc6);
	RTHOOK(64);
	F1141_10084(RTCW(loc2), loc6);
	RTHOOK(65);
	tr1 = RTLNSMART(eif_new_type(1142, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(66);
	F1134_9938(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	RTHOOK(67);
	loc6 = RTLNS(eif_new_type(1143, 0x00).id, 1143, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc6));
	RTHOOK(68);
	ti4_1 = RTOSCF(2758,F124_2758, (Current));
	F1136_9997(RTCW(loc6), ti4_1);
	RTHOOK(69);
	F1134_9938(RTCW(loc2), loc6);
	RTHOOK(70);
	F1141_10084(RTCW(loc2), loc6);
	RTHOOK(71);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2835[Dtype(Current)-343])(Current);
	RTHOOK(72);
	loc3 = RTLNS(eif_new_type(1142, 0x00).id, 1142, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc3));
	RTHOOK(73);
	ti4_1 = RTOSCF(2725,F123_2725, (Current));
	F1141_10080(RTCW(loc3), ti4_1);
	RTHOOK(74);
	ti4_1 = RTOSCF(2721,F123_2721, (Current));
	F1141_10082(RTCW(loc3), ti4_1);
	RTHOOK(75);
	F1134_9938(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_6_));
	RTHOOK(76);
	F1141_10084(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_6_));
	RTHOOK(77);
	F1134_9938(RTCW(loc3), loc2);
	RTHOOK(78);
	tr1 = RTOSCF(2733,F124_2733, (Current));
	F1134_9938(RTCW(tr1), loc1);
	RTHOOK(79);
	tr1 = RTOSCF(2733,F124_2733, (Current));
	F1141_10084(RTCW(tr1), loc1);
	RTHOOK(80);
	tr1 = RTOSCF(2733,F124_2733, (Current));
	F1134_9938(RTCW(tr1), loc4);
	RTHOOK(81);
	tr1 = RTOSCF(2733,F124_2733, (Current));
	F1141_10084(RTCW(tr1), loc4);
	RTHOOK(82);
	tr1 = RTOSCF(2733,F124_2733, (Current));
	F1134_9938(RTCW(tr1), loc3);
	RTHOOK(83);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc10 = RTLNTS(typres0.id, 1, 1);
	}
	RTHOOK(84);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,973,0,0xFFF9,0,973,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = loc10;
	RTAR(tr2,loc10);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1048,0xFFF9,0,973,182,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A117_100, (EIF_POINTER) _A117_100, (EIF_POINTER)(F129_2860),tr2, 1, 0);
	}
	F1105_9600(RTCW(tr1), tr3);
	RTHOOK(86);
	RTLE;
	RTEE;
}

/* {WIZARD_INTERMEDIARY_STATE_WINDOW}.pixmap_location */
static EIF_REFERENCE F130_2873_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("pixmap_location", 129, Current, 0, 0, 2978);
	RTGC;
	RTOSP (2873);
#define Result RTOSR(2873)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("eiffel_wizard_icon",18,1807830126);
	tr3 = RTOSCF(2738,F124_2738, (Current));
	tr2 = F1059_9029(tr2, tr3);
	F940_7444(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2873);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F130_2873 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2873,F130_2873_body,(Current));
}

/* {WIZARD_INTERMEDIARY_STATE_WINDOW}.current_help_context */
EIF_REFERENCE F130_2874 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("current_help_context", 129, Current, 2, 0, 2979);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = F1105_9599(RTCW(tr1));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1);
		tr1 = F1049_8758(loc1, tr1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(182, 0),loc2);
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc2;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit117 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
