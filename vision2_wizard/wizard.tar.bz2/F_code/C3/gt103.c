/*
 * Code for class GTK3
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt103.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F116_2308
static void inline_F116_2308 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return gtk_widget_set_halign ((GtkWidget *)arg1, (GtkAlign)arg2)
	;
}
#define INLINE_F116_2308
#endif
#ifndef INLINE_F116_2311
static void inline_F116_2311 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return gtk_widget_set_valign ((GtkWidget *)arg1, (GtkAlign)arg2)
	;
}
#define INLINE_F116_2311
#endif
#ifndef INLINE_F116_2313
static void inline_F116_2313 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_widget_set_margin_start ((GtkWidget *)arg1, (gint)arg2)
	;
}
#define INLINE_F116_2313
#endif
#ifndef INLINE_F116_2315
static void inline_F116_2315 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_widget_set_margin_end ((GtkWidget *)arg1, (gint)arg2)
	;
}
#define INLINE_F116_2315
#endif
#ifndef INLINE_F116_2320
static void inline_F116_2320 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_widget_set_visual ((GtkWidget *)arg1, (GdkVisual *)arg2)
	;
}
#define INLINE_F116_2320
#endif
#ifndef INLINE_F116_2321
static EIF_POINTER inline_F116_2321 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F116_2321
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK3}.gtk_widget_get_preferred_size */
void F116_2302 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_preferred_size", 115, Current, 0, 3, 2415);gtk_widget_get_preferred_size((GtkWidget*) arg1, (GtkRequisition*) arg2, (GtkRequisition*) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK3}.gtk_widget_set_halign */
void F116_2308 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_set_halign", 115, Current, 0, 2, 2421);
	inline_F116_2308 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK3}.gtk_widget_set_valign */
void F116_2311 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_set_valign", 115, Current, 0, 2, 2424);
	inline_F116_2311 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK3}.gtk_widget_set_margin_start */
void F116_2313 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_set_margin_start", 115, Current, 0, 2, 2426);
	inline_F116_2313 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK3}.gtk_widget_set_margin_end */
void F116_2315 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_set_margin_end", 115, Current, 0, 2, 2428);
	inline_F116_2315 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK3}.gtk_widget_set_visual */
void F116_2320 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_set_visual", 115, Current, 0, 2, 2433);
	inline_F116_2320 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK3}.gtk_box_new */
EIF_POINTER F116_2321 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_box_new", 115, Current, 0, 2, 2434);
	Result = inline_F116_2321 ((EIF_NATURAL_8) arg1, (EIF_INTEGER_32) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK3}.gtk_widget_get_style_context */
EIF_POINTER F116_2331 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_style_context", 115, Current, 0, 1, 2444);Result = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit103 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
