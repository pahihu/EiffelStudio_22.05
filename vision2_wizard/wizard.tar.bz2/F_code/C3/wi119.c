/*
 * Code for class WIZARD_FINAL_STATE_WINDOW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi119.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_FINAL_STATE_WINDOW}.display */
void F132_2885 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("display", 131, Current, 0, 0, 2989);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2731(Current);
	tr2 = F124_2763(Current);
	F1151_10209(RTCW(tr1), tr2);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2840[Dtype(Current)-343])(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {WIZARD_FINAL_STATE_WINDOW}.proceed_with_current_info */
void F132_2886 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("proceed_with_current_info", 131, Current, 0, 0, 2990);
	RTGC;
	RTHOOK(1);
	F129_2855(Current);
	RTHOOK(2);
	F1151_10201(RTCV(F124_2731(Current)));
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit119 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
