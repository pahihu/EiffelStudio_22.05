/*
 * Code for class WIZARD_ERROR_STATE_WINDOW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi120.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_ERROR_STATE_WINDOW}.build */
void F133_2893 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("build", 132, Current, 0, 0, 2997);
	RTGC;
	RTHOOK(1);
	F131_2878(Current);
	RTHOOK(2);
	tr1 = F124_2731(Current);
	tr2 = F124_2764(Current);
	F1151_10209(RTCW(tr1), tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {WIZARD_ERROR_STATE_WINDOW}.proceed_with_current_info */
void F133_2894 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("proceed_with_current_info", 132, Current, 0, 0, 2998);
	RTGC;
	RTHOOK(1);
	F343_4993(Current);
	RTHOOK(2);
	F132_2886(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit120 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
