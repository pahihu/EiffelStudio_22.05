/*
 * Code for class SYSTEM_ENCODINGS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sy135.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SYSTEM_ENCODINGS}.console_encoding */
static EIF_REFERENCE F148_3135_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("console_encoding", 147, Current, 0, 0, 3241);
	RTGC;
	RTOSP (3135);
#define Result RTOSR(3135)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(41, 0x00).id, 41, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = F173_3460(RTCV(RTOSCF(3140,F148_3140, (Current))));
	F42_711(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3135);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F148_3135 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3135,F148_3135_body,(Current));
}

/* {SYSTEM_ENCODINGS}.utf8 */
static EIF_REFERENCE F148_3136_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("utf8", 147, Current, 0, 0, 3242);
	RTGC;
	RTOSP (3136);
#define Result RTOSR(3136)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(41, 0x00).id, 41, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(704,F41_704, (Current));
	F42_711(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3136);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F148_3136 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3136,F148_3136_body,(Current));
}

/* {SYSTEM_ENCODINGS}.utf32 */
static EIF_REFERENCE F148_3138_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("utf32", 147, Current, 0, 0, 3244);
	RTGC;
	RTOSP (3138);
#define Result RTOSR(3138)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(41, 0x00).id, 41, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(706,F41_706, (Current));
	F42_711(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3138);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F148_3138 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3138,F148_3138_body,(Current));
}

/* {SYSTEM_ENCODINGS}.system_encodings_i */
static EIF_REFERENCE F148_3140_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("system_encodings_i", 147, Current, 0, 0, 3246);
	RTGC;
	RTOSP (3140);
#define Result RTOSR(3140)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(172, 0x00).id, 172, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3140);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F148_3140 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3140,F148_3140_body,(Current));
}

void EIF_Minit135 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
