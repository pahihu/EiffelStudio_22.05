/*
 * Code for class WIZARD_STATE_MANAGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi115.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_STATE_MANAGER}.back */
void F128_2837 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("back", 127, Current, 0, 0, 2947);
	RTGC;
	RTHOOK(1);
	F1148_10162(RTCV(F124_2731(Current)));
	RTHOOK(2);
	tr1 = F662_5515(RTCV(RTOSCF(2734,F124_2734, (Current))));
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O2847[Dtype(tr1)-128]);
	if (tb1) {
		RTHOOK(3);
		tr1 = F662_5515(RTCV(RTOSCF(2734,F124_2734, (Current))));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2838[Dtype(RTCW(tr1))-343])(tr1);
	}
	RTHOOK(4);
	F669_5599(RTCV(RTOSCF(2734,F124_2734, (Current))));
	RTHOOK(5);
	tr1 = F662_5515(RTCV(RTOSCF(2734,F124_2734, (Current))));
	F129_2851(RTCW(tr1));
	RTHOOK(6);
	tr1 = F662_5515(RTCV(RTOSCF(2734,F124_2734, (Current))));
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2836[Dtype(RTCW(tr1))-343])(tr1);
	RTHOOK(7);
	tr1 = F662_5515(RTCV(RTOSCF(2734,F124_2734, (Current))));
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2834[Dtype(RTCW(tr1))-343])(tr1);
	RTHOOK(8);
	F1148_10163(RTCV(F124_2731(Current)));
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {WIZARD_STATE_MANAGER}.next */
void F128_2838 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("next", 127, Current, 0, 0, 2948);
	RTGC;
	RTHOOK(1);
	F1148_10162(RTCV(F124_2731(Current)));
	RTHOOK(2);
	tb1 = '\0';
	tr1 = F662_5515(RTCV(RTOSCF(2734,F124_2734, (Current))));
	tb2 = *(EIF_BOOLEAN *)(RTCW(tr1) + O2847[Dtype(tr1)-128]);
	if (tb2) {
		tb2 = F669_5597(RTCV(RTOSCF(2734,F124_2734, (Current))));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		for (;;) {
			RTHOOK(3);
			tb1 = F669_5597(RTCV(RTOSCF(2734,F124_2734, (Current))));
			if (tb1) break;
			RTHOOK(4);
			F669_5610(RTCV(RTOSCF(2734,F124_2734, (Current))));
		}
	}
	RTHOOK(5);
	tb2 = F669_5597(RTCV(RTOSCF(2734,F124_2734, (Current))));
	if (tb2) {
		RTHOOK(6);
		tr1 = F662_5515(RTCV(RTOSCF(2734,F124_2734, (Current))));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2838[Dtype(RTCW(tr1))-343])(tr1);
	}
	
	RTHOOK(8);
	tb2 = '\0';
	tb3 = F669_5597(RTCV(RTOSCF(2734,F124_2734, (Current))));
	if ((EIF_BOOLEAN) !tb3) {
		tr1 = F662_5515(RTCV(RTOSCF(2734,F124_2734, (Current))));
		tb3 = *(EIF_BOOLEAN *)(RTCW(tr1) + O2847[Dtype(tr1)-128]);
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		RTHOOK(9);
		F669_5598(RTCV(RTOSCF(2734,F124_2734, (Current))));
		RTHOOK(10);
		tr1 = F662_5515(RTCV(RTOSCF(2734,F124_2734, (Current))));
		F129_2851(RTCW(tr1));
		RTHOOK(11);
		tr1 = F662_5515(RTCV(RTOSCF(2734,F124_2734, (Current))));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2836[Dtype(RTCW(tr1))-343])(tr1);
		RTHOOK(12);
		tr1 = F662_5515(RTCV(RTOSCF(2734,F124_2734, (Current))));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2834[Dtype(RTCW(tr1))-343])(tr1);
	} else {
		RTHOOK(13);
		tr1 = F662_5515(RTCV(RTOSCF(2734,F124_2734, (Current))));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2837[Dtype(RTCW(tr1))-343])(tr1);
	}
	RTHOOK(14);
	tb2 = F1091_9348(RTCV(F124_2731(Current)));
	if ((EIF_BOOLEAN) !tb2) {
		RTHOOK(15);
		F1148_10163(RTCV(F124_2731(Current)));
	}
	RTHOOK(17);
	RTLE;
	RTEE;
}

/* {WIZARD_STATE_MANAGER}.cancel_actions */
void F128_2839 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("cancel_actions", 127, Current, 0, 0, 2949);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O2829[dtype-127])) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current + O2829[dtype-127]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(3);
		F669_5600(RTCV(RTOSCF(2734,F124_2734, (Current))));
		for (;;) {
			RTHOOK(4);
			tb1 = *(EIF_BOOLEAN *)(RTCV(RTOSCF(2734,F124_2734, (Current)))+ _CHROFF_4_1_);
			if (tb1) break;
			RTHOOK(5);
			tr1 = F662_5515(RTCV(RTOSCF(2734,F124_2734, (Current))));
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R2839[Dtype(RTCW(tr1))-343])(tr1);
			RTHOOK(6);
			F669_5599(RTCV(RTOSCF(2734,F124_2734, (Current))));
		}
		RTHOOK(7);
		F669_5611(RTCV(RTOSCF(2734,F124_2734, (Current))));
		RTHOOK(8);
		tr1 = F1085_9298(RTCV(F124_2731(Current)));
		F689_5956(RTCW(tr1));
		for (;;) {
			RTHOOK(9);
			tr1 = F1085_9298(RTCV(F124_2731(Current)));
			tb2 = F638_5502(RTCW(tr1));
			if (tb2) break;
			RTHOOK(10);
			tr1 = F1085_9298(RTCV(F124_2731(Current)));
			tr1 = F689_5930(RTCW(tr1));
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_));
			RTHOOK(11);
			tr1 = F1085_9298(RTCV(F124_2731(Current)));
			F689_5958(RTCW(tr1));
		}
		RTHOOK(12);
		F1151_10201(RTCV(F124_2731(Current)));
		RTHOOK(13);
		*(EIF_BOOLEAN *)(Current + O2829[dtype-127]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {WIZARD_STATE_MANAGER}.show_help */
void F128_2840 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("show_help", 127, Current, 0, 0, 2950);
	RTGC;
	RTHOOK(1);
	tr1 = F662_5515(RTCV(RTOSCF(2734,F124_2734, (Current))));
	F129_2859(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {WIZARD_STATE_MANAGER}.proceed_with_new_state */
void F128_2841 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("proceed_with_new_state", 127, Current, 0, 1, 2951);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(2734,F124_2734, (Current));
	F669_5603(RTCW(tr1), arg1);
	RTHOOK(2);
	tr1 = RTOSCF(2734,F124_2734, (Current));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(2734,F124_2734, (Current)))+ _LNGOFF_4_3_0_0_);
	F662_5537(RTCW(tr1), ti4_1);
	RTHOOK(3);
	F129_2851(RTCW(arg1));
	RTHOOK(4);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2836[Dtype(RTCW(arg1))-343])(arg1);
	RTHOOK(5);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2834[Dtype(RTCW(arg1))-343])(arg1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {WIZARD_STATE_MANAGER}.can_go_back */
EIF_BOOLEAN F128_2842 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("can_go_back", 127, Current, 0, 0, 2952);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {WIZARD_STATE_MANAGER}.can_go_next */
EIF_BOOLEAN F128_2843 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("can_go_next", 127, Current, 0, 0, 2953);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {WIZARD_STATE_MANAGER}.can_cancel */
EIF_BOOLEAN F128_2844 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("can_cancel", 127, Current, 0, 0, 2954);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {WIZARD_STATE_MANAGER}.check_wizard_status */
void F128_2845 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("check_wizard_status", 127, Current, 0, 0, 2955);
	RTGC;
	RTHOOK(1);
	if (F128_2842(Current)) {
		RTHOOK(2);
		F1151_10215(RTCV(F124_2731(Current)));
	} else {
		RTHOOK(3);
		F1151_10212(RTCV(F124_2731(Current)));
	}
	RTHOOK(4);
	if (F128_2843(Current)) {
		RTHOOK(5);
		F1151_10214(RTCV(F124_2731(Current)));
	} else {
		RTHOOK(6);
		F1151_10211(RTCV(F124_2731(Current)));
	}
	RTHOOK(7);
	if (F128_2844(Current)) {
		RTHOOK(8);
		F1151_10216(RTCV(F124_2731(Current)));
	} else {
		RTHOOK(9);
		F1151_10213(RTCV(F124_2731(Current)));
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

void EIF_Minit115 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
