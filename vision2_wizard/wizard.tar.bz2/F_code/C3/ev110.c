/*
 * Code for class EV_LAYOUT_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev110.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_LAYOUT_CONSTANTS}.default_button_width */
static EIF_INTEGER_32 F123_2719_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("default_button_width", 122, Current, 0, 0, 2831);
	RTOSP (2719);
#define Result RTOSR(2719)
	RTHOOK(1);
	Result = F123_2729(Current, ((EIF_INTEGER_32) 75L));
	RTOSE (2719);
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F123_2719 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2719,F123_2719_body,(Current));
}

/* {EV_LAYOUT_CONSTANTS}.default_button_height */
static EIF_INTEGER_32 F123_2720_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("default_button_height", 122, Current, 0, 0, 2832);
	RTOSP (2720);
#define Result RTOSR(2720)
	RTHOOK(1);
	Result = F123_2729(Current, ((EIF_INTEGER_32) 23L));
	RTOSE (2720);
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F123_2720 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2720,F123_2720_body,(Current));
}

/* {EV_LAYOUT_CONSTANTS}.default_padding_size */
static EIF_INTEGER_32 F123_2721_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("default_padding_size", 122, Current, 0, 0, 2833);
	RTOSP (2721);
#define Result RTOSR(2721)
	RTHOOK(1);
	Result = F123_2729(Current, ((EIF_INTEGER_32) 14L));
	RTOSE (2721);
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F123_2721 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2721,F123_2721_body,(Current));
}

/* {EV_LAYOUT_CONSTANTS}.default_border_size */
static EIF_INTEGER_32 F123_2725_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("default_border_size", 122, Current, 0, 0, 2837);
	RTOSP (2725);
#define Result RTOSR(2725)
	RTHOOK(1);
	Result = F123_2729(Current, ((EIF_INTEGER_32) 7L));
	RTOSE (2725);
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F123_2725 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2725,F123_2725_body,(Current));
}

/* {EV_LAYOUT_CONSTANTS}.set_default_size_for_button */
void F123_2727 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_default_size_for_button", 122, Current, 0, 1, 2839);
	RTGC;
	RTHOOK(1);
	ti4_1 = F1114_9699(RTCW(arg1));
	ti4_2 = RTOSCF(2719,F123_2719, (Current));
	ti4_1 = eif_max_int32 (ti4_1,ti4_2);
	ti4_2 = F1114_9700(RTCW(arg1));
	ti4_3 = RTOSCF(2720,F123_2720, (Current));
	ti4_2 = eif_max_int32 (ti4_2,ti4_3);
	F1136_9999(RTCW(arg1), ti4_1, ti4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_LAYOUT_CONSTANTS}.dialog_unit_to_pixels */
EIF_INTEGER_32 F123_2729 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dialog_unit_to_pixels", 122, Current, 0, 1, 2829);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(RTOSCF(2730,F123_2730, (Current)) == ((EIF_INTEGER_32) 96L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) arg1;
	} else {
		RTHOOK(4);
		Result = RTOSCF(2730,F123_2730, (Current));
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 * Result) / ((EIF_INTEGER_32) 96L));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_LAYOUT_CONSTANTS}.resolution */
static EIF_INTEGER_32 F123_2730_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("resolution", 122, Current, 0, 0, 2830);
	RTGC;
	RTOSP (2730);
#define Result RTOSR(2730)
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1125, 0x00).id, 1125, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1091_9344(RTCW(tr1));
	Result = F1126_9836(RTCW(tr1));
	RTOSE (2730);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F123_2730 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2730,F123_2730_body,(Current));
}

void EIF_Minit110 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
