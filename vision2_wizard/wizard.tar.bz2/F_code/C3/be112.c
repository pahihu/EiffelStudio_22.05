/*
 * Code for class BENCH_WIZARD_INTERFACE_NAMES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "be112.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BENCH_WIZARD_INTERFACE_NAMES}.t_project_name_and_location_state */
EIF_REFERENCE F125_2768 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("t_project_name_and_location_state", 124, Current, 0, 0, 2878);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Project Name and Project location",33,2010414190);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.st_project_name_and_location_state */
EIF_REFERENCE F125_2769 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("st_project_name_and_location_state", 124, Current, 0, 0, 2879);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("You can choose the name of the project and\012the directory where the project will be generated.",93,1036771374);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.m_project_name_and_location_state */
EIF_REFERENCE F125_2770 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("m_project_name_and_location_state", 124, Current, 0, 0, 2880);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Please fill in:\012\011 The name of the project (without spaces).\012\011 The directory where you want the Eiffel classes to be generated.",126,189915950);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.l_project_name */
EIF_REFERENCE F125_2771 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("l_project_name", 124, Current, 0, 0, 2881);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Project name",12,1823660133);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.l_project_location */
EIF_REFERENCE F125_2772 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("l_project_location", 124, Current, 0, 0, 2882);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Project location",16,235939694);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.l_support_scoop */
EIF_REFERENCE F125_2773 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("l_support_scoop", 124, Current, 0, 0, 2883);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Enable concurrency",18,2008125305);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.l_compile_project */
EIF_REFERENCE F125_2774 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("l_compile_project", 124, Current, 0, 0, 2884);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Compile the generated project",29,736099444);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.t_project_name_error_state */
EIF_REFERENCE F125_2775 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("t_project_name_error_state", 124, Current, 0, 0, 2885);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Project Name Error",18,1897587314);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.m_project_name_error_state */
EIF_REFERENCE F125_2776 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("m_project_name_error_state", 124, Current, 0, 0, 2886);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("The project name that you have specified does not conform\012to the Lace specification.\012\012A valid project name is not empty and only contains letters,\012digits, and underscores. Moreover the first character must\012be a letter.\012\012Click Back and choose a valid project name.",263,1141418542);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.t_location_state */
EIF_REFERENCE F125_2777 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("t_location_state", 124, Current, 0, 0, 2887);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Location Error",14,1193975154);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.m_location_state */
EIF_REFERENCE F125_2778 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("m_location_state", 124, Current, 0, 0, 2888);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("The directory you have chosen doesn\'t exist and\012the Wizard cannot create it.\012\012Click Back and choose another directory.",118,1108815918);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.t_project_already_exist */
EIF_REFERENCE F125_2779 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("t_project_already_exist", 124, Current, 0, 0, 2889);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Project already exists",22,138608755);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.m_project_already_exist */
EIF_REFERENCE F125_2780 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("m_project_already_exist", 124, Current, 0, 0, 2890);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("The directory you have chosen already contain\012a project.\012\012Click Back to choose another directory.\012\012Click Next to continue and erase actual project.",147,1779740718);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.t_files_already_exist */
EIF_REFERENCE F125_2781 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("t_files_already_exist", 124, Current, 0, 0, 2891);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Files already exist",19,1984100724);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.m_files_already_exist */
EIF_REFERENCE F125_2782 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("m_files_already_exist", 124, Current, 0, 1, 2892);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("The project directory already contains the following files\012that are about to be generated:$1\012\012Click Back to rename a project and to choose another directory.\012\012Click Next to continue and to replace existing files with the new ones.",230,1120275758);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,1053,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F43_732(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.b_ok */
EIF_REFERENCE F125_2783 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("b_ok", 124, Current, 0, 0, 2893);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("OK",2,20299);
	tr3 = RTMS_EX_H("wizard.button",13,1015912558);
	Result = F43_730(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.t_file_read_error */
EIF_REFERENCE F125_2784 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("t_file_read_error", 124, Current, 0, 0, 2894);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Error reading file",18,587540325);
	tr3 = RTMS_EX_H("wizard",6,140496740);
	Result = F43_730(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.m_file_read_error */
EIF_REFERENCE F125_2785 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,arg1);
	RTLR(6,Result);
	RTLIU(7);
	
	RTEAA("m_file_read_error", 124, Current, 0, 1, 2895);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = F124_2746(Current);
	tr3 = RTMS_EX_H("Cannot read file: \"$1\"",22,739479586);
	tr4 = RTMS_EX_H("wizard",6,140496740);
	tr2 = F43_730(RTCW(tr2), tr3, tr4);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,1053,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F43_732(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.t_file_write_error */
EIF_REFERENCE F125_2786 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("t_file_write_error", 124, Current, 0, 0, 2896);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Error writing file",18,268161637);
	tr3 = RTMS_EX_H("wizard",6,140496740);
	Result = F43_730(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BENCH_WIZARD_INTERFACE_NAMES}.m_file_write_error */
EIF_REFERENCE F125_2787 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,arg1);
	RTLR(6,Result);
	RTLIU(7);
	
	RTEAA("m_file_write_error", 124, Current, 0, 1, 2897);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = F124_2746(Current);
	tr3 = RTMS_EX_H("Cannot write file: \"$1\"",23,1080795682);
	tr4 = RTMS_EX_H("wizard",6,140496740);
	tr2 = F43_730(RTCW(tr2), tr3, tr4);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,1053,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F43_732(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit112 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
