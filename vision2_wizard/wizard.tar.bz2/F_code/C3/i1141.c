/*
 * Code for class I18N_FILE_MANAGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1141.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_FILE_MANAGER}.make */
void F154_3167 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("make", 153, Current, 0, 1, 3263);
	RTGC;
	RTHOOK(1);
	F153_3160(Current, arg1);
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(106, 0x00).id, 106, _OBJSIZ_2_1_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = RTLNSMART(eif_new_type(923, 0).id);
	F924_6669(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	F154_3177(Current);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {I18N_FILE_MANAGER}.dictionary */
EIF_REFERENCE F154_3168 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTEAA("dictionary", 153, Current, 3, 1, 3264);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = F154_3169(Current);
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4763[Dtype(RTCW(tr1))-600])(tr1, arg1);
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F680_5800(RTCW(tr1), arg1);
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc1 = F106_1456(RTCW(tr1), loc2);
	} else {
		RTHOOK(3);
		tb1 = '\0';
		tr1 = F154_3170(Current);
		tr2 = F1399_13978(RTCW(arg1));
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4763[Dtype(RTCW(tr1))-600])(tr1, tr2);
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr2 = F1399_13978(RTCW(arg1));
			tr1 = F680_5800(RTCW(tr1), tr2);
			loc3 = tr1;
			tb1 = EIF_TEST(loc3);
		}
		if (tb1) {
			RTHOOK(4);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			loc1 = F106_1456(RTCW(tr1), loc3);
		}
	}
	RTHOOK(5);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(6);
		loc1 = RTLNS(eif_new_type(194, 0x00).id, 194, _OBJSIZ_1_0_0_2_0_0_0_0_);
		F193_3604(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	}
	RTHOOK(7);
	RTHOOK(8);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

/* {I18N_FILE_MANAGER}.available_locales */
EIF_REFERENCE F154_3169 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("available_locales", 153, Current, 0, 0, 3265);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_2_);
}

/* {I18N_FILE_MANAGER}.available_languages */
EIF_REFERENCE F154_3170 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("available_languages", 153, Current, 0, 0, 3266);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_4_);
}

/* {I18N_FILE_MANAGER}.populate_file_lists */
void F154_3177 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc4);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLIU(8);
	
	RTEAA("populate_file_lists", 153, Current, 6, 0, 3273);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {679,1053,1398,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F680_5794(RTCW(tr1), ((EIF_INTEGER_32) 16L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {688,1398,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F689_5925(RTCW(tr1), ((EIF_INTEGER_32) 16L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	{
		static EIF_TYPE_INDEX typarr0[] = {679,1053,1395,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F680_5794(RTCW(tr1), ((EIF_INTEGER_32) 16L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {688,1395,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F689_5925(RTCW(tr1), ((EIF_INTEGER_32) 16L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F359_5038(RTCW(tr1));
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F359_5038(RTCW(tr1));
	RTHOOK(7);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F359_5038(RTCW(tr1));
	RTHOOK(8);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F359_5038(RTCW(tr1));
	RTHOOK(9);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tb2 = F924_6694(RTCW(tr1));
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tb2 = F924_6695(RTCW(tr1));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(10);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F924_6679(RTCW(tr1));
		RTHOOK(11);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc1 = F924_6685(RTCW(tr1));
		RTHOOK(12);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc4 = F924_6675(RTCW(tr1));
		RTHOOK(13);
		F689_5956(RTCW(loc1));
		for (;;) {
			RTHOOK(14);
			tb1 = F638_5502(RTCW(loc1));
			if (tb1) break;
			RTHOOK(15);
			tb2 = '\0';
			tr1 = F689_5930(RTCW(loc1));
			tb3 = F940_7450(RTCW(tr1));
			if ((EIF_BOOLEAN) !tb3) {
				tr1 = F689_5930(RTCW(loc1));
				tb3 = F940_7449(RTCW(tr1));
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				RTHOOK(16);
				tr1 = F689_5930(RTCW(loc1));
				tr1 = F940_7472(RTCW(loc4), tr1);
				loc3 = F940_7483(RTCW(tr1));
				RTHOOK(17);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				loc2 = F106_1454(RTCW(tr1), loc3);
				RTHOOK(18);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(19);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
					loc5 = tr1;
					if (EIF_TEST(loc5)) {
						RTHOOK(20);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F680_5840(RTCW(tr1), loc3, loc5);
						RTHOOK(21);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						tb2 = F680_5823(RTCW(tr1));
						if (tb2) {
							RTHOOK(22);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4895[Dtype(RTCW(tr1))-661])(tr1, loc5);
						}
					} else {
						RTHOOK(23);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_1_);
						loc6 = tr1;
						if (EIF_TEST(loc6)) {
							RTHOOK(24);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
							F680_5840(RTCW(tr1), loc3, loc6);
							RTHOOK(25);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
							tb2 = F680_5823(RTCW(tr1));
							if (tb2) {
								RTHOOK(26);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4895[Dtype(RTCW(tr1))-661])(tr1, loc6);
							}
						}
					}
				}
			}
			RTHOOK(27);
			F689_5958(RTCW(loc1));
		}
	}
	RTHOOK(28);
	RTLE;
	RTEE;
}

void EIF_Minit141 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
