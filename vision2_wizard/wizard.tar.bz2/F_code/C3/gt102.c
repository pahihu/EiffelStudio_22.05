/*
 * Code for class GTK2
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt102.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F115_1885
static EIF_POINTER inline_F115_1885 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_BACKGROUND_COLOR)
	;
}
#define INLINE_F115_1885
#endif
#ifndef INLINE_F115_1886
static EIF_POINTER inline_F115_1886 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_COLOR)
	;
}
#define INLINE_F115_1886
#endif
#ifndef INLINE_F115_1887
static EIF_POINTER inline_F115_1887 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_FONT)
	;
}
#define INLINE_F115_1887
#endif
#ifndef INLINE_F115_1907
static int inline_F115_1907 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	return gtk_style_context_lookup_color((GtkStyleContext*) arg1, (gchar*) arg2, (GdkRGBA*) arg3);
	;
}
#define INLINE_F115_1907
#endif
#ifndef INLINE_F115_1908
static void inline_F115_1908 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	gtk_style_context_get (arg1, arg2, arg3, arg4, NULL)
	;
}
#define INLINE_F115_1908
#endif
#ifndef INLINE_F115_1913
static void inline_F115_1913 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_window_set_accept_focus((GtkWindow*)arg1, (gboolean) arg2)
	;
}
#define INLINE_F115_1913
#endif
#ifndef INLINE_F115_1932
static void inline_F115_1932 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_window_set_icon ((GtkWindow*) arg1, (GdkPixbuf*) arg2)
	;
}
#define INLINE_F115_1932
#endif
#ifndef INLINE_F115_1947
static EIF_POINTER inline_F115_1947 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_8 arg3, EIF_INTEGER_8 arg4, EIF_POINTER arg5)
{
	return (EIF_POINTER) (gtk_icon_theme_load_icon ((GtkIconTheme *)arg1,
                          (const gchar *)arg2,
                          (gint)arg3,
                          (GtkIconLookupFlags)arg4,
                          (GError **)arg5))
	;
}
#define INLINE_F115_1947
#endif
#ifndef INLINE_F115_1948
static EIF_POINTER inline_F115_1948 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_icon_theme_get_for_screen ((GdkScreen*) arg1))
	;
}
#define INLINE_F115_1948
#endif
#ifndef INLINE_F115_1949
static EIF_POINTER inline_F115_1949 (void)
{
	return gtk_icon_theme_get_default ();
	;
}
#define INLINE_F115_1949
#endif
#ifndef INLINE_F115_1983
static int inline_F115_1983 (EIF_POINTER arg1)
{
	return (int) (gtk_widget_has_screen ((GtkWidget*) arg1))
	;
}
#define INLINE_F115_1983
#endif
#ifndef INLINE_F115_1984
static EIF_POINTER inline_F115_1984 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_widget_get_screen ((GtkWidget*) arg1))
	;
}
#define INLINE_F115_1984
#endif
#ifndef INLINE_F115_1986
static void inline_F115_1986 (EIF_POINTER arg1)
{
	gtk_widget_destroy((GtkWidget*) arg1)
	;
}
#define INLINE_F115_1986
#endif
#ifndef INLINE_F115_2025
static void inline_F115_2025 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	gtk_widget_set_size_request ((GtkWidget*) arg1, (gint) arg2, (gint) arg3)
	;
}
#define INLINE_F115_2025
#endif
#ifndef INLINE_F115_2024
static void inline_F115_2024 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	gtk_widget_get_size_request ((GtkWidget*) arg1, (gint*) arg2, (gint*) arg3)
	;
}
#define INLINE_F115_2024
#endif
#ifndef INLINE_F115_2026
static void inline_F115_2026 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_widget_size_allocate ((GtkWidget*) arg1, (GtkAllocation*) arg2)
	;
}
#define INLINE_F115_2026
#endif
#ifndef INLINE_F115_2139
static void inline_F115_2139 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	g_value_set_boolean ((GValue*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F115_2139
#endif
#ifndef INLINE_F115_2190
static void inline_F115_2190 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	g_object_set ((gpointer) arg1, (gchar*) arg2, (gpointer) arg3, NULL)
	;
}
#define INLINE_F115_2190
#endif
#ifndef INLINE_F115_2191
static void inline_F115_2191 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	return g_object_set ((gpointer) arg1, (gchar*) arg2, (gchar*) arg3, NULL);
	;
}
#define INLINE_F115_2191
#endif
#ifndef INLINE_F115_2192
static void inline_F115_2192 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER* arg3)
{
	return g_object_get ((gpointer) arg1, (gchar*) arg2, (gchar**) arg3, NULL);
	;
}
#define INLINE_F115_2192
#endif
#ifndef INLINE_F115_2194
static EIF_INTEGER_32 inline_F115_2194 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gint v;
g_object_get ((gpointer) arg1, (const gchar *) arg2, &v, NULL);
return (EIF_INTEGER) v;
	;
}
#define INLINE_F115_2194
#endif
#ifndef INLINE_F115_2198
static void inline_F115_2198 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	g_object_set((gpointer) arg1, (gchar*) arg2, arg3 ? TRUE : FALSE, NULL)
	;
}
#define INLINE_F115_2198
#endif
#ifndef INLINE_F115_2202
static void inline_F115_2202 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	g_signal_handler_disconnect ((gpointer) arg1, (gulong) arg2)
	;
}
#define INLINE_F115_2202
#endif
#ifndef INLINE_F115_2272
static EIF_POINTER inline_F115_2272 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	return (EIF_POINTER) (gtk_dialog_add_button ((GtkDialog*) arg1, (gchar*) arg2, (gint) arg3))
	;
}
#define INLINE_F115_2272
#endif
#ifndef INLINE_F115_2274
static void inline_F115_2274 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_dialog_set_default_response ((GtkDialog*) arg1, (gint) arg2)
	;
}
#define INLINE_F115_2274
#endif
#ifndef INLINE_F115_2288
static EIF_POINTER inline_F115_2288 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	return (EIF_POINTER) (gtk_file_chooser_dialog_new ((gchar*) arg1, (GtkWindow*) arg2, (GtkFileChooserAction) arg3, NULL, NULL))
	;
}
#define INLINE_F115_2288
#endif
#ifndef INLINE_F115_2290
static EIF_POINTER inline_F115_2290 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_file_chooser_get_filename ((GtkFileChooser*) arg1))
	;
}
#define INLINE_F115_2290
#endif
#ifndef INLINE_F115_2292
static void inline_F115_2292 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_chooser_set_filename ((GtkFileChooser*) arg1, (gchar*) arg2)
	;
}
#define INLINE_F115_2292
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK2}.gtk_style_property_background_color */
EIF_POINTER F115_1885 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_style_property_background_color", 114, Current, 0, 0, 1998);
	Result = inline_F115_1885 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_style_property_color */
EIF_POINTER F115_1886 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_style_property_color", 114, Current, 0, 0, 1999);
	Result = inline_F115_1886 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_style_property_font */
EIF_POINTER F115_1887 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_style_property_font", 114, Current, 0, 0, 2000);
	Result = inline_F115_1887 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_style_context_add_provider */
void F115_1892 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_NATURAL_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_style_context_add_provider", 114, Current, 0, 3, 2005);gtk_style_context_add_provider((GtkStyleContext*) arg1, (GtkStyleProvider*) arg2, (guint) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_style_context_lookup_color */
EIF_BOOLEAN F115_1907 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_style_context_lookup_color", 114, Current, 0, 3, 2020);
	Result = EIF_TEST(inline_F115_1907 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_style_context_get */
void F115_1908 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_style_context_get", 114, Current, 0, 4, 2021);
	inline_F115_1908 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_POINTER) arg3, (EIF_POINTER) arg4);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_window_set_accept_focus */
void F115_1913 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_set_accept_focus", 114, Current, 0, 2, 2026);
	inline_F115_1913 ((EIF_POINTER) arg1, (EIF_BOOLEAN) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_window_get_focus */
EIF_POINTER F115_1914 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_get_focus", 114, Current, 0, 1, 2027);Result = (EIF_POINTER) gtk_window_get_focus((GtkWindow*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_window_get_position */
void F115_1915 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_get_position", 114, Current, 0, 3, 2028);gtk_window_get_position((GtkWindow*) arg1, (gint*) arg2, (gint*) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_window_get_size */
void F115_1916 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_get_size", 114, Current, 0, 3, 2029);gtk_window_get_size((GtkWindow*) arg1, (gint*) arg2, (gint*) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_window_move */
void F115_1918 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_move", 114, Current, 0, 3, 2031);gtk_window_move((GtkWindow*) arg1, (gint) arg2, (gint) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_window_close */
void F115_1919 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_close", 114, Current, 0, 1, 2032);gtk_window_close((GtkWindow*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_window_is_active */
EIF_BOOLEAN F115_1921 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_is_active", 114, Current, 0, 1, 2034);Result = (EIF_BOOLEAN) EIF_TEST(gtk_window_is_active((GtkWindow*) arg1));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_window_resize */
void F115_1922 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_resize", 114, Current, 0, 3, 2035);gtk_window_resize((GtkWindow*) arg1, (gint) arg2, (gint) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_window_deiconify */
void F115_1925 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_deiconify", 114, Current, 0, 1, 2038);gtk_window_deiconify((GtkWindow*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_window_unmaximize */
void F115_1929 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_unmaximize", 114, Current, 0, 1, 2042);gtk_window_unmaximize((GtkWindow*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_window_set_icon */
void F115_1932 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_set_icon", 114, Current, 0, 2, 2045);
	inline_F115_1932 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_win_pos_center_on_parent_enum */
EIF_INTEGER_32 F115_1933 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_win_pos_center_on_parent_enum", 114, Current, 0, 0, 2046);
	Result = (EIF_INTEGER_32) GTK_WIN_POS_CENTER_ON_PARENT;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_event_box_new */
EIF_POINTER F115_1934 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_event_box_new", 114, Current, 0, 0, 2047);Result = (EIF_POINTER) gtk_event_box_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_is_event_box */
EIF_BOOLEAN F115_1935 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_is_event_box", 114, Current, 0, 1, 2048);
	Result = (EIF_BOOLEAN) EIF_TEST(GTK_IS_EVENT_BOX((arg1)));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_event_box_set_visible_window */
void F115_1936 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_event_box_set_visible_window", 114, Current, 0, 2, 2049);gtk_event_box_set_visible_window((GtkEventBox*) arg1, (gboolean) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_orientable_set_orientation */
void F115_1938 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_NATURAL_8 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_orientable_set_orientation", 114, Current, 0, 2, 2051);gtk_orientable_set_orientation((GtkOrientable*) arg1, (GtkOrientation) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_layout_new */
EIF_POINTER F115_1939 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_layout_new", 114, Current, 0, 2, 2052);Result = (EIF_POINTER) gtk_layout_new((GtkAdjustment*) arg1, (GtkAdjustment*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_layout_set_size */
void F115_1942 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_layout_set_size", 114, Current, 0, 3, 2055);gtk_layout_set_size((GtkLayout*) arg1, (guint) arg2, (guint) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_icon_theme_load_icon */
EIF_POINTER F115_1947 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_8 arg3, EIF_INTEGER_8 arg4, EIF_POINTER arg5)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_icon_theme_load_icon", 114, Current, 0, 5, 2060);
	Result = inline_F115_1947 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_8) arg3, (EIF_INTEGER_8) arg4, (EIF_POINTER) arg5);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_icon_theme_get_for_screen */
EIF_POINTER F115_1948 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_icon_theme_get_for_screen", 114, Current, 0, 1, 2061);
	Result = inline_F115_1948 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_icon_theme_get_default */
EIF_POINTER F115_1949 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_icon_theme_get_default", 114, Current, 0, 0, 2062);
	Result = inline_F115_1949 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_im_context_simple_new */
EIF_POINTER F115_1966 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_im_context_simple_new", 114, Current, 0, 0, 2079);Result = (EIF_POINTER) gtk_im_context_simple_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_im_context_reset */
void F115_1967 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_im_context_reset", 114, Current, 0, 1, 2080);gtk_im_context_reset((GtkIMContext*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_im_context_focus_in */
void F115_1968 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_im_context_focus_in", 114, Current, 0, 1, 2081);gtk_im_context_focus_in((GtkIMContext*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_im_context_filter_keypress */
EIF_BOOLEAN F115_1970 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_im_context_filter_keypress", 114, Current, 0, 2, 2083);Result = (EIF_BOOLEAN) EIF_TEST(gtk_im_context_filter_keypress((GtkIMContext*) arg1, (GdkEventKey*) arg2));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_im_context_set_client_window */
void F115_1971 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_im_context_set_client_window", 114, Current, 0, 2, 2084);gtk_im_context_set_client_window((GtkIMContext*) arg1, (GdkWindow*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.events_pending */
EIF_BOOLEAN F115_1973 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("events_pending", 114, Current, 0, 0, 2086);
	Result = (EIF_BOOLEAN) EIF_TEST(g_main_context_pending (NULL));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_event_iteration */
EIF_BOOLEAN F115_1974 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_event_iteration", 114, Current, 0, 0, 2087);
	Result = (EIF_BOOLEAN) EIF_TEST(g_main_context_iteration(NULL, FALSE));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.dispatch_events */
void F115_1977 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dispatch_events", 114, Current, 0, 0, 2090);
	g_main_context_dispatch(g_main_context_default());
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_widget_is_toplevel */
EIF_BOOLEAN F115_1982 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_is_toplevel", 114, Current, 0, 1, 2095);Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_toplevel((GtkWidget*) arg1));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_widget_has_screen */
EIF_BOOLEAN F115_1983 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_has_screen", 114, Current, 0, 1, 2096);
	Result = EIF_TEST(inline_F115_1983 ((EIF_POINTER) arg1));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_widget_get_screen */
EIF_POINTER F115_1984 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_screen", 114, Current, 0, 1, 2097);
	Result = inline_F115_1984 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_widget_destroy */
void F115_1986 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_destroy", 114, Current, 0, 1, 2099);
	inline_F115_1986 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_toolbar_new */
EIF_POINTER F115_1987 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_toolbar_new", 114, Current, 0, 0, 2100);Result = (EIF_POINTER) gtk_toolbar_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_toolbar_set_style */
void F115_1988 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_toolbar_set_style", 114, Current, 0, 2, 2101);gtk_toolbar_set_style((GtkToolbar*) arg1, (GtkToolbarStyle) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_toolbar_set_show_arrow */
void F115_1989 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_toolbar_set_show_arrow", 114, Current, 0, 2, 2102);gtk_toolbar_set_show_arrow((GtkToolbar*) arg1, (gboolean) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_toolbar_insert */
void F115_1990 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_toolbar_insert", 114, Current, 0, 3, 2103);gtk_toolbar_insert((GtkToolbar*) arg1, (GtkToolItem*) arg2, (gint) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_toolbar_icons_enum */
EIF_INTEGER_32 F115_1991 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_toolbar_icons_enum", 114, Current, 0, 0, 2104);
	Result = (EIF_INTEGER_32) GTK_TOOLBAR_ICONS;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_toolbar_text_enum */
EIF_INTEGER_32 F115_1992 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_toolbar_text_enum", 114, Current, 0, 0, 2105);
	Result = (EIF_INTEGER_32) GTK_TOOLBAR_TEXT;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_toolbar_both_enum */
EIF_INTEGER_32 F115_1993 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_toolbar_both_enum", 114, Current, 0, 0, 2106);
	Result = (EIF_INTEGER_32) GTK_TOOLBAR_BOTH;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_toolbar_both_horiz_enum */
EIF_INTEGER_32 F115_1994 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_toolbar_both_horiz_enum", 114, Current, 0, 0, 2107);
	Result = (EIF_INTEGER_32) GTK_TOOLBAR_BOTH_HORIZ;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_label_get_label */
EIF_POINTER F115_1997 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_label_get_label", 114, Current, 0, 1, 2110);Result = (EIF_POINTER) gtk_label_get_label((GtkLabel*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_scrolled_window_set_shadow_type */
void F115_1999 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_scrolled_window_set_shadow_type", 114, Current, 0, 2, 2112);gtk_scrolled_window_set_shadow_type((GtkScrolledWindow*) arg1, (GtkShadowType) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_entry_set_alignment */
void F115_2005 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_entry_set_alignment", 114, Current, 0, 2, 2118);gtk_entry_set_alignment((GtkEntry*) arg1, (gfloat) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_get_current_event_time */
EIF_NATURAL_32 F115_2006 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_get_current_event_time", 114, Current, 0, 0, 2119);Result = (EIF_NATURAL_32) gtk_get_current_event_time();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gdk_event_window_state_struct_changed_mask */
EIF_INTEGER_32 F115_2012 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_window_state_struct_changed_mask", 114, Current, 0, 1, 2125);Result = (EIF_INTEGER_32) (((GdkEventWindowState *)arg1)->changed_mask);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gdk_event_window_state_struct_new_window_state */
EIF_INTEGER_32 F115_2013 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_window_state_struct_new_window_state", 114, Current, 0, 1, 2126);Result = (EIF_INTEGER_32) (((GdkEventWindowState *)arg1)->new_window_state);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_widget_get_has_window */
EIF_BOOLEAN F115_2014 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_has_window", 114, Current, 0, 1, 2127);Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_has_window((GtkWidget*) arg1));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_widget_set_redraw_on_allocate */
void F115_2016 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_set_redraw_on_allocate", 114, Current, 0, 2, 2129);gtk_widget_set_redraw_on_allocate((GtkWidget*) arg1, (gboolean) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_widget_set_can_default */
void F115_2017 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_set_can_default", 114, Current, 0, 2, 2130);gtk_widget_set_can_default((GtkWidget*) arg1, (gboolean) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_widget_set_app_paintable */
void F115_2018 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_set_app_paintable", 114, Current, 0, 2, 2131);gtk_widget_set_app_paintable((GtkWidget*) arg1, (gboolean) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_widget_set_minimum_size */
void F115_2021 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	
	
	RTEAA("gtk_widget_set_minimum_size", 114, Current, 0, 3, 2134);
	RTHOOK(1);
	inline_F115_2025(arg1, arg2, arg3);
	RTHOOK(2);
	RTEE;
}

/* {GTK2}.gtk_widget_get_size_request */
void F115_2024 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_size_request", 114, Current, 0, 3, 2137);
	inline_F115_2024 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_widget_set_size_request */
void F115_2025 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_set_size_request", 114, Current, 0, 3, 2138);
	inline_F115_2025 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_widget_size_allocate */
void F115_2026 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_size_allocate", 114, Current, 0, 2, 2139);
	inline_F115_2026 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_separator_tool_item_new */
EIF_POINTER F115_2031 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_separator_tool_item_new", 114, Current, 0, 0, 2144);Result = (EIF_POINTER) gtk_separator_tool_item_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_radio_tool_button_set_group */
void F115_2038 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_radio_tool_button_set_group", 114, Current, 0, 2, 2151);gtk_radio_tool_button_set_group((GtkRadioToolButton*) arg1, (GSList*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_radio_tool_button_get_group */
EIF_POINTER F115_2039 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_radio_tool_button_get_group", 114, Current, 0, 1, 2152);Result = (EIF_POINTER) gtk_radio_tool_button_get_group((GtkRadioToolButton*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_ok_enum_label */
EIF_POINTER F115_2044 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("gtk_ok_enum_label", 114, Current, 0, 0, 2157);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(298, 0x00).id, 298, _OBJSIZ_1_0_0_1_0_0_0_0_);
	tr2 = RTMS_EX_H("_OK",3,6246219);
	F299_4560(RTCW(tr1), tr2);
	Result = F299_4582(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_response_ok_enum */
EIF_INTEGER_32 F115_2046 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_response_ok_enum", 114, Current, 0, 0, 2159);
	Result = (EIF_INTEGER_32) GTK_RESPONSE_OK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_response_accept_enum */
EIF_INTEGER_32 F115_2050 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_response_accept_enum", 114, Current, 0, 0, 2163);
	Result = (EIF_INTEGER_32) GTK_RESPONSE_ACCEPT;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_response_cancel_enum */
EIF_INTEGER_32 F115_2051 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_response_cancel_enum", 114, Current, 0, 0, 2164);
	Result = (EIF_INTEGER_32) GTK_RESPONSE_CANCEL;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_cancel_enum_label */
EIF_POINTER F115_2054 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("gtk_cancel_enum_label", 114, Current, 0, 0, 2167);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(298, 0x00).id, 298, _OBJSIZ_1_0_0_1_0_0_0_0_);
	tr2 = RTMS_EX_H("_CANCEL",7,2015767884);
	F299_4560(RTCW(tr1), tr2);
	Result = F299_4582(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.g_value_set_boolean */
void F115_2139 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_value_set_boolean", 114, Current, 0, 2, 2252);
	inline_F115_2139 ((EIF_POINTER) arg1, (EIF_BOOLEAN) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_entry_set_max_length */
void F115_2160 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_entry_set_max_length", 114, Current, 0, 2, 2273);gtk_entry_set_max_length((GtkEntry*) arg1, (gint) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_fixed_new */
EIF_POINTER F115_2163 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_fixed_new", 114, Current, 0, 0, 2276);Result = (EIF_POINTER) gtk_fixed_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_label_set_text_with_mnemonic */
void F115_2176 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_label_set_text_with_mnemonic", 114, Current, 0, 2, 2289);gtk_label_set_text_with_mnemonic((GtkLabel*) arg1, (gchar*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_value_pointer */
EIF_POINTER F115_2180 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_value_pointer", 114, Current, 0, 1, 2293);Result = (EIF_POINTER) g_value_peek_pointer((GValue*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_value_int */
EIF_INTEGER_32 F115_2181 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_value_int", 114, Current, 0, 1, 2294);Result = (EIF_INTEGER_32) g_value_get_int((GValue*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_widget_create_pango_layout */
EIF_POINTER F115_2187 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_create_pango_layout", 114, Current, 0, 2, 2300);Result = (EIF_POINTER) gtk_widget_create_pango_layout((GtkWidget*) arg1, (gchar*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_widget_get_mapped */
EIF_BOOLEAN F115_2188 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_mapped", 114, Current, 0, 1, 2301);Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_mapped((GtkWidget*) arg1));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.g_object_set_pointer */
void F115_2190 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_object_set_pointer", 114, Current, 0, 3, 2303);
	inline_F115_2190 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.g_object_set_string */
void F115_2191 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_object_set_string", 114, Current, 0, 3, 2304);
	inline_F115_2191 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.g_object_get_string */
void F115_2192 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER* arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_object_get_string", 114, Current, 0, 3, 2305);
	inline_F115_2192 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER*) arg3);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.g_object_get_integer */
EIF_INTEGER_32 F115_2194 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_object_get_integer", 114, Current, 0, 2, 2307);
	Result = inline_F115_2194 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.g_object_set_menu_icons */
void F115_2198 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_object_set_menu_icons", 114, Current, 0, 3, 2311);
	inline_F115_2198 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_BOOLEAN) arg3);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.signal_disconnect */
void F115_2201 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("signal_disconnect", 114, Current, 0, 2, 2314);
	RTGC;
	RTHOOK(1);
	inline_F115_2202(arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {GTK2}.c_signal_disconnect */
void F115_2202 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_signal_disconnect", 114, Current, 0, 2, 2315);
	inline_F115_2202 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_text_view_new */
EIF_POINTER F115_2206 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_text_view_new", 114, Current, 0, 0, 2319);Result = (EIF_POINTER) gtk_text_view_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_text_view_get_buffer */
EIF_POINTER F115_2210 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_text_view_get_buffer", 114, Current, 0, 1, 2323);Result = (EIF_POINTER) gtk_text_view_get_buffer((GtkTextView*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_text_buffer_set_text */
void F115_2212 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_text_buffer_set_text", 114, Current, 0, 3, 2325);gtk_text_buffer_set_text((GtkTextBuffer*) arg1, (gchar*) arg2, (gint) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_text_buffer_get_bounds */
void F115_2218 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_text_buffer_get_bounds", 114, Current, 0, 3, 2331);gtk_text_buffer_get_bounds((GtkTextBuffer*) arg1, (GtkTextIter*) arg2, (GtkTextIter*) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_text_buffer_get_text */
EIF_POINTER F115_2223 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_BOOLEAN arg4)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_text_buffer_get_text", 114, Current, 0, 4, 2336);Result = (EIF_POINTER) gtk_text_buffer_get_text((GtkTextBuffer*) arg1, (GtkTextIter*) arg2, (GtkTextIter*) arg3, (gboolean) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_text_view_set_editable */
void F115_2228 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_text_view_set_editable", 114, Current, 0, 2, 2341);gtk_text_view_set_editable((GtkTextView*) arg1, (gboolean) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_text_view_set_wrap_mode */
void F115_2229 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_text_view_set_wrap_mode", 114, Current, 0, 2, 2342);gtk_text_view_set_wrap_mode((GtkTextView*) arg1, (GtkWrapMode) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_image_new_from_pixbuf */
EIF_POINTER F115_2269 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_image_new_from_pixbuf", 114, Current, 0, 1, 2382);Result = (EIF_POINTER) gtk_image_new_from_pixbuf((GdkPixbuf*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_dialog_new */
EIF_POINTER F115_2271 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_dialog_new", 114, Current, 0, 0, 2384);Result = (EIF_POINTER) gtk_dialog_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_dialog_add_button */
EIF_POINTER F115_2272 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_dialog_add_button", 114, Current, 0, 3, 2385);
	Result = inline_F115_2272 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_dialog_set_default_response */
void F115_2274 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_dialog_set_default_response", 114, Current, 0, 2, 2387);
	inline_F115_2274 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK2}.gtk_file_chooser_action_select_folder_enum */
EIF_INTEGER_32 F115_2283 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_file_chooser_action_select_folder_enum", 114, Current, 0, 0, 2396);
	Result = (EIF_INTEGER_32) GTK_FILE_CHOOSER_ACTION_SELECT_FOLDER;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_file_chooser_dialog_new */
EIF_POINTER F115_2288 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_file_chooser_dialog_new", 114, Current, 0, 3, 2401);
	Result = inline_F115_2288 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_file_chooser_get_filename */
EIF_POINTER F115_2290 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_file_chooser_get_filename", 114, Current, 0, 1, 2403);
	Result = inline_F115_2290 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK2}.gtk_file_chooser_set_filename */
void F115_2292 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_file_chooser_set_filename", 114, Current, 0, 2, 2405);
	inline_F115_2292 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit102 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
