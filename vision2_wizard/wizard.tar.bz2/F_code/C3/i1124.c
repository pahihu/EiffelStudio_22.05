/*
 * Code for class I18N_CURRENCY_VALUE_FORMATTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1124.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_CURRENCY_VALUE_FORMATTER}.make_from_currency_info */
void F137_2932 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("make_from_currency_info", 136, Current, 0, 1, 3037);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O3052[Dtype(arg1)-143]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O3053[Dtype(arg1)-143]);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_0_0_0_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O3054[Dtype(arg1)-143]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O3058[Dtype(arg1)-143]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O3056[Dtype(arg1)-143]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O3057[Dtype(arg1)-143]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_VALUE_FORMATTER}.make_from_locale_info */
void F137_2933 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("make_from_locale_info", 136, Current, 0, 1, 3038);
	RTHOOK(1);
	F137_2932(Current, arg1);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit124 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
