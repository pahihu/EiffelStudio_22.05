/*
 * Code for class I18N_DATE_TIME_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1129.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_DATE_TIME_INFO}.make */
void F142_3016 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 141, Current, 0, 0, 3124);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(3043,F142_3043, (Current));
	F142_3034(Current, tr1);
	RTHOOK(2);
	tr1 = RTOSCF(3046,F142_3046, (Current));
	F142_3035(Current, tr1);
	RTHOOK(3);
	tr1 = RTOSCF(3045,F142_3045, (Current));
	F142_3036(Current, tr1);
	RTHOOK(4);
	tr1 = RTOSCF(3046,F142_3046, (Current));
	F142_3037(Current, tr1);
	RTHOOK(5);
	tr1 = RTOSCF(3047,F142_3047, (Current));
	F142_3038(Current, tr1);
	RTHOOK(6);
	tr1 = RTOSCF(3048,F142_3048, (Current));
	F142_3039(Current, tr1);
	RTHOOK(7);
	tr1 = RTOSCF(3049,F142_3049, (Current));
	F142_3040(Current, tr1);
	RTHOOK(8);
	tr1 = RTOSCF(3055,F142_3055, (Current));
	F142_3041(Current, tr1);
	RTHOOK(9);
	tr1 = RTOSCF(3054,F142_3054, (Current));
	F142_3042(Current, tr1);
	RTHOOK(10);
	tr1 = RTOSCF(3050,F142_3050, (Current));
	F142_3030(Current, tr1);
	RTHOOK(11);
	tr1 = RTOSCF(3051,F142_3051, (Current));
	F142_3032(Current, tr1);
	RTHOOK(12);
	tr1 = RTOSCF(3052,F142_3052, (Current));
	F142_3031(Current, tr1);
	RTHOOK(13);
	tr1 = RTOSCF(3053,F142_3053, (Current));
	F142_3033(Current, tr1);
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_day_names */
void F142_3030 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_day_names", 141, Current, 0, 1, 3138);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_abbreviated_day_names */
void F142_3031 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_abbreviated_day_names", 141, Current, 0, 1, 3139);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_month_names */
void F142_3032 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_month_names", 141, Current, 0, 1, 3140);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_abbreviated_month_names */
void F142_3033 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_abbreviated_month_names", 141, Current, 0, 1, 3141);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_date_time_format */
void F142_3034 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_date_time_format", 141, Current, 0, 1, 3142);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_long_date_format */
void F142_3035 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_long_date_format", 141, Current, 0, 1, 3143);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_short_date_format */
void F142_3036 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_short_date_format", 141, Current, 0, 1, 3144);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_long_time_format */
void F142_3037 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_long_time_format", 141, Current, 0, 1, 3145);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_short_time_format */
void F142_3038 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_short_time_format", 141, Current, 0, 1, 3146);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_am_suffix */
void F142_3039 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_am_suffix", 141, Current, 0, 1, 3147);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_pm_suffix */
void F142_3040 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_pm_suffix", 141, Current, 0, 1, 3148);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_time_separator */
void F142_3041 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_time_separator", 141, Current, 0, 1, 3149);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_date_separator */
void F142_3042 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_date_separator", 141, Current, 0, 1, 3150);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.default_date_time_format */
static EIF_REFERENCE F142_3043_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_date_time_format", 141, Current, 0, 0, 3151);
	RTGC;
	RTOSP (3043);
#define Result RTOSR(3043)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1054_8767(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(3044,F142_3044, (Current));
	F1063_9178(RTCW(Result), tr1);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'T';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(4);
	tr1 = RTOSCF(3046,F142_3046, (Current));
	F1063_9178(RTCW(Result), tr1);
	RTOSE (3043);
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F142_3043 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3043,F142_3043_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_long_date_format */
static EIF_REFERENCE F142_3044_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_long_date_format", 141, Current, 0, 0, 3152);
	RTGC;
	RTOSP (3044);
#define Result RTOSR(3044)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1054_8767(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Y';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(4);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(5);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(6);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'm';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(7);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(8);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(9);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'e';
	F1063_9192(RTCW(Result), tw1);
	RTOSE (3044);
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F142_3044 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3044,F142_3044_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_short_date_format */
static EIF_REFERENCE F142_3045_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_short_date_format", 141, Current, 0, 0, 3153);
	RTGC;
	RTOSP (3045);
#define Result RTOSR(3045)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1054_8767(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Y';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(4);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(5);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(6);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'm';
	F1063_9192(RTCW(Result), tw1);
	RTOSE (3045);
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F142_3045 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3045,F142_3045_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_long_time_format */
static EIF_REFERENCE F142_3046_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_long_time_format", 141, Current, 0, 0, 3154);
	RTGC;
	RTOSP (3046);
#define Result RTOSR(3046)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1054_8767(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(3047,F142_3047, (Current));
	F1063_9178(RTCW(Result), tr1);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(4);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(5);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '5';
	F1063_9192(RTCW(Result), tw1);
	RTOSE (3046);
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F142_3046 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3046,F142_3046_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_short_time_format */
static EIF_REFERENCE F142_3047_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_short_time_format", 141, Current, 0, 0, 3155);
	RTGC;
	RTOSP (3047);
#define Result RTOSR(3047)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1054_8767(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'k';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(4);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(5);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1063_9192(RTCW(Result), tw1);
	RTHOOK(6);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'M';
	F1063_9192(RTCW(Result), tw1);
	RTOSE (3047);
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F142_3047 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3047,F142_3047_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_am_suffix */
static EIF_REFERENCE F142_3048_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_am_suffix", 141, Current, 0, 0, 3156);
	RTGC;
	RTOSP (3048);
#define Result RTOSR(3048)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H("a\000\000\000m\000\000\000",2,24941);
	RTOSE (3048);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F142_3048 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3048,F142_3048_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_pm_suffix */
static EIF_REFERENCE F142_3049_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_pm_suffix", 141, Current, 0, 0, 3157);
	RTGC;
	RTOSP (3049);
#define Result RTOSR(3049)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H("p\000\000\000m\000\000\000",2,28781);
	RTOSE (3049);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F142_3049 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3049,F142_3049_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_day_names */
static EIF_REFERENCE F142_3050_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("default_day_names", 141, Current, 0, 0, 3158);
	RTGC;
	RTOSP (3050);
#define Result RTOSR(3050)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {858,1062,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 7L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 7L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1054_8827(RTMS_EX_H("Monday",6,2004312953));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Tuesday",7,1495753593));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Wednesday",9,1804915065));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Thursday",8,844137593));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Friday",6,1906687353));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Saturday",8,1596931193));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Sunday",6,2016155513));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F859_6501)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3050);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F142_3050 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3050,F142_3050_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_month_names */
static EIF_REFERENCE F142_3051_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("default_month_names", 141, Current, 0, 0, 3159);
	RTGC;
	RTOSP (3051);
#define Result RTOSR(3051)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {858,1062,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 12L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1054_8827(RTMS_EX_H("January",7,751658105));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("February",8,1474449017));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("March",5,1635477864));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("April",5,1887045484));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("May",3,5071225));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("June",4,1249209957));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("July",4,1249209465));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("August",6,1864444276));
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("September",9,1077346930));
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("October",7,1024137842));
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("November",8,2119563634));
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("December",8,1341698930));
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F859_6501)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3051);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F142_3051 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3051,F142_3051_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_abbreviated_day_names */
static EIF_REFERENCE F142_3052_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("default_abbreviated_day_names", 141, Current, 0, 0, 3160);
	RTGC;
	RTOSP (3052);
#define Result RTOSR(3052)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {858,1062,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 7L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 7L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1054_8827(RTMS_EX_H("Mon",3,5074798));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Tue",3,5535077));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Wed",3,5727588));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Thu",3,5531765));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Fri",3,4616809));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Sat",3,5464436));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Sun",3,5469550));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F859_6501)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3052);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F142_3052 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3052,F142_3052_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_abbreviated_month_names */
static EIF_REFERENCE F142_3053_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("default_abbreviated_month_names", 141, Current, 0, 0, 3121);
	RTGC;
	RTOSP (3053);
#define Result RTOSR(3053)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {858,1062,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 12L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1054_8827(RTMS_EX_H("Jan",3,4874606));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Feb",3,4613474));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Mar",3,5071218));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Apr",3,4288626));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("May",3,5071225));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Jun",3,4879726));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Jul",3,4879724));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Aug",3,4289895));
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Sep",3,5465456));
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Oct",3,5202804));
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Nov",3,5140342));
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1054_8827(RTMS_EX_H("Dec",3,4482403));
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F859_6501)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3053);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F142_3053 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3053,F142_3053_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_date_separator */
static EIF_REFERENCE F142_3054_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_date_separator", 141, Current, 0, 0, 3122);
	RTGC;
	RTOSP (3054);
#define Result RTOSR(3054)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H("/\000\000\000",1,47);
	RTOSE (3054);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F142_3054 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3054,F142_3054_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_time_separator */
static EIF_REFERENCE F142_3055_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_time_separator", 141, Current, 0, 0, 3123);
	RTGC;
	RTOSP (3055);
#define Result RTOSR(3055)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H(":\000\000\000",1,58);
	RTOSE (3055);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F142_3055 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3055,F142_3055_body,(Current));
}

void EIF_Minit129 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
