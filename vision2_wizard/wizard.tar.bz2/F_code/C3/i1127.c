/*
 * Code for class I18N_POSIX_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1127.h"
#include "eif_langinfo.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F140_2963
static EIF_INTEGER_32 inline_F140_2963 (void)
{
	return ABDAY_1;
	;
}
#define INLINE_F140_2963
#endif
#ifndef INLINE_F140_2970
static EIF_INTEGER_32 inline_F140_2970 (void)
{
	return DAY_1;
	;
}
#define INLINE_F140_2970
#endif
#ifndef INLINE_F140_2977
static EIF_INTEGER_32 inline_F140_2977 (void)
{
	return ABMON_1;
	;
}
#define INLINE_F140_2977
#endif
#ifndef INLINE_F140_2989
static EIF_INTEGER_32 inline_F140_2989 (void)
{
	return MON_1;
	;
}
#define INLINE_F140_2989
#endif
#ifndef INLINE_F140_3001
static EIF_INTEGER_32 inline_F140_3001 (void)
{
	return AM_STR;
	;
}
#define INLINE_F140_3001
#endif
#ifndef INLINE_F140_3002
static EIF_INTEGER_32 inline_F140_3002 (void)
{
	return PM_STR;
	;
}
#define INLINE_F140_3002
#endif
#ifndef INLINE_F140_3003
static EIF_INTEGER_32 inline_F140_3003 (void)
{
	return D_T_FMT;
	;
}
#define INLINE_F140_3003
#endif
#ifndef INLINE_F140_3004
static EIF_INTEGER_32 inline_F140_3004 (void)
{
	return D_FMT;
	;
}
#define INLINE_F140_3004
#endif
#ifndef INLINE_F140_3005
static EIF_INTEGER_32 inline_F140_3005 (void)
{
	return T_FMT;
	;
}
#define INLINE_F140_3005
#endif
#ifndef INLINE_F140_3007
static EIF_INTEGER_32 inline_F140_3007 (void)
{
	return CRNCYSTR;
	;
}
#define INLINE_F140_3007
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_POSIX_CONSTANTS}.abday_1 */
EIF_INTEGER_32 F140_2963 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("abday_1", 139, Current, 0, 0, 3094);
	Result = inline_F140_2963 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.day_1 */
EIF_INTEGER_32 F140_2970 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("day_1", 139, Current, 0, 0, 3101);
	Result = inline_F140_2970 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.abmon_1 */
EIF_INTEGER_32 F140_2977 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("abmon_1", 139, Current, 0, 0, 3108);
	Result = inline_F140_2977 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.mon_1 */
EIF_INTEGER_32 F140_2989 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("mon_1", 139, Current, 0, 0, 3075);
	Result = inline_F140_2989 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.am_str */
EIF_INTEGER_32 F140_3001 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("am_str", 139, Current, 0, 0, 3087);
	Result = inline_F140_3001 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.pm_str */
EIF_INTEGER_32 F140_3002 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pm_str", 139, Current, 0, 0, 3088);
	Result = inline_F140_3002 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.d_t_fmt */
EIF_INTEGER_32 F140_3003 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("d_t_fmt", 139, Current, 0, 0, 3089);
	Result = inline_F140_3003 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.d_fmt */
EIF_INTEGER_32 F140_3004 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("d_fmt", 139, Current, 0, 0, 3090);
	Result = inline_F140_3004 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.t_fmt */
EIF_INTEGER_32 F140_3005 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("t_fmt", 139, Current, 0, 0, 3091);
	Result = inline_F140_3005 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.crncystr */
EIF_INTEGER_32 F140_3007 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("crncystr", 139, Current, 0, 0, 3093);
	Result = inline_F140_3007 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit127 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
