/*
 * Code for class I18N_DATASOURCE_MANAGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1140.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_DATASOURCE_MANAGER}.make */
void F153_3160 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("make", 152, Current, 0, 1, 3261);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1062, 0).id);
	F1063_9139(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATASOURCE_MANAGER}.has_locale */
EIF_BOOLEAN F153_3164 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("has_locale", 152, Current, 0, 1, 3258);
	RTGC;
	RTHOOK(1);
	tr1 = F154_3169(Current);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4763[Dtype(RTCW(tr1))-600])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_DATASOURCE_MANAGER}.has_language */
EIF_BOOLEAN F153_3165 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("has_language", 152, Current, 0, 1, 3259);
	RTGC;
	RTHOOK(1);
	tr1 = F154_3170(Current);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4763[Dtype(RTCW(tr1))-600])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit140 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
