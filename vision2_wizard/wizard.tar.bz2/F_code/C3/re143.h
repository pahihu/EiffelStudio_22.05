
#ifndef _C3_re143_
#define _C3_re143_

#ifdef __cplusplus
extern "C" {
#endif

extern void F156_3191(EIF_REFERENCE, EIF_REFERENCE);
extern void F156_3192(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit143(void);

#ifdef __cplusplus
}
#endif

#endif
