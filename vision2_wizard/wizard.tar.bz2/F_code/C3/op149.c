/*
 * Code for class OPERATING_ENVIRONMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "op149.h"
#include "eif_dir.h"
#include "eif_path_name.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {OPERATING_ENVIRONMENT}.directory_separator */
static EIF_CHARACTER_8 F162_3267_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("directory_separator", 161, Current, 0, 0, 3362);
	RTOSP (3267);
#define Result RTOSR(3267)
	RTHOOK(1);
	Result = (EIF_CHARACTER_8) eif_dir_separator();
	RTOSE (3267);
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_CHARACTER_8 F162_3267 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3267,F162_3267_body,(Current));
}

/* {OPERATING_ENVIRONMENT}.home_directory_supported */
EIF_BOOLEAN F162_3269 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("home_directory_supported", 161, Current, 0, 0, 3364);Result = (EIF_BOOLEAN) EIF_TEST(eif_home_dir_supported());
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {OPERATING_ENVIRONMENT}.case_sensitive_path_names */
EIF_BOOLEAN F162_3271 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("case_sensitive_path_names", 161, Current, 0, 0, 3366);Result = (EIF_BOOLEAN) EIF_TEST(eif_case_sensitive_path_names());
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {OPERATING_ENVIRONMENT}.c_dir_separator */
EIF_CHARACTER_8 F162_3272 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_dir_separator", 161, Current, 0, 0, 3367);Result = (EIF_CHARACTER_8) eif_dir_separator();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit149 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
