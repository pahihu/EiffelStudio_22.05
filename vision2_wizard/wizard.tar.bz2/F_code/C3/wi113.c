/*
 * Code for class WIZARD_SMART_TEXT_FIELD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi113.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_SMART_TEXT_FIELD}.make */
void F126_2788 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("make", 125, Current, 0, 1, 2898);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tr1 = RTLNSMART(eif_new_type(1142, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = RTLNSMART(eif_new_type(1158, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	tr1 = RTLNSMART(eif_new_type(1166, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {WIZARD_SMART_TEXT_FIELD}.generate */
void F126_2789 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,loc4);
	RTLR(5,loc7);
	RTLR(6,loc2);
	RTLR(7,loc1);
	RTLR(8,loc8);
	RTLR(9,tr2);
	RTLR(10,tr3);
	RTLR(11,loc3);
	RTLIU(12);
	
	RTEAA("generate", 125, Current, 8, 0, 2899);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1122_9745(RTCW(tr1), loc5);
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1122_9746(RTCW(tr1));
	}
	RTHOOK(4);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_)) {
		RTHOOK(5);
		tr1 = RTLNS(eif_new_type(1167, 0x00).id, 1167, _OBJSIZ_5_2_0_1_0_0_0_0_);
		F1091_9344(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(6);
		tr1 = RTLNSMART(eif_new_type(1166, 0).id);
		F1091_9344(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(7);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7289[Dtype(loc6)-1057])(loc6);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(8);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1122_9745(RTCW(tr1), loc6);
	}
	RTHOOK(9);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_1_)) {
		RTHOOK(10);
		loc4 = RTLNSMART(eif_new_type(1171, 0).id);
		tr1 = F124_2765(Current);
		F1122_9743(RTCW(loc4), tr1);
		RTHOOK(11);
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc4;
		RTHOOK(12);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			RTHOOK(13);
			tr1 = F1087_9304(RTCW(loc4));
			F704_6008(RTCW(tr1), loc7);
		}
		RTHOOK(14);
		loc2 = RTLNS(eif_new_type(1141, 0x00).id, 1141, _OBJSIZ_6_3_0_1_0_0_0_0_);
		F1091_9344(RTCW(loc2));
		RTHOOK(15);
		ti4_1 = F123_2729(Current, ((EIF_INTEGER_32) 5L));
		F1141_10082(RTCW(loc2), ti4_1);
		RTHOOK(16);
		F1134_9938(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_2_));
		RTHOOK(17);
		F1134_9938(RTCW(loc2), loc4);
		RTHOOK(18);
		F1141_10084(RTCW(loc2), loc4);
		RTHOOK(19);
		loc1 = (EIF_REFERENCE) loc2;
	} else {
		RTHOOK(20);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	}
	RTHOOK(21);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1136_9997(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_3_0_0_));
	RTHOOK(22);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1123_9755(RTCW(tr1));
	RTHOOK(23);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		RTHOOK(24);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTMS32_EX_H(" \000\000\000",1,32);
		tr3 = F1054_8826(loc8);
		tr2 = F1063_9197(tr2, tr3);
		F1122_9745(RTCW(tr1), tr2);
	}
	RTHOOK(25);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1167_10433(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_3_0_1_));
	RTHOOK(26);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1084_9293(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,128,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,0,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A116_82, (EIF_POINTER) _A116_82, (EIF_POINTER)(F128_2838),tr2, 1, 0);
	}
	F704_6008(RTCW(tr1), tr3);
	RTHOOK(27);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1078_9275(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,128,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,0,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A116_106, (EIF_POINTER) _A116_106, (EIF_POINTER)(F129_2862),tr2, 1, 0);
	}
	F704_6008(RTCW(tr1), tr3);
	RTHOOK(28);
	loc3 = RTLNS(eif_new_type(1143, 0x00).id, 1143, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc3));
	RTHOOK(29);
	ti4_1 = F123_2729(Current, ((EIF_INTEGER_32) 2L));
	F1136_9998(RTCW(loc3), ti4_1);
	RTHOOK(30);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1134_9938(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	RTHOOK(31);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1134_9938(RTCW(tr1), loc3);
	RTHOOK(32);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1141_10084(RTCW(tr1), loc3);
	RTHOOK(33);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1134_9938(RTCW(tr1), loc1);
	RTHOOK(34);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	RTHOOK(35);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) NULL;
	RTHOOK(36);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
	RTHOOK(37);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) NULL;
	RTHOOK(38);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(40);
	RTLE;
	RTEE;
}

/* {WIZARD_SMART_TEXT_FIELD}.text_32 */
EIF_REFERENCE F126_2790 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("text_32", 125, Current, 1, 0, 2900);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_2_)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		Result = F1122_9744(RTCW(tr1));
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTHOOK(4);
			Result = F1054_8826(loc1);
			RTHOOK(5);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) Result;
		} else {
			RTHOOK(6);
			Result = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1054_8767(RTCW(Result));
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {WIZARD_SMART_TEXT_FIELD}.widget */
EIF_REFERENCE F126_2791 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("widget", 125, Current, 0, 0, 2901);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
}

/* {WIZARD_SMART_TEXT_FIELD}.change_actions */
EIF_REFERENCE F126_2792 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("change_actions", 125, Current, 0, 0, 2902);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = F1078_9275(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {WIZARD_SMART_TEXT_FIELD}.set_text */
void F126_2797 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_text", 125, Current, 0, 1, 2907);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_2_)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1122_9745(RTCW(tr1), arg1);
	} else {
		RTHOOK(3);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {WIZARD_SMART_TEXT_FIELD}.set_textfield_string */
void F126_2798 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_textfield_string", 125, Current, 0, 1, 2908);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_2_)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1122_9745(RTCW(tr1), arg1);
	} else {
		RTHOOK(3);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {WIZARD_SMART_TEXT_FIELD}.set_label_string_and_size */
void F126_2800 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("set_label_string_and_size", 125, Current, 0, 2, 2910);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_2_)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = F1054_8826(RTCW(arg1));
		tr3 = F1054_8826(RTMS_EX_H(":",1,58));
		tr2 = F1063_9197(RTCW(tr2), tr3);
		F1122_9745(RTCW(tr1), tr2);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1136_9997(RTCW(tr1), arg2);
	} else {
		RTHOOK(4);
		tr1 = F1054_8826(RTCW(arg1));
		tr2 = F1054_8826(RTMS_EX_H(":",1,58));
		tr1 = F1063_9197(RTCW(tr1), tr2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
		RTHOOK(5);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_3_0_0_) = (EIF_INTEGER_32) arg2;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {WIZARD_SMART_TEXT_FIELD}.enable_directory_browse_button */
void F126_2802 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("enable_directory_browse_button", 125, Current, 0, 0, 2912);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,0,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2= RTLNRF(typres0.id, (EIF_POINTER) __A113_101, (EIF_POINTER) _A113_101, (EIF_POINTER)(F126_2808),tr1, 1, 0);
	}
	RTAR(Current, tr2);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr2;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {WIZARD_SMART_TEXT_FIELD}.browse_directory */
void F126_2808 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc3 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTEAA("browse_directory", 125, Current, 3, 0, 2918);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1128, 0x00).id, 1128, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1091_9344(RTCW(loc1));
	RTHOOK(2);
	tr1 = F124_2766(Current);
	F1128_9855(RTCW(loc1), tr1);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1122_9744(RTCW(tr1));
	loc2 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	RTHOOK(4);
	tb1 = F512_5267(RTCW(loc2));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(5);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		loc3 = F1063_9145(RTCW(loc2), ti4_1);
		RTHOOK(6);
		tb1 = '\01';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
		if (!(EIF_BOOLEAN)(loc3 == tw1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
			tb1 = (EIF_BOOLEAN)(loc3 == tw1);
		}
		if (tb1) {
			RTHOOK(7);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
			F1063_9160(RTCW(loc2), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
		}
		RTHOOK(8);
		tb1 = '\0';
		tb2 = F512_5267(RTCW(loc2));
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = RTLNS(eif_new_type(923, 0x00).id, 923, _OBJSIZ_3_0_0_1_0_2_0_0_);
			F924_6669(RTCW(tr1), loc2);
			tb2 = F924_6694(RTCW(tr1));
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(9);
			tr1 = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F940_7444(RTCW(tr1), loc2);
			F1129_9863(RTCW(loc1), tr1);
		}
	}
	RTHOOK(10);
	tr1 = F1079_9277(RTCW(loc1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,973,0,1128,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = loc1;
	RTAR(tr2,loc1);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,0,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A113_102, (EIF_POINTER) _A113_102, (EIF_POINTER)(F126_2809),tr2, 1, 0);
	}
	F704_6008(RTCW(tr1), tr3);
	RTHOOK(11);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = F124_2731(RTCW(tr1));
	F1128_9854(RTCW(loc1), tr1);
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {WIZARD_SMART_TEXT_FIELD}.directory_selected */
void F126_2809 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("directory_selected", 125, Current, 0, 1, 2919);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = F1129_9859(RTCW(arg1));
	tr2 = F940_7483(RTCW(tr2));
	F1122_9745(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit113 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
