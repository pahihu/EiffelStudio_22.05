
#ifndef _C3_wi119_
#define _C3_wi119_

#ifdef __cplusplus
extern "C" {
#endif

extern void F132_2885(EIF_REFERENCE);
extern void F132_2886(EIF_REFERENCE);
extern void EIF_Minit119(void);
extern void F1151_10209(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F124_2731(EIF_REFERENCE);
extern void F1151_10201(EIF_REFERENCE);
extern EIF_REFERENCE F124_2763(EIF_REFERENCE);
extern void F129_2855(EIF_REFERENCE);
extern char *(*R2840[])();

#ifdef __cplusplus
}
#endif

#endif
