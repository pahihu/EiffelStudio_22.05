/*
 * Code for class WIZARD_INITIAL_STATE_WINDOW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi118.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_INITIAL_STATE_WINDOW}.display */
void F131_2877 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("display", 130, Current, 0, 0, 2983);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2840[Dtype(Current)-343])(Current);
	RTHOOK(2);
	RTEE;
}

/* {WIZARD_INITIAL_STATE_WINDOW}.build */
void F131_2878 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc4);
	RTLR(4,loc2);
	RTLR(5,loc1);
	RTLR(6,loc3);
	RTLR(7,loc5);
	RTLR(8,tr3);
	RTLIU(9);
	
	RTEAA("build", 130, Current, 5, 0, 2984);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1158, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTOSCF(2748,F124_2748, (Current));
	F1112_9681(RTCW(tr1), tr2);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1123_9755(RTCW(tr1));
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTOSCF(2752,F124_2752, (Current));
	F1124_9758(RTCW(tr1), tr2);
	RTHOOK(5);
	tr1 = RTLNSMART(eif_new_type(1158, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTOSCF(2748,F124_2748, (Current));
	F1112_9681(RTCW(tr1), tr2);
	RTHOOK(7);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1123_9755(RTCW(tr1));
	RTHOOK(8);
	tr1 = RTLNSMART(eif_new_type(1142, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = RTOSCF(2748,F124_2748, (Current));
	F1112_9681(RTCW(tr1), tr2);
	RTHOOK(10);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2835[Dtype(Current)-343])(Current);
	RTHOOK(11);
	loc4 = RTLNS(eif_new_type(1142, 0x00).id, 1142, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc4));
	RTHOOK(12);
	tr1 = RTOSCF(2748,F124_2748, (Current));
	F1112_9681(RTCW(loc4), tr1);
	RTHOOK(13);
	ti4_1 = RTOSCF(2725,F123_2725, (Current));
	F1141_10080(RTCW(loc4), ti4_1);
	RTHOOK(14);
	ti4_1 = RTOSCF(2721,F123_2721, (Current));
	F1141_10082(RTCW(loc4), ti4_1);
	RTHOOK(15);
	F1134_9938(RTCW(loc4), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	RTHOOK(16);
	F1141_10084(RTCW(loc4), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	RTHOOK(17);
	F131_2881(Current, loc4);
	RTHOOK(18);
	loc2 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (RTOSCF(2740,F124_2740, (Current)));
	RTHOOK(19);
	ti4_1 = F123_2729(Current, ((EIF_INTEGER_32) 165L));
	ti4_2 = F123_2729(Current, ((EIF_INTEGER_32) 312L));
	F1136_9999(RTCW(loc2), ti4_1, ti4_2);
	RTHOOK(20);
	tr1 = RTOSCF(2741,F124_2741, (Current));
	F1125_9790(RTCW(loc2), ((EIF_INTEGER_32) 122L), ((EIF_INTEGER_32) 69L), tr1);
	RTHOOK(21);
	loc1 = RTLNS(eif_new_type(1169, 0x00).id, 1169, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc1));
	RTHOOK(22);
	loc3 = RTLNS(eif_new_type(1141, 0x00).id, 1141, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc3));
	RTHOOK(23);
	F1134_9938(RTCW(loc3), loc2);
	RTHOOK(24);
	F1141_10084(RTCW(loc3), loc2);
	RTHOOK(25);
	F1134_9938(RTCW(loc3), loc1);
	RTHOOK(26);
	F1141_10084(RTCW(loc3), loc1);
	RTHOOK(27);
	F1134_9938(RTCW(loc3), loc4);
	RTHOOK(28);
	tr1 = RTOSCF(2733,F124_2733, (Current));
	F1134_9938(RTCW(tr1), loc3);
	RTHOOK(29);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc5 = RTLNTS(typres0.id, 1, 1);
	}
	RTHOOK(30);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,973,0,0xFFF9,0,973,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = loc5;
	RTAR(tr2,loc5);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1048,0xFFF9,0,973,182,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A118_99, (EIF_POINTER) _A118_99, (EIF_POINTER)(F129_2860),tr2, 1, 0);
	}
	F1105_9600(RTCW(tr1), tr3);
	RTHOOK(31);
	RTLE;
	RTEE;
}

/* {WIZARD_INITIAL_STATE_WINDOW}.current_help_context */
EIF_REFERENCE F131_2879 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("current_help_context", 130, Current, 2, 0, 2985);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = F1105_9599(RTCW(tr1));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1);
		tr1 = F1049_8758(loc1, tr1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(182, 0),loc2);
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc2;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {WIZARD_INITIAL_STATE_WINDOW}.fill_message_and_title_box */
void F131_2881 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("fill_message_and_title_box", 130, Current, 1, 1, 2987);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1143, 0x00).id, 1143, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc1));
	RTHOOK(2);
	tr1 = RTOSCF(2748,F124_2748, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7936[Dtype(RTCW(loc1))-1125])(loc1, tr1);
	RTHOOK(3);
	F1134_9938(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTHOOK(4);
	F1141_10084(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTHOOK(5);
	F1134_9938(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	RTHOOK(6);
	F1141_10084(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	RTHOOK(7);
	F1134_9938(RTCW(arg1), loc1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {WIZARD_INITIAL_STATE_WINDOW}.display_pixmap */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F131_2882 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr2 = NULL;
	RTLD;
	RTXD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc4);
	RTLR(5,loc3);
	RTLR(6,saved_except);
	RTLIU(7);
	RTXSLS;
	
	RTEAA("display_pixmap", 130, Current, 4, 0, 2988);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc2) {
		RTHOOK(2);
		F129_2854(Current);
		RTHOOK(3);
		tr1 = RTOSCF(2736,F124_2736, (Current));
		tr2 = RTOSCF(4957,F339_4957, (Current));
		loc1 = F940_7472(RTCW(tr1), tr2);
		RTHOOK(4);
		tr1 = RTOSCF(2741,F124_2741, (Current));
		F1160_10312(RTCW(tr1), loc1);
	}
	RTE_E
	RTXSC;
	RTHOOK(5);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(6);
	tr1 = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1061_9063(RTCW(tr1), ((EIF_INTEGER_32) 30L));
	loc4 = (EIF_REFERENCE) tr1;
	RTHOOK(7);
	tr1 = F1054_8826(RTMS_EX_H("Unable to open the pixmap named\012\"",33,20206882));
	F1063_9178(RTCW(loc4), tr1);
	RTHOOK(8);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(9);
		tr1 = F940_7483(RTCW(loc1));
		F1063_9178(RTCW(loc4), tr1);
	} else {
		RTHOOK(10);
		tr1 = F1054_8826(RTMS_EX_H("UNKNOWN FILE",12,1709026373));
		F1063_9178(RTCW(loc4), tr1);
	}
	RTHOOK(11);
	tr1 = F1054_8826(RTMS_EX_H("\"",1,34));
	F1063_9178(RTCW(loc4), tr1);
	RTHOOK(12);
	tr1 = RTLNS(eif_new_type(1155, 0x00).id, 1155, _OBJSIZ_14_3_0_3_0_0_0_0_);
	F1154_10244(RTCW(tr1), loc4);
	loc3 = (EIF_REFERENCE) tr1;
	RTHOOK(13);
	tr1 = F124_2731(Current);
	F1152_10233(RTCW(loc3), tr1);
	RTHOOK(14);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(15);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {WIZARD_INITIAL_STATE_WINDOW}.pixmap_location */
static EIF_REFERENCE F131_2883_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("pixmap_location", 130, Current, 0, 0, 2982);
	RTGC;
	RTOSP (2883);
#define Result RTOSR(2883)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("eiffel_wizard",13,1883122276);
	tr3 = RTOSCF(2738,F124_2738, (Current));
	tr2 = F1059_9029(tr2, tr3);
	F940_7444(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2883);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F131_2883 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2883,F131_2883_body,(Current));
}

void EIF_Minit118 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
