
#ifndef _C3_sh121_
#define _C3_sh121_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2895)
static EIF_REFERENCE F134_2895_body(EIF_REFERENCE);
extern EIF_REFERENCE F134_2895(EIF_REFERENCE);
extern void EIF_Minit121(void);

#ifdef __cplusplus
}
#endif

#endif
