
#ifndef _C3_i1140_
#define _C3_i1140_

#ifdef __cplusplus
extern "C" {
#endif

extern void F153_3160(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F153_3164(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F153_3165(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit140(void);
extern void F1063_9139(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F154_3170(EIF_REFERENCE);
extern EIF_REFERENCE F154_3169(EIF_REFERENCE);
extern char *(*R4763[])();

#ifdef __cplusplus
}
#endif

#endif
