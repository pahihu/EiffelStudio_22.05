
#ifndef _C3_sh138_
#define _C3_sh138_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,3153)
static EIF_REFERENCE F151_3153_body(EIF_REFERENCE);
extern EIF_REFERENCE F151_3153(EIF_REFERENCE);
extern void EIF_Minit138(void);

#ifdef __cplusplus
}
#endif

#endif
