
#ifndef _C3_i1123_
#define _C3_i1123_

#ifdef __cplusplus
extern "C" {
#endif

extern void F136_2917(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit123(void);

#ifdef __cplusplus
}
#endif

#endif
