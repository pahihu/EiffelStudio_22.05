/*
 * Code for class INTERFACE_NAMES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in114.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INTERFACE_NAMES}.l_menu_bar */
EIF_REFERENCE F127_2823 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("l_menu_bar", 126, Current, 0, 0, 2933);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Menu Bar",8,71578482);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTERFACE_NAMES}.l_tool_bar */
EIF_REFERENCE F127_2824 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("l_tool_bar", 126, Current, 0, 0, 2934);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Tool Bar",8,813293426);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTERFACE_NAMES}.l_status_bar */
EIF_REFERENCE F127_2825 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("l_status_bar", 126, Current, 0, 0, 2935);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Status Bar",10,726587762);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTERFACE_NAMES}.l_about_dialogbox */
EIF_REFERENCE F127_2826 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("l_about_dialogbox", 126, Current, 0, 0, 2936);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("About DialogBox",15,1329071224);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTERFACE_NAMES}.t_new_vision2_wizard */
EIF_REFERENCE F127_2827 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("t_new_vision2_wizard", 126, Current, 0, 0, 2937);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("New Vision2 Application Wizard",30,988325988);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTERFACE_NAMES}.t_welcome_to_the_wizard */
EIF_REFERENCE F127_2828 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("t_welcome_to_the_wizard", 126, Current, 0, 0, 2938);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Welcome to the New Vision2\012Application Wizard",45,1020361828);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTERFACE_NAMES}.t_completing_wizard */
EIF_REFERENCE F127_2829 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("t_completing_wizard", 126, Current, 0, 0, 2939);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Completing the New Vision2\012Application Wizard",45,1536826980);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTERFACE_NAMES}.t_vision2_application_appearance */
EIF_REFERENCE F127_2830 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("t_vision2_application_appearance", 126, Current, 0, 0, 2940);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Vision2 Application Appearance",30,1396903781);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTERFACE_NAMES}.t_subtitle */
EIF_REFERENCE F127_2831 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("t_subtitle", 126, Current, 0, 0, 2941);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("You can choose the appearance of your application.",50,780647982);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTERFACE_NAMES}.m_you_have_specified_the_following_setting */
EIF_REFERENCE F127_2832 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLR(6,Result);
	RTLIU(7);
	
	RTEAA("m_you_have_specified_the_following_setting", 126, Current, 0, 2, 2942);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = F124_2746(Current);
	tr3 = RTMS_EX_H("You have specified the following settings:\012\012Project name: \011$1\012Location:     \011$2\012",80,1127440650);
	tr2 = F43_728(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,973,1053,1053,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	((EIF_TYPED_VALUE *)tr3+2)->it_r = arg2;
	RTAR(tr3,arg2);
	Result = F43_732(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTERFACE_NAMES}.m_is_scoop_enabled */
EIF_REFERENCE F127_2833 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("m_is_scoop_enabled", 126, Current, 0, 1, 2943);
	RTGC;
	RTHOOK(1);
	if (arg1) {
		RTHOOK(2);
		tr1 = F124_2746(Current);
		tr2 = RTMS_EX_H("Concurrency: \011Yes\012",18,1012758794);
		Result = F43_728(RTCW(tr1), tr2);
	} else {
		RTHOOK(3);
		tr1 = F124_2746(Current);
		tr2 = RTMS_EX_H("Concurrency: \011No\012",17,1295080970);
		Result = F43_728(RTCW(tr1), tr2);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {INTERFACE_NAMES}.m_click_finish_to */
EIF_REFERENCE F127_2834 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("m_click_finish_to", 126, Current, 0, 1, 2944);
	RTGC;
	RTHOOK(1);
	if (arg1) {
		RTHOOK(2);
		tr1 = F124_2746(Current);
		tr2 = RTMS_EX_H("Click Finish to generate and compile this project",49,556727668);
		Result = F43_728(RTCW(tr1), tr2);
	} else {
		RTHOOK(3);
		tr1 = F124_2746(Current);
		tr2 = RTMS_EX_H("Click Finish to generate this project",37,1002709364);
		Result = F43_728(RTCW(tr1), tr2);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {INTERFACE_NAMES}.m_wizard_introduction */
EIF_REFERENCE F127_2835 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("m_wizard_introduction", 126, Current, 0, 0, 2945);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Using this wizard you can create a graphical application\012based on the EiffelVision2 library.\012\012The generated application will run on any Windows system\012as well as on any GTK supported platform (Linux, FreeBSD, ...)\012\012\012To continue, click Next.",240,833611054);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTERFACE_NAMES}.m_click_checkboxes_to */
EIF_REFERENCE F127_2836 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("m_click_checkboxes_to", 126, Current, 0, 0, 2946);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Click the checkboxes to change the appearance.",46,426383406);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit114 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
