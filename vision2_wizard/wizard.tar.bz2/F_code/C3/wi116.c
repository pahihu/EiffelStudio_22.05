/*
 * Code for class WIZARD_STATE_WINDOW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi116.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_STATE_WINDOW}.make */
void F129_2848 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("make", 128, Current, 0, 1, 2973);
	RTGC;
	RTHOOK(1);
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F129_2862(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {WIZARD_STATE_WINDOW}.clean_screen */
void F129_2851 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("clean_screen", 128, Current, 0, 0, 2975);
	RTGC;
	RTHOOK(1);
	F1134_9951(RTCV(RTOSCF(2733,F124_2733, (Current))));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {WIZARD_STATE_WINDOW}.display_pixmap */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F129_2854 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr2 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr3 = NULL;
	RTLD;
	RTXD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,tr3);
	RTLR(6,saved_except);
	RTLIU(7);
	RTXSLS;
	
	RTEAA("display_pixmap", 128, Current, 3, 0, 2958);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc2) {
		RTHOOK(2);
		tr1 = RTOSCF(2736,F124_2736, (Current));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2848[Dtype(Current)-343])(Current);
		loc1 = F940_7472(RTCW(tr1), tr2);
		RTHOOK(3);
		tr1 = RTOSCF(2740,F124_2740, (Current));
		F1160_10312(RTCW(tr1), loc1);
	}
	RTE_E
	RTXSC;
	RTHOOK(4);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(5);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(6);
		tr1 = RTLNS(eif_new_type(1155, 0x00).id, 1155, _OBJSIZ_14_3_0_3_0_0_0_0_);
		tr2 = RTMS32_EX_H("U\000\000\000n\000\000\000a\000\000\000b\000\000\000l\000\000\000e\000\000\000 \000\000\000t\000\000\000o\000\000\000 \000\000\000o\000\000\000p\000\000\000e\000\000\000n\000\000\000 \000\000\000t\000\000\000h\000\000\000e\000\000\000 \000\000\000p\000\000\000i\000\000\000x\000\000\000m\000\000\000a\000\000\000p\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000d\000\000\000\012\000\000\000\"\000\000\000",33,20206882);
		tr3 = F940_7483(RTCW(loc1));
		tr2 = F1063_9197(tr2, tr3);
		tr3 = F1054_8826(RTMS_EX_H("\"",1,34));
		tr2 = F1063_9197(RTCW(tr2), tr3);
		F1154_10244(RTCW(tr1), tr2);
		loc3 = (EIF_REFERENCE) tr1;
		RTHOOK(7);
		tr1 = F124_2731(Current);
		F1152_10233(RTCW(loc3), tr1);
	}
	RTHOOK(8);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(9);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {WIZARD_STATE_WINDOW}.proceed_with_current_info */
void F129_2855 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("proceed_with_current_info", 128, Current, 0, 0, 2959);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O2847[Dtype(Current)-128]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	RTEE;
}

/* {WIZARD_STATE_WINDOW}.update_state_information */
void F129_2856 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("update_state_information", 128, Current, 0, 0, 2960);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O2846[Dtype(Current)-128]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTEE;
}

/* {WIZARD_STATE_WINDOW}.display_help */
void F129_2859 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("display_help", 128, Current, 1, 0, 2962);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2831[Dtype(Current)-343])(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = RTOSCF(2745,F124_2745, (Current));
		F186_3544(RTCW(tr1), loc1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {WIZARD_STATE_WINDOW}.create_help_context */
EIF_REFERENCE F129_2860 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("create_help_context", 128, Current, 0, 1, 2963);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(182, 0x00).id, 182, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F183_3536(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {WIZARD_STATE_WINDOW}.set_updatable_entries */
void F129_2861 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("set_updatable_entries", 128, Current, 1, 1, 2964);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(2);
		ti4_1 = F601_5395(RTCW(arg1));
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		RTHOOK(3);
		tr1 = F601_5388(RTCW(arg1), loc1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,0,973,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3= RTLNRF(typres0.id, (EIF_POINTER) __A116_106, (EIF_POINTER) _A116_106, (EIF_POINTER)(F129_2862),tr2, 1, 0);
		}
		F704_6008(RTCW(tr1), tr3);
		RTHOOK(4);
		tr1 = F601_5388(RTCW(arg1), loc1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,0,973,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3= RTLNRF(typres0.id, (EIF_POINTER) __A116_89, (EIF_POINTER) _A116_89, (EIF_POINTER)(F128_2845),tr2, 1, 0);
		}
		F704_6008(RTCW(tr1), tr3);
		RTHOOK(5);
		loc1++;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {WIZARD_STATE_WINDOW}.change_entries */
void F129_2862 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("change_entries", 128, Current, 0, 0, 2965);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O2847[Dtype(Current)-128]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit116 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
