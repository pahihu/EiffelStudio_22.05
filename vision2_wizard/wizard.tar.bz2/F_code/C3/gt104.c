/*
 * Code for class GTK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt104.h"
#include <string.h>
#include <ev_gtk.h>
#include "eif_out.h"
#include <stdlib.h>
#include "eif_helpers.h"
#include <gmodule.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F117_2345
static EIF_POINTER inline_F117_2345 (void)
{
	return gtk_settings_get_default();
	;
}
#define INLINE_F117_2345
#endif
#ifndef INLINE_F117_2347
static void inline_F117_2347 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_window_set_skip_taskbar_hint ((GtkWindow*) arg1, (gboolean) arg2);
	;
}
#define INLINE_F117_2347
#endif
#ifndef INLINE_F117_2370
static int inline_F117_2370 (EIF_POINTER arg1)
{
	return (int) (GTK_IS_WIDGET(arg1))
	;
}
#define INLINE_F117_2370
#endif
#ifndef INLINE_F117_2381
static EIF_POINTER inline_F117_2381 (EIF_POINTER arg1)
{
	return gtk_widget_get_display ((GtkWidget *)arg1)
	;
}
#define INLINE_F117_2381
#endif
#ifndef INLINE_F117_2395
static void inline_F117_2395 (EIF_POINTER arg1)
{
	gtk_widget_show_all ((GtkWidget *)arg1)
	;
}
#define INLINE_F117_2395
#endif
#ifndef INLINE_F117_2405
static void inline_F117_2405 (EIF_POINTER arg1)
{
	gtk_widget_queue_draw ((GtkWidget *)arg1)
	;
}
#define INLINE_F117_2405
#endif
#ifndef INLINE_F117_2446
static EIF_INTEGER_32 inline_F117_2446 (void)
{
	return (EIF_INTEGER_32) (GTK_JUSTIFY_CENTER)
	;
}
#define INLINE_F117_2446
#endif
#ifndef INLINE_F117_2496
static void inline_F117_2496 (EIF_POINTER arg1)
{
	gtk_menu_shell_cancel((GtkMenuShell*)arg1);
	;
}
#define INLINE_F117_2496
#endif
#ifndef INLINE_F117_2512
static void inline_F117_2512 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_entry_set_width_chars ((GtkEntry *)arg1, (gint)arg2)
	;
}
#define INLINE_F117_2512
#endif
#ifndef INLINE_F117_2537
static void inline_F117_2537 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_xalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F117_2537
#endif
#ifndef INLINE_F117_2538
static void inline_F117_2538 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_yalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F117_2538
#endif
#ifndef INLINE_F117_2540
static void inline_F117_2540 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_label_set_attributes ((GtkLabel *)arg1, (PangoAttrList *)arg2);
	;
}
#define INLINE_F117_2540
#endif
#ifndef INLINE_F115_1907
static int inline_F115_1907 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	return gtk_style_context_lookup_color((GtkStyleContext*) arg1, (gchar*) arg2, (GdkRGBA*) arg3);
	;
}
#define INLINE_F115_1907
#endif
#ifndef INLINE_F115_1885
static EIF_POINTER inline_F115_1885 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_BACKGROUND_COLOR)
	;
}
#define INLINE_F115_1885
#endif
#ifndef INLINE_F115_1908
static void inline_F115_1908 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	gtk_style_context_get (arg1, arg2, arg3, arg4, NULL)
	;
}
#define INLINE_F115_1908
#endif
#ifndef INLINE_F115_1986
static void inline_F115_1986 (EIF_POINTER arg1)
{
	gtk_widget_destroy((GtkWidget*) arg1)
	;
}
#define INLINE_F115_1986
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK}.is_x11_session */
static EIF_BOOLEAN F117_2336_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	

	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("is_x11_session", 116, Current, 1, 0, 2495);
	RTGC;
	RTOSP (2336);
#define Result RTOSR(2336)
	RTHOOK(1);
	Result = '\0';
	tr2 = RTMS_EX_H("XDG_SESSION_TYPE",16,1292423749);
	tr1 = RTLNS(eif_new_type(673, 0x00).id, 673, _OBJSIZ_0_0_0_1_0_0_0_0_);
	tr2 = F674_5706(RTCW(tr1), tr2);
	loc1 = tr2;
	if (EIF_TEST(loc1)) {
		tr1 = RTMS_EX_H("x11",3,7876913);
		tb1 = F1054_8809(loc1, tr1);
		Result = tb1;
	}
	RTOSE (2336);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F117_2336 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2336,F117_2336_body,(Current));
}

/* {GTK}.is_wayland_session */
static EIF_BOOLEAN F117_2337_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	

	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("is_wayland_session", 116, Current, 1, 0, 2496);
	RTGC;
	RTOSP (2337);
#define Result RTOSR(2337)
	RTHOOK(1);
	Result = '\0';
	tr2 = RTMS_EX_H("XDG_SESSION_TYPE",16,1292423749);
	tr1 = RTLNS(eif_new_type(673, 0x00).id, 673, _OBJSIZ_0_0_0_1_0_0_0_0_);
	tr2 = F674_5706(RTCW(tr1), tr2);
	loc1 = tr2;
	if (EIF_TEST(loc1)) {
		tr1 = RTMS_EX_H("wayland",7,1775190116);
		tb1 = F1054_8809(loc1, tr1);
		Result = tb1;
	}
	RTOSE (2337);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F117_2337 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2337,F117_2337_body,(Current));
}

/* {GTK}.gtk_maj_ver */
EIF_INTEGER_32 F117_2338 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_maj_ver", 116, Current, 0, 0, 2497);
	Result = (EIF_INTEGER_32) GTK_MAJOR_VERSION;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.g_module_supported */
EIF_BOOLEAN F117_2341 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_module_supported", 116, Current, 0, 0, 2500);Result = (EIF_BOOLEAN) EIF_TEST(g_module_supported());
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.g_module_symbol */
EIF_BOOLEAN F117_2342 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER* arg3)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_module_symbol", 116, Current, 0, 3, 2501);Result = (EIF_BOOLEAN) EIF_TEST(g_module_symbol((GModule*) arg1, (gchar*) arg2, (gpointer*) arg3));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.g_module_open */
EIF_POINTER F117_2343 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_module_open", 116, Current, 0, 2, 2502);Result = (EIF_POINTER) g_module_open((gchar*) arg1, (GModuleFlags) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_settings_get_default */
EIF_POINTER F117_2345 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_settings_get_default", 116, Current, 0, 0, 2504);
	Result = inline_F117_2345 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_is_window */
EIF_BOOLEAN F117_2346 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_is_window", 116, Current, 0, 1, 2505);
	Result = (EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((arg1)));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_window_set_skip_taskbar_hint */
void F117_2347 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_set_skip_taskbar_hint", 116, Current, 0, 2, 2506);
	inline_F117_2347 ((EIF_POINTER) arg1, (EIF_BOOLEAN) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_window_get_title */
EIF_POINTER F117_2349 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_get_title", 116, Current, 0, 1, 2508);Result = (EIF_POINTER) gtk_window_get_title((GtkWindow*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_window_new */
EIF_POINTER F117_2351 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_new", 116, Current, 0, 1, 2510);Result = (EIF_POINTER) gtk_window_new((GtkWindowType) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_window_set_default_size */
void F117_2352 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_set_default_size", 116, Current, 0, 3, 2511);gtk_window_set_default_size((GtkWindow*) arg1, (gint) arg2, (gint) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_window_get_default_size */
void F117_2354 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_get_default_size", 116, Current, 0, 3, 2513);gtk_window_get_default_size((GtkWindow*) arg1, (EIF_INTEGER_32*) arg2, (EIF_INTEGER_32*) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_window_set_focus */
void F117_2355 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_set_focus", 116, Current, 0, 2, 2514);gtk_window_set_focus((GtkWindow*) arg1, (GtkWidget*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_window_set_geometry_hints */
void F117_2356 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_set_geometry_hints", 116, Current, 0, 4, 2515);gtk_window_set_geometry_hints((GtkWindow*) arg1, (GtkWidget*) arg2, (GdkGeometry*) arg3, (GdkWindowHints) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_window_set_position */
void F117_2358 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_set_position", 116, Current, 0, 2, 2517);gtk_window_set_position((GtkWindow*) arg1, (GtkWindowPosition) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_window_set_title */
void F117_2359 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_set_title", 116, Current, 0, 2, 2518);gtk_window_set_title((GtkWindow*) arg1, (gchar*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_window_set_transient_for */
void F117_2360 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_set_transient_for", 116, Current, 0, 2, 2519);gtk_window_set_transient_for((GtkWindow*) arg1, (GtkWindow*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_is_container */
EIF_BOOLEAN F117_2363 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_is_container", 116, Current, 0, 1, 2522);
	Result = (EIF_BOOLEAN) EIF_TEST(GTK_IS_CONTAINER((arg1)));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_container_add */
void F117_2364 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_container_add", 116, Current, 0, 2, 2523);gtk_container_add((GtkContainer*) arg1, (GtkWidget*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_container_check_resize */
void F117_2365 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_container_check_resize", 116, Current, 0, 1, 2524);gtk_container_check_resize((GtkContainer*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_container_get_children */
EIF_POINTER F117_2366 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_container_get_children", 116, Current, 0, 1, 2525);Result = (EIF_POINTER) gtk_container_get_children((GtkContainer*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_container_remove */
void F117_2367 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_container_remove", 116, Current, 0, 2, 2526);gtk_container_remove((GtkContainer*) arg1, (GtkWidget*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_container_set_border_width */
void F117_2368 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_container_set_border_width", 116, Current, 0, 2, 2527);gtk_container_set_border_width((GtkContainer*) arg1, (guint) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_container_get_border_width */
EIF_INTEGER_32 F117_2369 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_container_get_border_width", 116, Current, 0, 1, 2528);Result = (EIF_INTEGER_32) gtk_container_get_border_width((GtkContainer*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_is_widget */
EIF_BOOLEAN F117_2370 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_is_widget", 116, Current, 0, 1, 2529);
	Result = EIF_TEST(inline_F117_2370 ((EIF_POINTER) arg1));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_widget_set_hexpand */
void F117_2371 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_set_hexpand", 116, Current, 0, 2, 2530);gtk_widget_set_hexpand((GtkWidget*) arg1, (gboolean) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_widget_set_vexpand */
void F117_2372 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_set_vexpand", 116, Current, 0, 2, 2531);gtk_widget_set_vexpand((GtkWidget*) arg1, (gboolean) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_widget_get_display */
EIF_POINTER F117_2381 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_display", 116, Current, 0, 1, 2540);
	Result = inline_F117_2381 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_widget_is_sensitive */
EIF_BOOLEAN F117_2382 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_is_sensitive", 116, Current, 0, 1, 2541);Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_sensitive((GtkWidget*) arg1));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_widget_get_visible */
EIF_BOOLEAN F117_2384 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_visible", 116, Current, 0, 1, 2543);Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_visible((GtkWidget*) arg1));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_widget_is_focus */
EIF_BOOLEAN F117_2386 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_is_focus", 116, Current, 0, 1, 2545);Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_focus((GtkWidget*) arg1));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_widget_has_focus */
EIF_BOOLEAN F117_2387 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_has_focus", 116, Current, 0, 1, 2546);Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_has_focus((GtkWidget*) arg1));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_widget_get_allocation */
void F117_2388 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_allocation", 116, Current, 0, 2, 2547);gtk_widget_get_allocation((GtkWidget*) arg1, (GtkAllocation*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_widget_get_allocated_width */
EIF_INTEGER_32 F117_2390 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_allocated_width", 116, Current, 0, 1, 2549);Result = (EIF_INTEGER_32) gtk_widget_get_allocated_width((GtkWidget*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_widget_get_allocated_height */
EIF_INTEGER_32 F117_2391 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_allocated_height", 116, Current, 0, 1, 2550);Result = (EIF_INTEGER_32) gtk_widget_get_allocated_height((GtkWidget*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_widget_get_parent */
EIF_POINTER F117_2392 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_parent", 116, Current, 0, 1, 2551);Result = (EIF_POINTER) gtk_widget_get_parent((GtkWidget*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_widget_get_window */
EIF_POINTER F117_2393 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_window", 116, Current, 0, 1, 2552);Result = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_widget_show_all */
void F117_2395 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_show_all", 116, Current, 0, 1, 2554);
	inline_F117_2395 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_widget_get_state_flags */
EIF_INTEGER_32 F117_2396 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_state_flags", 116, Current, 0, 1, 2555);Result = (EIF_INTEGER_32) gtk_widget_get_state_flags((GtkWidget*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_widget_add_events */
void F117_2397 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_add_events", 116, Current, 0, 2, 2556);gtk_widget_add_events((GtkWidget*) arg1, (gint) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_widget_event */
EIF_BOOLEAN F117_2400 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_event", 116, Current, 0, 2, 2559);Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_event((GtkWidget*) arg1, (GdkEvent*) arg2));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_widget_get_toplevel */
EIF_POINTER F117_2401 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_toplevel", 116, Current, 0, 1, 2560);Result = (EIF_POINTER) gtk_widget_get_toplevel((GtkWidget*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_widget_grab_focus */
void F117_2403 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_grab_focus", 116, Current, 0, 1, 2562);gtk_widget_grab_focus((GtkWidget*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_widget_hide */
void F117_2404 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_hide", 116, Current, 0, 1, 2563);gtk_widget_hide((GtkWidget*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_widget_queue_draw */
void F117_2405 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_queue_draw", 116, Current, 0, 1, 2564);
	inline_F117_2405 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_widget_realize */
void F117_2408 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_realize", 116, Current, 0, 1, 2567);gtk_widget_realize((GtkWidget*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_widget_set_name */
void F117_2409 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_set_name", 116, Current, 0, 2, 2568);gtk_widget_set_name((GtkWidget*) arg1, (gchar*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_widget_get_name */
EIF_POINTER F117_2410 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_name", 116, Current, 0, 1, 2569);Result = (EIF_POINTER) gtk_widget_get_name((GtkWidget*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_widget_set_sensitive */
void F117_2411 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_set_sensitive", 116, Current, 0, 2, 2570);gtk_widget_set_sensitive((GtkWidget*) arg1, (gboolean) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_widget_set_can_focus */
void F117_2412 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_set_can_focus", 116, Current, 0, 2, 2571);gtk_widget_set_can_focus((GtkWidget*) arg1, (gboolean) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_widget_get_can_focus */
EIF_BOOLEAN F117_2413 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_get_can_focus", 116, Current, 0, 1, 2572);Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_can_focus((GtkWidget*) arg1));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_widget_show */
void F117_2414 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_show", 116, Current, 0, 1, 2573);gtk_widget_show((GtkWidget*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_style_context_save */
void F117_2418 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_style_context_save", 116, Current, 0, 1, 2577);gtk_style_context_save((GtkStyleContext*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_style_context_restore */
void F117_2419 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_style_context_restore", 116, Current, 0, 1, 2578);gtk_style_context_restore((GtkStyleContext*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_style_context_set_state */
void F117_2420 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_style_context_set_state", 116, Current, 0, 2, 2579);gtk_style_context_set_state((GtkStyleContext*) arg1, (GtkStateFlags) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_style_context_get_state */
EIF_INTEGER_32 F117_2421 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_style_context_get_state", 116, Current, 0, 1, 2580);Result = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_drawing_area_new */
EIF_POINTER F117_2427 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_drawing_area_new", 116, Current, 0, 0, 2586);Result = (EIF_POINTER) gtk_drawing_area_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.g_source_remove */
void F117_2428 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_source_remove", 116, Current, 0, 1, 2587);g_source_remove((guint) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_state_flag_normal_enum */
EIF_INTEGER_32 F117_2439 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_state_flag_normal_enum", 116, Current, 0, 0, 2598);
	Result = (EIF_INTEGER_32) GTK_STATE_NORMAL;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_state_flag_insensitive_enum */
EIF_INTEGER_32 F117_2443 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_state_flag_insensitive_enum", 116, Current, 0, 0, 2602);
	Result = (EIF_INTEGER_32) GTK_STATE_FLAG_INSENSITIVE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_justify_center_enum */
EIF_INTEGER_32 F117_2446 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_justify_center_enum", 116, Current, 0, 0, 2605);
	Result = inline_F117_2446 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_justify_left_enum */
EIF_INTEGER_32 F117_2447 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_justify_left_enum", 116, Current, 0, 0, 2606);
	Result = (EIF_INTEGER_32) GTK_JUSTIFY_LEFT;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_justify_right_enum */
EIF_INTEGER_32 F117_2448 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_justify_right_enum", 116, Current, 0, 0, 2607);
	Result = (EIF_INTEGER_32) GTK_JUSTIFY_RIGHT;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_shadow_none_enum */
EIF_INTEGER_32 F117_2450 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_shadow_none_enum", 116, Current, 0, 0, 2609);
	Result = (EIF_INTEGER_32) GTK_SHADOW_NONE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_shadow_etched_in_enum */
EIF_INTEGER_32 F117_2451 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_shadow_etched_in_enum", 116, Current, 0, 0, 2610);
	Result = (EIF_INTEGER_32) GTK_SHADOW_ETCHED_IN;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_shadow_etched_out_enum */
EIF_INTEGER_32 F117_2452 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_shadow_etched_out_enum", 116, Current, 0, 0, 2611);
	Result = (EIF_INTEGER_32) GTK_SHADOW_ETCHED_OUT;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_shadow_in_enum */
EIF_INTEGER_32 F117_2453 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_shadow_in_enum", 116, Current, 0, 0, 2612);
	Result = (EIF_INTEGER_32) GTK_SHADOW_IN;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_shadow_out_enum */
EIF_INTEGER_32 F117_2454 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_shadow_out_enum", 116, Current, 0, 0, 2613);
	Result = (EIF_INTEGER_32) GTK_SHADOW_OUT;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_window_toplevel_enum */
EIF_INTEGER_32 F117_2455 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_toplevel_enum", 116, Current, 0, 0, 2614);
	Result = (EIF_INTEGER_32) GTK_WINDOW_TOPLEVEL;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_window_popup_enum */
EIF_INTEGER_32 F117_2456 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_window_popup_enum", 116, Current, 0, 0, 2615);
	Result = (EIF_INTEGER_32) GTK_WINDOW_POPUP;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_win_pos_center_enum */
EIF_INTEGER_32 F117_2457 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_win_pos_center_enum", 116, Current, 0, 0, 2616);
	Result = (EIF_INTEGER_32) GTK_WIN_POS_CENTER;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_win_pos_none_enum */
EIF_INTEGER_32 F117_2458 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_win_pos_none_enum", 116, Current, 0, 0, 2617);
	Result = (EIF_INTEGER_32) GTK_WIN_POS_NONE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_policy_automatic_enum */
EIF_INTEGER_32 F117_2460 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_policy_automatic_enum", 116, Current, 0, 0, 2619);
	Result = (EIF_INTEGER_32) GTK_POLICY_AUTOMATIC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_policy_always_enum */
EIF_INTEGER_32 F117_2461 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_policy_always_enum", 116, Current, 0, 0, 2620);
	Result = (EIF_INTEGER_32) GTK_POLICY_ALWAYS;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_policy_never_enum */
EIF_INTEGER_32 F117_2462 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_policy_never_enum", 116, Current, 0, 0, 2621);
	Result = (EIF_INTEGER_32) GTK_POLICY_NEVER;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_drag_finish */
void F117_2467 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_NATURAL_32 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_drag_finish", 116, Current, 0, 4, 2626);gtk_drag_finish((GdkDragContext*) arg1, (gboolean) arg2, (gboolean) arg3, (guint32) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_box_get_spacing */
EIF_INTEGER_32 F117_2470 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_box_get_spacing", 116, Current, 0, 1, 2629);Result = (EIF_INTEGER_32) gtk_box_get_spacing((GtkBox*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_box_pack_start */
void F117_2472 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_box_pack_start", 116, Current, 0, 5, 2631);gtk_box_pack_start((GtkBox*) arg1, (GtkWidget*) arg2, (gboolean) arg3, (gboolean) arg4, (guint) arg5);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_box_query_child_packing */
void F117_2473 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_POINTER arg5, EIF_POINTER arg6)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_box_query_child_packing", 116, Current, 0, 6, 2632);gtk_box_query_child_packing((GtkBox*) arg1, (GtkWidget*) arg2, (gboolean*) arg3, (gboolean*) arg4, (guint*) arg5, (GtkPackType*) arg6);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_box_reorder_child */
void F117_2474 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_box_reorder_child", 116, Current, 0, 3, 2633);gtk_box_reorder_child((GtkBox*) arg1, (GtkWidget*) arg2, (gint) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_box_set_child_packing */
void F117_2475 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_box_set_child_packing", 116, Current, 0, 6, 2634);gtk_box_set_child_packing((GtkBox*) arg1, (GtkWidget*) arg2, (gboolean) arg3, (gboolean) arg4, (guint) arg5, (GtkPackType) arg6);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_box_set_homogeneous */
void F117_2476 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_box_set_homogeneous", 116, Current, 0, 2, 2635);gtk_box_set_homogeneous((GtkBox*) arg1, (gboolean) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_box_set_spacing */
void F117_2477 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_box_set_spacing", 116, Current, 0, 2, 2636);gtk_box_set_spacing((GtkBox*) arg1, (gint) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_separator_new */
EIF_POINTER F117_2478 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_separator_new", 116, Current, 0, 1, 2637);Result = (EIF_POINTER) gtk_separator_new((GtkOrientation) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_button_new */
EIF_POINTER F117_2479 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_button_new", 116, Current, 0, 0, 2638);Result = (EIF_POINTER) gtk_button_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_check_button_new */
EIF_POINTER F117_2480 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_check_button_new", 116, Current, 0, 0, 2639);Result = (EIF_POINTER) gtk_check_button_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_radio_button_get_group */
EIF_POINTER F117_2481 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_radio_button_get_group", 116, Current, 0, 1, 2640);Result = (EIF_POINTER) gtk_radio_button_get_group((GtkRadioButton*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_radio_button_set_group */
void F117_2483 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_radio_button_set_group", 116, Current, 0, 2, 2642);gtk_radio_button_set_group((GtkRadioButton*) arg1, (GSList*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_is_menu */
EIF_BOOLEAN F117_2484 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_is_menu", 116, Current, 0, 1, 2643);
	Result = (EIF_BOOLEAN) EIF_TEST(GTK_IS_MENU((arg1)));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_check_menu_item_set_active */
void F117_2487 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_check_menu_item_set_active", 116, Current, 0, 2, 2646);gtk_check_menu_item_set_active((GtkCheckMenuItem*) arg1, (gboolean) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_menu_item_deselect */
void F117_2491 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_menu_item_deselect", 116, Current, 0, 1, 2650);gtk_menu_item_deselect((GtkMenuItem*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_menu_item_new */
EIF_POINTER F117_2492 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_menu_item_new", 116, Current, 0, 0, 2651);Result = (EIF_POINTER) gtk_menu_item_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_menu_item_set_submenu */
void F117_2494 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_menu_item_set_submenu", 116, Current, 0, 2, 2653);gtk_menu_item_set_submenu((GtkMenuItem*) arg1, (GtkWidget*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_menu_new */
EIF_POINTER F117_2495 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_menu_new", 116, Current, 0, 0, 2654);Result = (EIF_POINTER) gtk_menu_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_menu_shell_cancel */
void F117_2496 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_menu_shell_cancel", 116, Current, 0, 1, 2655);
	inline_F117_2496 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_menu_shell_deactivate */
void F117_2497 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_menu_shell_deactivate", 116, Current, 0, 1, 2656);gtk_menu_shell_deactivate((GtkMenuShell*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_menu_shell_insert */
void F117_2499 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_menu_shell_insert", 116, Current, 0, 3, 2658);gtk_menu_shell_insert((GtkMenuShell*) arg1, (GtkWidget*) arg2, (gint) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_editable_set_editable */
void F117_2507 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_editable_set_editable", 116, Current, 0, 2, 2666);gtk_editable_set_editable((GtkEditable*) arg1, (gboolean) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_entry_get_text */
EIF_POINTER F117_2509 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_entry_get_text", 116, Current, 0, 1, 2668);Result = (EIF_POINTER) gtk_entry_get_text((GtkEntry*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_entry_new */
EIF_POINTER F117_2510 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_entry_new", 116, Current, 0, 0, 2669);Result = (EIF_POINTER) gtk_entry_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_entry_set_text */
void F117_2511 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_entry_set_text", 116, Current, 0, 2, 2670);gtk_entry_set_text((GtkEntry*) arg1, (gchar*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_entry_set_width_chars */
void F117_2512 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_entry_set_width_chars", 116, Current, 0, 2, 2671);
	inline_F117_2512 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_entry_set_visibility */
void F117_2513 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_entry_set_visibility", 116, Current, 0, 2, 2672);gtk_entry_set_visibility((GtkEntry*) arg1, (gboolean) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_frame_new */
EIF_POINTER F117_2519 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_frame_new", 116, Current, 0, 1, 2678);Result = (EIF_POINTER) gtk_frame_new((gchar*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_frame_set_label */
void F117_2520 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_frame_set_label", 116, Current, 0, 2, 2679);gtk_frame_set_label((GtkFrame*) arg1, (gchar*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_frame_set_label_align */
void F117_2521 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2, EIF_REAL_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_frame_set_label_align", 116, Current, 0, 3, 2680);gtk_frame_set_label_align((GtkFrame*) arg1, (gfloat) arg2, (gfloat) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_frame_set_shadow_type */
void F117_2522 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_frame_set_shadow_type", 116, Current, 0, 2, 2681);gtk_frame_set_shadow_type((GtkFrame*) arg1, (GtkShadowType) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_grab_add */
void F117_2524 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_grab_add", 116, Current, 0, 1, 2683);gtk_grab_add((GtkWidget*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_grab_get_current */
EIF_POINTER F117_2525 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_grab_get_current", 116, Current, 0, 0, 2684);Result = (EIF_POINTER) gtk_grab_get_current();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_grab_remove */
void F117_2526 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_grab_remove", 116, Current, 0, 1, 2685);gtk_grab_remove((GtkWidget*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_is_label */
EIF_BOOLEAN F117_2533 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_is_label", 116, Current, 0, 1, 2692);
	Result = (EIF_BOOLEAN) EIF_TEST(GTK_IS_LABEL((arg1)));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_label_new */
EIF_POINTER F117_2534 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_label_new", 116, Current, 0, 1, 2693);Result = (EIF_POINTER) gtk_label_new((gchar*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_label_set_justify */
void F117_2535 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_label_set_justify", 116, Current, 0, 2, 2694);gtk_label_set_justify((GtkLabel*) arg1, (GtkJustification) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_label_set_text */
void F117_2536 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_label_set_text", 116, Current, 0, 2, 2695);gtk_label_set_text((GtkLabel*) arg1, (gchar*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_label_set_xalign */
void F117_2537 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_label_set_xalign", 116, Current, 0, 2, 2696);
	inline_F117_2537 ((EIF_POINTER) arg1, (EIF_REAL_32) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_label_set_yalign */
void F117_2538 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_label_set_yalign", 116, Current, 0, 2, 2697);
	inline_F117_2538 ((EIF_POINTER) arg1, (EIF_REAL_32) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_label_set_attributes */
void F117_2540 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_label_set_attributes", 116, Current, 0, 2, 2699);
	inline_F117_2540 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_radio_menu_item_set_group */
void F117_2544 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_radio_menu_item_set_group", 116, Current, 0, 2, 2703);gtk_radio_menu_item_set_group((GtkRadioMenuItem*) arg1, (GSList*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_scrolled_window_get_hadjustment */
EIF_POINTER F117_2550 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_scrolled_window_get_hadjustment", 116, Current, 0, 1, 2709);Result = (EIF_POINTER) gtk_scrolled_window_get_hadjustment((GtkScrolledWindow*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_scrolled_window_get_vadjustment */
EIF_POINTER F117_2551 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_scrolled_window_get_vadjustment", 116, Current, 0, 1, 2710);Result = (EIF_POINTER) gtk_scrolled_window_get_vadjustment((GtkScrolledWindow*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_scrolled_window_new */
EIF_POINTER F117_2552 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_scrolled_window_new", 116, Current, 0, 2, 2711);Result = (EIF_POINTER) gtk_scrolled_window_new((GtkAdjustment*) arg1, (GtkAdjustment*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_scrolled_window_set_policy */
void F117_2553 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_scrolled_window_set_policy", 116, Current, 0, 3, 2712);gtk_scrolled_window_set_policy((GtkScrolledWindow*) arg1, (GtkPolicyType) arg2, (GtkPolicyType) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_toggle_button_get_active */
EIF_BOOLEAN F117_2556 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_toggle_button_get_active", 116, Current, 0, 1, 2715);Result = (EIF_BOOLEAN) EIF_TEST(gtk_toggle_button_get_active((GtkToggleButton*) arg1));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_toggle_button_set_active */
void F117_2558 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_toggle_button_set_active", 116, Current, 0, 2, 2717);gtk_toggle_button_set_active((GtkToggleButton*) arg1, (gboolean) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_get_event_widget */
EIF_POINTER F117_2559 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_get_event_widget", 116, Current, 0, 1, 2718);Result = (EIF_POINTER) gtk_get_event_widget((GdkEvent*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_main_do_event */
void F117_2560 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_main_do_event", 116, Current, 0, 1, 2719);gtk_main_do_event((GdkEvent*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_propagate_event */
void F117_2561 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_propagate_event", 116, Current, 0, 2, 2720);gtk_propagate_event((GtkWidget*) arg1, (GdkEvent*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_allocation_struct_height */
EIF_INTEGER_32 F117_2562 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_allocation_struct_height", 116, Current, 0, 1, 2721);Result = (EIF_INTEGER_32) (((GtkAllocation *)arg1)->height);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_allocation_struct_width */
EIF_INTEGER_32 F117_2563 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_allocation_struct_width", 116, Current, 0, 1, 2722);Result = (EIF_INTEGER_32) (((GtkAllocation *)arg1)->width);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_allocation_struct_x */
EIF_INTEGER_32 F117_2564 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_allocation_struct_x", 116, Current, 0, 1, 2723);Result = (EIF_INTEGER_32) (((GtkAllocation *)arg1)->x);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_allocation_struct_y */
EIF_INTEGER_32 F117_2565 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_allocation_struct_y", 116, Current, 0, 1, 2724);Result = (EIF_INTEGER_32) (((GtkAllocation *)arg1)->y);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.set_gtk_allocation_struct_height */
void F117_2566 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_gtk_allocation_struct_height", 116, Current, 0, 2, 2725);(((GtkAllocation *)arg1)->height = (gint)(arg2));
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.set_gtk_allocation_struct_width */
void F117_2567 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_gtk_allocation_struct_width", 116, Current, 0, 2, 2726);(((GtkAllocation *)arg1)->width = (gint)(arg2));
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.c_gtk_allocation_struct_size */
EIF_INTEGER_32 F117_2570 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_gtk_allocation_struct_size", 116, Current, 0, 0, 2450);
	Result = (EIF_INTEGER_32) sizeof(GtkAllocation);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_bin_get_child */
EIF_POINTER F117_2572 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_bin_get_child", 116, Current, 0, 1, 2452);Result = (EIF_POINTER) gtk_bin_get_child((GtkBin*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_viewport_new */
EIF_POINTER F117_2586 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_viewport_new", 116, Current, 0, 2, 2466);Result = (EIF_POINTER) gtk_viewport_new((GtkAdjustment*) arg1, (GtkAdjustment*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_adjustment_set_value */
void F117_2589 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_adjustment_set_value", 116, Current, 0, 2, 2469);gtk_adjustment_set_value((GtkAdjustment*) arg1, (gfloat) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_adjustment_get_lower */
EIF_REAL_32 F117_2590 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_adjustment_get_lower", 116, Current, 0, 1, 2470);Result = (EIF_REAL_32) gtk_adjustment_get_lower((GtkAdjustment*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_adjustment_get_step_increment */
EIF_REAL_32 F117_2593 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_adjustment_get_step_increment", 116, Current, 0, 1, 2473);Result = (EIF_REAL_32) gtk_adjustment_get_step_increment((GtkAdjustment*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_adjustment_get_upper */
EIF_REAL_32 F117_2594 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_adjustment_get_upper", 116, Current, 0, 1, 2474);Result = (EIF_REAL_32) gtk_adjustment_get_upper((GtkAdjustment*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_adjustment_set_lower */
void F117_2597 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_adjustment_set_lower", 116, Current, 0, 2, 2477);gtk_adjustment_set_lower((GtkAdjustment*) arg1, (gdouble) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_adjustment_set_step_increment */
void F117_2600 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_adjustment_set_step_increment", 116, Current, 0, 2, 2480);gtk_adjustment_set_step_increment((GtkAdjustment*) arg1, (gdouble) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_adjustment_set_upper */
void F117_2601 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_adjustment_set_upper", 116, Current, 0, 2, 2481);gtk_adjustment_set_upper((GtkAdjustment*) arg1, (gdouble) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GTK}.gtk_requisition_struct_height */
EIF_INTEGER_32 F117_2602 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_requisition_struct_height", 116, Current, 0, 1, 2482);Result = (EIF_INTEGER_32) (((GtkRequisition *)arg1)->height);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.gtk_requisition_struct_width */
EIF_INTEGER_32 F117_2603 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_requisition_struct_width", 116, Current, 0, 1, 2483);Result = (EIF_INTEGER_32) (((GtkRequisition *)arg1)->width);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.c_gtk_requisition_struct_size */
EIF_INTEGER_32 F117_2604 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_gtk_requisition_struct_size", 116, Current, 0, 0, 2484);
	Result = (EIF_INTEGER_32) sizeof(GtkRequisition);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.rgba_struct_to_style_color_string */
EIF_REFERENCE F117_2606 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REAL_64 loc4 = (EIF_REAL_64) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc5);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("rgba_struct_to_style_color_string", 116, Current, 5, 1, 2486);
	RTGC;
	RTHOOK(1);
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 255L));
	loc1 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) (((GdkRGBA *)arg1)->red) * tr8_1);
	RTHOOK(2);
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 255L));
	loc2 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) (((GdkRGBA *)arg1)->green) * tr8_1);
	RTHOOK(3);
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 255L));
	loc3 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) (((GdkRGBA *)arg1)->blue) * tr8_1);
	RTHOOK(4);
	loc4 = (EIF_REAL_64) (((GdkRGBA *)arg1)->alpha);
	RTHOOK(5);
	if ((EIF_BOOLEAN) eif_is_less_real_64 (loc4, (EIF_REAL_64) 1.0)) {
		RTHOOK(6);
		loc5 = RTLNS(eif_new_type(1411, 0x00).id, 1411, _OBJSIZ_1_8_0_4_0_0_0_0_);
		F1412_14285(RTCW(loc5), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 7L));
		RTHOOK(7);
		tr1 = RTMS_EX_H("rgb(",4,1919377960);
		tr2 = eif_out__i4_s1(loc1);
		tr1 = F1059_9029(tr1, tr2);
		tr2 = RTMS_EX_H(",",1,44);
		tr1 = F1059_9029(RTCW(tr1), tr2);
		tr2 = eif_out__i4_s1(loc2);
		tr1 = F1059_9029(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(",",1,44);
		tr1 = F1059_9029(RTCW(tr1), tr2);
		tr2 = eif_out__i4_s1(loc3);
		tr1 = F1059_9029(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(",",1,44);
		tr1 = F1059_9029(RTCW(tr1), tr2);
		tr2 = F1412_14303(RTCW(loc5), loc4);
		tr1 = F1059_9029(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(")",1,41);
		Result = F1059_9029(RTCW(tr1), tr2);
	} else {
		RTHOOK(8);
		tr1 = RTMS_EX_H("rgb(",4,1919377960);
		tr2 = eif_out__i4_s1(loc1);
		tr1 = F1059_9029(tr1, tr2);
		tr2 = RTMS_EX_H(",",1,44);
		tr1 = F1059_9029(RTCW(tr1), tr2);
		tr2 = eif_out__i4_s1(loc2);
		tr1 = F1059_9029(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(",",1,44);
		tr1 = F1059_9029(RTCW(tr1), tr2);
		tr2 = eif_out__i4_s1(loc3);
		tr1 = F1059_9029(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(")",1,41);
		Result = F1059_9029(RTCW(tr1), tr2);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.rgba_struct_to_color */
EIF_REFERENCE F117_2607 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 tr8_1;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("rgba_struct_to_color", 116, Current, 0, 1, 2487);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1095, 0x00).id, 1095, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr8_1 = (EIF_REAL_64) (((GdkRGBA *)arg1)->red);
	tr4_1 = (EIF_REAL_32) (tr8_1);
	tr8_1 = (EIF_REAL_64) (((GdkRGBA *)arg1)->green);
	tr4_2 = (EIF_REAL_32) (tr8_1);
	tr8_1 = (EIF_REAL_64) (((GdkRGBA *)arg1)->blue);
	tr4_3 = (EIF_REAL_32) (tr8_1);
	F1096_9422(RTCW(Result), tr4_1, tr4_2, tr4_3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.style_color */
EIF_REFERENCE F117_2608 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("style_color", 116, Current, 3, 2, 2488);
	RTGC;
	RTHOOK(1);
	loc2 = (EIF_POINTER) calloc (sizeof(GdkRGBA), 1);
	RTHOOK(2);
	loc1 = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F923_6661(RTCW(loc1), arg2);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	loc3 = EIF_TEST (inline_F115_1907(arg1, tp1, loc2));
	RTHOOK(4);
	if (loc3) {
		RTHOOK(5);
		Result = F117_2607(Current, loc2);
	}
	RTHOOK(6);
	free(loc2);
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.rgba_string_style_color */
EIF_REFERENCE F117_2609 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("rgba_string_style_color", 116, Current, 3, 2, 2489);
	RTGC;
	RTHOOK(1);
	loc2 = (EIF_POINTER) calloc (sizeof(GdkRGBA), 1);
	RTHOOK(2);
	loc1 = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F923_6661(RTCW(loc1), arg2);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	loc3 = EIF_TEST (inline_F115_1907(arg1, tp1, loc2));
	RTHOOK(4);
	if (loc3) {
		RTHOOK(5);
		Result = F117_2606(Current, loc2);
	}
	RTHOOK(6);
	free(loc2);
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK}.rgba_string_default_background_color */
EIF_REFERENCE F117_2610 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("rgba_string_default_background_color", 116, Current, 3, 0, 2490);
	RTGC;
	RTHOOK(1);
	loc2 = (EIF_POINTER) gtk_dialog_new();
	RTHOOK(2);
	tb1 = !loc2;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		loc3 = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) loc2);
		RTHOOK(4);
		ti4_1 = (EIF_INTEGER_32) GTK_STATE_NORMAL;
		tp1 = inline_F115_1885();
		inline_F115_1908(loc3, ti4_1, tp1, (EIF_POINTER *) &(loc1));
		RTHOOK(5);
		Result = F117_2606(Current, loc1);
		RTHOOK(6);
		gdk_rgba_free((GdkRGBA*) loc1);
		RTHOOK(7);
		inline_F115_1986(loc2);
	} else {
		RTHOOK(8);
		Result = RTMS_EX_H("rgb(0,0,0)",10,427135529);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit104 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
