
#ifndef _C3_i1128_
#define _C3_i1128_

#ifdef __cplusplus
extern "C" {
#endif

extern void F141_3008(EIF_REFERENCE);
extern void F141_3013(EIF_REFERENCE, EIF_REFERENCE);
extern void F141_3014(EIF_REFERENCE, EIF_REFERENCE);
extern void F141_3015(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit128(void);
extern EIF_REFERENCE F1054_8820(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
