
#ifndef _C3_be145_
#define _C3_be145_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F158_3195(EIF_REFERENCE);
extern void EIF_Minit145(void);
extern void F342_4978(EIF_REFERENCE);
extern void F129_2848(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
