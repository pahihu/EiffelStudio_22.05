/*
 * Code for class BENCH_WIZARD_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "be145.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BENCH_WIZARD_FACTORY}.new_wizard_initial_state */
EIF_REFERENCE F158_3195 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("new_wizard_initial_state", 157, Current, 0, 0, 3290);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(351, 0x00).id, 351, _OBJSIZ_6_3_0_0_0_0_0_0_);
	tr1 = RTLNS(eif_new_type(341, 0x00).id, 341, _OBJSIZ_4_9_0_0_0_0_0_0_);
	F342_4978(RTCW(tr1));
	F129_2848(RTCW(Result), tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit145 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
