
#ifndef _C3_op149_
#define _C3_op149_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_CHARACTER_8,3267)
static EIF_CHARACTER_8 F162_3267_body(EIF_REFERENCE);
extern EIF_CHARACTER_8 F162_3267(EIF_REFERENCE);
extern EIF_BOOLEAN F162_3269(EIF_REFERENCE);
extern EIF_BOOLEAN F162_3271(EIF_REFERENCE);
extern EIF_CHARACTER_8 F162_3272(EIF_REFERENCE);
extern void EIF_Minit149(void);

#ifdef __cplusplus
}
#endif

#endif
