/*
 * Code for class EIFFEL_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei122.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_CONSTANTS}.ise_eiffel_env */

EIF_REFERENCE F135_2896 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2896,RTMS_EX_H("ISE_EIFFEL",10,960687436));
}

/* {EIFFEL_CONSTANTS}.ise_library_env */

EIF_REFERENCE F135_2897 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2897,RTMS_EX_H("ISE_LIBRARY",11,552576601));
}

/* {EIFFEL_CONSTANTS}.eiffel_library_env */

EIF_REFERENCE F135_2898 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2898,RTMS_EX_H("EIFFEL_LIBRARY",14,1735641689));
}

/* {EIFFEL_CONSTANTS}.ise_iron_path_env */

EIF_REFERENCE F135_2899 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2899,RTMS_EX_H("ISE_IRON_PATH",13,591182408));
}

/* {EIFFEL_CONSTANTS}.iron_path_env */

EIF_REFERENCE F135_2900 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2900,RTMS_EX_H("IRON_PATH",9,490076488));
}

/* {EIFFEL_CONSTANTS}.ise_precomp_env */

EIF_REFERENCE F135_2901 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2901,RTMS_EX_H("ISE_PRECOMP",11,185338448));
}

/* {EIFFEL_CONSTANTS}.ise_platform_env */

EIF_REFERENCE F135_2902 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2902,RTMS_EX_H("ISE_PLATFORM",12,1318550605));
}

/* {EIFFEL_CONSTANTS}.ise_c_compiler_env */

EIF_REFERENCE F135_2903 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2903,RTMS_EX_H("ISE_C_COMPILER",14,1981921618));
}

/* {EIFFEL_CONSTANTS}.ise_projects_env */

EIF_REFERENCE F135_2905 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2905,RTMS_EX_H("ISE_PROJECTS",12,53375059));
}

/* {EIFFEL_CONSTANTS}.ise_user_files_env */

EIF_REFERENCE F135_2906 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2906,RTMS_EX_H("ISE_USER_FILES",14,1880819283));
}

/* {EIFFEL_CONSTANTS}.ise_app_data_env */

EIF_REFERENCE F135_2907 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2907,RTMS_EX_H("ISE_APP_DATA",12,1175984961));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_major_version */
static EIF_REFERENCE F135_2914_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("two_digit_minimum_major_version", 134, Current, 0, 0, 3000);
	RTGC;
	RTOSP (2914);
#define Result RTOSR(2914)
	RTOC_NEW(Result);
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 22U);
	Result = F135_2916(Current, ti4_1);
	RTOSE (2914);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F135_2914 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2914,F135_2914_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_minor_version */
static EIF_REFERENCE F135_2915_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("two_digit_minimum_minor_version", 134, Current, 0, 0, 3001);
	RTGC;
	RTOSP (2915);
#define Result RTOSR(2915)
	RTOC_NEW(Result);
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 5U);
	Result = F135_2916(Current, ti4_1);
	RTOSE (2915);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F135_2915 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2915,F135_2915_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_string */
EIF_REFERENCE F135_2916 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("two_digit_minimum_string", 134, Current, 0, 1, 3002);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1057_8897(RTCW(Result), ((EIF_INTEGER_32) 2L));
	RTHOOK(2);
	if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 10L))) {
		RTHOOK(3);
		F1059_9023(RTCW(Result), (EIF_CHARACTER_8) '0');
	}
	RTHOOK(4);
	F1059_9013(RTCW(Result), arg1);
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit122 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
