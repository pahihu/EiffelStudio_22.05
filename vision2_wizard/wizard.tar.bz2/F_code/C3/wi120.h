
#ifndef _C3_wi120_
#define _C3_wi120_

#ifdef __cplusplus
extern "C" {
#endif

extern void F133_2893(EIF_REFERENCE);
extern void F133_2894(EIF_REFERENCE);
extern void EIF_Minit120(void);
extern void F1151_10209(EIF_REFERENCE, EIF_REFERENCE);
extern void F132_2886(EIF_REFERENCE);
extern EIF_REFERENCE F124_2731(EIF_REFERENCE);
extern void F343_4993(EIF_REFERENCE);
extern void F131_2878(EIF_REFERENCE);
extern EIF_REFERENCE F124_2764(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
