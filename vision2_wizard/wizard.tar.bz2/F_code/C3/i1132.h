
#ifndef _C3_i1132_
#define _C3_i1132_

#ifdef __cplusplus
extern "C" {
#endif

extern void F145_3126(EIF_REFERENCE);
extern void F145_3128(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit132(void);
extern void F144_3078(EIF_REFERENCE);
extern void F143_3056(EIF_REFERENCE);
extern void F142_3016(EIF_REFERENCE);
extern void F1399_13972(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
