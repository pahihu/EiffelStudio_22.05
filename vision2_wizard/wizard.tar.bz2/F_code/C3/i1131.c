/*
 * Code for class I18N_CURRENCY_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1131.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_CURRENCY_INFO}.make */
void F144_3078 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 143, Current, 0, 0, 3185);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(3101,F144_3101, (Current));
	F144_3110(Current, tr1);
	RTHOOK(2);
	F144_3111(Current, ((EIF_INTEGER_32) 0L));
	RTHOOK(3);
	tr1 = RTOSCF(3102,F144_3102, (Current));
	F144_3112(Current, tr1);
	RTHOOK(4);
	F144_3113(Current, ((EIF_INTEGER_32) 2L));
	RTHOOK(5);
	tr1 = RTOSCF(3105,F144_3105, (Current));
	F144_3114(Current, tr1);
	RTHOOK(6);
	tr1 = RTOSCF(3106,F144_3106, (Current));
	F144_3115(Current, tr1);
	RTHOOK(7);
	tr1 = RTOSCF(3107,F144_3107, (Current));
	F144_3116(Current, tr1);
	RTHOOK(8);
	tr1 = RTOSCF(3108,F144_3108, (Current));
	F144_3117(Current, tr1);
	RTHOOK(9);
	tr1 = RTOSCF(3109,F144_3109, (Current));
	F144_3118(Current, tr1);
	RTHOOK(10);
	tr1 = RTOSCF(3101,F144_3101, (Current));
	F144_3119(Current, tr1);
	RTHOOK(11);
	F144_3120(Current, ((EIF_INTEGER_32) 0L));
	RTHOOK(12);
	tr1 = RTOSCF(3102,F144_3102, (Current));
	F144_3121(Current, tr1);
	RTHOOK(13);
	F144_3122(Current, ((EIF_INTEGER_32) 2L));
	RTHOOK(14);
	tr1 = RTOSCF(3105,F144_3105, (Current));
	F144_3123(Current, tr1);
	RTHOOK(15);
	tr1 = RTOSCF(3106,F144_3106, (Current));
	F144_3124(Current, tr1);
	RTHOOK(16);
	tr1 = RTOSCF(3109,F144_3109, (Current));
	F144_3125(Current, tr1);
	RTHOOK(17);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.default_currency_symbol */
static EIF_REFERENCE F144_3101_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_symbol", 143, Current, 0, 0, 3208);
	RTGC;
	RTOSP (3101);
#define Result RTOSR(3101)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H("",0,0);
	RTOSE (3101);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_3101 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3101,F144_3101_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_decimal_separator */
static EIF_REFERENCE F144_3102_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_decimal_separator", 143, Current, 0, 0, 3209);
	RTGC;
	RTOSP (3102);
#define Result RTOSR(3102)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H(".\000\000\000",1,46);
	RTOSE (3102);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_3102 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3102,F144_3102_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_group_separator */
static EIF_REFERENCE F144_3105_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_group_separator", 143, Current, 0, 0, 3212);
	RTGC;
	RTOSP (3105);
#define Result RTOSR(3105)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H(",\000\000\000",1,44);
	RTOSE (3105);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_3105 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3105,F144_3105_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_number_list_separator */
static EIF_REFERENCE F144_3106_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_number_list_separator", 143, Current, 0, 0, 3213);
	RTGC;
	RTOSP (3106);
#define Result RTOSR(3106)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H(";\000\000\000",1,59);
	RTOSE (3106);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_3106 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3106,F144_3106_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_positive_sign */
static EIF_REFERENCE F144_3107_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_positive_sign", 143, Current, 0, 0, 3214);
	RTGC;
	RTOSP (3107);
#define Result RTOSR(3107)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H("",0,0);
	RTOSE (3107);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_3107 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3107,F144_3107_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_negative_sign */
static EIF_REFERENCE F144_3108_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_negative_sign", 143, Current, 0, 0, 3215);
	RTGC;
	RTOSP (3108);
#define Result RTOSR(3108)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H("-\000\000\000",1,45);
	RTOSE (3108);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_3108 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3108,F144_3108_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_grouping */
static EIF_REFERENCE F144_3109_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("default_currency_grouping", 143, Current, 0, 0, 3216);
	RTGC;
	RTOSP (3109);
#define Result RTOSR(3109)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {862,1006,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 3L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 3L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F863_6501)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3109);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_3109 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3109,F144_3109_body,(Current));
}

/* {I18N_CURRENCY_INFO}.set_currency_symbol */
void F144_3110 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_symbol", 143, Current, 0, 1, 3217);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8826(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O3047[Dtype(Current)-143]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_symbol_location */
void F144_3111 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_currency_symbol_location", 143, Current, 0, 1, 3218);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O3048[Dtype(Current)-143]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_decimal_separator */
void F144_3112 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_decimal_separator", 143, Current, 0, 1, 3219);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O3052[Dtype(Current)-143]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_numbers_after_decimal_separator */
void F144_3113 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_currency_numbers_after_decimal_separator", 143, Current, 0, 1, 3220);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O3053[Dtype(Current)-143]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_group_separator */
void F144_3114 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_group_separator", 143, Current, 0, 1, 3221);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O3054[Dtype(Current)-143]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_number_list_separator */
void F144_3115 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_number_list_separator", 143, Current, 0, 1, 3222);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O3055[Dtype(Current)-143]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_positive_sign */
void F144_3116 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_positive_sign", 143, Current, 0, 1, 3223);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O3056[Dtype(Current)-143]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_negative_sign */
void F144_3117 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_negative_sign", 143, Current, 0, 1, 3224);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O3057[Dtype(Current)-143]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_grouping */
void F144_3118 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_currency_grouping", 143, Current, 0, 1, 3225);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O3058[Dtype(Current)-143]) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_symbol */
void F144_3119 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_international_currency_symbol", 143, Current, 0, 1, 3226);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8826(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O3059[Dtype(Current)-143]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_symbol_location */
void F144_3120 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_international_currency_symbol_location", 143, Current, 0, 1, 3227);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O3060[Dtype(Current)-143]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_decimal_separator */
void F144_3121 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_international_currency_decimal_separator", 143, Current, 0, 1, 3228);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O3064[Dtype(Current)-143]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_numbers_after_decimal_separator */
void F144_3122 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_international_currency_numbers_after_decimal_separator", 143, Current, 0, 1, 3229);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O3065[Dtype(Current)-143]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_group_separator */
void F144_3123 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_international_currency_group_separator", 143, Current, 0, 1, 3230);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O3066[Dtype(Current)-143]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_number_list_separator */
void F144_3124 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_international_currency_number_list_separator", 143, Current, 0, 1, 3183);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8827(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O3067[Dtype(Current)-143]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_grouping */
void F144_3125 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_international_currency_grouping", 143, Current, 0, 1, 3184);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O3068[Dtype(Current)-143]) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit131 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
