/*
 * Code for class I18N_LOCALE_CONV
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1125.h"
#include <locale.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_LOCALE_CONV}.localeconv */
EIF_POINTER F138_2934 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("localeconv", 137, Current, 0, 0, 3048);Result = (EIF_POINTER) localeconv();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.decimal_point */
EIF_POINTER F138_2936 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("decimal_point", 137, Current, 0, 1, 3050);Result = (EIF_POINTER) (((struct lconv *)arg1)->decimal_point);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.thousands_sep */
EIF_POINTER F138_2937 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("thousands_sep", 137, Current, 0, 1, 3051);Result = (EIF_POINTER) (((struct lconv *)arg1)->thousands_sep);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.grouping */
EIF_POINTER F138_2938 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("grouping", 137, Current, 0, 1, 3052);Result = (EIF_POINTER) (((struct lconv *)arg1)->grouping);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.int_curr_symbol */
EIF_POINTER F138_2939 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("int_curr_symbol", 137, Current, 0, 1, 3053);Result = (EIF_POINTER) (((struct lconv *)arg1)->int_curr_symbol);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.mon_decimal_point */
EIF_POINTER F138_2941 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("mon_decimal_point", 137, Current, 0, 1, 3055);Result = (EIF_POINTER) (((struct lconv *)arg1)->mon_decimal_point);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.mon_thousands_sep */
EIF_POINTER F138_2942 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("mon_thousands_sep", 137, Current, 0, 1, 3056);Result = (EIF_POINTER) (((struct lconv *)arg1)->mon_thousands_sep);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.mon_grouping */
EIF_POINTER F138_2943 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("mon_grouping", 137, Current, 0, 1, 3057);Result = (EIF_POINTER) (((struct lconv *)arg1)->mon_grouping);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.positive_sign */
EIF_POINTER F138_2944 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("positive_sign", 137, Current, 0, 1, 3058);Result = (EIF_POINTER) (((struct lconv *)arg1)->positive_sign);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.negative_sign */
EIF_POINTER F138_2945 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("negative_sign", 137, Current, 0, 1, 3039);Result = (EIF_POINTER) (((struct lconv *)arg1)->negative_sign);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.int_frac_digits */
EIF_CHARACTER_8 F138_2946 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("int_frac_digits", 137, Current, 0, 1, 3040);Result = (EIF_CHARACTER_8) (((struct lconv *)arg1)->int_frac_digits);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.frac_digits */
EIF_CHARACTER_8 F138_2947 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("frac_digits", 137, Current, 0, 1, 3041);Result = (EIF_CHARACTER_8) (((struct lconv *)arg1)->frac_digits);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit125 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
