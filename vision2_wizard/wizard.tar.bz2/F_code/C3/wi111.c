/*
 * Code for class WIZARD_SHARED
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi111.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_SHARED}.first_window */
EIF_REFERENCE F124_2731 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("first_window", 123, Current, 1, 0, 2840);
	RTGC;
	RTHOOK(1);
	RTCT0("attached first_window_cell.item as r", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(2732,F124_2732, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	Result = (EIF_REFERENCE) loc1;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {WIZARD_SHARED}.first_window_cell */
static EIF_REFERENCE F124_2732_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("first_window_cell", 123, Current, 0, 0, 2841);
	RTGC;
	RTOSP (2732);
#define Result RTOSR(2732)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {211,1150,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 211, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F212_3852(RTCW(tr1), NULL);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2732);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2732 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2732,F124_2732_body,(Current));
}

/* {WIZARD_SHARED}.main_box */
static EIF_REFERENCE F124_2733_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("main_box", 123, Current, 0, 0, 2842);
	RTGC;
	RTOSP (2733);
#define Result RTOSR(2733)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = *(EIF_REFERENCE *)(RTCV(F124_2731(Current)) + _REFACS_7_);
	RTOSE (2733);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2733 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2733,F124_2733_body,(Current));
}

/* {WIZARD_SHARED}.history */
static EIF_REFERENCE F124_2734_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("history", 123, Current, 0, 0, 2843);
	RTGC;
	RTOSP (2734);
#define Result RTOSR(2734)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {668,128,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 668, _OBJSIZ_4_3_0_1_0_0_0_0_);
	}
	F662_5513(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2734);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2734 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2734,F124_2734_body,(Current));
}

/* {WIZARD_SHARED}.wizard_source */
static EIF_REFERENCE F124_2735_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,tr3);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("wizard_source", 123, Current, 0, 0, 2844);
	RTGC;
	RTOSP (2735);
#define Result RTOSR(2735)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(673, 0x00).id, 673, _OBJSIZ_0_0_0_1_0_0_0_0_);
	tr3 = RTOSCF(5700,F674_5700, (RTCW(tr2)));
	tr2 = F338_4932(RTCW(tr3), ((EIF_INTEGER_32) 1L));
	F940_7444(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2735);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2735 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2735,F124_2735_body,(Current));
}

/* {WIZARD_SHARED}.wizard_pixmaps_path */
static EIF_REFERENCE F124_2736_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("wizard_pixmaps_path", 123, Current, 0, 0, 2845);
	RTGC;
	RTOSP (2736);
#define Result RTOSR(2736)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTOSCF(2735,F124_2735, (Current));
	tr2 = RTMS_EX_H("pixmaps",7,431953267);
	Result = F940_7471(RTCW(tr1), tr2);
	RTOSE (2736);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2736 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2736,F124_2736_body,(Current));
}

/* {WIZARD_SHARED}.wizard_resources_path */
static EIF_REFERENCE F124_2737_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("wizard_resources_path", 123, Current, 0, 0, 2846);
	RTGC;
	RTOSP (2737);
#define Result RTOSR(2737)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTOSCF(2735,F124_2735, (Current));
	tr2 = RTMS_EX_H("resources",9,195035251);
	Result = F940_7471(RTCW(tr1), tr2);
	RTOSE (2737);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2737 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2737,F124_2737_body,(Current));
}

/* {WIZARD_SHARED}.pixmap_extension */
static EIF_REFERENCE F124_2738_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pixmap_extension", 123, Current, 0, 0, 2847);
	RTGC;
	RTOSP (2738);
#define Result RTOSR(2738)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS_EX_H(".png",4,779120231);
	RTOSE (2738);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2738 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2738,F124_2738_body,(Current));
}

/* {WIZARD_SHARED}.platform_is_unix */
static EIF_BOOLEAN F124_2739_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("platform_is_unix", 123, Current, 0, 0, 2848);
	RTGC;
	RTOSP (2739);
#define Result RTOSR(2739)
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(265, 0x00).id, 265, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTOSE (2739);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F124_2739 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2739,F124_2739_body,(Current));
}

/* {WIZARD_SHARED}.pixmap */
static EIF_REFERENCE F124_2740_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("pixmap", 123, Current, 0, 0, 2849);
	RTGC;
	RTOSP (2740);
#define Result RTOSR(2740)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1159, 0x00).id, 1159, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2740);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2740 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2740,F124_2740_body,(Current));
}

/* {WIZARD_SHARED}.pixmap_icon */
static EIF_REFERENCE F124_2741_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("pixmap_icon", 123, Current, 0, 0, 2850);
	RTGC;
	RTOSP (2741);
#define Result RTOSR(2741)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1159, 0x00).id, 1159, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2741);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2741 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2741,F124_2741_body,(Current));
}

/* {WIZARD_SHARED}.app_cell */
static EIF_REFERENCE F124_2743_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("app_cell", 123, Current, 0, 0, 2852);
	RTGC;
	RTOSP (2743);
#define Result RTOSR(2743)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {211,1106,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 211, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F212_3852(RTCW(tr1), NULL);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2743);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2743 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2743,F124_2743_body,(Current));
}

/* {WIZARD_SHARED}.set_application */
void F124_2744 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_application", 123, Current, 0, 1, 2853);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(2743,F124_2743, (Current));
	F212_3852(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {WIZARD_SHARED}.help_engine */
static EIF_REFERENCE F124_2745_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("help_engine", 123, Current, 0, 0, 2854);
	RTGC;
	RTOSP (2745);
#define Result RTOSR(2745)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(185, 0x00).id, 185, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F186_3541(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2745);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2745 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2745,F124_2745_body,(Current));
}

/* {WIZARD_SHARED}.locale */
EIF_REFERENCE F124_2746 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("locale", 123, Current, 0, 0, 2855);
	RTGC;
	RTHOOK(1);
	Result = *(EIF_REFERENCE *)(RTCV(RTOSCF(2767,F124_2767, (Current))));
	RTHOOK(2);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		RTHOOK(3);
		tr1 = RTLNS(eif_new_type(1397, 0x00).id, 1397, _OBJSIZ_2_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("",0,0);
		F1398_13961(RTCW(tr1), tr2);
		Result = F1398_13963(RTCW(tr1));
		RTHOOK(4);
		tr1 = RTOSCF(2767,F124_2767, (Current));
		F212_3852(RTCW(tr1), Result);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {WIZARD_SHARED}.white_color */
static EIF_REFERENCE F124_2748_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("white_color", 123, Current, 0, 0, 2857);
	RTGC;
	RTOSP (2748);
#define Result RTOSR(2748)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1095, 0x00).id, 1095, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	tr4_2 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	tr4_3 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	F1096_9422(RTCW(tr1), tr4_1, tr4_2, tr4_3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2748);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2748 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2748,F124_2748_body,(Current));
}

/* {WIZARD_SHARED}.welcome_title_font */
static EIF_REFERENCE F124_2752_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("welcome_title_font", 123, Current, 1, 0, 2861);
	RTGC;
	RTOSP (2752);
#define Result RTOSR(2752)
	RTOC_NEW(Result);
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(222, 0x00).id, 222, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(1100, 0x00).id, 1100, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1091_9344(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	ti4_1 = ((EIF_INTEGER_32) 1L);
	F1101_9527(RTCW(Result), ti4_1);
	RTHOOK(4);
	ti4_1 = ((EIF_INTEGER_32) 8L);
	F1101_9528(RTCW(Result), ti4_1);
	RTHOOK(5);
	ti4_1 = ((EIF_INTEGER_32) 10L);
	F1101_9529(RTCW(Result), ti4_1);
	RTHOOK(6);
	if (RTOSCF(2739,F124_2739, (Current))) {
		RTHOOK(7);
		tr1 = F1101_9526(RTCW(Result));
		tr2 = F1054_8826(RTMS_EX_H("Tahoma",6,1918028641));
		F704_6008(RTCW(tr1), tr2);
	} else {
		RTHOOK(8);
		tr1 = F1101_9526(RTCW(Result));
		tr2 = F1054_8826(RTMS_EX_H("Verdana",7,71697761));
		F704_6008(RTCW(tr1), tr2);
		RTHOOK(9);
		tr1 = F1101_9526(RTCW(Result));
		tr2 = F1054_8826(RTMS_EX_H("Arial",5,1920008044));
		F704_6008(RTCW(tr1), tr2);
	}
	RTHOOK(10);
	tr1 = F1101_9526(RTCW(Result));
	tr2 = F1054_8826(RTMS_EX_H("Helvetica",9,684585313));
	F704_6008(RTCW(tr1), tr2);
	RTHOOK(11);
	F1101_9530(RTCW(Result), ((EIF_INTEGER_32) 16L));
	RTOSE (2752);
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2752 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2752,F124_2752_body,(Current));
}

/* {WIZARD_SHARED}.interior_title_font */
static EIF_REFERENCE F124_2753_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("interior_title_font", 123, Current, 1, 0, 2862);
	RTGC;
	RTOSP (2753);
#define Result RTOSR(2753)
	RTOC_NEW(Result);
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(222, 0x00).id, 222, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(1100, 0x00).id, 1100, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1091_9344(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	ti4_1 = ((EIF_INTEGER_32) 1L);
	F1101_9527(RTCW(Result), ti4_1);
	RTHOOK(4);
	ti4_1 = ((EIF_INTEGER_32) 8L);
	F1101_9528(RTCW(Result), ti4_1);
	RTHOOK(5);
	ti4_1 = ((EIF_INTEGER_32) 10L);
	F1101_9529(RTCW(Result), ti4_1);
	RTHOOK(6);
	tr1 = F1101_9526(RTCW(Result));
	tr2 = F1054_8826(RTMS_EX_H("Tahoma",6,1918028641));
	F704_6008(RTCW(tr1), tr2);
	RTHOOK(7);
	if ((EIF_BOOLEAN) !RTOSCF(2739,F124_2739, (Current))) {
		RTHOOK(8);
		tr1 = F1101_9526(RTCW(Result));
		tr2 = F1054_8826(RTMS_EX_H("Arial",5,1920008044));
		F704_6008(RTCW(tr1), tr2);
	}
	RTHOOK(9);
	tr1 = F1101_9526(RTCW(Result));
	tr2 = F1054_8826(RTMS_EX_H("Helvetica",9,684585313));
	F704_6008(RTCW(tr1), tr2);
	RTHOOK(10);
	F1101_9530(RTCW(Result), ((EIF_INTEGER_32) 11L));
	RTOSE (2753);
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2753 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2753,F124_2753_body,(Current));
}

/* {WIZARD_SHARED}.interior_font */
static EIF_REFERENCE F124_2754_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("interior_font", 123, Current, 1, 0, 2863);
	RTGC;
	RTOSP (2754);
#define Result RTOSR(2754)
	RTOC_NEW(Result);
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(222, 0x00).id, 222, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(1100, 0x00).id, 1100, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1091_9344(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	ti4_1 = ((EIF_INTEGER_32) 1L);
	F1101_9527(RTCW(Result), ti4_1);
	RTHOOK(4);
	ti4_1 = ((EIF_INTEGER_32) 7L);
	F1101_9528(RTCW(Result), ti4_1);
	RTHOOK(5);
	ti4_1 = ((EIF_INTEGER_32) 10L);
	F1101_9529(RTCW(Result), ti4_1);
	RTHOOK(6);
	tr1 = F1101_9526(RTCW(Result));
	tr2 = F1054_8826(RTMS_EX_H("Tahoma",6,1918028641));
	F704_6008(RTCW(tr1), tr2);
	RTHOOK(7);
	if ((EIF_BOOLEAN) !RTOSCF(2739,F124_2739, (Current))) {
		RTHOOK(8);
		tr1 = F1101_9526(RTCW(Result));
		tr2 = F1054_8826(RTMS_EX_H("Arial",5,1920008044));
		F704_6008(RTCW(tr1), tr2);
	}
	RTHOOK(9);
	tr1 = F1101_9526(RTCW(Result));
	tr2 = F1054_8826(RTMS_EX_H("Helvetica",9,684585313));
	F704_6008(RTCW(tr1), tr2);
	RTHOOK(10);
	F1101_9530(RTCW(Result), ((EIF_INTEGER_32) 11L));
	RTOSE (2754);
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2754 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2754,F124_2754_body,(Current));
}

/* {WIZARD_SHARED}.title_border_width */
static EIF_INTEGER_32 F124_2755_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("title_border_width", 123, Current, 0, 0, 2864);
	RTOSP (2755);
#define Result RTOSR(2755)
	RTHOOK(1);
	Result = F123_2729(Current, ((EIF_INTEGER_32) 22L));
	RTOSE (2755);
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F124_2755 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2755,F124_2755_body,(Current));
}

/* {WIZARD_SHARED}.title_right_border_width */
static EIF_INTEGER_32 F124_2756_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("title_right_border_width", 123, Current, 0, 0, 2865);
	RTOSP (2756);
#define Result RTOSR(2756)
	RTHOOK(1);
	Result = F123_2729(Current, ((EIF_INTEGER_32) 5L));
	RTOSE (2756);
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F124_2756 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2756,F124_2756_body,(Current));
}

/* {WIZARD_SHARED}.subtitle_border_width */
static EIF_INTEGER_32 F124_2757_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("subtitle_border_width", 123, Current, 0, 0, 2866);
	RTOSP (2757);
#define Result RTOSR(2757)
	RTHOOK(1);
	Result = F123_2729(Current, ((EIF_INTEGER_32) 20L));
	RTOSE (2757);
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F124_2757 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2757,F124_2757_body,(Current));
}

/* {WIZARD_SHARED}.interior_border_width */
static EIF_INTEGER_32 F124_2758_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("interior_border_width", 123, Current, 0, 0, 2867);
	RTOSP (2758);
#define Result RTOSR(2758)
	RTHOOK(1);
	Result = F123_2729(Current, ((EIF_INTEGER_32) 42L));
	RTOSE (2758);
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F124_2758 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2758,F124_2758_body,(Current));
}

/* {WIZARD_SHARED}.b_back */
EIF_REFERENCE F124_2759 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("b_back", 123, Current, 0, 0, 2868);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("< Back ",7,1831598368);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {WIZARD_SHARED}.b_next */
EIF_REFERENCE F124_2760 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("b_next", 123, Current, 0, 0, 2869);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Next >",6,27526462);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {WIZARD_SHARED}.b_cancel */
EIF_REFERENCE F124_2761 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("b_cancel", 123, Current, 0, 0, 2870);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Cancel",6,1984480108);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {WIZARD_SHARED}.b_help */
EIF_REFERENCE F124_2762 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("b_help", 123, Current, 0, 0, 2871);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Help",4,1214606448);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {WIZARD_SHARED}.b_finish */
EIF_REFERENCE F124_2763 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("b_finish", 123, Current, 0, 0, 2872);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Finish",6,1990836584);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {WIZARD_SHARED}.b_abort */
EIF_REFERENCE F124_2764 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("b_abort", 123, Current, 0, 0, 2873);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Abort",5,1651970164);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {WIZARD_SHARED}.b_browse */
EIF_REFERENCE F124_2765 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("b_browse", 123, Current, 0, 0, 2874);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Browse...",9,1590170670);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {WIZARD_SHARED}.t_choose_directory */
EIF_REFERENCE F124_2766 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("t_choose_directory", 123, Current, 0, 0, 2875);
	RTGC;
	RTHOOK(1);
	tr1 = F124_2746(Current);
	tr2 = RTMS_EX_H("Please choose a folder.",23,727220270);
	Result = F43_728(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {WIZARD_SHARED}.locale_cell */
static EIF_REFERENCE F124_2767_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("locale_cell", 123, Current, 0, 0, 2876);
	RTGC;
	RTOSP (2767);
#define Result RTOSR(2767)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {211,42,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 211, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F212_3852(RTCW(tr1), NULL);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2767);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2767 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2767,F124_2767_body,(Current));
}

void EIF_Minit111 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
