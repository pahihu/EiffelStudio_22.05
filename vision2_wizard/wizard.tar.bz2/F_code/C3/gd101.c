/*
 * Code for class GDK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gd101.h"
#include <ev_gtk.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F114_1574
static void inline_F114_1574 (EIF_POINTER arg1)
{
	return gdk_set_allowed_backends ( (const gchar*) arg1);
	;
}
#define INLINE_F114_1574
#endif
#ifndef INLINE_F114_1595
static int inline_F114_1595 (EIF_POINTER arg1)
{
	return (int) (GDK_IS_PIXBUF(arg1))
	;
}
#define INLINE_F114_1595
#endif
#ifndef INLINE_F114_1597
static void inline_F114_1597 (EIF_POINTER arg1)
{
	printf((char*) arg1)
	;
}
#define INLINE_F114_1597
#endif
#ifndef INLINE_F114_1598
static EIF_NATURAL_32 inline_F114_1598 (EIF_POINTER arg1)
{
	return (EIF_NATURAL_32) (((GObject*)arg1)->ref_count)
	;
}
#define INLINE_F114_1598
#endif
#ifndef INLINE_F114_1599
static int inline_F114_1599 (EIF_POINTER arg1)
{
	return (int) (g_object_is_floating((gpointer) arg1))
	;
}
#define INLINE_F114_1599
#endif
#ifndef INLINE_F114_1600
static EIF_POINTER inline_F114_1600 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref_sink((gpointer) arg1))
	;
}
#define INLINE_F114_1600
#endif
#ifndef INLINE_F114_1601
static EIF_POINTER inline_F114_1601 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref((gpointer) arg1))
	;
}
#define INLINE_F114_1601
#endif
#ifndef INLINE_F114_1602
static void inline_F114_1602 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F114_1602
#endif
#ifndef INLINE_F114_1605
static void inline_F114_1605 (EIF_POINTER arg1)
{
	g_object_run_dispose((GObject *) arg1)
	;
}
#define INLINE_F114_1605
#endif
#ifndef INLINE_F114_1611
static EIF_POINTER inline_F114_1611 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gdk_display_get_default_screen ((GdkDisplay*) arg1))
	;
}
#define INLINE_F114_1611
#endif
#ifndef INLINE_F114_1613
static EIF_INTEGER_32 inline_F114_1613 (EIF_POINTER arg1)
{
	return gdk_display_get_n_monitors ((GdkDisplay*) arg1)
	;
}
#define INLINE_F114_1613
#endif
#ifndef INLINE_F114_1618
static void inline_F114_1618 (EIF_POINTER arg1)
{
	gdk_display_flush ((GdkDisplay *)arg1);
	;
}
#define INLINE_F114_1618
#endif
#ifndef INLINE_F114_1619
static void inline_F114_1619 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gdk_monitor_get_geometry ((GdkMonitor*) arg1, (GdkRectangle*) arg2)
	;
}
#define INLINE_F114_1619
#endif
#ifndef INLINE_F114_1649
static EIF_POINTER inline_F114_1649 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	return gdk_window_create_similar_surface ((GdkWindow *)arg1,
                                   (cairo_content_t)arg2,
                                   (int)arg3,
                                   (int)arg4);
	;
}
#define INLINE_F114_1649
#endif
#ifndef INLINE_F114_1662
static void inline_F114_1662 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	return gdk_cairo_set_source_pixbuf ((cairo_t *) arg1, (const GdkPixbuf *) arg2, (gdouble) arg3, (gdouble) arg4);
	;
}
#define INLINE_F114_1662
#endif
#ifndef INLINE_F114_1668
static EIF_INTEGER_32 inline_F114_1668 (EIF_POINTER arg1)
{
	return (EIF_INTEGER_32) (gdk_visual_get_depth ((GdkVisual*) arg1))
	;
}
#define INLINE_F114_1668
#endif
#ifndef INLINE_F114_1737
static EIF_INTEGER_32 inline_F114_1737 (void)
{
	return GDK_COLORSPACE_RGB;
	;
}
#define INLINE_F114_1737
#endif
#ifndef INLINE_F114_1742
static EIF_POINTER inline_F114_1742 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	return (EIF_POINTER) (gdk_pixbuf_scale_simple ((GdkPixbuf*) arg1, (int) arg2, (int) arg3, (int) arg4))
	;
}
#define INLINE_F114_1742
#endif
#ifndef INLINE_F114_1751
static EIF_POINTER inline_F114_1751 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_get_from_surface ((cairo_surface_t *) arg1, (gint) arg2, (gint) arg3, (gint) arg4, (gint) arg5);
	;
}
#define INLINE_F114_1751
#endif
#ifndef INLINE_F114_1752
static EIF_POINTER inline_F114_1752 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_get_from_window ((GdkWindow *) arg1, (gint) arg2, (gint) arg3, (gint) arg4, (gint) arg5);
	;
}
#define INLINE_F114_1752
#endif
#ifndef INLINE_F114_1754
static EIF_POINTER inline_F114_1754 (EIF_POINTER arg1)
{
	return gdk_pixbuf_copy ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F114_1754
#endif
#ifndef INLINE_F114_1755
static EIF_INTEGER_32 inline_F114_1755 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_width ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F114_1755
#endif
#ifndef INLINE_F114_1756
static EIF_INTEGER_32 inline_F114_1756 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_height ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F114_1756
#endif
#ifndef INLINE_F114_1760
static EIF_POINTER inline_F114_1760 (EIF_POINTER arg1, EIF_POINTER* arg2)
{
	return gdk_pixbuf_new_from_file ((char*) arg1, (GError**) arg2);
	;
}
#define INLINE_F114_1760
#endif
#ifndef INLINE_F114_1762
static EIF_POINTER inline_F114_1762 (EIF_POINTER arg1)
{
	return gdk_pixbuf_new_from_xpm_data ((const char**) arg1);
	;
}
#define INLINE_F114_1762
#endif
#ifndef INLINE_F114_1764
static EIF_POINTER inline_F114_1764 (EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_new ((GdkColorspace) arg1, (gboolean) arg2, (int) arg3, (int) arg4, (int) arg5);
	;
}
#define INLINE_F114_1764
#endif
#ifndef INLINE_F114_1766
static void inline_F114_1766 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gdk_pixbuf_fill ((GdkPixbuf*)arg1, (guint32) arg2);
	;
}
#define INLINE_F114_1766
#endif
#ifndef INLINE_F114_1768
static EIF_INTEGER_32 inline_F114_1768 (EIF_POINTER arg1)
{
	return gdk_screen_get_resolution ((GdkScreen*)arg1);
	;
}
#define INLINE_F114_1768
#endif
#ifndef INLINE_F114_1769
static int inline_F114_1769 (EIF_POINTER arg1)
{
	return gdk_screen_is_composited ((GdkScreen*)arg1);
	;
}
#define INLINE_F114_1769
#endif
#ifndef INLINE_F114_1770
static EIF_POINTER inline_F114_1770 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gdk_screen_get_system_visual ((GdkScreen*) arg1))
	;
}
#define INLINE_F114_1770
#endif
#ifndef INLINE_F114_1771
static EIF_POINTER inline_F114_1771 (EIF_POINTER arg1)
{
	return gdk_screen_get_rgba_visual ((GdkScreen*)arg1);
	;
}
#define INLINE_F114_1771
#endif
#ifndef INLINE_F114_1773
static EIF_POINTER inline_F114_1773 (void)
{
	return gdk_screen_get_default()
	;
}
#define INLINE_F114_1773
#endif
#ifndef INLINE_F114_1775
static EIF_POINTER inline_F114_1775 (EIF_POINTER arg1)
{
	return gdk_screen_get_root_window ((GdkScreen *)arg1);;
	;
}
#define INLINE_F114_1775
#endif
#ifndef INLINE_F114_1776
static EIF_POINTER inline_F114_1776 (void)
{
	return gdk_get_default_root_window();
	;
}
#define INLINE_F114_1776
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GDK}.gdk_set_allowed_backends */
void F114_1574 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_set_allowed_backends", 113, Current, 0, 1, 1918);
	inline_F114_1574 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.g_free */
void F114_1575 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_free", 113, Current, 0, 1, 1919);g_free((gpointer) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.g_malloc */
EIF_POINTER F114_1576 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_malloc", 113, Current, 0, 1, 1920);Result = (EIF_POINTER) g_malloc((gulong) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_realloc */
EIF_POINTER F114_1577 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_realloc", 113, Current, 0, 2, 1921);Result = (EIF_POINTER) g_realloc((gpointer) arg1, (gulong) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_list_free */
void F114_1579 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_list_free", 113, Current, 0, 1, 1923);g_list_free((GList*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.g_list_nth_data */
EIF_POINTER F114_1584 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_list_nth_data", 113, Current, 0, 2, 1928);Result = (EIF_POINTER) g_list_nth_data((GList*) arg1, (guint) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.glist_struct_data */
EIF_POINTER F114_1586 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("glist_struct_data", 113, Current, 0, 1, 1930);Result = (EIF_POINTER) (((GList *)arg1)->data);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.glist_struct_next */
EIF_POINTER F114_1587 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("glist_struct_next", 113, Current, 0, 1, 1931);Result = (EIF_POINTER) (((GList *)arg1)->next);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_slist_index */
EIF_INTEGER_32 F114_1590 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_slist_index", 113, Current, 0, 2, 1934);Result = (EIF_INTEGER_32) g_slist_index((GSList*) arg1, (gpointer) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_slist_length */
EIF_INTEGER_32 F114_1591 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_slist_length", 113, Current, 0, 1, 1935);Result = (EIF_INTEGER_32) g_slist_length((GSList*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_slist_nth_data */
EIF_POINTER F114_1592 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_slist_nth_data", 113, Current, 0, 2, 1936);Result = (EIF_POINTER) g_slist_nth_data((GSList*) arg1, (guint) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gslist_struct_data */
EIF_POINTER F114_1593 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gslist_struct_data", 113, Current, 0, 1, 1937);Result = (EIF_POINTER) (((GSList *)arg1)->data);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_is_pixbuf */
EIF_BOOLEAN F114_1595 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_is_pixbuf", 113, Current, 0, 1, 1939);
	Result = EIF_TEST(inline_F114_1595 ((EIF_POINTER) arg1));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.printf */
void F114_1596 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("printf", 113, Current, 1, 1, 1940);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1));
	RTHOOK(2);
	inline_F114_1597(loc1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {GDK}.c_printf */
void F114_1597 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_printf", 113, Current, 0, 1, 1941);
	inline_F114_1597 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.internal_g_object_ref_count */
EIF_NATURAL_32 F114_1598 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("internal_g_object_ref_count", 113, Current, 0, 1, 1942);
	Result = inline_F114_1598 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_object_is_floating */
EIF_BOOLEAN F114_1599 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_object_is_floating", 113, Current, 0, 1, 1943);
	Result = EIF_TEST(inline_F114_1599 ((EIF_POINTER) arg1));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_object_ref_sink */
EIF_POINTER F114_1600 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_object_ref_sink", 113, Current, 0, 1, 1944);
	Result = inline_F114_1600 ((EIF_POINTER) arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_object_ref */
EIF_POINTER F114_1601 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_object_ref", 113, Current, 0, 1, 1945);
	Result = inline_F114_1601 ((EIF_POINTER) arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_object_unref */
void F114_1602 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_object_unref", 113, Current, 0, 1, 1946);
	inline_F114_1602 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.g_object_run_dispose */
void F114_1605 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_object_run_dispose", 113, Current, 0, 1, 1949);
	inline_F114_1605 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_display_get_default */
EIF_POINTER F114_1607 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_display_get_default", 113, Current, 0, 0, 1951);Result = (EIF_POINTER) gdk_display_get_default();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_display_get_default_seat */
EIF_POINTER F114_1608 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_display_get_default_seat", 113, Current, 0, 1, 1952);Result = (EIF_POINTER) gdk_display_get_default_seat((GdkDisplay*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_display_get_primary_monitor */
EIF_POINTER F114_1609 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_display_get_primary_monitor", 113, Current, 0, 1, 1953);Result = (EIF_POINTER) gdk_display_get_primary_monitor((GdkDisplay*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_display_get_default_screen */
EIF_POINTER F114_1611 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_display_get_default_screen", 113, Current, 0, 1, 1955);
	Result = inline_F114_1611 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_display_get_n_monitors */
EIF_INTEGER_32 F114_1613 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_display_get_n_monitors", 113, Current, 0, 1, 1957);
	Result = inline_F114_1613 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_display_flush */
void F114_1618 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_display_flush", 113, Current, 0, 1, 1962);
	inline_F114_1618 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_monitor_get_geometry */
void F114_1619 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_monitor_get_geometry", 113, Current, 0, 2, 1963);
	inline_F114_1619 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_window_get_device_position */
EIF_POINTER F114_1628 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3, EIF_INTEGER_32* arg4, EIF_POINTER arg5)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_get_device_position", 113, Current, 0, 5, 1972);Result = (EIF_POINTER) gdk_window_get_device_position((GdkWindow*) arg1, (GdkDevice *) arg2, (gint*) arg3, (gint*) arg4, (GdkModifierType*) arg5);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_window_get_origin */
EIF_INTEGER_32 F114_1633 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_get_origin", 113, Current, 0, 3, 1977);Result = (EIF_INTEGER_32) gdk_window_get_origin((GdkWindow*) arg1, (gint*) arg2, (gint*) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_window_get_user_data */
void F114_1634 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER* arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_get_user_data", 113, Current, 0, 2, 1978);gdk_window_get_user_data((GdkWindow*) arg1, (gpointer*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_window_hide */
void F114_1635 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_hide", 113, Current, 0, 1, 1979);gdk_window_hide((GdkWindow*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_window_raise */
void F114_1639 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_raise", 113, Current, 0, 1, 1983);gdk_window_raise((GdkWindow*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_window_set_cursor */
void F114_1640 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_set_cursor", 113, Current, 0, 2, 1984);gdk_window_set_cursor((GdkWindow*) arg1, (GdkCursor*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_window_set_decorations */
void F114_1641 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_set_decorations", 113, Current, 0, 2, 1985);gdk_window_set_decorations((GdkWindow*) arg1, (GdkWMDecoration) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_window_set_functions */
void F114_1643 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_set_functions", 113, Current, 0, 2, 1987);gdk_window_set_functions((GdkWindow*) arg1, (GdkWMFunction) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_window_create_similar_surface */
EIF_POINTER F114_1649 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_create_similar_surface", 113, Current, 0, 4, 1993);
	Result = inline_F114_1649 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_window_invalidate_rect */
void F114_1653 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_invalidate_rect", 113, Current, 0, 3, 1997);gdk_window_invalidate_rect((GdkWindow*) arg1, (GdkRectangle*) arg2, (gboolean) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_cairo_set_source_pixbuf */
void F114_1662 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_cairo_set_source_pixbuf", 113, Current, 0, 4, 1695);
	inline_F114_1662 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_REAL_64) arg3, (EIF_REAL_64) arg4);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_seat_grab */
EIF_INTEGER_32 F114_1664 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_BOOLEAN arg4, EIF_POINTER arg5, EIF_POINTER arg6, EIF_POINTER arg7, EIF_POINTER arg8)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_seat_grab", 113, Current, 0, 8, 1697);Result = (EIF_INTEGER_32) gdk_seat_grab((GdkSeat*) arg1, (GdkWindow*) arg2, (GdkSeatCapabilities) arg3, (gboolean) arg4, (GdkCursor*) arg5, (const GdkEvent*) arg6, (GdkSeatGrabPrepareFunc) arg7, (gpointer) arg8);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_seat_ungrab */
void F114_1665 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_seat_ungrab", 113, Current, 0, 1, 1698);gdk_seat_ungrab((GdkSeat*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_device_get_window_at_position */
EIF_POINTER F114_1667 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_device_get_window_at_position", 113, Current, 0, 3, 1700);Result = (EIF_POINTER) gdk_device_get_window_at_position((GdkDevice*) arg1, (gint*) arg2, (gint*) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_visual_get_depth */
EIF_INTEGER_32 F114_1668 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_visual_get_depth", 113, Current, 0, 1, 1701);
	Result = inline_F114_1668 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_free */
void F114_1669 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_free", 113, Current, 0, 1, 1702);gdk_event_free((GdkEvent*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_event_get */
EIF_POINTER F114_1670 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_get", 113, Current, 0, 0, 1703);Result = (EIF_POINTER) gdk_event_get();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_focus_struct_in */
EIF_INTEGER_8 F114_1672 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_focus_struct_in", 113, Current, 0, 1, 1705);Result = (EIF_INTEGER_8) (((GdkEventFocus *)arg1)->in);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_any_struct_send_event */
EIF_INTEGER_8 F114_1673 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_any_struct_send_event", 113, Current, 0, 1, 1706);Result = (EIF_INTEGER_8) (((GdkEventAny *)arg1)->send_event);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_any_struct_window */
EIF_POINTER F114_1674 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_any_struct_window", 113, Current, 0, 1, 1707);Result = (EIF_POINTER) (((GdkEventAny *)arg1)->window);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.set_gdk_event_any_struct_window */
void F114_1675 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_gdk_event_any_struct_window", 113, Current, 0, 2, 1708);(((GdkEventAny *)arg1)->window = (GdkWindow*)(arg2));
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_event_any_struct_type */
EIF_INTEGER_8 F114_1676 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_any_struct_type", 113, Current, 0, 1, 1709);Result = (EIF_INTEGER_8) (((GdkEventAny *)arg1)->type);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_button_struct_button */
EIF_INTEGER_32 F114_1677 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_button_struct_button", 113, Current, 0, 1, 1710);Result = (EIF_INTEGER_32) (((GdkEventButton *)arg1)->button);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_button_struct_window */
EIF_POINTER F114_1678 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_button_struct_window", 113, Current, 0, 1, 1711);Result = (EIF_POINTER) (((GdkEventButton *)arg1)->window);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_button_struct_state */
EIF_NATURAL_32 F114_1679 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_button_struct_state", 113, Current, 0, 1, 1712);Result = (EIF_NATURAL_32) (((GdkEventButton *)arg1)->state);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_button_struct_type */
EIF_INTEGER_32 F114_1680 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_button_struct_type", 113, Current, 0, 1, 1713);Result = (EIF_INTEGER_32) (((GdkEventButton *)arg1)->type);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_button_struct_x */
EIF_REAL_64 F114_1681 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_button_struct_x", 113, Current, 0, 1, 1714);Result = (EIF_REAL_64) (((GdkEventButton *)arg1)->x);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_button_struct_x_root */
EIF_REAL_64 F114_1682 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_button_struct_x_root", 113, Current, 0, 1, 1715);Result = (EIF_REAL_64) (((GdkEventButton *)arg1)->x_root);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_scroll_struct_x_root */
EIF_REAL_64 F114_1683 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_scroll_struct_x_root", 113, Current, 0, 1, 1716);Result = (EIF_REAL_64) (((GdkEventScroll *)arg1)->x_root);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_button_struct_y */
EIF_REAL_64 F114_1684 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_button_struct_y", 113, Current, 0, 1, 1717);Result = (EIF_REAL_64) (((GdkEventButton *)arg1)->y);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_button_struct_y_root */
EIF_REAL_64 F114_1685 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_button_struct_y_root", 113, Current, 0, 1, 1718);Result = (EIF_REAL_64) (((GdkEventButton *)arg1)->y_root);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_scroll_struct_y_root */
EIF_REAL_64 F114_1686 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_scroll_struct_y_root", 113, Current, 0, 1, 1719);Result = (EIF_REAL_64) (((GdkEventScroll *)arg1)->y_root);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_configure_struct_x */
EIF_INTEGER_32 F114_1687 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_configure_struct_x", 113, Current, 0, 1, 1720);Result = (EIF_INTEGER_32) (((GdkEventConfigure *)arg1)->x);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_configure_struct_y */
EIF_INTEGER_32 F114_1688 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_configure_struct_y", 113, Current, 0, 1, 1721);Result = (EIF_INTEGER_32) (((GdkEventConfigure *)arg1)->y);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_configure_struct_height */
EIF_INTEGER_32 F114_1689 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_configure_struct_height", 113, Current, 0, 1, 1722);Result = (EIF_INTEGER_32) (((GdkEventConfigure *)arg1)->height);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_configure_struct_width */
EIF_INTEGER_32 F114_1690 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_configure_struct_width", 113, Current, 0, 1, 1723);Result = (EIF_INTEGER_32) (((GdkEventConfigure *)arg1)->width);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_setting_struct_name */
EIF_POINTER F114_1691 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_setting_struct_name", 113, Current, 0, 1, 1724);Result = (EIF_POINTER) (((GdkEventSetting *)arg1)->name);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_crossing_struct_mode */
EIF_INTEGER_32 F114_1693 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_crossing_struct_mode", 113, Current, 0, 1, 1726);Result = (EIF_INTEGER_32) (((GdkEventCrossing *)arg1)->mode);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_key_struct_keyval */
EIF_NATURAL_32 F114_1701 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_key_struct_keyval", 113, Current, 0, 1, 1734);Result = (EIF_NATURAL_32) (((GdkEventKey *)arg1)->keyval);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_key_struct_state */
EIF_NATURAL_32 F114_1702 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_key_struct_state", 113, Current, 0, 1, 1735);Result = (EIF_NATURAL_32) (((GdkEventKey *)arg1)->state);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_key_struct_type */
EIF_INTEGER_32 F114_1703 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_key_struct_type", 113, Current, 0, 1, 1736);Result = (EIF_INTEGER_32) (((GdkEventKey *)arg1)->type);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_motion_struct_is_hint */
EIF_INTEGER_32 F114_1704 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_motion_struct_is_hint", 113, Current, 0, 1, 1737);Result = (EIF_INTEGER_32) (((GdkEventMotion *)arg1)->is_hint);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_motion_struct_state */
EIF_NATURAL_32 F114_1705 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_motion_struct_state", 113, Current, 0, 1, 1738);Result = (EIF_NATURAL_32) (((GdkEventMotion *)arg1)->state);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_motion_struct_window */
EIF_POINTER F114_1706 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_motion_struct_window", 113, Current, 0, 1, 1739);Result = (EIF_POINTER) (((GdkEventMotion *)arg1)->window);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_motion_struct_x */
EIF_REAL_64 F114_1707 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_motion_struct_x", 113, Current, 0, 1, 1740);Result = (EIF_REAL_64) (((GdkEventMotion *)arg1)->x);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_motion_struct_x_root */
EIF_REAL_64 F114_1708 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_motion_struct_x_root", 113, Current, 0, 1, 1741);Result = (EIF_REAL_64) (((GdkEventMotion *)arg1)->x_root);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_motion_struct_y */
EIF_REAL_64 F114_1709 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_motion_struct_y", 113, Current, 0, 1, 1742);Result = (EIF_REAL_64) (((GdkEventMotion *)arg1)->y);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_motion_struct_y_root */
EIF_REAL_64 F114_1710 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_motion_struct_y_root", 113, Current, 0, 1, 1743);Result = (EIF_REAL_64) (((GdkEventMotion *)arg1)->y_root);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_dnd_struct_context */
EIF_POINTER F114_1711 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_dnd_struct_context", 113, Current, 0, 1, 1744);Result = (EIF_POINTER) (((GdkEventDND *)arg1)->context);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_dnd_struct_time */
EIF_NATURAL_32 F114_1712 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_dnd_struct_time", 113, Current, 0, 1, 1745);Result = (EIF_NATURAL_32) (((GdkEventDND *)arg1)->time);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_scroll_struct_scroll_direction */
EIF_INTEGER_32 F114_1713 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_scroll_struct_scroll_direction", 113, Current, 0, 1, 1746);Result = (EIF_INTEGER_32) (((GdkEventScroll *)arg1)->direction);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.c_gdk_rgba_struct_allocate */
EIF_POINTER F114_1719 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_gdk_rgba_struct_allocate", 113, Current, 0, 0, 1752);
	Result = (EIF_POINTER) calloc (sizeof(GdkRGBA), 1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.rgba_free */
void F114_1720 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rgba_free", 113, Current, 0, 1, 1753);gdk_rgba_free((GdkRGBA*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.rgba_struct_red */
EIF_REAL_64 F114_1731 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rgba_struct_red", 113, Current, 0, 1, 1764);Result = (EIF_REAL_64) (((GdkRGBA *)arg1)->red);
	
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.rgba_struct_green */
EIF_REAL_64 F114_1732 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rgba_struct_green", 113, Current, 0, 1, 1765);Result = (EIF_REAL_64) (((GdkRGBA *)arg1)->green);
	
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.rgba_struct_blue */
EIF_REAL_64 F114_1733 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rgba_struct_blue", 113, Current, 0, 1, 1766);Result = (EIF_REAL_64) (((GdkRGBA *)arg1)->blue);
	
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.rgba_struct_alpha */
EIF_REAL_64 F114_1734 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rgba_struct_alpha", 113, Current, 0, 1, 1767);Result = (EIF_REAL_64) (((GdkRGBA *)arg1)->alpha);
	
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_colorspace_rgb_enum */
EIF_INTEGER_32 F114_1737 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_colorspace_rgb_enum", 113, Current, 0, 0, 1770);
	Result = inline_F114_1737 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_scale_simple */
EIF_POINTER F114_1742 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_scale_simple", 113, Current, 0, 4, 1775);
	Result = inline_F114_1742 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_get_has_alpha */
EIF_BOOLEAN F114_1747 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_get_has_alpha", 113, Current, 0, 1, 1780);Result = (EIF_BOOLEAN) EIF_TEST(gdk_pixbuf_get_has_alpha((GdkPixbuf*) arg1));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_get_from_surface */
EIF_POINTER F114_1751 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_get_from_surface", 113, Current, 0, 5, 1784);
	Result = inline_F114_1751 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4, (EIF_INTEGER_32) arg5);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_get_from_window */
EIF_POINTER F114_1752 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_get_from_window", 113, Current, 0, 5, 1785);
	Result = inline_F114_1752 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4, (EIF_INTEGER_32) arg5);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_copy */
EIF_POINTER F114_1754 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_copy", 113, Current, 0, 1, 1787);
	Result = inline_F114_1754 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_get_width */
EIF_INTEGER_32 F114_1755 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_get_width", 113, Current, 0, 1, 1788);
	Result = inline_F114_1755 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_get_height */
EIF_INTEGER_32 F114_1756 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_get_height", 113, Current, 0, 1, 1789);
	Result = inline_F114_1756 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_new_from_file */
EIF_POINTER F114_1760 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER* arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_new_from_file", 113, Current, 0, 2, 1793);
	Result = inline_F114_1760 ((EIF_POINTER) arg1, (EIF_POINTER*) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_new_from_xpm_data */
EIF_POINTER F114_1762 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_new_from_xpm_data", 113, Current, 0, 1, 1795);
	Result = inline_F114_1762 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_new */
EIF_POINTER F114_1764 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_new", 113, Current, 0, 5, 1797);
	Result = inline_F114_1764 ((EIF_INTEGER_32) arg1, (EIF_BOOLEAN) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4, (EIF_INTEGER_32) arg5);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_fill */
void F114_1766 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_fill", 113, Current, 0, 2, 1799);
	inline_F114_1766 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_pixbuf_add_alpha */
EIF_POINTER F114_1767 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2, EIF_NATURAL_8 arg3, EIF_NATURAL_8 arg4, EIF_NATURAL_8 arg5)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_add_alpha", 113, Current, 0, 5, 1800);Result = (EIF_POINTER) gdk_pixbuf_add_alpha((GdkPixbuf*) arg1, (gboolean) arg2, (guchar) arg3, (guchar) arg4, (guchar) arg5);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_screen_get_resolution */
EIF_INTEGER_32 F114_1768 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_screen_get_resolution", 113, Current, 0, 1, 1801);
	Result = inline_F114_1768 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_screen_is_composited */
EIF_BOOLEAN F114_1769 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_screen_is_composited", 113, Current, 0, 1, 1802);
	Result = EIF_TEST(inline_F114_1769 ((EIF_POINTER) arg1));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_screen_get_system_visual */
EIF_POINTER F114_1770 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_screen_get_system_visual", 113, Current, 0, 1, 1803);
	Result = inline_F114_1770 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_screen_get_rgba_visual */
EIF_POINTER F114_1771 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_screen_get_rgba_visual", 113, Current, 0, 1, 1804);
	Result = inline_F114_1771 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_screen_get_default */
EIF_POINTER F114_1773 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_screen_get_default", 113, Current, 0, 0, 1806);
	Result = inline_F114_1773 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_set_show_events */
void F114_1774 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_set_show_events", 113, Current, 0, 1, 1807);gdk_set_show_events((gboolean) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_screen_get_root_window */
EIF_POINTER F114_1775 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_screen_get_root_window", 113, Current, 0, 1, 1808);
	Result = inline_F114_1775 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_get_default_root_window */
EIF_POINTER F114_1776 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_get_default_root_window", 113, Current, 0, 0, 1809);
	Result = inline_F114_1776 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.c_gdk_geometry_struct_allocate */
EIF_POINTER F114_1779 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_gdk_geometry_struct_allocate", 113, Current, 0, 0, 1812);
	Result = (EIF_POINTER) calloc (sizeof(GdkGeometry), 1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.set_gdk_geometry_struct_max_height */
void F114_1784 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_gdk_geometry_struct_max_height", 113, Current, 0, 2, 1817);(((GdkGeometry *)arg1)->max_height = (gint)(arg2));
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.set_gdk_geometry_struct_max_width */
void F114_1785 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_gdk_geometry_struct_max_width", 113, Current, 0, 2, 1818);(((GdkGeometry *)arg1)->max_width = (gint)(arg2));
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.set_gdk_geometry_struct_min_height */
void F114_1787 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_gdk_geometry_struct_min_height", 113, Current, 0, 2, 1820);(((GdkGeometry *)arg1)->min_height = (gint)(arg2));
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.set_gdk_geometry_struct_min_width */
void F114_1788 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_gdk_geometry_struct_min_width", 113, Current, 0, 2, 1821);(((GdkGeometry *)arg1)->min_width = (gint)(arg2));
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_rectangle_struct_height */
EIF_INTEGER_32 F114_1792 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_rectangle_struct_height", 113, Current, 0, 1, 1825);Result = (EIF_INTEGER_32) (((GdkRectangle *)arg1)->height);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_rectangle_struct_width */
EIF_INTEGER_32 F114_1793 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_rectangle_struct_width", 113, Current, 0, 1, 1826);Result = (EIF_INTEGER_32) (((GdkRectangle *)arg1)->width);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_rectangle_struct_x */
EIF_INTEGER_32 F114_1794 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_rectangle_struct_x", 113, Current, 0, 1, 1827);Result = (EIF_INTEGER_32) (((GdkRectangle *)arg1)->x);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_rectangle_struct_y */
EIF_INTEGER_32 F114_1795 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_rectangle_struct_y", 113, Current, 0, 1, 1828);Result = (EIF_INTEGER_32) (((GdkRectangle *)arg1)->y);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.c_gdk_rectangle_struct_allocate */
EIF_POINTER F114_1796 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_gdk_rectangle_struct_allocate", 113, Current, 0, 0, 1829);
	Result = (EIF_POINTER) calloc (sizeof(GdkRectangle), 1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_cursor_new_for_display */
EIF_POINTER F114_1798 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_cursor_new_for_display", 113, Current, 0, 2, 1831);Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_cursor_new_from_pixbuf */
EIF_POINTER F114_1799 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_cursor_new_from_pixbuf", 113, Current, 0, 4, 1832);Result = (EIF_POINTER) gdk_cursor_new_from_pixbuf((GdkDisplay*) arg1, (GdkPixbuf*) arg2, (gint) arg3, (gint) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_selection_property_get */
EIF_INTEGER_32 F114_1800 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER* arg2, EIF_POINTER arg3, EIF_INTEGER_32* arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_selection_property_get", 113, Current, 0, 4, 1833);Result = (EIF_INTEGER_32) gdk_selection_property_get((GdkWindow*) arg1, (guchar**) arg2, (GdkAtom*) arg3, (gint*) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_drag_get_selection */
EIF_POINTER F114_1801 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_drag_get_selection", 113, Current, 0, 1, 1834);Result = (EIF_POINTER) gdk_drag_get_selection((GdkDragContext*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_drag_context_get_source_window */
EIF_POINTER F114_1802 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_drag_context_get_source_window", 113, Current, 0, 1, 1835);Result = (EIF_POINTER) gdk_drag_context_get_source_window((GdkDragContext*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_drag_context_get_dest_window */
EIF_POINTER F114_1803 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_drag_context_get_dest_window", 113, Current, 0, 1, 1836);Result = (EIF_POINTER) gdk_drag_context_get_dest_window((GdkDragContext*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_drag_context_list_targets */
EIF_POINTER F114_1804 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_drag_context_list_targets", 113, Current, 0, 1, 1837);Result = (EIF_POINTER) gdk_drag_context_list_targets((GdkDragContext*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_selection_convert */
void F114_1805 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_NATURAL_32 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_selection_convert", 113, Current, 0, 4, 1838);gdk_selection_convert((GdkWindow*) arg1, (GdkAtom) arg2, (GdkAtom) arg3, (guint32) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_drop_finish */
void F114_1806 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2, EIF_NATURAL_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_drop_finish", 113, Current, 0, 3, 1839);gdk_drop_finish((GdkDragContext*) arg1, (gboolean) arg2, (guint32) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_atom_name */
EIF_POINTER F114_1809 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_atom_name", 113, Current, 0, 1, 1842);Result = (EIF_POINTER) gdk_atom_name((GdkAtom) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_control_mask_enum */
EIF_NATURAL_32 F114_1818 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_control_mask_enum", 113, Current, 0, 0, 1851);
	Result = (EIF_NATURAL_32) GDK_CONTROL_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_mod1_mask_enum */
EIF_NATURAL_32 F114_1819 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_mod1_mask_enum", 113, Current, 0, 0, 1852);
	Result = (EIF_NATURAL_32) GDK_MOD1_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_shift_mask_enum */
EIF_NATURAL_32 F114_1820 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_shift_mask_enum", 113, Current, 0, 0, 1853);
	Result = (EIF_NATURAL_32) GDK_SHIFT_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_button_press_enum */
EIF_INTEGER_32 F114_1822 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_button_press_enum", 113, Current, 0, 0, 1855);
	Result = (EIF_INTEGER_32) GDK_BUTTON_PRESS;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_2button_press_enum */
EIF_INTEGER_32 F114_1823 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_2button_press_enum", 113, Current, 0, 0, 1856);
	Result = (EIF_INTEGER_32) GDK_2BUTTON_PRESS;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_3button_press_enum */
EIF_INTEGER_32 F114_1824 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_3button_press_enum", 113, Current, 0, 0, 1857);
	Result = (EIF_INTEGER_32) GDK_3BUTTON_PRESS;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_button_release_enum */
EIF_INTEGER_32 F114_1825 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_button_release_enum", 113, Current, 0, 0, 1858);
	Result = (EIF_INTEGER_32) GDK_BUTTON_RELEASE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_exposure_mask_enum */
EIF_INTEGER_32 F114_1826 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_exposure_mask_enum", 113, Current, 0, 0, 1859);
	Result = (EIF_INTEGER_32) GDK_EXPOSURE_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pointer_motion_mask_enum */
EIF_INTEGER_32 F114_1827 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pointer_motion_mask_enum", 113, Current, 0, 0, 1860);
	Result = (EIF_INTEGER_32) GDK_POINTER_MOTION_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pointer_motion_hint_mask_enum */
EIF_INTEGER_32 F114_1828 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pointer_motion_hint_mask_enum", 113, Current, 0, 0, 1861);
	Result = (EIF_INTEGER_32) GDK_POINTER_MOTION_HINT_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_button_press_mask_enum */
EIF_INTEGER_32 F114_1832 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_button_press_mask_enum", 113, Current, 0, 0, 1865);
	Result = (EIF_INTEGER_32) GDK_BUTTON_PRESS_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_button_release_mask_enum */
EIF_INTEGER_32 F114_1833 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_button_release_mask_enum", 113, Current, 0, 0, 1866);
	Result = (EIF_INTEGER_32) GDK_BUTTON_RELEASE_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_key_press_enum */
EIF_INTEGER_32 F114_1838 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_key_press_enum", 113, Current, 0, 0, 1871);
	Result = (EIF_INTEGER_32) GDK_KEY_PRESS;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_key_press_mask_enum */
EIF_INTEGER_32 F114_1840 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_key_press_mask_enum", 113, Current, 0, 0, 1873);
	Result = (EIF_INTEGER_32) GDK_KEY_PRESS_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_key_release_mask_enum */
EIF_INTEGER_32 F114_1841 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_key_release_mask_enum", 113, Current, 0, 0, 1874);
	Result = (EIF_INTEGER_32) GDK_KEY_RELEASE_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_enter_notify_mask_enum */
EIF_INTEGER_32 F114_1842 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_enter_notify_mask_enum", 113, Current, 0, 0, 1875);
	Result = (EIF_INTEGER_32) GDK_ENTER_NOTIFY_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_leave_notify_mask_enum */
EIF_INTEGER_32 F114_1843 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_leave_notify_mask_enum", 113, Current, 0, 0, 1876);
	Result = (EIF_INTEGER_32) GDK_LEAVE_NOTIFY_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_focus_change_mask_enum */
EIF_INTEGER_32 F114_1844 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_focus_change_mask_enum", 113, Current, 0, 0, 1877);
	Result = (EIF_INTEGER_32) GDK_FOCUS_CHANGE_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_visibility_notify_mask_enum */
EIF_INTEGER_32 F114_1845 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_visibility_notify_mask_enum", 113, Current, 0, 0, 1878);
	Result = (EIF_INTEGER_32) GDK_VISIBILITY_NOTIFY_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_structure_mask_enum */
EIF_INTEGER_32 F114_1846 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_structure_mask_enum", 113, Current, 0, 0, 1879);
	Result = (EIF_INTEGER_32) GDK_STRUCTURE_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_scroll_mask_enum */
EIF_INTEGER_32 F114_1851 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_scroll_mask_enum", 113, Current, 0, 0, 1884);
	Result = (EIF_INTEGER_32) GDK_SCROLL_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_decor_all_enum */
EIF_INTEGER_32 F114_1858 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_decor_all_enum", 113, Current, 0, 0, 1891);
	Result = (EIF_INTEGER_32) GDK_DECOR_ALL;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_decor_border_enum */
EIF_INTEGER_32 F114_1859 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_decor_border_enum", 113, Current, 0, 0, 1892);
	Result = (EIF_INTEGER_32) GDK_DECOR_BORDER;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_hint_max_size_enum */
EIF_INTEGER_32 F114_1862 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_hint_max_size_enum", 113, Current, 0, 0, 1895);
	Result = (EIF_INTEGER_32) GDK_HINT_MAX_SIZE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_hint_min_size_enum */
EIF_INTEGER_32 F114_1863 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_hint_min_size_enum", 113, Current, 0, 0, 1896);
	Result = (EIF_INTEGER_32) GDK_HINT_MIN_SIZE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_func_close_enum */
EIF_INTEGER_32 F114_1864 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_func_close_enum", 113, Current, 0, 0, 1897);
	Result = (EIF_INTEGER_32) GDK_FUNC_CLOSE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_func_move_enum */
EIF_INTEGER_32 F114_1865 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_func_move_enum", 113, Current, 0, 0, 1898);
	Result = (EIF_INTEGER_32) GDK_FUNC_MOVE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_func_resize_enum */
EIF_INTEGER_32 F114_1866 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_func_resize_enum", 113, Current, 0, 0, 1899);
	Result = (EIF_INTEGER_32) GDK_FUNC_RESIZE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_window_state_iconified_enum */
EIF_INTEGER_32 F114_1871 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_state_iconified_enum", 113, Current, 0, 0, 1904);
	Result = (EIF_INTEGER_32) GDK_WINDOW_STATE_ICONIFIED;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_window_state_maximized_enum */
EIF_INTEGER_32 F114_1872 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_state_maximized_enum", 113, Current, 0, 0, 1905);
	Result = (EIF_INTEGER_32) GDK_WINDOW_STATE_MAXIMIZED;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_scroll_up_enum */
EIF_INTEGER_32 F114_1877 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_scroll_up_enum", 113, Current, 0, 0, 1910);
	Result = (EIF_INTEGER_32) GDK_SCROLL_UP;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_interp_bilinear */
EIF_INTEGER_32 F114_1880 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_interp_bilinear", 113, Current, 0, 0, 1913);
	Result = (EIF_INTEGER_32) GDK_INTERP_BILINEAR;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_interp_nearest */
EIF_INTEGER_32 F114_1882 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_interp_nearest", 113, Current, 0, 0, 1915);
	Result = (EIF_INTEGER_32) GDK_INTERP_NEAREST;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit101 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
