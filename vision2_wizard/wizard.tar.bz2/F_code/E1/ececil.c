#include "eif_eiffel.h"
#include "eif_rout_obj.h"
#include "eaddress.h"
#include "eoffsets.h"

#ifdef __cplusplus
extern "C" {
#endif

	/* DESCRIPTOR_CACHE c_iconv_close */
void _A16_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_p);
}

	/* DESCRIPTOR_CACHE c_iconv_close */
void __A16_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_one_plural_form */
EIF_INTEGER_32 _A25_50_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_one_plural_form */
EIF_INTEGER_32 __A25_50_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one */
EIF_INTEGER_32 _A25_51_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one */
EIF_INTEGER_32 __A25_51_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one_zero */
EIF_INTEGER_32 _A25_52_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one_zero */
EIF_INTEGER_32 __A25_52_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_zero */
EIF_INTEGER_32 _A25_53_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_zero */
EIF_INTEGER_32 __A25_53_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_one_two */
EIF_INTEGER_32 _A25_54_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_one_two */
EIF_INTEGER_32 __A25_54_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_twelve_to_nineteen */
EIF_INTEGER_32 _A25_55_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_twelve_to_nineteen */
EIF_INTEGER_32 __A25_55_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_slavic */
EIF_INTEGER_32 _A25_56_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_slavic */
EIF_INTEGER_32 __A25_56_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_polish */
EIF_INTEGER_32 _A25_57_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_polish */
EIF_INTEGER_32 __A25_57_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_four_plural_forms_special_slovenian */
EIF_INTEGER_32 _A25_58_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_four_plural_forms_special_slovenian */
EIF_INTEGER_32 __A25_58_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* WIZARD_SMART_TEXT_FIELD directory_selected */
void _A113_102 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* WIZARD_SMART_TEXT_FIELD directory_selected */
void __A113_102 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* WIZARD_SMART_TEXT_FIELD file_selected */
void _A113_103 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* WIZARD_SMART_TEXT_FIELD file_selected */
void __A113_103 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* WIZARD_SMART_TEXT_FIELD browse_file */
void _A113_100 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_SMART_TEXT_FIELD browse_file */
void __A113_100 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_SMART_TEXT_FIELD browse_directory */
void _A113_101 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_SMART_TEXT_FIELD browse_directory */
void __A113_101 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_STATE_WINDOW next */
void _A116_82 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_STATE_WINDOW next */
void __A116_82 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_STATE_WINDOW change_entries */
void _A116_106 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_STATE_WINDOW change_entries */
void __A116_106 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_STATE_WINDOW check_wizard_status */
void _A116_89 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_STATE_WINDOW check_wizard_status */
void __A116_89 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_INTERMEDIARY_STATE_WINDOW create_help_context */
EIF_REFERENCE _A117_100 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* WIZARD_INTERMEDIARY_STATE_WINDOW create_help_context */
EIF_REFERENCE __A117_100 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* WIZARD_INITIAL_STATE_WINDOW create_help_context */
EIF_REFERENCE _A118_99 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* WIZARD_INITIAL_STATE_WINDOW create_help_context */
EIF_REFERENCE __A118_99 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* BENCH_WIZARD_PROJECT_GENERATOR inline-agent#1 of existing_target_files */
void _A282_93_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F323_14726)(closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* BENCH_WIZARD_PROJECT_GENERATOR inline-agent#1 of existing_target_files */
void __A282_93_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F323_14726)(closed [1].it_r, op_2, closed [2].it_r);
}

	/* WIZARD_SECOND_STATE change_preview */
void _A294_147 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_SECOND_STATE change_preview */
void __A294_147 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_PROJECT_NAME_AND_LOCATION_STATE on_change_name */
void _A295_149 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_PROJECT_NAME_AND_LOCATION_STATE on_change_name */
void __A295_149 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_WARNING_FILE_PRESENCE inline-agent#1 of display_state_text */
void _A297_151_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F350_14728)(closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* WIZARD_WARNING_FILE_PRESENCE inline-agent#1 of display_state_text */
void __A297_151_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F350_14728)(closed [1].it_r, op_2, closed [2].it_r);
}

	/* MISMATCH_INFORMATION wipe_out */
void A312_98 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F680_5848)(Current);
}

	/* MISMATCH_INFORMATION internal_put */
void A312_162 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER)) F688_5921)(Current, arg1, arg2);
}

	/* MISMATCH_INFORMATION set_string_versions */
void A312_163 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER)) F688_5922)(Current, arg1, arg2);
}

	/* EV_ACCELERATOR_LIST enable_item_parented */
void _A313_166_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_ACCELERATOR_LIST enable_item_parented */
void __A313_166_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_ACCELERATOR_LIST disable_item_parented */
void _A313_167_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_ACCELERATOR_LIST disable_item_parented */
void __A313_167_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_MENU_ITEM_SELECT_ACTION_SEQUENCE wrapper */
void _A318_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* EV_MENU_ITEM_SELECT_ACTION_SEQUENCE wrapper */
void __A318_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* EV_DOCKABLE_SOURCE_ACTION_SEQUENCE wrapper */
void _A321_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* EV_DOCKABLE_SOURCE_ACTION_SEQUENCE wrapper */
void __A321_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* EV_KEY_ACTION_SEQUENCE wrapper */
void _A322_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* EV_KEY_ACTION_SEQUENCE wrapper */
void __A322_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* EV_POINTER_MOTION_ACTION_SEQUENCE wrapper */
void _A326_181_2_3_4_5_6_7_8 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, open [3].it_r8, open [4].it_r8, open [5].it_r8, open [6].it_i4, open [7].it_i4, closed [2].it_r);
}

	/* EV_POINTER_MOTION_ACTION_SEQUENCE wrapper */
void __A326_181_2_3_4_5_6_7_8 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3, EIF_REAL_64 op_4, EIF_REAL_64 op_5, EIF_REAL_64 op_6, EIF_INTEGER_32 op_7, EIF_INTEGER_32 op_8)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5, op_6, op_7, op_8, closed [2].it_r);
}

	/* EV_PND_MOTION_ACTION_SEQUENCE wrapper */
void _A328_181_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, open [3].it_r, closed [2].it_r);
}

	/* EV_PND_MOTION_ACTION_SEQUENCE wrapper */
void __A328_181_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3, EIF_REFERENCE op_4)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, closed [2].it_r);
}

	/* EV_POINTER_BUTTON_ACTION_SEQUENCE wrapper */
void _A329_181_2_3_4_5_6_7_8_9 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, open [3].it_i4, open [4].it_r8, open [5].it_r8, open [6].it_r8, open [7].it_i4, open [8].it_i4, closed [2].it_r);
}

	/* EV_POINTER_BUTTON_ACTION_SEQUENCE wrapper */
void __A329_181_2_3_4_5_6_7_8_9 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3, EIF_INTEGER_32 op_4, EIF_REAL_64 op_5, EIF_REAL_64 op_6, EIF_REAL_64 op_7, EIF_INTEGER_32 op_8, EIF_INTEGER_32 op_9)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5, op_6, op_7, op_8, op_9, closed [2].it_r);
}

	/* EV_NOTIFY_ACTION_SEQUENCE wrapper */
void _A330_180 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_NOTIFY_ACTION_SEQUENCE wrapper */
void __A330_180 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_NOTIFY_ACTION_SEQUENCE call */
void _A330_175 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_NOTIFY_ACTION_SEQUENCE call */
void __A330_175 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_GEOMETRY_ACTION_SEQUENCE wrapper */
void _A331_181_2_3_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, open [3].it_i4, open [4].it_i4, closed [2].it_r);
}

	/* EV_GEOMETRY_ACTION_SEQUENCE wrapper */
void __A331_181_2_3_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3, EIF_INTEGER_32 op_4, EIF_INTEGER_32 op_5)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5, closed [2].it_r);
}

	/* EV_MENU_ITEM_IMP on_activate */
void _A722_278 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_MENU_ITEM_IMP on_activate */
void __A722_278 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* HASH_TABLE [G#1, G#2] put */
void _A1009_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* HASH_TABLE [INTEGER_32, G#2] put */
void _A1148_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,closed [3].it_r);
	RTLR(1,arg1);
	RTLIU(3);
	arg1 = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = closed [2].it_i4;
	f_ptr (closed [1].it_r, arg1, closed [3].it_r);
	RTLE;
}

	/* HASH_TABLE [POINTER, G#2] put */
void _A1250_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p, closed [3].it_r);
}

	/* HASH_TABLE [G#1, INTEGER_32] put */
void _A1366_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg2 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,arg2);
	RTLR(1,closed [2].it_r);
	RTLIU(3);
	arg2 = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg2 = closed [3].it_i4;
	f_ptr (closed [1].it_r, closed [2].it_r, arg2);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, NATURAL_32] put */
void _A1384_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_n4);
}

	/* HASH_TABLE [INTEGER_32, INTEGER_32] put */
void _A1407_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* HASH_TABLE [G#1, G#2] put */
void __A1009_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* HASH_TABLE [INTEGER_32, G#2] put */
void __A1148_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,closed [3].it_r);
	RTLR(1,arg1);
	RTLIU(3);
	arg1 = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = closed [2].it_i4;
	f_ptr (closed [1].it_r, arg1, closed [3].it_r);
	RTLE;
}

	/* HASH_TABLE [POINTER, G#2] put */
void __A1250_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p, closed [3].it_r);
}

	/* HASH_TABLE [G#1, INTEGER_32] put */
void __A1366_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	EIF_REFERENCE arg2 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,arg2);
	RTLR(1,closed [2].it_r);
	RTLIU(3);
	arg2 = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg2 = closed [3].it_i4;
	f_ptr (closed [1].it_r, closed [2].it_r, arg2);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, NATURAL_32] put */
void __A1384_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_NATURAL_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_n4);
}

	/* HASH_TABLE [INTEGER_32, INTEGER_32] put */
void __A1407_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* HASH_TABLE [G#1, G#2] remove */
void _A1009_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [INTEGER_32, G#2] remove */
void _A1148_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [POINTER, G#2] remove */
void _A1250_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [G#1, INTEGER_32] remove */
void _A1366_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = closed [2].it_i4;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, NATURAL_32] remove */
void _A1384_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_n4);
}

	/* HASH_TABLE [INTEGER_32, INTEGER_32] remove */
void _A1407_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* HASH_TABLE [G#1, G#2] remove */
void __A1009_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [INTEGER_32, G#2] remove */
void __A1148_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [POINTER, G#2] remove */
void __A1250_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [G#1, INTEGER_32] remove */
void __A1366_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(1006, 0x00).id, 1006, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = closed [2].it_i4;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, NATURAL_32] remove */
void __A1384_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_n4);
}

	/* HASH_TABLE [INTEGER_32, INTEGER_32] remove */
void __A1407_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL marshal */
void A365_408 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_POINTER, EIF_POINTER)) F937_7406)(Current, arg1, arg2, arg3, arg4);
}

	/* EV_GTK_CALLBACK_MARSHAL on_timeout_intermediary */
void _A365_140 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL on_timeout_intermediary */
void __A365_140 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL gtk_dialog_response_event */
EIF_POINTER _A365_339_3 ( EIF_POINTER(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL gtk_dialog_response_event */
EIF_POINTER __A365_339_3 ( EIF_POINTER(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_mapped_signal_intermediary */
void _A365_326 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_mapped_signal_intermediary */
void __A365_326 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_unmapped_signal_intermediary */
void _A365_327 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_unmapped_signal_intermediary */
void __A365_327 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_hide_signal_intermediary */
void _A365_328 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_hide_signal_intermediary */
void __A365_328 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_size_allocate_event */
void _A365_333_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_size_allocate_event */
void __A365_333_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL on_notebook_page_switch_event */
void _A365_325_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_notebook_page_switch_event */
void __A365_325_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_p, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL on_set_focus_event */
void _A365_334_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_set_focus_event */
void __A365_334_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL mcl_column_resize_callback */
void _A365_315 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL mcl_column_resize_callback */
void __A365_315 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL mcl_column_click_callback */
void _A365_314 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL mcl_column_click_callback */
void __A365_314 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL on_pnd_deferred_item_parent_selection_change */
void _A365_320 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL on_pnd_deferred_item_parent_selection_change */
void __A365_320 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL tree_row_expansion_change_intermediary */
void _A365_317_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_BOOLEAN, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_b, open [1].it_i4, open [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL tree_row_expansion_change_intermediary */
void __A365_317_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_BOOLEAN, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_4, EIF_POINTER op_5)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_b, op_4, op_5);
}

	/* EV_GTK_CALLBACK_MARSHAL on_gauge_value_changed_intermediary */
void _A365_332 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_gauge_value_changed_intermediary */
void __A365_332 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL text_component_change_intermediary */
void _A365_335 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL text_component_change_intermediary */
void __A365_335 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL text_buffer_mark_set_intermediary */
void _A365_316_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, open [1].it_i4, open [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL text_buffer_mark_set_intermediary */
void __A365_316_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_3, EIF_POINTER op_4)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, op_3, op_4);
}

	/* EV_GTK_CALLBACK_MARSHAL text_field_return_intermediary */
void _A365_336 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL text_field_return_intermediary */
void __A365_336 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_combo_box_toggle_button_event */
void _A365_321 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL on_combo_box_toggle_button_event */
void __A365_321 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL button_select_intermediary */
void _A365_337 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL button_select_intermediary */
void __A365_337 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL menu_item_activate_intermediary */
void _A365_338 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL menu_item_activate_intermediary */
void __A365_338 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL new_toolbar_item_select_actions_intermediary */
void _A365_312 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL new_toolbar_item_select_actions_intermediary */
void __A365_312 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL toolbar_item_select_actions_intermediary */
void _A365_322 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL toolbar_item_select_actions_intermediary */
void __A365_322 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL configure_event */
EIF_BOOLEAN _A365_330_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL configure_event */
EIF_BOOLEAN __A365_330_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL scroll_event */
EIF_BOOLEAN _A365_331_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL scroll_event */
EIF_BOOLEAN __A365_331_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL draw_actions_event */
EIF_BOOLEAN _A365_329_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL draw_actions_event */
EIF_BOOLEAN __A365_329_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, op_3);
}

	/* WIZARD_WINDOW cancel_actions */
void _A508_353 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_WINDOW cancel_actions */
void __A508_353 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_WINDOW previous_page */
void _A508_385 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_WINDOW previous_page */
void __A508_385 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_WINDOW next_page */
void _A508_387 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_WINDOW next_page */
void __A508_387 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_WINDOW show_help */
void _A508_354 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_WINDOW show_help */
void __A508_354 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_WINDOW_I connect_accelerator */
void _A649_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_WINDOW_I connect_accelerator */
void __A649_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_WINDOW_I disconnect_accelerator */
void _A649_264_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_WINDOW_I disconnect_accelerator */
void __A649_264_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_DIALOG dialog_key_press_action */
void _A509_314_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_DIALOG dialog_key_press_action */
void __A509_314_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_DIALOG destroy */
void _A509_267 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_DIALOG destroy */
void __A509_267 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_MESSAGE_DIALOG on_button_press */
void _A511_355 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_MESSAGE_DIALOG on_button_press */
void __A511_355 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_MESSAGE_DIALOG on_key_press */
void _A511_356_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_MESSAGE_DIALOG on_key_press */
void __A511_356_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_FONT_IMP update_preferred_faces */
void _A574_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_FONT_IMP update_preferred_faces */
void __A574_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_APPLICATION_I contextual_help */
void _A577_303_2_3_4_5_6_7_8_9 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, open [3].it_i4, open [4].it_r8, open [5].it_r8, open [6].it_r8, open [7].it_i4, open [8].it_i4);
}

	/* EV_APPLICATION_I contextual_help */
void __A577_303_2_3_4_5_6_7_8_9 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3, EIF_INTEGER_32 op_4, EIF_REAL_64 op_5, EIF_REAL_64 op_6, EIF_REAL_64 op_7, EIF_INTEGER_32 op_8, EIF_INTEGER_32 op_9)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5, op_6, op_7, op_8, op_9);
}

	/* EV_APPLICATION_I safe_destroy */
void _A577_68 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_APPLICATION_I safe_destroy */
void __A577_68 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_APPLICATION_I inline-agent#1 of create_target_menu */
EIF_BOOLEAN _A577_308_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1221_14828)(closed [1].it_r, open [1].it_r, open [2].it_r);
}

	/* EV_APPLICATION_I inline-agent#1 of create_target_menu */
EIF_BOOLEAN __A577_308_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1221_14828)(closed [1].it_r, op_2, op_3);
}

	/* EV_APPLICATION_I inline-agent#2 of create_target_menu */
void _A577_309_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1221_14829)(closed [1].it_r, open [1].it_r, open [2].it_r, open [3].it_r);
}

	/* EV_APPLICATION_I inline-agent#2 of create_target_menu */
void __A577_309_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3, EIF_REFERENCE op_4)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1221_14829)(closed [1].it_r, op_2, op_3, op_4);
}

	/* EV_APPLICATION_I help_handler */
void _A577_300 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_APPLICATION_I help_handler */
void __A577_300 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_APPLICATION_I enable_contextual_help */
void _A577_243 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_APPLICATION_I enable_contextual_help */
void __A577_243 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_PND_ACTION_SEQUENCE call */
void _A314_180 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_PND_ACTION_SEQUENCE call */
void __A314_180 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_APPLICATION_IMP on_char_event */
EIF_POINTER _A578_425_2 ( EIF_POINTER(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_p);
}

	/* EV_APPLICATION_IMP on_char_event */
EIF_POINTER __A578_425_2 ( EIF_POINTER(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* EV_ANY_IMP c_object_dispose */
void A583_84 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R9139[Dtype(Current) - 1229])(Current);
}

	/* EV_DOCKABLE_SOURCE_HINT_IMP on_timeout */
void _A586_447 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_DOCKABLE_SOURCE_HINT_IMP on_timeout */
void __A586_447 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_DOCKABLE_SOURCE_I close_dockable_dialog */
void _A595_100 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_DOCKABLE_SOURCE_I close_dockable_dialog */
void __A595_100 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_PICK_AND_DROPABLE_IMP inline-agent#1 of start_transport */
void _A628_232 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) F1276_14837)(closed [1].it_r, closed [2].it_r, closed [3].it_i4, closed [4].it_i4, closed [5].it_i4, closed [6].it_i4);
}

	/* EV_PICK_AND_DROPABLE_IMP inline-agent#1 of start_transport */
void __A628_232 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) F1276_14837)(closed [1].it_r, closed [2].it_r, closed [3].it_i4, closed [4].it_i4, closed [5].it_i4, closed [6].it_i4);
}

	/* EV_MENU_IMP c_gtk_menu_popup_at_pointer */
void _A726_326 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p, closed [3].it_i4, closed [4].it_i4, closed [5].it_i4, closed [6].it_n4);
}

	/* EV_MENU_IMP c_gtk_menu_popup_at_pointer */
void __A726_326 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_NATURAL_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p, closed [3].it_i4, closed [4].it_i4, closed [5].it_i4, closed [6].it_n4);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_action */
EIF_REFERENCE _A763_113_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_action */
EIF_REFERENCE __A763_113_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_padded_action */
EIF_REFERENCE _A763_114_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_padded_action */
EIF_REFERENCE __A763_114_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER month_action */
EIF_REFERENCE _A763_120_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_action */
EIF_REFERENCE __A763_120_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_name_action */
EIF_REFERENCE _A763_116_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_name_action */
EIF_REFERENCE __A763_116_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_sunday_as_first_action */
EIF_REFERENCE _A763_126_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_sunday_as_first_action */
EIF_REFERENCE __A763_126_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_4_action */
EIF_REFERENCE _A763_132_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_4_action */
EIF_REFERENCE __A763_132_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_day_name_action */
EIF_REFERENCE _A763_115_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_day_name_action */
EIF_REFERENCE __A763_115_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_year_action */
EIF_REFERENCE _A763_117_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_year_action */
EIF_REFERENCE __A763_117_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_action */
EIF_REFERENCE _A763_118_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_action */
EIF_REFERENCE __A763_118_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_0_action */
EIF_REFERENCE _A763_119_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_0_action */
EIF_REFERENCE __A763_119_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER month_padded_action */
EIF_REFERENCE _A763_121_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_padded_action */
EIF_REFERENCE __A763_121_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_month_name_action */
EIF_REFERENCE _A763_122_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_month_name_action */
EIF_REFERENCE __A763_122_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_name_action */
EIF_REFERENCE _A763_123_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_name_action */
EIF_REFERENCE __A763_123_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER century_number_action */
EIF_REFERENCE _A763_124_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER century_number_action */
EIF_REFERENCE __A763_124_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_with_century_action */
EIF_REFERENCE _A763_128_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_with_century_action */
EIF_REFERENCE __A763_128_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_without_century_action */
EIF_REFERENCE _A763_129_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_without_century_action */
EIF_REFERENCE __A763_129_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER week_number_iso_action */
EIF_REFERENCE _A763_125_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_iso_action */
EIF_REFERENCE __A763_125_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER week_number_monday_as_first_action */
EIF_REFERENCE _A763_127_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_monday_as_first_action */
EIF_REFERENCE __A763_127_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_1_action */
EIF_REFERENCE _A763_130_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_1_action */
EIF_REFERENCE __A763_130_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_2_action */
EIF_REFERENCE _A763_131_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_2_action */
EIF_REFERENCE __A763_131_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_padded_action */
EIF_REFERENCE _A763_102_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_padded_action */
EIF_REFERENCE __A763_102_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_action */
EIF_REFERENCE _A763_103_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_action */
EIF_REFERENCE __A763_103_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_24_action */
EIF_REFERENCE _A763_104_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_24_action */
EIF_REFERENCE __A763_104_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER minutes_action */
EIF_REFERENCE _A763_106_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER minutes_action */
EIF_REFERENCE __A763_106_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER minutes_padded_action */
EIF_REFERENCE _A763_107_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER minutes_padded_action */
EIF_REFERENCE __A763_107_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER seconds_action */
EIF_REFERENCE _A763_108_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER seconds_action */
EIF_REFERENCE __A763_108_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER seconds_padded_action */
EIF_REFERENCE _A763_109_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER seconds_padded_action */
EIF_REFERENCE __A763_109_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_1_action */
EIF_REFERENCE _A763_110_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_1_action */
EIF_REFERENCE __A763_110_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_lowercase_action */
EIF_REFERENCE _A763_111_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_lowercase_action */
EIF_REFERENCE __A763_111_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_uppercase_action */
EIF_REFERENCE _A763_112_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_uppercase_action */
EIF_REFERENCE __A763_112_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* EIFFEL_ENV safe_create_dir */
void _A773_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EIFFEL_ENV safe_create_dir */
void __A773_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}


#ifdef __cplusplus
}
#endif
