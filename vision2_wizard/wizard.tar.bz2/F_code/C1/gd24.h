
#ifndef _C1_gd24_
#define _C1_gd24_

#ifdef __cplusplus
extern "C" {
#endif

extern void F25_415(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32*, EIF_INTEGER_32*);
extern EIF_POINTER F25_418(EIF_REFERENCE);
extern EIF_INTEGER_32 F25_420(EIF_REFERENCE);
extern void EIF_Minit24(void);

#ifdef __cplusplus
}
#endif

#endif
