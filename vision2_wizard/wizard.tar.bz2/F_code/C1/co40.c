/*
 * Code for class CODE_PAGE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co40.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CODE_PAGE_CONSTANTS}.utf7 */

EIF_REFERENCE F41_703 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (703,RTMS_EX_H("UTF-7",5,1414538039));
}

/* {CODE_PAGE_CONSTANTS}.utf8 */

EIF_REFERENCE F41_704 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (704,RTMS_EX_H("UTF-8",5,1414538040));
}

/* {CODE_PAGE_CONSTANTS}.utf16 */

EIF_REFERENCE F41_705 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (705,RTMS_EX_H("UTF-16",6,1345128758));
}

/* {CODE_PAGE_CONSTANTS}.utf32 */

EIF_REFERENCE F41_706 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (706,RTMS_EX_H("UTF-32",6,1345129266));
}

/* {CODE_PAGE_CONSTANTS}.utf16_le */

EIF_REFERENCE F41_707 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (707,RTMS_EX_H("UTF-16LE",8,312185413));
}

/* {CODE_PAGE_CONSTANTS}.utf32_le */

EIF_REFERENCE F41_708 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (708,RTMS_EX_H("UTF-32LE",8,345477701));
}

/* {CODE_PAGE_CONSTANTS}.utf16_be */

EIF_REFERENCE F41_709 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (709,RTMS_EX_H("UTF-16BE",8,312182853));
}

/* {CODE_PAGE_CONSTANTS}.utf32_be */

EIF_REFERENCE F41_710 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (710,RTMS_EX_H("UTF-32BE",8,345475141));
}

void EIF_Minit40 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
