
#ifndef _C1_gt12_
#define _C1_gt12_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F12_122(EIF_REFERENCE);
extern EIF_POINTER F12_129(EIF_REFERENCE);
extern EIF_POINTER F12_130(EIF_REFERENCE);
extern void EIF_Minit12(void);

#ifdef __cplusplus
}
#endif

#endif
