/*
 * Code for class GTK_ORIENTATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt10.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F10_92
static EIF_NATURAL_8 inline_F10_92 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F10_92
#endif
#ifndef INLINE_F10_93
static EIF_NATURAL_8 inline_F10_93 (void)
{
	return GTK_ORIENTATION_VERTICAL
	;
}
#define INLINE_F10_93
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_ORIENTATION}.gtk_orientation_horizontal */
EIF_NATURAL_8 F10_92 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_orientation_horizontal", 9, Current, 0, 0, 89);
	Result = inline_F10_92 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK_ORIENTATION}.gtk_orientation_vertical */
EIF_NATURAL_8 F10_93 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_orientation_vertical", 9, Current, 0, 0, 88);
	Result = inline_F10_93 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit10 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
