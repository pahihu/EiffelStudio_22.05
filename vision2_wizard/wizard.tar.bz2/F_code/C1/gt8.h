
#ifndef _C1_gt8_
#define _C1_gt8_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F8_74(EIF_REFERENCE);
extern EIF_BOOLEAN F8_75(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32, EIF_POINTER*);
extern void EIF_Minit8(void);

#ifdef __cplusplus
}
#endif

#endif
