
#ifndef _C1_is27_
#define _C1_is27_

#ifdef __cplusplus
extern "C" {
#endif

extern void F28_455(EIF_REFERENCE);
extern EIF_NATURAL_16 F28_457(EIF_REFERENCE, EIF_POINTER);
extern void F28_458(EIF_REFERENCE, EIF_NATURAL_16);
extern void EIF_Minit27(void);

#ifdef __cplusplus
}
#endif

#endif
