/*
 * Code for class EV_STOCK_PIXMAPS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev18.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STOCK_PIXMAPS}.information_pixmap */
static EIF_REFERENCE F19_210_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("information_pixmap", 18, Current, 0, 0, 250);
	RTGC;
	RTOSP (210);
#define Result RTOSR(210)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = F321_4860(RTCV(RTOSCF(230,F19_230, (Current))));
	RTOSE (210);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F19_210 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(210,F19_210_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.error_pixmap */
static EIF_REFERENCE F19_211_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("error_pixmap", 18, Current, 0, 0, 251);
	RTGC;
	RTOSP (211);
#define Result RTOSR(211)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = F321_4861(RTCV(RTOSCF(230,F19_230, (Current))));
	RTOSE (211);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F19_211 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(211,F19_211_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.default_window_icon */
static EIF_REFERENCE F19_214_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_window_icon", 18, Current, 0, 0, 254);
	RTGC;
	RTOSP (214);
#define Result RTOSR(214)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = F321_4868(RTCV(RTOSCF(230,F19_230, (Current))));
	RTOSE (214);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F19_214 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(214,F19_214_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.standard_cursor */
static EIF_REFERENCE F19_216_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("standard_cursor", 18, Current, 0, 0, 256);
	RTGC;
	RTOSP (216);
#define Result RTOSR(216)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1102, 0x00).id, 1102, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1103_9575(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (216);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F19_216 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(216,F19_216_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.help_cursor */
static EIF_REFERENCE F19_218_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("help_cursor", 18, Current, 0, 0, 233);
	RTGC;
	RTOSP (218);
#define Result RTOSR(218)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1102, 0x00).id, 1102, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1103_9575(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (218);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F19_218 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(218,F19_218_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.ibeam_cursor */
static EIF_REFERENCE F19_219_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("ibeam_cursor", 18, Current, 0, 0, 234);
	RTGC;
	RTOSP (219);
#define Result RTOSR(219)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1102, 0x00).id, 1102, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1103_9575(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (219);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F19_219 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(219,F19_219_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.no_cursor */
static EIF_REFERENCE F19_220_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("no_cursor", 18, Current, 0, 0, 235);
	RTGC;
	RTOSP (220);
#define Result RTOSR(220)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1102, 0x00).id, 1102, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1103_9575(RTCW(tr1), ((EIF_INTEGER_32) 6L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (220);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F19_220 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(220,F19_220_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.sizeall_cursor */
static EIF_REFERENCE F19_221_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("sizeall_cursor", 18, Current, 0, 0, 236);
	RTGC;
	RTOSP (221);
#define Result RTOSR(221)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1102, 0x00).id, 1102, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1103_9575(RTCW(tr1), ((EIF_INTEGER_32) 7L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (221);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F19_221 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(221,F19_221_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.implementation */
static EIF_REFERENCE F19_230_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("implementation", 18, Current, 0, 0, 245);
	RTGC;
	RTOSP (230);
#define Result RTOSR(230)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(320, 0x00).id, 320, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (230);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F19_230 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(230,F19_230_body,(Current));
}

void EIF_Minit18 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
