
#ifndef _C1_gt14_
#define _C1_gt14_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F14_136(EIF_REFERENCE);
extern EIF_INTEGER_32 F14_137(EIF_REFERENCE);
extern EIF_INTEGER_32 F14_138(EIF_REFERENCE);
extern void EIF_Minit14(void);

#ifdef __cplusplus
}
#endif

#endif
