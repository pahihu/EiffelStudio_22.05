/*
 * Code for class GTK_PROPERTIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt12.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F12_122
static EIF_POINTER inline_F12_122 (void)
{
	static char *v = "justify";
return (EIF_POINTER) v;
	;
}
#define INLINE_F12_122
#endif
#ifndef INLINE_F12_129
static EIF_POINTER inline_F12_129 (void)
{
	static char *v = "gtk-menu-bar-accel";
return (EIF_POINTER) v;
	;
}
#define INLINE_F12_129
#endif
#ifndef INLINE_F12_130
static EIF_POINTER inline_F12_130 (void)
{
	static char *v = "gtk-menu-images";
return (EIF_POINTER) v;
	;
}
#define INLINE_F12_130
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_PROPERTIES}.justify */
EIF_POINTER F12_122 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("justify", 11, Current, 0, 0, 119);
	Result = inline_F12_122 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK_PROPERTIES}.gtk_menu_bar_accel */
EIF_POINTER F12_129 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_menu_bar_accel", 11, Current, 0, 0, 126);
	Result = inline_F12_129 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK_PROPERTIES}.gtk_menu_icons */
EIF_POINTER F12_130 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_menu_icons", 11, Current, 0, 0, 127);
	Result = inline_F12_130 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit12 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
