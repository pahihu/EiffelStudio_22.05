
#ifndef _C1_i137_
#define _C1_i137_

#ifdef __cplusplus
extern "C" {
#endif

extern void F38_688(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit37(void);
extern void F272_4101(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
