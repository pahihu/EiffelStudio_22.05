
#ifndef _C1_i138_
#define _C1_i138_

#ifdef __cplusplus
extern "C" {
#endif

extern void F39_695(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit38(void);
extern void F137_2932(EIF_REFERENCE, EIF_REFERENCE);
extern long O3047[];
extern long O3048[];

#ifdef __cplusplus
}
#endif

#endif
