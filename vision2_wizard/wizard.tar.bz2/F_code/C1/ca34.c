/*
 * Code for class CAIRO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ca34.h"
#include <ev_gtk.h>
#include <cairo.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F35_588
static EIF_NATURAL_32 inline_F35_588 (EIF_POINTER arg1)
{
	return (EIF_NATURAL_32) (cairo_get_reference_count((cairo_t*) arg1))
	;
}
#define INLINE_F35_588
#endif
#ifndef INLINE_F35_594
static void inline_F35_594 (EIF_POINTER arg1)
{
	cairo_surface_destroy((cairo_surface_t*) arg1)
	;
}
#define INLINE_F35_594
#endif
#ifndef INLINE_F35_637
static void inline_F35_637 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	double len = 2.0;
if (arg2) {
	cairo_set_dash ((cairo_t *) arg1, &len, 1, 0.0);
} else {
	cairo_set_dash ((cairo_t *) arg1, NULL, 0, 0.0);
}
	;
}
#define INLINE_F35_637
#endif
#ifndef INLINE_F35_652
static void inline_F35_652 (EIF_POINTER arg1)
{
	cairo_paint ((cairo_t*)arg1)
	;
}
#define INLINE_F35_652
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CAIRO}.operator_source */
EIF_INTEGER_8 F35_571 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_source", 34, Current, 0, 0, 641);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_SOURCE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.operator_over */
EIF_INTEGER_8 F35_572 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_over", 34, Current, 0, 0, 642);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_OVER;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.operator_atop */
EIF_INTEGER_8 F35_577 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_atop", 34, Current, 0, 0, 647);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_ATOP;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.operator_difference */
EIF_INTEGER_8 F35_583 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_difference", 34, Current, 0, 0, 653);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_DIFFERENCE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.operator_exclusion */
EIF_INTEGER_8 F35_584 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_exclusion", 34, Current, 0, 0, 654);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_EXCLUSION;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.operator_multiply */
EIF_INTEGER_8 F35_585 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_multiply", 34, Current, 0, 0, 655);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_MULTIPLY;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.create_context */
EIF_POINTER F35_586 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("create_context", 34, Current, 0, 1, 656);Result = (EIF_POINTER) cairo_create((cairo_surface_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.get_reference_count */
EIF_NATURAL_32 F35_588 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_reference_count", 34, Current, 0, 1, 658);
	Result = inline_F35_588 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.destroy */
void F35_589 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("destroy", 34, Current, 0, 1, 659);cairo_destroy((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_source_surface */
void F35_593 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_source_surface", 34, Current, 0, 4, 663);cairo_set_source_surface((cairo_t*) arg1, (cairo_surface_t*) arg2, (double) arg3, (double) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.surface_destroy */
void F35_594 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("surface_destroy", 34, Current, 0, 1, 664);
	inline_F35_594 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.surface_flush */
void F35_597 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("surface_flush", 34, Current, 0, 1, 667);cairo_surface_flush((cairo_surface_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.image_surface_create */
EIF_POINTER F35_611 (EIF_REFERENCE Current, EIF_INTEGER_8 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("image_surface_create", 34, Current, 0, 3, 681);Result = (EIF_POINTER) cairo_image_surface_create((cairo_format_t) arg1, (int) arg2, (int) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.image_surface_get_width */
EIF_INTEGER_32 F35_615 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("image_surface_get_width", 34, Current, 0, 1, 685);Result = (EIF_INTEGER_32) cairo_image_surface_get_width((cairo_surface_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.image_surface_get_height */
EIF_INTEGER_32 F35_616 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("image_surface_get_height", 34, Current, 0, 1, 686);Result = (EIF_INTEGER_32) cairo_image_surface_get_height((cairo_surface_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.clip_extents */
void F35_619 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64* arg2, EIF_REAL_64* arg3, EIF_REAL_64* arg4, EIF_REAL_64* arg5)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("clip_extents", 34, Current, 0, 5, 689);cairo_clip_extents((cairo_t*) arg1, (double*) arg2, (double*) arg3, (double*) arg4, (double*) arg5);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.save */
void F35_629 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("save", 34, Current, 0, 1, 699);cairo_save((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.restore */
void F35_630 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("restore", 34, Current, 0, 1, 700);cairo_restore((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_operator */
void F35_635 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_8 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_operator", 34, Current, 0, 2, 705);cairo_set_operator((cairo_t*) arg1, (cairo_operator_t) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_antialias */
void F35_636 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_8 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_antialias", 34, Current, 0, 2, 706);cairo_set_antialias((cairo_t*) arg1, (cairo_antialias_t) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_dashed_line_style */
void F35_637 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_dashed_line_style", 34, Current, 0, 2, 707);
	inline_F35_637 ((EIF_POINTER) arg1, (EIF_BOOLEAN) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.fill */
void F35_640 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("fill", 34, Current, 0, 1, 710);
	RTHOOK(1);
	cairo_fill((cairo_t*) arg1);
	RTHOOK(2);
	RTEE;
}

/* {CAIRO}.cairo_fill */
void F35_641 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("cairo_fill", 34, Current, 0, 1, 711);cairo_fill((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.scale */
void F35_650 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("scale", 34, Current, 0, 3, 720);cairo_scale((cairo_t*) arg1, (double) arg2, (double) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.paint */
void F35_652 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("paint", 34, Current, 0, 1, 597);
	inline_F35_652 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.stroke */
void F35_653 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("stroke", 34, Current, 0, 1, 598);cairo_stroke((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.stroke_preserve */
void F35_654 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("stroke_preserve", 34, Current, 0, 1, 599);cairo_stroke_preserve((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.move_to */
void F35_655 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("move_to", 34, Current, 0, 3, 600);cairo_move_to((cairo_t*) arg1, (double) arg2, (double) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.line_to */
void F35_656 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("line_to", 34, Current, 0, 3, 601);cairo_line_to((cairo_t*) arg1, (double) arg2, (double) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.rectangle */
void F35_657 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rectangle", 34, Current, 0, 5, 602);cairo_rectangle((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4, (double) arg5);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_source_rgba */
void F35_658 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_source_rgba", 34, Current, 0, 5, 603);cairo_set_source_rgba((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4, (double) arg5);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_source_rgb */
void F35_659 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_source_rgb", 34, Current, 0, 4, 604);cairo_set_source_rgb((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.arc_negative */
void F35_662 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("arc_negative", 34, Current, 0, 6, 607);cairo_arc_negative((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4, (double) arg5, (double) arg6);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_line_width */
void F35_663 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_line_width", 34, Current, 0, 2, 608);cairo_set_line_width((cairo_t*) arg1, (double) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_line_cap */
void F35_664 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_8 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_line_cap", 34, Current, 0, 2, 609);cairo_set_line_cap((cairo_t*) arg1, (cairo_line_cap_t) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.close_path */
void F35_669 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("close_path", 34, Current, 0, 1, 614);cairo_close_path((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.cairo_content_color_alpha */
EIF_INTEGER_32 F35_678 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("cairo_content_color_alpha", 34, Current, 0, 0, 623);
	Result = (EIF_INTEGER_32) CAIRO_CONTENT_COLOR_ALPHA;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit34 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
