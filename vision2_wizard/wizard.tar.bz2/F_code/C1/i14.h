
#ifndef _C1_i14_
#define _C1_i14_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F4_46(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F4_50(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_CHARACTER_8);
extern void EIF_Minit4(void);
extern void F1063_9139(EIF_REFERENCE, EIF_REFERENCE);
extern void F1061_9064(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F1063_9170(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
