/*
 * Code for class EV_GTK_EVENT_STRINGS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev33.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_EVENT_STRINGS}.set_focus_event_name */

EIF_REFERENCE F34_507 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (507,RTMS_EX_H("set-focus",9,577130099));
}

/* {EV_GTK_EVENT_STRINGS}.configure_event_name */

EIF_REFERENCE F34_508 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (508,RTMS_EX_H("configure-event",15,1205453684));
}

/* {EV_GTK_EVENT_STRINGS}.map_event_name */

EIF_REFERENCE F34_511 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (511,RTMS_EX_H("map-event",9,474090100));
}

/* {EV_GTK_EVENT_STRINGS}.unmap_event_name */

EIF_REFERENCE F34_512 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (512,RTMS_EX_H("unmap-event",11,77806708));
}

/* {EV_GTK_EVENT_STRINGS}.hide_signal_name */

EIF_REFERENCE F34_513 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (513,RTMS_EX_H("hide",4,1751737445));
}

/* {EV_GTK_EVENT_STRINGS}.size_allocate_event_name */

EIF_REFERENCE F34_517 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (517,RTMS_EX_H("size-allocate",13,769151077));
}

/* {EV_GTK_EVENT_STRINGS}.clicked_event_name */

EIF_REFERENCE F34_520 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (520,RTMS_EX_H("clicked",7,169941860));
}

/* {EV_GTK_EVENT_STRINGS}.draw_event_name */

EIF_REFERENCE F34_522 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (522,RTMS_EX_H("draw",4,1685217655));
}

/* {EV_GTK_EVENT_STRINGS}.commit_event_name */

EIF_REFERENCE F34_523 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (523,RTMS_EX_H("commit",6,2031381364));
}

/* {EV_GTK_EVENT_STRINGS}.changed_event_name */

EIF_REFERENCE F34_524 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (524,RTMS_EX_H("changed",7,346303332));
}

/* {EV_GTK_EVENT_STRINGS}.response_event_name */

EIF_REFERENCE F34_528 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (528,RTMS_EX_H("response",8,1418183525));
}

/* {EV_GTK_EVENT_STRINGS}.scroll_event_name */

EIF_REFERENCE F34_534 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (534,RTMS_EX_H("scroll-event",12,2102824820));
}

/* {EV_GTK_EVENT_STRINGS}.commit_event_string */
static EIF_REFERENCE F34_553_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("commit_event_string", 33, Current, 0, 0, 596);
	RTGC;
	RTOSP (553);
#define Result RTOSR(553)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr2 = RTOSCF(523,F34_523, (Current));
	F923_6661(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (553);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F34_553 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(553,F34_553_body,(Current));
}

void EIF_Minit33 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
