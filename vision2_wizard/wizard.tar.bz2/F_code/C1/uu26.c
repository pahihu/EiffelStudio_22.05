/*
 * Code for class UUID_GENERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uu26.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UUID_GENERATOR}.generate_uuid */
EIF_REFERENCE F27_448 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("generate_uuid", 26, Current, 0, 0, 474);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(938, 0x00).id, 938, _OBJSIZ_0_0_3_1_0_0_1_0_);
	tr1 = RTOSCF(451,F27_451, (Current));
	tr2 = RTOSCF(450,F27_450, (Current));
	tr1 = F27_449(Current, tr1, tr2);
	F939_7423(RTCW(Result), tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {UUID_GENERATOR}.segments */
EIF_REFERENCE F27_449 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("segments", 26, Current, 2, 2, 475);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {602,985,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 602, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F603_5383(RTCW(Result), ((EIF_NATURAL_8) 0U), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 16L));
	RTHOOK(2);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O3731[Dtype(arg1)-211]);
	RTHOOK(3);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 16L))) break;
		RTHOOK(5);
		if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 2147483647L))) {
			RTHOOK(6);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			RTHOOK(7);
			ti4_1 = F27_452(Current);
			F746_6155(RTCW(arg2), ti4_1);
		} else {
			RTHOOK(8);
			loc2++;
		}
		RTHOOK(9);
		ti4_1 = F746_6163(RTCW(arg2), loc2);
		tu1_1 = (EIF_NATURAL_8) ti4_1;
		F603_5407(RTCW(Result), tu1_1, loc1);
		RTHOOK(10);
		loc1++;
	}
	RTHOOK(11);
	F213_3852(RTCW(arg1), loc2);
	RTHOOK(12);
	tu1_1 = F603_5388(RTCW(Result), ((EIF_INTEGER_32) 7L));
	tu1_1 = eif_bit_and(tu1_1,(EIF_NATURAL_8) ((EIF_INTEGER_32) 15L));
	tu1_1 = eif_bit_or(tu1_1,(EIF_NATURAL_8) ((EIF_INTEGER_32) 64L));
	F603_5407(RTCW(Result), tu1_1, ((EIF_INTEGER_32) 7L));
	RTHOOK(13);
	tu1_1 = F603_5388(RTCW(Result), ((EIF_INTEGER_32) 9L));
	tu1_1 = eif_bit_and(tu1_1,(EIF_NATURAL_8) ((EIF_INTEGER_32) 63L));
	tu1_1 = eif_bit_or(tu1_1,(EIF_NATURAL_8) ((EIF_INTEGER_32) 128L));
	F603_5407(RTCW(Result), tu1_1, ((EIF_INTEGER_32) 9L));
	RTHOOK(14);
	RTLE;
	RTEE;
	return Result;
}

/* {UUID_GENERATOR}.rand */
static EIF_REFERENCE F27_450_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("rand", 26, Current, 0, 0, 476);
	RTGC;
	RTOSP (450);
#define Result RTOSR(450)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(745, 0x00).id, 745, _OBJSIZ_0_1_0_4_0_0_0_0_);
	ti4_1 = F27_452(Current);
	F746_6155(RTCW(tr1), ti4_1);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (450);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F27_450 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(450,F27_450_body,(Current));
}

/* {UUID_GENERATOR}.rand_count */
static EIF_REFERENCE F27_451_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("rand_count", 26, Current, 0, 0, 477);
	RTGC;
	RTOSP (451);
#define Result RTOSR(451)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {212,1006,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 212, _OBJSIZ_0_0_0_1_0_0_0_0_);
	}
	F213_3852(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (451);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F27_451 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(451,F27_451_body,(Current));
}

/* {UUID_GENERATOR}.seed */
EIF_INTEGER_32 F27_452 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_64 loc1 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_NATURAL_64 tu8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("seed", 26, Current, 2, 0, 478);
	RTGC;
	RTHOOK(1);
	loc2 = RTLNS(eif_new_type(14, 0x00).id, 14, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F15_140(RTCW(loc2));
	RTHOOK(2);
	ti4_1 = F15_144(RTCW(loc2));
	loc1 = (EIF_NATURAL_64) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1970L));
	loc1 = (EIF_NATURAL_64) (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (loc1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 12L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 30L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 24L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	RTHOOK(3);
	ti4_1 = F15_145(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 30L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 24L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	RTHOOK(4);
	ti4_1 = F15_146(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 24L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	RTHOOK(5);
	ti4_1 = F15_147(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	RTHOOK(6);
	ti4_1 = F15_148(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) ((EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	RTHOOK(7);
	ti4_1 = F15_149(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	RTHOOK(8);
	ti4_1 = F15_150(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += tu8_1;
	RTHOOK(9);
	tu8_1 = eif_bit_shift_right(loc1,((EIF_INTEGER_32) 32L));
	tu8_1 = eif_bit_xor(tu8_1,loc1);
	ti4_1 = (EIF_INTEGER_32) tu8_1;
	Result = eif_bit_and(ti4_1,((EIF_INTEGER_32) 2147483647L));
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit26 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
