/*
 * Code for class EV_STOCK_COLORS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev17.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STOCK_COLORS}.white */
static EIF_REFERENCE F17_178_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("white", 16, Current, 0, 0, 176);
	RTGC;
	RTOSP (178);
#define Result RTOSR(178)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1095, 0x00).id, 1095, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	tr4_2 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	tr4_3 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	F1096_9422(RTCW(tr1), tr4_1, tr4_2, tr4_3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (178);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F17_178 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(178,F17_178_body,(Current));
}

/* {EV_STOCK_COLORS}.black */
static EIF_REFERENCE F17_179_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("black", 16, Current, 0, 0, 177);
	RTGC;
	RTOSP (179);
#define Result RTOSR(179)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1095, 0x00).id, 1095, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	tr4_2 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	tr4_3 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	F1096_9422(RTCW(tr1), tr4_1, tr4_2, tr4_3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (179);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F17_179 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(179,F17_179_body,(Current));
}

/* {EV_STOCK_COLORS}.gray */
static EIF_REFERENCE F17_181_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("gray", 16, Current, 0, 0, 179);
	RTGC;
	RTOSP (181);
#define Result RTOSR(181)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1095, 0x00).id, 1095, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1096_9422(RTCW(tr1), (EIF_REAL_32) 0.7, (EIF_REAL_32) 0.7, (EIF_REAL_32) 0.7);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (181);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F17_181 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(181,F17_181_body,(Current));
}

/* {EV_STOCK_COLORS}.default_background_color */
EIF_REFERENCE F17_202 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("default_background_color", 16, Current, 0, 0, 200);
	RTGC;
	RTHOOK(1);
	Result = F9_80(RTCV(RTOSCF(205,F17_205, (Current))));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_STOCK_COLORS}.default_foreground_color */
EIF_REFERENCE F17_203 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("default_foreground_color", 16, Current, 0, 0, 201);
	RTGC;
	RTHOOK(1);
	Result = F9_83(RTCV(RTOSCF(205,F17_205, (Current))));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_STOCK_COLORS}.implementation */
static EIF_REFERENCE F17_205_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("implementation", 16, Current, 0, 0, 203);
	RTGC;
	RTOSP (205);
#define Result RTOSR(205)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(8, 0x00).id, 8, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (205);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F17_205 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(205,F17_205_body,(Current));
}

void EIF_Minit17 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
