/*
 * Code for class reference FILE_UTILITIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fi29.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FILE_UTILITIES}.directory_path_exists */
EIF_BOOLEAN F29_464 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("directory_path_exists", 28, Current, 0, 1, 518);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tb1 = F940_7452(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTLNS(eif_new_type(923, 0x00).id, 923, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F924_6671(RTCW(tr1), arg1);
		tb1 = F924_6694(RTCW(tr1));
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE_UTILITIES}.directory_exists */
EIF_BOOLEAN F29_465 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("directory_exists", 28, Current, 0, 1, 502);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7289[Dtype(RTCW(arg1))-1057])(arg1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTLNS(eif_new_type(923, 0x00).id, 923, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F924_6669(RTCW(tr1), arg1);
		tb1 = F924_6694(RTCW(tr1));
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE_UTILITIES}.create_directory */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F29_469 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	RTLD;
	RTXD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Current);
	RTLR(4,saved_except);
	RTLIU(5);
	RTXSLS;
	
	RTEAA("create_directory", 28, Current, 2, 1, 506);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(923, 0x00).id, 923, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F924_6669(RTCW(tr1), arg1);
		loc2 = (EIF_REFERENCE) tr1;
		RTHOOK(3);
		tb1 = F924_6694(RTCW(loc2));
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(4);
			F924_6674(RTCW(loc2));
		}
	}
	RTE_E
	RTXSC;
	RTHOOK(5);
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(6);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(7);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {FILE_UTILITIES}.copy_file_path */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F29_471 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	RTLD;
	RTXD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,Current);
	RTLR(6,saved_except);
	RTLIU(7);
	RTXSLS;
	
	RTEAA("copy_file_path", 28, Current, 3, 2, 508);
	RTGC;
	RTE_T
	RTHOOK(1);
	if (loc3) {
		RTHOOK(2);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb2 = F929_7026(RTCW(loc1));
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(3);
			F929_7053(RTCW(loc1));
		}
		RTHOOK(4);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tb2 = F929_7027(RTCW(loc2));
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(5);
			F929_7053(RTCW(loc2));
		}
	} else {
		RTHOOK(6);
		tr1 = RTLNS(eif_new_type(929, 0x00).id, 929, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F929_6967(RTCW(tr1), arg1);
		loc1 = (EIF_REFERENCE) tr1;
		RTHOOK(7);
		F929_7036(RTCW(loc1));
		RTHOOK(8);
		tr1 = RTLNS(eif_new_type(929, 0x00).id, 929, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F929_6967(RTCW(tr1), arg2);
		loc2 = (EIF_REFERENCE) tr1;
		RTHOOK(9);
		F929_7037(RTCW(loc2));
		RTHOOK(10);
		F929_7123(RTCW(loc1), loc2);
		RTHOOK(11);
		F929_7053(RTCW(loc1));
		RTHOOK(12);
		F929_7053(RTCW(loc2));
	}
	RTE_E
	RTXSC;
	RTHOOK(13);
	if ((EIF_BOOLEAN) !loc3) {
		RTHOOK(14);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(15);
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTHOOK(16);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {FILE_UTILITIES}.file_path_exists */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_BOOLEAN F29_475 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_VOLATILE EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	RTXD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,saved_except);
	RTLIU(5);
	RTXSLS;
	
	RTEAA("file_path_exists", 28, Current, 2, 1, 512);
	RTGC;
	RTE_T
	RTHOOK(1);
	tb1 = '\0';
	tb2 = F940_7452(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = (EIF_BOOLEAN) !loc2;
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(929, 0x00).id, 929, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F929_6967(RTCW(tr1), arg1);
		loc1 = (EIF_REFERENCE) tr1;
		RTHOOK(3);
		Result = '\0';
		tb1 = F929_7001(RTCW(loc1));
		if (tb1) {
			tb1 = F929_7008(RTCW(loc1));
			Result = tb1;
		}
	}
	RTE_E
	RTXSC;
	RTHOOK(4);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(5);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(6);
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

void EIF_Minit29 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
