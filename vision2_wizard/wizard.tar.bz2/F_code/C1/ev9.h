
#ifndef _C1_ev9_
#define _C1_ev9_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F9_80(EIF_REFERENCE);
extern EIF_REFERENCE F9_83(EIF_REFERENCE);
extern EIF_REFERENCE F9_87(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit9(void);
extern void F1096_9422(EIF_REFERENCE, EIF_REAL_32, EIF_REAL_32, EIF_REAL_32);
extern void F923_6661(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
