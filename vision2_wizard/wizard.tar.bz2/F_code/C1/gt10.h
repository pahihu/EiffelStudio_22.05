
#ifndef _C1_gt10_
#define _C1_gt10_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F10_92(EIF_REFERENCE);
extern EIF_NATURAL_8 F10_93(EIF_REFERENCE);
extern void EIF_Minit10(void);

#ifdef __cplusplus
}
#endif

#endif
