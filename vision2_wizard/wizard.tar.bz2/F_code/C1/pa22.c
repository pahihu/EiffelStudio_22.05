/*
 * Code for class PANGO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pa22.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F23_375
static EIF_POINTER inline_F23_375 (void)
{
	return pango_attr_list_new();
	;
}
#define INLINE_F23_375
#endif
#ifndef INLINE_F23_378
static EIF_POINTER inline_F23_378 (EIF_POINTER arg1)
{
	return pango_attr_font_desc_new ((const PangoFontDescription *)arg1);
	;
}
#define INLINE_F23_378
#endif
#ifndef INLINE_F23_379
static void inline_F23_379 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	pango_attr_list_insert ((PangoAttrList *)arg1, (PangoAttribute *)arg2);
	;
}
#define INLINE_F23_379
#endif
#ifndef INLINE_F23_380
static void inline_F23_380 (EIF_POINTER arg1)
{
	pango_attr_list_unref ((PangoAttrList *)arg1);
	;
}
#define INLINE_F23_380
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PANGO}.scale */
EIF_INTEGER_32 F23_323 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("scale", 22, Current, 0, 0, 405);
	Result = (EIF_INTEGER_32) PANGO_SCALE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.font_description_new */
EIF_POINTER F23_326 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_new", 22, Current, 0, 0, 346);Result = (EIF_POINTER) pango_font_description_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.font_description_free */
void F23_327 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_free", 22, Current, 0, 1, 347);pango_font_description_free((PangoFontDescription*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.font_description_set_family */
void F23_330 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_set_family", 22, Current, 0, 2, 350);pango_font_description_set_family((PangoFontDescription*) arg1, (char*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.font_description_set_style */
void F23_332 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_set_style", 22, Current, 0, 2, 352);pango_font_description_set_style((PangoFontDescription*) arg1, (PangoStyle) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.font_description_set_weight */
void F23_334 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_set_weight", 22, Current, 0, 2, 354);pango_font_description_set_weight((PangoFontDescription*) arg1, (PangoWeight) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.font_description_set_size */
void F23_336 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_set_size", 22, Current, 0, 2, 356);pango_font_description_set_size((PangoFontDescription*) arg1, (gint) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.layout_set_font_description */
void F23_339 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_set_font_description", 22, Current, 0, 2, 359);pango_layout_set_font_description((PangoLayout*) arg1, (PangoFontDescription*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.layout_get_pixel_size */
void F23_341 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_get_pixel_size", 22, Current, 0, 3, 361);pango_layout_get_pixel_size((PangoLayout*) arg1, (gint*) arg2, (gint*) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.layout_get_iter */
EIF_POINTER F23_342 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_get_iter", 22, Current, 0, 1, 362);Result = (EIF_POINTER) pango_layout_get_iter((PangoLayout*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.layout_set_text */
void F23_343 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_set_text", 22, Current, 0, 3, 363);pango_layout_set_text((PangoLayout*) arg1, (char*) arg2, (int) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.layout_iter_get_baseline */
EIF_INTEGER_32 F23_344 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_iter_get_baseline", 22, Current, 0, 1, 364);Result = (EIF_INTEGER_32) pango_layout_iter_get_baseline((PangoLayoutIter*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.layout_iter_free */
void F23_345 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_iter_free", 22, Current, 0, 1, 365);pango_layout_iter_free((PangoLayoutIter*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.layout_get_pixel_extents */
void F23_347 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_get_pixel_extents", 22, Current, 0, 3, 367);pango_layout_get_pixel_extents((PangoLayout*) arg1, (PangoRectangle*) arg2, (PangoRectangle*) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.new_rectangle_struct */
EIF_POINTER F23_359 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("new_rectangle_struct", 22, Current, 0, 0, 379);
	Result = (EIF_POINTER) calloc (sizeof(PangoRectangle), 1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.rectangle_struct_x */
EIF_INTEGER_32 F23_360 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rectangle_struct_x", 22, Current, 0, 1, 380);Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->x);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.rectangle_struct_y */
EIF_INTEGER_32 F23_361 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rectangle_struct_y", 22, Current, 0, 1, 381);Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->y);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.rectangle_struct_width */
EIF_INTEGER_32 F23_362 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rectangle_struct_width", 22, Current, 0, 1, 382);Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->width);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.rectangle_struct_height */
EIF_INTEGER_32 F23_363 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rectangle_struct_height", 22, Current, 0, 1, 383);Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->height);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.pango_attr_list_new */
EIF_POINTER F23_375 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pango_attr_list_new", 22, Current, 0, 0, 395);
	Result = inline_F23_375 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.pango_attr_font_desc_new */
EIF_POINTER F23_378 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pango_attr_font_desc_new", 22, Current, 0, 1, 398);
	Result = inline_F23_378 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.pango_attr_list_insert */
void F23_379 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pango_attr_list_insert", 22, Current, 0, 2, 399);
	inline_F23_379 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.pango_attr_list_unref */
void F23_380 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pango_attr_list_unref", 22, Current, 0, 1, 400);
	inline_F23_380 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit22 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
