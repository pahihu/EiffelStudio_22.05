
#ifndef _C1_gd32_
#define _C1_gd32_

#ifdef __cplusplus
extern "C" {
#endif

extern void F33_494(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_REAL_64, EIF_REAL_64);
extern void EIF_Minit32(void);

#ifdef __cplusplus
}
#endif

#endif
