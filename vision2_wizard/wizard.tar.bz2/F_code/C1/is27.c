/*
 * Code for class ISE_SCOOP_RUNTIME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "is27.h"
#include "eif_scoop.h"
#include "eif_macros.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F28_457
static EIF_NATURAL_16 inline_F28_457 (EIF_POINTER arg1)
{
	return RTS_PID(arg1)
	;
}
#define INLINE_F28_457
#endif
#ifndef INLINE_F28_458
static void inline_F28_458 (EIF_NATURAL_16 arg1)
{
	eif_scoop_set_is_impersonation_allowed (arg1, EIF_FALSE)
	;
}
#define INLINE_F28_458
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ISE_SCOOP_RUNTIME}.pin_to_thread */
void F28_455 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_16 tu2_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pin_to_thread", 27, Current, 0, 0, 481);
	RTGC;
	RTHOOK(1);
	tu2_1 = inline_F28_457(Current);
	inline_F28_458(tu2_1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {ISE_SCOOP_RUNTIME}.c_region_id */
EIF_NATURAL_16 F28_457 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_16 Result = ((EIF_NATURAL_16) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_region_id", 27, Current, 0, 1, 483);
	Result = inline_F28_457 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {ISE_SCOOP_RUNTIME}.c_disable_impersonation */
void F28_458 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_disable_impersonation", 27, Current, 0, 1, 484);
	inline_F28_458 ((EIF_NATURAL_16) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit27 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
