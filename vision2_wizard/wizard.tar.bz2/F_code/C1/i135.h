
#ifndef _C1_i135_
#define _C1_i135_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F36_679(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit35(void);
extern void F154_3167(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
