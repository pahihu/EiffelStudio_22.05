/*
 * Code for class COMPILER_PROFILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co20.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {COMPILER_PROFILE}.initialize_from_arguments */
void F21_238 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("initialize_from_arguments", 20, Current, 3, 0, 264);
	RTGC;
	RTHOOK(1);
	F21_278(Current);
	RTHOOK(2);
	loc1 = RTLNS(eif_new_type(79, 0x00).id, 79, _OBJSIZ_1_0_0_0_0_0_0_0_);
	RTHOOK(3);
	tr1 = RTOSCF(239,F21_239, (Current));
	ti4_1 = F79_1260(RTCW(loc1), tr1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(4);
		F21_265(Current);
	} else {
		RTHOOK(5);
		tr1 = RTOSCF(240,F21_240, (Current));
		ti4_1 = F79_1260(RTCW(loc1), tr1);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(6);
			F21_266(Current);
		}
	}
	RTHOOK(7);
	tr1 = RTOSCF(241,F21_241, (Current));
	ti4_1 = F79_1260(RTCW(loc1), tr1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(8);
		F21_267(Current);
	}
	RTHOOK(9);
	tr1 = RTOSCF(242,F21_242, (Current));
	ti4_1 = F79_1260(RTCW(loc1), tr1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(10);
		F21_268(Current);
	}
	RTHOOK(11);
	tr1 = RTOSCF(243,F21_243, (Current));
	loc3 = F79_1260(RTCW(loc1), tr1);
	RTHOOK(12);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = F79_1263(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)) <= ti4_1);
	}
	if (tb1) {
		RTHOOK(13);
		loc2 = F79_1258(RTCW(loc1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
		RTHOOK(14);
		if (F21_256(Current, loc2)) {
			RTHOOK(15);
			F21_269(Current, loc2);
		}
	}
	RTHOOK(16);
	tr1 = RTOSCF(244,F21_244, (Current));
	loc3 = F79_1260(RTCW(loc1), tr1);
	RTHOOK(17);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = F79_1263(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)) <= ti4_1);
	}
	if (tb1) {
		RTHOOK(18);
		loc2 = F79_1258(RTCW(loc1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
		RTHOOK(19);
		if (F21_261(Current, loc2)) {
			RTHOOK(20);
			F21_270(Current, loc2);
		}
	}
	RTHOOK(21);
	RTLE;
	RTEE;
}

/* {COMPILER_PROFILE}.compat_option_name */

EIF_REFERENCE F21_239 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (239,RTMS_EX_H("compat",6,2031575924));
}

/* {COMPILER_PROFILE}.experiment_option_name */

EIF_REFERENCE F21_240 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (240,RTMS_EX_H("experiment",10,207796852));
}

/* {COMPILER_PROFILE}.full_option_name */

EIF_REFERENCE F21_241 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (241,RTMS_EX_H("full",4,1718971500));
}

/* {COMPILER_PROFILE}.safe_option_name */

EIF_REFERENCE F21_242 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (242,RTMS_EX_H("safe",4,1935763045));
}

/* {COMPILER_PROFILE}.platform_option_name */

EIF_REFERENCE F21_243 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (243,RTMS_EX_H("platform",8,459690093));
}

/* {COMPILER_PROFILE}.capabilty_option_name */

EIF_REFERENCE F21_244 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (244,RTMS_EX_H("capability",10,950653049));
}

/* {COMPILER_PROFILE}.is_compatible_mode */
EIF_BOOLEAN F21_249 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_compatible_mode", 20, Current, 0, 0, 275);
	RTGC;
	RTHOOK(1);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 1U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 1U));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {COMPILER_PROFILE}.is_experimental_mode */
EIF_BOOLEAN F21_251 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_experimental_mode", 20, Current, 0, 0, 277);
	RTGC;
	RTHOOK(1);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 2U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 2U));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {COMPILER_PROFILE}.is_platform_valid */
EIF_BOOLEAN F21_256 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("is_platform_valid", 20, Current, 0, 1, 282);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	tb1 = '\01';
	tb2 = '\01';
	tr1 = RTMS_EX_H("windows",7,1657536371);
	tb3 = F1054_8809(RTCW(arg1), tr1);
	if (!tb3) {
		tr1 = RTMS_EX_H("unix",4,1970170232);
		tb3 = F1054_8809(RTCW(arg1), tr1);
		tb2 = tb3;
	}
	if (!tb2) {
		tr1 = RTMS_EX_H("macintosh",9,458551400);
		tb2 = F1054_8809(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (!tb1) {
		tr1 = RTMS_EX_H("vxworks",7,1368523123);
		tb1 = F1054_8809(RTCW(arg1), tr1);
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {COMPILER_PROFILE}.is_capability_valid */
EIF_BOOLEAN F21_261 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_capability_valid", 20, Current, 0, 1, 287);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	tb1 = '\01';
	tr1 = RTOSCF(290,F21_290, (Current));
	tb2 = F1054_8812(RTCW(arg1), tr1);
	if (!tb2) {
		tr1 = RTOSCF(291,F21_291, (Current));
		tb2 = F1054_8812(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (!tb1) {
		tr1 = RTOSCF(292,F21_292, (Current));
		tb1 = F1054_8812(RTCW(arg1), tr1);
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {COMPILER_PROFILE}.set_compatible_mode */
void F21_265 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_compatible_mode", 20, Current, 0, 0, 291);
	RTGC;
	RTHOOK(1);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 1U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {COMPILER_PROFILE}.set_experimental_mode */
void F21_266 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_experimental_mode", 20, Current, 0, 0, 292);
	RTGC;
	RTHOOK(1);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 2U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {COMPILER_PROFILE}.set_full_class_checking_mode */
void F21_267 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_full_class_checking_mode", 20, Current, 0, 0, 293);
	RTGC;
	RTHOOK(1);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 4U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {COMPILER_PROFILE}.set_safe_mode */
void F21_268 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_safe_mode", 20, Current, 0, 0, 294);
	RTGC;
	RTHOOK(1);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 8U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {COMPILER_PROFILE}.set_platform */
void F21_269 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("set_platform", 20, Current, 0, 1, 295);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS_EX_H("windows",7,1657536371);
	tb1 = F1054_8809(RTCW(arg1), tr1);
	if (tb1) {
		RTHOOK(2);
		F21_271(Current);
	} else {
		RTHOOK(3);
		tr1 = RTMS_EX_H("unix",4,1970170232);
		tb1 = F1054_8809(RTCW(arg1), tr1);
		if (tb1) {
			RTHOOK(4);
			F21_272(Current);
		} else {
			RTHOOK(5);
			tr1 = RTMS_EX_H("macintosh",9,458551400);
			tb1 = F1054_8809(RTCW(arg1), tr1);
			if (tb1) {
				RTHOOK(6);
				F21_273(Current);
			} else {
				RTHOOK(7);
				tr1 = RTMS_EX_H("vxworks",7,1368523123);
				tb1 = F1054_8809(RTCW(arg1), tr1);
				if (tb1) {
					RTHOOK(8);
					F21_274(Current);
				}
			}
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {COMPILER_PROFILE}.set_capability */
void F21_270 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_capability", 20, Current, 0, 1, 296);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(290,F21_290, (Current));
	tb1 = F1054_8812(RTCW(arg1), tr1);
	if (tb1) {
		RTHOOK(2);
		F21_275(Current);
	} else {
		RTHOOK(3);
		tr1 = RTOSCF(291,F21_291, (Current));
		tb1 = F1054_8812(RTCW(arg1), tr1);
		if (tb1) {
			RTHOOK(4);
			F21_276(Current);
		} else {
			RTHOOK(5);
			tr1 = RTOSCF(292,F21_292, (Current));
			tb1 = F1054_8812(RTCW(arg1), tr1);
			if (tb1) {
				RTHOOK(6);
				F21_277(Current);
			}
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {COMPILER_PROFILE}.set_is_windows_platform */
void F21_271 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_is_windows_platform", 20, Current, 0, 0, 297);
	RTGC;
	RTHOOK(1);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 240U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 32U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {COMPILER_PROFILE}.set_is_unix_platform */
void F21_272 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_is_unix_platform", 20, Current, 0, 0, 298);
	RTGC;
	RTHOOK(1);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 240U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 16U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {COMPILER_PROFILE}.set_is_mac_platform */
void F21_273 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_is_mac_platform", 20, Current, 0, 0, 299);
	RTGC;
	RTHOOK(1);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 240U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 48U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {COMPILER_PROFILE}.set_is_vxworks_platform */
void F21_274 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_is_vxworks_platform", 20, Current, 0, 0, 300);
	RTGC;
	RTHOOK(1);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 240U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 64U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {COMPILER_PROFILE}.set_capability_warning */
void F21_275 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_capability_warning", 20, Current, 0, 0, 301);
	RTGC;
	RTHOOK(1);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 512U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 256U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {COMPILER_PROFILE}.set_capability_error */
void F21_276 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_capability_error", 20, Current, 0, 0, 302);
	RTGC;
	RTHOOK(1);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 256U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 512U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {COMPILER_PROFILE}.set_capability_strict */
void F21_277 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_capability_strict", 20, Current, 0, 0, 303);
	RTGC;
	RTHOOK(1);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 1024U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {COMPILER_PROFILE}.reset */
void F21_278 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("reset", 20, Current, 0, 0, 304);
	RTHOOK(1);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	RTEE;
}

/* {COMPILER_PROFILE}.capability_value_warning */

EIF_REFERENCE F21_290 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (290,RTMS_EX_H("warning",7,1809215079));
}

/* {COMPILER_PROFILE}.capability_value_error */

EIF_REFERENCE F21_291 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (291,RTMS_EX_H("error",5,1920877938));
}

/* {COMPILER_PROFILE}.capability_value_strict */

EIF_REFERENCE F21_292 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (292,RTMS_EX_H("strict",6,2146499444));
}

void EIF_Minit20 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
