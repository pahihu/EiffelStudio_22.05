
#ifndef _C1_ut3_
#define _C1_ut3_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F3_44(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit3(void);
extern void F1054_8767(EIF_REFERENCE);
extern EIF_REFERENCE F49_913(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R6076[])();

#ifdef __cplusplus
}
#endif

#endif
