/*
 * Code for class I18N_PLURAL_TOOLS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i125.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_PLURAL_TOOLS}.mo_header_to_plural_form */
EIF_INTEGER_32 F26_422 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("mo_header_to_plural_form", 25, Current, 0, 2, 470);
	RTGC;
	RTHOOK(1);
	switch (arg1) {
		case 1L:
			RTHOOK(2);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			break;
		case 2L:
			RTHOOK(3);
			tr1 = RTMS_EX_H("n != 1;",7,619025723);
			tb1 = F1054_8812(RTCW(arg2), tr1);
			if (tb1) {
				RTHOOK(4);
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
			} else {
				RTHOOK(5);
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			}
			break;
		case 3L:
			RTHOOK(6);
			tb1 = '\0';
			tb2 = '\0';
			tr1 = RTMS_EX_H("!=",2,8509);
			tb3 = F1054_8811(RTCW(arg2), tr1);
			if (tb3) {
				tr1 = RTMS_EX_H("4",1,52);
				tb3 = F1054_8811(RTCW(arg2), tr1);
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				tr1 = RTMS_EX_H("20",2,12848);
				tb2 = F1054_8811(RTCW(arg2), tr1);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				RTHOOK(7);
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
			} else {
				RTHOOK(8);
				tb1 = '\0';
				tr1 = RTMS_EX_H("!=",2,8509);
				tb2 = F1054_8811(RTCW(arg2), tr1);
				if ((EIF_BOOLEAN) !tb2) {
					tr1 = RTMS_EX_H("4",1,52);
					tb2 = F1054_8811(RTCW(arg2), tr1);
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) {
					RTHOOK(9);
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
				} else {
					RTHOOK(10);
					tb1 = '\0';
					tr1 = RTMS_EX_H("20",2,12848);
					tb2 = F1054_8811(RTCW(arg2), tr1);
					if (tb2) {
						tr1 = RTMS_EX_H("4",1,52);
						tb2 = F1054_8811(RTCW(arg2), tr1);
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						RTHOOK(11);
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
					} else {
						RTHOOK(12);
						tr1 = RTMS_EX_H("!=",2,8509);
						tb1 = F1054_8811(RTCW(arg2), tr1);
						if (tb1) {
							RTHOOK(13);
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
						} else {
							RTHOOK(14);
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
						}
					}
				}
			}
			break;
		case 4L:
			RTHOOK(15);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
			break;
		default:
			RTHOOK(16);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			break;
	}
	RTHOOK(17);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_PLURAL_TOOLS}.get_reduction_agent */
EIF_REFERENCE F26_437 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("get_reduction_agent", 25, Current, 0, 1, 458);
	RTGC;
	RTHOOK(1);
	switch (arg1) {
		case 1L:
			RTHOOK(2);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1051,0xFFF9,1,973,1006,1006,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A25_50_2, (EIF_POINTER) _A25_50_2, (EIF_POINTER)(F26_439),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 2L:
			RTHOOK(3);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1051,0xFFF9,1,973,1006,1006,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A25_51_2, (EIF_POINTER) _A25_51_2, (EIF_POINTER)(F26_440),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 0L:
		case 3L:
			RTHOOK(4);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1051,0xFFF9,1,973,1006,1006,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A25_52_2, (EIF_POINTER) _A25_52_2, (EIF_POINTER)(F26_441),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 4L:
			RTHOOK(5);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1051,0xFFF9,1,973,1006,1006,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A25_53_2, (EIF_POINTER) _A25_53_2, (EIF_POINTER)(F26_442),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 5L:
			RTHOOK(6);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1051,0xFFF9,1,973,1006,1006,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A25_54_2, (EIF_POINTER) _A25_54_2, (EIF_POINTER)(F26_443),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 6L:
			RTHOOK(7);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1051,0xFFF9,1,973,1006,1006,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A25_55_2, (EIF_POINTER) _A25_55_2, (EIF_POINTER)(F26_444),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 7L:
			RTHOOK(8);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1051,0xFFF9,1,973,1006,1006,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A25_56_2, (EIF_POINTER) _A25_56_2, (EIF_POINTER)(F26_445),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 8L:
			RTHOOK(9);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1051,0xFFF9,1,973,1006,1006,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A25_57_2, (EIF_POINTER) _A25_57_2, (EIF_POINTER)(F26_446),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 9L:
			RTHOOK(10);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1051,0xFFF9,1,973,1006,1006,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A25_58_2, (EIF_POINTER) _A25_58_2, (EIF_POINTER)(F26_447),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_PLURAL_TOOLS}.get_nplural */
EIF_INTEGER_32 F26_438 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_nplural", 25, Current, 0, 1, 459);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 3L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 1L))) {
			RTHOOK(5);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(6);
			if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 8L))) {
				RTHOOK(7);
				RTHOOK(8);
				RTLE;
				RTEE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			} else {
				RTHOOK(9);
				RTHOOK(10);
				RTLE;
				RTEE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
			}
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_PLURAL_TOOLS}.reduce_one_plural_form */
EIF_INTEGER_32 F26_439 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("reduce_one_plural_form", 25, Current, 0, 1, 460);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

/* {I18N_PLURAL_TOOLS}.reduce_two_plural_forms_singular_one */
EIF_INTEGER_32 F26_440 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reduce_two_plural_forms_singular_one", 25, Current, 0, 1, 461);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_two_plural_forms_singular_one_zero */
EIF_INTEGER_32 F26_441 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reduce_two_plural_forms_singular_one_zero", 25, Current, 0, 1, 462);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_three_plural_forms_special_zero */
EIF_INTEGER_32 F26_442 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reduce_three_plural_forms_special_zero", 25, Current, 0, 1, 463);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) != ((EIF_INTEGER_32) 11L)))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN)(arg1 != ((EIF_INTEGER_32) 0L))) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		}
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_three_plural_forms_special_one_two */
EIF_INTEGER_32 F26_443 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reduce_three_plural_forms_special_one_two", 25, Current, 0, 1, 464);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 2L))) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		}
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_three_plural_forms_special_twelve_to_nineteen */
EIF_INTEGER_32 F26_444 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reduce_three_plural_forms_special_twelve_to_nineteen", 25, Current, 0, 1, 465);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) != ((EIF_INTEGER_32) 11L)))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) >= ((EIF_INTEGER_32) 2L)) && (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) < ((EIF_INTEGER_32) 10L)) || (EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) >= ((EIF_INTEGER_32) 20L))))) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		}
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_three_plural_forms_special_slavic */
EIF_INTEGER_32 F26_445 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reduce_three_plural_forms_special_slavic", 25, Current, 0, 1, 466);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) != ((EIF_INTEGER_32) 11L)))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) >= ((EIF_INTEGER_32) 2L)) && (EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) <= ((EIF_INTEGER_32) 4L))) && (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) < ((EIF_INTEGER_32) 10L)) || (EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) >= ((EIF_INTEGER_32) 20L))))) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		}
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_three_plural_forms_special_polish */
EIF_INTEGER_32 F26_446 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reduce_three_plural_forms_special_polish", 25, Current, 0, 1, 467);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) >= ((EIF_INTEGER_32) 2L)) && (EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) <= ((EIF_INTEGER_32) 4L))) && (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) < ((EIF_INTEGER_32) 10L)) || (EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) >= ((EIF_INTEGER_32) 20L))))) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		}
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_four_plural_forms_special_slovenian */
EIF_INTEGER_32 F26_447 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reduce_four_plural_forms_special_slovenian", 25, Current, 0, 1, 468);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) == ((EIF_INTEGER_32) 2L))) {
			RTHOOK(5);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(6);
			if ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) == ((EIF_INTEGER_32) 3L))) {
				RTHOOK(7);
				RTHOOK(8);
				RTLE;
				RTEE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
			} else {
				RTHOOK(9);
				RTHOOK(10);
				RTLE;
				RTEE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			}
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit25 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
