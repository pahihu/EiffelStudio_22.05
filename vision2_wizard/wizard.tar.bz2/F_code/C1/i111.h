
#ifndef _C1_i111_
#define _C1_i111_

#ifdef __cplusplus
extern "C" {
#endif

extern void F11_94(EIF_REFERENCE, EIF_REFERENCE);
extern void F11_95(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit11(void);

#ifdef __cplusplus
}
#endif

#endif
