
#ifndef _C1_pr30_
#define _C1_pr30_

#ifdef __cplusplus
extern "C" {
#endif
RTOSHF (EIF_REFERENCE, 476)


extern EIF_REFERENCE F31_476(EIF_REFERENCE);
extern void EIF_Minit30(void);

#ifdef __cplusplus
}
#endif

#endif
