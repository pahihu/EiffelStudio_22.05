/*
 * Code for class GTK_ALIGN
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt14.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F14_136
static EIF_INTEGER_32 inline_F14_136 (void)
{
	return GTK_ALIGN_START
	;
}
#define INLINE_F14_136
#endif
#ifndef INLINE_F14_137
static EIF_INTEGER_32 inline_F14_137 (void)
{
	return GTK_ALIGN_END
	;
}
#define INLINE_F14_137
#endif
#ifndef INLINE_F14_138
static EIF_INTEGER_32 inline_F14_138 (void)
{
	return GTK_ALIGN_CENTER
	;
}
#define INLINE_F14_138
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_ALIGN}.gtk_align_start */
EIF_INTEGER_32 F14_136 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_align_start", 13, Current, 0, 0, 133);
	Result = inline_F14_136 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK_ALIGN}.gtk_align_end */
EIF_INTEGER_32 F14_137 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_align_end", 13, Current, 0, 0, 134);
	Result = inline_F14_137 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK_ALIGN}.gtk_align_center */
EIF_INTEGER_32 F14_138 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_align_center", 13, Current, 0, 0, 135);
	Result = inline_F14_138 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit14 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
