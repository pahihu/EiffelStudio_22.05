/*
 * Code for class GDK_CAIRO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gd32.h"
#include "ev_gtk.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GDK_CAIRO}.set_source_pixbuf */
void F33_494 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_source_pixbuf", 32, Current, 0, 4, 541);gdk_cairo_set_source_pixbuf((cairo_t*) arg1, (GdkPixbuf*) arg2, (double) arg3, (double) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit32 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
