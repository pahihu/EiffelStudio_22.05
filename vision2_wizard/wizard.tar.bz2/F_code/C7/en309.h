
#ifndef _C7_en309_
#define _C7_en309_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F676_5740(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit309(void);
extern EIF_REFERENCE F674_5706(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
