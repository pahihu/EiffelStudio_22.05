/*
 * Code for class EV_COORDINATE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev341.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_COORDINATE}.set */
void F856_6416 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REAL_64 tr8_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set", 855, Current, 0, 2, 10326);
	RTGC;
	RTHOOK(1);
	tr8_1 = (EIF_REAL_64) (arg1);
	*(EIF_REAL_64 *)(Current+ _R64OFF_0_0_0_0_0_0_0_0_) = (EIF_REAL_64) tr8_1;
	RTHOOK(2);
	tr8_1 = (EIF_REAL_64) (arg2);
	*(EIF_REAL_64 *)(Current+ _R64OFF_0_0_0_0_0_0_0_1_) = (EIF_REAL_64) tr8_1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_COORDINATE}.x */
EIF_INTEGER_32 F856_6421 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("x", 855, Current, 0, 0, 10314);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) eif_is_greater_real_64 (*(EIF_REAL_64 *)(Current+ _R64OFF_0_0_0_0_0_0_0_0_), (EIF_REAL_64) 0.0)) {
		RTHOOK(2);
		Result = (EIF_INTEGER_32) (EIF_REAL_64) (*(EIF_REAL_64 *)(Current+ _R64OFF_0_0_0_0_0_0_0_0_) + (EIF_REAL_64) 0.5);
	} else {
		RTHOOK(3);
		Result = (EIF_INTEGER_32) (EIF_REAL_64) (*(EIF_REAL_64 *)(Current+ _R64OFF_0_0_0_0_0_0_0_0_) - (EIF_REAL_64) 0.5);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COORDINATE}.y */
EIF_INTEGER_32 F856_6423 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("y", 855, Current, 0, 0, 10316);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) eif_is_greater_real_64 (*(EIF_REAL_64 *)(Current+ _R64OFF_0_0_0_0_0_0_0_1_), (EIF_REAL_64) 0.0)) {
		RTHOOK(2);
		Result = (EIF_INTEGER_32) (EIF_REAL_64) (*(EIF_REAL_64 *)(Current+ _R64OFF_0_0_0_0_0_0_0_1_) + (EIF_REAL_64) 0.5);
	} else {
		RTHOOK(3);
		Result = (EIF_INTEGER_32) (EIF_REAL_64) (*(EIF_REAL_64 *)(Current+ _R64OFF_0_0_0_0_0_0_0_1_) - (EIF_REAL_64) 0.5);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit341 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
