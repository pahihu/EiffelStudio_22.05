
#ifndef _C7_mi310_
#define _C7_mi310_

#ifdef __cplusplus
extern "C" {
#endif

extern void F677_5742(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,5743)
static EIF_REFERENCE F677_5743_body(EIF_REFERENCE);
extern EIF_REFERENCE F677_5743(EIF_REFERENCE);
extern void EIF_Minit310(void);
extern void F688_5913(EIF_REFERENCE);
extern EIF_REFERENCE F941_7504(EIF_REFERENCE);
extern void F1063_9139(EIF_REFERENCE, EIF_REFERENCE);
extern void F1063_9178(EIF_REFERENCE, EIF_REFERENCE);
extern void F225_3909(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
