/*
 * Code for class MUTEX
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "mu348.h"
#include "eif_built_in.h"
#include <eif_threads.h>
#include "eif_threads.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F98_1359
static EIF_POINTER inline_F98_1359 (void)
{
	return eif_thr_thread_id();
	;
}
#define INLINE_F98_1359
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {MUTEX}.make */
void F920_6620 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 919, Current, 0, 0, 11736);
	RTGC;
	RTHOOK(1);
	tp1 = (EIF_POINTER) eif_thr_mutex_create();
	*(EIF_POINTER *)(Current+ _PTROFF_0_0_0_0_0_1_) = (EIF_POINTER) tp1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {MUTEX}.is_set */
EIF_BOOLEAN F920_6622 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_set", 919, Current, 0, 0, 11738);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if (!(EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_0_0_0_0_0_1_) != tp1)) {
		Result = (EIF_BOOLEAN) !(EIF_BOOLEAN) eif_builtin_PLATFORM_is_thread_capable__b;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {MUTEX}.lock */
void F920_6623 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("lock", 919, Current, 0, 0, 11739);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_0_0_0_0_1_);
	eif_thr_mutex_lock(tp1);
	RTHOOK(2);
	tp1 = inline_F98_1359();
	*(EIF_POINTER *)(Current+ _PTROFF_0_0_0_0_0_0_) = (EIF_POINTER) tp1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {MUTEX}.try_lock */
EIF_BOOLEAN F920_6624 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("try_lock", 919, Current, 0, 0, 11740);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_0_0_0_0_1_);
	Result = (EIF_BOOLEAN) EIF_TEST(eif_thr_mutex_trylock(tp1));
	RTHOOK(2);
	if (Result) {
		RTHOOK(3);
		tp1 = inline_F98_1359();
		*(EIF_POINTER *)(Current+ _PTROFF_0_0_0_0_0_0_) = (EIF_POINTER) tp1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {MUTEX}.unlock */
void F920_6625 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("unlock", 919, Current, 0, 0, 11741);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current+ _PTROFF_0_0_0_0_0_0_) = (EIF_POINTER) tp2;
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_0_0_0_0_1_);
	eif_thr_mutex_unlock(tp1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {MUTEX}.destroy */
void F920_6626 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("destroy", 919, Current, 0, 0, 11742);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_0_0_0_0_1_);
	eif_thr_mutex_destroy(tp1);
	RTHOOK(2);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current+ _PTROFF_0_0_0_0_0_1_) = (EIF_POINTER) tp2;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {MUTEX}.dispose */
void F920_6629 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dispose", 919, Current, 0, 0, 11745);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (F920_6622(Current)) {
		tb2 = '\01';
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if (!(EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_0_0_0_0_0_0_) == tp1)) {
			tb2 = (EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_0_0_0_0_0_0_) == inline_F98_1359());
		}
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		F920_6626(Current);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {MUTEX}.eif_thr_mutex_create */
EIF_POINTER F920_6631 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("eif_thr_mutex_create", 919, Current, 0, 0, 11747);Result = (EIF_POINTER) eif_thr_mutex_create();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {MUTEX}.eif_thr_mutex_lock */
void F920_6632 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("eif_thr_mutex_lock", 919, Current, 0, 1, 11748);
	EIF_ENTER_C;eif_thr_mutex_lock(arg1);
	
	EIF_EXIT_C;
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {MUTEX}.eif_thr_mutex_unlock */
void F920_6633 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("eif_thr_mutex_unlock", 919, Current, 0, 1, 11749);eif_thr_mutex_unlock(arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {MUTEX}.eif_thr_mutex_trylock */
EIF_BOOLEAN F920_6634 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("eif_thr_mutex_trylock", 919, Current, 0, 1, 11734);
	EIF_ENTER_C;Result = (EIF_BOOLEAN) EIF_TEST(eif_thr_mutex_trylock(arg1));
	
	EIF_EXIT_C;
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {MUTEX}.eif_thr_mutex_destroy */
void F920_6635 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("eif_thr_mutex_destroy", 919, Current, 0, 1, 11735);eif_thr_mutex_destroy(arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit348 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
