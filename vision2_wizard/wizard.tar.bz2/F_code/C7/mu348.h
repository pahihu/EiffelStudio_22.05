
#ifndef _C7_mu348_
#define _C7_mu348_

#ifdef __cplusplus
extern "C" {
#endif

extern void F920_6620(EIF_REFERENCE);
extern EIF_BOOLEAN F920_6622(EIF_REFERENCE);
extern void F920_6623(EIF_REFERENCE);
extern EIF_BOOLEAN F920_6624(EIF_REFERENCE);
extern void F920_6625(EIF_REFERENCE);
extern void F920_6626(EIF_REFERENCE);
extern void F920_6629(EIF_REFERENCE);
extern EIF_POINTER F920_6631(EIF_REFERENCE);
extern void F920_6632(EIF_REFERENCE, EIF_POINTER);
extern void F920_6633(EIF_REFERENCE, EIF_POINTER);
extern EIF_BOOLEAN F920_6634(EIF_REFERENCE, EIF_POINTER);
extern void F920_6635(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit348(void);

#ifdef __cplusplus
}
#endif

#endif
