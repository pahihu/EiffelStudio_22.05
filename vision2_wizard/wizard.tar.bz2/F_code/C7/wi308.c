/*
 * Code for class WIZARD_FINAL_STATE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi308.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_FINAL_STATE}.display_state_text */
void F675_5737 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTEAA("display_state_text", 674, Current, 1, 0, 7608);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = F127_2829(RTCV(RTOSCF(4390,F284_4390, (Current))));
	F1122_9745(RTCW(tr1), tr2);
	RTHOOK(2);
	tr1 = RTOSCF(4390,F284_4390, (Current));
	tr2 = *(EIF_REFERENCE *)(Current);
	tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_2_);
	tr3 = *(EIF_REFERENCE *)(Current);
	tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
	tr3 = F940_7483(RTCW(tr3));
	loc1 = F127_2832(RTCW(tr1), tr2, tr3);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_4_0_);
	if (tb1) {
		RTHOOK(4);
		tr1 = RTOSCF(4390,F284_4390, (Current));
		tr2 = *(EIF_REFERENCE *)(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr2)+ _CHROFF_4_1_);
		tr1 = F127_2833(RTCW(tr1), tb1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7499[Dtype(RTCW(loc1))-1061])(loc1, tr1);
		loc1 = (EIF_REFERENCE) tr1;
	}
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = F1054_8826(RTMS_EX_H("\012\012",2,2570));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7499[Dtype(RTCW(loc1))-1061])(loc1, tr2);
	tr3 = RTOSCF(4390,F284_4390, (Current));
	tr4 = *(EIF_REFERENCE *)(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr4)+ _CHROFF_4_2_);
	tr3 = F127_2834(RTCW(tr3), tb1);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7499[Dtype(RTCW(tr2))-1061])(tr2, tr3);
	F1122_9745(RTCW(tr1), tr2);
	RTHOOK(6);
	RTLE;
	RTEE;
}

void EIF_Minit308 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
