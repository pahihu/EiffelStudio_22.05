
#ifndef _C7_ev313_
#define _C7_ev313_

#ifdef __cplusplus
extern "C" {
#endif

extern void F710_6038(EIF_REFERENCE);
extern void F710_6039(EIF_REFERENCE, EIF_REFERENCE);
extern void F710_6040(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit313(void);
extern void F708_6032(EIF_REFERENCE);
extern void F710_6040(EIF_REFERENCE, EIF_REFERENCE);
extern void F1213_10845(EIF_REFERENCE);
extern void F1213_10844(EIF_REFERENCE);
extern EIF_REFERENCE _A313_167_2();
extern EIF_REFERENCE __A313_167_2();
extern void F710_6039(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE _A313_166_2();
extern void F704_6008(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE __A313_166_2();
extern EIF_TYPE_INDEX Y4909[];
extern EIF_TYPE_INDEX *Y4909_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
