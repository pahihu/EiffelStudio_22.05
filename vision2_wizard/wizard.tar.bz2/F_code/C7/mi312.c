/*
 * Code for class MISMATCH_INFORMATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "mi312.h"
#include <eif_retrieve.h>
#include "../C21/ha1009.h"
#include "../C7/mi312.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {MISMATCH_INFORMATION}.default_create */
void F688_5913 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_create", 687, Current, 0, 0, 8361);
	RTGC;
	RTHOOK(1);
	F680_5794(Current, ((EIF_INTEGER_32) 5L));
	RTHOOK(2);
	RTOSCP(5923,F688_5923, (Current));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {MISMATCH_INFORMATION}.class_name */
EIF_REFERENCE F688_5914 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("class_name", 687, Current, 1, 0, 8362);
	RTGC;
	
	RTHOOK(2);
	RTCT0("attached {STRING_8} item (type_name_key) as r", EX_CHECK);
	tr1 = RTOSCF(5917,F688_5917, (Current));
	tr1 = F680_5800(Current, tr1);
	loc1 = RTCCL(tr1);
	loc1 = RTRV(eif_new_type(1058, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	Result = (EIF_REFERENCE) loc1;
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {MISMATCH_INFORMATION}.type_name_key */

EIF_REFERENCE F688_5917 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (5917,RTMS_EX_H("_type_name",10,803527013));
}

/* {MISMATCH_INFORMATION}.out */
EIF_REFERENCE F688_5920 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTEAA("out", 687, Current, 2, 0, 8368);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F688_5914(Current))+ _LNGOFF_1_1_0_2_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_3_0_6_);
	F1057_8897(RTCW(Result), (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 20L) + ti4_1) + (EIF_INTEGER_32) (((EIF_INTEGER_32) 40L) * ti4_2)));
	RTHOOK(2);
	tr1 = RTMS_EX_H("Attributes of original class ",29,488257824);
	F1059_9010(RTCW(Result), tr1);
	RTHOOK(3);
	tr1 = F688_5914(Current);
	F1059_9010(RTCW(Result), tr1);
	RTHOOK(4);
	tr1 = RTMS_EX_H(": ",2,14880);
	F1059_9010(RTCW(Result), tr1);
	RTHOOK(5);
	F1059_9013(RTCW(Result), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_3_0_6_) - ((EIF_INTEGER_32) 1L)));
	RTHOOK(6);
	tr1 = RTMS_EX_H(" item",5,1769481581);
	F1059_9010(RTCW(Result), tr1);
	RTHOOK(7);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_3_0_6_) - ((EIF_INTEGER_32) 1L)) != ((EIF_INTEGER_32) 1L))) {
		RTHOOK(8);
		F1059_9023(RTCW(Result), (EIF_CHARACTER_8) 's');
	}
	RTHOOK(9);
	F1059_9023(RTCW(Result), (EIF_CHARACTER_8) '\012');
	RTHOOK(10);
	F680_5833(Current);
	for (;;) {
		RTHOOK(11);
		if (F680_5828(Current)) break;
		RTHOOK(12);
		loc2 = F680_5807(Current);
		RTHOOK(13);
		if (!RTEQ(loc2, RTOSCF(5917,F688_5917, (Current)))) {
			RTHOOK(14);
			tr1 = RTMS_EX_H("  ",2,8224);
			F1059_9010(RTCW(Result), tr1);
			RTHOOK(15);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				RTHOOK(16);
				tr1 = RTMS_EX_H("Void",4,1450142052);
				F1059_9010(RTCW(Result), tr1);
			} else {
				RTHOOK(17);
				F1059_9010(RTCW(Result), loc2);
			}
			RTHOOK(18);
			tr1 = RTMS_EX_H(": ",2,14880);
			F1059_9010(RTCW(Result), tr1);
			RTHOOK(19);
			loc1 = F680_5806(Current);
			RTHOOK(20);
			if ((EIF_BOOLEAN)(loc1 == NULL)) {
				RTHOOK(21);
				tr1 = RTMS_EX_H("Void",4,1450142052);
				F1059_9010(RTCW(Result), tr1);
			} else {
				RTHOOK(22);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R28[Dtype(RTCW(loc1))-2])(loc1);
				F1059_9010(RTCW(Result), tr1);
			}
			RTHOOK(23);
			F1059_9023(RTCW(Result), (EIF_CHARACTER_8) '\012');
		}
		RTHOOK(24);
		F680_5834(Current);
	}
	RTHOOK(25);
	RTLE;
	RTEE;
	return Result;
}

/* {MISMATCH_INFORMATION}.internal_put */
void F688_5921 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("internal_put", 687, Current, 0, 2, 8357);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	tr2 = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1057_8900(RTCW(tr2), arg2);
	F680_5840(Current, tr1, tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {MISMATCH_INFORMATION}.set_string_versions */
void F688_5922 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTEAA("set_string_versions", 687, Current, 1, 2, 8358);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(arg1 == tp1)) {
		RTHOOK(2);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
	} else {
		RTHOOK(3);
		loc1 = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1057_8900(RTCW(loc1), arg1);
		RTHOOK(4);
		tb1 = F1058_8966(RTCW(loc1));
		if (tb1) {
			RTHOOK(5);
			*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
		} else {
			RTHOOK(6);
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc1;
		}
	}
	RTHOOK(7);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(arg2 == tp1)) {
		RTHOOK(8);
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
	} else {
		RTHOOK(9);
		loc1 = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1057_8900(RTCW(loc1), arg2);
		RTHOOK(10);
		tb1 = F1058_8966(RTCW(loc1));
		if (tb1) {
			RTHOOK(11);
			*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
		} else {
			RTHOOK(12);
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) loc1;
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {MISMATCH_INFORMATION}.set_callback_pointers */
static void F688_5923_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("set_callback_pointers", 687, Current, 0, 0, 8359);
	RTOSP (5923);
	RTHOOK(1);
	F688_5924(Current, Current, (EIF_POINTER) F680_5848, (EIF_POINTER) F688_5921, (EIF_POINTER) F688_5922);
	RTOSE (5923);
	RTHOOK(2);
	RTEE;
#undef Result
}

void F688_5923 (EIF_REFERENCE Current)
{
	GTCX
	RTOSCP(5923,F688_5923_body,(Current));
}

/* {MISMATCH_INFORMATION}.set_mismatch_information_access */
void F688_5924 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("set_mismatch_information_access", 687, Current, 0, 4, 8360);
	{
		EIF_OBJECT larg1 = &arg1;
		EIF_POINTER larg2 = arg2;
		EIF_POINTER larg3 = arg3;
		EIF_POINTER larg4 = arg4;set_mismatch_information_access((EIF_OBJECT) larg1, (EIF_PROCEDURE) larg2, (EIF_PROCEDURE) larg3, (EIF_PROCEDURE) larg4);
		
	}
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit312 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
