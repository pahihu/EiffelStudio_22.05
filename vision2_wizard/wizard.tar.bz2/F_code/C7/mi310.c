/*
 * Code for class MISMATCH_CORRECTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "mi310.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {MISMATCH_CORRECTOR}.correct_mismatch */
void F677_5742 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("correct_mismatch", 676, Current, 2, 0, 7613);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = RTMS_EX_H("Mismatch: ",10,1538098208);
	F1063_9139(RTCW(loc1), tr1);
	RTHOOK(2);
	loc2 = RTLNS(eif_new_type(224, 0x00).id, 224, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTHOOK(3);
	tr1 = F941_7504(RTCV((EIF_REFERENCE) eif_builtin_ANY_generating_type__t (Current)));
	F1063_9178(RTCW(loc1), tr1);
	RTHOOK(4);
	F225_3909(RTCW(loc2), loc1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {MISMATCH_CORRECTOR}.mismatch_information */
static EIF_REFERENCE F677_5743_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("mismatch_information", 676, Current, 0, 0, 7614);
	RTGC;
	RTOSP (5743);
#define Result RTOSR(5743)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(687, 0x00).id, 687, _OBJSIZ_9_3_0_7_0_0_0_0_);
	F688_5913(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (5743);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F677_5743 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5743,F677_5743_body,(Current));
}

void EIF_Minit310 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
