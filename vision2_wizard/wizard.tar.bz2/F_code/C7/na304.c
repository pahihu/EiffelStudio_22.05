/*
 * Code for class NATIVE_STRING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "na304.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NATIVE_STRING}.make */
void F671_5620 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("make", 670, Current, 0, 1, 7491);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7311[Dtype(RTCW(arg1))-1057])(arg1);
	F671_5621(Current, ti4_1);
	RTHOOK(2);
	F671_5635(Current, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {NATIVE_STRING}.make_empty */
void F671_5621 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_empty", 670, Current, 0, 1, 7492);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(925, 0).id);
	ti4_1 = F671_5633(Current);
	F926_6737(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)) * ti4_1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {NATIVE_STRING}.make_from_pointer */
void F671_5622 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_from_pointer", 670, Current, 1, 1, 7493);
	RTGC;
	RTHOOK(1);
	loc1 = F670_5618(Current, arg1);
	RTHOOK(2);
	tr1 = RTLNSMART(eif_new_type(925, 0).id);
	ti4_1 = F671_5633(Current);
	F926_6739(RTCW(tr1), arg1, (EIF_INTEGER_32) (loc1 + ti4_1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	ti4_1 = F671_5633(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 / ti4_1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {NATIVE_STRING}.string */
EIF_REFERENCE F671_5625 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	struct eif_ex_46 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(48, 0x00).id);
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("string", 670, Current, 1, 0, 7496);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		RTHOOK(2);
		tr1 = F49_934(RTCW(loc1), *(EIF_REFERENCE *)(Current));
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		tr1 = F49_909(RTCW(loc1), *(EIF_REFERENCE *)(Current));
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {NATIVE_STRING}.item */
EIF_POINTER F671_5627 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("item", 670, Current, 0, 0, 7498);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_1_0_1_0_0_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {NATIVE_STRING}.unit_size */
EIF_INTEGER_32 F671_5633 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("unit_size", 670, Current, 0, 0, 7504);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}/* NOTREACHED */
	
}

/* {NATIVE_STRING}.is_equal */
EIF_BOOLEAN F671_5634 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("is_equal", 670, Current, 0, 1, 7505);
	RTGC;
	RTHOOK(1);
	tp1 = F671_5627(Current);
	tp2 = F671_5627(RTCW(arg1));
	Result = tp1 == tp2;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATIVE_STRING}.set_string */
void F671_5635 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_string", 670, Current, 0, 1, 7506);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7311[Dtype(RTCW(arg1))-1057])(arg1);
	F671_5636(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {NATIVE_STRING}.set_substring */
void F671_5636 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	struct eif_ex_46 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(48, 0x00).id);
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("set_substring", 670, Current, 1, 3, 7507);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTOSCF(5640,F671_5640, (Current));
		F49_927(RTCW(loc1), arg1, arg2, arg3, tr1, ((EIF_INTEGER_32) 0L), tr2);
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTOSCF(5640,F671_5640, (Current));
		F49_902(RTCW(loc1), arg1, arg2, arg3, tr1, ((EIF_INTEGER_32) 0L), tr2);
	}
	RTHOOK(4);
	tr1 = RTOSCF(5640,F671_5640, (Current));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O3731[Dtype(tr1)-211]);
	ti4_2 = F671_5633(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 / ti4_2);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {NATIVE_STRING}.set_shared_from_pointer */
void F671_5637 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_shared_from_pointer", 670, Current, 0, 1, 7508);
	RTGC;
	RTHOOK(1);
	ti4_1 = F670_5618(Current, arg1);
	F671_5638(Current, arg1, ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {NATIVE_STRING}.set_shared_from_pointer_and_count */
void F671_5638 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_shared_from_pointer_and_count", 670, Current, 0, 2, 7509);
	RTGC;
	RTHOOK(1);
	ti4_1 = F671_5633(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 / ti4_1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_0_);
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		tr1 = RTLNSMART(eif_new_type(925, 0).id);
		ti4_1 = F671_5633(Current);
		F926_6740(RTCW(tr1), arg1, (EIF_INTEGER_32) (arg2 + ti4_1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = F671_5633(Current);
		F926_6742(RTCW(tr1), arg1, (EIF_INTEGER_32) (arg2 + ti4_1));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {NATIVE_STRING}.upper_cell */
static EIF_REFERENCE F671_5640_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("upper_cell", 670, Current, 0, 0, 7511);
	RTGC;
	RTOSP (5640);
#define Result RTOSR(5640)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {212,1006,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 212, _OBJSIZ_0_0_0_1_0_0_0_0_);
	}
	F213_3852(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (5640);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F671_5640 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5640,F671_5640_body,(Current));
}

void EIF_Minit304 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
