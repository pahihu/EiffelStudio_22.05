/*
 * Code for class GTK_SIGNAL_MARSHAL_CONNECTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt347.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_SIGNAL_MARSHAL_CONNECTION}.make */
void F919_6614 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 918, Current, 0, 2, 11728);
	RTGC;
	RTHOOK(1);
	*(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_) = (EIF_POINTER) arg1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_) = (EIF_INTEGER_32) arg2;
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_0_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(arg2 != ((EIF_INTEGER_32) 0L));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {GTK_SIGNAL_MARSHAL_CONNECTION}.close */
void F919_6617 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("close", 918, Current, 0, 0, 11731);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_0_0_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(114, 0x00).id, 114, _OBJSIZ_0_0_0_0_0_0_0_0_);
		F115_2201(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_));
		RTHOOK(3);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_0_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {GTK_SIGNAL_MARSHAL_CONNECTION}.dispose */
void F919_6619 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dispose", 918, Current, 0, 0, 11733);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit347 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
