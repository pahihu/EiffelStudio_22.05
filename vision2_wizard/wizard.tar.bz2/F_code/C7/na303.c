/*
 * Code for class NATIVE_STRING_HANDLER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "na303.h"
#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F670_5619
static EIF_NATURAL_64 inline_F670_5619 (EIF_POINTER arg1)
{
	#ifdef EIF_WINDOWS
				return (EIF_NATURAL_64) wcslen(arg1) * sizeof(wchar_t);
			#else
				return (EIF_NATURAL_64) strlen(arg1) * sizeof(char);
			#endif
	;
}
#define INLINE_F670_5619
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NATIVE_STRING_HANDLER}.pointer_length_in_bytes */
EIF_INTEGER_32 F670_5618 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_64 loc1 = (EIF_NATURAL_64) 0;
	EIF_NATURAL_64 tu8_1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pointer_length_in_bytes", 669, Current, 1, 1, 7488);
	RTGC;
	RTHOOK(1);
	loc1 = inline_F670_5619(arg1);
	RTHOOK(2);
	tu8_1 = (EIF_NATURAL_64) ((EIF_INTEGER_32) 2147483647L);
	if ((EIF_BOOLEAN) (loc1 <= tu8_1)) {
		RTHOOK(3);
		ti4_1 = (EIF_INTEGER_32) loc1;
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		RTHOOK(5);
		RTHOOK(6);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	}/* NOTREACHED */
	
}

/* {NATIVE_STRING_HANDLER}.c_pointer_length_in_bytes */
EIF_NATURAL_64 F670_5619 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_pointer_length_in_bytes", 669, Current, 0, 1, 7489);
	Result = inline_F670_5619 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit303 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
