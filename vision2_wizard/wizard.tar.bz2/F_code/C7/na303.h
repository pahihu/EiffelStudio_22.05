
#ifndef _C7_na303_
#define _C7_na303_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F670_5618(EIF_REFERENCE, EIF_POINTER);
extern EIF_NATURAL_64 F670_5619(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit303(void);

#ifdef __cplusplus
}
#endif

#endif
