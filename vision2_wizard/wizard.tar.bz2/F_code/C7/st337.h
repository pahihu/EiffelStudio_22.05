
#ifndef _C7_st337_
#define _C7_st337_

#ifdef __cplusplus
extern "C" {
#endif

extern void F828_6321(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F828_6322(EIF_REFERENCE);
extern EIF_REFERENCE F828_6325(EIF_REFERENCE);
extern EIF_INTEGER_32 F828_6326(EIF_REFERENCE);
extern void EIF_Minit337(void);
extern EIF_INTEGER_32 F1061_9115(EIF_REFERENCE);
extern char *(*R7507[])();

#ifdef __cplusplus
}
#endif

#endif
