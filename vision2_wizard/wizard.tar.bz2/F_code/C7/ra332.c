/*
 * Code for class RANDOM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ra332.h"
#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RANDOM}.set_seed */
void F746_6155 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_seed", 745, Current, 0, 1, 9387);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_);
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {RANDOM}.modulus */
static EIF_INTEGER_32 F746_6157_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("modulus", 745, Current, 0, 0, 9389);
	RTOSP (6157);
#define Result RTOSR(6157)
	RTHOOK(1);
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	RTOSE (6157);
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F746_6157 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6157,F746_6157_body,(Current));
}

/* {RANDOM}.multiplier */
static EIF_INTEGER_32 F746_6158_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("multiplier", 745, Current, 0, 0, 9390);
	RTOSP (6158);
#define Result RTOSR(6158)
	RTHOOK(1);
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16807L);
	RTOSE (6158);
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F746_6158 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6158,F746_6158_body,(Current));
}

/* {RANDOM}.increment */
static EIF_INTEGER_32 F746_6159_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("increment", 745, Current, 0, 0, 9391);
	RTOSP (6159);
#define Result RTOSR(6159)
	RTHOOK(1);
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTOSE (6159);
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F746_6159 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6159,F746_6159_body,(Current));
}

/* {RANDOM}.has */
EIF_BOOLEAN F746_6162 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("has", 745, Current, 0, 1, 9394);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN) (arg1 < RTOSCF(6157,F746_6157, (Current)))) {
		Result = (EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 0L));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {RANDOM}.i_th */
EIF_INTEGER_32 F746_6163 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("i_th", 745, Current, 1, 1, 9395);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_))) {
		RTHOOK(2);
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_);
		RTHOOK(3);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_);
	} else {
		RTHOOK(4);
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_);
	}
	for (;;) {
		RTHOOK(5);
		if ((EIF_BOOLEAN)(loc1 == arg1)) break;
		RTHOOK(6);
		ti4_1 = F746_6169(Current, Result);
		Result = (EIF_INTEGER_32) ti4_1;
		RTHOOK(7);
		loc1++;
	}
	RTHOOK(8);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_) = (EIF_INTEGER_32) Result;
	RTHOOK(9);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_) = (EIF_INTEGER_32) arg1;
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {RANDOM}.new_cursor */
EIF_REFERENCE F746_6168 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("new_cursor", 745, Current, 0, 0, 9400);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(745, 0x00).id, 745, _OBJSIZ_0_1_0_4_0_0_0_0_);
	F746_6155(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_));
	RTHOOK(2);
	F505_5257(RTCW(Result));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {RANDOM}.randomize */
EIF_INTEGER_32 F746_6169 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_64 tr8_4;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("randomize", 745, Current, 0, 1, 9378);
	RTGC;
	RTHOOK(1);
	tr8_1 = RTOSCF(6174,F746_6174, (Current));
	tr8_2 = (EIF_REAL_64) (arg1);
	tr8_3 = RTOSCF(6175,F746_6175, (Current));
	tr8_4 = RTOSCF(6173,F746_6173, (Current));
	tr8_1 = F746_6170(Current, (EIF_REAL_64) ((EIF_REAL_64) (tr8_1 * tr8_2) + tr8_3), tr8_4);
	Result = (EIF_INTEGER_32) tr8_1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {RANDOM}.double_mod */
EIF_REAL_64 F746_6170 (EIF_REFERENCE Current, EIF_REAL_64 arg1, EIF_REAL_64 arg2)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("double_mod", 745, Current, 0, 2, 9379);
	RTGC;
	RTHOOK(1);
	Result = (EIF_REAL_64) floor((double) (EIF_REAL_64) ((EIF_REAL_64) (arg1) /  (EIF_REAL_64) (arg2)));
	Result = (EIF_REAL_64) (EIF_REAL_64) (arg1 - (EIF_REAL_64) (Result * arg2));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {RANDOM}.dmod */
static EIF_REAL_64 F746_6173_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dmod", 745, Current, 0, 0, 9382);
	RTGC;
	RTOSP (6173);
#define Result RTOSR(6173)
	RTHOOK(1);
	Result = (EIF_REAL_64) (RTOSCF(6157,F746_6157, (Current)));
	RTOSE (6173);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F746_6173 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6173,F746_6173_body,(Current));
}

/* {RANDOM}.dmul */
static EIF_REAL_64 F746_6174_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dmul", 745, Current, 0, 0, 9383);
	RTGC;
	RTOSP (6174);
#define Result RTOSR(6174)
	RTHOOK(1);
	Result = (EIF_REAL_64) (RTOSCF(6158,F746_6158, (Current)));
	RTOSE (6174);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F746_6174 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6174,F746_6174_body,(Current));
}

/* {RANDOM}.dinc */
static EIF_REAL_64 F746_6175_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dinc", 745, Current, 0, 0, 9384);
	RTGC;
	RTOSP (6175);
#define Result RTOSR(6175)
	RTHOOK(1);
	Result = (EIF_REAL_64) (RTOSCF(6159,F746_6159, (Current)));
	RTOSE (6175);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F746_6175 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6175,F746_6175_body,(Current));
}

void EIF_Minit332 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
