
#ifndef _C7_gt347_
#define _C7_gt347_

#ifdef __cplusplus
extern "C" {
#endif

extern void F919_6614(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern void F919_6617(EIF_REFERENCE);
extern void F919_6619(EIF_REFERENCE);
extern void EIF_Minit347(void);
extern void F115_2201(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
