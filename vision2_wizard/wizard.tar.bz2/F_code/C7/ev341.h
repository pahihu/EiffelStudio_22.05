
#ifndef _C7_ev341_
#define _C7_ev341_

#ifdef __cplusplus
extern "C" {
#endif

extern void F856_6416(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F856_6421(EIF_REFERENCE);
extern EIF_INTEGER_32 F856_6423(EIF_REFERENCE);
extern void EIF_Minit341(void);

#ifdef __cplusplus
}
#endif

#endif
