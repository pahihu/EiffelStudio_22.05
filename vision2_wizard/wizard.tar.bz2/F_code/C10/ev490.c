/*
 * Code for class EV_PICK_AND_DROPABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev490.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PICK_AND_DROPABLE}.configurable_target_menu_handler */
EIF_REFERENCE F1132_9898 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("configurable_target_menu_handler", 1131, Current, 0, 0, 16130);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + O9518[Dtype(tr1)-1274]);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit490 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
