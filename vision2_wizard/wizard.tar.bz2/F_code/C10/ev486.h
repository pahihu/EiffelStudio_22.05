
#ifndef _C10_ev486_
#define _C10_ev486_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1128_9854(EIF_REFERENCE, EIF_REFERENCE);
extern void F1128_9855(EIF_REFERENCE, EIF_REFERENCE);
extern void F1128_9856(EIF_REFERENCE);
extern void EIF_Minit486(void);
extern void F1271_11824(EIF_REFERENCE, EIF_REFERENCE);
extern void F1271_11825(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
