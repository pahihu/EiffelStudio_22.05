
#ifndef _C10_ev474_
#define _C10_ev474_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1116_9710(EIF_REFERENCE);
extern EIF_BOOLEAN F1116_9711(EIF_REFERENCE);
extern void EIF_Minit474(void);
extern long O9429[];
extern long O9430[];
extern long O7674[];

#ifdef __cplusplus
}
#endif

#endif
