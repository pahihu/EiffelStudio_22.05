
#ifndef _C10_ev460_
#define _C10_ev460_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1102_9570(EIF_REFERENCE);
extern void F1102_9571(EIF_REFERENCE);
extern void EIF_Minit460(void);
extern void F1224_11285(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
