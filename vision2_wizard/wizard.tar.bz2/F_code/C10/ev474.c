/*
 * Code for class EV_DOCKABLE_TARGET
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev474.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DOCKABLE_TARGET}.veto_dock_function */
EIF_REFERENCE F1116_9710 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("veto_dock_function", 1115, Current, 0, 0, 15936);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + O9429[Dtype(tr1)-1251]);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DOCKABLE_TARGET}.is_docking_enabled */
EIF_BOOLEAN F1116_9711 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_docking_enabled", 1115, Current, 0, 0, 15937);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1) + O9430[Dtype(tr1)-1251]);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit474 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
