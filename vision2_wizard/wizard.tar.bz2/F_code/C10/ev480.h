
#ifndef _C10_ev480_
#define _C10_ev480_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1122_9743(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1122_9744(EIF_REFERENCE);
extern void F1122_9745(EIF_REFERENCE, EIF_REFERENCE);
extern void F1122_9746(EIF_REFERENCE);
extern void EIF_Minit480(void);
extern void F1061_9071(EIF_REFERENCE, EIF_REFERENCE);
extern void F1091_9344(EIF_REFERENCE);
extern char *(*R9459[])();
extern char *(*R9460[])();
extern long O7674[];

#ifdef __cplusplus
}
#endif

#endif
