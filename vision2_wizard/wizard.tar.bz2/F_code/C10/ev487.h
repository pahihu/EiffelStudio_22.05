
#ifndef _C10_ev487_
#define _C10_ev487_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1129_9859(EIF_REFERENCE);
extern void F1129_9863(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1129_9864(EIF_REFERENCE);
extern void F1129_9865(EIF_REFERENCE);
extern void EIF_Minit487(void);
extern void F1272_11841(EIF_REFERENCE, EIF_REFERENCE);
extern void F1272_11838(EIF_REFERENCE);
extern EIF_REFERENCE F1272_11839(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
