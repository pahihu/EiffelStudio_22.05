/*
 * Code for class EV_POSITIONED
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev472.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_POSITIONED}.screen_x */
EIF_INTEGER_32 F1114_9695 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("screen_x", 1113, Current, 0, 0, 15921);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9307[Dtype(RTCW(tr1))-1271])(tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_POSITIONED}.screen_y */
EIF_INTEGER_32 F1114_9696 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("screen_y", 1113, Current, 0, 0, 15922);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9308[Dtype(RTCW(tr1))-1271])(tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_POSITIONED}.width */
EIF_INTEGER_32 F1114_9697 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("width", 1113, Current, 0, 0, 15923);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9309[Dtype(RTCW(tr1))-1271])(tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_POSITIONED}.height */
EIF_INTEGER_32 F1114_9698 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("height", 1113, Current, 0, 0, 15924);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9310[Dtype(RTCW(tr1))-1271])(tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_POSITIONED}.minimum_width */
EIF_INTEGER_32 F1114_9699 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("minimum_width", 1113, Current, 0, 0, 15925);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = F1228_11377(RTCW(tr1));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_POSITIONED}.minimum_height */
EIF_INTEGER_32 F1114_9700 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("minimum_height", 1113, Current, 0, 0, 15926);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = F1228_11378(RTCW(tr1));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit472 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
