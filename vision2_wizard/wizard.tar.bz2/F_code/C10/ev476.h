
#ifndef _C10_ev476_
#define _C10_ev476_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1118_9722(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit476(void);
extern char *(*R9445[])();
extern long O7674[];

#ifdef __cplusplus
}
#endif

#endif
