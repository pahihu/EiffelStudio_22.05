
#ifndef _C10_ev470_
#define _C10_ev470_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1112_9678(EIF_REFERENCE);
extern EIF_REFERENCE F1112_9679(EIF_REFERENCE);
extern void F1112_9680(EIF_REFERENCE, EIF_REFERENCE);
extern void F1112_9681(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit470(void);
extern EIF_REFERENCE F1245_11645(EIF_REFERENCE);
extern EIF_REFERENCE F1245_11644(EIF_REFERENCE);
extern char *(*R9379[])();
extern char *(*R9380[])();
extern long O7674[];

#ifdef __cplusplus
}
#endif

#endif
