/*
 * Code for class EV_POINTER_STYLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev461.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_POINTER_STYLE}.make_predefined */
void F1103_9575 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_predefined", 1102, Current, 0, 1, 15810);
	RTGC;
	RTHOOK(1);
	F1091_9344(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1226_11324(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_POINTER_STYLE}.set_x_hotspot */
void F1103_9578 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_x_hotspot", 1102, Current, 0, 1, 15813);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1226_11326(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_POINTER_STYLE}.set_y_hotspot */
void F1103_9579 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_y_hotspot", 1102, Current, 0, 1, 15800);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1226_11327(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_POINTER_STYLE}.x_hotspot */
EIF_INTEGER_32 F1103_9580 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("x_hotspot", 1102, Current, 0, 0, 15801);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_POINTER_STYLE}.y_hotspot */
EIF_INTEGER_32 F1103_9581 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("y_hotspot", 1102, Current, 0, 0, 15802);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_1_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_POINTER_STYLE}.width */
EIF_INTEGER_32 F1103_9582 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("width", 1102, Current, 0, 0, 15803);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1226_11329(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_POINTER_STYLE}.height */
EIF_INTEGER_32 F1103_9583 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("height", 1102, Current, 0, 0, 15804);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1226_11330(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_POINTER_STYLE}.copy */
void F1103_9584 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("copy", 1102, Current, 0, 1, 15805);
	RTGC;
	
	RTHOOK(2);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) == NULL)) {
		RTHOOK(3);
		F1091_9344(Current);
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1226_11339(RTCW(tr1), arg1);
	RTHOOK(5);
	ti4_1 = F1103_9580(RTCW(arg1));
	F1103_9578(Current, ti4_1);
	RTHOOK(6);
	ti4_1 = F1103_9581(RTCW(arg1));
	F1103_9579(Current, ti4_1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_POINTER_STYLE}.is_equal */
EIF_BOOLEAN F1103_9585 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_equal", 1102, Current, 0, 1, 15806);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		Result = '\0';
		ti4_1 = F1103_9583(RTCW(arg1));
		ti4_2 = F1103_9582(RTCW(arg1));
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) (F1103_9582(Current) * ti4_1) == (EIF_INTEGER_32) (ti4_2 * F1103_9583(Current)))) {
			tb1 = '\0';
			ti4_1 = F1103_9580(RTCW(arg1));
			if ((EIF_BOOLEAN)(ti4_1 == F1103_9580(Current))) {
				ti4_1 = F1103_9581(RTCW(arg1));
				tb1 = (EIF_BOOLEAN)(ti4_1 == F1103_9581(Current));
			}
			Result = tb1;
		}
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_POINTER_STYLE}.create_interface_objects */
void F1103_9586 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("create_interface_objects", 1102, Current, 0, 0, 15807);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_POINTER_STYLE}.create_implementation */
void F1103_9587 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1102, Current, 0, 0, 15808);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1225, 0x00).id, 1225, _OBJSIZ_1_1_0_3_0_1_0_0_);
	F1226_11322(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit461 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
