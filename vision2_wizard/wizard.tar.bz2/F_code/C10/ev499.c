/*
 * Code for class EV_HORIZONTAL_BOX
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev499.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_HORIZONTAL_BOX}.implementation */
EIF_REFERENCE F1142_10087 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_HORIZONTAL_BOX}.create_implementation */
void F1142_10088 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1141, Current, 0, 0, 16318);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1290, 0x00).id, 1290, _OBJSIZ_49_13_10_7_0_1_0_0_);
	F1291_12196(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit499 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
