/*
 * Code for class EV_CONTAINER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev494.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CONTAINER}.item */
EIF_REFERENCE F1137_10005 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("item", 1136, Current, 0, 0, 16263);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9643[Dtype(RTCW(tr1))-1290])(tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_CONTAINER}.extend */
void F1137_10014 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("extend", 1136, Current, 0, 1, 16238);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9650[Dtype(RTCW(tr1))-1290])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_CONTAINER}.put */
void F1137_10015 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("put", 1136, Current, 1, 1, 16239);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9651[Dtype(RTCW(tr1))-1290])(tr1, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_CONTAINER}.client_width */
EIF_INTEGER_32 F1137_10019 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("client_width", 1136, Current, 0, 0, 16242);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9647[Dtype(RTCW(tr1))-1290])(tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_CONTAINER}.client_height */
EIF_INTEGER_32 F1137_10020 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("client_height", 1136, Current, 0, 0, 16243);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9648[Dtype(RTCW(tr1))-1290])(tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_CONTAINER}.propagate_background_color */
void F1137_10022 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("propagate_background_color", 1136, Current, 0, 0, 16245);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	F1280_12078(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_CONTAINER}.cl_extend */
void F1137_10037 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("cl_extend", 1136, Current, 0, 1, 16260);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8183[Dtype(Current)-1141])(Current, arg1);
	RTHOOK(2);
	RTEE;
}

/* {EV_CONTAINER}.cl_prune */
void F1137_10038 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("cl_prune", 1136, Current, 0, 1, 16261);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8186[Dtype(Current)-1141])(Current, arg1);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit494 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
