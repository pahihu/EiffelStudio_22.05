/*
 * Code for class EV_ACCELERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev456.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ACCELERATOR}.make_with_key_combination */
void F1098_9469 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make_with_key_combination", 1097, Current, 0, 4, 15697);
	RTGC;
	RTHOOK(1);
	F1091_9344(Current);
	RTHOOK(2);
	F1098_9476(Current, arg1);
	RTHOOK(3);
	if (arg2) {
		RTHOOK(4);
		F1098_9481(Current);
	}
	RTHOOK(5);
	if (arg3) {
		RTHOOK(6);
		F1098_9479(Current);
	}
	RTHOOK(7);
	if (arg4) {
		RTHOOK(8);
		F1098_9477(Current);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_ACCELERATOR}.actions */
EIF_REFERENCE F1098_9470 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("actions", 1097, Current, 0, 0, 15698);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1213_10850(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_ACCELERATOR}.key */
EIF_REFERENCE F1098_9472 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("key", 1097, Current, 0, 0, 15700);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_ACCELERATOR}.shift_required */
EIF_BOOLEAN F1098_9473 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("shift_required", 1097, Current, 0, 0, 15701);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_3_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_ACCELERATOR}.alt_required */
EIF_BOOLEAN F1098_9474 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("alt_required", 1097, Current, 0, 0, 15702);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_2_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_ACCELERATOR}.control_required */
EIF_BOOLEAN F1098_9475 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("control_required", 1097, Current, 0, 0, 15703);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_1_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_ACCELERATOR}.set_key */
void F1098_9476 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_key", 1097, Current, 0, 1, 15704);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1214_10868(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_ACCELERATOR}.enable_shift_required */
void F1098_9477 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_shift_required", 1097, Current, 0, 0, 15705);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1214_10869(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_ACCELERATOR}.enable_alt_required */
void F1098_9479 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_alt_required", 1097, Current, 0, 0, 15707);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1214_10871(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_ACCELERATOR}.enable_control_required */
void F1098_9481 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_control_required", 1097, Current, 0, 0, 15709);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1214_10873(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_ACCELERATOR}.is_equal */
EIF_BOOLEAN F1098_9483 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("is_equal", 1097, Current, 0, 1, 15711);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	tr1 = F1098_9472(Current);
	tr2 = F1098_9472(RTCW(arg1));
	tb3 = (EIF_BOOLEAN) eif_builtin_ANY_is_equal__o_b (tr1, tr2);
	if (tb3) {
		tb3 = F1098_9474(RTCW(arg1));
		tb2 = (EIF_BOOLEAN)(F1098_9474(Current) == tb3);
	}
	if (tb2) {
		tb2 = F1098_9473(RTCW(arg1));
		tb1 = (EIF_BOOLEAN)(F1098_9473(Current) == tb2);
	}
	if (tb1) {
		tb1 = F1098_9475(RTCW(arg1));
		Result = (EIF_BOOLEAN)(F1098_9475(Current) == tb1);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_ACCELERATOR}.text */
EIF_REFERENCE F1098_9484 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("text", 1097, Current, 1, 0, 15712);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1061_9063(RTCW(Result), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	if (F1098_9475(Current)) {
		RTHOOK(3);
		tr1 = F1054_8826(RTMS_EX_H("Ctrl+",5,1954170411));
		F1063_9178(RTCW(Result), tr1);
	}
	RTHOOK(4);
	if (F1098_9474(Current)) {
		RTHOOK(5);
		tr1 = F1054_8826(RTMS_EX_H("Alt+",4,1097626667));
		F1063_9178(RTCW(Result), tr1);
	}
	RTHOOK(6);
	if (F1098_9473(Current)) {
		RTHOOK(7);
		tr1 = F1054_8826(RTMS_EX_H("Shift+",6,1932305451));
		F1063_9178(RTCW(Result), tr1);
	}
	RTHOOK(8);
	loc1 = F1395_13893(RTCV(F1098_9472(Current)));
	RTHOOK(9);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(10);
		F1063_9220(RTCW(loc1));
	}
	RTHOOK(11);
	F1063_9178(RTCW(Result), loc1);
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_ACCELERATOR}.out */
EIF_REFERENCE F1098_9485 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("out", 1097, Current, 0, 0, 15713);
	RTGC;
	RTHOOK(1);
	Result = F1054_8821(RTCV(F1098_9484(Current)));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_ACCELERATOR}.create_interface_objects */
void F1098_9487 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("create_interface_objects", 1097, Current, 0, 0, 15693);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_ACCELERATOR}.create_implementation */
void F1098_9488 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1097, Current, 0, 0, 15694);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1213, 0x00).id, 1213, _OBJSIZ_3_5_0_0_0_0_0_0_);
	F1214_10863(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit456 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
