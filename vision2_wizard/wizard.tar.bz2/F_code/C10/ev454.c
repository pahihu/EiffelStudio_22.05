/*
 * Code for class EV_COLOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev454.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_COLOR}.make_with_8_bit_rgb */
void F1096_9421 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_with_8_bit_rgb", 1095, Current, 0, 3, 15662);
	RTGC;
	RTHOOK(1);
	F1091_9344(Current);
	RTHOOK(2);
	F1096_9441(Current, arg1);
	RTHOOK(3);
	F1096_9442(Current, arg2);
	RTHOOK(4);
	F1096_9443(Current, arg3);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_COLOR}.make_with_rgb */
void F1096_9422 (EIF_REFERENCE Current, EIF_REAL_32 arg1, EIF_REAL_32 arg2, EIF_REAL_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_with_rgb", 1095, Current, 0, 3, 15663);
	RTGC;
	RTHOOK(1);
	F1091_9344(Current);
	RTHOOK(2);
	F1096_9432(Current, arg1);
	RTHOOK(3);
	F1096_9433(Current, arg2);
	RTHOOK(4);
	F1096_9434(Current, arg3);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_COLOR}.red */
EIF_REAL_32 F1096_9423 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("red", 1095, Current, 0, 0, 15664);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_REAL_32 *)(RTCW(tr1)+ _R32OFF_2_1_0_3_2_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR}.green */
EIF_REAL_32 F1096_9424 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("green", 1095, Current, 0, 0, 15665);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_REAL_32 *)(RTCW(tr1)+ _R32OFF_2_1_0_3_1_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR}.blue */
EIF_REAL_32 F1096_9425 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("blue", 1095, Current, 0, 0, 15666);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_REAL_32 *)(RTCW(tr1)+ _R32OFF_2_1_0_3_0_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR}.set_red */
void F1096_9432 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_red", 1095, Current, 0, 1, 15673);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1211_10817(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_COLOR}.set_green */
void F1096_9433 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_green", 1095, Current, 0, 1, 15674);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1211_10818(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_COLOR}.set_blue */
void F1096_9434 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_blue", 1095, Current, 0, 1, 15675);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1211_10819(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_COLOR}.rgb_24_bit */
EIF_INTEGER_32 F1096_9435 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("rgb_24_bit", 1095, Current, 0, 0, 15676);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1211_10821(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR}.red_8_bit */
EIF_INTEGER_32 F1096_9438 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("red_8_bit", 1095, Current, 0, 0, 15679);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1211_10823(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR}.green_8_bit */
EIF_INTEGER_32 F1096_9439 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("green_8_bit", 1095, Current, 0, 0, 15680);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1211_10824(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR}.blue_8_bit */
EIF_INTEGER_32 F1096_9440 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("blue_8_bit", 1095, Current, 0, 0, 15681);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1211_10825(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR}.set_red_with_8_bit */
void F1096_9441 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_red_with_8_bit", 1095, Current, 0, 1, 15682);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1211_10826(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_COLOR}.set_green_with_8_bit */
void F1096_9442 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_green_with_8_bit", 1095, Current, 0, 1, 15683);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1211_10827(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_COLOR}.set_blue_with_8_bit */
void F1096_9443 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_blue_with_8_bit", 1095, Current, 0, 1, 15642);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1211_10828(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_COLOR}.red_16_bit */
EIF_INTEGER_32 F1096_9445 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("red_16_bit", 1095, Current, 0, 0, 15644);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_1_0_2_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR}.green_16_bit */
EIF_INTEGER_32 F1096_9446 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("green_16_bit", 1095, Current, 0, 0, 15645);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_1_0_1_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR}.blue_16_bit */
EIF_INTEGER_32 F1096_9447 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("blue_16_bit", 1095, Current, 0, 0, 15646);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_1_0_0_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR}.out */
EIF_REFERENCE F1096_9451 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("out", 1095, Current, 1, 0, 15650);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1411, 0x00).id, 1411, _OBJSIZ_1_8_0_4_0_0_0_0_);
	F1412_14285(RTCW(loc1), ((EIF_INTEGER_32) 6L), ((EIF_INTEGER_32) 4L));
	RTHOOK(2);
	tr8_1 = (EIF_REAL_64) (F1096_9423(Current));
	tr1 = F1412_14303(RTCW(loc1), tr8_1);
	tr2 = RTMS_EX_H(" ",1,32);
	tr1 = F1059_9029(RTCW(tr1), tr2);
	tr8_1 = (EIF_REAL_64) (F1096_9424(Current));
	tr2 = F1412_14303(RTCW(loc1), tr8_1);
	tr1 = F1059_9029(RTCW(tr1), tr2);
	tr2 = RTMS_EX_H(" ",1,32);
	tr1 = F1059_9029(RTCW(tr1), tr2);
	tr8_1 = (EIF_REAL_64) (F1096_9425(Current));
	tr2 = F1412_14303(RTCW(loc1), tr8_1);
	Result = F1059_9029(RTCW(tr1), tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR}.is_equal */
EIF_BOOLEAN F1096_9452 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REAL_32 loc1 = (EIF_REAL_32) 0;
	EIF_REAL_32 tr4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("is_equal", 1095, Current, 1, 1, 15651);
	RTGC;
	RTHOOK(1);
	loc1 = F1096_9458(Current);
	RTHOOK(2);
	Result = '\0';
	tb1 = '\0';
	tr4_1 = F1096_9423(RTCW(arg1));
	tr4_1 = eif_abs_real32 ((EIF_REAL_32) (tr4_1 - F1096_9423(Current)));
	if ((EIF_BOOLEAN) eif_is_less_real_32 (tr4_1, loc1)) {
		tr4_1 = F1096_9424(RTCW(arg1));
		tr4_1 = eif_abs_real32 ((EIF_REAL_32) (tr4_1 - F1096_9424(Current)));
		tb1 = (EIF_BOOLEAN) eif_is_less_real_32 (tr4_1, loc1);
	}
	if (tb1) {
		tr4_1 = F1096_9425(RTCW(arg1));
		tr4_1 = eif_abs_real32 ((EIF_REAL_32) (tr4_1 - F1096_9425(Current)));
		Result = (EIF_BOOLEAN) eif_is_less_real_32 (tr4_1, loc1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR}.copy */
void F1096_9453 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("copy", 1095, Current, 0, 1, 15652);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) == NULL)) {
		RTHOOK(2);
		F1091_9344(Current);
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1211_10835(RTCW(tr1), arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_COLOR}.hash_code */
EIF_INTEGER_32 F1096_9454 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("hash_code", 1095, Current, 0, 0, 15653);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) F1096_9435(Current);
}

/* {EV_COLOR}.delta */
EIF_REAL_32 F1096_9458 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("delta", 1095, Current, 0, 0, 15657);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1211_10836(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR}.create_interface_objects */
void F1096_9460 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("create_interface_objects", 1095, Current, 0, 0, 15659);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_COLOR}.create_implementation */
void F1096_9461 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1095, Current, 0, 0, 15660);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1210, 0x00).id, 1210, _OBJSIZ_2_1_0_3_3_0_0_0_);
	F1211_10812(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit454 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
