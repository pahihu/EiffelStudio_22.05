/*
 * Code for class BENCH_WIZARD_MANAGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "be467.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BENCH_WIZARD_MANAGER}.make_and_launch */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1109_9657 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEAA("make_and_launch", 1108, Current, 2, 0, 15881);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(2);
		loc2 = RTLNS(eif_new_type(1422, 0x00).id, 1422, _OBJSIZ_0_3_0_0_0_0_0_0_);
		RTHOOK(3);
		F1421_14516(RTCW(loc2));
		RTHOOK(4);
		F283_4387(Current, loc2);
		RTHOOK(5);
		F1108_9653(Current);
	} else {
		RTHOOK(6);
		F339_4955(Current);
	}
	RTE_E
	RTXSC;
	RTHOOK(7);
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(8);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(9);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {BENCH_WIZARD_MANAGER}.prepare */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1109_9658 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr2 = NULL;
	RTLD;
	RTXD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,saved_except);
	RTLIU(5);
	RTXSLS;
	
	RTEAA("prepare", 1108, Current, 2, 0, 15882);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc2) {
		RTHOOK(2);
		F1109_9659(Current);
		RTHOOK(3);
		F1108_9654(Current);
		RTHOOK(4);
		tr1 = RTLNS(eif_new_type(1159, 0x00).id, 1159, _OBJSIZ_6_3_0_1_0_0_0_0_);
		F1091_9344(RTCW(tr1));
		loc1 = (EIF_REFERENCE) tr1;
		RTHOOK(5);
		tr1 = RTOSCF(2736,F124_2736, (Current));
		tr2 = RTMS_EX_H("wizard.png",10,1759219815);
		tr1 = F940_7471(RTCW(tr1), tr2);
		F1160_10312(RTCW(loc1), tr1);
		RTHOOK(6);
		tr1 = F124_2731(Current);
		F1150_10192(RTCW(tr1), loc1);
	}
	RTE_E
	RTXSC;
	RTHOOK(7);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(8);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(9);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {BENCH_WIZARD_MANAGER}.setup_locale */
void F1109_9659 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("setup_locale", 1108, Current, 2, 0, 15883);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1397, 0x00).id, 1397, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(14550,F1421_14550, (RTCV(F283_4388(Current))));
	tr1 = F940_7483(RTCW(tr1));
	F1398_13961(RTCW(loc1), tr1);
	RTHOOK(2);
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count__i4 >= ((EIF_INTEGER_32) 2L))) {
		RTHOOK(3);
		tr1 = RTLNS(eif_new_type(1398, 0x00).id, 1398, _OBJSIZ_6_0_0_0_0_0_0_0_);
		tr2 = F338_4932(Current, ((EIF_INTEGER_32) 2L));
		F1399_13972(RTCW(tr1), tr2);
		loc2 = F1398_13962(RTCW(loc1), tr1);
	}
	RTHOOK(4);
	tr1 = RTOSCF(2767,F124_2767, (Current));
	F212_3852(RTCW(tr1), loc2);
	RTHOOK(5);
	RTLE;
	RTEE;
}

void EIF_Minit467 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
