/*
 * Code for class EV_DIRECTORY_DIALOG
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev487.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DIRECTORY_DIALOG}.path */
EIF_REFERENCE F1129_9859 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("path", 1128, Current, 0, 0, 16088);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1272_11839(RTCW(tr1));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DIRECTORY_DIALOG}.set_start_path */
void F1129_9863 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_start_path", 1128, Current, 0, 1, 16092);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1272_11841(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DIRECTORY_DIALOG}.implementation */
EIF_REFERENCE F1129_9864 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {EV_DIRECTORY_DIALOG}.create_implementation */
void F1129_9865 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1128, Current, 0, 0, 16094);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1271, 0x00).id, 1271, _OBJSIZ_9_5_0_1_0_1_0_0_);
	F1272_11838(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit487 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
