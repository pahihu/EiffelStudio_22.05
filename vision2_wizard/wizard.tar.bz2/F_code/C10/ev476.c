/*
 * Code for class EV_PIXMAPABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev476.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PIXMAPABLE}.set_pixmap */
void F1118_9722 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_pixmap", 1117, Current, 0, 1, 15949);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9445[Dtype(RTCW(tr1))-1290])(tr1, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit476 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
