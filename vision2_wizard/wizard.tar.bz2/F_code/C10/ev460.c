/*
 * Code for class EV_PIXEL_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev460.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PIXEL_BUFFER}.create_interface_objects */
void F1102_9570 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("create_interface_objects", 1101, Current, 0, 0, 15795);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_PIXEL_BUFFER}.create_implementation */
void F1102_9571 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1101, Current, 0, 0, 15796);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1223, 0).id);
	F1224_11285(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit460 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
