/*
 * Code for class EV_TEXTABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev480.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TEXTABLE}.make_with_text */
void F1122_9743 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make_with_text", 1121, Current, 0, 1, 15971);
	RTGC;
	RTHOOK(1);
	F1091_9344(Current);
	RTHOOK(2);
	F1122_9745(Current, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_TEXTABLE}.text */
EIF_REFERENCE F1122_9744 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("text", 1121, Current, 0, 0, 15972);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9459[Dtype(RTCW(tr1))-1301])(tr1);
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_TEXTABLE}.set_text */
void F1122_9745 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("set_text", 1121, Current, 1, 1, 15973);
	RTGC;
	RTHOOK(1);
	loc1 = arg1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + O7674[dtype-1090]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9460[Dtype(RTCW(tr1))-1301])(tr1, loc1);
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + O7674[dtype-1090]);
		tr2 = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1061_9071(RTCW(tr2), arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9460[Dtype(RTCW(tr1))-1301])(tr1, tr2);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_TEXTABLE}.remove_text */
void F1122_9746 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("remove_text", 1121, Current, 0, 0, 15974);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS_EX_H("",0,0);
	F1122_9745(Current, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit480 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
