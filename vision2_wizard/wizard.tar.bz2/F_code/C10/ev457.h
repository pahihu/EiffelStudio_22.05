
#ifndef _C10_ev457_
#define _C10_ev457_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1099_9490(EIF_REFERENCE);
extern void F1099_9502(EIF_REFERENCE);
extern void F1099_9503(EIF_REFERENCE);
extern void EIF_Minit457(void);
extern EIF_REFERENCE F1091_9356(EIF_REFERENCE);
extern void F1201_10658(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1201_10653(EIF_REFERENCE, EIF_INTEGER_8, EIF_BOOLEAN);
extern EIF_REFERENCE F1219_10982(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,9356)

#ifdef __cplusplus
}
#endif

#endif
