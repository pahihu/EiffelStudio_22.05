
#ifndef _C10_ev478_
#define _C10_ev478_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1120_9735(EIF_REFERENCE);
extern EIF_BOOLEAN F1120_9736(EIF_REFERENCE);
extern void F1120_9737(EIF_REFERENCE);
extern void EIF_Minit478(void);
extern EIF_BOOLEAN F1353_13189(EIF_REFERENCE);
extern EIF_BOOLEAN F1254_11723(EIF_REFERENCE);
extern void F1353_13187(EIF_REFERENCE);
extern long O7674[];

#ifdef __cplusplus
}
#endif

#endif
