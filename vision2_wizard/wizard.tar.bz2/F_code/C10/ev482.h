
#ifndef _C10_ev482_
#define _C10_ev482_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1124_9758(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit482(void);
extern char *(*R9455[])();
extern long O7674[];

#ifdef __cplusplus
}
#endif

#endif
