
#ifndef _C10_ev481_
#define _C10_ev481_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1123_9753(EIF_REFERENCE);
extern void F1123_9755(EIF_REFERENCE);
extern void EIF_Minit481(void);
extern char *(*R9472[])();
extern char *(*R9473[])();
extern long O7674[];

#ifdef __cplusplus
}
#endif

#endif
