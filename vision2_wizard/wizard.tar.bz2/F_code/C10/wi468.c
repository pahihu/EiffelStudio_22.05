/*
 * Code for class WIZARD_MANAGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi468.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_MANAGER}.wizard_title */
static EIF_REFERENCE F1110_9660_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("wizard_title", 1109, Current, 0, 0, 15884);
	RTGC;
	RTOSP (9660);
#define Result RTOSR(9660)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = F127_2827(RTCV(RTOSCF(4390,F284_4390, (Current))));
	RTOSE (9660);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1110_9660 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9660,F1110_9660_body,(Current));
}

/* {WIZARD_MANAGER}.wizard_factory */
static EIF_REFERENCE F1110_9661_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("wizard_factory", 1109, Current, 0, 0, 15885);
	RTGC;
	RTOSP (9661);
#define Result RTOSR(9661)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(157, 0x00).id, 157, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9661);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1110_9661 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9661,F1110_9661_body,(Current));
}

void EIF_Minit468 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
