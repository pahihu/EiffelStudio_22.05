
#ifndef _C10_ev490_
#define _C10_ev490_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1132_9898(EIF_REFERENCE);
extern void EIF_Minit490(void);
extern long O9518[];
extern long O7674[];

#ifdef __cplusplus
}
#endif

#endif
