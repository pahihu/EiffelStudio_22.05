/*
 * Code for class EV_IDENTIFIABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev462.h"
#include "eif_built_in.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_IDENTIFIABLE}.identifier_name */
EIF_REFERENCE F1104_9590 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("identifier_name", 1103, Current, 1, 0, 15814);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7865[dtype-1103]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc1);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7859[dtype-1141])(Current);
	}/* NOTREACHED */
	
}

/* {EV_IDENTIFIABLE}.default_identifier_name */
EIF_REFERENCE F1104_9591 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("default_identifier_name", 1103, Current, 0, 0, 15815);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("{\000\000\000",1,123);
	tr2 = F941_7504(RTCV((EIF_REFERENCE) eif_builtin_ANY_generating_type__t (Current)));
	tr1 = F1063_9197(tr1, tr2);
	tr2 = F1054_8826(RTMS_EX_H("}",1,125));
	Result = F1063_9197(RTCW(tr1), tr2);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_IDENTIFIABLE}.debug_output */
EIF_REFERENCE F1104_9593 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("debug_output", 1103, Current, 0, 0, 15817);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1061_9063(RTCW(Result), ((EIF_INTEGER_32) 10L));
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '<';
	F1063_9191(RTCW(Result), tw1);
	RTHOOK(3);
	tr1 = eif_out__p_s1(Current);
	tr1 = F1054_8826(RTCW(tr1));
	F1063_9178(RTCW(Result), tr1);
	RTHOOK(4);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
	F1063_9191(RTCW(Result), tw1);
	RTHOOK(5);
	if (F1104_9595(Current)) {
		RTHOOK(6);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F1063_9191(RTCW(Result), tw1);
		RTHOOK(7);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		F1063_9191(RTCW(Result), tw1);
		RTHOOK(8);
		tr1 = F1104_9590(Current);
		F1063_9178(RTCW(Result), tr1);
		RTHOOK(9);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		F1063_9191(RTCW(Result), tw1);
		RTHOOK(10);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F1063_9191(RTCW(Result), tw1);
	}
	RTHOOK(11);
	tr1 = F941_7504(RTCV((EIF_REFERENCE) eif_builtin_ANY_generating_type__t (Current)));
	F1063_9178(RTCW(Result), tr1);
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_IDENTIFIABLE}.has_identifier_name_set */
EIF_BOOLEAN F1104_9595 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("has_identifier_name_set", 1103, Current, 0, 0, 15819);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O7865[Dtype(Current)-1103]) != NULL);
}

void EIF_Minit462 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
