/*
 * Code for class EV_DRAWABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev483.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DRAWABLE}.line_width */
EIF_INTEGER_32 F1125_9760 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("line_width", 1124, Current, 0, 0, 16002);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1) + O10449[Dtype(tr1)-1385]);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DRAWABLE}.set_line_width */
void F1125_9768 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_line_width", 1124, Current, 0, 1, 16008);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R10319[Dtype(RTCW(tr1))-1386])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE}.enable_dashed_line_style */
void F1125_9776 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_dashed_line_style", 1124, Current, 0, 0, 16016);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10326[Dtype(RTCW(tr1))-1386])(tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE}.start_drawing_session */
void F1125_9778 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("start_drawing_session", 1124, Current, 0, 0, 16018);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10332[Dtype(RTCW(tr1))-1386])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE}.end_drawing_session */
void F1125_9779 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("end_drawing_session", 1124, Current, 0, 0, 16019);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10333[Dtype(RTCW(tr1))-1386])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE}.clear */
void F1125_9780 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("clear", 1124, Current, 0, 0, 16020);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	F1386_13630(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE}.draw_point */
void F1125_9782 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("draw_point", 1124, Current, 0, 2, 16022);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R10337[Dtype(RTCW(tr1))-1386])(tr1, arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE}.draw_segment */
void F1125_9788 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("draw_segment", 1124, Current, 0, 4, 16028);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R10343[Dtype(RTCW(tr1))-1386])(tr1, arg1, arg2, arg3, arg4);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE}.draw_pixmap */
void F1125_9790 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTEAA("draw_pixmap", 1124, Current, 0, 3, 16030);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	F1386_13644(RTCW(tr1), arg1, arg2, arg3);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE}.draw_ellipse */
void F1125_9795 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("draw_ellipse", 1124, Current, 0, 4, 16035);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R10350[Dtype(RTCW(tr1))-1386])(tr1, arg1, arg2, arg3, arg4);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE}.fill_rectangle */
void F1125_9798 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("fill_rectangle", 1124, Current, 0, 4, 15989);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R10353[Dtype(RTCW(tr1))-1386])(tr1, arg1, arg2, arg3, arg4);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE}.fill_ellipse */
void F1125_9799 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("fill_ellipse", 1124, Current, 0, 4, 15990);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R10354[Dtype(RTCW(tr1))-1386])(tr1, arg1, arg2, arg3, arg4);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DRAWABLE}.set_invert_mode */
void F1125_9804 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_invert_mode", 1124, Current, 0, 0, 15995);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R10320[Dtype(RTCW(tr1))-1386])(tr1, ((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit483 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
