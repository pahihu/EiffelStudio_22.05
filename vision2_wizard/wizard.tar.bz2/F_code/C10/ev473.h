
#ifndef _C10_ev473_
#define _C10_ev473_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1115_9703(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1115_9704(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1115_9708(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit473(void);
extern void F1229_11419(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1229_11415(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1229_11418(EIF_REFERENCE, EIF_INTEGER_32);
extern long O7674[];

#ifdef __cplusplus
}
#endif

#endif
