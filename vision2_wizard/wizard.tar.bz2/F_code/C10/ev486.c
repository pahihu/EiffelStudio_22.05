/*
 * Code for class EV_STANDARD_DIALOG
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev486.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STANDARD_DIALOG}.show_modal_to_window */
void F1128_9854 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("show_modal_to_window", 1127, Current, 0, 1, 16083);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1271_11824(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_STANDARD_DIALOG}.set_title */
void F1128_9855 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_title", 1127, Current, 0, 1, 16084);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1271_11825(RTCW(tr1), arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_STANDARD_DIALOG}.create_interface_objects */
void F1128_9856 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("create_interface_objects", 1127, Current, 0, 0, 16085);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit486 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
