
#ifndef _C10_ev499_
#define _C10_ev499_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1142_10087(EIF_REFERENCE);
extern void F1142_10088(EIF_REFERENCE);
extern void EIF_Minit499(void);
extern void F1291_12196(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
