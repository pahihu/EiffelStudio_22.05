/*
 * Code for class EV_TEXT_ALIGNABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev481.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TEXT_ALIGNABLE}.align_text_center */
void F1123_9753 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("align_text_center", 1122, Current, 0, 0, 15982);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R9472[Dtype(RTCW(tr1))-1301])(tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_TEXT_ALIGNABLE}.align_text_left */
void F1123_9755 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("align_text_left", 1122, Current, 0, 0, 15984);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R9473[Dtype(RTCW(tr1))-1301])(tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit481 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
