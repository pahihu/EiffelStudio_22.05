
#ifndef _C17_ty839_
#define _C17_ty839_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F770_6243(EIF_REFERENCE);
extern void EIF_Minit839(void);
extern char *(*R5485[])();
extern char *(*R4944[])();
extern char *(*R5472[])();

#ifdef __cplusplus
}
#endif

#endif
