
#ifndef _C17_re840_
#define _C17_re840_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F576_5329(EIF_REFERENCE);
extern void EIF_Minit840(void);
extern void F782_6249(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5484[])();
extern EIF_TYPE_INDEX Y4668[];
extern EIF_TYPE_INDEX *Y4668_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
