
#ifndef _C17_bi849_
#define _C17_bi849_

#ifdef __cplusplus
extern "C" {
#endif

extern void F399_5210(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit849(void);
extern EIF_BOOLEAN F639_5503(EIF_REFERENCE);
extern void F690_5958(EIF_REFERENCE);
extern void F387_5193(EIF_REFERENCE, EIF_NATURAL_64);
extern EIF_BOOLEAN F507_5267(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
