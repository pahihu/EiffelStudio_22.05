
#ifndef _C17_li808_
#define _C17_li808_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F638_5501(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F638_5502(EIF_REFERENCE);
extern EIF_BOOLEAN F638_5503(EIF_REFERENCE);
extern void EIF_Minit808(void);
extern char *(*R4909[])();
extern char *(*R4875[])();
extern char *(*R4915[])();
extern char *(*R4917[])();
extern char *(*R4764[])();
extern char *(*R4882[])();
extern char *(*R4886[])();
extern char *(*R4888[])();
extern char *(*R4921[])();
extern long O4766[];

#ifdef __cplusplus
}
#endif

#endif
