
#ifndef _C17_to846_
#define _C17_to846_

#ifdef __cplusplus
extern "C" {
#endif

extern void F308_4843(EIF_REFERENCE, EIF_INTEGER_32);
extern void F308_4844(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern void F308_4850(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit846(void);
extern void F860_6493(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4606[];
extern EIF_TYPE_INDEX *Y4606_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
