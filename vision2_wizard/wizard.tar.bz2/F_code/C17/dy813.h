
#ifndef _C17_dy813_
#define _C17_dy813_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F452_5233(EIF_REFERENCE);
extern void EIF_Minit813(void);

#ifdef __cplusplus
}
#endif

#endif
