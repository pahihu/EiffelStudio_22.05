/*
 * Code for class BILINEAR [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi849.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BILINEAR}.search */
void F399_5210 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 398, Current, 0, 1, 5602);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (F639_5503(Current)) {
		tb1 = (EIF_BOOLEAN) !F507_5267(Current);
	}
	if (tb1) {
		RTHOOK(2);
		F690_5958(Current);
	}
	RTHOOK(3);
	F387_5193(Current, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit849 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
