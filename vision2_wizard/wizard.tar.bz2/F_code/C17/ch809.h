
#ifndef _C17_ch809_
#define _C17_ch809_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F614_5463(EIF_REFERENCE);
extern EIF_REFERENCE F614_5464(EIF_REFERENCE);
extern EIF_BOOLEAN F614_5465(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F614_5467(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F614_5468(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F614_5470(EIF_REFERENCE);
extern void F614_5472(EIF_REFERENCE);
extern EIF_BOOLEAN F614_5475(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F614_5476(EIF_REFERENCE);
extern EIF_BOOLEAN F614_5478(EIF_REFERENCE);
extern void F614_5483(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit809(void);
extern EIF_BOOLEAN F386_5191(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4909[])();
extern char *(*R4873[])();
extern char *(*R4874[])();
extern char *(*R4875[])();
extern char *(*R4915[])();
extern char *(*R4917[])();
extern char *(*R4764[])();
extern char *(*R4882[])();
extern char *(*R4887[])();
extern char *(*R4888[])();
extern char *(*R5034[])();
extern char *(*R4921[])();
extern char *(*R4770[])();
extern char *(*R4891[])();
extern char *(*R4895[])();

#ifdef __cplusplus
}
#endif

#endif
