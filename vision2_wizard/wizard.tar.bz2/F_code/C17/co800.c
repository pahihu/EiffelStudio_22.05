/*
 * Code for class CONTAINER [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co800.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F359_5038 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("compare_objects", 358, Current, 0, 0, 5199);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O4766[Dtype(Current)-358]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTEE;
}

/* {CONTAINER}.compare_references */
void F359_5039 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("compare_references", 358, Current, 0, 0, 5200);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O4766[Dtype(Current)-358]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit800 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
