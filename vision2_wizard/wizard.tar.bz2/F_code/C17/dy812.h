
#ifndef _C17_dy812_
#define _C17_dy812_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F626_5487(EIF_REFERENCE);
extern void F626_5493(EIF_REFERENCE, EIF_REFERENCE);
extern void F626_5494(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit812(void);
extern char *(*R4875[])();
extern char *(*R4914[])();
extern char *(*R4881[])();
extern char *(*R4885[])();

#ifdef __cplusplus
}
#endif

#endif
