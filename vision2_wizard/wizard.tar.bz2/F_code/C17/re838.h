
#ifndef _C17_re838_
#define _C17_re838_

#ifdef __cplusplus
extern "C" {
#endif

extern void F782_6249(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F782_6251(EIF_REFERENCE);
extern EIF_INTEGER_32 F782_6252(EIF_REFERENCE);
extern EIF_INTEGER_32 F782_6253(EIF_REFERENCE);
extern EIF_INTEGER_32 F782_6254(EIF_REFERENCE);
extern EIF_BOOLEAN F782_6261(EIF_REFERENCE);
extern EIF_BOOLEAN F782_6262(EIF_REFERENCE);
extern EIF_BOOLEAN F782_6263(EIF_REFERENCE);
extern void F782_6268(EIF_REFERENCE);
extern void F782_6269(EIF_REFERENCE);
extern EIF_REFERENCE F782_6270(EIF_REFERENCE);
extern void EIF_Minit838(void);
extern char *(*R4945[])();
extern char *(*R4946[])();
extern char *(*R4948[])();

#ifdef __cplusplus
}
#endif

#endif
