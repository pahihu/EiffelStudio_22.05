/*
 * Code for class LIST [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li808.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LIST}.is_equal */
EIF_BOOLEAN F638_5501 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("is_equal", 637, Current, 2, 1, 7188);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		Result = '\0';
		tb1 = '\0';
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4764[Dtype(RTCW(arg1))-372])(arg1);
		if ((EIF_BOOLEAN)((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4764[dtype-372])(Current) == tb2)) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O4766[Dtype(arg1)-358]);
			tb1 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O4766[dtype-358]) == tb2);
		}
		if (tb1) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4921[Dtype(RTCW(arg1))-600])(arg1);
			Result = (EIF_BOOLEAN)((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4921[dtype-600])(Current) == ti4_1);
		}
		RTHOOK(5);
		tb1 = '\0';
		if (Result) {
			tb1 = (EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4764[dtype-372])(Current);
		}
		if (tb1) {
			RTHOOK(6);
			tb1 = '\0';
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4915[dtype-661])(Current);
			loc1 = tr1;
			if (EIF_TEST(loc1)) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4915[Dtype(RTCW(arg1))-661])(arg1);
				loc2 = tr1;
				tb1 = EIF_TEST(loc2);
			}
			if (tb1) {
				RTHOOK(7);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R4875[dtype-661])(Current);
				RTHOOK(8);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R4875[Dtype(RTCW(arg1))-661])(arg1);
				for (;;) {
					RTHOOK(9);
					tb1 = '\01';
					if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4886[dtype-661])(Current)) {
						tb1 = (EIF_BOOLEAN) !Result;
					}
					if (tb1) break;
					RTHOOK(10);
					if (*(EIF_BOOLEAN *)(Current + O4766[dtype-358])) {
						RTHOOK(11);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4909[dtype-661])(Current);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4909[Dtype(RTCW(arg1))-661])(arg1);
						Result = (EIF_BOOLEAN) RTEQ(tr1, tr2);
					} else {
						RTHOOK(12);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4909[dtype-661])(Current);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4909[Dtype(RTCW(arg1))-661])(arg1);
						Result = (EIF_BOOLEAN) RTCEQ(tr1, tr2);
					}
					RTHOOK(13);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R4888[dtype-661])(Current);
					RTHOOK(14);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R4888[Dtype(RTCW(arg1))-661])(arg1);
				}
				RTHOOK(15);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4917[dtype-661])(Current, loc1);
				RTHOOK(16);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4917[Dtype(RTCW(arg1))-661])(arg1, loc2);
			} else {
				
			}
		} else {
			RTHOOK(18);
			tb2 = '\0';
			tb3 = '\0';
			if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4764[dtype-372])(Current)) {
				tb4 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4764[Dtype(RTCW(arg1))-372])(arg1);
				tb3 = tb4;
			}
			if (tb3) {
				tb3 = *(EIF_BOOLEAN *)(RTCW(arg1) + O4766[Dtype(arg1)-358]);
				tb2 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O4766[dtype-358]) == tb3);
			}
			if (tb2) {
				RTHOOK(19);
				RTHOOK(20);
				RTLE;
				RTEE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	RTHOOK(23);
	RTLE;
	RTEE;
	return Result;
}

/* {LIST}.after */
EIF_BOOLEAN F638_5502 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("after", 637, Current, 0, 0, 7189);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4882[dtype-661])(Current);
	ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4921[dtype-600])(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {LIST}.before */
EIF_BOOLEAN F638_5503 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("before", 637, Current, 0, 0, 7190);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4882[Dtype(Current)-661])(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit808 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
