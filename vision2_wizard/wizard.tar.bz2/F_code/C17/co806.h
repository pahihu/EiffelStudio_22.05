
#ifndef _C17_co806_
#define _C17_co806_

#ifdef __cplusplus
extern "C" {
#endif

extern void F410_5218(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit806(void);
extern char *(*R4763[])();
extern char *(*R4897[])();

#ifdef __cplusplus
}
#endif

#endif
