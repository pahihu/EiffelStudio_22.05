
#ifndef _C17_re816_
#define _C17_re816_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F530_5273(EIF_REFERENCE);
extern void F530_5275(EIF_REFERENCE);
extern void EIF_Minit816(void);
extern char *(*R4922[])();
extern char *(*R4926[])();
extern char *(*R4928[])();

#ifdef __cplusplus
}
#endif

#endif
