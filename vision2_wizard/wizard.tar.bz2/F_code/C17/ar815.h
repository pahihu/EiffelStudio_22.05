
#ifndef _C17_ar815_
#define _C17_ar815_

#ifdef __cplusplus
extern "C" {
#endif

extern void F815_6309(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F815_6310(EIF_REFERENCE);
extern EIF_REFERENCE F815_6313(EIF_REFERENCE);
extern EIF_INTEGER_32 F815_6314(EIF_REFERENCE);
extern void EIF_Minit815(void);
extern char *(*R5325[])();
extern char *(*R5329[])();

#ifdef __cplusplus
}
#endif

#endif
