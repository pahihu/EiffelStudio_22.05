/*
 * Code for class DYNAMIC_CHAIN [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dy812.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DYNAMIC_CHAIN}.extendible */
EIF_BOOLEAN F626_5487 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("extendible", 625, Current, 0, 0, 7116);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {DYNAMIC_CHAIN}.prune */
void F626_5493 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("prune", 625, Current, 0, 1, 7117);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4881[dtype-661])(Current, tr1);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4885[dtype-661])(Current)) {
		RTHOOK(3);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4914[dtype-661])(Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {DYNAMIC_CHAIN}.prune_all */
void F626_5494 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("prune_all", 625, Current, 0, 1, 7118);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4875[dtype-661])(Current);
	RTHOOK(2);
	tr1 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4881[dtype-661])(Current, tr1);
	for (;;) {
		RTHOOK(3);
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4885[dtype-661])(Current)) break;
		RTHOOK(4);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4914[dtype-661])(Current);
		RTHOOK(5);
		tr1 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4881[dtype-661])(Current, tr1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

void EIF_Minit812 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
