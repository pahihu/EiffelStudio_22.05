
#ifndef _C17_se848_
#define _C17_se848_

#ifdef __cplusplus
extern "C" {
#endif

extern void F543_5280(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit848(void);
extern void F690_5966(EIF_REFERENCE, EIF_NATURAL_64);

#ifdef __cplusplus
}
#endif

#endif
