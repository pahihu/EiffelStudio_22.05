
#ifndef _C17_ge844_
#define _C17_ge844_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F804_6289(EIF_REFERENCE);
extern EIF_INTEGER_32 F804_6291(EIF_REFERENCE);
extern EIF_BOOLEAN F804_6298(EIF_REFERENCE);
extern void F804_6303(EIF_REFERENCE);
extern void F804_6304(EIF_REFERENCE);
extern void EIF_Minit844(void);

#ifdef __cplusplus
}
#endif

#endif
