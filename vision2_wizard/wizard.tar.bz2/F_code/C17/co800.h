
#ifndef _C17_co800_
#define _C17_co800_

#ifdef __cplusplus
extern "C" {
#endif

extern void F359_5038(EIF_REFERENCE);
extern void F359_5039(EIF_REFERENCE);
extern void EIF_Minit800(void);
extern long O4766[];

#ifdef __cplusplus
}
#endif

#endif
