/*
 * Code for class READABLE_INDEXABLE [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re840.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {READABLE_INDEXABLE}.new_cursor */
EIF_REFERENCE F576_5329 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("new_cursor", 575, Current, 0, 0, 6007);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {781,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y4668,Y4668_gen_type,Dftype(Current),324);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		Result = RTLNS(typres0.id, 781, _OBJSIZ_1_1_0_5_0_0_0_0_);
	}
	F782_6249(RTCW(Result), Current);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5484[Dtype(RTCW(Result))-780])(Result);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit840 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
