
#ifndef _C17_fi801_
#define _C17_fi801_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F506_5267(EIF_REFERENCE);
extern void EIF_Minit801(void);
extern char *(*R4921[])();

#ifdef __cplusplus
}
#endif

#endif
