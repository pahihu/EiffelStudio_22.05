
#ifndef _C11_ev528_
#define _C11_ev528_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1171_10443(EIF_REFERENCE);
extern void F1171_10444(EIF_REFERENCE);
extern void EIF_Minit528(void);
extern void F1344_12958(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
