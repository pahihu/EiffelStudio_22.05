/*
 * Code for class EV_FRAME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev502.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FRAME}.default_identifier_name */
EIF_REFERENCE F1145_10105 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("default_identifier_name", 1144, Current, 0, 0, 16342);
	RTGC;
	RTHOOK(1);
	tb1 = F512_5267(RTCV(F1122_9744(Current)));
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1104_9591(Current);
	} else {
		RTHOOK(4);
		Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (F1122_9744(Current));
		RTHOOK(5);
		F1063_9219(RTCW(Result));
		RTHOOK(6);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
		F1063_9204(RTCW(Result), tw1);
		RTHOOK(7);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
		F1063_9204(RTCW(Result), tw1);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_FRAME}.implementation */
EIF_REFERENCE F1145_10110 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_FRAME}.create_implementation */
void F1145_10111 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1144, Current, 0, 0, 16339);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1301, 0x00).id, 1301, _OBJSIZ_51_13_10_8_0_1_0_0_);
	F1302_12313(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit502 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
