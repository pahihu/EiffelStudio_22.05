/*
 * Code for class EV_TITLED_WINDOW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev507.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TITLED_WINDOW}.initialize */
void F1150_10180 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("initialize", 1149, Current, 0, 0, 16415);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(214,F19_214, (RTCV(RTOSCF(7396,F936_7396, (Current)))));
	F1150_10192(Current, tr1);
	RTHOOK(2);
	F1148_10137(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_TITLED_WINDOW}.raise */
void F1150_10185 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("raise", 1149, Current, 0, 0, 16420);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	F1307_12477(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_TITLED_WINDOW}.set_icon_pixmap */
void F1150_10192 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_icon_pixmap", 1149, Current, 0, 1, 16427);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	F1307_12483(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_TITLED_WINDOW}.implementation */
EIF_REFERENCE F1150_10193 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
}


/* {EV_TITLED_WINDOW}.create_implementation */
void F1150_10194 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1149, Current, 0, 0, 16429);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1306, 0x00).id, 1306, _OBJSIZ_65_25_10_11_0_4_0_0_);
	F1305_12387(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit507 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
