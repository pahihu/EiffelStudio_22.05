
#ifndef _C11_ev504_
#define _C11_ev504_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1147_10129(EIF_REFERENCE);
extern void F1147_10131(EIF_REFERENCE);
extern void F1147_10132(EIF_REFERENCE);
extern EIF_REFERENCE F1147_10134(EIF_REFERENCE);
extern void F1147_10135(EIF_REFERENCE);
extern void EIF_Minit504(void);
extern void F1304_12369(EIF_REFERENCE);
extern void F1304_12368(EIF_REFERENCE);
extern void F1304_12366(EIF_REFERENCE);
extern void F1304_12354(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
