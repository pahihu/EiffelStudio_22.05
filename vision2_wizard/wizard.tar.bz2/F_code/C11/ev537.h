
#ifndef _C11_ev537_
#define _C11_ev537_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1180_10483(EIF_REFERENCE);
extern void F1180_10484(EIF_REFERENCE);
extern void EIF_Minit537(void);
extern void F1364_13329(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
