/*
 * Code for class EV_INFORMATION_DIALOG
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev513.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_INFORMATION_DIALOG}.initialize */
void F1156_10279 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("initialize", 1155, Current, 0, 0, 16514);
	RTGC;
	RTHOOK(1);
	F1154_10247(Current);
	RTHOOK(2);
	tr1 = F171_3444(Current);
	F1148_10158(Current, tr1);
	RTHOOK(3);
	tr1 = RTOSCF(210,F19_210, (RTCV(RTOSCF(7396,F936_7396, (Current)))));
	F1154_10255(Current, tr1);
	RTHOOK(4);
	tr1 = RTOSCF(210,F19_210, (RTCV(RTOSCF(7396,F936_7396, (Current)))));
	F1150_10192(Current, tr1);
	RTHOOK(5);
	{
		static EIF_TYPE_INDEX typarr0[] = {858,1058,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 1L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F171_3432(Current);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F859_6501)(tr2);
	F1154_10259(Current, tr1);
	RTHOOK(6);
	tr1 = F171_3432(Current);
	tr1 = F1154_10262(Current, tr1);
	F1152_10229(Current, tr1);
	RTHOOK(7);
	tr1 = F171_3432(Current);
	tr1 = F1154_10262(Current, tr1);
	F1152_10231(Current, tr1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

void EIF_Minit513 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
