/*
 * Code for class EV_CELL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev501.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CELL}.has */
EIF_BOOLEAN F1144_10091 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("has", 1143, Current, 0, 1, 16321);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN) !F1091_9348(Current)) {
		tb1 = '\0';
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O9824[Dtype(tr1)-1300]);
			tb1 = (EIF_BOOLEAN)(tr1 == arg1);
		}
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_CELL}.is_empty */
EIF_BOOLEAN F1144_10092 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_empty", 1143, Current, 0, 0, 16322);
	RTGC;
	RTHOOK(1);
	Result = F1144_10094(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_CELL}.full */
EIF_BOOLEAN F1144_10094 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("full", 1143, Current, 0, 0, 16324);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O9824[Dtype(tr1)-1300]);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		Result = (EIF_BOOLEAN) !F1091_9348(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_CELL}.prunable */
EIF_BOOLEAN F1144_10095 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("prunable", 1143, Current, 0, 0, 16325);
	RTGC;
	RTHOOK(1);
	Result = F1091_9348(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_CELL}.readable */
EIF_BOOLEAN F1144_10097 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("readable", 1143, Current, 0, 0, 16327);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if (F1144_10094(Current)) {
		Result = (EIF_BOOLEAN) !F1091_9348(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_CELL}.prune */
void F1144_10099 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("prune", 1143, Current, 0, 1, 16329);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(F1137_10005(Current) == arg1)) {
		RTHOOK(2);
		F1144_10100(Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_CELL}.wipe_out */
void F1144_10100 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("wipe_out", 1143, Current, 0, 0, 16330);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	F1301_12309(RTCW(tr1), NULL);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_CELL}.linear_representation */
EIF_REFERENCE F1144_10101 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("linear_representation", 1143, Current, 1, 0, 16331);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {661,1135,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 661, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F662_5513(RTCW(loc1));
	RTHOOK(2);
	if (F1144_10097(Current)) {
		RTHOOK(3);
		tr1 = F1137_10005(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4895[Dtype(RTCW(loc1))-661])(loc1, tr1);
	}
	RTHOOK(4);
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_CELL}.implementation */
EIF_REFERENCE F1144_10102 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
}


/* {EV_CELL}.create_implementation */
void F1144_10103 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1143, Current, 0, 0, 16333);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1300, 0x00).id, 1300, _OBJSIZ_49_13_10_6_0_1_0_0_);
	F1301_12305(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit501 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
