
#ifndef _C11_ev510_
#define _C11_ev510_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1153_10241(EIF_REFERENCE, EIF_REFERENCE);
extern void F1153_10242(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1153_10243(EIF_REFERENCE);
extern void EIF_Minit510(void);

#ifdef __cplusplus
}
#endif

#endif
