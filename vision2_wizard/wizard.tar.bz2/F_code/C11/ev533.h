
#ifndef _C11_ev533_
#define _C11_ev533_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1176_10461(EIF_REFERENCE);
extern void EIF_Minit533(void);
extern char *(*R10227[])();

#ifdef __cplusplus
}
#endif

#endif
