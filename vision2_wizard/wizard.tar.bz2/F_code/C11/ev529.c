/*
 * Code for class EV_BUTTON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev529.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_BUTTON}.make_with_text_and_action */
void F1172_10445 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("make_with_text_and_action", 1171, Current, 0, 2, 16689);
	RTGC;
	RTHOOK(1);
	F1091_9344(Current);
	RTHOOK(2);
	F1122_9745(Current, arg1);
	RTHOOK(3);
	tr1 = F1087_9304(Current);
	F704_6008(RTCW(tr1), arg2);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_BUTTON}.default_identifier_name */
EIF_REFERENCE F1172_10446 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("default_identifier_name", 1171, Current, 0, 0, 16690);
	RTGC;
	RTHOOK(1);
	tb1 = F512_5267(RTCV(F1122_9744(Current)));
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1104_9591(Current);
	} else {
		RTHOOK(4);
		Result = F1063_9213(RTCV(F1122_9744(Current)));
		RTHOOK(5);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
		F1063_9204(RTCW(Result), tw1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_BUTTON}.is_default_push_button */
EIF_BOOLEAN F1172_10447 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_default_push_button", 1171, Current, 0, 0, 16683);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_46_11_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_BUTTON}.enable_default_push_button */
void F1172_10448 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_default_push_button", 1171, Current, 0, 0, 16684);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1351_13168(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_BUTTON}.disable_default_push_button */
void F1172_10449 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("disable_default_push_button", 1171, Current, 0, 0, 16685);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1351_13169(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_BUTTON}.implementation */
EIF_REFERENCE F1172_10451 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_BUTTON}.create_implementation */
void F1172_10452 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1171, Current, 0, 0, 16688);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1350, 0x00).id, 1350, _OBJSIZ_46_14_10_6_0_3_0_0_);
	F1351_13159(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit529 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
