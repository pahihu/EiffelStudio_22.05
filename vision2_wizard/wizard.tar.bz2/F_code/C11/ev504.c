/*
 * Code for class EV_SCROLLABLE_AREA
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev504.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SCROLLABLE_AREA}.show_horizontal_scroll_bar */
void F1147_10129 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("show_horizontal_scroll_bar", 1146, Current, 0, 0, 16362);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1304_12366(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_SCROLLABLE_AREA}.show_vertical_scroll_bar */
void F1147_10131 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("show_vertical_scroll_bar", 1146, Current, 0, 0, 16364);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1304_12368(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_SCROLLABLE_AREA}.hide_vertical_scroll_bar */
void F1147_10132 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("hide_vertical_scroll_bar", 1146, Current, 0, 0, 16365);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1304_12369(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_SCROLLABLE_AREA}.implementation */
EIF_REFERENCE F1147_10134 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_SCROLLABLE_AREA}.create_implementation */
void F1147_10135 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1146, Current, 0, 0, 16368);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1303, 0x00).id, 1303, _OBJSIZ_49_14_10_10_0_5_0_0_);
	F1304_12354(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit504 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
