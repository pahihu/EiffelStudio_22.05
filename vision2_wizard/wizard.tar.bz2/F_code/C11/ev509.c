/*
 * Code for class EV_DIALOG
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev509.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DIALOG}.initialize */
void F1152_10223 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLIU(6);
	
	RTEAA("initialize", 1151, Current, 0, 0, 16466);
	RTGC;
	RTHOOK(1);
	tr1 = F1088_9314(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,1,973,1394,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A509_314_2, (EIF_POINTER) _A509_314_2, (EIF_POINTER)(F1152_10235),tr2, 1, 1);
	}
	F704_6008(RTCW(tr1), tr5);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1308_12493(RTCW(tr1));
	RTHOOK(3);
	F1150_10180(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_DIALOG}.default_push_button */
EIF_REFERENCE F1152_10224 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("default_push_button", 1151, Current, 0, 0, 16467);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1300_12287(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DIALOG}.default_cancel_button */
EIF_REFERENCE F1152_10225 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("default_cancel_button", 1151, Current, 0, 0, 16468);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1300_12288(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DIALOG}.set_default_push_button */
void F1152_10229 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_default_push_button", 1151, Current, 0, 1, 16472);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1300_12290(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DIALOG}.remove_default_push_button */
void F1152_10230 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("remove_default_push_button", 1151, Current, 0, 0, 16457);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1300_12291(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DIALOG}.set_default_cancel_button */
void F1152_10231 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_default_cancel_button", 1151, Current, 0, 1, 16458);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1300_12292(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DIALOG}.remove_default_cancel_button */
void F1152_10232 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("remove_default_cancel_button", 1151, Current, 0, 0, 16459);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1300_12293(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DIALOG}.show_modal_to_window */
void F1152_10233 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("show_modal_to_window", 1151, Current, 1, 1, 16460);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1229_11433(RTCW(tr1), arg1);
	RTHOOK(2);
	tr1 = F1099_9490(RTCV(RTOSCF(3874,F222_3874, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		F1107_9645(loc1, Current);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_DIALOG}.show_relative_to_window */
void F1152_10234 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("show_relative_to_window", 1151, Current, 1, 1, 16461);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1229_11434(RTCW(tr1), arg1);
	RTHOOK(2);
	tr1 = F1099_9490(RTCV(RTOSCF(3874,F222_3874, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		F1107_9645(loc1, Current);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_DIALOG}.dialog_key_press_action */
void F1152_10235 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("dialog_key_press_action", 1151, Current, 0, 1, 16462);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1300_12298(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DIALOG}.implementation */
EIF_REFERENCE F1152_10236 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_DIALOG}.create_implementation */
void F1152_10237 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1151, Current, 0, 0, 16464);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1307, 0x00).id, 1307, _OBJSIZ_68_26_10_11_0_4_0_0_);
	F1308_12489(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit509 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
