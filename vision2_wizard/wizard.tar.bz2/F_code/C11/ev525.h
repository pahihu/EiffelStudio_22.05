
#ifndef _C11_ev525_
#define _C11_ev525_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1168_10437(EIF_REFERENCE);
extern void F1168_10438(EIF_REFERENCE);
extern void EIF_Minit525(void);
extern void F1350_13155(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
