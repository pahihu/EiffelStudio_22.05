
#ifndef _C11_ev532_
#define _C11_ev532_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1175_10459(EIF_REFERENCE);
extern void F1175_10460(EIF_REFERENCE);
extern void EIF_Minit532(void);
extern void F1354_13193(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
