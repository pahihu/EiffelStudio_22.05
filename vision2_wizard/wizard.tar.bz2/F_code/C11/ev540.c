/*
 * Code for class EV_MENU_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev540.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MENU_ITEM}.make_with_text_and_action */
void F1183_10498 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("make_with_text_and_action", 1182, Current, 0, 2, 16734);
	RTGC;
	RTHOOK(1);
	F1091_9344(Current);
	RTHOOK(2);
	F1122_9745(Current, arg1);
	RTHOOK(3);
	tr1 = F1080_9280(Current);
	F704_6008(RTCW(tr1), arg2);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_MENU_ITEM}.default_identifier_name */
EIF_REFERENCE F1183_10499 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("default_identifier_name", 1182, Current, 1, 0, 16735);
	RTGC;
	RTHOOK(1);
	tb1 = F512_5267(RTCV(F1122_9744(Current)));
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1104_9591(Current);
	} else {
		RTHOOK(4);
		Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (F1122_9744(Current));
		RTHOOK(5);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
		F1063_9204(RTCW(Result), tw1);
		RTHOOK(6);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
		F1063_9204(RTCW(Result), tw1);
		RTHOOK(7);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\011';
		loc1 = F1061_9075(RTCW(Result), tw1, ((EIF_INTEGER_32) 1L));
		RTHOOK(8);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(9);
			F1063_9160(RTCW(Result), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
		}
		RTHOOK(10);
		F1063_9219(RTCW(Result));
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_MENU_ITEM}.implementation */
EIF_REFERENCE F1183_10504 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_MENU_ITEM}.create_implementation */
void F1183_10505 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1182, Current, 0, 0, 16741);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1369, 0x00).id, 1369, _OBJSIZ_23_8_6_1_0_4_0_0_);
	F1370_13340(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit540 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
