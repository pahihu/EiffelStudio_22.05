
#ifndef _C11_ev500_
#define _C11_ev500_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1143_10089(EIF_REFERENCE);
extern void F1143_10090(EIF_REFERENCE);
extern void EIF_Minit500(void);
extern void F1292_12199(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
