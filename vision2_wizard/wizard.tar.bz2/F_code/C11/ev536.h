
#ifndef _C11_ev536_
#define _C11_ev536_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1179_10482(EIF_REFERENCE);
extern void EIF_Minit536(void);
extern EIF_REFERENCE F1176_10461(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
