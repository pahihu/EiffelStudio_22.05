
#ifndef _C11_ev515_
#define _C11_ev515_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1158_10291(EIF_REFERENCE);
extern void F1158_10292(EIF_REFERENCE);
extern void EIF_Minit515(void);
extern void F1387_13678(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
