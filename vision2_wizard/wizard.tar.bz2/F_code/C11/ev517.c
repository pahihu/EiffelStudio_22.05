/*
 * Code for class EV_PIXMAP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev517.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PIXMAP}.make_with_size */
void F1160_10300 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_with_size", 1159, Current, 0, 2, 16535);
	RTGC;
	RTHOOK(1);
	F1091_9344(Current);
	RTHOOK(2);
	F1160_10314(Current, arg1, arg2);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP}.make_with_pixel_buffer */
void F1160_10302 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("make_with_pixel_buffer", 1159, Current, 0, 1, 16537);
	RTGC;
	RTHOOK(1);
	F1091_9344(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1390_13815(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP}.is_equal */
EIF_BOOLEAN F1160_10304 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_equal", 1159, Current, 0, 1, 16539);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		ti4_1 = F1114_9697(Current);
		ti4_2 = F1114_9698(RTCW(arg1));
		ti4_3 = F1114_9697(RTCW(arg1));
		ti4_4 = F1114_9698(Current);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) (ti4_1 * ti4_2) == (EIF_INTEGER_32) (ti4_3 * ti4_4));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_PIXMAP}.set_with_named_path */
void F1160_10312 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_with_named_path", 1159, Current, 0, 1, 16547);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1390_13822(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP}.set_size */
void F1160_10314 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_size", 1159, Current, 0, 2, 16549);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1390_13826(RTCW(tr1), arg1, arg2);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP}.copy */
void F1160_10320 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("copy", 1159, Current, 0, 1, 16555);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) == NULL)) {
		RTHOOK(2);
		F1091_9344(Current);
	}
	RTHOOK(3);
	tb1 = F1091_9348(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1390_13833(RTCW(tr1), arg1);
	} else {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		ti4_1 = F1390_13820(RTCW(tr2));
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		ti4_2 = F1390_13821(RTCW(tr2));
		F1390_13826(RTCW(tr1), ti4_1, ti4_2);
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1390_13846(RTCW(tr1));
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP}.implementation */
EIF_REFERENCE F1160_10321 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_PIXMAP}.create_implementation */
void F1160_10322 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1159, Current, 0, 0, 16557);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1389, 0x00).id, 1389, _OBJSIZ_48_18_10_9_0_4_0_1_);
	F1390_13813(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit517 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
