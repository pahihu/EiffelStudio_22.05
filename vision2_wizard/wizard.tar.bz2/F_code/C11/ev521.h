
#ifndef _C11_ev521_
#define _C11_ev521_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1164_10359(EIF_REFERENCE);
extern void EIF_Minit521(void);
extern char *(*R9988[])();

#ifdef __cplusplus
}
#endif

#endif
