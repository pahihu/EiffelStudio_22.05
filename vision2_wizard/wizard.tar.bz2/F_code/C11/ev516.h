
#ifndef _C11_ev516_
#define _C11_ev516_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1159_10298(EIF_REFERENCE);
extern void F1159_10299(EIF_REFERENCE);
extern void EIF_Minit516(void);
extern void F1336_12847(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
