
#ifndef _C11_ev527_
#define _C11_ev527_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1170_10441(EIF_REFERENCE);
extern void F1170_10442(EIF_REFERENCE);
extern void EIF_Minit527(void);
extern void F1343_12955(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
