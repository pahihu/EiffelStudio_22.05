/*
 * Code for class EV_MESSAGE_DIALOG
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev511.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MESSAGE_DIALOG}.make_with_text */
void F1154_10244 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make_with_text", 1153, Current, 0, 1, 16479);
	RTGC;
	RTHOOK(1);
	F1091_9344(Current);
	RTHOOK(2);
	F1154_10257(Current, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.create_interface_objects */
void F1154_10246 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEAA("create_interface_objects", 1153, Current, 1, 0, 16481);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {679,1171,1062,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F680_5794(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTLNSMART(eif_new_type(1141, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = RTLNSMART(eif_new_type(1143, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	tr1 = RTLNSMART(eif_new_type(1146, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tr1 = RTLNSMART(eif_new_type(1158, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	loc1 = RTLNS(eif_new_type(16, 0x00).id, 16, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTHOOK(7);
	tr1 = F17_203(RTCW(loc1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	RTHOOK(8);
	tr1 = F17_202(RTCW(loc1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.initialize */
void F1154_10247 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,tr4);
	RTLR(10,tr5);
	RTLIU(11);
	
	RTEAA("initialize", 1153, Current, 5, 0, 16482);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1245_11644(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1245_11645(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	loc1 = RTLNS(eif_new_type(1141, 0x00).id, 1141, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc1));
	RTHOOK(4);
	loc2 = RTLNS(eif_new_type(1142, 0x00).id, 1142, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc2));
	RTHOOK(5);
	loc3 = RTLNS(eif_new_type(1141, 0x00).id, 1141, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc3));
	RTHOOK(6);
	loc4 = RTLNS(eif_new_type(1142, 0x00).id, 1142, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc4));
	RTHOOK(7);
	F1152_10223(Current);
	RTHOOK(8);
	loc5 = RTLNS(eif_new_type(1125, 0x00).id, 1125, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1091_9344(RTCW(loc5));
	RTHOOK(9);
	ti4_1 = F1126_9833(RTCW(loc5));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_1_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 200L));
	RTHOOK(10);
	ti4_1 = F1126_9834(RTCW(loc5));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 200L));
	RTHOOK(11);
	F1134_9938(RTCW(loc4), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	RTHOOK(12);
	F1141_10084(RTCW(loc4), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	RTHOOK(13);
	tr1 = RTLNS(eif_new_type(1143, 0x00).id, 1143, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(tr1));
	F1134_9938(RTCW(loc4), tr1);
	RTHOOK(14);
	F1134_9938(RTCW(loc1), loc4);
	RTHOOK(15);
	F1134_9938(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
	RTHOOK(16);
	F1141_10082(RTCW(loc1), ((EIF_INTEGER_32) 10L));
	RTHOOK(17);
	tr1 = RTLNS(eif_new_type(1143, 0x00).id, 1143, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(tr1));
	F1134_9938(RTCW(loc3), tr1);
	RTHOOK(18);
	F1134_9938(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	RTHOOK(19);
	F1141_10084(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	RTHOOK(20);
	tr1 = RTLNS(eif_new_type(1143, 0x00).id, 1143, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(tr1));
	F1134_9938(RTCW(loc3), tr1);
	RTHOOK(21);
	F1134_9938(RTCW(loc2), loc1);
	RTHOOK(22);
	F1134_9938(RTCW(loc2), loc3);
	RTHOOK(23);
	F1141_10084(RTCW(loc2), loc3);
	RTHOOK(24);
	F1141_10082(RTCW(loc2), ((EIF_INTEGER_32) 14L));
	RTHOOK(25);
	F1141_10080(RTCW(loc2), ((EIF_INTEGER_32) 10L));
	RTHOOK(26);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	F1123_9755(RTCW(tr1));
	RTHOOK(27);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1141_10082(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTHOOK(28);
	F1137_10014(Current, loc2);
	RTHOOK(29);
	tr1 = RTMS_EX_H("Use `set_text\' to modify this message.",38,1665955374);
	F1154_10257(Current, tr1);
	RTHOOK(30);
	tr1 = F1088_9314(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,1,973,1394,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A511_356_2, (EIF_POINTER) _A511_356_2, (EIF_POINTER)(F1154_10276),tr2, 1, 1);
	}
	F704_6008(RTCW(tr1), tr5);
	RTHOOK(31);
	F1148_10152(Current);
	RTHOOK(32);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.pixmap */
EIF_REFERENCE F1154_10248 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("pixmap", 1153, Current, 0, 0, 16483);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tb1 = F1144_10097(RTCW(tr1));
	if (tb1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		Result = F1137_10005(RTCW(tr1));
		Result = RTRV(eif_new_type(1159, 0x00), Result);
		
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_MESSAGE_DIALOG}.foreground_color */
EIF_REFERENCE F1154_10250 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_13_);
}


/* {EV_MESSAGE_DIALOG}.background_color */
EIF_REFERENCE F1154_10251 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_12_);
}


/* {EV_MESSAGE_DIALOG}.default_identifier_name */
EIF_REFERENCE F1154_10252 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("default_identifier_name", 1153, Current, 0, 0, 16487);
	RTGC;
	RTHOOK(1);
	tb1 = F512_5267(RTCV(F1148_10142(Current)));
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1104_9591(Current);
	} else {
		RTHOOK(4);
		Result = F1063_9213(RTCV(F1148_10142(Current)));
		RTHOOK(5);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
		F1063_9204(RTCW(Result), tw1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_MESSAGE_DIALOG}.set_background_color */
void F1154_10253 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("set_background_color", 1153, Current, 1, 1, 16488);
	RTGC;
	RTHOOK(1);
	tr1 = F1137_10005(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7936[Dtype(RTCW(tr1))-1125])(tr1, arg1);
	RTHOOK(2);
	loc1 = F1137_10005(Current);
	loc1 = RTRV(eif_new_type(1136, 0x00), loc1);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(4);
		F1137_10022(RTCW(loc1));
	}
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	F1096_9453(RTCW(tr1), arg1);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.set_pixmap */
void F1154_10255 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("set_pixmap", 1153, Current, 2, 1, 16490);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(F1154_10248(Current) != NULL)) {
		RTHOOK(2);
		F1154_10256(Current);
	}
	RTHOOK(3);
	loc1 = RTLNS(eif_new_type(1159, 0x00).id, 1159, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc1));
	RTHOOK(4);
	F1160_10320(RTCW(loc1), arg1);
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1137_10014(RTCW(tr1), loc1);
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	ti4_1 = F1114_9697(RTCW(loc1));
	ti4_2 = F1114_9698(RTCW(loc1));
	F1136_9999(RTCW(tr1), ti4_1, ti4_2);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.remove_pixmap */
void F1154_10256 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("remove_pixmap", 1153, Current, 0, 0, 16491);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1144_10100(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.set_text */
void F1154_10257 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,loc6);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTEAA("set_text", 1153, Current, 6, 1, 16492);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = F1136_9973(RTCW(tr1));
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8186[Dtype(loc5)-1141])(loc5, *(EIF_REFERENCE *)(Current + _REFACS_8_));
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1144_10099(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
		RTHOOK(4);
		loc4 = (EIF_REFERENCE) loc5;
	} else {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		tr1 = F1136_9973(RTCW(tr1));
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			RTHOOK(6);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8186[Dtype(loc6)-1141])(loc6, *(EIF_REFERENCE *)(Current + _REFACS_9_));
			RTHOOK(7);
			loc4 = (EIF_REFERENCE) loc6;
		}
	}
	RTHOOK(8);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	F1122_9745(RTCW(tr1), arg1);
	RTHOOK(9);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = F1114_9697(RTCW(tr1));
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = F1114_9698(RTCW(tr1));
	RTHOOK(11);
	if ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_1_))) {
		RTHOOK(12);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(13);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1147_10129(RTCW(tr1));
		RTHOOK(14);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_1_);
	} else {
		RTHOOK(15);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1147_10132(RTCW(tr1));
	}
	RTHOOK(16);
	if ((EIF_BOOLEAN) (loc2 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_2_))) {
		RTHOOK(17);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(18);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1147_10131(RTCW(tr1));
		RTHOOK(19);
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_2_);
	} else {
		RTHOOK(20);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1147_10132(RTCW(tr1));
	}
	RTHOOK(21);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	F1136_9997(RTCW(tr1), loc1);
	RTHOOK(22);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	F1136_9998(RTCW(tr1), loc2);
	RTHOOK(23);
	if (loc3) {
		RTHOOK(24);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1137_10014(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
		RTHOOK(25);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			RTHOOK(26);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8183[Dtype(RTCW(loc4))-1141])(loc4, *(EIF_REFERENCE *)(Current + _REFACS_8_));
		}
	} else {
		RTHOOK(27);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			RTHOOK(28);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8183[Dtype(RTCW(loc4))-1141])(loc4, *(EIF_REFERENCE *)(Current + _REFACS_9_));
		}
	}
	RTHOOK(31);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.set_buttons */
void F1154_10259 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_buttons", 1153, Current, 1, 1, 16494);
	RTGC;
	RTHOOK(1);
	F1154_10272(Current);
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(3);
		ti4_1 = F601_5395(RTCW(arg1));
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		RTHOOK(4);
		tr1 = F601_5389(RTCW(arg1), loc1);
		F1154_10273(Current, tr1);
		RTHOOK(5);
		loc1++;
	}
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1141_10078(RTCW(tr1));
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.button */
EIF_REFERENCE F1154_10262 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("button", 1153, Current, 1, 1, 16497);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = F1054_8826(RTCW(arg1));
	loc1 = F680_5800(RTCW(tr1), tr2);
	RTHOOK(2);
	RTCT0("l_result /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_MESSAGE_DIALOG}.clean_buttons */
void F1154_10272 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("clean_buttons", 1153, Current, 0, 0, 16507);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(F1152_10224(Current) != NULL)) {
		RTHOOK(2);
		F1152_10230(Current);
	}
	RTHOOK(3);
	if ((EIF_BOOLEAN)(F1152_10225(Current) != NULL)) {
		RTHOOK(4);
		F1152_10232(Current);
	}
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1134_9951(RTCW(tr1));
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	F680_5848(RTCW(tr1));
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.add_button */
void F1154_10273 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTEAA("add_button", 1153, Current, 2, 1, 16508);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1171, 0x00).id, 1171, _OBJSIZ_6_2_0_1_0_0_0_0_);
	F1122_9743(RTCW(loc1), arg1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = F1054_8826(RTCW(arg1));
	F680_5840(RTCW(tr1), loc1, tr2);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc2 = F506_5267(RTCW(tr1));
	RTHOOK(4);
	tr1 = F1087_9304(RTCW(loc1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,973,0,1053,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = arg1;
	RTAR(tr2,arg1);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,0,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A511_355, (EIF_POINTER) _A511_355, (EIF_POINTER)(F1154_10275),tr2, 1, 0);
	}
	F704_6008(RTCW(tr1), tr3);
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1134_9938(RTCW(tr1), loc1);
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1141_10084(RTCW(tr1), loc1);
	RTHOOK(7);
	ti4_1 = F1114_9699(RTCW(loc1));
	ti4_1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 75L));
	F1136_9997(RTCW(loc1), ti4_1);
	RTHOOK(8);
	F1123_9753(RTCW(loc1));
	RTHOOK(9);
	if (loc2) {
		RTHOOK(10);
		F1152_10229(Current, loc1);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.on_button_press */
void F1154_10275 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("on_button_press", 1153, Current, 0, 1, 16510);
	RTGC;
	RTHOOK(1);
	tr1 = F1054_8826(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	if ((EIF_BOOLEAN) !F1091_9348(Current)) {
		RTHOOK(3);
		F1148_10149(Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.on_key_press */
void F1154_10276 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("on_key_press", 1153, Current, 0, 1, 16511);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 60L))) {
		RTHOOK(2);
		F1154_10277(Current, ((EIF_INTEGER_32) -1L));
	} else {
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 61L))) {
			RTHOOK(4);
			F1154_10277(Current, ((EIF_INTEGER_32) 1L));
		}
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.move_to_next_button */
void F1154_10277 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("move_to_next_button", 1153, Current, 4, 1, 16512);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	RTHOOK(2);
	ti4_1 = F1134_9927(RTCW(loc1));
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
		RTHOOK(3);
		loc2 = F1134_9922(RTCW(loc1));
		RTHOOK(4);
		F1134_9930(RTCW(loc1));
		for (;;) {
			RTHOOK(5);
			tb1 = '\01';
			tb2 = F638_5502(RTCW(loc1));
			if (!tb2) {
				tb1 = loc4;
			}
			if (tb1) break;
			RTHOOK(6);
			loc3 = F1134_9920(RTCW(loc1));
			RTHOOK(7);
			loc4 = F1136_9983(RTCW(loc3));
			RTHOOK(8);
			if ((EIF_BOOLEAN) !loc4) {
				RTHOOK(9);
				F1134_9932(RTCW(loc1));
			}
		}
		RTHOOK(10);
		if (loc4) {
			RTHOOK(11);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTHOOK(12);
				if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) -1L))) {
					RTHOOK(13);
					tr1 = F614_5463(RTCW(loc1));
					if ((EIF_BOOLEAN)(tr1 == loc3)) {
						RTHOOK(14);
						tr1 = F614_5464(RTCW(loc1));
						F1136_9987(RTCW(tr1));
					} else {
						RTHOOK(15);
						F1134_9931(RTCW(loc1));
						RTHOOK(16);
						tr1 = F1134_9920(RTCW(loc1));
						F1136_9987(RTCW(tr1));
					}
				} else {
					RTHOOK(17);
					tr1 = F614_5464(RTCW(loc1));
					if ((EIF_BOOLEAN)(tr1 == loc3)) {
						RTHOOK(18);
						tr1 = F614_5463(RTCW(loc1));
						F1136_9987(RTCW(tr1));
					} else {
						RTHOOK(19);
						F1134_9932(RTCW(loc1));
						RTHOOK(20);
						tr1 = F1134_9920(RTCW(loc1));
						F1136_9987(RTCW(tr1));
					}
				}
			}
		} else {
			RTHOOK(21);
			tr1 = F614_5463(RTCW(loc1));
			F1136_9987(RTCW(tr1));
		}
		RTHOOK(22);
		F1134_9934(RTCW(loc1), loc2);
	}
	RTHOOK(23);
	RTLE;
	RTEE;
}

void EIF_Minit511 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
