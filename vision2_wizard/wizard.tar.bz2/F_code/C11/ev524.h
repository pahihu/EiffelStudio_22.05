
#ifndef _C11_ev524_
#define _C11_ev524_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1167_10433(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1167_10435(EIF_REFERENCE);
extern void F1167_10436(EIF_REFERENCE);
extern void EIF_Minit524(void);
extern void F1348_13097(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1348_13091(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
