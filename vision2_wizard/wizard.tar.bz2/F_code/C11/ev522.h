
#ifndef _C11_ev522_
#define _C11_ev522_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1165_10387(EIF_REFERENCE);
extern EIF_REFERENCE F1165_10397(EIF_REFERENCE);
extern void F1165_10398(EIF_REFERENCE);
extern void EIF_Minit522(void);
extern void F1346_13006(EIF_REFERENCE);
extern void F1346_12970(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
