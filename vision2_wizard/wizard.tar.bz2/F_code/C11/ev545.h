
#ifndef _C11_ev545_
#define _C11_ev545_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1189_10554(EIF_REFERENCE);
extern EIF_REFERENCE F1189_10564(EIF_REFERENCE);
extern void EIF_Minit545(void);
extern void F1333_12710(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
