/*
 * Code for class EV_TOOL_BAR_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev536.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TOOL_BAR_ITEM}.parent */
EIF_REFERENCE F1179_10482 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("parent", 1178, Current, 0, 0, 16718);
	RTGC;
	RTHOOK(1);
	Result = F1176_10461(Current);
	RTHOOK(2);
	RTLE;
	RTEE;
	return RTRV(eif_new_type(1188, 0x00), Result);
}

void EIF_Minit536 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
