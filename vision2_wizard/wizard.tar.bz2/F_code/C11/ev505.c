/*
 * Code for class EV_WINDOW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev505.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WINDOW}.initialize */
void F1148_10137 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLIU(6);
	
	RTEAA("initialize", 1147, Current, 0, 0, 16391);
	RTGC;
	RTHOOK(1);
	F1091_9353(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCV(F1148_10145(Current)) + _REFACS_3_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,1296,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	tr3 = *(EIF_REFERENCE *)(Current + O7674[dtype-1090]);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,1,973,1097,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A649_263_2, (EIF_POINTER) _A649_263_2, (EIF_POINTER)(F1305_12410),tr2, 1, 1);
	}
	F704_6008(RTCW(tr1), tr5);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(RTCV(F1148_10145(Current)) + _REFACS_4_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,1296,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	tr3 = *(EIF_REFERENCE *)(Current + O7674[dtype-1090]);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,1,973,1097,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A649_264_2, (EIF_POINTER) _A649_264_2, (EIF_POINTER)(F1305_12411),tr2, 1, 1);
	}
	F704_6008(RTCW(tr1), tr5);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_WINDOW}.title */
EIF_REFERENCE F1148_10142 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("title", 1147, Current, 0, 0, 16396);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = F1305_12391(RTCW(tr1));
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_WINDOW}.accelerators */
EIF_REFERENCE F1148_10145 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("accelerators", 1147, Current, 0, 0, 16399);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = F1297_12239(RTCW(tr1));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_WINDOW}.has */
EIF_BOOLEAN F1148_10146 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("has", 1147, Current, 0, 1, 16400);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	Result = F1297_12236(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_WINDOW}.destroy */
void F1148_10149 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("destroy", 1147, Current, 1, 0, 16403);
	RTGC;
	RTHOOK(1);
	F1091_9347(Current);
	RTHOOK(2);
	tr1 = F1099_9490(RTCV(RTOSCF(3874,F222_3874, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		F1107_9646(loc1, Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_WINDOW}.disable_user_resize */
void F1148_10152 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("disable_user_resize", 1147, Current, 0, 0, 16406);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	F1305_12398(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_WINDOW}.set_title */
void F1148_10158 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("set_title", 1147, Current, 1, 1, 16374);
	RTGC;
	RTHOOK(1);
	loc1 = arg1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + O7674[dtype-1090]);
		F1305_12407(RTCW(tr1), loc1);
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + O7674[dtype-1090]);
		tr2 = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1061_9071(RTCW(tr2), arg1);
		F1305_12407(RTCW(tr1), tr2);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_WINDOW}.lock_update */
void F1148_10162 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("lock_update", 1147, Current, 0, 0, 16378);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	F1297_12252(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_WINDOW}.unlock_update */
void F1148_10163 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("unlock_update", 1147, Current, 0, 0, 16379);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
	F1297_12253(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_WINDOW}.show */
void F1148_10164 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("show", 1147, Current, 1, 0, 16380);
	RTGC;
	RTHOOK(1);
	F1136_9986(Current);
	RTHOOK(2);
	tr1 = F1099_9490(RTCV(RTOSCF(3874,F222_3874, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		F1107_9645(loc1, Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_WINDOW}.implementation */
EIF_REFERENCE F1148_10167 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]);
}


/* {EV_WINDOW}.create_implementation */
void F1148_10171 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1147, Current, 0, 0, 16387);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1304, 0x00).id, 1304, _OBJSIZ_59_21_10_11_0_4_0_0_);
	F1305_12387(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O7674[Dtype(Current)-1090]) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit505 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
