/*
 * Code for class EV_TOOL_BAR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev545.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TOOL_BAR}.create_implementation */
void F1189_10554 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1188, Current, 0, 0, 16791);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1332, 0x00).id, 1332, _OBJSIZ_45_16_10_7_0_2_0_0_);
	F1333_12710(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_TOOL_BAR}.implementation */
EIF_REFERENCE F1189_10564 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


void EIF_Minit545 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
