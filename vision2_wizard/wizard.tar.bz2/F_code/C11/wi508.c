/*
 * Code for class WIZARD_WINDOW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi508.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_WINDOW}.make */
void F1151_10195 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make", 1150, Current, 0, 1, 16431);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F1091_9344(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.create_interface_objects */
void F1151_10196 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_interface_objects", 1150, Current, 0, 0, 16432);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1142, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTLNSMART(eif_new_type(1171, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = RTLNSMART(eif_new_type(1171, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	tr1 = RTLNSMART(eif_new_type(1171, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tr1 = RTLNSMART(eif_new_type(1171, 0).id);
	F1091_9344(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	F936_7394(Current);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.initialize */
void F1151_10197 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTEAA("initialize", 1150, Current, 1, 0, 16433);
	RTGC;
	RTHOOK(1);
	F1150_10180(Current);
	RTHOOK(2);
	loc1 = RTLNS(eif_new_type(1142, 0x00).id, 1142, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc1));
	RTHOOK(3);
	F1134_9938(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	RTHOOK(4);
	F1151_10198(Current, loc1);
	RTHOOK(5);
	F1137_10014(Current, loc1);
	RTHOOK(6);
	ti4_1 = F123_2729(Current, ((EIF_INTEGER_32) 503L));
	ti4_2 = F123_2729(Current, ((EIF_INTEGER_32) 385L));
	F1115_9708(Current, ti4_1, ti4_2);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.build_navigation_bar */
void F1151_10198 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,loc1);
	RTLR(6,loc3);
	RTLR(7,loc2);
	RTLR(8,arg1);
	RTLIU(9);
	
	RTEAA("build_navigation_bar", 1150, Current, 3, 1, 16434);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1171, 0).id);
	tr2 = F124_2759(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
	RTAR(tr3,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,0,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A508_385, (EIF_POINTER) _A508_385, (EIF_POINTER)(F1151_10217),tr3, 1, 0);
	}
	F1172_10445(RTCW(tr1), tr2, tr4);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	F1123_9753(RTCW(tr1));
	RTHOOK(3);
	F123_2727(Current, *(EIF_REFERENCE *)(Current + _REFACS_9_));
	RTHOOK(4);
	tr1 = RTLNSMART(eif_new_type(1171, 0).id);
	tr2 = F124_2760(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
	RTAR(tr3,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,0,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A508_387, (EIF_POINTER) _A508_387, (EIF_POINTER)(F1151_10219),tr3, 1, 0);
	}
	F1172_10445(RTCW(tr1), tr2, tr4);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1123_9753(RTCW(tr1));
	RTHOOK(6);
	F123_2727(Current, *(EIF_REFERENCE *)(Current + _REFACS_10_));
	RTHOOK(7);
	tr1 = RTLNSMART(eif_new_type(1171, 0).id);
	tr2 = F124_2761(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
	RTAR(tr3,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,0,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A508_353, (EIF_POINTER) _A508_353, (EIF_POINTER)(F128_2839),tr3, 1, 0);
	}
	F1172_10445(RTCW(tr1), tr2, tr4);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	RTHOOK(8);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	F1123_9753(RTCW(tr1));
	RTHOOK(9);
	F123_2727(Current, *(EIF_REFERENCE *)(Current + _REFACS_11_));
	RTHOOK(10);
	tr1 = RTLNSMART(eif_new_type(1171, 0).id);
	tr2 = F124_2762(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,973,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
	RTAR(tr3,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1047,0xFFF9,0,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A508_354, (EIF_POINTER) _A508_354, (EIF_POINTER)(F128_2840),tr3, 1, 0);
	}
	F1172_10445(RTCW(tr1), tr2, tr4);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	RTHOOK(11);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	F1123_9753(RTCW(tr1));
	RTHOOK(12);
	F123_2727(Current, *(EIF_REFERENCE *)(Current + _REFACS_12_));
	RTHOOK(13);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	F1136_9985(RTCW(tr1));
	RTHOOK(14);
	loc1 = RTLNS(eif_new_type(1141, 0x00).id, 1141, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc1));
	RTHOOK(15);
	F1134_9938(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
	RTHOOK(16);
	F1141_10084(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
	RTHOOK(17);
	F1134_9938(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	RTHOOK(18);
	F1141_10084(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	RTHOOK(19);
	loc3 = RTLNS(eif_new_type(1141, 0x00).id, 1141, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc3));
	RTHOOK(20);
	ti4_1 = F123_2729(Current, ((EIF_INTEGER_32) 11L));
	F1141_10082(RTCW(loc3), ti4_1);
	RTHOOK(21);
	ti4_1 = F123_2729(Current, ((EIF_INTEGER_32) 11L));
	F1141_10080(RTCW(loc3), ti4_1);
	RTHOOK(22);
	F1134_9938(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_12_));
	RTHOOK(23);
	F1141_10084(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_12_));
	RTHOOK(24);
	tr1 = RTLNS(eif_new_type(1143, 0x00).id, 1143, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1091_9344(RTCW(tr1));
	F1134_9938(RTCW(loc3), tr1);
	RTHOOK(25);
	F1134_9938(RTCW(loc3), loc1);
	RTHOOK(26);
	F1141_10084(RTCW(loc3), loc1);
	RTHOOK(27);
	F1134_9938(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_11_));
	RTHOOK(28);
	F1141_10084(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_11_));
	RTHOOK(29);
	loc2 = RTLNS(eif_new_type(1170, 0x00).id, 1170, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F1091_9344(RTCW(loc2));
	RTHOOK(30);
	F1134_9938(RTCW(arg1), loc2);
	RTHOOK(31);
	F1141_10084(RTCW(arg1), loc2);
	RTHOOK(32);
	F1134_9938(RTCW(arg1), loc3);
	RTHOOK(33);
	F1141_10084(RTCW(arg1), loc3);
	RTHOOK(34);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.load_first_state */
void F1151_10199 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("load_first_state", 1150, Current, 1, 0, 16435);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc1 = F158_3195(RTCW(tr1));
	RTHOOK(2);
	F128_2841(Current, loc1);
	RTHOOK(3);
	F1151_10218(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.destroy */
void F1151_10201 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("destroy", 1150, Current, 1, 0, 16437);
	RTGC;
	RTHOOK(1);
	F1148_10149(Current);
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(1098, 0x00).id, 1098, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1091_9344(RTCW(tr1));
	tr1 = F1099_9490(RTCW(tr1));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		F1091_9347(loc1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.set_final_state */
void F1151_10209 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_final_state", 1150, Current, 0, 1, 16445);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1122_9745(RTCW(tr1), arg1);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.set_intermediary_state */
void F1151_10210 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_intermediary_state", 1150, Current, 0, 0, 16446);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	RTEE;
}

/* {WIZARD_WINDOW}.disable_next_button */
void F1151_10211 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("disable_next_button", 1150, Current, 0, 0, 16447);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1135_9968(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.disable_back_button */
void F1151_10212 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("disable_back_button", 1150, Current, 0, 0, 16448);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	F1135_9968(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.disable_cancel_button */
void F1151_10213 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("disable_cancel_button", 1150, Current, 0, 0, 16449);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	F1135_9968(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.enable_next_button */
void F1151_10214 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_next_button", 1150, Current, 0, 0, 16450);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1135_9967(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.enable_back_button */
void F1151_10215 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_back_button", 1150, Current, 0, 0, 16451);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	F1135_9967(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.enable_cancel_button */
void F1151_10216 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_cancel_button", 1150, Current, 0, 0, 16452);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	F1135_9967(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.previous_page */
void F1151_10217 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("previous_page", 1150, Current, 0, 0, 16453);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(2734,F124_2734, (Current)))+ _LNGOFF_4_3_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		F128_2837(Current);
	}
	RTHOOK(3);
	F1151_10218(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.update_navigation */
void F1151_10218 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("update_navigation", 1150, Current, 0, 0, 16454);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(2734,F124_2734, (Current)))+ _LNGOFF_4_3_0_0_);
	if (!(EIF_BOOLEAN) (ti4_1 < ((EIF_INTEGER_32) 1L))) {
		tb2 = F662_5527(RTCV(RTOSCF(2734,F124_2734, (Current))));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		F1135_9968(RTCW(tr1));
	} else {
		RTHOOK(3);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_13_4_)) {
			RTHOOK(4);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			F1135_9967(RTCW(tr1));
		} else {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			F1135_9967(RTCW(tr1));
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
			tr2 = F124_2760(Current);
			F1122_9745(RTCW(tr1), tr2);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.next_page */
void F1151_10219 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("next_page", 1150, Current, 0, 0, 16455);
	RTGC;
	RTHOOK(1);
	tb1 = *(EIF_BOOLEAN *)(RTCV(RTOSCF(2734,F124_2734, (Current)))+ _CHROFF_4_2_);
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(2);
		F128_2838(Current);
	}
	RTHOOK(3);
	F1151_10218(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit508 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
