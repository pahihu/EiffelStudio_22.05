
#ifndef _C21_ha1014_
#define _C21_ha1014_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F793_6271(EIF_REFERENCE);
extern EIF_REFERENCE F793_6272(EIF_REFERENCE);
extern EIF_BOOLEAN F793_6274(EIF_REFERENCE);
extern void F793_6275(EIF_REFERENCE);
extern EIF_REFERENCE F793_6276(EIF_REFERENCE);
extern void EIF_Minit1014(void);
extern char *(*R4944[])();
extern char *(*R5660[])();
extern char *(*R5249[])();
extern char *(*R5248[])();
extern char *(*R5481[])();
extern long O5257[];
extern long O5258[];

#ifdef __cplusplus
}
#endif

#endif
