
#ifndef _C21_ev1034_
#define _C21_ev1034_

#ifdef __cplusplus
extern "C" {
#endif

extern void F276_4372(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN);
extern EIF_REFERENCE F276_4374(EIF_REFERENCE);
extern void EIF_Minit1034(void);

#ifdef __cplusplus
}
#endif

#endif
