/*
 * Code for class BILINEAR [CHARACTER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi1048.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BILINEAR}.search */
void F403_5210 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 402, Current, 0, 1, 5614);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (F643_5503(Current)) {
		tb1 = (EIF_BOOLEAN) !F512_5267(Current);
	}
	if (tb1) {
		RTHOOK(2);
		F694_5958(Current);
	}
	RTHOOK(3);
	F392_5193(Current, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit1048 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
