
#ifndef _C21_co1020_
#define _C21_co1020_

#ifdef __cplusplus
extern "C" {
#endif

extern void F365_5038(EIF_REFERENCE);
extern void F365_5039(EIF_REFERENCE);
extern void EIF_Minit1020(void);
extern long O4766[];

#ifdef __cplusplus
}
#endif

#endif
