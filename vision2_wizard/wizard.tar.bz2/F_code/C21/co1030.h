
#ifndef _C21_co1030_
#define _C21_co1030_

#ifdef __cplusplus
extern "C" {
#endif

extern void F416_5218(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit1030(void);
extern char *(*R4763[])();
extern char *(*R4897[])();

#ifdef __cplusplus
}
#endif

#endif
