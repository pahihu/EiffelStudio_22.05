
#ifndef _C21_ty1023_
#define _C21_ty1023_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F775_6243(EIF_REFERENCE);
extern void EIF_Minit1023(void);
extern char *(*R5485[])();
extern char *(*R4944[])();
extern char *(*R5472[])();

#ifdef __cplusplus
}
#endif

#endif
