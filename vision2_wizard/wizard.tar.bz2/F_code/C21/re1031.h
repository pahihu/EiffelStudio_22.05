
#ifndef _C21_re1031_
#define _C21_re1031_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F536_5273(EIF_REFERENCE);
extern void F536_5275(EIF_REFERENCE);
extern void EIF_Minit1031(void);
extern char *(*R4922[])();
extern char *(*R4928[])();

#ifdef __cplusplus
}
#endif

#endif
