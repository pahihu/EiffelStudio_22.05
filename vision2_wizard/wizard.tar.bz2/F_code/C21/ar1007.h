
#ifndef _C21_ar1007_
#define _C21_ar1007_

#ifdef __cplusplus
extern "C" {
#endif

extern void F819_6309(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F819_6310(EIF_REFERENCE);
extern EIF_REFERENCE F819_6313(EIF_REFERENCE);
extern EIF_INTEGER_32 F819_6314(EIF_REFERENCE);
extern void EIF_Minit1007(void);
extern EIF_REFERENCE F693_5929(EIF_REFERENCE);
extern EIF_INTEGER_32 F693_5948(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
