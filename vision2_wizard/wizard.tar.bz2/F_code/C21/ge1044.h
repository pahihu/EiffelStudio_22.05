
#ifndef _C21_ge1044_
#define _C21_ge1044_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F808_6289(EIF_REFERENCE);
extern EIF_INTEGER_32 F808_6291(EIF_REFERENCE);
extern EIF_BOOLEAN F808_6298(EIF_REFERENCE);
extern void F808_6303(EIF_REFERENCE);
extern void F808_6304(EIF_REFERENCE);
extern void EIF_Minit1044(void);
extern char *(*R5500[])();
extern char *(*R5473[])();

#ifdef __cplusplus
}
#endif

#endif
