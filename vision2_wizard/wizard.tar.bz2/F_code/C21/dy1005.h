
#ifndef _C21_dy1005_
#define _C21_dy1005_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F457_5233(EIF_REFERENCE);
extern void EIF_Minit1005(void);

#ifdef __cplusplus
}
#endif

#endif
