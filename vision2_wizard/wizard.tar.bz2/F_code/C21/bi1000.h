
#ifndef _C21_bi1000_
#define _C21_bi1000_

#ifdef __cplusplus
extern "C" {
#endif

extern void F402_5210(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1000(void);
extern void F389_5193(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F509_5267(EIF_REFERENCE);
extern char *(*R4888[])();
extern char *(*R4889[])();

#ifdef __cplusplus
}
#endif

#endif
