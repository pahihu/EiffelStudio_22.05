
#ifndef _C21_fi1025_
#define _C21_fi1025_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F512_5267(EIF_REFERENCE);
extern void EIF_Minit1025(void);
extern char *(*R4921[])();

#ifdef __cplusplus
}
#endif

#endif
