
#ifndef _C21_ha1009_
#define _C21_ha1009_

#ifdef __cplusplus
extern "C" {
#endif

extern void F680_5794(EIF_REFERENCE, EIF_INTEGER_32);
extern void F680_5797(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F680_5798(EIF_REFERENCE);
extern EIF_REFERENCE F680_5800(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F680_5802(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F680_5804(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F680_5806(EIF_REFERENCE);
extern EIF_REFERENCE F680_5807(EIF_REFERENCE);
extern EIF_REFERENCE F680_5808(EIF_REFERENCE);
extern EIF_REFERENCE F680_5809(EIF_REFERENCE);
extern EIF_REFERENCE F680_5810(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F680_5811(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F680_5812(EIF_REFERENCE);
extern EIF_INTEGER_32 F680_5815(EIF_REFERENCE);
extern EIF_INTEGER_32 F680_5816(EIF_REFERENCE);
extern EIF_BOOLEAN F680_5817(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F680_5818(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F680_5823(EIF_REFERENCE);
extern EIF_BOOLEAN F680_5826(EIF_REFERENCE);
extern EIF_BOOLEAN F680_5827(EIF_REFERENCE);
extern EIF_BOOLEAN F680_5828(EIF_REFERENCE);
extern EIF_BOOLEAN F680_5829(EIF_REFERENCE);
extern EIF_BOOLEAN F680_5830(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F680_5832(EIF_REFERENCE, EIF_INTEGER_32);
extern void F680_5833(EIF_REFERENCE);
extern void F680_5834(EIF_REFERENCE);
extern void F680_5835(EIF_REFERENCE, EIF_REFERENCE);
extern void F680_5836(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F680_5838(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F680_5839(EIF_REFERENCE, EIF_INTEGER_32);
extern void F680_5840(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F680_5841(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F680_5846(EIF_REFERENCE, EIF_REFERENCE);
extern void F680_5847(EIF_REFERENCE, EIF_REFERENCE);
extern void F680_5848(EIF_REFERENCE);
extern EIF_REFERENCE F680_5850(EIF_REFERENCE);
extern void F680_5851(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F680_5852(EIF_REFERENCE, EIF_INTEGER_32);
extern void F680_5853(EIF_REFERENCE);
extern EIF_INTEGER_32 F680_5862(EIF_REFERENCE);
extern EIF_BOOLEAN F680_5863(EIF_REFERENCE);
extern EIF_REFERENCE F680_5870(EIF_REFERENCE);
extern EIF_REFERENCE F680_5871(EIF_REFERENCE);
extern EIF_INTEGER_32 F680_5872(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F680_5873(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F680_5874(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F680_5875(EIF_REFERENCE, EIF_INTEGER_32);
extern void F680_5876(EIF_REFERENCE, EIF_REFERENCE);
extern void F680_5878(EIF_REFERENCE, EIF_REFERENCE);
extern void F680_5879(EIF_REFERENCE, EIF_REFERENCE);
extern void F680_5880(EIF_REFERENCE, EIF_REFERENCE);
extern void F680_5884(EIF_REFERENCE, EIF_REFERENCE);
extern void F680_5890(EIF_REFERENCE);
extern void F680_5903(EIF_REFERENCE);
extern void EIF_Minit1009(void);
extern EIF_INTEGER_32 F750_6217(EIF_REFERENCE, EIF_INTEGER_32);
extern void F863_6514(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F867_6493(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_REFERENCE F677_5743(EIF_REFERENCE);
extern void F867_6511(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F867_6514(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F677_5742(EIF_REFERENCE);
extern void F863_6493(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F867_6504(EIF_REFERENCE);
extern void F277_4377(EIF_REFERENCE, EIF_INTEGER_32);
RTOSHF(EIF_REFERENCE,5743)
extern char *(*R5484[])();
extern char *(*R5487[])();
extern char *(*R4944[])();
extern char *(*R5292[])();
extern char *(*R5274[])();
extern char *(*R4905[])();
extern char *(*R5409[])();
extern char *(*R5255[])();
extern char *(*R5321[])();
extern char *(*R5688[])();
extern char *(*R4768[])();
extern char *(*R5217[])();
extern char *(*R5694[])();
extern char *(*R5410[])();
extern char *(*R5411[])();
extern char *(*R6389[])();
extern char *(*R5220[])();
extern char *(*R5221[])();
extern char *(*R5265[])();
extern char *(*R5226[])();
extern char *(*R5227[])();
extern char *(*R4895[])();
extern char *(*R5229[])();
extern char *(*R5243[])();
extern char *(*R5305[])();
extern char *(*R5661[])();
extern char *(*R4908[])();
extern char *(*R5264[])();
extern char *(*R5469[])();
extern char *(*R5660[])();
extern char *(*R5231[])();
extern char *(*R5275[])();
extern char *(*R5276[])();
extern char *(*R5277[])();
extern char *(*R5278[])();
extern char *(*R5237[])();
extern char *(*R5238[])();
extern char *(*R5239[])();
extern char *(*R5674[])();
extern char *(*R5280[])();
extern char *(*R5281[])();
extern char *(*R5282[])();
extern char *(*R5240[])();
extern char *(*R4667[])();
extern char *(*R5286[])();
extern char *(*R5244[])();
extern char *(*R5675[])();
extern char *(*R5246[])();
extern char *(*R5248[])();
extern char *(*R5249[])();
extern long O5273[];
extern long O5257[];
extern long O5258[];
extern long O5259[];
extern long O5260[];
extern long O5261[];
extern long O5262[];
extern long O5263[];
extern long O5221[];
extern long O5266[];
extern long O5267[];
extern long O4766[];
extern long O5307[];
extern long O5271[];
extern long O5272[];
extern long O5230[];
extern EIF_TYPE_INDEX Y4668[];
extern EIF_TYPE_INDEX *Y4668_gen_type [];
extern EIF_TYPE_INDEX Y4907[];
extern EIF_TYPE_INDEX *Y4907_gen_type [];
extern EIF_TYPE_INDEX Y5257[];
extern EIF_TYPE_INDEX *Y5257_gen_type [];
extern EIF_TYPE_INDEX Y5258[];
extern EIF_TYPE_INDEX *Y5258_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
