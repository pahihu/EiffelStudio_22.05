
#ifndef _C21_re1021_
#define _C21_re1021_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F581_5329(EIF_REFERENCE);
extern void EIF_Minit1021(void);
extern void F787_6249(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5484[])();
extern EIF_TYPE_INDEX Y4668[];
extern EIF_TYPE_INDEX *Y4668_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
