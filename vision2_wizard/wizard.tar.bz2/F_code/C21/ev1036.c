/*
 * Code for class EV_DYNAMIC_LIST_I [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1036.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DYNAMIC_LIST_I}.interface_item */
EIF_REFERENCE F1232_11490 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("interface_item", 1231, Current, 0, 0, 17597);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1233_11527(Current, *(EIF_INTEGER_32 *)(Current + O9254[Dtype(Current)-1231]));
}

/* {EV_DYNAMIC_LIST_I}.item */
EIF_REFERENCE F1232_11491 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("item", 1231, Current, 0, 0, 17598);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1233_11527(Current, *(EIF_INTEGER_32 *)(Current + O9254[Dtype(Current)-1231]));
}

/* {EV_DYNAMIC_LIST_I}.cursor */
EIF_REFERENCE F1232_11493 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("cursor", 1231, Current, 2, 0, 17600);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(Current + O9254[Dtype(Current)-1231]);
	RTHOOK(2);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		tb1 = (EIF_BOOLEAN) (loc2 <= F1233_11528(Current));
	}
	if (tb1) {
		RTHOOK(3);
		loc1 = F1232_11491(Current);
	}
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {275,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y9287,Y9287_gen_type,Dftype(Current),1231);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		Result = RTLNS(typres0.id, 275, _OBJSIZ_1_2_0_0_0_0_0_0_);
	}
	ti4_1 = F1233_11528(Current);
	F276_4372(RTCW(Result), loc1, (EIF_BOOLEAN) (loc2 <= ((EIF_INTEGER_32) 0L)), (EIF_BOOLEAN) (loc2 > ti4_1));
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DYNAMIC_LIST_I}.off */
EIF_BOOLEAN F1232_11496 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 1231, Current, 0, 0, 17602);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!(EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]) == ((EIF_INTEGER_32) 0L))) {
		Result = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]) == (EIF_INTEGER_32) (F1233_11528(Current) + ((EIF_INTEGER_32) 1L)));
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DYNAMIC_LIST_I}.index_of */
EIF_INTEGER_32 F1232_11497 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("index_of", 1231, Current, 1, 2, 17603);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(3);
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (Result > ((EIF_INTEGER_32) 0L))) {
				tb1 = (EIF_BOOLEAN) (loc1 > F1233_11528(Current));
			}
			if (tb1) break;
			RTHOOK(4);
			if ((EIF_BOOLEAN)(F1233_11527(Current, loc1) == arg1)) {
				RTHOOK(5);
				Result = (EIF_INTEGER_32) loc1;
			}
			RTHOOK(6);
			loc1++;
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DYNAMIC_LIST_I}.has */
EIF_BOOLEAN F1232_11502 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("has", 1231, Current, 1, 1, 17574);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(2);
		tb1 = '\01';
		if (!Result) {
			tb1 = (EIF_BOOLEAN) (loc1 > F1233_11528(Current));
		}
		if (tb1) break;
		RTHOOK(3);
		tr1 = F1233_11527(Current, loc1);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == arg1);
		RTHOOK(4);
		loc1++;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DYNAMIC_LIST_I}.start */
void F1232_11503 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("start", 1231, Current, 0, 0, 17575);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O9254[Dtype(Current)-1231]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(3);
	RTEE;
}

/* {EV_DYNAMIC_LIST_I}.back */
void F1232_11504 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	
	
	RTEAA("back", 1231, Current, 0, 0, 17576);
	RTHOOK(1);
	(*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]))--;
	RTHOOK(2);
	RTEE;
}

/* {EV_DYNAMIC_LIST_I}.forth */
void F1232_11505 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	
	
	RTEAA("forth", 1231, Current, 0, 0, 17577);
	RTHOOK(1);
	(*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]))++;
	RTHOOK(2);
	RTEE;
}

/* {EV_DYNAMIC_LIST_I}.go_i_th */
void F1232_11506 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("go_i_th", 1231, Current, 0, 1, 17578);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]) < ((EIF_INTEGER_32) 0L))) {
		RTHOOK(3);
		*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]) > (EIF_INTEGER_32) (F1233_11528(Current) + ((EIF_INTEGER_32) 1L)))) {
			RTHOOK(5);
			ti4_1 = F1233_11528(Current);
			*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L));
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST_I}.go_to */
void F1232_11507 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("go_to", 1231, Current, 2, 1, 17579);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {275,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y9287,Y9287_gen_type,dftype,1231);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(dftype, typarr0);
		loc1 = arg1;
		loc1 = RTRV(typres0, loc1);
	}
	RTHOOK(2);
	RTCT0("dlc_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_1_0_);
	if (tb1) {
		RTHOOK(4);
		ti4_1 = F1233_11528(Current);
		*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L));
	} else {
		RTHOOK(5);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_1_1_);
		if (tb1) {
			RTHOOK(6);
			*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		} else {
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				RTHOOK(8);
				ti4_1 = F1232_11497(Current, loc2, ((EIF_INTEGER_32) 1L));
				*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]) = (EIF_INTEGER_32) ti4_1;
			} else {
				
			}
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST_I}.extend */
void F1232_11510 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("extend", 1231, Current, 0, 1, 17582);
	RTGC;
	RTHOOK(1);
	ti4_1 = F1233_11528(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R9285[dtype-1290])(Current, arg1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	RTHOOK(2);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]) == F1233_11528(Current))) {
		RTHOOK(3);
		(*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]))++;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST_I}.replace */
void F1232_11511 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("replace", 1231, Current, 0, 1, 17583);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R9286[dtype-1290])(Current, *(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]));
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R9285[dtype-1290])(Current, arg1, *(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST_I}.put_left */
void F1232_11514 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("put_left", 1231, Current, 0, 1, 17586);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R9285[dtype-1290])(Current, arg1, *(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]));
	RTHOOK(2);
	(*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]))++;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST_I}.put_i_th */
void F1232_11515 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("put_i_th", 1231, Current, 0, 2, 17587);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R9285[dtype-1290])(Current, arg1, arg2);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R9286[dtype-1290])(Current, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST_I}.prune */
void F1232_11518 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("prune", 1231, Current, 1, 1, 17590);
	RTGC;
	RTHOOK(1);
	loc1 = F1232_11497(Current, arg1, ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 <= *(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]))) {
			RTHOOK(4);
			(*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]))--;
		}
		RTHOOK(5);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R9286[dtype-1290])(Current, loc1);
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST_I}.remove */
void F1232_11519 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("remove", 1231, Current, 0, 0, 17591);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R9286[dtype-1290])(Current, *(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]));
	RTHOOK(2);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]) > (EIF_INTEGER_32) (F1233_11528(Current) + ((EIF_INTEGER_32) 1L)))) {
		RTHOOK(3);
		ti4_1 = F1233_11528(Current);
		*(EIF_INTEGER_32 *)(Current + O9254[dtype-1231]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST_I}.wipe_out */
void F1232_11522 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("wipe_out", 1231, Current, 1, 0, 17594);
	RTGC;
	RTHOOK(1);
	loc1 = F1233_11528(Current);
	for (;;) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) break;
		RTHOOK(3);
		F1232_11506(Current, loc1);
		RTHOOK(4);
		F1232_11519(Current);
		RTHOOK(5);
		loc1--;
	}
	RTHOOK(6);
	F1232_11506(Current, loc1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

void EIF_Minit1036 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
