
#ifndef _C21_to1040_
#define _C21_to1040_

#ifdef __cplusplus
extern "C" {
#endif

extern void F312_4843(EIF_REFERENCE, EIF_INTEGER_32);
extern void F312_4844(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F312_4850(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1040(void);
extern void F864_6493(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4606[];
extern EIF_TYPE_INDEX *Y4606_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
