/*
 * Code for class COLLECTION [CHARACTER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1030.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {COLLECTION}.prune_all */
void F416_5218 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("prune_all", 415, Current, 0, 1, 5655);
	RTGC;
	for (;;) {
		RTHOOK(1);
		if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4763[dtype-600])(Current, (EIF_REFERENCE) &arg1)) break;
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4897[dtype-600])(Current, (EIF_REFERENCE) &arg1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit1030 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
