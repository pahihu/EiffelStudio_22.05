
#ifndef _C21_dy1004_
#define _C21_dy1004_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F630_5487(EIF_REFERENCE);
extern void F630_5493(EIF_REFERENCE, EIF_INTEGER_32);
extern void F630_5494(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1004(void);
extern EIF_BOOLEAN F389_5197(EIF_REFERENCE);
extern char *(*R4875[])();
extern char *(*R4914[])();
extern char *(*R4881[])();

#ifdef __cplusplus
}
#endif

#endif
