/*
 * Code for class LINEAR [CHARACTER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li1018.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.has */
EIF_BOOLEAN F392_5191 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("has", 391, Current, 0, 1, 5522);
	RTGC;
	RTHOOK(1);
	F694_5956(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !F619_5478(Current)) {
		RTHOOK(3);
		F694_5962(Current, arg1);
	}
	RTHOOK(4);
	Result = F392_5197(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {LINEAR}.search */
void F392_5193 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 391, Current, 0, 1, 5524);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		for (;;) {
			RTHOOK(2);
			tb1 = '\01';
			if (!F392_5197(Current)) {
				tb1 = (arg1 == F694_5930(Current));
			}
			if (tb1) break;
			RTHOOK(3);
			F694_5958(Current);
		}
	} else {
		for (;;) {
			RTHOOK(4);
			tb2 = '\01';
			if (!F392_5197(Current)) {
				tb2 = (EIF_BOOLEAN)(arg1 == F694_5930(Current));
			}
			if (tb2) break;
			RTHOOK(5);
			F694_5958(Current);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F392_5197 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("exhausted", 391, Current, 0, 0, 5527);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F619_5478(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F392_5199 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 391, Current, 0, 0, 5528);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F512_5267(Current)) {
		Result = F643_5502(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {LINEAR}.do_all */
void F392_5202 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 tw1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTEAA("do_all", 391, Current, 3, 1, 5529);
	RTGC;
	RTHOOK(1);
	loc3 = Current;
	{
		static EIF_TYPE_INDEX typarr0[] = {484,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y4668,Y4668_gen_type,dftype,324);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(dftype, typarr0);
		loc3 = RTRV(typres0,loc3);
	}
	if (EIF_TEST(loc3)) {
		RTHOOK(2);
		loc2 = (EIF_REFERENCE) loc3;
		RTHOOK(3);
		loc1 = F694_5936(loc3);
	}
	RTHOOK(4);
	F694_5956(Current);
	for (;;) {
		RTHOOK(5);
		if (F643_5502(Current)) break;
		RTHOOK(6);
		tw1 = F694_5930(Current);
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_CHARACTER_32)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), tw1);
		RTHOOK(7);
		F694_5958(Current);
	}
	RTHOOK(8);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != NULL) && (EIF_BOOLEAN)(loc1 != NULL))) {
		RTHOOK(9);
		F694_5961(RTCW(loc2), loc1);
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {LINEAR}.linear_representation */
EIF_REFERENCE F392_5206 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("linear_representation", 391, Current, 0, 0, 5533);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) Current;
}

void EIF_Minit1018 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
