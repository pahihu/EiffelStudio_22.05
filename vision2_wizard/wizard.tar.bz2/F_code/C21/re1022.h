
#ifndef _C21_re1022_
#define _C21_re1022_

#ifdef __cplusplus
extern "C" {
#endif

extern void F787_6249(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F787_6251(EIF_REFERENCE);
extern EIF_INTEGER_32 F787_6252(EIF_REFERENCE);
extern EIF_INTEGER_32 F787_6253(EIF_REFERENCE);
extern EIF_INTEGER_32 F787_6254(EIF_REFERENCE);
extern EIF_BOOLEAN F787_6261(EIF_REFERENCE);
extern EIF_BOOLEAN F787_6262(EIF_REFERENCE);
extern EIF_BOOLEAN F787_6263(EIF_REFERENCE);
extern void F787_6268(EIF_REFERENCE);
extern void F787_6269(EIF_REFERENCE);
extern EIF_REFERENCE F787_6270(EIF_REFERENCE);
extern void EIF_Minit1022(void);
extern char *(*R4945[])();
extern char *(*R4946[])();
extern char *(*R4948[])();

#ifdef __cplusplus
}
#endif

#endif
