/*
 * Code for class DYNAMIC_CHAIN [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dy1004.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DYNAMIC_CHAIN}.extendible */
EIF_BOOLEAN F630_5487 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("extendible", 629, Current, 0, 0, 7140);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {DYNAMIC_CHAIN}.prune */
void F630_5493 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("prune", 629, Current, 0, 1, 7141);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4881[dtype-661])(Current, (EIF_REFERENCE) &arg1);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !F389_5197(Current)) {
		RTHOOK(3);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4914[dtype-661])(Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {DYNAMIC_CHAIN}.prune_all */
void F630_5494 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("prune_all", 629, Current, 0, 1, 7142);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4875[dtype-661])(Current);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4881[dtype-661])(Current, (EIF_REFERENCE) &arg1);
	for (;;) {
		RTHOOK(3);
		if (F389_5197(Current)) break;
		RTHOOK(4);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4914[dtype-661])(Current);
		RTHOOK(5);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4881[dtype-661])(Current, (EIF_REFERENCE) &arg1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

void EIF_Minit1004 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
