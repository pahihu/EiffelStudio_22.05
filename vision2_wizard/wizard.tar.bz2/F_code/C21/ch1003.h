
#ifndef _C21_ch1003_
#define _C21_ch1003_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F618_5463(EIF_REFERENCE);
extern EIF_INTEGER_32 F618_5464(EIF_REFERENCE);
extern EIF_BOOLEAN F618_5465(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F618_5467(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F618_5468(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F618_5470(EIF_REFERENCE);
extern void F618_5472(EIF_REFERENCE);
extern EIF_BOOLEAN F618_5475(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F618_5476(EIF_REFERENCE);
extern EIF_BOOLEAN F618_5478(EIF_REFERENCE);
extern void F618_5483(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1003(void);
extern EIF_BOOLEAN F630_5487(EIF_REFERENCE);
extern EIF_BOOLEAN F509_5267(EIF_REFERENCE);
extern EIF_BOOLEAN F389_5191(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R4909[])();
extern char *(*R4873[])();
extern char *(*R4874[])();
extern char *(*R4875[])();
extern char *(*R4915[])();
extern char *(*R4917[])();
extern char *(*R4882[])();
extern char *(*R4887[])();
extern char *(*R4888[])();
extern char *(*R5034[])();
extern char *(*R4921[])();
extern char *(*R4770[])();
extern char *(*R4895[])();

#ifdef __cplusplus
}
#endif

#endif
