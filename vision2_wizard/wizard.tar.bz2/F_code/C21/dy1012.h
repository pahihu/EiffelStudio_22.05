
#ifndef _C21_dy1012_
#define _C21_dy1012_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F451_5233(EIF_REFERENCE);
extern void EIF_Minit1012(void);

#ifdef __cplusplus
}
#endif

#endif
