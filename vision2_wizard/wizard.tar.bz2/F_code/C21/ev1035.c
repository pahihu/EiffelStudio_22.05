/*
 * Code for class EV_DYNAMIC_LIST [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1035.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DYNAMIC_LIST}.item */
EIF_REFERENCE F1134_9920 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("item", 1133, Current, 0, 0, 16176);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1232_11491(RTCW(tr1));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DYNAMIC_LIST}.index */
EIF_INTEGER_32 F1134_9921 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("index", 1133, Current, 0, 0, 16177);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1) + O9254[Dtype(tr1)-1231]);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DYNAMIC_LIST}.cursor */
EIF_REFERENCE F1134_9922 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("cursor", 1133, Current, 0, 0, 16178);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1232_11493(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DYNAMIC_LIST}.i_th */
EIF_REFERENCE F1134_9923 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("i_th", 1133, Current, 0, 1, 16179);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1233_11527(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DYNAMIC_LIST}.index_of */
EIF_INTEGER_32 F1134_9924 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("index_of", 1133, Current, 0, 2, 16180);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1232_11497(RTCW(tr1), arg1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DYNAMIC_LIST}.count */
EIF_INTEGER_32 F1134_9927 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("count", 1133, Current, 0, 0, 16183);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1233_11528(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DYNAMIC_LIST}.start */
void F1134_9930 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("start", 1133, Current, 0, 0, 16186);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1232_11503(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST}.back */
void F1134_9931 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("back", 1133, Current, 0, 0, 16187);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1232_11504(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST}.forth */
void F1134_9932 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("forth", 1133, Current, 0, 0, 16188);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1232_11505(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST}.go_i_th */
void F1134_9933 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("go_i_th", 1133, Current, 0, 1, 16189);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1232_11506(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST}.go_to */
void F1134_9934 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("go_to", 1133, Current, 0, 1, 16190);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1232_11507(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST}.extend */
void F1134_9938 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("extend", 1133, Current, 0, 1, 16194);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1232_11510(RTCW(tr1), arg1);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST}.replace */
void F1134_9939 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("replace", 1133, Current, 0, 1, 16195);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1232_11511(RTCW(tr1), arg1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST}.put_left */
void F1134_9942 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("put_left", 1133, Current, 0, 1, 16153);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1232_11514(RTCW(tr1), arg1);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST}.put_i_th */
void F1134_9943 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("put_i_th", 1133, Current, 0, 2, 16154);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1232_11515(RTCW(tr1), arg1, arg2);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST}.prune */
void F1134_9947 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("prune", 1133, Current, 0, 1, 16158);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1232_11518(RTCW(tr1), arg1);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST}.remove */
void F1134_9948 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("remove", 1133, Current, 0, 0, 16159);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1232_11519(RTCW(tr1));
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST}.wipe_out */
void F1134_9951 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("wipe_out", 1133, Current, 0, 0, 16162);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1232_11522(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST}.dl_extend */
void F1134_9956 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("dl_extend", 1133, Current, 0, 1, 16166);
	RTHOOK(1);
	F1134_9938(Current, arg1);
	RTHOOK(2);
	RTEE;
}

/* {EV_DYNAMIC_LIST}.dl_replace */
void F1134_9957 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("dl_replace", 1133, Current, 0, 1, 16167);
	RTHOOK(1);
	F1134_9939(Current, arg1);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit1035 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
