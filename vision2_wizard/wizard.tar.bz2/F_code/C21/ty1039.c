/*
 * Code for class TYPE [expanded EV_STOCK_COLORS]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ty1039.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TYPE}.name_32 */
EIF_REFERENCE F959_7504 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("name_32", 958, Current, 0, 0, 13073);
	RTGC;
	RTHOOK(1);
	Result = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		RTHOOK(3);
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_1_0_0_4_0_0_0_0_);
		tr1 = (EIF_REFERENCE) eif_builtin_TYPE_runtime_name__s1 (Current);
		F1062_9116(RTCW(Result), tr1);
		RTHOOK(4);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) Result;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {TYPE}.name */
EIF_REFERENCE F959_7505 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("name", 958, Current, 2, 0, 13074);
	RTGC;
	RTHOOK(1);
	Result = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		RTHOOK(3);
		loc1 = (EIF_REFERENCE) eif_builtin_TYPE_runtime_name__s1 (Current);
		RTHOOK(4);
		Result = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_0_0_4_0_0_0_0_);
		loc2 = loc1;
		if (EIF_TEST(loc2)) {
			RTHOOK(5);
			tr1 = loc2;
		} else {
			RTHOOK(6);
			tr2 = RTLNS(eif_new_type(48, 0x00).id, 48, _OBJSIZ_0_0_0_0_0_0_0_0_);
			tr1 = F49_899(RTCW(tr2), loc1);
		}
		F1057_8899(RTCW(Result), tr1);
		RTHOOK(7);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) Result;
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {TYPE}.generic_parameter_type */
EIF_REFERENCE F959_7506 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("generic_parameter_type", 958, Current, 0, 1, 13075);
	Result = (EIF_REFERENCE) eif_builtin_TYPE_generic_parameter_type__i4_t (Current, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {TYPE}.type_id */
EIF_INTEGER_32 F959_7507 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("type_id", 958, Current, 0, 0, 13076);
	Result = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (Current);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {TYPE}.hash_code */
EIF_INTEGER_32 F959_7508 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("hash_code", 958, Current, 0, 0, 13077);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (Current);
}

/* {TYPE}.is_attached */
EIF_BOOLEAN F959_7513 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_attached", 958, Current, 0, 0, 13082);
	Result = (EIF_BOOLEAN) eif_builtin_TYPE_is_attached__b (Current);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TYPE}.is_equal */
EIF_BOOLEAN F959_7514 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("is_equal", 958, Current, 0, 1, 13083);
	RTGC;
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (Current);
	ti4_2 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (arg1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {TYPE}.attempted */
EIF_REFERENCE F959_7518 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	struct eif_ex_1037 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_gen_param(Dftype(Current), 1).id);
	RTLI(5);
	RTLR(0,Result);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("attempted", 958, Current, 1, 1, 13087);
	RTGC;
	Result= RTLN(eif_gen_param(Dftype(Current), 1).id);
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	RTOE(eif_gen_param(Dftype(Current), 1), tr1, loc1, tb1);
	if (tb1) {
		RTHOOK(2);
		tr1 = RTRCL(loc1);
		RTXA(tr1, Result);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {TYPE}.default */
EIF_REFERENCE F959_7521 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	struct eif_ex_1037 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_gen_param(Dftype(Current), 1).id);
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default", 958, Current, 1, 0, 13090);
	RTGC;
	Result= RTLN(eif_gen_param(Dftype(Current), 1).id);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TYPE}.out */
EIF_REFERENCE F959_7522 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("out", 958, Current, 2, 0, 13091);
	RTGC;
	RTHOOK(1);
	tr1 = F959_7504(Current);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1056, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1057_8899(RTCW(tr1), loc1);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		tr1 = F959_7505(Current);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(5);
			tr1 = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1057_8899(RTCW(tr1), loc2);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) tr1;
		} else {
			RTHOOK(7);
			RTCT0("known_string_type", EX_CHECK);
				RTCF0;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {TYPE}.runtime_name */
EIF_REFERENCE F959_7533 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("runtime_name", 958, Current, 0, 0, 13072);
	Result = (EIF_REFERENCE) eif_builtin_TYPE_runtime_name__s1 (Current);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit1039 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
