
#ifndef _C21_bi1048_
#define _C21_bi1048_

#ifdef __cplusplus
extern "C" {
#endif

extern void F403_5210(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit1048(void);
extern EIF_BOOLEAN F512_5267(EIF_REFERENCE);
extern EIF_BOOLEAN F643_5503(EIF_REFERENCE);
extern void F694_5958(EIF_REFERENCE);
extern void F392_5193(EIF_REFERENCE, EIF_CHARACTER_32);

#ifdef __cplusplus
}
#endif

#endif
