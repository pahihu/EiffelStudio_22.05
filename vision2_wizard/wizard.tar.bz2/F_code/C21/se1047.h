
#ifndef _C21_se1047_
#define _C21_se1047_

#ifdef __cplusplus
extern "C" {
#endif

extern void F547_5280(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit1047(void);
extern void F694_5966(EIF_REFERENCE, EIF_CHARACTER_32);

#ifdef __cplusplus
}
#endif

#endif
