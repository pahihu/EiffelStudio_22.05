/*
 * Code for class HASH_TABLE [G#1, G#2]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ha1009.h"
#include "eif_built_in.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {HASH_TABLE}.make */
void F680_5794 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("make", 679, Current, 4, 1, 7704);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(749, 0x00).id, 749, _OBJSIZ_0_1_0_1_0_0_0_0_);
	RTHOOK(2);
	loc4 = eif_max_int32 (arg1,((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 + (EIF_INTEGER_32) (loc4 / ((EIF_INTEGER_32) 2L))) + ((EIF_INTEGER_32) 1L));
	RTHOOK(4);
	ti4_1 = F750_6217(RTCW(loc1), loc4);
	loc4 = (EIF_INTEGER_32) ti4_1;
	RTHOOK(5);
	*(EIF_INTEGER_32 *)(Current + O5230[dtype-679]) = (EIF_INTEGER_32) loc4;
	RTHOOK(6);
	tr1 = RTLNSP2(eif_final_id(Y5257,Y5257_gen_type,dftype,679).id,EO_REF,(EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)),sizeof(EIF_REFERENCE), EIF_FALSE);
	RT_SPECIAL_COUNT(tr1) = 0;
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O5257[dtype-679]) = (EIF_REFERENCE) tr1;
	RTHOOK(7);
	tr1 = RTLNSP2(eif_final_id(Y5258,Y5258_gen_type,dftype,679).id,EO_REF,(EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)),sizeof(EIF_REFERENCE), EIF_FALSE);
	RT_SPECIAL_COUNT(tr1) = 0;
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O5258[dtype-679]) = (EIF_REFERENCE) tr1;
	RTHOOK(8);
	{
		static EIF_TYPE_INDEX typarr0[] = {866,1000,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSP2(typres0.id,0,(EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)),sizeof(EIF_BOOLEAN), EIF_TRUE);
	}
	F867_6493(RTCW(tr1), (EIF_BOOLEAN) 0, (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O5260[dtype-679]) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	{
		static EIF_TYPE_INDEX typarr0[] = {862,1006,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSP2(typres0.id,0,(EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)),sizeof(EIF_INTEGER_32), EIF_TRUE);
	}
	F863_6493(RTCW(tr1), ((EIF_INTEGER_32) -1L), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O5259[dtype-679]) = (EIF_REFERENCE) tr1;
	RTHOOK(10);
	*(EIF_INTEGER_32 *)(Current + O5263[dtype-679]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
	RTHOOK(11);
	*(EIF_INTEGER_32 *)(Current + O5307[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(12);
	*(EIF_INTEGER_32 *)(Current + O5267[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(13);
	*(EIF_INTEGER_32 *)(Current + O5266[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(14);
	tr1 = RTCCL(loc2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O5221[dtype-679]) = (EIF_REFERENCE) tr1;
	RTHOOK(15);
	*(EIF_BOOLEAN *)(Current + O5262[dtype-679]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(16);
	*(EIF_INTEGER_32 *)(Current + O5261[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(17);
	*(EIF_INTEGER_32 *)(Current + O5271[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483645L);
	RTHOOK(18);
	tr1 = RTCCL(loc2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O5272[dtype-679]) = (EIF_REFERENCE) tr1;
	RTHOOK(19);
	tr1 = RTCCL(loc3);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O5273[dtype-679]) = (EIF_REFERENCE) tr1;
	RTHOOK(23);
	RTLE;
	RTEE;
}

/* {HASH_TABLE}.accommodate */
void F680_5797 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,loc5);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,tr4);
	RTLIU(8);
	
	RTEAA("accommodate", 679, Current, 5, 1, 7707);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5660[Dtype(RTCW(tr1))-858])(tr1);
	ti4_1 = eif_max_int32 (ti4_1,arg1);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5255[dtype-679])(Current, ti4_1);
	RTHOOK(2);
	loc4 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
	RTHOOK(3);
	loc5 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
	RTHOOK(4);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5660[Dtype(RTCW(loc5))-858])(loc5);
	for (;;) {
		RTHOOK(5);
		if ((EIF_BOOLEAN)(loc1 == loc2)) break;
		RTHOOK(6);
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R5275[dtype-679])(Current, loc1)) {
			RTHOOK(7);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(loc4))-600])(loc4, loc1);
			tr2 = RTCCL(tr1);
			tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(loc5))-600])(loc5, loc1);
			tr4 = RTCCL(tr3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4905[Dtype(RTCW(loc3))-600])(loc3, tr2, tr4);
		}
		RTHOOK(8);
		loc1++;
	}
	RTHOOK(9);
	if (*(EIF_BOOLEAN *)(Current + O5262[dtype-679])) {
		RTHOOK(10);
		tr1 = *(EIF_REFERENCE *)(Current + O5259[dtype-679]);
		/* INLINED CODE (SPECIAL.item) */
		ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current + O5230[dtype-679])));
		/* END INLINED CODE */
		loc1 = ti4_3;
		RTHOOK(11);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(loc4))-600])(loc4, loc1);
		tr2 = RTCCL(tr1);
		tr3 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
		tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(tr3))-600])(tr3, loc1);
		tr4 = RTCCL(tr3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4905[Dtype(RTCW(loc3))-600])(loc3, tr2, tr4);
	}
	RTHOOK(12);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + O5257[Dtype(loc3)-679]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5278[dtype-679])(Current, tr1);
	RTHOOK(13);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + O5258[Dtype(loc3)-679]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5280[dtype-679])(Current, tr1);
	RTHOOK(14);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + O5260[Dtype(loc3)-679]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5281[dtype-679])(Current, tr1);
	RTHOOK(15);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + O5259[Dtype(loc3)-679]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5282[dtype-679])(Current, tr1);
	RTHOOK(16);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O5230[Dtype(loc3)-679]);
	*(EIF_INTEGER_32 *)(Current + O5230[dtype-679]) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(17);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O5263[Dtype(loc3)-679]);
	*(EIF_INTEGER_32 *)(Current + O5263[dtype-679]) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(20);
	RTLE;
	RTEE;
}

/* {HASH_TABLE}.found_item */
EIF_REFERENCE F680_5798 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O5221[Dtype(Current)-679]);
}


/* {HASH_TABLE}.item */
EIF_REFERENCE F680_5800 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,Result);
	RTLR(6,loc9);
	RTLR(7,loc10);
	RTLR(8,loc11);
	RTLR(9,loc12);
	RTLIU(10);
	
	RTEAA("item", 679, Current, 12, 1, 7710);
	RTGC;
	RTHOOK(1);
	loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(2);
	if ((EIF_BOOLEAN) (RTCEQ(arg1, loc1) || (EIF_BOOLEAN)(arg1 == NULL))) {
		RTHOOK(3);
		if (*(EIF_BOOLEAN *)(Current + O5262[dtype-679])) {
			RTHOOK(4);
			tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
			tr2 = *(EIF_REFERENCE *)(Current + O5259[dtype-679]);
			/* INLINED CODE (SPECIAL.item) */
			ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current + O5230[dtype-679])));
			/* END INLINED CODE */
			ti4_1 = ti4_3;
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(tr1))-600])(tr1, ti4_1);
		}
	} else {
		RTHOOK(5);
		loc9 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
		RTHOOK(6);
		loc10 = *(EIF_REFERENCE *)(Current + O5259[dtype-679]);
		RTHOOK(7);
		loc11 = *(EIF_REFERENCE *)(Current + O5260[dtype-679]);
		RTHOOK(8);
		loc6 = *(EIF_INTEGER_32 *)(Current + O5230[dtype-679]);
		RTHOOK(9);
		loc8 = (EIF_INTEGER_32) loc6;
		RTHOOK(10);
		tr1 = RTCCL(arg1);
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R5229[dtype-679])(Current, tr1);
		RTHOOK(11);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) (loc2 % (EIF_INTEGER_32) (loc6 - ((EIF_INTEGER_32) 1L))));
		RTHOOK(12);
		loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 % loc6) - loc3);
		for (;;) {
			RTHOOK(13);
			if ((EIF_BOOLEAN)(loc8 == ((EIF_INTEGER_32) 0L))) break;
			RTHOOK(14);
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + loc3) % loc6);
			RTHOOK(15);
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(loc10) + (loc5));
			/* END INLINED CODE */
			loc4 = ti4_2;
			RTHOOK(16);
			if ((EIF_BOOLEAN) (loc4 >= ((EIF_INTEGER_32) 0L))) {
				RTHOOK(17);
				loc12 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(loc9))-600])(loc9, loc4);
				RTHOOK(18);
				tr1 = RTCCL(loc12);
				tr2 = RTCCL(arg1);
				if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5231[dtype-679])(Current, tr1, tr2)) {
					RTHOOK(19);
					loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					RTHOOK(20);
					tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
					Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(tr1))-600])(tr1, loc4);
				}
			} else {
				RTHOOK(21);
				if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L))) {
					RTHOOK(22);
					loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				} else {
					RTHOOK(23);
					if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) -1L))) {
						RTHOOK(24);
						loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) -loc4 + ((EIF_INTEGER_32) -2L));
						
						RTHOOK(26);
						/* INLINED CODE (SPECIAL.item) */
						tb2 = *((EIF_BOOLEAN *)RTCW(loc11) + (loc4));
						/* END INLINED CODE */
						tb1 = tb2;
						if ((EIF_BOOLEAN) !tb1) {
							RTHOOK(27);
							loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							RTHOOK(28);
							loc7 = (EIF_INTEGER_32) loc5;
						}
					}
				}
			}
			RTHOOK(29);
			loc8--;
		}
	}
	RTHOOK(31);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.has */
EIF_BOOLEAN F680_5802 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,loc9);
	RTLR(4,loc10);
	RTLR(5,loc11);
	RTLR(6,tr1);
	RTLR(7,loc12);
	RTLR(8,tr2);
	RTLIU(9);
	
	RTEAA("has", 679, Current, 12, 1, 7712);
	RTGC;
	RTHOOK(1);
	loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(2);
	if ((EIF_BOOLEAN) (RTCEQ(arg1, loc1) || (EIF_BOOLEAN)(arg1 == NULL))) {
		RTHOOK(3);
		if (*(EIF_BOOLEAN *)(Current + O5262[dtype-679])) {
			RTHOOK(4);
			RTHOOK(5);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		RTHOOK(6);
		loc9 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
		RTHOOK(7);
		loc10 = *(EIF_REFERENCE *)(Current + O5259[dtype-679]);
		RTHOOK(8);
		loc11 = *(EIF_REFERENCE *)(Current + O5260[dtype-679]);
		RTHOOK(9);
		loc6 = *(EIF_INTEGER_32 *)(Current + O5230[dtype-679]);
		RTHOOK(10);
		loc8 = (EIF_INTEGER_32) loc6;
		RTHOOK(11);
		tr1 = RTCCL(arg1);
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R5229[dtype-679])(Current, tr1);
		RTHOOK(12);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) (loc2 % (EIF_INTEGER_32) (loc6 - ((EIF_INTEGER_32) 1L))));
		RTHOOK(13);
		loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 % loc6) - loc3);
		for (;;) {
			RTHOOK(14);
			if ((EIF_BOOLEAN)(loc8 == ((EIF_INTEGER_32) 0L))) break;
			RTHOOK(15);
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + loc3) % loc6);
			RTHOOK(16);
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(loc10) + (loc5));
			/* END INLINED CODE */
			loc4 = ti4_2;
			RTHOOK(17);
			if ((EIF_BOOLEAN) (loc4 >= ((EIF_INTEGER_32) 0L))) {
				RTHOOK(18);
				loc12 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(loc9))-600])(loc9, loc4);
				RTHOOK(19);
				tr1 = RTCCL(loc12);
				tr2 = RTCCL(arg1);
				if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5231[dtype-679])(Current, tr1, tr2)) {
					RTHOOK(20);
					loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					RTHOOK(21);
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				RTHOOK(22);
				if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L))) {
					RTHOOK(23);
					loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				} else {
					RTHOOK(24);
					if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) -1L))) {
						RTHOOK(25);
						loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) -loc4 + ((EIF_INTEGER_32) -2L));
						
						RTHOOK(27);
						/* INLINED CODE (SPECIAL.item) */
						tb2 = *((EIF_BOOLEAN *)RTCW(loc11) + (loc4));
						/* END INLINED CODE */
						tb1 = tb2;
						if ((EIF_BOOLEAN) !tb1) {
							RTHOOK(28);
							loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							RTHOOK(29);
							loc7 = (EIF_INTEGER_32) loc5;
						}
					}
				}
			}
			RTHOOK(30);
			loc8--;
		}
	}
	RTHOOK(32);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.has_item */
EIF_BOOLEAN F680_5804 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("has_item", 679, Current, 3, 1, 7714);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current + O5262[dtype-679])) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
		tr2 = *(EIF_REFERENCE *)(Current + O5259[dtype-679]);
		/* INLINED CODE (SPECIAL.item) */
		ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current + O5230[dtype-679])));
		/* END INLINED CODE */
		ti4_1 = ti4_3;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(tr1))-600])(tr1, ti4_1);
		Result = (EIF_BOOLEAN) RTCEQ(arg1, tr1);
	}
	RTHOOK(3);
	if ((EIF_BOOLEAN) !Result) {
		RTHOOK(4);
		loc3 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
		RTHOOK(5);
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5660[Dtype(RTCW(loc3))-858])(loc3);
		RTHOOK(6);
		if (*(EIF_BOOLEAN *)(Current + O4766[dtype-358])) {
			for (;;) {
				RTHOOK(7);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == loc2) || Result)) break;
				RTHOOK(8);
				Result = '\0';
				if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R5275[dtype-679])(Current, loc1)) {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(loc3))-600])(loc3, loc1);
					Result = RTEQ(arg1, tr1);
				}
				RTHOOK(9);
				loc1++;
			}
		} else {
			for (;;) {
				RTHOOK(10);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == loc2) || Result)) break;
				RTHOOK(11);
				Result = '\0';
				if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R5275[dtype-679])(Current, loc1)) {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(loc3))-600])(loc3, loc1);
					Result = RTCEQ(arg1, tr1);
				}
				RTHOOK(12);
				loc1++;
			}
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.item_for_iteration */
EIF_REFERENCE F680_5806 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("item_for_iteration", 679, Current, 0, 0, 7716);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(tr1))-600])(tr1, *(EIF_INTEGER_32 *)(Current + O5263[dtype-679]));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.key_for_iteration */
EIF_REFERENCE F680_5807 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("key_for_iteration", 679, Current, 0, 0, 7717);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(tr1))-600])(tr1, *(EIF_INTEGER_32 *)(Current + O5263[dtype-679]));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.cursor */
EIF_REFERENCE F680_5808 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("cursor", 679, Current, 0, 0, 7718);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(276, 0x00).id, 276, _OBJSIZ_0_0_0_1_0_0_0_0_);
	F277_4377(RTCW(tr1), *(EIF_INTEGER_32 *)(Current + O5263[Dtype(Current)-679]));
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {HASH_TABLE}.new_cursor */
EIF_REFERENCE F680_5809 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("new_cursor", 679, Current, 0, 0, 7719);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {792,0,0,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y4668,Y4668_gen_type,Dftype(Current),324);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y4907,Y4907_gen_type,Dftype(Current),434);
			typarr0[3] = l_type.annotations | 0xFF00;
			typarr0[4] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		Result = RTLNS(typres0.id, 792, _OBJSIZ_1_1_0_5_0_0_0_0_);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5487[Dtype(RTCW(Result))-780])(Result, Current);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5484[Dtype(RTCW(Result))-780])(Result);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.iteration_item */
EIF_REFERENCE F680_5810 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("iteration_item", 679, Current, 0, 1, 7720);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5257[Dtype(Current)-679]);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(tr1))-600])(tr1, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.hash_code_of */
EIF_INTEGER_32 F680_5811 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	
	
	RTEAA("hash_code_of", 679, Current, 0, 1, 7721);
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6389[Dtype(RTCW(arg1))-938])(arg1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {HASH_TABLE}.count */
EIF_INTEGER_32 F680_5812 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O5307[Dtype(Current)-679]);
}


/* {HASH_TABLE}.iteration_lower */
EIF_INTEGER_32 F680_5815 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("iteration_lower", 679, Current, 0, 0, 7725);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5248[Dtype(Current)-679])(Current, ((EIF_INTEGER_32) -1L));
}

/* {HASH_TABLE}.iteration_upper */
EIF_INTEGER_32 F680_5816 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("iteration_upper", 679, Current, 0, 0, 7726);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5660[Dtype(RTCW(tr1))-858])(tr1);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5249[dtype-679])(Current, ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.is_equal */
EIF_BOOLEAN F680_5817 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("is_equal", 679, Current, 1, 1, 7727);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tb2 = '\0';
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O5307[Dtype(arg1)-679]);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5307[dtype-679]) == ti4_1)) {
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg1) + O4766[Dtype(arg1)-358]);
		tb2 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O4766[dtype-358]) == tb3);
	}
	if (tb2) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O5262[Dtype(arg1)-679]);
		tb1 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O5262[dtype-679]) == tb2);
	}
	if (tb1) {
		RTHOOK(2);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(3);
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4667[dtype-661])(Current);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5410[Dtype(loc1)-745])(loc1);
			if (tb1) break;
			RTHOOK(4);
			if ((EIF_BOOLEAN) !Result) break;
			RTHOOK(5);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5469[Dtype(loc1)-792])(loc1);
			tr2 = RTCCL(tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5246[Dtype(RTCW(arg1))-679])(arg1, tr2);
			RTHOOK(6);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5237[Dtype(RTCW(arg1))-679])(arg1);
			if (tb2) {
				RTHOOK(7);
				if (*(EIF_BOOLEAN *)(Current + O4766[dtype-358])) {
					RTHOOK(8);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5409[Dtype(loc1)-745])(loc1);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5221[Dtype(RTCW(arg1))-679])(arg1);
					Result = (EIF_BOOLEAN) RTEQ(tr1, tr2);
				} else {
					RTHOOK(9);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5409[Dtype(loc1)-745])(loc1);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5221[Dtype(RTCW(arg1))-679])(arg1);
					Result = (EIF_BOOLEAN) RTCEQ(tr1, tr2);
				}
			} else {
				RTHOOK(10);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			RTHOOK(11);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5411[Dtype(loc1)-745])(loc1);
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.same_keys */
EIF_BOOLEAN F680_5818 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	
	
	RTEAA("same_keys", 679, Current, 0, 2, 7728);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) RTEQ(arg1, arg2);
}

/* {HASH_TABLE}.inserted */
EIF_BOOLEAN F680_5823 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("inserted", 679, Current, 0, 0, 7733);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5266[Dtype(Current)-679]) == ((EIF_INTEGER_32) 4L));
}

/* {HASH_TABLE}.found */
EIF_BOOLEAN F680_5826 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("found", 679, Current, 0, 0, 7736);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5266[Dtype(Current)-679]) == ((EIF_INTEGER_32) 2L));
}

/* {HASH_TABLE}.not_found */
EIF_BOOLEAN F680_5827 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("not_found", 679, Current, 0, 0, 7737);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5266[Dtype(Current)-679]) == ((EIF_INTEGER_32) 8L));
}

/* {HASH_TABLE}.after */
EIF_BOOLEAN F680_5828 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	
	
	RTEAA("after", 679, Current, 0, 0, 7738);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R5277[dtype-679])(Current, *(EIF_INTEGER_32 *)(Current + O5263[dtype-679]));
}

/* {HASH_TABLE}.off */
EIF_BOOLEAN F680_5829 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	
	
	RTEAA("off", 679, Current, 0, 0, 7739);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R5277[dtype-679])(Current, *(EIF_INTEGER_32 *)(Current + O5263[dtype-679]));
}

/* {HASH_TABLE}.valid_cursor */
EIF_BOOLEAN F680_5830 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("valid_cursor", 679, Current, 2, 1, 7740);
	RTGC;
	RTHOOK(1);
	loc2 = arg1;
	loc2 = RTRV(eif_new_type(276, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		loc1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_0_0_0_0_);
		RTHOOK(3);
		Result = '\01';
		if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R5277[dtype-679])(Current, loc1)) {
			Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R5276[dtype-679])(Current, loc1);
		}
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.valid_iteration_index */
EIF_BOOLEAN F680_5832 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("valid_iteration_index", 679, Current, 0, 1, 7742);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R5276[Dtype(Current)-679])(Current, arg1);
}

/* {HASH_TABLE}.start */
void F680_5833 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("start", 679, Current, 0, 0, 7743);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5248[dtype-679])(Current, ((EIF_INTEGER_32) -1L));
	*(EIF_INTEGER_32 *)(Current + O5263[dtype-679]) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {HASH_TABLE}.forth */
void F680_5834 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("forth", 679, Current, 0, 0, 7744);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5248[dtype-679])(Current, *(EIF_INTEGER_32 *)(Current + O5263[dtype-679]));
	*(EIF_INTEGER_32 *)(Current + O5263[dtype-679]) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {HASH_TABLE}.go_to */
void F680_5835 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("go_to", 679, Current, 1, 1, 7745);
	RTGC;
	RTHOOK(1);
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(276, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_0_0_0_0_);
		*(EIF_INTEGER_32 *)(Current + O5263[Dtype(Current)-679]) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {HASH_TABLE}.search */
void F680_5836 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("search", 679, Current, 2, 1, 7746);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(Current + O5261[dtype-679]);
	RTHOOK(2);
	tr1 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5286[dtype-679])(Current, tr1);
	RTHOOK(3);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5237[dtype-679])(Current)) {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5264[dtype-679])(Current);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(tr1))-600])(tr1, ti4_1);
		tr1 = RTCCL(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O5221[dtype-679]) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(5);
		tr1 = RTCCL(loc2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O5221[dtype-679]) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(6);
	*(EIF_INTEGER_32 *)(Current + O5261[dtype-679]) = (EIF_INTEGER_32) loc1;
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {HASH_TABLE}.next_iteration_position */
EIF_INTEGER_32 F680_5838 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_iteration_position", 679, Current, 2, 1, 7748);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + O5260[dtype-679]);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5660[Dtype(RTCW(tr1))-858])(tr1);
	RTHOOK(3);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
	for (;;) {
		RTHOOK(4);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (Result >= loc2)) {
			/* INLINED CODE (SPECIAL.item) */
			tb3 = *((EIF_BOOLEAN *)RTCW(loc1) + (Result));
			/* END INLINED CODE */
			tb2 = tb3;
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		RTHOOK(5);
		Result++;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.previous_iteration_position */
EIF_INTEGER_32 F680_5839 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("previous_iteration_position", 679, Current, 1, 1, 7749);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + O5260[Dtype(Current)-679]);
	RTHOOK(2);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (Result <= ((EIF_INTEGER_32) -1L))) {
			/* INLINED CODE (SPECIAL.item) */
			tb3 = *((EIF_BOOLEAN *)RTCW(loc1) + (Result));
			/* END INLINED CODE */
			tb2 = tb3;
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		Result--;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.put */
void F680_5840 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTEAA("put", 679, Current, 3, 2, 7750);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5286[dtype-679])(Current, tr1);
	RTHOOK(2);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5237[dtype-679])(Current)) {
		RTHOOK(3);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5292[dtype-679])(Current);
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5264[dtype-679])(Current);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(tr1))-600])(tr1, ti4_1);
		tr1 = RTCCL(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O5221[dtype-679]) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(5);
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5265[dtype-679])(Current)) {
			RTHOOK(6);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5305[dtype-679])(Current);
			RTHOOK(7);
			tr1 = RTCCL(arg2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5286[dtype-679])(Current, tr1);
			
		}
		RTHOOK(9);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5267[dtype-679]) == ((EIF_INTEGER_32) -1L))) {
			RTHOOK(10);
			tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
			loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5660[Dtype(RTCW(tr1))-858])(tr1);
			RTHOOK(11);
			loc3 = *(EIF_INTEGER_32 *)(Current + O5261[dtype-679]);
		} else {
			RTHOOK(12);
			loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5274[dtype-679])(Current, *(EIF_INTEGER_32 *)(Current + O5267[dtype-679]));
			RTHOOK(13);
			loc3 = *(EIF_INTEGER_32 *)(Current + O5267[dtype-679]);
			RTHOOK(14);
			tr1 = *(EIF_REFERENCE *)(Current + O5260[dtype-679]);
			F867_6511(RTCW(tr1), (EIF_BOOLEAN) 0, loc2);
		}
		RTHOOK(15);
		tr1 = *(EIF_REFERENCE *)(Current + O5259[dtype-679]);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + (loc3)) = loc2;
		/* END INLINED CODE */
		;
		RTHOOK(16);
		tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
		tr2 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5675[Dtype(RTCW(tr1))-858])(tr1, tr2, loc2);
		RTHOOK(17);
		tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
		tr2 = RTCCL(arg2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5675[Dtype(RTCW(tr1))-858])(tr1, tr2, loc2);
		RTHOOK(18);
		if (RTCEQ(arg2, loc1)) {
			RTHOOK(19);
			*(EIF_BOOLEAN *)(Current + O5262[dtype-679]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		RTHOOK(20);
		(*(EIF_INTEGER_32 *)(Current + O5307[dtype-679]))++;
		RTHOOK(21);
		tr1 = RTCCL(arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O5221[dtype-679]) = (EIF_REFERENCE) tr1;
		RTHOOK(22);
		*(EIF_INTEGER_32 *)(Current + O5266[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	}
	RTHOOK(33);
	RTLE;
	RTEE;
}

/* {HASH_TABLE}.force */
void F680_5841 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTEAA("force", 679, Current, 4, 2, 7751);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5286[dtype-679])(Current, tr1);
	RTHOOK(2);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5238[dtype-679])(Current)) {
		RTHOOK(3);
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5265[dtype-679])(Current)) {
			RTHOOK(4);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5305[dtype-679])(Current);
			RTHOOK(5);
			tr1 = RTCCL(arg2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5286[dtype-679])(Current, tr1);
		}
		RTHOOK(6);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5267[dtype-679]) == ((EIF_INTEGER_32) -1L))) {
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
			loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5660[Dtype(RTCW(tr1))-858])(tr1);
			RTHOOK(8);
			loc4 = *(EIF_INTEGER_32 *)(Current + O5261[dtype-679]);
		} else {
			RTHOOK(9);
			loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5274[dtype-679])(Current, *(EIF_INTEGER_32 *)(Current + O5267[dtype-679]));
			RTHOOK(10);
			loc4 = *(EIF_INTEGER_32 *)(Current + O5267[dtype-679]);
			RTHOOK(11);
			tr1 = *(EIF_REFERENCE *)(Current + O5260[dtype-679]);
			F867_6511(RTCW(tr1), (EIF_BOOLEAN) 0, loc3);
		}
		RTHOOK(12);
		tr1 = *(EIF_REFERENCE *)(Current + O5259[dtype-679]);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + (loc4)) = loc3;
		/* END INLINED CODE */
		;
		RTHOOK(13);
		tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
		tr2 = RTCCL(arg2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5675[Dtype(RTCW(tr1))-858])(tr1, tr2, loc3);
		RTHOOK(14);
		if (RTCEQ(arg2, loc1)) {
			RTHOOK(15);
			*(EIF_BOOLEAN *)(Current + O5262[dtype-679]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		RTHOOK(16);
		(*(EIF_INTEGER_32 *)(Current + O5307[dtype-679]))++;
		RTHOOK(17);
		tr1 = RTCCL(loc2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O5221[dtype-679]) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(18);
		loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5264[dtype-679])(Current);
		RTHOOK(19);
		tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(tr1))-600])(tr1, loc3);
		tr1 = RTCCL(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O5221[dtype-679]) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(20);
	tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
	tr2 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5675[Dtype(RTCW(tr1))-858])(tr1, tr2, loc3);
	RTHOOK(29);
	RTLE;
	RTEE;
}

/* {HASH_TABLE}.remove */
void F680_5846 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLIU(8);
	
	RTEAA("remove", 679, Current, 6, 1, 7756);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5286[dtype-679])(Current, tr1);
	RTHOOK(2);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5237[dtype-679])(Current)) {
		RTHOOK(3);
		loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5264[dtype-679])(Current);
		RTHOOK(4);
		if (RTCEQ(arg1, loc1)) {
			RTHOOK(5);
			*(EIF_BOOLEAN *)(Current + O5262[dtype-679]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current + O5260[dtype-679]);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_BOOLEAN *)RTCW(tr1) + (loc3)) = (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
		;
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current + O5259[dtype-679]);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current + O5261[dtype-679]))) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -loc3 + ((EIF_INTEGER_32) -2L));
		/* END INLINED CODE */
		;
		RTHOOK(8);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5263[dtype-679]) == loc3)) {
			RTHOOK(9);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5244[dtype-679])(Current);
		}
		RTHOOK(10);
		(*(EIF_INTEGER_32 *)(Current + O5307[dtype-679]))--;
		RTHOOK(11);
		ti4_1 = eif_min_int32 (loc3,*(EIF_INTEGER_32 *)(Current + O5271[dtype-679]));
		*(EIF_INTEGER_32 *)(Current + O5271[dtype-679]) = (EIF_INTEGER_32) ti4_1;
		RTHOOK(12);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5271[dtype-679]) == *(EIF_INTEGER_32 *)(Current + O5307[dtype-679]))) {
			RTHOOK(13);
			tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
			loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5660[Dtype(RTCW(tr1))-858])(tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(Current + O5271[dtype-679]);
			loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - ti4_1);
			RTHOOK(14);
			tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5688[Dtype(RTCW(tr1))-858])(tr1, loc4);
			RTHOOK(15);
			tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5688[Dtype(RTCW(tr1))-858])(tr1, loc4);
			RTHOOK(16);
			tr1 = *(EIF_REFERENCE *)(Current + O5260[dtype-679]);
			ti4_1 = *(EIF_INTEGER_32 *)(Current + O5271[dtype-679]);
			tr2 = *(EIF_REFERENCE *)(Current + O5260[dtype-679]);
			ti4_2 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr2);
			F867_6514(RTCW(tr1), (EIF_BOOLEAN) 0, ti4_1, (EIF_INTEGER_32) (ti4_2 - ((EIF_INTEGER_32) 1L)));
			RTHOOK(17);
			tr1 = RTCCL(loc2);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O5272[dtype-679]) = (EIF_REFERENCE) tr1;
			RTHOOK(18);
			tr1 = RTCCL(loc1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O5273[dtype-679]) = (EIF_REFERENCE) tr1;
			RTHOOK(19);
			*(EIF_INTEGER_32 *)(Current + O5271[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483645L);
		} else {
			RTHOOK(20);
			tr1 = *(EIF_REFERENCE *)(Current + O5272[dtype-679]);
			loc5 = RTCCL(tr1);
			tr1 = *(EIF_REFERENCE *)(Current + O5273[dtype-679]);
			loc6 = RTCCL(tr1);
			if ((EIF_BOOLEAN) (EIF_TEST(loc5) && EIF_TEST(loc6))) {
				RTHOOK(21);
				tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
				tr2 = RTCCL(loc5);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5674[Dtype(RTCW(tr1))-858])(tr1, tr2, loc3);
				RTHOOK(22);
				tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
				tr2 = RTCCL(loc6);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5674[Dtype(RTCW(tr1))-858])(tr1, tr2, loc3);
			} else {
				RTHOOK(23);
				tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(tr1))-600])(tr1, loc3);
				tr1 = RTCCL(tr1);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O5272[dtype-679]) = (EIF_REFERENCE) tr1;
				RTHOOK(24);
				tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(tr1))-600])(tr1, loc3);
				tr1 = RTCCL(tr1);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O5273[dtype-679]) = (EIF_REFERENCE) tr1;
			}
		}
		RTHOOK(25);
		*(EIF_INTEGER_32 *)(Current + O5266[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
		RTHOOK(26);
		tr1 = RTCCL(loc2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O5221[dtype-679]) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(32);
	RTLE;
	RTEE;
}

/* {HASH_TABLE}.prune */
void F680_5847 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("prune", 679, Current, 0, 1, 7757);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current + O4766[dtype-358])) {
		for (;;) {
			RTHOOK(2);
			tb1 = '\01';
			if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5239[dtype-679])(Current)) {
				tb1 = RTEQ((FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5226[dtype-679])(Current), arg1);
			}
			if (tb1) break;
			RTHOOK(3);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5244[dtype-679])(Current);
		}
	} else {
		for (;;) {
			RTHOOK(4);
			tb2 = '\01';
			if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5239[dtype-679])(Current)) {
				tb2 = RTCEQ((FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5226[dtype-679])(Current), arg1);
			}
			if (tb2) break;
			RTHOOK(5);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5244[dtype-679])(Current);
		}
	}
	RTHOOK(6);
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5239[dtype-679])(Current)) {
		RTHOOK(7);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5227[dtype-679])(Current);
		tr2 = RTCCL(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4908[dtype-679])(Current, tr2);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {HASH_TABLE}.wipe_out */
void F680_5848 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("wipe_out", 679, Current, 1, 0, 7758);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5694[Dtype(RTCW(tr1))-858])(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5694[Dtype(RTCW(tr1))-858])(tr1);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + O5260[dtype-679]);
	tr2 = *(EIF_REFERENCE *)(Current + O5260[dtype-679]);
	ti4_1 = F867_6504(RTCW(tr2));
	F867_6514(RTCW(tr1), (EIF_BOOLEAN) 0, ((EIF_INTEGER_32) 0L), ti4_1);
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + O5259[dtype-679]);
	F863_6514(RTCW(tr1), ((EIF_INTEGER_32) -1L), ((EIF_INTEGER_32) 0L), *(EIF_INTEGER_32 *)(Current + O5230[dtype-679]));
	RTHOOK(5);
	tr1 = RTCCL(loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O5221[dtype-679]) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	*(EIF_INTEGER_32 *)(Current + O5307[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(7);
	*(EIF_INTEGER_32 *)(Current + O5261[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(8);
	tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5660[Dtype(RTCW(tr1))-858])(tr1);
	*(EIF_INTEGER_32 *)(Current + O5263[dtype-679]) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(9);
	*(EIF_INTEGER_32 *)(Current + O5266[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(10);
	*(EIF_BOOLEAN *)(Current + O5262[dtype-679]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {HASH_TABLE}.linear_representation */
EIF_REFERENCE F680_5850 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("linear_representation", 679, Current, 1, 0, 7760);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(Current + O5263[dtype-679]);
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {688,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y4668,Y4668_gen_type,Dftype(Current),324);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		Result = RTLNS(typres0.id, 688, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5321[Dtype(RTCW(Result))-688])(Result, *(EIF_INTEGER_32 *)(Current + O5307[dtype-679]));
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5243[dtype-679])(Current);
	for (;;) {
		RTHOOK(4);
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5240[dtype-679])(Current)) break;
		RTHOOK(5);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5226[dtype-679])(Current);
		tr2 = RTCCL(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4895[Dtype(RTCW(Result))-661])(Result, tr2);
		RTHOOK(6);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5244[dtype-679])(Current);
	}
	RTHOOK(7);
	*(EIF_INTEGER_32 *)(Current + O5263[dtype-679]) = (EIF_INTEGER_32) loc1;
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.copy */
void F680_5851 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("copy", 679, Current, 0, 1, 7761);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		RTHOOK(2);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O5257[Dtype(arg1)-679]);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5278[dtype-679])(Current, tr1);
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O5258[Dtype(arg1)-679]);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5280[dtype-679])(Current, tr1);
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O5260[Dtype(arg1)-679]);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5281[dtype-679])(Current, tr1);
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O5259[Dtype(arg1)-679]);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5282[dtype-679])(Current, tr1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {HASH_TABLE}.empty_duplicate */
EIF_REFERENCE F680_5852 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("empty_duplicate", 679, Current, 0, 1, 7762);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5217[Dtype(RTCW(Result))-679])(Result, arg1);
	RTHOOK(2);
	if (*(EIF_BOOLEAN *)(Current + O4766[Dtype(Current)-358])) {
		RTHOOK(3);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4768[Dtype(RTCW(Result))-372])(Result);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.correct_mismatch */
void F680_5853 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc13 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_32 ti4_5;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc8);
	RTLR(4,loc9);
	RTLR(5,loc10);
	RTLR(6,loc1);
	RTLR(7,tr3);
	RTLR(8,loc5);
	RTLR(9,loc12);
	RTLR(10,loc7);
	RTLR(11,tr4);
	RTLR(12,loc6);
	RTLIU(13);
	
	RTEAA("correct_mismatch", 679, Current, 13, 0, 7763);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(5743,F677_5743, (Current));
	tr2 = RTMS_EX_H("hash_table_version_64",21,855604276);
	tb1 = F680_5802(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(2);
		tr1 = RTOSCF(5743,F677_5743, (Current));
		tr2 = RTMS_EX_H("content",7,460700276);
		tr1 = F680_5800(RTCW(tr1), tr2);
		loc8 = RTCCL(tr1);
		{
			static EIF_TYPE_INDEX typarr0[] = {600,0,0,0xFFFF};
			EIF_TYPE typres0;
			{
				EIF_TYPE l_type;
				l_type = eif_final_id(Y4668,Y4668_gen_type,dftype,324);
				typarr0[1] = l_type.annotations | 0xFF00;
				typarr0[2] = l_type.id;
			}
			
			typres0 = eif_compound_id(dftype, typarr0);
			loc8 = RTRV(typres0,loc8);
		}
		if (EIF_TEST(loc8)) {
			RTHOOK(3);
			tr1 = *(EIF_REFERENCE *)(loc8);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O5257[dtype-679]) = (EIF_REFERENCE) tr1;
		}
		RTHOOK(4);
		tr1 = RTOSCF(5743,F677_5743, (Current));
		tr2 = RTMS_EX_H("keys",4,1801812339);
		tr1 = F680_5800(RTCW(tr1), tr2);
		loc9 = RTCCL(tr1);
		{
			static EIF_TYPE_INDEX typarr0[] = {600,0,0,0xFFFF};
			EIF_TYPE typres0;
			{
				EIF_TYPE l_type;
				l_type = eif_final_id(Y4907,Y4907_gen_type,dftype,434);
				typarr0[1] = l_type.annotations | 0xFF00;
				typarr0[2] = l_type.id;
			}
			
			typres0 = eif_compound_id(dftype, typarr0);
			loc9 = RTRV(typres0,loc9);
		}
		if (EIF_TEST(loc9)) {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(loc9);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O5258[dtype-679]) = (EIF_REFERENCE) tr1;
		}
		RTHOOK(6);
		tr1 = RTOSCF(5743,F677_5743, (Current));
		tr2 = RTMS_EX_H("deleted_marks",13,2142169971);
		tr1 = F680_5800(RTCW(tr1), tr2);
		loc10 = RTCCL(tr1);
		{
			static EIF_TYPE_INDEX typarr0[] = {608,1000,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc10 = RTRV(typres0,loc10);
		}
		if (EIF_TEST(loc10)) {
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(loc10);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O5260[dtype-679]) = (EIF_REFERENCE) tr1;
		}
		RTHOOK(8);
		tb1 = '\0';
		tb2 = '\0';
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O5260[dtype-679]) != NULL) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O5258[dtype-679]) != NULL))) {
			tr1 = RTOSCF(5743,F677_5743, (Current));
			tr2 = RTMS_EX_H("hash_table_version_57",21,855604023);
			tb3 = F680_5802(RTCW(tr1), tr2);
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + O5260[dtype-679]);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
			tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
			ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5660[Dtype(RTCW(tr1))-858])(tr1);
			tb1 = (EIF_BOOLEAN)(ti4_1 != ti4_2);
		}
		if (tb1) {
			RTHOOK(9);
			loc1 = *(EIF_REFERENCE *)(Current + O5260[dtype-679]);
			RTHOOK(10);
			tr2 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5660[Dtype(RTCW(tr2))-858])(tr2);
			{
				static EIF_TYPE_INDEX typarr0[] = {866,1000,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNSP2(typres0.id,0,ti4_1,sizeof(EIF_BOOLEAN), EIF_TRUE);
				RT_SPECIAL_COUNT(tr1) = 0;
			}
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O5260[dtype-679]) = (EIF_REFERENCE) tr1;
			RTHOOK(11);
			tr1 = *(EIF_REFERENCE *)(Current + O5260[dtype-679]);
			ti4_2 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc1);
			/* INLINED CODE (SPECIAL.copy_data) */
			memmove((EIF_BOOLEAN *)RTCW(tr1) + (((EIF_INTEGER_32) 0L)),(EIF_BOOLEAN *)loc1 + ((EIF_INTEGER_32) 0L), (rt_uint_ptr)sizeof(EIF_BOOLEAN) * (rt_uint_ptr)ti4_2);
			RT_SPECIAL_COUNT(tr1) = eif_max_int32(RT_SPECIAL_COUNT(tr1), ((EIF_INTEGER_32) 0L) + ti4_2);
			/* END INLINED CODE */
			;
		}
		RTHOOK(12);
		tr2 = RTOSCF(5743,F677_5743, (Current));
		tr3 = RTMS_EX_H("count",5,1870727284);
		tr2 = F680_5800(RTCW(tr2), tr3);
		tr1 = RTCCL(tr2);
		RTOB(*(EIF_INTEGER_32 *), eif_new_type(1006, 0x00), tr1, loc11, tb1);
		if (tb1) {
			RTHOOK(13);
			loc4 = (EIF_INTEGER_32) loc11;
		}
		RTHOOK(14);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O5257[dtype-679]) == NULL) || (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O5258[dtype-679]) == NULL)) || (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O5260[dtype-679]) == NULL))) {
			RTHOOK(15);
			F677_5742(Current);
		} else {
			RTHOOK(16);
			tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
			loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5660[Dtype(RTCW(tr1))-858])(tr1);
			RTHOOK(17);
			loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5255[dtype-679])(Current, loc4);
			for (;;) {
				RTHOOK(18);
				if ((EIF_BOOLEAN)(loc2 == loc3)) break;
				RTHOOK(19);
				tb1 = '\0';
				tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(tr1))-600])(tr1, loc2);
				loc12 = RTCCL(tr1);
				if (EIF_TEST(loc12)) {
					tb1 = !RTCEQ(loc12, loc7);
				}
				if (tb1) {
					RTHOOK(20);
					tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(tr1))-600])(tr1, loc2);
					tr2 = RTCCL(tr1);
					tr3 = RTCCL(loc12);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4905[Dtype(RTCW(loc5))-600])(loc5, tr2, tr3);
				}
				RTHOOK(21);
				loc2++;
			}
			RTHOOK(22);
			tb1 = '\0';
			tr2 = RTOSCF(5743,F677_5743, (Current));
			tr3 = RTMS_EX_H("has_default",11,1777575796);
			tr2 = F680_5800(RTCW(tr2), tr3);
			tr1 = RTCCL(tr2);
			RTOB(*(EIF_BOOLEAN *), eif_new_type(1000, 0x00), tr1, loc13, tb2);
			if (tb2) {
				tb1 = loc13;
			}
			if (tb1) {
				RTHOOK(23);
				tr1 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
				tr2 = *(EIF_REFERENCE *)(Current + O5257[dtype-679]);
				ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5661[Dtype(RTCW(tr2))-858])(tr2);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(tr1))-600])(tr1, (EIF_INTEGER_32) (ti4_2 - ((EIF_INTEGER_32) 1L)));
				tr2 = RTCCL(tr1);
				tr3 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
				tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(tr3))-600])(tr3, (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
				tr4 = RTCCL(tr3);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4905[Dtype(RTCW(loc5))-600])(loc5, tr2, tr4);
			}
			RTHOOK(24);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + O5257[Dtype(loc5)-679]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5278[dtype-679])(Current, tr1);
			RTHOOK(25);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + O5258[Dtype(loc5)-679]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5280[dtype-679])(Current, tr1);
			RTHOOK(26);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + O5260[Dtype(loc5)-679]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5281[dtype-679])(Current, tr1);
			RTHOOK(27);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + O5259[Dtype(loc5)-679]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5282[dtype-679])(Current, tr1);
			RTHOOK(28);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc5) + O5230[Dtype(loc5)-679]);
			*(EIF_INTEGER_32 *)(Current + O5230[dtype-679]) = (EIF_INTEGER_32) ti4_2;
			RTHOOK(29);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc5) + O5263[Dtype(loc5)-679]);
			*(EIF_INTEGER_32 *)(Current + O5263[dtype-679]) = (EIF_INTEGER_32) ti4_2;
			RTHOOK(30);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc5) + O5267[Dtype(loc5)-679]);
			*(EIF_INTEGER_32 *)(Current + O5267[dtype-679]) = (EIF_INTEGER_32) ti4_2;
			RTHOOK(31);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc5) + O5261[Dtype(loc5)-679]);
			*(EIF_INTEGER_32 *)(Current + O5261[dtype-679]) = (EIF_INTEGER_32) ti4_2;
			RTHOOK(32);
			*(EIF_INTEGER_32 *)(Current + O5271[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483645L);
			RTHOOK(33);
			tr1 = RTCCL(loc6);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O5272[dtype-679]) = (EIF_REFERENCE) tr1;
			RTHOOK(34);
			tr1 = RTCCL(loc7);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O5273[dtype-679]) = (EIF_REFERENCE) tr1;
		}
		RTHOOK(35);
		*(EIF_INTEGER_32 *)(Current + O5266[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	RTHOOK(36);
	RTLE;
	RTEE;
}

/* {HASH_TABLE}.position */
EIF_INTEGER_32 F680_5862 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("position", 679, Current, 0, 0, 7772);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5259[dtype-679]);
	/* INLINED CODE (SPECIAL.item) */
	ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current + O5261[dtype-679])));
	/* END INLINED CODE */
	Result = ti4_3;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.soon_full */
EIF_BOOLEAN F680_5863 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("soon_full", 679, Current, 0, 0, 7773);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5660[Dtype(RTCW(tr1))-858])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
	ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5661[Dtype(RTCW(tr1))-858])(tr1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.ht_deleted_item */
EIF_REFERENCE F680_5870 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O5272[Dtype(Current)-679]);
}


/* {HASH_TABLE}.ht_deleted_key */
EIF_REFERENCE F680_5871 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O5273[Dtype(Current)-679]);
}


/* {HASH_TABLE}.deleted_position */
EIF_INTEGER_32 F680_5872 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("deleted_position", 679, Current, 0, 1, 7669);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5259[dtype-679]);
	/* INLINED CODE (SPECIAL.item) */
	ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (arg1));
	/* END INLINED CODE */
	Result = ti4_2;
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) -Result + ((EIF_INTEGER_32) -2L));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5660[Dtype(RTCW(tr1))-858])(tr1);
	ti4_1 = eif_min_int32 (Result,ti4_1);
	Result = (EIF_INTEGER_32) ti4_1;
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.occupied */
EIF_BOOLEAN F680_5873 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("occupied", 679, Current, 0, 1, 7670);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current + O5262[dtype-679])) {
		RTHOOK(2);
		Result = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + O5259[dtype-679]);
		/* INLINED CODE (SPECIAL.item) */
		ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current + O5230[dtype-679])));
		/* END INLINED CODE */
		ti4_1 = ti4_3;
		if ((EIF_BOOLEAN)(arg1 != ti4_1)) {
			tr1 = *(EIF_REFERENCE *)(Current + O5260[dtype-679]);
			/* INLINED CODE (SPECIAL.item) */
			tb2 = *((EIF_BOOLEAN *)RTCW(tr1) + (arg1));
			/* END INLINED CODE */
			tb1 = tb2;
			Result = (EIF_BOOLEAN) !tb1;
		}
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + O5260[dtype-679]);
		/* INLINED CODE (SPECIAL.item) */
		tb2 = *((EIF_BOOLEAN *)RTCW(tr1) + (arg1));
		/* END INLINED CODE */
		Result = tb2;
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.truly_occupied */
EIF_BOOLEAN F680_5874 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("truly_occupied", 679, Current, 0, 1, 7671);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5660[Dtype(RTCW(tr1))-858])(tr1);
		tb1 = (EIF_BOOLEAN) (arg1 < ti4_1);
	}
	if (tb1) {
		RTHOOK(2);
		Result = '\01';
		tb1 = '\0';
		if (*(EIF_BOOLEAN *)(Current + O5262[dtype-679])) {
			tr1 = *(EIF_REFERENCE *)(Current + O5259[dtype-679]);
			/* INLINED CODE (SPECIAL.item) */
			ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current + O5230[dtype-679])));
			/* END INLINED CODE */
			ti4_1 = ti4_3;
			tb1 = (EIF_BOOLEAN)(arg1 == ti4_1);
		}
		if (!tb1) {
			Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R5275[dtype-679])(Current, arg1);
		}
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.is_off_position */
EIF_BOOLEAN F680_5875 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_off_position", 679, Current, 0, 1, 7672);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!(EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + O5258[Dtype(Current)-679]);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5660[Dtype(RTCW(tr1))-858])(tr1);
		Result = (EIF_BOOLEAN) (arg1 >= ti4_1);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {HASH_TABLE}.set_content */
void F680_5876 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_content", 679, Current, 0, 1, 7673);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O5257[Dtype(Current)-679]) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {HASH_TABLE}.set_keys */
void F680_5878 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_keys", 679, Current, 0, 1, 7675);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O5258[Dtype(Current)-679]) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {HASH_TABLE}.set_deleted_marks */
void F680_5879 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_deleted_marks", 679, Current, 0, 1, 7676);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O5260[Dtype(Current)-679]) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {HASH_TABLE}.set_indexes_map */
void F680_5880 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_indexes_map", 679, Current, 0, 1, 7677);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O5259[Dtype(Current)-679]) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {HASH_TABLE}.internal_search */
void F680_5884 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,loc9);
	RTLR(4,loc10);
	RTLR(5,loc11);
	RTLR(6,tr1);
	RTLR(7,loc12);
	RTLR(8,tr2);
	RTLIU(9);
	
	RTEAA("internal_search", 679, Current, 12, 1, 7681);
	RTGC;
	RTHOOK(1);
	loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(2);
	if ((EIF_BOOLEAN) (RTCEQ(arg1, loc1) || (EIF_BOOLEAN)(arg1 == NULL))) {
		RTHOOK(3);
		*(EIF_INTEGER_32 *)(Current + O5261[dtype-679]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O5230[dtype-679]);
		RTHOOK(4);
		if (*(EIF_BOOLEAN *)(Current + O5262[dtype-679])) {
			RTHOOK(5);
			*(EIF_INTEGER_32 *)(Current + O5266[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		} else {
			RTHOOK(6);
			*(EIF_INTEGER_32 *)(Current + O5266[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
		}
	} else {
		RTHOOK(7);
		loc9 = *(EIF_REFERENCE *)(Current + O5258[dtype-679]);
		RTHOOK(8);
		loc10 = *(EIF_REFERENCE *)(Current + O5259[dtype-679]);
		RTHOOK(9);
		loc11 = *(EIF_REFERENCE *)(Current + O5260[dtype-679]);
		RTHOOK(10);
		loc6 = *(EIF_INTEGER_32 *)(Current + O5230[dtype-679]);
		RTHOOK(11);
		loc8 = (EIF_INTEGER_32) loc6;
		RTHOOK(12);
		tr1 = RTCCL(arg1);
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R5229[dtype-679])(Current, tr1);
		RTHOOK(13);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) (loc2 % (EIF_INTEGER_32) (loc6 - ((EIF_INTEGER_32) 1L))));
		RTHOOK(14);
		loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 % loc6) - loc3);
		RTHOOK(15);
		*(EIF_INTEGER_32 *)(Current + O5266[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
		for (;;) {
			RTHOOK(16);
			if ((EIF_BOOLEAN)(loc8 == ((EIF_INTEGER_32) 0L))) break;
			RTHOOK(17);
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + loc3) % loc6);
			RTHOOK(18);
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(loc10) + (loc5));
			/* END INLINED CODE */
			loc4 = ti4_2;
			RTHOOK(19);
			if ((EIF_BOOLEAN) (loc4 >= ((EIF_INTEGER_32) 0L))) {
				RTHOOK(20);
				loc12 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4944[Dtype(RTCW(loc9))-600])(loc9, loc4);
				RTHOOK(21);
				tr1 = RTCCL(loc12);
				tr2 = RTCCL(arg1);
				if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5231[dtype-679])(Current, tr1, tr2)) {
					RTHOOK(22);
					loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					RTHOOK(23);
					*(EIF_INTEGER_32 *)(Current + O5266[dtype-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
				}
			} else {
				RTHOOK(24);
				if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L))) {
					RTHOOK(25);
					loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				} else {
					RTHOOK(26);
					if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) -1L))) {
						RTHOOK(27);
						loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) -loc4 + ((EIF_INTEGER_32) -2L));
						
						RTHOOK(29);
						/* INLINED CODE (SPECIAL.item) */
						tb2 = *((EIF_BOOLEAN *)RTCW(loc11) + (loc4));
						/* END INLINED CODE */
						tb1 = tb2;
						if ((EIF_BOOLEAN) !tb1) {
							RTHOOK(30);
							loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							RTHOOK(31);
							loc7 = (EIF_INTEGER_32) loc5;
						}
					}
				}
			}
			RTHOOK(32);
			loc8--;
		}
		RTHOOK(33);
		*(EIF_INTEGER_32 *)(Current + O5261[dtype-679]) = (EIF_INTEGER_32) loc5;
	}
	RTHOOK(34);
	*(EIF_INTEGER_32 *)(Current + O5267[dtype-679]) = (EIF_INTEGER_32) loc7;
	RTHOOK(38);
	RTLE;
	RTEE;
}

/* {HASH_TABLE}.set_conflict */
void F680_5890 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_conflict", 679, Current, 0, 0, 7687);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O5266[Dtype(Current)-679]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(3);
	RTEE;
}

/* {HASH_TABLE}.add_space */
void F680_5903 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	
	
	RTEAA("add_space", 679, Current, 0, 0, 7700);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5220[dtype-679])(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5307[dtype-679]) + (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5307[dtype-679]) / ((EIF_INTEGER_32) 2L))));
	RTHOOK(4);
	RTEE;
}

void EIF_Minit1009 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
