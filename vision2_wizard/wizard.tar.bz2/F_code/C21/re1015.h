
#ifndef _C21_re1015_
#define _C21_re1015_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F535_5273(EIF_REFERENCE);
extern void F535_5275(EIF_REFERENCE);
extern void EIF_Minit1015(void);
extern char *(*R4922[])();
extern char *(*R4928[])();

#ifdef __cplusplus
}
#endif

#endif
